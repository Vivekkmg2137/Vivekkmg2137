﻿using AutoMapper;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Models.ViewModels;
using Models.ViewModels.LineOfBusiness.Property.Input;
using Models.ApiModels.LineOfBusiness.Property.Input;
using Models.ViewModels.Policy;
using Models.ApiModels.Policy;
using Models.ViewModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ViewModels.LineOfBusiness.EmploymentPractices.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Input;
using Models.ViewModels.LineOfBusiness.Excess.Input;
using Models.ApiModels.LineOfBusiness.Excess.Input;
using Models.ViewModels.LineOfBusiness.GeneralLiability.Input;
using Models.ApiModels.LineOfBusiness.GeneralLiability.Input;
using Models.ViewModels.LineOfBusiness.InlandMarine.Input;
using Models.ApiModels.LineOfBusiness.InlandMarine.Input;
using Models.ApiModels.LineOfBusiness.Ocp.Input;
using Api.Models.ViewModels.LineOfBusiness.Ocp.Input;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Input;
using Models.ViewModels.LineOfBusiness.Property.Output;
using Models.ApiModels.LineOfBusiness.Property.Output;
using Api.Models.ViewModels.LineOfBusiness.Ocp.Output;
using Models.ApiModels.LineOfBusiness.Ocp.Output;
using Api.Models.ViewModels.LineOfBusiness.Property.Input;
using Api.Models.ViewModels.LineOfBusiness.Property.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Output;
using Models.ViewModels.LineOfBusiness.Auto.AutoLiability.Input;
using Api.Models.ViewModels.LineOfBusiness.Auto.AutoLiability.Output;
using Models.ViewModels.LineOfBusiness.Auto.AutoPhysicalDamage.Input;
using Api.Models.ViewModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output;
using Models.ViewModels.LineOfBusiness.Auto.AutoSchedule.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Input;
using Api.Models.ViewModels.LineOfBusiness.Auto.AutoSchedule.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Output;
using Models.ViewModels.LineOfBusiness.Auto;
using Models.ApiModels.LineOfBusiness.Auto;
using Models.ViewModels.LineOfBusiness.EmploymentPracticesSchool.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPracticesSchool.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPracticesSchool.Output;
using Api.Models.ViewModels.LineOfBusiness.EmploymentPracticesSchool.Output;
using Models.ApiModels.Pricing.Input;
using Api.Models.ViewModels.Pricing.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Output;
using Api.Models.ViewModels.LineOfBusiness.EmploymentPractices.Output;
using Models.ApiModels.LineOfBusiness.EmploymentPracticesOutput;
using Api.Models.ViewModels.LineOfBusiness.LawEnforcement.Input;
using Api.Models.ViewModels.LineOfBusiness.LawEnforcement.Output;
using Models.ApiModels.LineOfBusiness.LawEnforcement.Input;
using Models.ApiModels.LineOfBusiness.LawEnforcement.Output;
using Models.ApiModels.Pricing.Output;
using Models.ViewModels.Pricing.Output;
using Api.Models.ViewModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Output;
using Api.Models.ViewModels.LineOfBusiness.EducatorsLegal.Output;
using Models.ViewModels.LineOfBusiness.EducatorsLegal.Output;
using Api.Models.ViewModels.LineOfBusiness.PublicOfficials.Input;
using Api.Models.ViewModels.LineOfBusiness.PublicOfficials.Output;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Output;
using Api.Models.ViewModels.LineOfBusiness.DirectorsAndOfficers.Input;
using Api.Models.ViewModels.LineOfBusiness.DirectorsAndOfficers.Output;
using Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Input;
using Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Output;
using Models.ApiModels.LineOfBusiness.PublicOfficials;
using Api.Models.ViewModels.LineOfBusiness.PublicOfficials;
using Api.Models.ViewModels.LineOfBusiness.Auto;
using Models.ViewModels.LineOfBusiness.GeneralLiability.Input;
using Models.ApiModels.LineOfBusiness.GeneralLiability.output;
using Models.ApiModels.LineOfBusiness.GeneralLiability.Input;
using Models.ViewModels.LineOfBusiness.GeneralLiability.output;

namespace Api
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            #region Policy
            CreateMap<PolicyHeaderViewModel, PolicyHeaderModel>().ReverseMap();
            CreateMap<LineOfBusinessInputViewModel, LineOfBusinessInputModel>().ReverseMap();
            CreateMap<LineOfBusinessOutputViewModel, LineOfBusinessOutputModel>().ReverseMap();
            CreateMap<LastTransactionViewModel, LastTransactionModel>().ReverseMap();
            CreateMap<PremiumSummaryViewModel, PremiumSummaryModel>().ReverseMap();
            CreateMap<LobIncludedViewModel, LobIncludedModel>().ReverseMap();
            #endregion

            #region Auto
            CreateMap<AutoInputViewModel, AutoInputModel>().ReverseMap();
            CreateMap<AutoOutputViewModel, AutoOutputModel>().ReverseMap();
            CreateMap<CWInputViewModel, CWInputModel>().ReverseMap();
            CreateMap<OutputViewModel, OutputModel>().ReverseMap();
            #endregion

            #region AutoLiability
            CreateMap<AutoLiabilityInputViewModel, AutoLiabilityInputModel>().ReverseMap();
            CreateMap<AutoLiabilityOutputViewModel, AutoLiabilityOutputModel>().ReverseMap();
            CreateMap<AutoLiabilityOptionalCoverageInputViewModel, AutoLiabilityOptionalCoverageInputModel>().ReverseMap();
            CreateMap<AutoLiabilityOptionalCoverageOutputViewModel, AutoLiabilityOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<AutoLiabilityOptionalOtherCoverageInputViewModel, AutoLiabilityOptionalOtherCoverageInputModel>().ReverseMap();
            CreateMap<AutoLiabilityOptionalOtherCoverageOutputViewModel, AutoLiabilityOptionalOtherCoverageOutputModel>().ReverseMap();
            #endregion

            #region Auto Physical Damage
            CreateMap<AutoPhysicalDamageInputViewModel, AutoPhysicalDamageInputModel>().ReverseMap();
            CreateMap<AutoPhysicalDamageOutputViewModel, AutoPhysicalDamageOutputModel>().ReverseMap();
            CreateMap<AutoPhysicalDamageOptionalCoverageInputViewModel, AutoPhysicalDamageOptionalCoverageInputModel>().ReverseMap();
            CreateMap<AutoPhysicalDamageOptionalCoverageOutputViewModel, AutoPhysicalDamageOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<CollisionOutputViewModel, CollisionOutputModel>().ReverseMap();
            CreateMap<ComprehensiveOutputViewModel, ComprehensiveOutputModel>().ReverseMap();
            CreateMap<SpecifiedCausesofLossOutputViewModel, SpecifiedCausesofLossOutputModel>().ReverseMap();
            CreateMap<AutoPhysicalDamageOptionalOtherCoverageInputViewModel, AutoPhysicalDamageOptionalOtherCoverageInputModel>().ReverseMap();
            CreateMap<AutoPhysicalDamageOptionalOtherCoverageOutputViewModel, AutoPhysicalDamageOptionalOtherCoverageOutputModel>().ReverseMap();
            #endregion

            #region AutoSchedule
            CreateMap<AutoScheduleVehiclesDetailsInputViewModel, AutoScheduleVehiclesDetailsInputModel>().ReverseMap();
            CreateMap<AutoScheduleVehiclesDetailsOutputViewModel, AutoScheduleVehiclesDetailsOutputModel>().ReverseMap();
            CreateMap<AutoSchedulePervehiclePremiumDetailsOutputViewModel, AutoSchedulePervehiclePremiumDetailsOutputModel>().ReverseMap();
            #endregion            

            //#region Educators Legal
            //CreateMap<EducatorsLegalCwInputViewModel, EducatorsLegalCwInputModel>().ReverseMap();
            //#endregion

            #region Employment Practices
            CreateMap<EmploymentPracticesInputViewModel, EmploymentPracticesInputModel>().ReverseMap();
            CreateMap<EmploymentPracticesOutputViewModel, EmploymentPracticesOutputModel>().ReverseMap();
            CreateMap<EmploymentPracticesOptionalCoverageInputViewModel, EmploymentPracticesOptionalCoverageInputModel>().ReverseMap();
            CreateMap<EmploymentPracticesOtherCoverageInputViewModel, EmploymentPracticesOtherCoverageInputModel>().ReverseMap();
            CreateMap<EmploymentPracticesOptionalCoverageOutputViewModel, EmploymentPracticesOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<EmploymentPracticesOtherCoverageInputViewModel, EmploymentPracticesOtherCoverageInputModel>().ReverseMap();
            CreateMap<EmploymentPracticesOtherCoverageOutputViewModel, EmploymentPracticesOtherCoverageOutputModel>().ReverseMap();
            #endregion 

            #region Excess
            CreateMap<ExcessInputViewModel, ExcessInputModel>().ReverseMap();
            #endregion

            #region GeneralLiability
            CreateMap<GeneralLiabilityInputViewModel, GeneralLiabilityInputModel>().ReverseMap();
            CreateMap<GeneralLiabilityOutputViewModel, GeneralLiabilityOutputModel>().ReverseMap();

            CreateMap<GeneralLiabilityOptionalCoverageInputViewModel, GeneralLiabilityOptionalCoverageInputModel>().ReverseMap();
            CreateMap<GeneralLiabilityOptionalCoverageOutputViewModel, GeneralLiabilityOptionalCoverageOutputModel>().ReverseMap();

            CreateMap<GeneralLiabilityOptionalOtherCoverageInputViewModel, GeneralLiabilityOptionalOtherCoverageInputModel>().ReverseMap();
            CreateMap<GeneralLiabilityOptionalOtherCoverageOutputViewModel, GeneralLiabilityOptionalOtherCoverageOutputModel>().ReverseMap();

            #endregion

            #region InlandMarine
            CreateMap<InlandMarineInputViewModel, InlandMarineInputModel>().ReverseMap();
            #endregion

            #region Ocp
            CreateMap<OcpInputViewModel, OcpInputModel>().ReverseMap();
            CreateMap<OcpOutputViewModel, OcpOutputModel>().ReverseMap();
            #endregion

            #region Property

            CreateMap<PropertyInputViewModel, PropertyInputModel>().ReverseMap();
            CreateMap<Property360InputViewModel, Property360InputModel>().ReverseMap();
            CreateMap<Property360OptionalCoverageInputViewModel, Property360OptionalCoverageInputModel>().ReverseMap();
            CreateMap<Property360OptionalVacancyPermitInputViewModel, Property360OptionalVacancyPermitInputModel>().ReverseMap();
            CreateMap<Property360OptionalVehiclePhysicalDamageInputViewModel, Property360OptionalVehiclePhysicalDamageInputModel>().ReverseMap();
            CreateMap<Property360OptionalLossOfMunicipalTaxRevenueInputViewModel, Property360OptionalLossOfMunicipalTaxRevenueInputModel>().ReverseMap();
            CreateMap<PropertyScheduleRatingInputViewModel, PropertyScheduleRatingInputModel>().ReverseMap();
            CreateMap<PropertyOptionalCoverageInputViewModel, PropertyOptionalCoverageInputModel>().ReverseMap();
            CreateMap<PropertyOptionalOtherCoverageInputViewModel, PropertyOptionalOtherCoverageInputModel>().ReverseMap();
            CreateMap<PropertyStateSpecificInputViewModel, PropertyStateSpecificInputModel>().ReverseMap();
            CreateMap<BuildingScheduleInputViewModel, BuildingScheduleInputModel>().ReverseMap();
            CreateMap<PropertyNewYork360InputViewModel, PropertyNewYork360InputModel>().ReverseMap();
            CreateMap<PropertyOptionalOtherCoverageInputViewModel, PropertyOptionalOtherCoverageInputModel>().ReverseMap();

            CreateMap<PropertyOutputViewModel, PropertyOutputModel>().ReverseMap();
            CreateMap<Property360OutputViewModel, Property360OutputModel>().ReverseMap();   
            CreateMap<Property360OptionalCoverageOutputViewModel, Property360OptionalCoverageOutputModel>().ReverseMap();
            CreateMap<Property360OptionalLossOfMunicipalTaxRevenueOutputViewModel, Property360OptionalLossOfMunicipalTaxRevenueOutputModel>().ReverseMap();

            CreateMap<PropertyScheduleRatingOutputViewModel, PropertyScheduleRatingOutputModel>().ReverseMap();            
            CreateMap<PropertyStateSpecificOutputViewModel, PropertyStateSpecificOutputModel>().ReverseMap();
            CreateMap<BuildingScheduleOutputViewModel, BuildingScheduleOutputModel>().ReverseMap();
            CreateMap<PropertyNewYork360OutputViewModel, PropertyNewYork360OutputModel>().ReverseMap();
            CreateMap<GroupedBuildingScheduleOutputViewModel, GroupedBuildingScheduleOutputModel>().ReverseMap();
            CreateMap<PropertyOptionalCoverageOutputViewModel, PropertyOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<PropertyOptionalOtherCoverageOutputViewModel, PropertyOptionalOtherCoverageOutputModel>().ReverseMap();
            #endregion

            #region Public Officials
            CreateMap<PublicOfficialsInputViewModel, PublicOfficialsInputModel>().ReverseMap();
            CreateMap<PublicOfficialsOutputViewModel, PublicOfficialsOutputModel>().ReverseMap();
            CreateMap<PublicOfficialsCWInputViewModel, PublicOfficialsCWInputModel>().ReverseMap();
            CreateMap<PublicOfficialsCWOutputViewModel, PublicOfficialsCWOutputModel>().ReverseMap();
            #endregion

            #region Rater Facade
            CreateMap<RaterFacadeViewModel, RaterFacadeModel>().ReverseMap();
            CreateMap<RaterInputFacadeViewModel, RaterInputFacadeModel>().ReverseMap();
            CreateMap<RaterOutputFacadeViewModel, RaterOutputFacadeModel>().ReverseMap();

            #endregion

            #region LawEnforcement

            CreateMap<LawEnforcementInputViewModel, LawEnforcementInputModel>().ReverseMap();
            CreateMap<LawEnforcementOutputViewModel, LawEnforcementOutputModel>().ReverseMap();
            CreateMap<LawEnforcementOptionalCoverageInputViewModel,  LawEnforcementOptionalCoverageInputModel>().ReverseMap();
            CreateMap<LawEnforcementOptionalCoverageOutputViewModel, LawEnforcementOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<LawEnforcementOptionalOtherCoverageInputViewModel, LawEnforcementOptionalOtherCoverageInputModel>().ReverseMap();
            CreateMap<LawEnforcementOptionalOtherCoverageOutputViewModel, LawEnforcementOptionalOtherCoverageOutputModel>().ReverseMap();
            #endregion

            #region DirectorsAndOfficers

            CreateMap<DirectorsAndOfficersInputViewModel, DirectorsAndOfficersInputModel>().ReverseMap();
            CreateMap<DirectorsAndOfficersOutputViewModel, DirectorsAndOfficersOutputModel>().ReverseMap();
            CreateMap<DirectorsAndOfficersOptionalCoverageInputViewModel, DirectorsAndOfficersOptionalCoverageInputModel>().ReverseMap();
            CreateMap<DirectorsAndOfficersOptionalCoverageOutputViewModel, DirectorsAndOfficersOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<DirectorsAndOfficersOptionalOtherCoverageInputViewModel, DirectorsAndOfficersOptionalOtherCoverageInputModel>().ReverseMap();
            CreateMap<DirectorsAndOfficersOptionalOtherCoverageOutputViewModel, DirectorsAndOfficersOptionalOtherCoverageOutputModel>().ReverseMap();

            #endregion

            #region Employment Practices School
            CreateMap<EmploymentPracticesSchoolInputViewModel, EmploymentPracticesSchoolInputModel>().ReverseMap();
            CreateMap<EmploymentPracticesSchoolOptionalCoverageInputViewModel, EmploymentPracticesSchoolOptionalCoverageInputModel>().ReverseMap();
            CreateMap<EmploymentPracticesSchoolOtherCoverageInputViewModel, EmploymentPracticesSchoolOtherCoverageInputModel>().ReverseMap();

            CreateMap<EmploymentPracticesSchoolOutputViewModel, EmploymentPracticesSchoolOutputModel>().ReverseMap();
            CreateMap<EmploymentPracticesSchoolOptionalCoverageOutputViewModel, EmploymentPracticesSchoolOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<EmploymentPracticesSchoolOtherCoverageOutputViewModel, EmploymentPracticesSchoolOtherCoverageOutputModel>().ReverseMap();

            #endregion

            #region Pricing
            CreateMap<PricingInputViewModel, PricingInputModel> ().ReverseMap();
            CreateMap<PricingOutputViewModel, PricingOutputModel>().ReverseMap();
            #endregion

            #region Educators Legal
            CreateMap<EducatorsLegalInputViewModel, EducatorsLegalInputModel>().ReverseMap();
            CreateMap<EducatorsLegalCwInputViewModel, EducatorsLegalCwInputModel>().ReverseMap();
            CreateMap<EducatorsLegalCwOptionalCoverageInputViewModel, EducatorsLegalCwOptionalCoverageInputModel>().ReverseMap();
            CreateMap<EducatorsLegalNyInputViewModel, EducatorsLegalNyInputModel>().ReverseMap();
            CreateMap<EducatorsLegalNyOptionalCoverageInputViewModel, EducatorsLegalNyOptionalCoverageInputModel>().ReverseMap(); 
            CreateMap<EducatorsLegalOtherCoverageInputViewModel, EducatorsLegalOtherCoverageInputModel>().ReverseMap();
            CreateMap<EducatorsLegalNyOtherCoverageInputViewModel, EducatorsLegalNyOtherCoverageInputModel>().ReverseMap();

            CreateMap<EducatorsLegalOutputViewModel, EducatorsLegalOutputModel>().ReverseMap();
            CreateMap<EducatorsLegalCwOutputViewModel, EducatorsLegalCwOutputModel>().ReverseMap();
            CreateMap<EducatorsLegalCwOptionalCoverageOutputViewModel, EducatorsLegalCwOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<EducatorsLegalNyOutputViewModel, EducatorsLegalNyOutputModel>().ReverseMap();
            CreateMap<EducatorsLegalNyOptionalCoverageOutputViewModel, EducatorsLegalNyOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<EducatorsLegalOtherCoverageOutputViewModel, EducatorsLegalOtherCoverageOutputModel>().ReverseMap();
            #endregion

            #region PublicOfficials
            CreateMap<PublicOfficialsInputViewModel, PublicOfficialsInputModel>().ReverseMap();
            CreateMap<PublicOfficialsCWInputViewModel, PublicOfficialsCWInputModel>().ReverseMap();
            CreateMap<PublicOfficialsCWOptionalCoverageInputViewModel, PublicOfficialsCWOptionalCoverageInputModel>().ReverseMap();
            CreateMap<PublicOfficialsCWOtherCoverageInputViewModel, PublicOfficialsCWOtherCoverageInputModel>().ReverseMap();
            CreateMap<PublicOfficialsNYInputViewModel, PublicOfficialsNYInputModel>().ReverseMap();
            CreateMap<PublicOfficialsNYOptionalCoverageInputViewModel, PublicOfficialsNYOptionalCoverageInputModel>().ReverseMap();
            CreateMap<PublicOfficialsNYOtherCoverageInputViewModel, PublicOfficialsNYOtherCoverageInputModel>().ReverseMap();

            CreateMap<PublicOfficialsOutputViewModel, PublicOfficialsOutputModel>().ReverseMap();
            CreateMap<PublicOfficialsCWOutputViewModel, PublicOfficialsCWOutputModel>().ReverseMap();
            CreateMap<PublicOfficialsCWOptionalCoverageOutputViewModel, PublicOfficialsCWOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<PublicOfficialsCWOtherCoverageOutputViewModel, PublicOfficialsCWOtherCoverageOutputModel>().ReverseMap();
            CreateMap<PublicOfficialsNYOutputViewModel, PublicOfficialsNYOutputModel>().ReverseMap();
            CreateMap<PublicOfficialsNYOptionalCoverageOutputViewModel, PublicOfficialsNYOptionalCoverageOutputModel>().ReverseMap();
            CreateMap<PublicOfficialsNYOtherCoverageOutputViewModel, PublicOfficialsNYOtherCoverageOutputModel>().ReverseMap();

            #endregion
        }
    }
}
