﻿using Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ViewModels;
using RaterProperty;
using System;
using System.Collections.Generic;
using Models.Initialization;
using System.Diagnostics;
using RaterAutoLiability;
using RaterOCP;
using AutoMapper;
using System.Reflection;
using Microsoft.AspNetCore.Hosting;
using System.Data.SqlClient;
using RaterLawEnforcement;
using RaterPricing;
using RaterPublicOfficials;
using RaterEmploymentPractices;
using RateEmploymentPracticesSchool;
using RaterDirectorsAndOfficers;
using RateEducatorsLegal;
using RaterPolicyHeader;
using RaterGeneralLiability;

namespace Api.Controllers
{
    /// <summary>
    /// Rating engine
    /// </summary>
    /// 
    [ApiController]
    [Route("api/[controller]")]
    public class RaterController : Controller
    {
        /// <summary>
        /// Gets or sets LoggingManager
        /// </summary>
        protected ILoggingManager _Logger { get; private set; }

        readonly IConfiguration _Configuration;

        /// <summary>
        /// SqlConnectionString
        /// </summary>
        private string _SqlConnectionString { get; set; }

        private readonly IMapper _mapper;

        private readonly IWebHostEnvironment _environment;

        /// <summary>
        /// RaterController
        /// </summary>
        /// <param name="env"></param>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        /// <param name="mapper"></param>
        public RaterController(IWebHostEnvironment env, IConfiguration configuration, ILoggingManager logger, IMapper mapper)
        {
            this._Logger = logger;
            this._Configuration = configuration;
            this._mapper = mapper;
            this._environment = env;
        }

        /// <summary>
        /// Get heartbeat for rater
        /// </summary>
        /// <returns>string</returns>
        public IEnumerable<string> Get()
        {

            SqlConnectionStringBuilder sqlconnectionbuilder = new SqlConnectionStringBuilder(this._Configuration["ConnectionStrings:SqlDBConnection"]);
            var dbName = sqlconnectionbuilder.InitialCatalog;
            var dbServer = sqlconnectionbuilder.DataSource;
            string timeStampId = Convert.ToString(Guid.NewGuid());

            _Logger.Info("HeartBeat: Api is live!");
            _Logger.Info("TimeStampId: " + timeStampId);
            _Logger.Info("Product: " + Convert.ToString(Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyProductAttribute>().Product));
            _Logger.Info("Company: " + Convert.ToString(Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyCompanyAttribute>().Company));
            _Logger.Info("Product/Package Version (InformationalVersion): " + Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion);
            _Logger.Info("File Version: " + Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version);
            _Logger.Info("Environment: " + this._environment.EnvironmentName);
            _Logger.Info("Database Server: " + dbServer);
            _Logger.Info("Database Name: " + dbName);

            return new string[] {
                "HeartBeat: Api is live!",
                "TimeStampId: " + timeStampId,
                "Product: " + Convert.ToString(Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyProductAttribute>().Product),
                "Description: " + Convert.ToString(Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyDescriptionAttribute>().Description),
                "Company: " + Convert.ToString(Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyCompanyAttribute>().Company),
                "Copyright: " + Convert.ToString(Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyCopyrightAttribute>().Copyright),
                "Product/Package Version (InformationalVersion): " + Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                "File Version: " + Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                "Environment: " + this._environment.EnvironmentName,
                "Database Server: " + dbServer,
                "Database Name: "+ dbName,
        };
        }

        /// <summary>
        /// Rate : It will rate premium for selected LOBs
        /// </summary>
        /// <param name="model">Input Model</param>
        /// <returns>IActionResult</returns>
        [HttpPost]
        [Route("Rate")]
        [Consumes("application/json")]
        [RequestFormLimits(ValueCountLimit = int.MaxValue)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        //[ProducesResponseType(200, Type = typeof(JsonResult))]
        ///[ProducesResponseType(200, Type = typeof(ResponseInfoModel))]
        [ProducesResponseType(200, Type = typeof(RaterOutputFacadeViewModel))]
        public IActionResult Rate([FromBody] RaterInputFacadeViewModel model)
        {
            RaterOutputFacadeViewModel raterOutputFacadeViewModel = new RaterOutputFacadeViewModel();
            raterOutputFacadeViewModel.ResponseModel = new ResponseInfoModel();

            //Check for not null models
            if (model == null)
            {
                _Logger.Error($"{nameof(model)} cannot be null");
                return BadRequest($"{nameof(model)} cannot be null");
            }

            if (model.LineOfBusiness == null)
            {
                _Logger.Error($"{nameof(model.LineOfBusiness)} cannot be null");
                return BadRequest($"{nameof(model.LineOfBusiness)} cannot be null");
            }

            RaterInputFacadeModel raterInputFacadeModel = new RaterInputFacadeModel();
            raterInputFacadeModel = this._mapper.Map(model, raterInputFacadeModel);

            //Prepare facade model from input to pass on to LOBs
            RaterFacadeModel raterFacadeModel = new InitializeFacade().GetRaterFacadeModelFromInput(raterInputFacadeModel);

            try
            {
                PolicyHeaderService service = new PolicyHeaderService(this._Configuration, this._Logger);
                //var domainValidationResults = service.ExecuteDomainRules(raterFacadeModel);

                var fluentValidationResult = service.PreValidate(raterFacadeModel);

                if (!fluentValidationResult.IsValid)
                {
                    ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, fluentValidationResult);

                    //Return response object with pre validation errors
                    raterOutputFacadeViewModel.ResponseModel = raterFacadeModel.RaterOutputFacadeModel.ResponseModel;
                    return new JsonResult(raterOutputFacadeViewModel);
                }

                //Process LOBs
                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.Property == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecutePropertyLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        raterOutputFacadeViewModel.ResponseModel = raterFacadeModel.RaterOutputFacadeModel.ResponseModel;
                        return new JsonResult(raterOutputFacadeViewModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("Property calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.Auto == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteAutoLiabilityLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        raterOutputFacadeViewModel.ResponseModel = raterFacadeModel.RaterOutputFacadeModel.ResponseModel;
                        return new JsonResult(raterOutputFacadeViewModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("Auto calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.Ocp1 == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteOCPLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        raterOutputFacadeViewModel.ResponseModel = raterFacadeModel.RaterOutputFacadeModel.ResponseModel;
                        return new JsonResult(raterOutputFacadeViewModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("OCP1 calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.Ocp2 == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteOCPLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        return new JsonResult(raterFacadeModel.RaterOutputFacadeModel.ResponseModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("OCP2 calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.Ocp3 == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteOCPLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        return new JsonResult(raterFacadeModel.RaterOutputFacadeModel.ResponseModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("OCP3 calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.Ocp4 == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteOCPLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        return new JsonResult(raterFacadeModel.RaterOutputFacadeModel.ResponseModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("OCP4 calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.Ocp5 == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteOCPLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        return new JsonResult(raterFacadeModel.RaterOutputFacadeModel.ResponseModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("OCP5 calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.EmploymentPractices == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteEmploymentPracticesLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        raterOutputFacadeViewModel.ResponseModel = raterFacadeModel.RaterOutputFacadeModel.ResponseModel;
                        return new JsonResult(raterOutputFacadeViewModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("Employment Practices calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.EmploymentPracticesSchool == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteEmploymentPracticesSchoolLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        raterOutputFacadeViewModel.ResponseModel = raterFacadeModel.RaterOutputFacadeModel.ResponseModel;
                        return new JsonResult(raterOutputFacadeViewModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("Employment Practices School calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.LawEnforcement == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteLawEnforcementLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        return new JsonResult(raterFacadeModel.RaterOutputFacadeModel.ResponseModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("Law enforcement calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.PublicOfficials == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecutePublicOfficialsLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        raterOutputFacadeViewModel.ResponseModel = raterFacadeModel.RaterOutputFacadeModel.ResponseModel;
                        return new JsonResult(raterOutputFacadeViewModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("Public Officials time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.DirectorsAndOfficers == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteDirectorsAndOfficersLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        return new JsonResult(raterFacadeModel.RaterOutputFacadeModel.ResponseModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("Directors And Officers calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }                

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.EducatorsLegal == true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteEducatorLegalLOB(raterFacadeModel);

                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults);

                        //Return response object with pre validation errors
                        return new JsonResult(raterFacadeModel.RaterOutputFacadeModel.ResponseModel);
                    }

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("Educator Legal calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if(raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.GeneralLiability==true)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    var validationResults = ExecuteGeneralLiabilityLOB(raterFacadeModel);
                    //Process and return is pre calculation validate are not success
                    if (!validationResults.IsValid)
                    {
                        ProcessFluentValidationErrors(raterFacadeModel.RaterOutputFacadeModel.ResponseModel, validationResults); 

                        //Return response object with pre validation errors
                        return new JsonResult(raterFacadeModel.RaterOutputFacadeModel.ResponseModel);
                    }
                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("General Liability calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                if (raterFacadeModel.RaterInputFacadeModel.PricingInputModel != null)
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    raterFacadeModel = ExecutePricingLOB(raterFacadeModel);

                    stopwatch.Stop();
                    raterFacadeModel.RaterOutputFacadeModel.ResponseModel.SystemLog.Add("Pricing calculation time: " + stopwatch.ElapsedMilliseconds + " Milli Seconds");
                }

                raterFacadeModel.RaterOutputFacadeModel.ResponseModel.Successful = true;
                raterFacadeModel.RaterOutputFacadeModel.ResponseModel.Status = "200 (OK)";

                raterOutputFacadeViewModel = this._mapper.Map(raterFacadeModel.RaterOutputFacadeModel, raterOutputFacadeViewModel);

                return new JsonResult(raterOutputFacadeViewModel);
            }
            catch (Exception ex)
            {
                string timeStampIdFormattedString = "[TimeStampId: " + Convert.ToString(Guid.NewGuid()) + "] ";
                raterOutputFacadeViewModel.ResponseModel.Successful = false;
                string errorMessageForInvalidInput = "Something went wrong with input provided. Please check input data!";
                this._Logger.Error(timeStampIdFormattedString + "Error: " + errorMessageForInvalidInput);
                raterOutputFacadeViewModel.ResponseModel.Messages.Add(timeStampIdFormattedString + "Error: " + errorMessageForInvalidInput);
                raterOutputFacadeViewModel.ResponseModel.Status = "500 (Internal Server Error) " + errorMessageForInvalidInput;

                if (ex.Message != null)
                {
                    // System error, operation is successful
                    this.ModelState.AddModelError(string.Empty, ex.Message);
                    this._Logger.Error(timeStampIdFormattedString + "RaterController.Rate: 500 (Internal Server Error) - " + ex.Message, ex);
                    raterOutputFacadeViewModel.ResponseModel.Messages.Add(timeStampIdFormattedString + "Error: " + ex.GetBaseException().Message);
                }

                return new JsonResult(raterOutputFacadeViewModel);
            }
        }

        /// <summary>
        /// ProcessValidationErrors
        /// </summary>
        /// <param name="response">Response info model</param>
        /// <param name="validationResults">Validation result</param>
        private void ProcessFluentValidationErrors(ResponseInfoModel response, FluentValidation.Results.ValidationResult validationResults)
        {
            //Create Model Validation error list
            foreach (var error in validationResults.Errors)
            {
                this.ModelState.AddModelError(string.Empty, error.PropertyName + ": " + error.ErrorCode + " " + error.ErrorMessage);

                response.Messages.Add(error.PropertyName + ": " + error.ErrorCode + " " + error.ErrorMessage);
            }

            response.Successful = false;
            response.Status = "422 (Unprocessable Entity)";
        }

        private void ProcessDomainValidationErrors(ResponseInfoModel response, DomainValidationCore.Validation.ValidationResult validationResults)
        {
            //Create Model Validation error list
            foreach (var error in validationResults.Errors)
            {
                this.ModelState.AddModelError(string.Empty, error.Name + ": " + error.Message);

                response.Messages.Add(error.Name + ": " + error.Message);
            }

            response.Successful = false;
            response.Status = "422 (Unprocessable Entity)";
        }

        /// <summary>
        /// ExecutePropertyLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacade model</param>
        /// <returns>ValidationResult</returns>
        private FluentValidation.Results.ValidationResult ExecutePropertyLOB(RaterFacadeModel raterFacadeModel)
        {
            PropertyServiceWrapper wrapper = new PropertyServiceWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecutePropertyEngine(raterFacadeModel);
            return validationResults;
        }

        /// <summary>
        /// ExecuteAutoLiabilityLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacade Model</param>
        /// <returns>ValidationResult</returns>
        private FluentValidation.Results.ValidationResult ExecuteAutoLiabilityLOB(RaterFacadeModel raterFacadeModel)
        {
            AutoServiceWrapper wrapper = new AutoServiceWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecuteAutoLiabilityEngine(raterFacadeModel);
            return validationResults;
        }

        /// <summary>
        /// ExecuteOCPLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacadeModel</param>
        /// <returns>ValidationResult</returns>
        private FluentValidation.Results.ValidationResult ExecuteOCPLOB(RaterFacadeModel raterFacadeModel)
        {
            OcpServiceWrapper wrapper = new OcpServiceWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecuteOcpEngine(raterFacadeModel);
            return validationResults;
        }

        /// <summary>
        /// ExecuteEmploymentPracticesLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacadeModel</param>
        /// <returns>ValidationResult</returns>
        private FluentValidation.Results.ValidationResult ExecuteEmploymentPracticesLOB(RaterFacadeModel raterFacadeModel)
        {
            EmploymentPracticesWrapper wrapper = new EmploymentPracticesWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecuteEmploymentPracticesEngine(raterFacadeModel);
            return validationResults;
        }

        /// <summary>
        /// ExecuteEmploymentPracticesSchoolLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacade Model</param>
        /// <returns>ValidationResult</returns>
        private FluentValidation.Results.ValidationResult ExecuteEmploymentPracticesSchoolLOB(RaterFacadeModel raterFacadeModel)
        {
            EmploymentPracticesSchooIWrapper wrapper = new EmploymentPracticesSchooIWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecuteEmploymentPracticesSchoolEngine(raterFacadeModel);
            return validationResults;
        }

        /// <summary>
        /// ExecuteLawEnforcementLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacade Model</param>
        /// <returns>ValidationResult</returns>
        private FluentValidation.Results.ValidationResult ExecuteLawEnforcementLOB(RaterFacadeModel raterFacadeModel)
        {
            LawEnforcementServiceWrapper wrapper = new LawEnforcementServiceWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecuteLawEnforcementEngine(raterFacadeModel);
            return validationResults;
        }

        /// <summary>
        /// ExecuteDirectorsAndOfficersLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacade Model</param>
        /// <returns>ValidationResult</returns>
        private FluentValidation.Results.ValidationResult ExecuteDirectorsAndOfficersLOB(RaterFacadeModel raterFacadeModel)
        {
            DirectorsAndOfficersServiceWrapper wrapper = new DirectorsAndOfficersServiceWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecuteDirectorsAndOfficersEngine(raterFacadeModel);
            return validationResults;
        }

        /// <summary>
        /// ExecutePricingLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacade Model</param>
        /// <returns>RaterFacadeModel</returns>
        private RaterFacadeModel ExecutePricingLOB(RaterFacadeModel raterFacadeModel)
        {
            PricingServiceWrapper wrapper = new PricingServiceWrapper(this._Configuration, this._Logger);

            return wrapper.ExecutePricingEngine(raterFacadeModel);
        }

        /// <summary>
        /// ExecutePublicOfficialsLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacade Model</param>
        /// <returns>ValidationResult</returns>
        private FluentValidation.Results.ValidationResult ExecutePublicOfficialsLOB(RaterFacadeModel raterFacadeModel)
        {
            PublicOfficialsWrapper wrapper = new PublicOfficialsWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecutePublicOfficialsEngine(raterFacadeModel);
            return validationResults;
        }

        /// <summary>
        /// ExecuteEducatorLegalLOB
        /// </summary>
        /// <param name="raterFacadeModel">RaterFacade Model</param>
        /// <returns>ValidationResult</returns>
        private FluentValidation.Results.ValidationResult ExecuteEducatorLegalLOB(RaterFacadeModel raterFacadeModel)
        {
            EducatorsLegalWrapper wrapper = new EducatorsLegalWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecuteEducatorsLegalEngine(raterFacadeModel);
            return validationResults;
        }

        private FluentValidation.Results.ValidationResult ExecuteGeneralLiabilityLOB(RaterFacadeModel raterFacadeModel)
        {
            GeneralLiabilityServiceWrapper wrapper = new GeneralLiabilityServiceWrapper(this._Configuration, this._Logger);
            var validationResults = wrapper.ExecuteGeneralLiabilityEngine(raterFacadeModel);
            return validationResults;
        }
    }
}
