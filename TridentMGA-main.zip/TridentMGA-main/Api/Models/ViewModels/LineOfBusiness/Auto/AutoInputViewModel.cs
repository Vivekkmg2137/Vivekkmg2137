﻿using Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Input;
using Models.ViewModels.LineOfBusiness.Auto.AutoLiability.Input;
using Models.ViewModels.LineOfBusiness.Auto.AutoPhysicalDamage.Input;
using Models.ViewModels.LineOfBusiness.Auto.AutoSchedule.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.Auto
{
    public class AutoInputViewModel
    {
        public CWInputViewModel CW { get; set; }

        public CWInputViewModel NY { get; set; }
    }

    public class CWInputViewModel
    {
        public AutoLiabilityInputViewModel AutoLiabilityInputModel { get; set; }
        public bool HasAutoPhysicalDamage { get; set; }
        public AutoPhysicalDamageInputViewModel AutoPhysicalDamageInputModel { get; set; }
        public List<AutoScheduleVehiclesDetailsInputViewModel> AutoScheduleVehiclesDetailsInputModel { get; set; }
    }
}
