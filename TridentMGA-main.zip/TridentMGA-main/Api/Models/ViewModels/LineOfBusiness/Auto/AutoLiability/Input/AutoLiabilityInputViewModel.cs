﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Models.ViewModels.LineOfBusiness.Auto.AutoLiability.Input
{
    public class AutoLiabilityInputViewModel
    {
        public AutoLiabilityInputViewModel()
        {
        }
           
        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "AL";

        /// <summary>
        /// Gets or sets LimitType
        /// </summary>
        public string LimitType { get; set; }

        /// <summary>
        /// Gets or sets LiabilityLimit
        /// </summary>
        public string LiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets LiabilityLimitRate
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Get or sets HiredAndNonOwned
        /// </summary>
        public string HiredAndNonOwned { get; set; }

        /// <summary>
        /// Get or sets Deductible_SIR
        /// </summary>
        public string Deductible_SIR { get; set; }

        /// <summary>
        /// Get or sets Retention
        /// </summary>
        public int Retention { get; set; }

        /// <summary>
        ///  Get or sets Expense
        /// </summary>
        public string Expense { get; set; }

        /// <summary>
        /// Get or sets AggregateRetention
        /// </summary>
        public int AggregateRetention { get; set; }

        /// <summary>
        /// Get or sets MedicalPaymentsLimit
        /// </summary>
        public string MedicalPaymentsLimit { get; set; }

        /// <summary>
        /// Get or sets MedPayAggregate
        /// </summary>
        public int MedPayAggregate { get; set; }

        /// <summary>
        /// Gets or sets UninsuredLimit
        /// </summary>
        public string UninsuredLimit { get; set; }
        public string UninsuredBIPDLimit { get; set; }
        public string UninsuredPD { get; set; }
        public string UninsuredDeductible { get; set; }
        public string UninsuredCondition { get; set; }
        public string UnderinsuredLimit { get; set; }
        public bool UnderinsuredConversion { get; set; }
        public bool UMUIMStacking { get; set; }
        public string PersonalInjuryProtectionLimit { get; set; }
        public string PIPDeductible { get; set; }
        public string AdditionalPIPLimit { get; set; }
        public int AdditionalMonthlyWorkLossLimit { get; set; }
        public int AdditionalPIPOtherExpensesPerDayLimit { get; set; }
        public string AdditionalDeathBenefitLimit { get; set; }
        public string OBELLimit { get; set; }
        public string PIPMedicalExpenseEliminationLimit { get; set; }
        public string ExcessAttendantCareLimit { get; set; }
        public string PropertyProtectionInsuranceLimit { get; set; }
        public string PropertyProtectionDeductible { get; set; }
        public string PropertyDamageLiabilityBuybackLimit { get; set; }
        public string PIPWorkLossExclusionLimit { get; set; }
        public string BasicFPBLimit { get; set; }
        public string AdditionalBenefitsLimit { get; set; }
        public string CombinationFPBLimit { get; set; }
        public string MedicalExpenseBenefitsLimit { get; set; }
        public string WorkLossBenefitsLimit { get; set; }
        public string FuneralExpenseBenefitsLimit { get; set; }
        public string AccidentalDeathBenefitsLimit { get; set; }
        public string ExtraordinaryMedicalBenefitsLimit { get; set; }
        public string PedestrianFPBLimit { get; set; }
        public int NonEmergencyUnitsCount { get; set; }
        public decimal NonEmergencyUnitsBaseRate { get; set; }
        public int EmergencyUnitsCount { get; set; }
        public decimal EmergencyUnitsBaseRate { get; set; }
        public int BusesCount { get; set; }
        public decimal BusesBaseRate { get; set; }
        public int TrailersCount { get; set; }
        public decimal TrailersBaseRate { get; set; }
        public int TotalVehiclesCount { get; set; }
        public int TotalVehicleswithoutTrailersCount { get; set; }
        public int NonEmergencyPIPUnitsCount { get; set; }
        public int EmergencyPIPUnitsCount { get; set; }
        public int BusesPIPUnitsCount { get; set; }
        public int TotalPIPUnitswithoutTrailersCount { get; set; }
        public int NonEmergencyMedPayUnitsCount { get; set; }
        public int EmergencyMedPayUnitsCount { get; set; }
        public int BusesMedPayUnitsCount { get; set; }
        public int TotalMedPayUnitswithoutTrailersCount { get; set; }
        public string LiabilitySymbol { get; set; }
        public string PersonalInjuryProtectionSymbol { get; set; }
        public string MedicalPaymentsSymbol { get; set; }
        public string UninsuredMotoristSymbol { get; set; }
        public string UnderinsuredMotoristSymbol { get; set; }
        public bool IRPMApplies { get; set; }
        public decimal OtherModRate { get; set; }
        public decimal IRPMRate { get; set; }

        #region Optional Coverage
        public AutoLiabilityOptionalCoverageInputViewModel AutoLiabilityOptionalCoverageInputModel { get; set; }

        #endregion
    }
}
