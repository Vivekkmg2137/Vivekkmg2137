﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.Auto.AutoLiability.Input
{
    public class AutoLiabilityOptionalCoverageInputViewModel
    {

        #region Additional Insured Designated Person Or Organization - CA201
        public int AdditionalInsuredDesignatedPersonOrOrganizationCA201CoverageID { get; set; }
        public bool AdditionalInsuredDesignatedPersonOrOrganizationCA201IsSelected { get; set; }
        public int AdditionalInsuredDesignatedPersonOrOrganizationCA201Limit { get; set; }
        public int AdditionalInsuredDesignatedPersonOrOrganizationCA201Deductible { get; set; }
        public string AdditionalInsuredDesignatedPersonOrOrganizationCA201RatingBasis { get; set; }
        public string AdditionalInsuredDesignatedPersonOrOrganizationCA201ReturnMethod { get; set; }
        public decimal AdditionalInsuredDesignatedPersonOrOrganizationCA201Rate { get; set; }
        public int AdditionalInsuredDesignatedPersonOrOrganizationCA201UnModifiedPremium { get; set; }
        public int AdditionalInsuredDesignatedPersonOrOrganizationCA201ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured Endorsement - Auto - AG1009

        public int AdditionalInsuredEndorsementAutoAG1009CoverageID { get; set; }
        public bool AdditionalInsuredEndorsementAutoAG1009IsSelected { get; set; }
        public int AdditionalInsuredEndorsementAutoAG1009Limit { get; set; }
        public int AdditionalInsuredEndorsementAutoAG1009Deductible { get; set; }
        public string AdditionalInsuredEndorsementAutoAG1009RatingBasis { get; set; }
        public string AdditionalInsuredEndorsementAutoAG1009ReturnMethod { get; set; }
        public decimal AdditionalInsuredEndorsementAutoAG1009Rate { get; set; }
        public int AdditionalInsuredEndorsementAutoAG1009UnModifiedPremium { get; set; }
        public int AdditionalInsuredEndorsementAutoAG1009ModifiedPremium { get; set; }

        #endregion

        #region Lessor - Additional Insured And Loss Payee - CA 20 01
        public int LessorAdditionalInsuredAndLossPayeeCA2001CoverageID { get; set; }
        public bool LessorAdditionalInsuredAndLossPayeeCA2001IsSelected { get; set; }
        public int LessorAdditionalInsuredAndLossPayeeCA2001Limit { get; set; }
        public int LessorAdditionalInsuredAndLossPayeeCA2001Deductible { get; set; }
        public string LessorAdditionalInsuredAndLossPayeeCA2001RatingBasis { get; set; }
        public string LessorAdditionalInsuredAndLossPayeeCA2001ReturnMethod { get; set; }
        public decimal LessorAdditionalInsuredAndLossPayeeCA2001Rate { get; set; }
        public int LessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremium { get; set; }
        public int LessorAdditionalInsuredAndLossPayeeCA2001ModifiedPremium { get; set; }

        #endregion

        #region Mutual Aid - CA 2025
        public int MutualAidCoverageID { get; set; }
        public bool MutualAidIsSelected { get; set; }
        public int MutualAidCA2025Limit { get; set; }
        public int MutualAidCA2025Deductible { get; set; }
        public string MutualAidCA2025RatingBasis { get; set; }
        public string MutualAidCA2025ReturnMethod { get; set; }
        public decimal MutualAidCA2025Rate { get; set; }
        public int MutualAidCA2025UnModifiedPremium { get; set; }
        public int MutualAidCA2025ModifiedPremium { get; set; }

        #endregion

        public int OtherCoverageUnModifiedPremium { get; set; }
        public int OtherCoverageModifiedPremium { get; set; }
        public List<AutoLiabilityOptionalOtherCoverageInputViewModel> AutoLiabilityOptionalOtherCoverageInputModels { get; set; }
    }

    public class AutoLiabilityOptionalOtherCoverageInputViewModel
    {
        public int OtherCoverageID { get; set; }
        public string OtherCoverageDescription { get; set; }   
        public int OtherCoverageLimit { get; set; }
        public int OtherCoverageDedcutible { get; set; }
        public decimal OtherCoverageRate { get; set; }
        public string OtherCoverageRatingBasis { get; set; }
        public string OtherCoverageReturnMethod { get; set; }
        public int OtherCoveragePremium { get; set; }      

    }
}
