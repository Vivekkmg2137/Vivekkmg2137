﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Api.Models.ViewModels.LineOfBusiness.Auto.AutoLiability.Output
{
    public class AutoLiabilityOutputViewModel
    {
        /// <summary>
        /// Get or sets HiredAndNonOwnedModifiedPremium
        /// </summary>
        public decimal HiredAndNonOwnedModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets HiredAndNonOwnedUnModifiedPremium
        /// </summary>
        public int HiredAndNonOwnedUnModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets Deductible_SIRFactor
        /// </summary>
        public decimal Deductible_SIRFactor { get; set; }

        /// <summary>
        /// Get or sets LiabilityLimitRate
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Get or sets LiabilityUnModifiedPremium
        /// </summary>
        public decimal LiabilityUnModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets LiabilityModifiedPremium
        /// </summary>
        public decimal LiabilityModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets MedicalPaymentsModifiedPremium
        /// </summary>
        public decimal MedicalPaymentsModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets MedicalPaymentsUnModifiedPremium
        /// </summary>
        public decimal MedicalPaymentsUnModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets UninsuredModifiedPremium
        /// </summary>
        public decimal UninsuredModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets UninsuredUnModifiedPremium
        /// </summary>
        public decimal UninsuredUnModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets UnderinsuredModifiedPremium
        /// </summary>
        public decimal UnderinsuredModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets UnderinsuredUnModifiedPremium
        /// </summary>
        public decimal UnderinsuredUnModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets PersonalInjuryProtectionRate
        /// </summary>
        public decimal PersonalInjuryProtectionRate { get; set; }

        /// <summary>
        /// Get or sets PersonalInjuryProtectionModifiedPremium
        /// </summary>
        public decimal PersonalInjuryProtectionModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets PersonalInjuryProtectionUnModifiedPremium
        /// </summary>
        public decimal PersonalInjuryProtectionUnModifiedPremium { get; set; }

        /// <summary>
        /// Get or sets ExcessAttendantCareNonEmergencyRate
        /// </summary>
        public decimal ExcessAttendantCareNonEmergencyRate { get; set; }

        /// <summary>
        /// Get or sets ExcessAttendantCareEmergencyRate
        /// </summary>
        public decimal ExcessAttendantCareEmergencyRate { get; set; }

        /// <summary>
        /// Get or sets ExcessAttendantCareBusesRate
        /// </summary>
        public decimal ExcessAttendantCareBusesRate { get; set; }

        /// <summary>
        /// Get or sets BasicFPBRate
        /// </summary>
        public decimal BasicFPBRate { get; set; }

        /// <summary>
        /// Get or sets NonEmergencyUnitsCount
        /// </summary>
        public int NonEmergencyUnitsCount { get; set; }

        /// <summary>
        /// Get or sets NonEmergencyUnitsBaseRate
        /// </summary>
        public decimal NonEmergencyUnitsBaseRate { get; set; }

        /// <summary>
        /// Get or sets EmergencyUnitsCount
        /// </summary>
        public int EmergencyUnitsCount { get; set; }

        /// <summary>
        /// Get or sets EmergencyUnitsBaseRate
        /// </summary>
        public decimal EmergencyUnitsBaseRate { get; set; }

        /// <summary>
        /// Get or sets BusesCount
        /// </summary>
        public int BusesCount { get; set; }

        /// <summary>
        /// Get or sets BusesBaseRate
        /// </summary>
        public decimal BusesBaseRate { get; set; }

        /// <summary>
        /// Get or sets TrailersCount
        /// </summary>
        public int TrailersCount { get; set; }

        /// <summary>
        /// Get or sets TrailersBaseRate
        /// </summary>
        public decimal TrailersBaseRate { get; set; }

        /// <summary>
        /// Get or sets TotalVehiclesCount
        /// </summary>
        public int TotalVehiclesCount { get; set; }

        /// <summary>
        /// Get or sets TotalVehicleswithoutTrailersCount
        /// </summary>
        public int TotalVehicleswithoutTrailersCount { get; set; }

        /// <summary>
        /// Get or sets NonEmergencyPIPUnitsCount
        /// </summary>
        public int NonEmergencyPIPUnitsCount { get; set; }

        /// <summary>
        /// Get or sets EmergencyPIPUnitsCount
        /// </summary>
        public int EmergencyPIPUnitsCount { get; set; }

        /// <summary>
        /// Get or sets BusesPIPUnitsCount
        /// </summary>
        public int BusesPIPUnitsCount { get; set; }

        /// <summary>
        /// Get or sets TotalPIPUnitswithoutTrailersCount
        /// </summary>
        public int TotalPIPUnitswithoutTrailersCount { get; set; }

        /// <summary>
        /// Get or sets NonEmergencyMedPayUnitsCount
        /// </summary>
        public int NonEmergencyMedPayUnitsCount { get; set; }

        /// <summary>
        /// Get or sets EmergencyMedPayUnitsCount
        /// </summary>
        public int EmergencyMedPayUnitsCount { get; set; }

        /// <summary>
        /// Get or sets BusesMedPayUnitsCount
        /// </summary>
        public int BusesMedPayUnitsCount { get; set; }

        /// <summary>
        /// Get or sets TotalMedPayUnitswithoutTrailersCount
        /// </summary>
        public int TotalMedPayUnitswithoutTrailersCount { get; set; }

        /// <summary>
        /// Get or sets MIMCCAAssessmentRate
        /// </summary>
        public decimal MIMCCAAssessmentRate { get; set; }

        /// <summary>
        /// Get or sets MIMCCAAssessmentRatingExposure
        /// </summary>
        public int MIMCCAAssessmentRatingExposure { get; set; }

        /// <summary>
        /// Get or sets MIMCCAAssessmentCharge
        /// </summary>
        public decimal MIMCCAAssessmentCharge { get; set; }

        /// <summary>
        /// Get or sets NCAutoLossRecoupmentSurchargeRate
        /// </summary>
        public decimal NCAutoLossRecoupmentSurchargeRate { get; set; }

        /// <summary>
        /// Get or sets NCAutoLossRecoupmentSurchargeRatingExposure
        /// </summary>
        public int NCAutoLossRecoupmentSurchargeRatingExposure { get; set; }

        /// <summary>
        /// Get or sets NCAutoLossRecoupmentSurchargeCharge
        /// </summary>
        public decimal NCAutoLossRecoupmentSurchargeCharge { get; set; }

        /// <summary>
        /// Gets or sets NYMotorVehicleLawEnforcementFeeRatingExposure
        /// </summary>
        public int NYMotorVehicleLawEnforcementFeeRatingExposure { get; set; }

        /// <summary>
        /// Gets or sets NYMotorVehicleLawEnforcementFeeRate
        /// </summary>
        public decimal NYMotorVehicleLawEnforcementFeeRate { get; set; }

        /// <summary>
        /// Gets or sets NYMotorVehicleLawEnforcementFeeCharge
        /// </summary>
        public decimal NYMotorVehicleLawEnforcementFeeCharge { get; set; }

        /// <summary>
        /// Gets or sets BasePremium
        /// </summary>
        public int BasePremium { get; set; }
        public int NonModifiedPremium { get; set; }
        public int ManualPremium { get; set; }
        public int IRPMPremium { get; set; }
        public decimal TerrorismRate { get; set; }
        public int TerrorismPremium { get; set; }
        public decimal LocationRate { get; set; }
        public decimal PopulationRate { get; set; }
        public decimal OtherModRate { get; set; }
        public int OtherModPremium { get; set; }
        public decimal TierRate { get; set; }
        public int TierPremium { get; set; }
        public int APRP { get; set; }
        public int ALModifiedFinalPremium { get; set; }


        #region Optional Coverage
        public AutoLiabilityOptionalCoverageOutputViewModel AutoLiabilityOptionalCoveragesOutputModel { get; set; }

        #endregion

        [JsonIgnore]
        public int MinimumPremium { get; set; }
        public decimal PersonalInjuryProtectionNonEmergencyRate { get; set; }
        public decimal PersonalInjuryProtectionEmergencyRate { get; set; }
        public decimal PersonalInjuryProtectionBusesRate { get; set; }
        public decimal BasicFPBNonEmergencyRate { get; set; }
        public decimal BasicFPBEmergencyRate { get; set; }
        public decimal BasicFPBBusesRate { get; set; }
        public decimal MedicalPaymentsNonEmergencyRate { get; set; }
        public decimal MedicalPaymentsEmergencyRate { get; set; }
        public decimal MedicalPaymentsBusesRate { get; set; }
        public decimal UninsuredNonEmergencyRate { get; set; }
        public decimal UninsuredEmergencyRate { get; set; }
        public decimal UninsuredBusesRate { get; set; }
        public decimal UninsuredBIPDNonEmergencyRate { get; set; }
        public decimal UninsuredBIPDEmergencyRate { get; set; }
        public decimal UninsuredBIPDBusesRate { get; set; }
        public decimal UnderinsuredNonEmergencyRate { get; set; }
        public decimal UnderinsuredEmergencyRate { get; set; }
        public decimal UnderinsuredBusesRate { get; set; }
       
    }

}
