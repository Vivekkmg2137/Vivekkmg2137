﻿using Api.Models.ViewModels.LineOfBusiness.Auto.AutoLiability.Output;
using Api.Models.ViewModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output;
using Api.Models.ViewModels.LineOfBusiness.Auto.AutoSchedule.Output;
using System;
using System.Collections.Generic;
using System.Text;

namespace Api.Models.ViewModels.LineOfBusiness.Auto
{
    public class AutoOutputViewModel
    {
        public OutputViewModel CW { get; set; }
        public OutputViewModel NY { get; set; }
    }

    public class OutputViewModel
    {
        public AutoLiabilityOutputViewModel AutoLiabilityOutputModel { get; set; }
        public AutoPhysicalDamageOutputViewModel AutoPhysicalDamageOutputModel { get; set; }
        public AutoScheduleVehiclesDetailsOutputViewModel AutoScheduleRatingOutputModel { get; set; }
    }
}

