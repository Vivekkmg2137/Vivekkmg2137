﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Api.Models.ViewModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output
{
    public class CollisionOutputViewModel
    {
        public int CollisionOCNPerCategory { get; set; }
        public int CollisionDeductibleperCategory { get; set; }
        public decimal CollisionDeductibleFactorperCategory { get; set; }
        public int CollisionVehiclescountpercategory { get; set; }
        public string CollisionValuationperCategory { get; set; }
        public decimal CollisionValuationFactorperCategory { get; set; }
        public int CollisionPremiumperCategory { get; set; }
    }
}
