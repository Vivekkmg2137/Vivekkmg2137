﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Api.Models.ViewModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output
{
    public class ComprehensiveOutputViewModel
    {
        public int ComprehensiveOCNPerCategory { get; set; }
        public int ComprehensiveDeductibleperCategory { get; set; }
        public decimal ComprehensiveDeductibleFactorperCategory { get; set; }
        public int ComprehensiveVehiclesCountpercategory { get; set; }
        public string ComprehensiveValuationperCategory { get; set; }
        public decimal ComprehensiveValuationFactorperCategory { get; set; }
        public int ComprehensivePremiumperCategory { get; set; }
    }
}
