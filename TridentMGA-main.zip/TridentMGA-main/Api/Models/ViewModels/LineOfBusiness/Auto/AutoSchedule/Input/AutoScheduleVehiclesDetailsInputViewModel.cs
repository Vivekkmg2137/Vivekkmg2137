﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.Auto.AutoSchedule.Input
{
    public class AutoScheduleVehiclesDetailsInputViewModel
    {
        #region APD

        #region AL
        public int Vehicle { get; set; }
        public string VIN { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string ClassCode { get; set; }
        public string RatingGroup { get; set; }
        #endregion

        public int OCN { get; set; }
        public string Valuation { get; set; }
        public int CompDeductible { get; set; }
        public int CollDeductible { get; set; }
        public int SpecifiedCauseofLossDeductible { get; set; }
        #endregion
    }
}

