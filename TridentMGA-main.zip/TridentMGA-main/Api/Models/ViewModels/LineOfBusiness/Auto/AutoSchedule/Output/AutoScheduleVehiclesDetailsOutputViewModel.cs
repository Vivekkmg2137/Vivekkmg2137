﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Api.Models.ViewModels.LineOfBusiness.Auto.AutoSchedule.Output
{

    public class AutoScheduleVehiclesDetailsOutputViewModel
    {
        public List<AutoSchedulePervehiclePremiumDetailsOutputViewModel> AutoSchedulePerVehiclePremiumDetails { get; set; }
        public int TotalSchedulePremium1 { get; set; }
        public int Difference1 { get; set; }
        public int TotalSchedulePremium2 { get; set; }
        public int Difference2 { get; set; }
    }


    public class AutoSchedulePervehiclePremiumDetailsOutputViewModel
    {
        public int Vehicle { get; set; }

        [JsonIgnore]
        public string RatingGroup { get; set; }
        public int UMUIMPremiumPerVehicle { get; set; }
        public int PIPPremiumPerVehicle { get; set; }
        public int MedPayPremiumPerVehicle { get; set; }
        public int OtherPremiumPerVehicle { get; set; }
        public int LiabilityPremiumPerVehicle { get; set; }
        public int FinalLiabilityPremiumPerVehicle { get; set; }
        public int APDPremiumPerVehicle { get; set; }
        public int TotalVehiclePremiumwithALAndAPD { get; set; }
    }

}
