﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Crime.Input
{
    /// <summary>
    /// CrimeCWInputViewModel
    /// </summary>
    public class CrimeCWInputViewModel
    {
        /// <summary>
        /// Gets or sets LineOfBusiness.
        /// </summary>
        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "CR";

        /// <summary>
        /// Gets or sets ClassAEmployees.
        /// </summary>
        public int ClassAEmployees { get; set; }

        /// <summary>
        /// Gets or sets ChairPersonsandMembersCount.
        /// </summary>
        public bool ChairPersonsandMembersCountIsSelected { get; set; }

        /// <summary>
        /// Gets or sets ChairPersonsandMembersCount.
        /// </summary>
        public int ChairPersonsandMembersCount { get; set; }

        /// <summary>
        /// Gets or sets VolunteersCountIsSelected.
        /// </summary>
        public bool VolunteersCountIsSelected { get; set; }

        /// <summary>
        /// Gets or sets Count.
        /// </summary>
        public int Count { get; set; }


        /// <summary>
        /// Gets or sets VolunteersOtherthanSolicitorsCountIsSelected.
        /// </summary>
        public bool VolunteersOtherthanSolicitorsCountIsSelected { get; set; }

        /// <summary>
        /// Gets or sets VolunteersOtherthanSolicitorsCount.
        /// </summary>
        public int VolunteersOtherthanSolicitorsCount { get; set; }

        /// <summary>
        /// Gets or sets StudentsCountIsSelected.
        /// </summary>
        public bool StudentsCountIsSelected { get; set; }

        /// <summary>
        /// Gets or sets StudentsCount.
        /// </summary>
        public int StudentsCount { get; set; }

        /// <summary>
        /// Gets or sets TreasurersorTaxCollectorsCountIsSelected.
        /// </summary>
        public bool TreasurersorTaxCollectorsCountIsSelected { get; set; }

        /// <summary>
        /// Gets or sets TreasurersorTaxCollectorsCount.
        /// </summary>
        public int TreasurersorTaxCollectorsCount { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossIsSelected.
        /// </summary>
        public bool EmployeeTheftPerLossIsSelected { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossLimit.
        /// </summary>
        public int EmployeeTheftPerLossLimit { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossDeductible.
        /// </summary>
        public int EmployeeTheftPerLossDeductible { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossBaseRate.
        /// </summary>
        public decimal EmployeeTheftPerLossBaseRate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeIsSelected.
        /// </summary>
        public bool EmployeeTheftPerEmployeeIsSelected { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeLimit.
        /// </summary>
        public int EmployeeTheftPerEmployeeLimit { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeDedcutible.
        /// </summary>
        public int EmployeeTheftPerEmployeeDedcutible { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeBaseRate.
        /// </summary>
        public decimal EmployeeTheftPerEmployeeBaseRate { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyIsSelected.
        /// </summary>
        public bool FaithfulPerformanceofDutyIsSelected { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyLimit.
        /// </summary>
        public int FaithfulPerformanceofDutyLimit { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyDeductible
        /// </summary>
        public int FaithfulPerformanceofDutyDeductible { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyBaseRate.
        /// </summary>
        public decimal FaithfulPerformanceofDutyBaseRate { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondIsSelected.
        /// </summary>
        public bool ExcessOverStatutoryBondIsSelected { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondLimit.
        /// </summary>
        public int ExcessOverStatutoryBondLimit { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondDeductible.
        /// </summary>
        public int ExcessOverStatutoryBondDeductible { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondRatableEmployees.
        /// </summary>
        public int ExcessOverStatutoryBondRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredIsSelected.
        /// </summary>
        public bool IncludeExpensesIncurredIsSelected { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredLimit.
        /// </summary>
        public int IncludeExpensesIncurredLimit { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredDeductible.
        /// </summary>
        public int IncludeExpensesIncurredDeductible { get; set; }

        /// <summary>
        /// EmployeeTheftExcessforSpecifiedEmployeesInputModel
        /// </summary>
        public List<CrimeCWEmployeeTheftExcessforSpecifiedEmployeesInputViewModel> CrimeEmployeeTheftExcessforSpecifiedEmployees { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationIsSelected.
        /// </summary>
        public bool ForgeryorAlterationIsSelected { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationLimit.
        /// </summary>
        public int ForgeryorAlterationLimit { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationDeductible.
        /// </summary>
        public int ForgeryorAlterationDeductible { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationBaseRate
        /// </summary>
        public decimal ForgeryorAlterationBaseRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIsSelected
        /// </summary>
        public bool InsidethePremisesTheftofMoneySecuritiesIsSelected { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesLimit
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesLimit { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesDeductible
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesDeductible { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesBaseRate
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesBaseRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsIsSelected
        /// </summary>
        public bool InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsIsSelected { get; set; }

        /// <summary>
        /// Gets or sets 
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsLimit { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDeductible
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDeductible { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsStartDate
        /// </summary>
        public DateTime InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsStartDate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsEndDate
        /// </summary>
        public DateTime InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsEndDate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIsSelected
        /// </summary>
        public bool InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIsSelected { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyLimit
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyLimit { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyDeductible
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyDeductible { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyDeductibleBaseRate
        /// </summary>
        public decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyDeductibleBaseRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsIsSelected
        /// </summary>
        public bool InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsIsSelected { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsLimit
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsLimit { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDeductible
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDeductible { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsStartDate
        /// </summary>
        public DateTime InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsStartDate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsEndDate
        /// </summary>
        public DateTime InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsEndDate { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIsSelected
        /// </summary>
        public bool OutsidethePremisesIsSelected { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesLimit
        /// </summary>
        public int OutsidethePremisesLimit { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesDeductible
        /// </summary>
        public int OutsidethePremisesDeductible { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesBaseRate
        /// </summary>
        public decimal OutsidethePremisesBaseRate { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitIsSelected
        /// </summary>
        public bool OutsidethePremisesIncreasedLimitIsSelected { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitLimit
        /// </summary>
        public int OutsidethePremisesIncreasedLimitLimit { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitDeductible
        /// </summary>
        public int OutsidethePremisesIncreasedLimitDeductible { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitStartDate
        /// </summary>
        public DateTime OutsidethePremisesIncreasedLimitStartDate { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitEndDate
        /// </summary>
        public int OutsidethePremisesIncreasedLimitEndDate { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudIsSelected
        /// </summary>
        public bool ComputerandFundsTransferFraudIsSelected { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudLimit
        /// </summary>
        public int ComputerandFundsTransferFraudLimit { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudDeductible
        /// </summary>
        public int ComputerandFundsTransferFraudDeductible { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudBaseRate
        /// </summary>
        public decimal ComputerandFundsTransferFraudBaseRate { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputerFundsTransferFraudIsSelected
        /// </summary>
        public bool IncludeExpensesIncurredComputerFundsTransferFraudIsSelected { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputer&FundsTransferFraudDeductible.
        /// </summary>
        public int IncludeExpensesIncurredComputerFundsTransferFraudLimit { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputer&FundsTransferFraud Deductible.
        /// </summary>
        public int IncludeExpensesIncurredComputerFundsTransferFraudDeductible { get; set; }

        /// <summary>
        /// Gets or sets MoneyOrdersandCounterfeitMoneyIsSelected
        /// </summary>
        public bool MoneyOrdersandCounterfeitMoneyIsSelected { get; set; }

        /// <summary>
        /// Gets or sets MoneyOrdersandCounterfeitLimit
        /// </summary>
        public int MoneyOrdersandCounterfeitLimit { get; set; }

        /// <summary>
        /// Gets or sets MoneyOrdersandCounterfeitDeductible
        /// </summary>
        public int MoneyOrdersandCounterfeitDeductible { get; set; }

        /// <summary>
        /// Gets or sets MoneyOrdersandCounterfeitMoneyBaseRate
        /// </summary>
        public decimal MoneyOrdersandCounterfeitMoneyBaseRate { get; set; }

        /// <summary>
        /// Gets or sets DestructionoElectronicDataorComputerProgramIsSelected
        /// </summary>
        public bool DestructionoElectronicDataorComputerProgramIsSelected { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramLimit
        /// </summary>
        public int DestructionofElectronicDataorComputerProgramLimit { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramDeductible
        /// </summary>
        public int DestructionofElectronicDataorComputerProgramDeductible { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramBaseRate
        /// </summary>
        public decimal DestructionofElectronicDataorComputerProgramBaseRate { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationIsSelected
        /// </summary>
        public bool FraudulentImpersonationIsSelected { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationLimit
        /// </summary>
        public int FraudulentImpersonationLimit { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationDeductible
        /// </summary>
        public int FraudulentImpersonationDeductible { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationCoverageOption
        /// </summary>
        public String FraudulentImpersonationCoverageOption { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationVerificationOption
        /// </summary>
        public String FraudulentImpersonationVerificationOption { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationBaseRate
        /// </summary>
        public decimal FraudulentImpersonationBaseRate { get; set; }

        /// <summary>
        /// Gets or sets AggregateLimitofInsuranceIsSelected
        /// </summary>
        public bool AggregateLimitofInsuranceIsSelected { get; set; }

        /// <summary>
        /// Gets or sets 
        /// </summary>
        public int AggregateLimitofInsuranceLimit { get; set; }

        /// <summary>
        /// Gets or sets IRPMApplies
        /// </summary>
        public bool IRPMApplies { get; set; }

        /// <summary>
        /// Gets or sets IRPMFactor
        /// </summary>
        public Decimal IRPMFactor { get; set; }

        /// <summary>
        /// Gets or sets OtherModRate
        /// </summary>
        public decimal OtherModRate { get; set; }

        /// <summary>
        /// CrimeCWOptionalCoveragesInputModel
        /// </summary>
        public CrimeCWOptionalCoveragesInputViewModel CrimeOptionalCoverages { get; set; }
    }
}
