﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Crime.Input
{
    /// <summary>
    /// CrimeCWOptionalCoveragesInputViewModel
    /// </summary>
    public class CrimeCWOptionalCoveragesInputViewModel
    {
        /// <summary>
        /// Gets or sets CrimeOtherCoverages.
        /// </summary>
        public List<CrimeCWOtherCoveragesInputViewModel> CrimeOtherCoverages { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageTotalPremium.
        /// </summary>
        public int OtherCoverageTotalPremium { get; set; }

    }

    /// <summary>
    /// CrimeCWOtherCoveragesInputModel
    /// </summary>
    public class CrimeCWOtherCoveragesInputViewModel
    {
        /// <summary>
        /// Gets or sets OtherCoverageCoverageID.
        /// </summary>
        public int OtherCoverageCoverageID { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageDescription.
        /// </summary>
        public String OtherCoverageDescription { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageLimit.
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageDedcutible.
        /// </summary>
        public int OtherCoverageDedcutible { get; set; }

        /// <summary>
        /// Gets or sets ClassAEmployees.
        /// </summary>
        public Decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageRatingBasis.
        /// </summary>
        public String OtherCoverageRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageReturnMethod.
        /// </summary>
        public String OtherCoverageReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageUnmodifiedPremium.
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }
    }
}
