﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Crime.Input
{
    /// <summary>
    /// CrimeInputViewModel
    /// </summary>
    public class CrimeInputViewModel
    {
        /// <summary>
        /// gets or sets CrimeCWInputViewModel
        /// </summary>
        public CrimeCWInputViewModel CW { get; set; }

        /// <summary>
        /// gets or sets CrimeNYInputViewModel
        /// </summary>
        public CrimeNYInputViewModel NY { get; set; }
    }
}
