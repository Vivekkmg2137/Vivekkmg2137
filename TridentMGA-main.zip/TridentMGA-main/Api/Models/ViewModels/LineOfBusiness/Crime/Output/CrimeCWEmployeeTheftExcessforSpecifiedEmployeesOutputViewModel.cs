﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Crime.Output
{
    /// <summary>
    /// CrimeCWEmployeeTheftExcessforSpecifiedEmployeesOutputViewModel
    /// </summary>
    public class CrimeCWEmployeeTheftExcessforSpecifiedEmployeesOutputViewModel
    {
        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsCoverageID.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsCoverageID { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsDeductible.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsDeductible { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsExposureAdjUpperLimitEmployeeValue.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsDutyExposureAdjLowerLimitEmployeeValue.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsExposureAdjUpperLimitEmployeeFactor.
        /// </summary>
        public Decimal ExcessforSpecifiedEmployeesorPositionsExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsExposureAdjLowerLimitEmployeeFactor.
        /// </summary>
        public Decimal ExcessforSpecifiedEmployeesorPositionsExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsExposureAdjFinalRate.
        /// </summary>
        public Decimal ExcessforSpecifiedEmployeesorPositionsExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsBaseRate.
        /// </summary>
        public Decimal ExcessforSpecifiedEmployeesorPositionsBaseRate { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsDeductibleFactor.
        /// </summary>
        public Decimal ExcessforSpecifiedEmployeesorPositionsDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsPremium.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsPremium { get; set; }
    }
}
