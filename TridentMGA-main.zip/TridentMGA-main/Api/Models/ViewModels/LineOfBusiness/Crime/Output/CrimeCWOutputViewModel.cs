﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Crime.Output
{
    /// <summary>
    /// CrimeCWOutputViewModel
    /// </summary>
    public class CrimeCWOutputViewModel
    {
        /// <summary>
        /// Gets or sets EmployeeTheftPerLossRatableEmployees
        /// </summary>
        public int EmployeeTheftPerLossRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int EmployeeTheftPerLossExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int EmployeeTheftPerLossExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal EmployeeTheftPerLossExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal EmployeeTheftPerLossExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossExposureAdjFinalRate
        /// </summary>
        public Decimal EmployeeTheftPerLossExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossBaseRate
        /// </summary>
        public Decimal EmployeeTheftPerLossBaseRate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossDeductibleFactor
        /// </summary>
        public Decimal EmployeeTheftPerLossDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerLossPremium
        /// </summary>
        public int EmployeeTheftPerLossPremium { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeRatableEmployees
        /// </summary>
        public int EmployeeTheftPerEmployeeRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int EmployeeTheftPerEmployeeExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int EmployeeTheftPerEmployeeExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal EmployeeTheftPerEmployeeExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal EmployeeTheftPerEmployeeExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeExposureAdjFinalRate 
        /// </summary>
        public Decimal EmployeeTheftPerEmployeeExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeeBaseRate
        /// </summary>
        public Decimal EmployeeTheftPerEmployeeBaseRate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeePremium
        /// </summary>
        public Decimal EmployeeTheftPerEmployeeDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets EmployeeTheftPerEmployeePremium
        /// </summary>
        public int EmployeeTheftPerEmployeePremium { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyLimit
        /// </summary>
        public int FaithfulPerformanceofDutyLimit { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyDeductible
        /// </summary>
        public int FaithfulPerformanceofDutyDeductible { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyRatableEmployees
        /// </summary>
        public int FaithfulPerformanceofDutyRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int FaithfulPerformanceofDutyExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int FaithfulPerformanceofDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal FaithfulPerformanceofDutyExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyExposureAdjLowerLimitEmployeeFactor 
        /// </summary>
        public Decimal FaithfulPerformanceofDutyExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyExposureAdjFinalRate
        /// </summary>
        public Decimal FaithfulPerformanceofDutyExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyBaseRate
        /// </summary>
        public Decimal FaithfulPerformanceofDutyBaseRate { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyDeductibleFactor
        /// </summary>
        public Decimal FaithfulPerformanceofDutyDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets FaithfulPerformanceofDutyPremium
        /// </summary>
        public int FaithfulPerformanceofDutyPremium { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondLimit
        /// </summary>
        public int ExcessOverStatutoryBondLimit { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondDeductible
        /// </summary>
        public int ExcessOverStatutoryBondDeductible { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int ExcessOverStatutoryBondExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondDutyExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int ExcessOverStatutoryBondDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal ExcessOverStatutoryBondExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal ExcessOverStatutoryBondExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondExposureAdjFinalRate
        /// </summary>
        public Decimal ExcessOverStatutoryBondExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondBaseRate
        /// </summary>
        public Decimal ExcessOverStatutoryBondBaseRate { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondDeductibleFactor
        /// </summary>
        public Decimal ExcessOverStatutoryBondDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets ExcessOverStatutoryBondPremium
        /// </summary>
        public int ExcessOverStatutoryBondPremium { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredDeductible
        /// </summary>
        public int IncludeExpensesIncurredDeductible { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredRatableEmployees
        /// </summary>
        public int IncludeExpensesIncurredRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int IncludeExpensesIncurredExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets 
        /// </summary>
        public int IncludeExpensesIncurredDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal IncludeExpensesIncurredExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal IncludeExpensesIncurredExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredExposureAdjFinalRate
        /// </summary>
        public Decimal IncludeExpensesIncurredExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredBaseRate
        /// </summary>
        public Decimal IncludeExpensesIncurredBaseRate { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredDeductibleFactor
        /// </summary>
        public Decimal IncludeExpensesIncurredDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredPremium
        /// </summary>
        public int IncludeExpensesIncurredPremium { get; set; }

        /// <summary>
        /// Gets or sets CrimeCWEmployeeTheftExcessforSpecifiedEmployeesOutputViewModel
        /// </summary>
        public List<CrimeCWEmployeeTheftExcessforSpecifiedEmployeesOutputViewModel> CrimeCWEmployeeTheftExcessforSpecifiedEmployeesOutputViewModel { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsTotalPremium
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationRatableEmployees
        /// </summary>
        public int ForgeryorAlterationRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int ForgeryorAlterationExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationDutyExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int ForgeryorAlterationDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal ForgeryorAlterationExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal ForgeryorAlterationExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationExposureAdjFinalRate
        /// </summary>
        public Decimal ForgeryorAlterationExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationBaseRate
        /// </summary>
        public Decimal ForgeryorAlterationBaseRate { get; set; }

        /// <summary>
        /// Gets or sets ForgeryorAlterationDeductibleFactor
        /// </summary>
        public Decimal ForgeryorAlterationDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets 
        /// </summary>
        public int ForgeryorAlterationPremium { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesRatableEmployees
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesDutyExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesExposureAdjFinalRate
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesBaseRate
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesBaseRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesDeductibleFactor
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesPremium
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesPremium { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsRatableEmployees
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDeductible
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDeductible { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDutyExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsExposureAdjLowerLimitEmployeeFactor 
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsExposureAdjFinalRate
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsBaseRate
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsBaseRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDeductibleFactor
        /// </summary>
        public Decimal InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDays
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsDays { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsPremium
        /// </summary>
        public int InsidethePremisesTheftofMoneySecuritiesIncreaseLimitsPremium { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyRatableEmployees
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyDutyExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyExposureAdjFinalRate 
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyBaseRate
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyBaseRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyDeductibleFactor
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyPremium
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyPremium { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreaseLimitsRatableEmployees
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreaseLimitsRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDeductible
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDeductible { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDutyExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsExposureAdjFinalRate
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsBaseRate
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsBaseRate { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDeductibleFactor
        /// </summary>
        public Decimal InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDays
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsDays { get; set; }

        /// <summary>
        /// Gets or sets InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsPremium
        /// </summary>
        public int InsidethePremisesRobberyorSafeBurglaryofOtherPropertyIncreasedLimitsPremium { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesRatableEmployees
        /// </summary>
        public int OutsidethePremisesRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int OutsidethePremisesExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesDutyExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int OutsidethePremisesDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal OutsidethePremisesExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal OutsidethePremisesExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesExposureAdjFinalRate
        /// </summary>
        public Decimal OutsidethePremisesExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesBaseRate
        /// </summary>
        public Decimal OutsidethePremisesBaseRate { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesDeductibleFactor
        /// </summary>
        public Decimal OutsidethePremisesDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesPremium
        /// </summary>
        public int OutsidethePremisesPremium { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitRatableEmployees
        /// </summary>
        public int OutsidethePremisesIncreasedLimitRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitDeductible
        /// </summary>
        public int OutsidethePremisesIncreasedLimitDeductible { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int OutsidethePremisesIncreasedLimitExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitDutyExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int OutsidethePremisesIncreasedLimitDutyExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal OutsidethePremisesIncreasedLimitExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal OutsidethePremisesIncreasedLimitExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitExposureAdjFinalRate
        /// </summary>
        public Decimal OutsidethePremisesIncreasedLimitExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitBaseRate
        /// </summary>
        public Decimal OutsidethePremisesIncreasedLimitBaseRate { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitDeductibleFactor
        /// </summary>
        public Decimal OutsidethePremisesIncreasedLimitDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitDays
        /// </summary>
        public int OutsidethePremisesIncreasedLimitDays { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitPremium
        /// </summary>
        public int OutsidethePremisesIncreasedLimitPremium { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudRatableEmployees
        /// </summary>
        public int ComputerandFundsTransferFraudRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudDeductible
        /// </summary>
        public int ComputerandFundsTransferFraudDeductible { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int ComputerandFundsTransferFraudExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int ComputerandFundsTransferFraudExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets OutsidethePremisesIncreasedLimitExposureAdjUpperLimitEmployeeFactor 
        /// </summary>
        public Decimal OutsidethePremisesIncreasedLimitExposureAdjUpperLimitEmployeeFactor1 { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal ComputerandFundsTransferFraudExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudExposureAdjFinalRate
        /// </summary>
        public Decimal ComputerandFundsTransferFraudExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudBaseRate
        /// </summary>
        public Decimal ComputerandFundsTransferFraudBaseRate { get; set; }

        /// <summary>
        /// Gets or sets ComputerandFundsTransferFraudDeductibleFactor  
        /// </summary>
        public Decimal ComputerandFundsTransferFraudDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets  
        /// </summary>
        public int ComputerandFundsTransferFraudPremium { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputerFundTransferFraudRatableEmployees  
        /// </summary>
        public int IncludeExpensesIncurredComputerFundTransferFraudRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputerFundTransferFraudExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int IncludeExpensesIncurredComputerFundTransferFraudExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputerFundTransferFraudExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int IncludeExpensesIncurredComputerFundTransferFraudExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets  
        /// </summary>
        public int IncludeExpensesIncurredComputerFundTransferFraudExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputerFundTransferFraudExposureAdjLowerLimitEmployeeFactor 
        /// </summary>
        public Decimal IncludeExpensesIncurredComputerFundTransferFraudExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputerFundTransferFraudExposureAdjFinalRate
        /// </summary>
        public Decimal IncludeExpensesIncurredComputerFundTransferFraudExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputerFundTransferFraudBaseRate  
        /// </summary>
        public Decimal IncludeExpensesIncurredComputerFundTransferFraudBaseRate { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputerFundTransferFraudDeductibleFactor 
        /// </summary>
        public Decimal IncludeExpensesIncurredComputerFundTransferFraudDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets IncludeExpensesIncurredComputerFundTransferFraudPremium 
        /// </summary>
        public int IncludeExpensesIncurredComputerFundTransferFraudPremium { get; set; }

        /// <summary>
        /// Gets or sets MoneyOrdersandCounterfeitMoneyBaseRate
        /// </summary>
        public Decimal MoneyOrdersandCounterfeitMoneyBaseRate { get; set; }

        /// <summary>
        /// Gets or sets MoneyOrdersandCounterfeitMoneyDeductibleFactor
        /// </summary>
        public Decimal MoneyOrdersandCounterfeitMoneyDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets MoneyOrdersandCounterfeitMoneyPremium
        /// </summary>
        public int MoneyOrdersandCounterfeitMoneyPremium { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramRatableEmployees
        /// </summary>
        public int DestructionofElectronicDataorComputerProgramRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int DestructionofElectronicDataorComputerProgramExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int DestructionofElectronicDataorComputerProgramExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal DestructionofElectronicDataorComputerProgramExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal DestructionofElectronicDataorComputerProgramExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramExposureAdjFinalRate 
        /// </summary>
        public Decimal DestructionofElectronicDataorComputerProgramExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramBaseRate
        /// </summary>
        public Decimal DestructionofElectronicDataorComputerProgramBaseRate { get; set; }

        /// <summary>
        /// Gets or sets  
        /// </summary>
        public Decimal DestructionofElectronicDataorComputerProgramDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets DestructionofElectronicDataorComputerProgramPremium
        /// </summary>
        public int DestructionofElectronicDataorComputerProgramPremium { get; set; }

        /// <summary>
        /// Gets or sets  
        /// </summary>
        public int FraudulentImpersonationRatableEmployees { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationExposureAdjUpperLimitEmployeeValue
        /// </summary>
        public int FraudulentImpersonationExposureAdjUpperLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationExposureAdjLowerLimitEmployeeValue
        /// </summary>
        public int FraudulentImpersonationExposureAdjLowerLimitEmployeeValue { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationExposureAdjUpperLimitEmployeeFactor
        /// </summary>
        public Decimal FraudulentImpersonationExposureAdjUpperLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationExposureAdjLowerLimitEmployeeFactor
        /// </summary>
        public Decimal FraudulentImpersonationExposureAdjLowerLimitEmployeeFactor { get; set; }

        /// <summary>
        /// Gets or sets  
        /// </summary>
        public Decimal FraudulentImpersonationExposureAdjFinalRate { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationBaseRate
        /// </summary>
        public Decimal FraudulentImpersonationBaseRate { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationDeductibleFactor
        /// </summary>
        public Decimal FraudulentImpersonationDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationCoverageOptionBaseRate 
        /// </summary>
        public Decimal FraudulentImpersonationCoverageOptionBaseRate { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationVerificationOptionBaseRate
        /// </summary>
        public Decimal FraudulentImpersonationVerificationOptionBaseRate { get; set; }

        /// <summary>
        /// Gets or sets FraudulentImpersonationPremium  
        /// </summary>
        public int FraudulentImpersonationPremium { get; set; }

        /// <summary>
        /// Gets or sets AggregateLimitofInsuranceBaseRate 
        /// </summary>
        public int AggregateLimitofInsuranceBaseRate { get; set; }

        /// <summary>
        /// Gets or sets BasePremium
        /// </summary>
        public int BasePremium { get; set; }

        /// <summary>
        /// Gets or sets NonModifiedPremium
        /// </summary>
        public int NonModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets ManualPremium
        /// </summary>
        public int ManualPremium { get; set; }

        /// <summary>
        /// Gets or sets IRPMFactor
        /// </summary>
        public Decimal IRPMFactor { get; set; }

        /// <summary>
        /// Gets or sets IRPMPremium 
        /// </summary>
        public int IRPMPremium { get; set; }

        /// <summary>
        /// Gets or sets TerrorismRate
        /// </summary>
        public Decimal TerrorismRate { get; set; }

        /// <summary>
        /// Gets or sets TerrorismPremium 
        /// </summary>
        public int TerrorismPremium { get; set; }

        /// <summary>
        /// Gets or sets  
        /// </summary>
        public Decimal OtherModRate { get; set; }

        /// <summary>
        /// Gets or sets  
        /// </summary>
        public int OtherModPremium { get; set; }

        /// <summary>
        /// Gets or sets TierRate 
        /// </summary>
        public Decimal TierRate { get; set; }

        /// <summary>
        /// Gets or sets TierPremium
        /// </summary>
        public int TierPremium { get; set; }

        /// <summary>
        /// Gets or sets CRModifiedFinalPremium
        /// </summary>
        public int CRModifiedFinalPremium { get; set; }
    }
}
