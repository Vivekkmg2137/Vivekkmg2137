﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Crime.Output
{
    public class CrimeNYOptionalCoveragesOutputViewModel
    {
        /// <summary>
        /// Gets or sets CrimeNYOtherCoverages.
        /// </summary>
        public List<CrimeNYOtherCoveragesOutputViewModel> CrimeNYOtherCoverages { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageTotalPremium.
        /// </summary>
        public int OtherCoverageTotalPremium { get; set; }
    }

    public class CrimeNYOtherCoveragesOutputViewModel
    {
        /// <summary>
        /// Gets or sets OtherCoverageID.
        /// </summary>
        public int OtherCoverageID { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageDescription.
        /// </summary>
        public string OtherCoverageDescription { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageLimit.
        /// </summary>
        public int OtherCoverageLimit { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageDedcutible.
        /// </summary>
        public int OtherCoverageDedcutible { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageRate.
        /// </summary>
        public decimal OtherCoverageRate { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageRatingBasis.
        /// </summary>
        public string OtherCoverageRatingBasis { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageReturnMethod.
        /// </summary>
        public string OtherCoverageReturnMethod { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageUnmodifiedPremium.
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }
    }
}
