﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Crime.Output
{
    public class CrimeNYOutputViewModel
    {
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyRatableLimitExposure.
        /// </summary>
        public int PublicEmployeeDishonestyRatableLimitExposure { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyDeductibleFactor.
        /// </summary>
        public decimal PublicEmployeeDishonestyDeductibleFactor { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyBaseRate.
        /// </summary>
        public decimal PublicEmployeeDishonestyBaseRate { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyPremium.
        /// </summary>
        public int PublicEmployeeDishonestyPremium { get; set; }
        /// <summary>
        /// Gets or sets FaithfulPerformanceOfDutyRatableLimitExposure.
        /// </summary>
        public int FaithfulPerformanceOfDutyRatableLimitExposure { get; set; }
        /// <summary>
        /// Gets or sets FaithfulPerformanceOfDutyDeductibleFactor.
        /// </summary>
        public decimal FaithfulPerformanceOfDutyDeductibleFactor { get; set; }
        /// <summary>
        /// Gets or sets FaithfulPerformanceOfDutyBaseRate.
        /// </summary>
        public decimal FaithfulPerformanceOfDutyBaseRate { get; set; }
        /// <summary>
        /// Gets or sets FaithfulPerformanceOfDutyPremium.
        /// </summary>
        public int FaithfulPerformanceOfDutyPremium { get; set; }
        /// <summary>
        /// Gets or sets CrimeNYPublicEmployeeDishonestyIncreasedLimits.
        /// </summary>
        public List<CrimeNYPublicEmployeeDishonestyIncreasedLimitsOutputViewModel> CrimeNYPublicEmployeeDishonestyIncreasedLimits { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyIncreasedLimitTotalPremium.
        /// </summary>
        public int PublicEmployeeDishonestyIncreasedLimitTotalPremium { get; set; }
        /// <summary>
        /// Gets or sets ForgeryAndAlterationRatableLimitExposure.
        /// </summary>
        public int ForgeryAndAlterationRatableLimitExposure { get; set; }
        /// <summary>
        /// Gets or sets ForgeryAndAlterationDeductibleFactor.
        /// </summary>
        public decimal ForgeryAndAlterationDeductibleFactor { get; set; }
        /// <summary>
        /// Gets or sets ForgeryAndAlterationBaseRate.
        /// </summary>
        public decimal ForgeryAndAlterationBaseRate { get; set; }
        /// <summary>
        /// Gets or sets ForgeryAndAlterationPremium.
        /// </summary>
        public int ForgeryAndAlterationPremium { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesRatableExposure.
        /// </summary>
        public int TheftDisappearanceAndDestructionInsideThePremisesRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesDeductibleFactor.
        /// </summary>
        public decimal TheftDisappearanceAndDestructionInsideThePremisesDeductibleFactor { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesBaseRate.
        /// </summary>
        public decimal TheftDisappearanceAndDestructionInsideThePremisesBaseRate { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesPremium.
        /// </summary>
        public int TheftDisappearanceAndDestructionInsideThePremisesPremium { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesRatableExposure.
        /// </summary>
        public int TheftDisappearanceAndDestructionOutsideThePremisesRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesDeductibleFactor.
        /// </summary>
        public decimal TheftDisappearanceAndDestructionOutsideThePremisesDeductibleFactor { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesBaseRate.
        /// </summary>
        public decimal TheftDisappearanceAndDestructionOutsideThePremisesBaseRate { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesPremium.
        /// </summary>
        public int TheftDisappearanceAndDestructionOutsideThePremisesPremium { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitDAYS.
        /// </summary>
        public int TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitDAYS { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitRatableExposure.
        /// </summary>
        public int TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitPremium.
        /// </summary>
        public int TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitPremium { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesDAYS.
        /// </summary>
        public int TheftDisappearanceAndDestructionOutsideThePremisesDAYS { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesIncreasedLimitRatableExposure.
        /// </summary>
        public int TheftDisappearanceAndDestructionOutsideThePremisesIncreasedLimitRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesIncreasedPremium.
        /// </summary>
        //check this line number 35
        public int TheftDisappearanceAndDestructionOutsideThePremisesIncreasedPremium { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesRatableExposure.
        /// </summary>
        public int RobberyAndSafeBurglaryInsideThePremisesRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesDeductibleFactor.
        /// </summary>
        public decimal RobberyAndSafeBurglaryInsideThePremisesDeductibleFactor { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesBaseRate.
        /// </summary>
        public decimal RobberyAndSafeBurglaryInsideThePremisesBaseRate { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesPremium.
        /// </summary>
        public int RobberyAndSafeBurglaryInsideThePremisesPremium { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesRatableExposure.
        /// </summary>
        public int RobberyAndSafeBurglaryOutsideThePremisesRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesDeductibleFactor.
        /// </summary>
        public decimal RobberyAndSafeBurglaryOutsideThePremisesDeductibleFactor { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesBaseRate.
        /// </summary>
        public decimal RobberyAndSafeBurglaryOutsideThePremisesBaseRate { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesPremium.
        /// </summary>
        public int RobberyAndSafeBurglaryOutsideThePremisesPremium { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryRatableExposure.
        /// </summary>
        public int RobberyAndSafeBurglarySafeBurglaryRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryDeductibleFactor.
        /// </summary>
        public decimal RobberyAndSafeBurglarySafeBurglaryDeductibleFactor { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryBaseRate.
        /// </summary>
        public decimal RobberyAndSafeBurglarySafeBurglaryBaseRate { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryPremium.
        /// </summary>
        public int RobberyAndSafeBurglarySafeBurglaryPremium { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitDAYS.
        /// </summary>
        public int RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitDAYS { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitRatableExposure.
        /// </summary>
        public int RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitPremium.
        /// </summary>
        public int RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitPremium { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitDAYS.
        /// </summary>
        public int RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitDAYS { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitRatableExposure.
        /// </summary>
        public int RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitPremium.
        /// </summary>
        public int RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitPremium { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryIncreasedLimitDAYS.
        /// </summary>
        public int RobberyAndSafeBurglarySafeBurglaryIncreasedLimitDAYS { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglarysIncreasedLimitRatableExposure.
        /// </summary>
        public int RobberyAndSafeBurglarySafeBurglarysIncreasedLimitRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryIncreasedLimitPremium.
        /// </summary>
        public int RobberyAndSafeBurglarySafeBurglaryIncreasedLimitPremium { get; set; }
        /// <summary>
        /// Gets or sets ComputerFraudRatableExposure.
        /// </summary>
        public int ComputerFraudRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets ComputerFraudDeductibleFactor.
        /// </summary>
        public decimal ComputerFraudDeductibleFactor { get; set; }
        /// <summary>
        /// Gets or sets ComputerFraudBaseRate.
        /// </summary>
        public decimal ComputerFraudBaseRate { get; set; }
        /// <summary>
        /// Gets or sets ComputerFraudPremium.
        /// </summary>
        public int ComputerFraudPremium { get; set; }
        /// <summary>
        /// Gets or sets CrimeNYOptionalCoverages.
        /// </summary>
        public List<CrimeNYOptionalCoveragesOutputViewModel> CrimeNYOptionalCoverages { get; set; }
        /// <summary>
        /// Gets or sets BasePremium.
        /// </summary>
        public int BasePremium { get; set; }
        /// <summary>
        /// Gets or sets NonModifiedPremium.
        /// </summary>
        public int NonModifiedPremium { get; set; }
        /// <summary>
        /// Gets or sets ManualPremium.
        /// </summary>
        public int ManualPremium { get; set; }
        /// <summary>
        /// Gets or sets IRPMFactor.
        /// </summary>
        public decimal IRPMFactor { get; set; }
        /// <summary>
        /// Gets or sets IRPMPremium.
        /// </summary>
        public int IRPMPremium { get; set; }
        /// <summary>
        /// Gets or sets TerrorismRate.
        /// </summary>
        public decimal TerrorismRate { get; set; }
        /// <summary>
        /// Gets or sets TerrorismPremium.
        /// </summary>
        public int TerrorismPremium { get; set; }
        /// <summary>
        /// Gets or sets OtherModRate.
        /// </summary>
        public decimal OtherModRate { get; set; }
        /// <summary>
        /// Gets or sets OtherModPremium.
        /// </summary>
        public int OtherModPremium { get; set; }
        /// <summary>
        /// Gets or sets TierRate.
        /// </summary>
        public decimal TierRate { get; set; }
        /// <summary>
        /// Gets or sets TierPremium.
        /// </summary>
        public int TierPremium { get; set; }
        /// <summary>
        /// Gets or sets CRModifiedFinalPremium.
        /// </summary>
        public int CRModifiedFinalPremium { get; set; }
    }
}
