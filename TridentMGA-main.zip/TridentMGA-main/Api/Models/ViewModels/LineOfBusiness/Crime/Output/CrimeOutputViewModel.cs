﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Crime.Output
{
    /// <summary>
    /// CrimeOutputViewModel
    /// </summary>
    public class CrimeOutputViewModel
    {
        /// <summary>
        /// gets or sets CrimeCWOutputViewModel
        /// </summary>
        public CrimeCWOutputViewModel CW { get; set; }

        /// <summary>
        /// gets or sets CrimeNYOutputViewModel
        /// </summary>
        public CrimeNYOutputViewModel NY { get; set; }
    }
}
