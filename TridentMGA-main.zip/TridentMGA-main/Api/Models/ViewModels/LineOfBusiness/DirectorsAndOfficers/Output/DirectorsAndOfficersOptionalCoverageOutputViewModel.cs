﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.DirectorsAndOfficers.Output
{
    public class DirectorsAndOfficersOptionalCoverageOutputViewModel
    {
        #region Suppl. Extended Reporting Period

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodIsSelected
        /// </summary>
        public bool SupplExtendedReportingPeriodIsSelected { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodLimit
        /// </summary>
        public int SupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodAggregateLimit
        /// </summary>
        public int SupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodDeductible
        /// </summary>
        public int SupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodRatingBasis
        /// </summary>
        public string SupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodReturnMethod
        /// </summary>
        public string SupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodRate
        /// </summary>
        public decimal SupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodUnmodifiedPremium
        /// </summary>
        public int SupplExtendedReportingPeriodUnmodifiedPremium { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodModifiedPremium
        /// </summary>
        public int SupplExtendedReportingPeriodModifiedPremium { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodIncludedInExcessExposure
        /// </summary>
        public string SupplExtendedReportingPeriodIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Get or set SupplExtendedReportingPeriodUnmodifiedwithoutExcessPremium
        /// </summary>
        public int SupplExtendedReportingPeriodUnmodifiedwithoutExcessPremium { get; set; }

        #endregion

        public List<DirectorsAndOfficersOptionalOtherCoverageOutputViewModel> DirectorsAndOfficersOptionalOtherCoverageModel { get; set; }

        /// <summary>
        /// Get or Set OtherCoverages Total Premium
        /// </summary>
        public int OtherCoveragesTotalPremium { get; set; }
    }

    public class DirectorsAndOfficersOptionalOtherCoverageOutputViewModel
    {
        #region Other Coverage 

        /// <summary>
        /// Get or Set OtherCoverageID
        /// </summary>
        public int OtherCoverageID { get; set; }

        /// <summary>
        /// Get or Set OtherCoverageDescription
        /// </summary>
        public string OtherCoverageDescription { get; set; }

        /// <summary>
        /// Get or Set OtherCoverageLimit
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// Get or Set OtherCoverageAggregateLimit
        /// </summary>
        public int OtherCoverageAggregateLimit { get; set; }

        /// <summary>
        /// Get or Set OtherCoverageDedcutible
        /// </summary>
        public int OtherCoverageDedcutible { get; set; }

        /// <summary>
        /// Get or Set OtherCoverageRate
        /// </summary>
        public decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// Get or Set OtherCoverageRatingBasis
        /// </summary>
        public string OtherCoverageRatingBasis { get; set; }

        /// <summary>
        /// Get or Set OtherCoverageReturnMethod
        /// </summary>
        public string OtherCoverageReturnMethod { get; set; }

        /// <summary>
        /// Get or set OtherCoverageUnModifiedWithoutExcessPremium
        /// </summary>
        public int OtherCoverageUnModifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Get or set OtherCoverageUnmodifiedPremium
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }

        /// <summary>
        /// Get or set OtherCoverageIncludedInExcessExposure
        /// </summary>
        public string OtherCoverageIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Get or set OtherCoverageModifiedPremium
        /// </summary>
        public int OtherCoverageModifiedPremium { get; set; }

        #endregion

    }
}
