﻿using Models.ViewModels.LineOfBusiness.EducatorsLegal.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.EducatorsLegal.Input
{
    public class EducatorsLegalInputViewModel
    {
        public EducatorsLegalCwInputViewModel CW { get; set; }

        public EducatorsLegalNyInputViewModel NY { get; set; }
    }     
}
