﻿using Models.ViewModels.LineOfBusiness.EducatorsLegal.Output;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.EducatorsLegal.Output
{
    public class EducatorsLegalOutputViewModel
    {
        public EducatorsLegalCwOutputViewModel CW { get; set; }

        public EducatorsLegalNyOutputViewModel NY { get; set; }
    }     
}
