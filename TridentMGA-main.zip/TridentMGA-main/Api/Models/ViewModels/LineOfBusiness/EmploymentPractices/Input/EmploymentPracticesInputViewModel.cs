﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ViewModels.LineOfBusiness.EmploymentPractices.Input
{
    public class EmploymentPracticesInputViewModel
    {

        /// <summary>
        /// Gets or sets LineOfBusiness.
        /// </summary>
        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "EP";

        /// <summary>
        /// Gets or sets Exposure.
        /// </summary>
        public int Exposure { get; set; }

        /// <summary>
        /// Gets or sets Exposure Rate.
        /// </summary>
        public decimal ExposureRate { get; set; }

        /// <summary>
        /// Gets or sets Liability Limit.
        /// </summary>
        public int LiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets Aggregate Limit.
        /// </summary>
        public int AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Liability Limit Rate.
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Gets or sets Deductible/SIR.
        /// </summary>
        public string DeductibleSIR { get; set; }

        /// <summary>
        /// Gets or sets Retention.
        /// </summary>
        public int Retention { get; set; }

        /// <summary>
        /// Gets or sets Aggregate Retention.
        /// </summary>
        public int AggregateRetention { get; set; }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        public String Type { get; set; }

        /// <summary>
        /// Gets or sets Expense.
        /// </summary>
        public String Expense { get; set; }

        /// <summary>
        /// Gets or sets LossExperienceIsSelected.
        /// </summary>
        public bool LossExperienceIsSelected { get; set; }

        /// <summary>
        /// Gets or sets PolicyType.
        /// </summary>
        public String PolicyType { get; set; }

        /// <summary>
        /// Gets or sets RetroActiveDate.
        /// </summary>
        public DateTime RetroActiveDate { get; set; }

        /// <summary>
        /// Gets or sets YearsinCMProgram.
        /// </summary>
        public int YearsinCMProgram { get; set; }

        /// <summary>
        /// Gets or sets IRPMFactor.
        /// </summary>
        public Decimal IRPMFactor { get; set; }

        /// <summary>
        /// Gets or sets Other Mod Factor.
        /// </summary>
        public Decimal OtherModFactor { get; set; }

        /// <summary>
        /// Gets or sets IRPMApplies.
        /// </summary>
        public bool IRPMApplies { get; set; }

        //GRID START - OPTIONAL COVERAGES
        #region Optional Coverage
        public EmploymentPracticesOptionalCoverageInputViewModel EmploymentPracticesOptionalCoverageModel { get; set; }
        #endregion

    }
}
