﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.EmploymentPractices.Input
{
    public class EmploymentPracticesOtherCoverageInputViewModel
    {

        /// <summary>
        /// Gets or sets Other Coverage IsSelected
        /// </summary>
        public int OtherCoverageID { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Description
        /// </summary>
        public string OtherCoverageDescription { get; set; }
        /// <summary>
        /// Gets or sets Other Coverage Id
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Aggregate Limit
        /// </summary>
        public int OtherCoverageAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Deductible
        /// </summary>
        public int OtherCoverageDeductible { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Rate
        /// </summary>
        public decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Rating Basis
        /// </summary>
        public String OtherCoverageRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Return Method
        /// </summary>
        public String OtherCoverageReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Unmodifed Premium
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Unmodifed Premium
        /// </summary>
        ///  
        public int OtherCoverageModifiedPremium { get; set; }

        /// <summary>
        /// Gets sets OtherCoverageIncludedInExcessExposure
        /// </summary>
        public string OtherCoverageIncludedInExcessExposure { get; set; }
    }
}
