﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Api.Models.ViewModels.LineOfBusiness.EmploymentPractices.Output
{
    public class EmploymentPracticesOptionalCoverageOutputViewModel
    {
        #region BackWages
        /// <summary>
        /// Gets or sets Back Wages Is Selected.
        /// </summary>
        public bool BackWagesIsSelected { get; set; }

        /// <summary>
        /// Gets or sets Back Wages Limit.
        /// </summary>
        public int BackWagesLimit { get; set; }

        /// <summary>
        /// Gets or sets Back Wages Aggregate Limit.
        /// </summary>
        public int BackWagesAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets BackWagesDeductible
        /// </summary>
        public int BackWagesDeductible { get; set; }

        /// <summary>
        /// Gets or sets BackWagesRatingBasis
        /// </summary>
        public String BackWagesRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets BackWagesReturnMethod
        /// </summary>
        public String BackWagesReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets BackWagesRate
        /// </summary>
        public Decimal BackWagesRate { get; set; }

        /// <summary>
        /// Gets or sets BackWagesUnmodifiedPremium
        /// </summary>
        public int BackWagesUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets BackWagesModifiedPremium
        /// </summary>
        public int BackWagesModifiedPremium { get; set; }

        /// <summary>
        /// Gets sets BackWagesIncludedInExcessExposure
        /// </summary>
        public string BackWagesIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets sets BackWagesUnModifiedWithoutExcessPremium
        /// </summary>
        public int BackWagesUnModifiedWithoutExcessPremium { get; set; }
        #endregion

        #region NonMonetaryDefense
        /// <summary>
        /// Gets or sets NonMonetaryDefenseIsSelected
        /// </summary>
        public bool NonMonetaryDefenseIsSelected { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseLimit
        /// </summary>
        public int NonMonetaryDefenseLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseAggregateLimit
        /// </summary>
        public int NonMonetaryDefenseAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseDeductible
        /// </summary>
        public int NonMonetaryDefenseDeductible { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRatingBasis
        /// </summary>
        public String NonMonetaryDefenseRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseReturnMethod
        /// </summary>
        public String NonMonetaryDefenseReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRate
        /// </summary>
        public Decimal NonMonetaryDefenseRate { get; set; }


        /// <summary>
        /// Gets or sets Non-Monetary Defense Unmodifed Premium
        /// </summary>
        public int NonMonetaryDefenseUnmodifiedPremium { get; set; }


        /// <summary>
        /// Gets or sets Non-Monetary Defense Modifed Premium
        /// </summary>
        public int NonMonetaryDefenseModifiedPremium { get; set; }

        /// <summary>
        /// Gets sets NonMonetaryDefenseIncludedInExcessExposure
        /// </summary>
        public string NonMonetaryDefenseIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets sets NonMonetaryDefenseUnModifiedWithoutExcessPremium
        /// </summary>
        public int NonMonetaryDefenseUnModifiedWithoutExcessPremium { get; set; }

        #endregion

        #region EEOC
        /// <summary>
        /// Gets or sets EEOC IsSelected
        /// </summary>
        public bool EEOCIsSelected { get; set; }

        /// <summary>
        /// Gets or sets EEOC Limit
        /// </summary>
        public int EEOCLimit { get; set; }

        /// <summary>
        /// Gets or sets EEOC Aggregate Limit
        /// </summary>
        public int EEOCAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets EEOC Deductible
        /// </summary>
        public int EEOCDeductible { get; set; }

        /// <summary>
        /// Gets or sets EEOC Rating Basis
        /// </summary>
        public String EEOCRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets EEOC Return Method
        /// </summary>
        public string EEOCReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets EEOC Rate
        /// </summary>
        public decimal EEOCRate { get; set; }

        /// <summary>
        /// Gets or sets EEOC Unmodifed Premium
        /// </summary>
        public int EEOCUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets EEOC Unmodifed Premium
        /// </summary>
        public int EEOCModifiedPremium { get; set; }

        /// <summary>
        /// Gets sets EEOCIncludedInExcessExposure
        /// </summary>
        public string EEOCIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets sets EEOCUnModifiedWithoutExcessPremium
        /// </summary>
        public int EEOCUnModifiedWithoutExcessPremium { get; set; }

        #endregion

        #region LossAdjustmentExpenseWrongfulAct
        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActIsSelected
        /// </summary>
        public bool LossAdjustmentExpenseWrongfulActIsSelected { get; set; }


        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActLimit
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActLimit { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActAggregate Limit
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActDeductible
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActDeductible { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActRating Basis
        /// </summary>
        public String LossAdjustmentExpenseWrongfulActRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActRate
        /// </summary>
        public decimal LossAdjustmentExpenseWrongfulActRate { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful Act Return Method
        /// </summary>
        public String LossAdjustmentExpenseWrongfulActReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActUnmodifed Premium
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActUnmodifed Premium
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActModifiedPremium { get; set; }

        /// <summary>
        /// Gets sets LossAdjustmentExpenseWrongfulActIncludedInExcessExposure
        /// </summary>
        public string LossAdjustmentExpenseWrongfulActIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets sets LossAdjustmentExpenseWrongfulActDefenseUnModifiedWithoutExcessPremium
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActUnModifiedWithoutExcessPremium { get; set; }

        #endregion

        #region SupplExtendedReportingPeriod
        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period IsSelected
        /// </summary>
        public bool SupplExtendedReportingPeriodIsSelected { get; set; }


        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Limit
        /// </summary>
        public int SupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Aggregate Limit
        /// </summary>
        public int SupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Deductible
        /// </summary>
        public int SupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rating Basis
        /// </summary>
        public String SupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Return Method
        /// </summary>
        public String SupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rate
        /// </summary>
        public decimal SupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodifed Premium
        /// </summary>
        public int SupplExtendedReportingPeriodUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodifed Premium
        /// </summary>
        public int SupplExtendedReportingPeriodModifiedPremium { get; set; }

        /// <summary>
        /// Gets sets SupplExtendedReportingPeriodIncludedInExcessExposure
        /// </summary>
        public string SupplExtendedReportingPeriodIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets sets SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium
        /// </summary>
        public int SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium { get; set; }
        #endregion 
        
        //"GRID START -OTHER COVERAGES"
        #region Optional Coverage
        public List<EmploymentPracticesOtherCoverageOutputViewModel> EmploymentPracticesOtherCoverageModel { get; set; }
        #endregion
    }
}
