﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Api.Models.ViewModels.LineOfBusiness.EmploymentPractices.Output
{
    public class EmploymentPracticesOutputViewModel
    {
        /// <summary>
        /// Gets or sets Exposure.
        /// </summary>
        public int RetroYear { get; set; }

        /// <summary>
        /// Gets or sets Exposure.
        /// </summary>
        public decimal ExposureRate { get; set; }

        /// <summary>
        /// Gets or sets Exposure.
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Gets or sets AggregateLimit Rate.
        /// </summary>
        public decimal AggregateLimitRate { get; set; }

        /// <summary>
        /// Gets or sets EPInclusionExclusion Rate.
        /// </summary>
        public decimal EPInclusionExclusionRate { get; set; }

        /// <summary>
        /// Gets or sets Retention Rate.
        /// </summary>
        public decimal RetentionRate { get; set; }

        /// <summary>
        /// Gets or sets Population Rate.
        /// </summary>
        public decimal PopulationRate { get; set; }

        /// <summary>
        /// Gets or sets Location Rate.
        /// </summary>
        public decimal LocationRate { get; set; }

        /// <summary>
        /// Gets or sets PolicyType Rate.
        /// </summary>
        public decimal PolicyTypeRate { get; set; }

        /// <summary>
        /// Gets or sets RetroDate Rate.
        /// </summary>
        public decimal RetroDateRate { get; set; }

        /// <summary>
        /// Gets or sets YearsinCM Rate.
        /// </summary>
        public decimal YearsinCMRate { get; set; }

        /// <summary>
        /// Gets or sets Loss Experience Rate.
        /// </summary>
        public decimal LossExperienceRate { get; set; }

        /// <summary>
        /// Gets or sets Rating Basis.
        /// </summary>
        public string RatingBasis { get; set; }

        //GRID START - OPTIONAL COVERAGES
        #region Optional Coverage
        public EmploymentPracticesOptionalCoverageOutputViewModel EmploymentPracticesOptionalCoverageModel { get; set; }
        #endregion

        /// <summary>
        /// Gets or sets Base Premium.
        /// </summary>
        public int BasePremium { get; set; }
        /// <summary>
        /// Gets or sets NonModified Premium.
        /// </summary>
        public int NonModifiedPremium { get; set; }
        /// <summary>
        /// Gets or sets Base Premium.
        /// </summary>
        public int ManualPremium { get; set; }
        /// <summary>
        /// Gets or sets IRPM Rate.
        /// </summary>
        public decimal IRPMRate { get; set; }
        /// <summary>
        /// Gets or sets IRPM Premium.
        /// </summary>
        public int IRPMPremium { get; set; }

        /// <summary>
        /// Gets or sets Terrorism Rate.
        /// </summary>
        public decimal TerrorismRate { get; set; }

        /// <summary>
        /// Gets or sets Terrorism Premium.
        /// </summary>
        public int TerrorismPremium { get; set; }

        /// <summary>
        /// Gets or sets OtherMod Rate.
        /// </summary>
        public decimal OtherModRate { get; set; }

        /// <summary>
        /// Gets or sets OtherMod Premium.
        /// </summary>
        public int OtherModPremium { get; set; }

        /// <summary>
        /// Gets or sets Tier Rate.
        /// </summary>

        public decimal TierRate { get; set; }

        /// <summary>
        /// Gets or sets Tier Premium.
        /// </summary>
        public int TierPremium { get; set; }

        /// <summary>
        /// Gets or sets EPFinal Modified Premium.
        /// </summary>
        public int EPFinalModifiedPremium { get; set; }

        /// <summary>
        /// Gets sets EP Total Unmodified Without Excess Premium
        /// </summary>
        public int EPTotalUnModifiedWithoutExcessPremium { get; set; }
    }
}
