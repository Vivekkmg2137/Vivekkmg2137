﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.GeneralLiability.output
{
    public class GeneralLiabilityOptionalCoverageOutputViewModel
    {

        #region Cemetery Professional Liability - GL-203
        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203IsSelected
        /// </summary>
        public bool CemeteryProfessionalLiabilityGL203IsSelected { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203Limit
        /// </summary>
        public int CemeteryProfessionalLiabilityGL203Limit { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203AggregateLimit
        /// </summary>
        public int CemeteryProfessionalLiabilityGL203AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203Deductible
        /// </summary>
        public int CemeteryProfessionalLiabilityGL203Deductible { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203RatingBasis
        /// </summary>
        public string CemeteryProfessionalLiabilityGL203RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203ReturnMethod
        /// </summary>
        public string CemeteryProfessionalLiabilityGL203ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203Rate
        /// </summary>
        public decimal CemeteryProfessionalLiabilityGL203Rate { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203IncludedinExcessExposure
        /// </summary>
        public string CemeteryProfessionalLiabilityGL203IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203UnmodifiedWithoutExcessPremium
        /// </summary>
        public int CemeteryProfessionalLiabilityGL203UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203UnmodifiedPremium
        /// </summary>
        public int CemeteryProfessionalLiabilityGL203UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets CemeteryProfessionalLiabilityGL203ModifiedPremium
        /// </summary>
        public int CemeteryProfessionalLiabilityGL203ModifiedPremium { get; set; }

        #endregion

        #region Cyber - Suppl. Extended Reporting Period
        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodIsSelected
        /// </summary>
        public bool CyberSupplExtendedReportingPeriodIsSelected { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodLimit
        /// </summary>
        public string CyberSupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodAggregateLimit
        /// </summary>
        public int CyberSupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodDeductible
        /// </summary>
        public int CyberSupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodRatingBasis
        /// </summary>
        public string CyberSupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodReturnMethod
        /// </summary>
        public string CyberSupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodRate
        /// </summary>
        public decimal CyberSupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodIncludedinExcessExposure
        /// </summary>
        public string CyberSupplExtendedReportingPeriodIncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium
        /// </summary>
        public int CyberSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodUnmodifiedPremium
        /// </summary>
        public int CyberSupplExtendedReportingPeriodUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets CyberSupplExtendedReportingPeriodModifiedPremium
        /// </summary>
        public int CyberSupplExtendedReportingPeriodModifiedPremium { get; set; }

        #endregion

        #region Data Compromise  - Suppl. Extended Reporting Period
        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodIsSelected
        /// </summary>
        public bool DataCompromiseSupplExtendedReportingPeriodIsSelected { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodLimit
        /// </summary>
        public string DataCompromiseSupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodAggregateLimit
        /// </summary>
        public int DataCompromiseSupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodDeductible
        /// </summary>
        public int DataCompromiseSupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodRatingBasis
        /// </summary>
        public string DataCompromiseSupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodReturnMethod
        /// </summary>
        public string DataCompromiseSupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodRate
        /// </summary>
        public decimal DataCompromiseSupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure
        /// </summary>
        public string DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium
        /// </summary>
        public int DataCompromiseSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium
        /// </summary>
        public int DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseSupplExtendedReportingPeriodModifiedPremium
        /// </summary>
        public int DataCompromiseSupplExtendedReportingPeriodModifiedPremium { get; set; }

        #endregion

        #region Employers Liability - GL-600
        /// <summary>
        /// Gets or sets EmployersLiabilityGL600IsSelected
        /// </summary>
        public bool EmployersLiabilityGL600IsSelected { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600Limit
        /// </summary>
        public string EmployersLiabilityGL600Limit { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600AggregateLimit
        /// </summary>
        public int EmployersLiabilityGL600AggregateLimit { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600Deductible
        /// </summary>
        public int EmployersLiabilityGL600Deductible { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600RatingBasis
        /// </summary>
        public string EmployersLiabilityGL600RatingBasis { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600ReturnMethod
        /// </summary>
        public string EmployersLiabilityGL600ReturnMethod { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600Rate
        /// </summary>
        public decimal EmployersLiabilityGL600Rate { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600IncludedinExcessExposure
        /// </summary>
        public string EmployersLiabilityGL600IncludedinExcessExposure { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600UnmodifiedWithoutExcessPremium
        /// </summary>
        public int EmployersLiabilityGL600UnmodifiedWithoutExcessPremium { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600UnmodifiedPremium
        /// </summary>
        public int EmployersLiabilityGL600UnmodifiedPremium { get; set; }

        // <summary>
        /// Gets or sets EmployersLiabilityGL600ModifiedPremium
        /// </summary>
        public int EmployersLiabilityGL600ModifiedPremium { get; set; }

        #endregion

        #region Failure to Supply Exclusion - GL-304
        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304IsSelected
        /// </summary>
        public bool FailuretoSupplyExclusionGL304IsSelected { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304Limit
        /// </summary>
        public string FailuretoSupplyExclusionGL304Limit { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304AggregateLimit
        /// </summary>
        public int FailuretoSupplyExclusionGL304AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304Deductible
        /// </summary>
        public int FailuretoSupplyExclusionGL304Deductible { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304RatingBasis
        /// </summary>
        public string FailuretoSupplyExclusionGL304RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304ReturnMethod
        /// </summary>
        public string FailuretoSupplyExclusionGL304ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304Rate
        /// </summary>
        public decimal FailuretoSupplyExclusionGL304Rate { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304IncludedinExcessExposure
        /// </summary>
        public string FailuretoSupplyExclusionGL304IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304UnmodifiedWithoutExcessPremium
        /// </summary>
        public int FailuretoSupplyExclusionGL304UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304UnmodifiedPremium
        /// </summary>
        public int FailuretoSupplyExclusionGL304UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplyExclusionGL304ModifiedPremium
        /// </summary>
        public int FailuretoSupplyExclusionGL304ModifiedPremium { get; set; }

        #endregion

        #region Failure to Supply Sublimit - GL-211
        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211IsSelected
        /// </summary>
        public bool FailuretoSupplySublimitGL211IsSelected { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211Limit
        /// </summary>
        public int FailuretoSupplySublimitGL211Limit { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211Aggregateimit
        /// </summary>
        public int FailuretoSupplySublimitGL211Aggregateimit { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211Deductible
        /// </summary>
        public int FailuretoSupplySublimitGL211Deductible { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211RatingBasis
        /// </summary>
        public string FailuretoSupplySublimitGL211RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211ReturnMethod
        /// </summary>
        public string FailuretoSupplySublimitGL211ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211Rate
        /// </summary>
        public decimal FailuretoSupplySublimitGL211Rate { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211IncludedinExcessExposure
        /// </summary>
        public string FailuretoSupplySublimitGL211IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211UnmodifiedWithoutExcessPremium
        /// </summary>
        public int FailuretoSupplySublimitGL211UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211UnmodifiedPremium
        /// </summary>
        public int FailuretoSupplySublimitGL211UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets FailuretoSupplySublimitGL211ModifiedPremium
        /// </summary>
        public int FailuretoSupplySublimitGL211ModifiedPremium { get; set; }

        #endregion

        #region Fellow Employee - GL-206
        /// <summary>
        /// Gets or sets FellowEmployeeGL206IsSelected
        /// </summary>
        public bool FellowEmployeeGL206IsSelected { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206Limit
        /// </summary>
        public int FellowEmployeeGL206Limit { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206AggregateLimit
        /// </summary>
        public int FellowEmployeeGL206AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206Deductible
        /// </summary>
        public int FellowEmployeeGL206Deductible { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206RatingBasis
        /// </summary>
        public string FellowEmployeeGL206RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206ReturnMethod
        /// </summary>
        public string FellowEmployeeGL206ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206Rate
        /// </summary>
        public decimal FellowEmployeeGL206Rate { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206IncludedinExcessExposure
        /// </summary>
        public string FellowEmployeeGL206IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206UnmodifiedWithoutExcessPremium
        /// </summary>
        public int FellowEmployeeGL206UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206UnmodifiedPremium
        /// </summary>
        public int FellowEmployeeGL206UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets FellowEmployeeGL206ModifiedPremium
        /// </summary>
        public int FellowEmployeeGL206ModifiedPremium { get; set; }

        #endregion

        #region Limited Pollution Coverage - GL-210
        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210IsSelected
        /// </summary>
        public bool LimitedPollutionCoverageGL210IsSelected { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210Limit
        /// </summary>
        public int LimitedPollutionCoverageGL210Limit { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210AggregateLimit
        /// </summary>
        public int LimitedPollutionCoverageGL210AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210Deductible
        /// </summary>
        public int LimitedPollutionCoverageGL210Deductible { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210RatingBasis
        /// </summary>
        public string LimitedPollutionCoverageGL210RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210ReturnMethod
        /// </summary>
        public string LimitedPollutionCoverageGL210ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210Rate
        /// </summary>
        public decimal LimitedPollutionCoverageGL210Rate { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210IncludedinExcessExposure
        /// </summary>
        public string LimitedPollutionCoverageGL210IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210UnmodifiedWithoutExcessPremium
        /// </summary>
        public int LimitedPollutionCoverageGL210UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210UnmodifiedPremium
        /// </summary>
        public int LimitedPollutionCoverageGL210UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets LimitedPollutionCoverageGL210ModifiedPremium
        /// </summary>
        public int LimitedPollutionCoverageGL210ModifiedPremium { get; set; }

        #endregion

        #region PA Heart & Lung Benefits - Limit per Officer - GL 801
        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801IsSelected
        /// </summary>
        public bool PAHeartAndLungBenefitsLimitperOfficerGL801IsSelected { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801Limit
        /// </summary>
        public int PAHeartAndLungBenefitsLimitperOfficerGL801Limit { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801AggregateLimit
        /// </summary>
        public int PAHeartAndLungBenefitsLimitperOfficerGL801AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801Deductible
        /// </summary>
        public int PAHeartAndLungBenefitsLimitperOfficerGL801Deductible { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801RatingBasis
        /// </summary>
        public string PAHeartAndLungBenefitsLimitperOfficerGL801RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801ReturnMethod
        /// </summary>
        public string PAHeartAndLungBenefitsLimitperOfficerGL801ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801Rate
        /// </summary>
        public decimal PAHeartAndLungBenefitsLimitperOfficerGL801Rate { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure
        /// </summary>
        public string PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedWithoutExcessPremium
        /// </summary>
        public int PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedPremium
        /// </summary>
        public int PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsLimitperOfficerGL801ModifiedPremium
        /// </summary>
        public int PAHeartAndLungBenefitsLimitperOfficerGL801ModifiedPremium { get; set; }

        #endregion

        #region PA Heart & Lung Benefits - Policy Level Aggregate - GL 800
        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800IsSelected
        /// </summary>
        public bool PAHeartAndLungBenefitsPolicyLevelAggregateGL800IsSelected { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800Limit
        /// </summary>
        public int PAHeartAndLungBenefitsPolicyLevelAggregateGL800Limit { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800AggregateLimit
        /// </summary>
        public int PAHeartAndLungBenefitsPolicyLevelAggregateGL800AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800Deductible
        /// </summary>
        public int PAHeartAndLungBenefitsPolicyLevelAggregateGL800Deductible { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800RatingBasis
        /// </summary>
        public string PAHeartAndLungBenefitsPolicyLevelAggregateGL800RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800ReturnMethod
        /// </summary>
        public string PAHeartAndLungBenefitsPolicyLevelAggregateGL800ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800Rate
        /// </summary>
        public decimal PAHeartAndLungBenefitsPolicyLevelAggregateGL800Rate { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure
        /// </summary>
        public string PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedWithoutExcessPremium
        /// </summary>
        public int PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedPremium
        /// </summary>
        public int PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets PAHeartAndLungBenefitsPolicyLevelAggregateGL800ModifiedPremium
        /// </summary>
        public int PAHeartAndLungBenefitsPolicyLevelAggregateGL800ModifiedPremium { get; set; }

        #endregion

        #region  Pesticide or Herbicide Applicator - AG 7314
        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314IsSelected
        /// </summary>
        public bool PesticideorHerbicideApplicatorAG7314IsSelected { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314Limit
        /// </summary>
        public int PesticideorHerbicideApplicatorAG7314Limit { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314AggregateLimit
        /// </summary>
        public int PesticideorHerbicideApplicatorAG7314AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314Deductible
        /// </summary>
        public int PesticideorHerbicideApplicatorAG7314Deductible { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314RatingBasis
        /// </summary>
        public string PesticideorHerbicideApplicatorAG7314RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314ReturnMethod
        /// </summary>
        public string PesticideorHerbicideApplicatorAG7314ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314Rate
        /// </summary>
        public decimal PesticideorHerbicideApplicatorAG7314Rate { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure
        /// </summary>
        public string PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314UnmodifiedWithoutExcessPremium
        /// </summary>
        public int PesticideorHerbicideApplicatorAG7314UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314UnmodifiedPremium
        /// </summary>
        public int PesticideorHerbicideApplicatorAG7314UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets PesticideorHerbicideApplicatorAG7314ModifiedPremium
        /// </summary>
        public int PesticideorHerbicideApplicatorAG7314ModifiedPremium { get; set; }

        #endregion

        #region School Violent Event Response - AG GL 1000
        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000IsSelected
        /// </summary>
        public bool SchoolViolentEventResponseAGGL1000IsSelected { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000Limit
        /// </summary>
        public int SchoolViolentEventResponseAGGL1000Limit { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000AggregateLimit
        /// </summary>
        public int SchoolViolentEventResponseAGGL1000AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000Deductible
        /// </summary>
        public int SchoolViolentEventResponseAGGL1000Deductible { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000RatingBasis
        /// </summary>
        public string SchoolViolentEventResponseAGGL1000RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000ReturnMethod
        /// </summary>
        public string SchoolViolentEventResponseAGGL1000ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000Rate
        /// </summary>
        public decimal SchoolViolentEventResponseAGGL1000Rate { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000IncludedinExcessExposure
        /// </summary>
        public string SchoolViolentEventResponseAGGL1000IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000UnmodifiedWithoutExcessPremium
        /// </summary>
        public int SchoolViolentEventResponseAGGL1000UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000UnmodifiedPremium
        /// </summary>
        public int SchoolViolentEventResponseAGGL1000UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets SchoolViolentEventResponseAGGL1000ModifiedPremium
        /// </summary>
        public int SchoolViolentEventResponseAGGL1000ModifiedPremium { get; set; }

        #endregion

        #region Sewer Backup Aggregate Limit - GL-217
        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217IsSelected
        /// </summary>
        public bool SewerBackupAggregateLimitGL217IsSelected { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217Limit
        /// </summary>
        public int SewerBackupAggregateLimitGL217Limit { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217AggregateLimit
        /// </summary>
        public int SewerBackupAggregateLimitGL217AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217Deductible
        /// </summary>
        public int SewerBackupAggregateLimitGL217Deductible { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217RatingBasis
        /// </summary>
        public string SewerBackupAggregateLimitGL217RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217ReturnMethod
        /// </summary>
        public string SewerBackupAggregateLimitGL217ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217Rate
        /// </summary>
        public decimal SewerBackupAggregateLimitGL217Rate { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217IncludedinExcessExposure
        /// </summary>
        public string SewerBackupAggregateLimitGL217IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217UnmodifiedWithoutExcessPremium
        /// </summary>
        public int SewerBackupAggregateLimitGL217UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217UnmodifiedPremium
        /// </summary>
        public int SewerBackupAggregateLimitGL217UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupAggregateLimitGL217ModifiedPremium
        /// </summary>
        public int SewerBackupAggregateLimitGL217ModifiedPremium { get; set; }

        #endregion

        #region Sewer Backup Sublimit - GL-260
        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260IsSelected
        /// </summary>
        public bool SewerBackupSublimitGL260IsSelected { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260Limit
        /// </summary>
        public int SewerBackupSublimitGL260Limit { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260AggregateLimit
        /// </summary>
        public int SewerBackupSublimitGL260AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260Deductible
        /// </summary>
        public int SewerBackupSublimitGL260Deductible { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260RatingBasis
        /// </summary>
        public string SewerBackupSublimitGL260RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260ReturnMethod
        /// </summary>
        public string SewerBackupSublimitGL260ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260Rate
        /// </summary>
        public decimal SewerBackupSublimitGL260Rate { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260IncludedinExcessExposure
        /// </summary>
        public string SewerBackupSublimitGL260IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260UnmodifiedWithoutExcessPremium
        /// </summary>
        public int SewerBackupSublimitGL260UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260UnmodifiedPremium
        /// </summary>
        public int SewerBackupSublimitGL260UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets SewerBackupSublimitGL260ModifiedPremium
        /// </summary>
        public int SewerBackupSublimitGL260ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Controlling Interest - CG 20 05
        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005IsSelected
        /// </summary>
        public bool AdditionalInsuredControllingInterestCG2005IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005Limit
        /// </summary>
        public int AdditionalInsuredControllingInterestCG2005Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005AggregateLimit
        /// </summary>
        public int AdditionalInsuredControllingInterestCG2005AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005Deductible
        /// </summary>
        public int AdditionalInsuredControllingInterestCG2005Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005RatingBasis
        /// </summary>
        public string AdditionalInsuredControllingInterestCG2005RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005ReturnMethod
        /// </summary>
        public string AdditionalInsuredControllingInterestCG2005ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005Rate
        /// </summary>
        public decimal AdditionalInsuredControllingInterestCG2005Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredControllingInterestCG2005UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredControllingInterestCG2005UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredControllingInterestCG2005ModifiedPremium
        /// </summary>
        public int AdditionalInsuredControllingInterestCG2005ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Designated Person or Organization - CG 20 26
        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected
        /// </summary>
        public bool AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026Limit
        /// </summary>
        public int AdditionalInsuredDesignatedPersonorOrganizationCG2026Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026AggregateLimit
        /// </summary>
        public int AdditionalInsuredDesignatedPersonorOrganizationCG2026AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026Deductible
        /// </summary>
        public int AdditionalInsuredDesignatedPersonorOrganizationCG2026Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026RatingBasis
        /// </summary>
        public string AdditionalInsuredDesignatedPersonorOrganizationCG2026RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026ReturnMethod
        /// </summary>
        public string AdditionalInsuredDesignatedPersonorOrganizationCG2026ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026Rate
        /// </summary>
        public decimal AdditionalInsuredDesignatedPersonorOrganizationCG2026Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonorOrganizationCG2026ModifiedPremium
        /// </summary>
        public int AdditionalInsuredDesignatedPersonorOrganizationCG2026ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Designated Person Or Organization For a Specified Event - AG 7305
        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IsSelected
        /// </summary>
        public bool AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Limit
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305AggregateLimit
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Deductible
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305RatingBasis
        /// </summary>
        public string AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305ReturnMethod
        /// </summary>
        public string AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Rate
        /// </summary>
        public decimal AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305ModifiedPremium
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306
        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelected
        /// </summary>
        public bool AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Limit
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306AggregateLimit
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Deductible
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306RatingBasis
        /// </summary>
        public string AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306ReturnMethod
        /// </summary>
        public string AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Rate
        /// </summary>
        public decimal AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306ModifiedPremium
        /// </summary>
        public int AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306ModifiedPremium { get; set; }

        #endregion

        #region  Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34
        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IsSelected
        /// </summary>
        public bool AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Limit
        /// </summary>
        public int AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034AggregateLimit
        /// </summary>
        public int AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Deductible
        /// </summary>
        public int AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034RatingBasis
        /// </summary>
        public string AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034ReturnMethod
        /// </summary>
        public string AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Rate
        /// </summary>
        public decimal AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034ModifiedPremium
        /// </summary>
        public int AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034ModifiedPremium { get; set; }

        #endregion

        #region  Additional Insured - Lessor of Leased Equipment - CG 20 28
        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028IsSelected
        /// </summary>
        public bool AdditionalInsuredLessorofLeasedEquipmentCG2028IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028Limit
        /// </summary>
        public int AdditionalInsuredLessorofLeasedEquipmentCG2028Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028AggregateLimit
        /// </summary>
        public int AdditionalInsuredLessorofLeasedEquipmentCG2028AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028Deductible
        /// </summary>
        public int AdditionalInsuredLessorofLeasedEquipmentCG2028Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028RatingBasis
        /// </summary>
        public string AdditionalInsuredLessorofLeasedEquipmentCG2028RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028ReturnMethod
        /// </summary>
        public string AdditionalInsuredLessorofLeasedEquipmentCG2028ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028Rate
        /// </summary>
        public decimal AdditionalInsuredLessorofLeasedEquipmentCG2028Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLessorofLeasedEquipmentCG2028ModifiedPremium
        /// </summary>
        public int AdditionalInsuredLessorofLeasedEquipmentCG2028ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307
        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelected
        /// </summary>
        public bool AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Limit
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307AggregateLimit
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Deductible
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307RatingBasis
        /// </summary>
        public string AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307ReturnMethod
        /// </summary>
        public string AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Rate
        /// </summary>
        public decimal AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307ModifiedPremium
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Managers or Lessors of Premises - CG 20 11
        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011IsSelected
        /// </summary>
        public bool AdditionalInsuredManagersorLessorsofPremisesCG2011IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011Limit
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesCG2011Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011AggregateLimit
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesCG2011AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011Deductible
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesCG2011Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011RatingBasis
        /// </summary>
        public string AdditionalInsuredManagersorLessorsofPremisesCG2011RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011ReturnMethod
        /// </summary>
        public string AdditionalInsuredManagersorLessorsofPremisesCG2011ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011Rate
        /// </summary>
        public decimal AdditionalInsuredManagersorLessorsofPremisesCG2011Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredManagersorLessorsofPremisesCG2011ModifiedPremium
        /// </summary>
        public int AdditionalInsuredManagersorLessorsofPremisesCG2011ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18
        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected
        /// </summary>
        public bool AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018Limit
        /// </summary>
        public int AdditionalInsuredMortgageeAssigneeorReceiverCG2018Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018AggregateLimit
        /// </summary>
        public int AdditionalInsuredMortgageeAssigneeorReceiverCG2018AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018Deductible
        /// </summary>
        public int AdditionalInsuredMortgageeAssigneeorReceiverCG2018Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018RatingBasis
        /// </summary>
        public string AdditionalInsuredMortgageeAssigneeorReceiverCG2018RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018ReturnMethod
        /// </summary>
        public string AdditionalInsuredMortgageeAssigneeorReceiverCG2018ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018Rate
        /// </summary>
        public decimal AdditionalInsuredMortgageeAssigneeorReceiverCG2018Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredMortgageeAssigneeorReceiverCG2018ModifiedPremium
        /// </summary>
        public int AdditionalInsuredMortgageeAssigneeorReceiverCG2018ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24
        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IsSelected
        /// </summary>
        public bool AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Limit
        /// </summary>
        public int AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024AggregateLimit
        /// </summary>
        public int AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Deductible
        /// </summary>
        public int AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024RatingBasis
        /// </summary>
        public string AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024ReturnMethod
        /// </summary>
        public string AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Rate
        /// </summary>
        public decimal AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024ModifiedPremium
        /// </summary>
        public int AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Students Involved In The School's Internship, Practicum And Teaching Program - AG 7310
        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected
        /// </summary>
        public bool AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Limit
        /// </summary>
        public int AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310AggregateLimit
        /// </summary>
        public int AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Deductible
        /// </summary>
        public int AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310RatingBasis
        /// </summary>
        public string AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310ReturnMethod
        /// </summary>
        public string AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Rate
        /// </summary>
        public decimal AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310ModifiedPremium
        /// </summary>
        public int AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310ModifiedPremium { get; set; }

        #endregion

        #region Additional Insured - Users of Golfmobiles - CG 20 08
        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008IsSelected
        /// </summary>
        public bool AdditionalInsuredUsersofGolfmobilesCG2008IsSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008Limit
        /// </summary>
        public int AdditionalInsuredUsersofGolfmobilesCG2008Limit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008AggregateLimit
        /// </summary>
        public int AdditionalInsuredUsersofGolfmobilesCG2008AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008Deductible
        /// </summary>
        public int AdditionalInsuredUsersofGolfmobilesCG2008Deductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008RatingBasis
        /// </summary>
        public string AdditionalInsuredUsersofGolfmobilesCG2008RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008ReturnMethod
        /// </summary>
        public string AdditionalInsuredUsersofGolfmobilesCG2008ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008Rate
        /// </summary>
        public decimal AdditionalInsuredUsersofGolfmobilesCG2008Rate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure
        /// </summary>
        public string AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedWithoutExcessPremium
        /// </summary>
        public int AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredUsersofGolfmobilesCG2008ModifiedPremium
        /// </summary>
        public int AdditionalInsuredUsersofGolfmobilesCG2008ModifiedPremium { get; set; }

        #endregion

        #region Limited Additional Insured - Designated Person Or Organization For Designated Premises - AG 7309
        /// <summary>
        /// Gets or sets LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IsSelected
        /// </summary>
        public bool LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IsSelected { get; set; }

        /// <summary>
        /// Gets or sets LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Limit
        /// </summary>
        public int LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Limit { get; set; }

        /// <summary>
        /// Gets or sets LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309AggregateLimit
        /// </summary>
        public int LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Deductible
        /// </summary>
        public int LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Deductible { get; set; }

        /// <summary>
        /// Gets or sets LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309RatingBasis
        /// </summary>
        public string LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309ReturnMethod
        /// </summary>
        public string LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309ReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Rate
        /// </summary>
        public decimal LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Rate { get; set; }

        /// <summary>
        /// Gets or sets ILimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure
        /// </summary>
        public string LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets ILimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedWithoutExcessPremium
        /// </summary>
        public int LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium
        /// </summary>
        public int LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309ModifiedPremium
        /// </summary>
        public int LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309ModifiedPremium { get; set; }

        #endregion
        /// <summary>
        /// Gets or sets generalLiabilityOptionalOtherCoverageOutputModels
        /// </summary>
        public List<GeneralLiabilityOptionalOtherCoverageOutputViewModel> GeneralLiabilityOptionalOtherCoverageModel { get; set; }
    }

    public class GeneralLiabilityOptionalOtherCoverageOutputViewModel
    {
        /// <summary>
        /// Gets or sets OtherCoverageID
        /// </summary>
        public int OtherCoverageID { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageDescription
        /// </summary>
        public string OtherCoverageDescription { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageLimit
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageAggregateLimit
        /// </summary>
        public int OtherCoverageAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageDeductible
        /// </summary>
        public int OtherCoverageDeductible { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageRate
        /// </summary>
        public decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageRatingBasis
        /// </summary>
        public string OtherCoverageRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageReturnMethod
        /// </summary>
        public string OtherCoverageReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageIncludedinExcessExposure
        /// </summary>
        public string OtherCoverageIncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageUnmodifiedWithoutExcessPremium
        /// </summary>
        public int OtherCoverageUnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageUnmodifiedPremium
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageModifiedPremium
        /// </summary>
        public int OtherCoverageModifiedPremium { get; set; }
    }
}
