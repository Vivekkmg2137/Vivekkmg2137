﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.InlandMarine.Input
{
    public class InlandMarineInputViewModel
    {
    }
}
