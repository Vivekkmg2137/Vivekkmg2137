﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.LawEnforcement.Input
{
    public class LawEnforcementInputViewModel
    {
        /// <summary>
        /// Gets or sets LineOfBusiness
        /// </summary>
        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "LE";

        /// <summary>
        /// Gets or sets Officer
        /// </summary>
        public int Officer { get; set; }

        /// <summary>
        /// Gets or sets ExposureRate
        /// </summary>
        public decimal ExposureRate { get; set; }

        /// <summary>
        /// Gets or sets LiabilityLimit
        /// </summary>
        public int LiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets AggregateLimit
        /// </summary>
        public int AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets LiabilityLimitRate
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Gets or sets Deductible_SIR
        /// </summary>
        public string Deductible_SIR { get; set; }

        /// <summary>
        /// Gets or sets Retention
        /// </summary>
        public string Retention { get; set; }

        /// <summary>
        /// Gets or sets AggregateRetention
        /// </summary>
        public int AggregateRetention { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Retention
        /// </summary>
        public string Expense { get; set; }

        /// <summary>
        /// Gets or sets ExperienceFactor
        /// </summary>
        public bool ExperienceFactor { get; set; }

        /// <summary>
        /// Gets or sets PolicyType
        /// </summary>
        public string PolicyType { get; set; }

        /// <summary>
        /// Gets or sets RetroActiveDate
        /// </summary>
        public DateTime RetroActiveDate { get; set; }

        /// <summary>
        /// Gets or sets YearsinCMProgram
        /// </summary>
        public int YearsinCMProgram { get; set; }

        /// <summary>
        /// Gets or sets IRPMRate
        /// </summary>
        public decimal IRPMRate { get; set; }

        /// <summary>
        /// Gets or sets OtherModRate
        /// </summary>
        public decimal OtherModRate { get; set; }

        /// <summary>
        /// Gets or sets IRPMApplies
        /// </summary>
        public bool IRPMApplies { get; set; }

        #region UNMANNED AIRCRAFT COVERAGE

        /// <summary>
        /// Gets or sets UnmannedAircraftOption
        /// </summary>
        public string UnmannedAircraftOption { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftAggregateLimit
        /// </summary>
        public int UnmannedAircraftAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverageIncludedinExcessExposure
        /// </summary>
        public string UnmannedAircraftCoverageIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15lbsorLessRate
        /// </summary>
        public decimal UnmannedAircraftCoverage15lbsorLessRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15lbsorLessTotalUnits
        /// </summary>
        public int UnmannedAircraftCoverage15lbsorLessTotalUnits { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15PT1_to_lt55lbsRate
        /// </summary>
        public decimal UnmannedAircraftCoverage15PT1_to_lt55lbsRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15PT1_to_lt55lbsTotalUnits
        /// </summary>
        public int UnmannedAircraftCoverage15PT1_to_lt55lbsTotalUnits { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage_gteq55lbslbsRate
        /// </summary>
        public decimal UnmannedAircraftCoverage_gteq55lbslbsRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage_gteq55lbsTotalUnits
        /// </summary>
        public int UnmannedAircraftCoverage_gteq55lbsTotalUnits { get; set; }

        #endregion

        #region Optional Coverage

        /// <summary>
        /// Gets or sets LawOptionalCoverageInputModel
        /// </summary>
        public LawEnforcementOptionalCoverageInputViewModel LawEnforcementOptionalCoverageModel { get; set; }

        #endregion
    }
}
