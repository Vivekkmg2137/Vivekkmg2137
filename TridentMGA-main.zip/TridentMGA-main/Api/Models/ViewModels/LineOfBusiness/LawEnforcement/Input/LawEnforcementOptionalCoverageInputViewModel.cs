﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.LawEnforcement.Input
{
    public class LawEnforcementOptionalCoverageInputViewModel
    {
        #region Line of Duty Death Benefits

        /// <summary>
        /// Gets or sets LineofDutyDeathBenefitsIsSelected
        /// </summary>
        public bool LineOfDutyDeathBenefitsIsSelected { get; set; }

        /// <summary>
        /// Gets or sets LineofDutyDeathBenefitsLimit
        /// </summary>
        public int LineOfDutyDeathBenefitsLimit { get; set; }

        /// <summary>
        /// Gets or sets LineofDutyDeathBenefitsAggregateLimit
        /// </summary>
        public int LineOfDutyDeathBenefitsAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets LineofDutyDeathBenefitsDeductible
        /// </summary>
        public int LineOfDutyDeathBenefitsDeductible { get; set; }

        /// <summary>
        /// Gets or sets LineofDutyDeathBenefitsRatingBasis
        /// </summary>
        public string LineOfDutyDeathBenefitsRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets LineofDutyDeathBenefitsReturnMethod
        /// </summary>
        public string LineOfDutyDeathBenefitsReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets LineofDutyDeathBenefitsRate
        /// </summary>
        public decimal LineOfDutyDeathBenefitsRate { get; set; }

        /// <summary>
        /// Gets or sets LineofDutyDeathBenefitsUnmodifiedPremium
        /// </summary>
        public int LineOfDutyDeathBenefitsUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets LineofDutyDeathBenefitsModifiedPremium
        /// </summary>
        public int LineOfDutyDeathBenefitsModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets LineOfDutyDeathBenefitsIncludedInExcessExposure
        /// </summary>
        public string LineOfDutyDeathBenefitsIncludedInExcessExposure { get; set; }

        #endregion

        #region Non-Monetary Defense

        /// <summary>
        /// Gets or sets NonMonetaryDefenseIsSelected
        /// </summary>
        public bool NonMonetaryDefenseIsSelected { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseLimit
        /// </summary>
        public int NonMonetaryDefenseLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseAggregateLimit
        /// </summary>
        public int NonMonetaryDefenseAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseDeductible
        /// </summary>
        public int NonMonetaryDefenseDeductible { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRatingBasis
        /// </summary>
        public string NonMonetaryDefenseRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseReturnMethod
        /// </summary>
        public string NonMonetaryDefenseReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRate
        /// </summary>
        public decimal NonMonetaryDefenseRate { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseUnmodifiedPremium
        /// </summary>
        public int NonMonetaryDefenseUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseModifiedPremium
        /// </summary>
        public int NonMonetaryDefenseModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseIncludedInExcessExposure
        /// </summary>
        public string NonMonetaryDefenseIncludedInExcessExposure { get; set; }

        #endregion

        #region Additional Insured - Law Enforcement Agencies

        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesIsSelected
        /// </summary>
        public bool AdditionalInsuredLawEnforcementAgenciesIsSelected { get; set; }
         
        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesLimit
        /// </summary>
        public int AdditionalInsuredLawEnforcementAgenciesLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesAggregateLimit
        /// </summary>
        public int AdditionalInsuredLawEnforcementAgenciesAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesDeductible
        /// </summary>
        public int AdditionalInsuredLawEnforcementAgenciesDeductible { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesRatingBasis
        /// </summary>
        public string AdditionalInsuredLawEnforcementAgenciesRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesReturnMethod
        /// </summary>
        public string AdditionalInsuredLawEnforcementAgenciesReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesRate
        /// </summary>
        public decimal AdditionalInsuredLawEnforcementAgenciesRate { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium
        /// </summary>
        public int AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesModifiedPremium
        /// </summary>
        public int AdditionalInsuredLawEnforcementAgenciesModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets AdditionalInsuredLawEnforcementAgenciesIncludedInExcessExposure
        /// </summary>
        public string AdditionalInsuredLawEnforcementAgenciesIncludedInExcessExposure { get; set; }

        #endregion

        #region Suppl. Extended Reporting Period

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodIsSelected
        /// </summary>
        public bool SupplExtendedReportingPeriodIsSelected { get; set; }

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodLimit
        /// </summary>
        public int SupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodAggregateLimit
        /// </summary>
        public int SupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodDeductible
        /// </summary>
        public int SupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodRatingBasis
        /// </summary>
        public string SupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodReturnMethod
        /// </summary>
        public string SupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodRate
        /// </summary>
        public decimal SupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodUnmodifiedPremium
        /// </summary>
        public int SupplExtendedReportingPeriodUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodModifiedPremium
        /// </summary>
        public int SupplExtendedReportingPeriodModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets SupplExtendedReportingPeriodIncludedInExcessExposure
        /// </summary>
        public string SupplExtendedReportingPeriodIncludedInExcessExposure { get; set; }

        #endregion

        #region NY Suppl. Extended Reporting Period

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodIsSelected
        /// </summary>
        public bool NYSupplExtendedReportingPeriodIsSelected { get; set; }

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodLimit
        /// </summary>
        public int NYSupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodAggregateLimit
        /// </summary>
        public int NYSupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodDeductible
        /// </summary>
        public int NYSupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodRatingBasis
        /// </summary>
        public string NYSupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodReturnMethod
        /// </summary>
        public string NYSupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodRate
        /// </summary>
        public decimal NYSupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodUnmodifiedPremium
        /// </summary>
        public int NYSupplExtendedReportingPeriodUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodModifiedPremium
        /// </summary>
        public int NYSupplExtendedReportingPeriodModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets NYSupplExtendedReportingPeriodIncludedInExcessExposure
        /// </summary>
        public string NYSupplExtendedReportingPeriodIncludedInExcessExposure { get; set; }

        #endregion        

        /// <summary>
        /// List Of LawOptionalOtherCoverageInputModel
        /// </summary>
        public List<LawEnforcementOptionalOtherCoverageInputViewModel> LawEnforcementOptionalOtherCoverageModel { get; set; }

    }

    public class LawEnforcementOptionalOtherCoverageInputViewModel
    {
        #region Other Coverage 

        /// <summary>
        /// List Of OtherCoverageID
        /// </summary>
        public int OtherCoverageID { get; set; }

        /// <summary>
        /// List Of OtherCoverageDescription
        /// </summary>
        public string OtherCoverageDescription { get; set; }

        /// <summary>
        /// List Of OtherCoverageLimit
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// List Of OtherCoverageAggregateLimit
        /// </summary>
        public int OtherCoverageAggregateLimit { get; set; }

        /// <summary>
        /// List Of OtherCoverageDedcutible
        /// </summary>
        public int OtherCoverageDedcutible { get; set; }

        /// <summary>
        /// List Of OtherCoverageRate
        /// </summary>
        public decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// List Of OtherCoverageRatingBasis
        /// </summary>
        public string OtherCoverageRatingBasis { get; set; }

        /// <summary>
        /// List Of OtherCoverageReturnMethod
        /// </summary>
        public string OtherCoverageReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageUnmodifiedPremium
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageModifiedPremium
        /// </summary>
        public int OtherCoverageModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageIncludedInExcessExposure
        /// </summary>
        public string OtherCoverageIncludedInExcessExposure { get; set; }


        #endregion
    }
}
