﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace Api.Models.ViewModels.LineOfBusiness.Ocp.Input
{
    public class OcpInputViewModel
    {

        public OcpInputViewModel()
        {
        }

        /// <summary>
        /// Gets or sets Limit
        /// </summary>
        public decimal Limit { get; set; }

        /// <summary>
        /// Gets or sets AggregateLimit
        /// </summary>
        public decimal AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets IRPMFlag
        /// </summary>
        public bool IRPMFlag { get; set; }
    }
}
