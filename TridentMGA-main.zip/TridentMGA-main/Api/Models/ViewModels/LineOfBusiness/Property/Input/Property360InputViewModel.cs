﻿using Api.Models.ViewModels.LineOfBusiness.Property.Input;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ViewModels.LineOfBusiness.Property.Input
{
    public class Property360InputViewModel
    {
        #region Business Income & Extra Expense Coverages

        #region Step 1 - Business Income & Extra Expense Coverages

        /// <summary>
        /// Gets or sets IsBusinessIncomeAndExtraExpenseCoverageSelected
        /// </summary>
        public bool IsBusinessIncomeAndExtraExpenseCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Business Income and Extra Expense Coverage name
        /// </summary>
        [JsonIgnore]
        public string BusinessIncomeAndExtraExpenseCoverageName { get; private set; } = "Business Income and Extra Expense";

        /// <summary>
        /// Gets or sets Business Income and Extra Expense Revised Limit
        /// </summary>
        public decimal BusinessIncomeAndExtraExpenseRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Business Income and Extra Expense Deductible
        /// </summary>
        public decimal BusinessIncomeAndExtraExpenseDeductible { get; set; }

        /// <summary>
        /// Gets or sets Business Income And Extra Expens eDays
        /// </summary>
        public int BusinessIncomeAndExtraExpenseDays { get; set; }
        #endregion

        #region  Step 2 - Dependent Property Business Income	

        /// <summary>
        /// Gets or sets IsDependentPropertyCoverageSelected
        /// </summary>
        public bool IsDependentPropertyCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Dependent Property Coverage Name
        /// </summary>                                                                                                                                                                                                          
        [JsonIgnore]
        public string DependentPropertyCoverageName { get; private set; } = "Dependent Property Business Income";

        /// <summary>
        /// Gets or sets Dependent Property Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal DependentPropertyRevisedLimit { get; set; }

        #endregion

        #region Step 3 -Interruption of Computer Operations

        /// <summary>
        /// Gets or sets IsInterruptionOfComputerOperationsCoverageSelected
        /// </summary>
        public bool IsInterruptionOfComputerOperationsCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Interruption Of Computer Operations coverage Name
        /// </summary>
        [JsonIgnore]
        public string InterruptionOfComputerOperationsCoverageName { get; private set; } = "Interruption of Computer Operations";

        /// <summary>
        /// Gets or sets Interruption Of ComputerOperations Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal InterruptionOfComputerOperationsRevisedLimit { get; set; }

        #endregion

        #region Step 4 - Lease Cancellation Moving Expenses

        /// <summary>
        /// Gets or sets IsLeaseCancellationMovingExpensesCoverageSelected
        /// </summary>
        public bool IsLeaseCancellationMovingExpensesCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Lease Cancellation Moving Expenses Coverage name
        /// </summary>
        [JsonIgnore]
        public string LeaseCancellationMovingExpensesCoverageName { get; private set; } = "Lease Cancellation Moving Expenses";

        /// <summary>
        /// Gets or sets Lease Cancellation Moving Expenses Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal LeaseCancellationMovingExpensesRevisedLimit { get; set; }

        #endregion

        #region Step 5 - Newly Acquired or Constructed Property  – Business Income

        /// <summary>
        /// Gets or sets IsNewlyAcquiredOrConstructedPropertyCoverageSelected
        /// </summary>
        public bool IsNewlyAcquiredOrConstructedPropertyCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Coverage name
        /// </summary>
        [JsonIgnore]
        public string NewlyAcquiredOrConstructedPropertyCoverageName { get; private set; } = "Newly Acquired or Constructed Property – Business Income";

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyRevisedLimit { get; set; }

        #endregion

        #region Step 6 - Off Premises Utility Failure - Business Income and Extra Expense

        /// <summary>
        /// Gets or sets IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageSelected
        /// </summary>
        public bool IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Off Premises Utility Failure Business Income and Extra Expense Coverage name
        /// </summary>
        [JsonIgnore]
        public string OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageName { get; private set; } = "Off-Premises Utility Failure – Business Income and Extra Expense";

        /// <summary>
        /// Gets or sets Off Premises Utility Failure Business Income and Extra Expense Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Off Premises Utility Failure Business Income and Extra Expense  BIDeductible
        /// </summary>   
        public decimal OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseBIDeductible { get; set; }

        #endregion

        #region Ingress or Egress

        /// <summary>
        /// Gets or sets IsIngressOrEgressCoverageSelected
        /// </summary>
        public bool IsIngressOrEgressCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Ingress Or Egress Coverage name
        /// </summary>
        [JsonIgnore]
        public string IngressOrEgressCoverageName { get; private set; } = "";

        /// <summary>
        /// Gets or sets Ingress Or Egress Revised Limit
        /// </summary>
        public decimal IngressOrEgressRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Ingress Or Egress # Miles
        /// </summary>
        public decimal IngressOrEgressMiles { get; set; }
        #endregion

        #region Business Income Pollutant Clean Up and Removal 

        /// <summary>
        /// Gets or sets Is BusinessIncome Pollutant CleanUp And Removal Selected
        /// </summary>
        public bool IsBusinessIncomePollutantCleanUpAndRemovalSelected { get; set; }

        /// <summary>
        /// Gets or sets BusinessIncome Pollutant CleanUp And Removal Coverage name
        /// </summary>
        [JsonIgnore]
        public string BusinessIncomePollutantCleanUpAndRemovalCoverageName { get; private set; } = "Pollutant Cleanup and Removal - Business Income";

        /// <summary>
        /// Gets or sets BusinessIncome Pollutant CleanUp And Removal RevisedLimit
        /// </summary>
        public decimal BusinessIncomePollutantCleanUpAndRemovalRevisedLimit { get; set; }

        #endregion

        #endregion

        #region 360 Coverage Modifications							

        #region Step 7 - Ordinance or Law Coverage

        #region Coverage A   //TODO check reference
        /// <summary>
        /// Gets or sets Ordinance Or Law CoverageA Name
        /// </summary>
        [JsonIgnore]
        public string OrdinanceOrLawCoverageAName { get; private set; } = "Ordinance or Law - Coverage A";

        /// <summary>
        /// Gets or sets Ordinance Or Law CoverageA BaseLimit
        /// </summary> 
        public string OrdinanceOrLawCoverageABaseLimit { get; set; }
        #endregion

        #region Coverage B

        /// <summary>
        /// Gets or sets IsOrdinanceOrLawCoverageSelected
        /// </summary>
        public bool IsOrdinanceOrLawCoverageBSelected { get; set; }

        /// <summary>
        /// Gets or sets Ordinance or Law CoverageB Name
        /// </summary>
        [JsonIgnore]
        public string OrdinanceOrLawCoverageBName { get; private set; } = "Ordinance or Law - Coverage B";

        /// <summary>
        /// Gets or sets Ordinance or Law CoverageB Revised Limit
        /// </summary>    
        public decimal OrdinanceOrLawCoverageBRevisedLimit { get; set; }

        #endregion

        #region Coverage c

        /// <summary>
        /// Gets or sets IsOrdinanceOrLawCoverageCSelected
        /// </summary>
        public bool IsOrdinanceOrLawCoverageCSelected { get; set; }

        /// <summary>
        /// Gets or sets Ordinance or Law CoverageC Name
        /// </summary>
        [JsonIgnore]
        public string OrdinanceOrLawCoverageCName { get; private set; } = "Ordinance or Law - Coverage C";

        /// <summary>
        /// Gets or sets Ordinance or Law CoverageC Revised Limit
        /// </summary>    
        public decimal OrdinanceOrLawCoverageCRevisedLimit { get; set; }

        #endregion

        #endregion

        #region Step 8 - Accounts Receivable Records

        /// <summary>
        /// Gets or sets IsAccountsReceivableRecordsCoverageSelected
        /// </summary>
        public bool IsAccountsReceivableRecordsCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Accounts Receivable Records Name
        /// </summary>
        [JsonIgnore]
        public string AccountsReceivableRecordsCoverageName { get; private set; } = "Accounts Receivable Records";

        /// <summary>
        /// Gets or sets Accounts Receivable Records Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal AccountsReceivableRecordsRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Accounts Receivable Records 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal AccountsReceivableRecords360Deductible { get; set; }

        #endregion

        #region Step 9 -  Appurtenant Structures

        /// <summary>
        /// Gets or sets IsAppurtenantStructuresCoverageSelected
        /// </summary>
        public bool IsAppurtenantStructuresCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Appurtenant Structures Name
        /// </summary>
        [JsonIgnore]
        public string AppurtenantStructuresCoverageName { get; private set; } = "Appurtenant Structures";

        /// <summary>
        /// Gets or sets  Appurtenant Structures Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal AppurtenantStructuresRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets  Appurtenant Structures 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal AppurtenantStructures360Deductible { get; set; }

        #endregion

        #region Step 10 -  Audio Visual and Communication Equipment

        /// <summary>
        /// Gets or sets IsAudioVisualAndCommunicationEquipmentCoverageSelected
        /// </summary>
        public bool IsAudioVisualAndCommunicationEquipmentCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Audio Visual and Communication Equipment Name
        /// </summary>
        [JsonIgnore]
        public string AudioVisualAndCommunicationEquipmentCoverageName { get; private set; } = "Audio Visual and Communication Equipment";

        /// <summary>
        /// Gets or sets  Audio Visual and Communication Equipment Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal AudioVisualAndCommunicationEquipmentRevisedLimit { get; set; }

        #endregion

        #region Step 11 - Changes in Temperature or Humidity

        /// <summary>
        /// Gets or sets IsChangesInTemperatureOrHumidityCoverageSelected
        /// </summary>
        public bool IsChangesInTemperatureOrHumidityCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Changes in Temperature or Humidity Name
        /// </summary>
        [JsonIgnore]
        public string ChangesInTemperatureOrHumidityCoverageName { get; private set; } = "Changes in Temperature or Humidity";

        /// <summary>
        /// Gets or sets Changes in Temperature or Humidity Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal ChangesInTemperatureOrHumidityRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Changes in Temperature or Humidity 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal ChangesInTemperatureOrHumidity360Deductible { get; set; }
        #endregion

        #region Step 12 - Commandeered Property

        /// <summary>
        /// Gets or sets IsCommandeeredPropertyCoverageSelected
        /// </summary>
        public bool IsCommandeeredPropertyCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Commandeered Property Name
        /// </summary>
        [JsonIgnore]
        public string CommandeeredPropertyCoverageName { get; private set; } = "Commandeered Property";

        /// <summary>
        /// Gets or sets Commandeered Property Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal CommandeeredPropertyRevisedLimit { get; set; }

        #endregion

        #region Step 13 - Computer Equipment

        /// <summary>
        /// Gets or sets IsComputerEquipmentCoverageSelected
        /// </summary>
        public bool IsComputerEquipmentCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Computer Equipment Coverage Name
        /// </summary>
        [JsonIgnore]
        public string ComputerEquipmentCoverageName { get; private set; } = "Computer Equipment";

        /// <summary>
        /// Gets or sets Computer Equipment Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal ComputerEquipmentRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Computer Equipment 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal ComputerEquipment360Deductible { get; set; }

        #endregion

        #region Step 14- Debris Removal - Your Premises

        /// <summary>
        /// Gets or sets IsDebrisRemovalYourPremisesCoverageSelected
        /// </summary>
        public bool IsDebrisRemovalYourPremisesCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Debris Removal Your Premises Coverage Name
        /// </summary>
        [JsonIgnore]
        public string DebrisRemovalYourPremisesCoverageName { get; private set; } = "Debris Removal - Your Premises";

        /// <summary>
        /// Gets or sets Debris Removal Your Premises Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal DebrisRemovalYourPremisesRevisedLimit { get; set; }

        #endregion

        #region Step 15 - Debris Removal -   Wind Blown Debris

        /// <summary>
        /// Gets or sets IsDebrisRemovalWindBlownDebrisCoverageSelected
        /// </summary>
        public bool IsDebrisRemovalWindBlownDebrisCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Debris Removal Wind Blown Debris Coverage Name
        /// </summary>
        [JsonIgnore]
        public string DebrisRemovalWindBlownDebrisCoverageName { get; private set; } = "Debris Removal - Wind Blown Debris";

        /// <summary>
        /// Gets or sets Debris Removal Wind Blown Debris Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal DebrisRemovalWindBlownDebrisRevisedLimit { get; set; }

        #endregion

        #region Step 16 - Electronic Data

        /// <summary>
        /// Gets or sets IsElectronicDataCoverageSelected
        /// </summary>
        public bool IsElectronicDataCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Electronic Data Coverage Name
        /// </summary>
        [JsonIgnore]
        public string ElectronicDataCoverageName { get; private set; } = "Electronic Data";

        /// <summary>
        /// Gets or sets Electronic Data Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal ElectronicDataRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Electronic Data 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal ElectronicData360Deductible { get; set; }

        #endregion

        #region Step 17 -Fine Arts

        /// <summary>
        /// Gets or sets IsFineArtsCoverageSelected
        /// </summary>
        public bool IsFineArtsCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Fine Arts Coverage Name
        /// </summary>
        [JsonIgnore]
        public string FineArtsCoverageName { get; private set; } = "Fine Arts";

        /// <summary>
        /// Gets or sets FineArts Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal FineArtsRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets FineArts 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal FineArts360Deductible { get; set; }

        #endregion

        #region Step 18 -Fire Department Service Charge

        /// <summary>
        /// Gets or sets IsFireDepartmentServiceChargeCoverageSelected
        /// </summary>
        public bool IsFireDepartmentServiceChargeCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Fire Department Service Charge Coverage Name
        /// </summary>
        [JsonIgnore]
        public string FireDepartmentServiceChargeCoverageName { get; private set; } = "Fire Department Service Charge";

        /// <summary>
        /// Gets or sets FireDepartment ServiceCharge Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal FireDepartmentServiceChargeRevisedLimit { get; set; }

        #endregion

        #region Step 19 - Fungus, Wet Rot, Dry Rot and Bacteria

        /// <summary>
        /// Gets or sets IsFungusWetRotDryRotAndBacteriaCoverageSelected
        /// </summary>
        public bool IsFungusWetRotDryRotAndBacteriaCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Fungus, Wet Rot, Dry Rot and Bacteria Coverage Name
        /// </summary>
        [JsonIgnore]
        public string FungusWetRotDryRotAndBacteriaCoverageName { get; private set; } = "Fungus, Wet Rot, Dry Rot, and Bacteria";

        /// <summary>
        /// Gets or sets Fungus, Wet Rot, Dry Rot and Bacteria Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal FungusWetRotDryRotAndBacteriaRevisedLimit { get; set; }

        #endregion

        #region Step 20 - Glass Display or Trophy Cases

        /// <summary>
        /// Gets or sets IsFungusWetRotDryRotAndBacteriaCoverageSelected
        /// </summary>
        public bool IsGlassDisplayOrTrophyCasesCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Glass Display Or Trophy Cases Coverage Name
        /// </summary>
        [JsonIgnore]
        public string GlassDisplayOrTrophyCasesCoverageName { get; private set; } = "Glass Display or Trophy Cases";

        /// <summary>
        /// Gets or sets Glass Display Or Trophy Cases Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal GlassDisplayOrTrophyCasesRevisedLimit { get; set; }

        #endregion

        #region Step 21 - Inventory and Appraisal

        /// <summary>
        /// Gets or sets IsInventoryAndAppraisalCoverageSelected
        /// </summary>
        public bool IsInventoryAndAppraisalCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Inventory and Appraisal Coverage Name
        /// </summary>
        [JsonIgnore]
        public string InventoryAndAppraisalCoverageName { get; private set; } = "Inventory and Appraisal";

        /// <summary>
        /// Gets or sets Inventory and Appraisal Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal InventoryAndAppraisalRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Inventory and Appraisal 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal InventoryAndAppraisal360Deductible { get; set; }

        #endregion

        #region Step 22 - Key/Card

        /// <summary>
        /// Gets or sets IsKeyCardCoverageSelected
        /// </summary>
        public bool IsKeyCardCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets KeyCard Coverage Name
        /// </summary>
        [JsonIgnore]
        public string KeyCardCoverageName { get; private set; } = "Key/Card";

        /// <summary>
        /// Gets or sets KeyCard Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal KeyCardRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets KeyCard 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal KeyCard360Deductible { get; set; }

        #endregion

        #region Step 23 - Lock Replacement

        /// <summary>
        /// Gets or sets IsLockReplacementCoverageSelected
        /// </summary>
        public bool IsLockReplacementCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Lock Replacement Coverage Name
        /// </summary>
        [JsonIgnore]
        public string LockReplacementCoverageName { get; private set; } = "Lock Replacement";

        /// <summary>
        /// Gets or sets Lock Replacement Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal LockReplacementRevisedLimit { get; set; }

        #endregion

        #region Step 24 - Money and Securities -On Your Premises

        /// <summary>
        /// Gets or sets IsMoneyAndSecuritiesOnYourPremisesCoverageSelected
        /// </summary>
        public bool IsMoneyAndSecuritiesOnYourPremisesCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Money and Securities On Your Premises Coverage Name
        /// </summary>
        [JsonIgnore]
        public string MoneyAndSecuritiesOnYourPremisesCoverageName { get; private set; } = "Money and Securities – On Your Premises";

        /// <summary>
        /// Gets or sets Money and Securities On Your Premises Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal MoneyAndSecuritiesOnYourPremisesRevisedLimit { get; set; }

        #endregion

        #region Step 25 - Money and Securities - Away From Your Premises

        /// <summary>
        /// Gets or sets IsMoneyAndSecuritiesAwayFromYourPremisesCoverageSelected
        /// </summary>
        public bool IsMoneyAndSecuritiesAwayFromYourPremisesCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Money and Securities Away From Your Premises Coverage Name
        /// </summary>
        [JsonIgnore]
        public string MoneyAndSecuritiesAwayFromYourPremisesCoverageName { get; private set; } = "Money and Securities – Away from Your Premises";

        /// <summary>
        /// Gets or sets Money and Securities Away From Your Premises Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit { get; set; }

        #endregion

        #region Step 26 - Newly Acquired or Constructed Property -Buildings

        /// <summary>
        /// Gets or sets IsNewlyAcquiredOrConstructedPropertyBuildingsCoverageSelected
        /// </summary>
        public bool IsNewlyAcquiredOrConstructedPropertyBuildingsCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired Or Constructed Property Buildings Coverage Name
        /// </summary>
        [JsonIgnore]
        public string NewlyAcquiredOrConstructedPropertyBuildingsCoverageName { get; private set; } = "Newly Acquired or Constructed Property – Buildings";

        /// <summary>
        /// Gets or sets Newly Acquired Or Constructed Property Buildings Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired Or Constructed Property Buildings 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyBuildings360Deductible { get; set; }

        #endregion

        #region Step 27 - Newly Acquired or Constructed Property Your Business Personal Property

        /// <summary>
        /// Gets or sets IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageSelected
        /// </summary>
        public bool IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Your Business Personal Property Coverage Name
        /// </summary>
        [JsonIgnore]
        public string NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageName { get; private set; } = "Newly Acquired or Constructed Property – Your Business Personal Property";

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Your Business Personal Property Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Your Business Personal Property 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyYourBusinessPersonalProperty360Deductible { get; set; }

        #endregion

        #region Step 28 - Non-owned Detached Trailers

        /// <summary>
        /// Gets or sets IsNonOwnedDetachedTrailersCoverageSelected
        /// </summary>
        public bool IsNonOwnedDetachedTrailersCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Non owned Detached Trailers Coverage Name
        /// </summary>
        [JsonIgnore]
        public string NonOwnedDetachedTrailersCoverageName { get; private set; } = "Non-Owned Detached Trailers";

        /// <summary>
        /// Gets or sets Non owned Detached Trailers Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal NonOwnedDetachedTrailersRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Non owned Detached Trailers 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal NonOwnedDetachedTrailers360Deductible { get; set; }

        #endregion

        #region Step 29 - Off Premises Utility Failure - Damage to Covered Property

        /// <summary>
        /// Gets or sets IsOffPremisesUtilityFailureDamageToCoveredPropertyCoverageSelected
        /// </summary>
        public bool IsOffPremisesUtilityFailureDamageToCoveredPropertyCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets OffPremises Utility FailureDamage ToCovered Property Coverage Name
        /// </summary>
        [JsonIgnore]
        public string OffPremisesUtilityFailureDamageToCoveredPropertyCoverageName { get; private set; } = "Off-Premises Utility Failure – Damage to Covered Property";

        /// <summary>
        /// Gets or sets OffPremises Utility FailureDamage ToCovered Property RevisedLimit
        /// </summary>                                                                                                                                                                                                          
        public decimal OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets OffPremises Utility FailureDamage ToCovered Property 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal OffPremisesUtilityFailureDamageToCoveredProperty360Deductible { get; set; }

        #endregion

        #region Step 30 - Outdoor Property

        /// <summary>
        /// Gets or sets IsOutdoorPropertyCoverageSelected
        /// </summary>
        public bool IsOutdoorPropertyCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Outdoor Property Coverage Name
        /// </summary>
        [JsonIgnore]
        public string OutdoorPropertyCoverageName { get; private set; } = "Outdoor Property";

        /// <summary>
        /// Gets or sets Outdoor Property Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal OutdoorPropertyRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Outdoor Property 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal OutdoorProperty360Deductible { get; set; }

        #endregion

        #region Step 31 - Personal Effects and Property of Others

        /// <summary>
        /// Gets or sets IsPersonalEffectsAndPropertyOfOthersCoverageSelected
        /// </summary>
        public bool IsPersonalEffectsAndPropertyOfOthersCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Coverage Name
        /// </summary>
        [JsonIgnore]
        public string PersonalEffectsAndPropertyOfOthersCoverageName { get; private set; } = "Personal Effects and Property of Others";

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal PersonalEffectsAndPropertyOfOthersRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal PersonalEffectsAndPropertyOfOthers360Deductible { get; set; }

        #endregion

        #region Step 32 - Personal Effects and Property of Others - Any Employee or Volunteer
        /// <summary>
        /// Gets or sets IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageSelected
        /// </summary>
        public bool IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Any Employee or Volunteer Coverage Name
        /// </summary>
        [JsonIgnore]
        public string PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageName { get; private set; } = "Personal Effects and Property of Others - Any Employee or Volunteer";

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Any Employee or Volunteer Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Any Employee or Volunteer 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteer360Deductible { get; set; }

        #endregion

        #region Step 33 - 360 Modification Pollutant Clean Up and Removal

        /// <summary>
        /// Gets or sets Is360ModificationPollutantCleanUpAndRemovalCoverageSelected
        /// </summary>
        public bool IsModificationPollutantCleanUpAndRemovalCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Modification Pollutant Clean Up and Removal Coverage Name
        /// </summary>
        [JsonIgnore]
        public string ModificationPollutantCleanUpAndRemovalCoverageName { get; private set; } = "Pollutant Clean Up and Removal";

        /// <summary>
        /// Gets or sets Modification Pollutant Clean Up and Removal Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal ModificationPollutantCleanUpAndRemovalRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Modification Pollutant Clean Up and Removal 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal ModificationPollutantCleanUpAndRemoval360Deductible { get; set; }

        #endregion

        #region Step 34 - Property In Transit

        /// <summary>
        /// Gets or sets IsPropertyInTransitCoverageSelected
        /// </summary>
        public bool IsPropertyInTransitCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Property In Transit Coverage Name
        /// </summary>
        [JsonIgnore]
        public string PropertyInTransitCoverageName { get; private set; } = "Property in Transit";

        /// <summary>
        /// Gets or sets Property In Transit Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal PropertyInTransitRevisedLimit { get; set; }

        #endregion

        #region Step 35 - Property Off-premises

        /// <summary>
        /// Gets or sets IsPropertyOffPremisesCoverageSelected
        /// </summary>
        public bool IsPropertyOffPremisesCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Property Off premises Coverage Name
        /// </summary>
        [JsonIgnore]
        public string PropertyOffPremisesCoverageName { get; private set; } = "Property Off-Premises";

        /// <summary>
        /// Gets or sets Property Off premises Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal PropertyOffPremisesRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Property Off premises 360 Deductible
        /// </summary>                                                                                                                                                                                                          
        public decimal PropertyOffPremises360Deductible { get; set; }

        #endregion

        #region Step 36 - Recharge of Fire Protection Equipment

        /// <summary>
        /// Gets or sets IsRechargeOfFireProtectionEquipmentCoverageSelected
        /// </summary>
        public bool IsRechargeOfFireProtectionEquipmentCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Recharge of Fire Protection Equipment Coverage Name
        /// </summary>
        [JsonIgnore]
        public string RechargeOfFireProtectionEquipmentCoverageName { get; private set; } = "Recharge of Fire Protection Equipment";

        /// <summary>
        /// Gets or sets Recharge of Fire Protection Equipment Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal RechargeOfFireProtectionEquipmentRevisedLimit { get; set; }

        #endregion

        #region Step 37 - Retaining Walls

        /// <summary>
        /// Gets or sets IsRetainingWallsCoverageSelected
        /// </summary>
        public bool IsRetainingWallsCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Retaining Walls Coverage Name
        /// </summary>
        [JsonIgnore]
        public string RetainingWallsCoverageName { get; private set; } = "Retaining Walls";

        /// <summary>
        /// Gets or sets Retaining Walls Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal RetainingWallsRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Retaining Walls 360 Deductible 
        /// </summary>                                                                                                                                                                                                          
        public decimal RetainingWalls360Deductible { get; set; }

        #endregion

        #region Step 38 - Reward Payments

        /// <summary>
        /// Gets or sets IsRewardPaymentsCoverageSelected
        /// </summary>
        public bool IsRewardPaymentsCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Reward Payments Coverage Name
        /// </summary>
        [JsonIgnore]
        public string RewardPaymentsCoverageName { get; private set; } = "Reward Payments";

        /// <summary>
        /// Gets or sets Reward Payments Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal RewardPaymentsRevisedLimit { get; set; }

        #endregion

        #region Step 39 - Salesperson’s Samples

        /// <summary>
        /// Gets or sets IsSalespersonsSamplesCoverageSelected
        /// </summary>
        public bool IsSalespersonsSamplesCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Sales persons Samples Coverage Name
        /// </summary>
        [JsonIgnore]
        public string SalespersonsSamplesCoverageName { get; private set; } = "Salesperson's Samples";

        /// <summary>
        /// Gets or sets Salespersons Samples Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal SalespersonsSamplesRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Salespersons Samples 360 Deductible 
        /// </summary>                                                                                                                                                                                                          
        public decimal SalespersonsSamples360Deductible { get; set; }

        #endregion

        #region Step 40 -SCADA Upgrade

        /// <summary>
        /// Gets or sets IsSCADAUpgradeCoverageSelected
        /// </summary>
        public bool IsSCADAUpgradeCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets SCADA Upgrade Coverage Name
        /// </summary>
        [JsonIgnore]
        public string SCADAUpgradeCoverageName { get; private set; } = "SCADA Upgrade";

        /// <summary>
        /// Gets or sets SCADA Upgrade Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal SCADAUpgradeRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets SCADA Upgrade 360 Deductible 
        /// </summary>                                                                                                                                                                                                          
        public decimal SCADAUpgrade360Deductible { get; set; }

        #endregion

        #region Step 41- Sod, Trees, Shrubs, and Plants - Any One

        /// <summary>
        /// Gets or sets IsSodTreesShrubsAndPlantsAnyOneCoverageSelected
        /// </summary>
        public bool IsSodTreesShrubsAndPlantsAnyOneCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs and Plants Any One Coverage Name
        /// </summary>
        [JsonIgnore]
        public string SodTreesShrubsAndPlantsAnyOneCoverageName { get; private set; } = "Sod, Trees, Shrubs, and Plants - Any One";

        /// <summary>
        /// Gets or sets Sod Trees Shrubs and Plants Any One Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal SodTreesShrubsAndPlantsAnyOneRevisedLimit { get; set; }

        #endregion

        #region Step 42  Sod, Trees, Shrubs, and Plants Occurrence

        /// <summary>
        /// Gets or sets IsSodTreesShrubsAndPlantsOccurrenceCoverageSelected
        /// </summary>
        public bool IsSodTreesShrubsAndPlantsOccurrenceCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs And Plants Occurrence Coverage Name
        /// </summary>
        [JsonIgnore]
        public string SodTreesShrubsAndPlantsOccurrenceCoverageName { get; private set; } = "Sod, Trees, Shrubs, and Plants - Occurrence";

        /// <summary>
        /// Gets or sets Sod Trees Shrubs And Plants Occurrence Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal SodTreesShrubsAndPlantsOccurrenceRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs And Plants Occurrence 360 Deductible 
        /// </summary>                                                                                                                                                                                                          
        public decimal SodTreesShrubsAndPlantsOccurrence360Deductible { get; set; }

        #endregion

        #region Step 43 - Spoilage

        /// <summary>
        /// Gets or sets IsSpoilageCoverageSelected
        /// </summary>
        public bool IsSpoilageCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Spoilage Coverage Name
        /// </summary>
        [JsonIgnore]
        public string SpoilageCoverageName { get; private set; } = "Spoilage";

        /// <summary>
        /// Gets or sets Spoilage Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal SpoilageRevisedLimit { get; set; }

        public decimal SpoilageDeductible { get; set; }

        #endregion

        #region Step 44 - Theft of Jewelry, Furs, Stamps, and Other Specified Items – Occurrence Limit

        /// <summary>
        /// Gets or sets IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageSelected
        /// </summary>
        public bool IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Theft of Jewelry Furs Stamps And Other Specified Items Occurrence Limit Coverage Name
        /// </summary>
        [JsonIgnore]
        public string TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageName { get; private set; } = "Theft of Jewelry, Furs, Stamps, and Other Specified Items – Occurrence Limit";

        /// <summary>
        /// Gets or sets Theft of Jewelry Furs Stamps And Other Specified Items Occurrence Limit Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit { get; set; }

        #endregion

        #region Step 45 - Undamaged Leasehold Improvements

        /// <summary>
        /// Gets or sets IsUndamagedLeaseholdImprovementsCoverageSelected
        /// </summary>
        public bool IsUndamagedLeaseholdImprovementsCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets UndamagedLeaseholdImprovements Coverage Name
        /// </summary>
        [JsonIgnore]
        public string UndamagedLeaseholdImprovementsCoverageName { get; private set; } = "Undamaged Leasehold Improvements";

        /// <summary>
        /// Gets or sets UndamagedLeaseholdImprovements Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal UndamagedLeaseholdImprovementsRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets UndamagedLeaseholdImprovements 360 Deductible 
        /// </summary>                                                                                                                                                                                                          
        public decimal UndamagedLeaseholdImprovements360Deductible { get; set; }

        #endregion

        #region Step 46 - Valuable Papers and Records Other than Electronic Data

        /// <summary>
        /// Gets or sets IsUndamagedLeaseholdImprovementsCoverageSelected
        /// </summary>
        public bool IsValuablePapersAndRecordsOtherThanElectronicDataCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets Valuable Papers And Records Other Than ElectronicData Coverage Name
        /// </summary>
        [JsonIgnore]
        public string ValuablePapersAndRecordsOtherThanElectronicDataCoverageName { get; private set; } = "Valuable Papers and Records Other than Electronic Data";

        /// <summary>
        /// Gets or sets ValuablePapersAndRecordsOtherThanElectronicData Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets ValuablePapersAndRecordsOtherThanElectronicData 360 Deductible 
        /// </summary>                                                                                                                                                                                                          
        public decimal ValuablePapersAndRecordsOtherThanElectronicData360Deductible { get; set; }

        #endregion

        #endregion 360 Coverage Modifications	

        #region Golf Courses

        #region Step 47 -Golf Courses - Tee to Green

        /// <summary>
        /// Gets or sets IsGolfCoursesTeeToGreenCoverageSelected
        /// </summary>
        public bool IsGolfCoursesTeeToGreenCoverageSelected { get; set; }

        /// <summary>
        /// GolfCoursesTeeToGreenName : Name of coverage.
        /// </summary>
        [JsonIgnore]
        public string GolfCoursesTeeToGreenName { get; private set; } = "Golf Courses - Tee to Green";

        /// <summary>
        /// Gets or sets Golf Courses Tee to Green Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesTeeToGreenRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Tee To Green Deductible
        /// </summary>
        public decimal GolfCoursesTeeToGreen360Deductible { get; set; }

        #endregion

        #region Step 48 - Golf Courses Sprinkler and Underground Wiring

        /// <summary>
        /// Gets or sets IsGolfCoursesSprinklerAndUndergroundWiringCoverageSelected
        /// </summary>
        public bool IsGolfCoursesSprinklerAndUndergroundWiringCoverageSelected { get; set; }

        /// <summary>
        /// GolfCoursesSprinklerAndUndergroundWiringName : Name of coverage.
        /// </summary>
        [JsonIgnore]
        public string GolfCoursesSprinklerAndUndergroundWiringName { get; private set; } = "Golf Courses - Sprinkler and Underground Wiring";

        /// <summary>
        /// Gets or sets Golf Courses Sprinkler and Underground Wiring Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesSprinklerAndUndergroundWiringRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses sprinkler and underground wiring deductible
        /// </summary>
        public decimal GolfCoursesSprinklerAndUndergroundWiring360Deductible { get; set; }

        #endregion

        #region Step 49 - Golf Courses -Additional Golf Course Property

        /// <summary>
        /// Gets or sets IsGolfCoursesAdditionalGolfCoursePropertyCoverageSelected
        /// </summary>
        public bool IsGolfCoursesAdditionalGolfCoursePropertyCoverageSelected { get; set; }

        /// <summary>
        /// GolfCoursesAdditionalGolfCoursePropertyName : Name of coverage.
        /// </summary>
        [JsonIgnore]
        public string GolfCoursesAdditionalGolfCoursePropertyName { get; private set; } = "Golf Courses - Additonal Golf Course Property";

        /// <summary>
        /// Gets or sets Golf Courses Additional Golf Course Property Revised Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesAdditionalGolfCoursePropertyRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses additional golf course property deductible
        /// </summary>
        public decimal GolfCoursesAdditionalGolfCourseProperty360Deductible { get; set; }

        #endregion

        #endregion

        #region Optional Coverage	

       public Property360OptionalCoverageInputViewModel Property360OptionalCoverageInputModel { get; set; }
        
        #endregion                
    }
}
