﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Property.Input
{
    public class Property360OptionalCoverageInputViewModel
    {
        public Property360OptionalCoverageInputViewModel()
        {
            VacancyPermitsInputModel = new List<Property360OptionalVacancyPermitInputViewModel>();
            VehiclePhysicalDamagesInputModel = new List<Property360OptionalVehiclePhysicalDamageInputViewModel>();
            LossOfMunicipalTaxRevenuesInputModel = new List<Property360OptionalLossOfMunicipalTaxRevenueInputViewModel>();
        }

        #region Builders Risk
        public bool IsBuildersRiskCoverageSelected { get; set; }
        public decimal BuildersRiskLimit { get; set; }
        public int BuildersRiskLocation { get; set; }
        public int BuildersRiskBuilding { get; set; }
        public string BuildersRiskLocationDescription { get; set; }

        #endregion

        #region Forest Fire Expense

        public bool IsForestFireExpenseInAnyOne72HourPeriodCoverageSelected { get; set; }
        public decimal ForestFireExpenseInAnyOne72HourPeriod { get; set; }

        public bool IsForestFireExpenseInAnyOnePolicyPeriodCoverageSelected { get; set; }
        public decimal ForestFireExpenseInAnyOnePolicyPeriod { get; set; }

        #endregion

        #region Historic Property Valuation
        public bool IsHistoricPropertyValuationCoverageSelected { get; set; }
        public decimal HistoricPropertyValuationLimit { get; set; }
        public int HistoricPropertyValuationLocation { get; set; }
        public int HistoricPropertyValuationBuilding { get; set; }
        public string HistoricPropertyValuationLocationDescription { get; set; }

        #endregion

        #region Underground Property On Premise Excess
        public bool IsUndergroundPropertyOnPremiseExcessCoverageSelected { get; set; }
        public decimal UndergroundPropertyOnPremiseExcessLimit { get; set; }
        public int UndergroundPropertyOnPremiseExcessLocation { get; set; }
        public int UndergroundPropertyOnPremiseExcessBuilding { get; set; }
        public string UndergroundPropertyOnPremiseExcessLocationDescription { get; set; }

        #endregion

        #region Underground Property Off Premise Excess
        public bool IsUndergroundPropertyOffPremiseExcessCoverageSelected { get; set; }
        public decimal UndergroundPropertyOffPremiseExcessLimit { get; set; }
        #endregion

        public List<Property360OptionalVacancyPermitInputViewModel> VacancyPermitsInputModel { get; set; }

        public List<Property360OptionalVehiclePhysicalDamageInputViewModel> VehiclePhysicalDamagesInputModel { get; set; }

        public List<Property360OptionalLossOfMunicipalTaxRevenueInputViewModel> LossOfMunicipalTaxRevenuesInputModel { get; set; }
    }

    public class Property360OptionalVacancyPermitInputViewModel
    {
        public bool IsVacancyPermitCoverageSelected { get; set; }
        public decimal VacancyPermitLimit { get; set; }
        public decimal VacancyPermitDeductible { get; set; }
        public int VacancyPermitLocation { get; set; }
        public int VacancyPermitBuilding { get; set; }
        public string VacancyPermitLocationDescription { get; set; }
    }

    public class Property360OptionalVehiclePhysicalDamageInputViewModel
    {
        public bool IsVehiclePhysicalDamageCoverageSelected { get; set; }
        public decimal VehiclePhysicalDamageLimit { get; set; }
        public int VehiclePhysicalDamageLocation { get; set; }
        public int VehiclePhysicalDamageBuilding { get; set; }
        public string VehiclePhysicalDamageLocationDescription { get; set; }
    }

    public class Property360OptionalLossOfMunicipalTaxRevenueInputViewModel
    {
        /// <summary>
        /// Get or sets Id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets IsLossOfMunicipalTaxRevenueCoverageSelected
        /// </summary>
        public bool IsLossOfMunicipalTaxRevenueCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets LossOfMunicipalTaxRevenueName
        /// </summary>                                                                                                                                                                                                          
        [JsonIgnore]
        public string LossOfMunicipalTaxRevenueName { get; private set; } = "Loss of Municipal Tax Revenue";

        /// <summary>
        /// Gets or sets Loss of Municipal Tax Revenue Limit
        /// </summary>                                                                                                                                                                                                          
        public decimal LossOfMunicipalTaxRevenueRevisedLimit { get; set; }

        /// <summary>
        /// Gets or sets Loss of Municipal Tax Deductible
        /// </summary>
        public decimal LossOfMunicipalTaxRevenue360Deductible { get; set; }
    }
}
