﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace Models.ViewModels.LineOfBusiness.Property.Input
{
    public class PropertyInputViewModel
    {
        public PropertyInputViewModel()
        {

        }

        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "PR";
        public decimal BuildingTIV { get; set; }
        public decimal ContentTIV { get; set; }        

        #region Terms

        public decimal AOPDeductible { get; set; }
        public string Coinsurance { get; set; }
        public string Blanket { get; set; }
        public string MarginClause { get; set; }
        public string Valuation { get; set; }

        #endregion

        #region Large Risk & Loss Rate
        public decimal LargeRiskFactor { get; set; }
        public decimal SumNetNormalLossClaims { get; set; }
        public decimal TIVExpPeriod1stYear { get; set; }
        public decimal TIVExpPeriod2ndYear { get; set; }
        public decimal TIVExpPeriod3rdYear { get; set; }
        public decimal OtherModFactor { get; set; }
        #endregion

        #region Equipment Breakdown & Other Perils

        #region Equipment Breakdown
        public bool EquipmentBreakdownCoverage { get; set; }
        public decimal EquipmentBreakdownDeductible { get; set; }
        public decimal EquipmentBreakdownRate { get; set; }
        public decimal IRPM { get; set; }
        #endregion

        #region Referred 
        public bool ReferredEquipmentBreakdownCoverage { get; set; }

        /// <summary>
        /// InputEquipmentBreakdownTotalPremium: Used in Referred Equipment Breakdown coverage calculation
        /// </summary>
        public decimal InputEquipmentBreakdownTotalPremium { get; set; }   // Used in Referred Equipment Breakdown coverage calculation
        #endregion

        #region BusinessIncome and ExtraExpense
        public decimal BusinessIncomeAndExtraExpenseLimit { get; set; }
        public decimal BusinessIncomeAndExtraExpenseDeductible { get; set; }
        #endregion

        #region Pollutant Cleanup
        public decimal PollutantCleanUpLimit { get; set; }
        #endregion

        #region Refrigerant Contamination

        public decimal RefrigerantContaminationLimit { get; set; }
        #endregion

        #region Spoilage
        public string SelectedSpoilageType { get; set; }
        public decimal EBSpoilageLimit { get; set; }
        public decimal SpoilageDeductible { get; set; }
        public decimal SpoilageMinimumDeductible { get; set; }
        #endregion        

        #region Windstorm and Hail
        public bool WindstormAndHailCoverage { get; set; }
        public decimal WindstormAndHailDeductible { get; set; }
        public string WindstormAndHailSubjectToMinimumDeductible { get; set; }
        public decimal WindstormAndHailSubjectToMinimumDeductibleOther { get; set; }
        #endregion

        #region Flood
        public bool FloodCoverage { get; set; }
        public decimal FloodLimit { get; set; }
        public decimal FloodDeductible { get; set; }
        #endregion

        #region Earth quake
        public bool EarthquakeCoverage { get; set; }
        public decimal EarthquakeLimit { get; set; }
        public decimal EarthquakeDeductible { get; set; }
        public string EarthquakeSubjectToMinimumDeductible { get; set; }
        public decimal EarthquakeSubjectToMinimumDeductibleOther { get; set; }
        #endregion

        #endregion

        // Add following field in the JSON file. These are applicable for states=AL, CO, DE, IL, IN, MA, MI, MN, NC, SC, TX, UT, VT, WY  
        #region Hazards Points

        #region Disaster Exposure
        public decimal DisasterExposureBuildingPoints { get; set; }
        public decimal DisasterExposureContentPoints { get; set; }
        public string DisasterExposureJustification { get; set; }

        public decimal DisasterExposureDispersionBuildingPoints { get; set; }
        public decimal DisasterExposureDispersionContentPoints { get; set; }
        public string DisasterExposureDispersionJustification { get; set; }
        public decimal DisasterExposurePMLBuildingPoints { get; set; }
        public decimal DisasterExposurePMLContentPoints { get; set; }
        public string DisasterExposurePMLJustification { get; set; }
        #endregion

        #region Climatical Hazards
        public decimal ClimaticalHazardsHurricaneBuildingPoints { get; set; }
        public decimal ClimaticalHazardsHurricaneContentPoints { get; set; }
        public string ClimaticalHazardsHurricaneJustification { get; set; }
        public decimal ClimaticalHazardsSevereConvectiveBuildingPoints { get; set; }
        public decimal ClimaticalHazardsSevereConvectiveContentPoints { get; set; }
        public string ClimaticalHazardsSevereConvectiveJustification { get; set; }
        public decimal ClimaticalHazardsWinterStormBuildingPoints { get; set; }
        public decimal ClimaticalHazardsWinterStormContentPoints { get; set; }
        public string ClimaticalHazardsWinterStormJustification { get; set; }
        public decimal ClimaticalHazardsAllOtherBuildingPoints { get; set; }
        public decimal ClimaticalHazardsAllOtherContentPoints { get; set; }
        public string ClimaticalHazardsAllOtherJustification { get; set; }
        #endregion

        #region Occupancy Hazards
        public decimal OccupancyHazardsBuildingPoints { get; set; }
        public decimal OccupancyHazardsContentPoints { get; set; }
        public string OccupancyHazardsJustification { get; set; }
        #endregion

        #region Lack of Private Protection
        public decimal LackofPrivateProtectionBuildingPoints { get; set; }
        public decimal LackofPrivateProtectionContentPoints { get; set; }
        public string LackofPrivateProtectionJustification { get; set; }
        #endregion

        #region Amended Limit or Add'l Coverage
        public decimal AmendedLimitorAddCoverageBuildingPoints { get; set; }
        public decimal AmendedLimitorAddCoverageContentPoints { get; set; }
        public string AmendedLimitorAddCoverageJustification { get; set; }
        #endregion

        #region Inadequate Public Protection

        public decimal InadequatePublicProtectionBuildingPoints { get; set; }
        public decimal InadequatePublicProtectionContentPoints { get; set; }
        public string InadequatePublicProtectionJustification { get; set; }

        #endregion

        #region Extra External Exposure

        public decimal ExtraExternalExposureBuildingPoints { get; set; }
        public decimal ExtraExternalExposureContentPoints { get; set; }
        public string ExtraExternalExposureJustification { get; set; }
        #endregion

        #region Deficiency Construction

        public decimal DeficiencyConstructionBuildingPoints { get; set; }
        public decimal DeficiencyConstructionContentPoints { get; set; }
        public string DeficiencyConstructionJustification { get; set; }
        #endregion

        #region  Unusual Combustion

        public decimal UnusualCombustionBuildingPoints { get; set; }
        public decimal UnusualCombustionContentPoints { get; set; }
        public string UnusualCombustionJustification { get; set; }
        #endregion

        #region Flood Exposure
        public decimal FloodExposureBuildingPoints { get; set; }
        public decimal FloodExposureContentPoints { get; set; }
        public string FloodExposureJustification { get; set; }
        #endregion

        #region Earthquake Exposure

        public decimal EarthquakeExposureBuildingPoints { get; set; }
        public decimal EarthquakeExposureContentPoints { get; set; }
        public string EarthquakeExposureJustification { get; set; }

        #endregion

        #region Excluded or Reduced Coverage
        public decimal ExcludedorReducedCoverageBuildingPoints { get; set; }
        public decimal ExcludedorReducedCoverageContentPoints { get; set; }
        public string ExcludedorReducedCoverageJustification { get; set; }

        #endregion
        // Add following field in the JSON file. These are applicable for states= CT, GA, KS, ME, MS, MO, NH, OH, PA 

        #region  Special Occupancy

        public decimal SpecialOccupancyHazardsBuildingPoints { get; set; }
        public decimal SpecialOccupancyHazardsContentPoints { get; set; }
        public string SpecialOccupancyHazardsJustification { get; set; }
        public decimal SpecialOccupancyProcessingBuildingPoints { get; set; }
        public decimal SpecialOccupancyProcessingContentPoints { get; set; }
        public string SpecialOccupancyProcessingJustification { get; set; }
        public decimal SpecialOccupancyBusinessIncomePMLBuildingPoints { get; set; }
        public decimal SpecialOccupancyBusinessIncomePMLContentPoints { get; set; }
        public string SpecialOccupancyBusinessIncomePMLJustification { get; set; }
        public decimal SpecialOccupancyNumberofOccupantsBuildingPoints { get; set; }
        public decimal SpecialOccupancyNumberofOccupantsContentPoints { get; set; }
        public string SpecialOccupancyNumberofOccupantsJustification { get; set; }
        #endregion

        #region Private Protection

        public decimal PrivateProtectionFireSuppressionBuildingPoints { get; set; }
        public decimal PrivateProtectionFireSuppressionContentPoints { get; set; }
        public string PrivateProtectionFireSuppressionJustification { get; set; }
        public decimal PrivateProtectionFireProtectionBuildingPoints { get; set; }
        public decimal PrivateProtectionFireProtectionContentPoints { get; set; }
        public string PrivateProtectionFireProtectionJustification { get; set; }
        public decimal PrivateProtectionCentralMonitoringBuildingPoints { get; set; }
        public decimal PrivateProtectionCentralMonitoringContentPoints { get; set; }
        public string PrivateProtectionCentralMonitoringJustification { get; set; }
        #endregion

        #region Specific Insurance

        public decimal SpecificInsuranceBuildingPoints { get; set; }
        public decimal SpecificInsuranceContentPoints { get; set; }
        public string SpecificInsuranceJustification { get; set; }
        #endregion

        #region Public Protection

        public decimal PublicProtectionLowHazardBuildingPoints { get; set; }
        public decimal PublicProtectionLowHazardContentPoints { get; set; }
        public string PublicProtectionLowHazardJustification { get; set; }
        public decimal PublicProtectionMediumHazardBuildingPoints { get; set; }
        public decimal PublicProtectionMediumHazardContentPoints { get; set; }
        public string PublicProtectionMediumHazardJustification { get; set; }
        public decimal PublicProtectionHighHazardBuildingPoints { get; set; }
        public decimal PublicProtectionHighHazardContentPoints { get; set; }
        public string PublicProtectionHighHazardJustification { get; set; }
        #endregion

        #region External Exposure

        public decimal ExternalExposureBuildingPoints { get; set; }
        public decimal ExternalExposureContentPoints { get; set; }
        public string ExternalExposureJustification { get; set; }
        public decimal ExternalExposureSeparationBuildingPoints { get; set; }
        public decimal ExternalExposureSeparationContentPoints { get; set; }
        public string ExternalExposureSeparationJustification { get; set; }
        #endregion

        #region Construction

        public decimal ConstructionBuildingPoints { get; set; }
        public decimal ConstructionContentPoints { get; set; }
        public string ConstructionJustification { get; set; }
        public decimal ConstructionEngineeringBuildingPoints { get; set; }
        public decimal ConstructionEngineeringContentPoints { get; set; }
        public string ConstructionEngineeringJustification { get; set; }
        public decimal ConstructionAttractionValueBuildingPoints { get; set; }
        public decimal ConstructionAttractionValueContentPoints { get; set; }
        public string ConstructionAttractionValueJustification { get; set; }
        #endregion

        #region Commodities
        public decimal CommoditiesBuildingPoints { get; set; }
        public decimal CommoditiesContentPoints { get; set; }
        public string CommoditiesJustification { get; set; }
        #endregion

        #region Flood
        public decimal FloodCoveredZoneBuildingPoints1 { get; set; }
        public decimal FloodCoveredZoneContentPoints1 { get; set; }
        public string FloodCoveredZoneJustification1 { get; set; }
        public decimal FloodCoveredZoneBuildingPoints2 { get; set; }
        public decimal FloodCoveredZoneContentPoints2 { get; set; }
        public string FloodCoveredZoneJustification2 { get; set; }
        public decimal FloodCoveredZoneBuildingPoints3 { get; set; }
        public decimal FloodCoveredZoneContentPoints3 { get; set; }
        public string FloodCoveredZoneJustification3 { get; set; }
        public decimal FloodCoveredZoneBuildingPoints4 { get; set; }
        public decimal FloodCoveredZoneContentPoints4 { get; set; }
        public string FloodCoveredZoneJustification4 { get; set; }
        public decimal FloodCoveredZoneBuildingPoints5 { get; set; }
        public decimal FloodCoveredZoneContentPoints5 { get; set; }
        public string FloodCoveredZoneJustification5 { get; set; }
        #endregion

        #region Earth Movement
        public decimal EarthMovementTerritoryBuildingPoints1 { get; set; }
        public decimal EarthMovementTerritoryContentPoints1 { get; set; }
        public string EarthMovementTerritoryJustification1 { get; set; }
        public decimal EarthMovementTerritoryBuildingPoints2 { get; set; }
        public decimal EarthMovementTerritoryContentPoints2 { get; set; }
        public string EarthMovementTerritoryJustification2 { get; set; }
        public decimal EarthMovementLimitBuildingPoints { get; set; }
        public decimal EarthMovementLimitContentPoints { get; set; }
        public string EarthMovementLimitJustification { get; set; }
        #endregion

        #region Exclusion or Reduction of Coverage
        public decimal ExclusionorReductionofCoverageBuildingPoints { get; set; }
        public decimal ExclusionorReductionofCoverageContentPoints { get; set; }
        public string ExclusionorReductionofCoverageJustification { get; set; }
        #endregion
        #endregion

        /// <summary>
        /// PropertyStateSpecificInputViewModel : Contains state specific property.
        /// </summary>
        public PropertyStateSpecificInputViewModel PropertyStateSpecificInputModel { get; set; }

        #region Optional Coverage
        public PropertyOptionalCoverageInputViewModel PropertyOptionalCoveragesModel { get; set; }
        #endregion

        #region Property 360
        public Property360InputViewModel Property360InputModel { get; set; }
        #endregion

        /// <summary>
        /// Gets or sets ScheduleRatingInputViewModels.
        /// </summary>
        public PropertyScheduleRatingInputViewModel ScheduleRatingInputModels { get; set; }
    }
}
