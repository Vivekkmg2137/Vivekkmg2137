﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ViewModels.LineOfBusiness.Property.Input
{
    public class PropertyNewYork360InputViewModel
    {

        #region Accounts Receivable Records	

        /// <summary>
        /// Gets or sets IsAccountsReceivableRecordsCoverageSelected
        /// </summary>
        public bool IsAccountsReceivableRecordsCoverageSelected { get; set; }

        [JsonIgnore]
        public string AccountsReceivableRecordsCoverageName { get; private set; } = "Accounts Receivable";
        public decimal AccountsReceivableRecordsRevisedLimit { get; set; }

        #endregion

        #region Building OrdinanceORLaw - Demolition Cost Coverage 

        /// <summary>
        /// Gets or sets IsAccountsReceivableRecordsCoverageSelected
        /// </summary>
        public bool IsBuildingOrdinanceORLawDemolitionCostCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets BuildingOrdinanceORLawDemolitionCostCoverageName
        /// </summary>
        [JsonIgnore]
        public string BuildingOrdinanceORLawDemolitionCostCoverageName { get; private set; } = "Building Ordinance or Law - Demolition Cost Coverage";

        /// <summary>
        /// Gets or sets BuildingOrdinanceORLawDemolitionCostRevisedLimit
        /// </summary>
        public decimal BuildingOrdinanceORLawDemolitionCostRevisedLimit { get; set; }

        #endregion

        #region Building OrdinanceORLaw - Increased Cost of Construction Coverage	

        /// <summary>
        /// Gets or sets IsBuildingOrdinanceORLawIncreasedCostOfContructionCoverageSelected
        /// </summary>
        public bool IsBuildingOrdinanceORLawIncreasedCostOfContructionCoverageSelected { get; set; }

        [JsonIgnore]
        public string BuildingOrdinanceORLawIncreasedCostOfContructionCoverageName { get; private set; } = "Building Ordinance or Law - Increased Cost of Construction";
        public decimal BuildingOrdinanceORLawIncreasedCostOfContructionRevisedLimit { get; set; }

        #endregion

        #region Changes in TemperatureORHumidity 

        /// <summary>
        /// Gets or sets IsChangesInTemperatureORHumidityCoverageSelected
        /// </summary>
        public bool IsChangesInTemperatureORHumidityCoverageSelected { get; set; }

        [JsonIgnore]
        public string ChangesInTemperatureORHumidityCoverageName { get; private set; } = "Changes in Temperature or Humidity";
        public decimal ChangesInTemperatureORHumidityRevisedLimit { get; set; }

        #endregion

        #region Commandeered Property  

        /// <summary>
        /// Gets or sets IsCommandeeredPropertyCoverageSelected
        /// </summary>
        public bool IsCommandeeredPropertyCoverageSelected { get; set; }

        [JsonIgnore]
        public string CommandeeredPropertyCoverageName { get; private set; } = "Commandeered Property";
        public decimal CommandeeredPropertyRevisedLimit { get; set; }

        #endregion

        #region Communication Equipment Coverage  

        /// <summary>
        /// Gets or sets IsCommandeeredPropertyCoverageSelected
        /// </summary>
        public bool IsCommunicationEquipmentCoverageSelected { get; set; }

        [JsonIgnore]
        public string CommunicationEquipmentCoverageName { get; private set; } = "Communication Equipment";
        public decimal CommunicationEquipmentRevisedLimit { get; set; }

        #endregion

        #region Computer Equipment Coverage  

        /// <summary>
        /// Gets or sets IsComputerEquipmentCoverageSelected
        /// </summary>
        public bool IsComputerEquipmentCoverageSelected { get; set; }

        [JsonIgnore]
        public string ComputerEquipmentCoverageName { get; private set; } = "Computer Equipment";
        public decimal ComputerEquipmentRevisedLimit { get; set; }

        #endregion

        #region Detached Signs Coverage	

        /// <summary>
        /// Gets or sets IsDetachedSignsCoverageSelected
        /// </summary>
        public bool IsDetachedSignsCoverageSelected { get; set; }

        [JsonIgnore]
        public string DetachedSignsCoverageName { get; private set; } = "Detached Signs";
        public decimal DetachedSignsRevisedLimit { get; set; }

        #endregion

        #region Electrical Damage Coverage

        /// <summary>
        /// Gets or sets IsElectricalDamageCoverageSelected
        /// </summary>
        public bool IsElectricalDamageCoverageSelected { get; set; }

        [JsonIgnore]
        public string ElectricalDamageCoverageName { get; private set; } = "Electrical Damage";
        public decimal ElectricalDamageRevisedLimit { get; set; }

        #endregion

        #region Extra Expense and Business Income Coverage

        /// <summary>
        /// Gets or sets IsExtraExpenseAndBusinessIncomeCoverageSelected
        /// </summary>
        public bool IsExtraExpenseAndBusinessIncomeCoverageSelected { get; set; }

        [JsonIgnore]
        public string ExtraExpenseAndBusinessIncomeCoverageName { get; private set; } = "Extra Expense and Business Income";
        public decimal ExtraExpenseAndBusinessIncomeRevisedLimit { get; set; }

        #endregion

        #region Fairs, Exhibitions, ExpositionsORTrade Shows Coverage

        /// <summary>
        /// Gets or sets IsFairsExhibitionsExpositionsORTradeShowsCoverageSelected
        /// </summary>
        public bool IsFairsExhibitionsExpositionsORTradeShowsCoverageSelected { get; set; }

        [JsonIgnore]
        public string FairsExhibitionsExpositionsORTradeShowsCoverageName { get; private set; } = "Fairs, Exhibitions, Expositions or Trade Shows";
        public decimal FairsExhibitionsExpositionsORTradeShowsRevisedLimit { get; set; }

        #endregion

        #region Fine Arts Coverage	 

        /// <summary>
        /// Gets or sets IsFineartsCoverageSelected
        /// </summary>
        public bool IsFineartsCoverageSelected { get; set; }

        [JsonIgnore]
        public string FineartsCoverageName { get; private set; } = "Fine Arts";
        public decimal FineartsRevisedLimit { get; set; }

        #endregion

        #region Fire Department Service Charge Coverage	

        /// <summary>
        /// Gets or sets IsFireDepartmentServiceChargeCoverageSelected
        /// </summary>
        public bool IsFireDepartmentServiceChargeCoverageSelected { get; set; }

        [JsonIgnore]
        public string FireDepartmentServiceChargeCoverageName { get; private set; } = "Fire Department Service Charge";
        public decimal FireDepartmentServiceChargeRevisedLimit { get; set; }

        #endregion

        #region  Flagpoles Coverage	

        /// <summary>
        /// Gets or sets IsFlagpolesCoverageSelected
        /// </summary>
        public bool IsFlagpolesCoverageSelected { get; set; }

        [JsonIgnore]
        public string FlagpolesCoverageName { get; private set; } = "Flagpoles";
        public decimal FlagpolesRevisedLimit { get; set; }

        #endregion

        #region Glass DisplayORTrophy Cases Coverage

        /// <summary>
        /// Gets or sets IsGlassDisplayORTrophyCasesCoverageSelected
        /// </summary>
        public bool IsGlassDisplayORTrophyCasesCoverageSelected { get; set; }

        [JsonIgnore]
        public string GlassDisplayORTrophyCasesCoverageName { get; private set; } = "Glass Display or Trophy Cases";
        public decimal GlassDisplayORTrophyCasesRevisedLimit { get; set; }

        #endregion

        #region Grounds, Maintenance Equipment Coverage

        /// <summary>
        /// Gets or sets IsGroundsMaintenanceEquipmentCoverageSelected
        /// </summary>
        public bool IsGroundsMaintenanceEquipmentCoverageSelected { get; set; }

        [JsonIgnore]
        public string GroundsMaintenanceEquipmentCoverageName { get; private set; } = "Grounds, Maintenance Equipment";
        public decimal GroundsMaintenanceEquipmentRevisedLimit { get; set; }

        #endregion

        #region Lock Replacement Coverage

        /// <summary>
        /// Gets or sets IsLockReplacementCoverageSelected
        /// </summary>
        public bool IsLockReplacementCoverageSelected { get; set; }

        [JsonIgnore]
        public string LockReplacementCoverageName { get; private set; } = "Lock Replacement";
        public decimal LockReplacementRevisedLimit { get; set; }

        #endregion

        #region Money, Securities and Stamps - Inside Premise Coverage

        /// <summary>
        /// Gets or sets IsMoneySecuritiesAndStampsInsidePremiseCoverageSelected
        /// </summary>
        public bool IsMoneySecuritiesAndStampsInsidePremiseCoverageSelected { get; set; }

        [JsonIgnore]
        public string MoneySecuritiesAndStampsInsidePremiseCoverageName { get; private set; } = "Money, Securities and Stamps - Inside Premise";
        public decimal MoneySecuritiesAndStampsInsidePremiseRevisedLimit { get; set; }

        #endregion

        #region Money, Securities and Stamps - Outside Premise Coverage	

        /// <summary>
        /// Gets or sets IsMoneySecuritiesAndStampsOutsidePremiseCoverageSelected
        /// </summary>
        public bool IsMoneySecuritiesAndStampsOutsidePremiseCoverageSelected { get; set; }

        [JsonIgnore]
        public string MoneySecuritiesAndStampsOutsidePremiseCoverageName { get; private set; } = "Money, Securities and Stamps - Outside Premise";
        public decimal MoneySecuritiesAndStampsOutsidePremiseRevisedLimit { get; set; }

        #endregion

        #region Newly AcquiredORConstructed Property - Building Coverage
        /// <summary>
        /// Gets or sets IsNewlyAcquiredORConstructedPropertyBuildingCoverageSelected
        /// </summary>
        public bool IsNewlyAcquiredORConstructedPropertyBuildingCoverageSelected { get; set; }

        [JsonIgnore]
        public string NewlyAcquiredORConstructedPropertyBuildingCoverageName { get; private set; } = "Newly Acquired or Constructed Property - Building";
        public decimal NewlyAcquiredORConstructedPropertyBuildingRevisedLimit { get; set; }

        #endregion

        #region Newly AcquiredORConstructed Property - Personal Property Coverage

        /// <summary>
        /// Gets or sets IsNewlyAcquiredORConstructedPropertyPersonalPropertyCoverageSelected
        /// </summary>
        public bool IsNewlyAcquiredORConstructedPropertyPersonalPropertyCoverageSelected { get; set; }

        [JsonIgnore]
        public string NewlyAcquiredORConstructedPropertyPersonalPropertyCoverageName { get; private set; } = "Newly Acquired or Constructed Property - Personal Property";
        public decimal NewlyAcquiredORConstructedPropertyPersonalPropertyRevisedLimit { get; set; }

        #endregion

        #region Off Premises Utility Failure Coverage

        /// <summary>
        /// Gets or sets IsOffPremisesUtilityFailureCoverageSelected
        /// </summary>
        public bool IsOffPremisesUtilityFailureCoverageSelected { get; set; }

        [JsonIgnore]
        public string OffPremisesUtilityFailureCoverageName { get; private set; } = "Off Premises Utility Failure";
        public decimal OffPremisesUtilityFailureRevisedLimit { get; set; }

        #endregion

        #region Outdoor Property - Any one tree, shrubORplant Coverage

        /// <summary>
        /// Gets or sets IsOutdoorPropertyAnyOneTreeShrubORplantCoverageSelected
        /// </summary>
        public bool IsOutdoorPropertyAnyOneTreeShrubORplantCoverageSelected { get; set; }

        [JsonIgnore]
        public string OutdoorPropertyAnyOneTreeShrubORplantCoverageName { get; set; } = "Outdoor Property - Any one tree, shrub or plant";
        public decimal OutdoorPropertyAnyOneTreeShrubORplantRevisedLimit { get; set; }

        #endregion

        #region Outdoor Property - Total limit Coverage

        /// <summary>
        /// Gets or sets IsOutdoorPropertyTotalLimitCoverageSelected
        /// </summary>
        public bool IsOutdoorPropertyTotalLimitCoverageSelected { get; set; }

        [JsonIgnore]
        public string OutdoorPropertyTotalLimitCoverageName { get; set; } = "Outdoor Property - Total limit";
        public decimal OutdoorPropertyTotalLimitRevisedLimit { get; set; }

        #endregion

        #region Personal Effects and Property of Others - Any one employeeORvolunteer Coverage

        /// <summary>
        /// Gets or sets IsPersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerCoverageSelected
        /// </summary>
        public bool IsPersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerCoverageSelected { get; set; }

        [JsonIgnore]
        public string PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerCoverageName { get; private set; } = "Personal Effects and Property of Others - Any one employee or volunteer";
        public decimal PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRevisedLimit { get; set; }

        #endregion

        #region Personal Effects and Property of Others - Any one occurrence Coverage

        /// <summary>
        /// Gets or sets IsPersonalEffectsAndPropertyOfOthersAnyOneOccurrenceCoverageSelected
        /// </summary>
        public bool IsPersonalEffectsAndPropertyOfOthersAnyOneOccurrenceCoverageSelected { get; set; }


        [JsonIgnore]
        public string PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceCoverageName { get; private set; } = "Personal Effects and Property of Others - Any one occurrence";
        public decimal PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRevisedLimit { get; set; }

        #endregion

        #region Pollutant Clean Up and Removal Coverage

        /// <summary>
        /// Gets or sets IsPollutantCleanUpAndRemovalCoverageSelected
        /// </summary>
        public bool IsPollutantCleanUpAndRemovalCoverageSelected { get; set; }

        [JsonIgnore]
        public string PollutantCleanUpAndRemovalCoverageName { get; private set; } = "Pollutant Clean Up and Removal";
        public decimal PollutantCleanUpAndRemovalRevisedLimit { get; set; }

        #endregion

        #region Property in Transit Coverage

        /// <summary>
        /// Gets or sets IsPropertyInTransitCoverageSelected
        /// </summary>
        public bool IsPropertyInTransitCoverageSelected { get; set; }

        [JsonIgnore]
        public string PropertyInTransitCoverageName { get; private set; } = "Property in Transit";
        public decimal PropertyInTransitRevisedLimit { get; set; }

        #endregion

        #region Property Off-Premises Coverage

        /// <summary>
        /// Gets or sets IsPropertyOffPremisesCoverageSelected
        /// </summary>
        public bool IsPropertyOffPremisesCoverageSelected { get; set; }

        [JsonIgnore]
        public string PropertyOffPremisesCoverageName { get; private set; } = "Property Off-Premises";
        public decimal PropertyOffPremisesRevisedLimit { get; set; }

        #endregion

        #region Spoilage Coverage

        /// <summary>
        /// Gets or sets IsSpoilageCoverageCoverageSelected
        /// </summary>
        public bool IsSpoilageCoverageSelected { get; set; }

        [JsonIgnore]
        public string SpoilageCoverageCoverageName { get; set; } = "Spoilage";
        public decimal SpoilageCoverageRevisedLimit { get; set; }

        #endregion

        #region Valuable Papers and Records Coverage

        /// <summary>
        /// Gets or sets IsValuablePapersAndRecordsCoverageSelected
        /// </summary>
        public bool IsValuablePapersAndRecordsCoverageSelected { get; set; }

        [JsonIgnore]
        public string ValuablePapersAndRecordsCoverageName { get; private set; } = "Valuable Papers and Records";
        public decimal ValuablePapersAndRecordsRevisedLimit { get; set; }

        #endregion

        #region Extra Expense and Tuition & Fees Coverage
        /// <summary>
        /// Gets or sets IsExtraExpenseAndTuitionFeesCoverageSelected
        /// </summary>
        public bool IsExtraExpenseAndTuitionFeesCoverageSelected { get; set; }

        [JsonIgnore]
        public string ExtraExpenseAndTuitionFeesCoverageName { get; private set; } = "Extra Expense and Tuition & Fees";
        public decimal ExtraExpenseAndTuitionFeesRevisedLimit { get; set; }

        #endregion

        #region Valuable Papers	

        /// <summary>
        /// Gets or sets IsValuablePapersCoverageSelected
        /// </summary>
        public bool IsValuablePapersCoverageSelected { get; set; }

        [JsonIgnore]
        public string ValuablePapersCoverageName { get; private set; } = "Valuable Papers";
        public decimal ValuablePapersRevisedLimit { get; set; }

        #endregion

        #region Musical Instruments and Band Uniforms Coverage

        /// <summary>
        /// Gets or sets IsMusicalInstrumentsAndBandUniformsCoverageSelected
        /// </summary>
        public bool IsMusicalInstrumentsAndBandUniformsCoverageSelected { get; set; }

        [JsonIgnore]
        public string MusicalInstrumentsAndBandUniformsCoverageName { get; private set; } = "Musical Instruments and Band Uniforms";
        public decimal MusicalInstrumentsAndBandUniformsRevisedLimit { get; set; }

        #endregion

        #region Personal Property of EmployeesORVolunteers - Any one employeeORvolunteer 

        /// <summary>
        /// Gets or sets IsPersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerCoverageSelected
        /// </summary>
        public bool IsPersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerCoverageSelected { get; set; }

        [JsonIgnore]
        public string PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerCoverageName { get; private set; } = "Personal Property of Employees or Volunteers - Any one employee or volunteer";
        public decimal PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRevisedLimit { get; set; }

        #endregion

        #region Personal Property of EmployeesORVolunteers - Any one occurrence

        /// <summary>
        /// Gets or sets IsPersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceCoverageSelected
        /// </summary>
        public bool IsPersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceCoverageSelected { get; set; }

        [JsonIgnore]
        public string PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceCoverageName { get; private set; } = "Personal Property of Employees or Volunteers - Any one occurrence";
        public decimal PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRevisedLimit { get; set; }

        #endregion
    }
}
