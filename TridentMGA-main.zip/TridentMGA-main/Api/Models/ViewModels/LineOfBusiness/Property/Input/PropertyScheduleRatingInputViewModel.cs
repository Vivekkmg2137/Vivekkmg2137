﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.Property.Input
{
    public class PropertyScheduleRatingInputViewModel
    {
        public List<BuildingScheduleInputViewModel> buildingScheduleInputModels { get; set; }        
    }
}
