﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Property.Output
{
    public class Property360OptionalCoverageOutputViewModel
    {
        public List<Property360OptionalLossOfMunicipalTaxRevenueOutputViewModel> LossOfMunicipalTaxRevenuesOutputModel { get; set; }
    }

    public class Property360OptionalLossOfMunicipalTaxRevenueOutputViewModel
    {
        /// <summary>
        /// Get or sets Id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets Loss of Municipal Tax Revenue Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal LossOfMunicipalTaxRevenueRate { get; set; }

        /// <summary>
        /// Gets or sets Loss of Municipal Tax AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal LossOfMunicipalTaxRevenueAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Loss of Municipal Tax 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal LossOfMunicipalTaxRevenue360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Loss of Municipal Tax Revenue Premium
        /// </summary>   
        public decimal LossOfMunicipalTaxRevenuePremium { get; set; }
    }
}
