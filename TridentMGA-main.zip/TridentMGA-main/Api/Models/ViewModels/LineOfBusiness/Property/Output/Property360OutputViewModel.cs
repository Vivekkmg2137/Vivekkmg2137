﻿using Api.Models.ViewModels.LineOfBusiness.Property.Output;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.Property.Output
{
    public class Property360OutputViewModel
    {

        /// <summary>
        /// Gets or sets Business Income and Extra Expense Rate
        /// </summary>
        public decimal BusinessIncomeAndExtraExpenseRate { get; set; }

        #region Business Income & Extra Expense Coverages

        #region Step 1 - Business Income & Extra Expense Coverages

        /// <summary>
        /// Gets or sets Business Income and Extra Expense Deductible Factor
        /// </summary>
        public decimal BusinessIncomeAndExtraExpenseDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Business Income and Extra Expense Days Factor
        /// </summary>
        public decimal BusinessIncomeAndExtraExpenseDaysFactor { get; set; }

        /// <summary>
        /// Gets or sets Business Income And Extra Expense Base Limit
        /// </summary>
        public decimal BusinessIncomeAndExtraExpenseBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Business Income And Extra Expense Premium
        /// </summary>
        public decimal BusinessIncomeAndExtraExpensePremium { get; set; }

        #endregion

        #region  Step 2 - Dependent Property Business Income	        

        /// <summary>
        /// Gets or sets Dependent Property Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal DependentPropertyDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Base Limit
        /// </summary>   
        public decimal DependentPropertyBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Dependent Property Premium
        /// </summary>   
        public decimal DependentPropertyPremium { get; set; }
        #endregion

        #region Step 3 -Interruption of Computer Operations        

        /// <summary>
        /// Gets or sets Interruption Of ComputerOperations Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal InterruptionOfComputerOperationsDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Interruption Of ComputerOperations Base Limit
        /// </summary>   
        public decimal InterruptionOfComputerOperationsBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Interruption Of ComputerOperations  Premium
        /// </summary>   
        public decimal InterruptionOfComputerOperationsPremium { get; set; }
        #endregion

        #region Step 4 - Lease Cancellation Moving Expenses        

        /// <summary>
        /// Gets or sets Lease Cancellation Moving Expenses  Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal LeaseCancellationMovingExpensesDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Lease Cancellation Moving Expenses Base Limit
        /// </summary>   
        public decimal LeaseCancellationMovingExpensesBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Lease Cancellation Moving Expenses  Premium
        /// </summary>   
        public decimal LeaseCancellationMovingExpensesPremium { get; set; }

        #endregion

        #region Step 5 - Newly Acquired or Constructed Property  – Business Income        

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Base Limit
        /// </summary>   
        public decimal NewlyAcquiredOrConstructedPropertyBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property  Premium
        /// </summary>   
        public decimal NewlyAcquiredOrConstructedPropertyPremium { get; set; }

        #endregion

        #region Step 6 - Off Premises Utility Failure - Business Income and Extra Expense       

        /// <summary>
        /// Gets or sets Off Premises Utility Failure Business Income and Extra Expense Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Off Premises Utility Failure Business Income and Extra Expense Base Limit
        /// </summary>   
        public decimal OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Off Premises Utility Failure Business Income and Extra Expense Premium
        /// </summary>   
        public decimal OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium { get; set; }
        #endregion

        #endregion

        #region 360 Coverage Modifications							

        #region Step 7 - Ordinance or Law Coverage

        #region Coverage A
       
        #endregion

        #region Coverage B
        
        /// <summary>
        /// Gets or sets Ordinance or Law CoverageB Base Limit
        /// </summary> 
        public decimal OrdinanceOrLawCoverageBBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Ordinance or Law CoverageB Premium
        /// </summary>  
        public decimal OrdinanceOrLawCoverageBPremium { get; set; }
        #endregion

        #region Coverage c
        
        /// <summary>
        /// Gets or sets Ordinance or Law Coverages Base Limit
        /// </summary> 
        public decimal OrdinanceOrLawCoverageCBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Ordinance or Law Coverages Premium
        /// </summary>  
        public decimal OrdinanceOrLawCoverageCPremium { get; set; }
        #endregion

        #endregion

        #region Step 8 - Accounts Receivable Records        

        /// <summary>
        /// Gets or sets Accounts Receivable Records AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal AccountsReceivableRecordsAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Accounts Receivable Records 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal AccountsReceivableRecords360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Accounts Receivable Records Base Limit
        /// </summary>   
        public decimal AccountsReceivableRecordsBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property  Premium
        /// </summary>   
        public decimal AccountsReceivableRecordsPremium { get; set; }
        #endregion

        #region Step 9 -  Appurtenant Structures        

        /// <summary>
        /// Gets or sets  Appurtenant Structures AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal AppurtenantStructuresAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets  Appurtenant Structures 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal AppurtenantStructures360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets  Appurtenant Structures Base Limit
        /// </summary>   
        public decimal AppurtenantStructuresBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets  Appurtenant Structures  Premium
        /// </summary>   
        public decimal AppurtenantStructuresPremium { get; set; }
        #endregion

        #region Step 10 -  Audio Visual and Communication Equipment

        /// <summary>
        /// Gets or sets Audio Visual and Communication Equipment AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal AudioVisualAndCommunicationEquipmentAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Audio Visual and Communication Equipment 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal AudioVisualAndCommunicationEquipment360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Audio Visual and Communication Equipment Base Limit
        /// </summary>   
        public decimal AudioVisualAndCommunicationEquipmentBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Audio Visual and Communication Equipment Premium
        /// </summary>   
        public decimal AudioVisualAndCommunicationEquipmentPremium { get; set; }
        #endregion

        #region Step 11 - Changes in Temperature or Humidity        

        /// <summary>
        /// Gets or sets Changes in Temperature or Humidity AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal ChangesInTemperatureOrHumidityAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Changes in Temperature or Humidity 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal ChangesInTemperatureOrHumidity360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Changes in Temperature or Humidity Base Limit
        /// </summary>   
        public decimal ChangesInTemperatureOrHumidityBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Changes in Temperature or Humidity Premium
        /// </summary>   
        public decimal ChangesInTemperatureOrHumidityPremium { get; set; }
        #endregion

        #region Step 12 - Commandeered Property        

        /// <summary>
        /// Gets or sets Commandeered Property AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal CommandeeredPropertyAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Commandeered Property 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal CommandeeredProperty360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Commandeered Property Base Limit
        /// </summary>   
        public decimal CommandeeredPropertyBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Commandeered Property Premium
        /// </summary>   
        public decimal CommandeeredPropertyPremium { get; set; }
        #endregion

        #region Step 13 - Computer Equipment

        /// <summary>
        /// Gets or sets Computer Equipment AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal ComputerEquipmentAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Computer Equipment 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal ComputerEquipment360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Computer Equipment Base Limit
        /// </summary>   
        public decimal ComputerEquipmentBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Computer Equipment Premium
        /// </summary>   
        public decimal ComputerEquipmentPremium { get; set; }
        #endregion

        #region Step 14- Debris Removal - Your Premises

        /// <summary>
        /// Gets or sets Debris Removal  Your Premises AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal DebrisRemovalYourPremisesAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Debris Removal  Your Premises 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal DebrisRemovalYourPremises360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Debris Removal  Your Premises Base Limit
        /// </summary>   
        public decimal DebrisRemovalYourPremisesBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Debris Removal  Your Premises Premium
        /// </summary>   
        public decimal DebrisRemovalYourPremisesPremium { get; set; }
        #endregion

        #region Step 15 - Debris Removal -   Wind Blown Debris

        /// <summary>
        /// Gets or sets Debris Removal Wind Blown Debris AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal DebrisRemovalWindBlownDebrisAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Debris Removal Wind Blown Debris 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal DebrisRemovalWindBlownDebris360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Debris Removal Wind Blown Debris Base Limit
        /// </summary>   
        public decimal DebrisRemovalWindBlownDebrisBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Debris Removal Wind Blown Debris Premium
        /// </summary>   
        public decimal DebrisRemovalWindBlownDebrisPremium { get; set; }
        #endregion

        #region Step 16 - Electronic Data

        /// <summary>
        /// Gets or sets Electronic Data AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal ElectronicDataAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Electronic Data 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal ElectronicData360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Electronic Data Base Limit
        /// </summary>   
        public decimal ElectronicDataBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Electronic Data Premium
        /// </summary>   
        public decimal ElectronicDataPremium { get; set; }
        #endregion

        #region Step 17 -Fine Arts

        /// <summary>
        /// Gets or sets FineArts AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal FineArtsAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets FineArts 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal FineArts360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets FineArts Base Limit
        /// </summary>   
        public decimal FineArtsBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets FineArts Premium
        /// </summary>   
        public decimal FineArtsPremium { get; set; }
        #endregion

        #region Step 18 -Fire Department Service Charge

        /// <summary>
        /// Gets or sets FireDepartment ServiceCharge AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal FireDepartmentServiceChargeAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets FireDepartment ServiceCharge 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal FireDepartmentServiceCharge360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets FireDepartment ServiceCharge Base Limit
        /// </summary>   
        public decimal FireDepartmentServiceChargeBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets FireDepartment ServiceCharge Premium
        /// </summary>   
        public decimal FireDepartmentServiceChargePremium { get; set; }
        #endregion

        #region Step 19 - Fungus, Wet Rot, Dry Rot and Bacteria

        /// <summary>
        /// Gets or sets Fungus, Wet Rot, Dry Rot and Bacteria AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal FungusWetRotDryRotAndBacteriaAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Fungus, Wet Rot, Dry Rot and Bacteria 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal FungusWetRotDryRotAndBacteria360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Fungus, Wet Rot, Dry Rot and Bacteria Base Limit
        /// </summary>   
        public decimal FungusWetRotDryRotAndBacteriaBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Fungus, Wet Rot, Dry Rot and Bacteria Premium
        /// </summary>   
        public decimal FungusWetRotDryRotAndBacteriaPremium { get; set; }
        #endregion

        #region Step 20 - Glass Display or Trophy Cases

        /// <summary>
        /// Gets or sets Glass Display Or Trophy Cases AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal GlassDisplayOrTrophyCasesAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Glass Display Or Trophy Cases 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal GlassDisplayOrTrophyCases360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Glass Display Or Trophy Cases Base Limit
        /// </summary>   
        public decimal GlassDisplayOrTrophyCasesBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Glass Display Or Trophy Cases Premium
        /// </summary>   
        public decimal GlassDisplayOrTrophyCasesPremium { get; set; }
        #endregion

        #region Step 21 - Inventory and Appraisal

        /// <summary>
        /// Gets or sets Inventory and Appraisal AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal InventoryAndAppraisalAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Inventory and Appraisal 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal InventoryAndAppraisal360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Inventory and Appraisal Base Limit
        /// </summary>   
        public decimal InventoryAndAppraisalBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Inventory and Appraisal Premium
        /// </summary>   
        public decimal InventoryAndAppraisalPremium { get; set; }
        #endregion

        #region Step 22 - Key/Card

        /// <summary>
        /// Gets or sets KeyCard AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal KeyCardAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets KeyCard 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal KeyCard360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets KeyCard Base Limit
        /// </summary>   
        public decimal KeyCardBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets KeyCard Premium
        /// </summary>   
        public decimal KeyCardPremium { get; set; }
        #endregion

        #region Step 23 - Lock Replacement

        /// <summary>
        /// Gets or sets Lock Replacement Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal LockReplacementRate { get; set; }

        /// <summary>
        /// Gets or sets Lock Replacement AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal LockReplacementAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Lock Replacement 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal LockReplacement360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Lock Replacement Base Limit
        /// </summary>   
        public decimal LockReplacementBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Lock Replacement Premium
        /// </summary>   
        public decimal LockReplacementPremium { get; set; }
        #endregion

        #region Step 24 - Money and Securities -On Your Premises

        /// <summary>
        /// Gets or sets Money and Securities On Your Premises AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal MoneyAndSecuritiesOnYourPremisesAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Money and Securities On Your Premises 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal MoneyAndSecuritiesOnYourPremises360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Money and Securities On Your Premises Base Limit
        /// </summary>   
        public decimal MoneyAndSecuritiesOnYourPremisesBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Money and Securities On Your Premises Premium
        /// </summary>   
        public decimal MoneyAndSecuritiesOnYourPremisesPremium { get; set; }
        #endregion

        #region Step 25 - Money and Securities - Away From Your Premises

        /// <summary>
        /// Gets or sets Money and Securities Away From Your Premises AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal MoneyAndSecuritiesAwayFromYourPremisesAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Money and Securities Away From Your Premises 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal MoneyAndSecuritiesAwayFromYourPremises360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Money and Securities Away From Your Premises Base Limit
        /// </summary>   
        public decimal MoneyAndSecuritiesAwayFromYourPremisesBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Money and Securities Away From Your Premises Premium
        /// </summary>   
        public decimal MoneyAndSecuritiesAwayFromYourPremisesPremium { get; set; }
        #endregion

        #region Step 26 - Newly Acquired or Constructed Property -Buildings
                
        /// <summary>
        /// Gets or sets Newly Acquired Or Constructed Property Buildings AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyBuildingsAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired Or Constructed Property Buildings 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyBuildings360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired Or Constructed Property Buildings Base Limit
        /// </summary>   
        public decimal NewlyAcquiredOrConstructedPropertyBuildingsBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired Or Constructed Property Buildings Premium
        /// </summary>   
        public decimal NewlyAcquiredOrConstructedPropertyBuildingsPremium { get; set; }
        #endregion

        #region Step 27 - Newly Acquired or Constructed Property Your Business Personal Property
                
        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Your Business Personal Property AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Your Business Personal Property 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal NewlyAcquiredOrConstructedPropertyYourBusinessPersonalProperty360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Your Business Personal Property Base Limit
        /// </summary>   
        public decimal NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Newly Acquired or Constructed Property Your Business Personal Property Premium
        /// </summary>   
        public decimal NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium { get; set; }
        #endregion

        #region Step 28 - Non-owned Detached Trailers

        /// <summary>
        /// Gets or sets Non owned Detached Trailers AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal NonOwnedDetachedTrailersAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Non owned Detached Trailers 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal NonOwnedDetachedTrailers360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Non owned Detached Trailers Base Limit
        /// </summary>   
        public decimal NonOwnedDetachedTrailersBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Non owned Detached Trailers Premium
        /// </summary>   
        public decimal NonOwnedDetachedTrailersPremium { get; set; }
        #endregion

        #region Step 29 - Off Premises Utility Failure - Damage to Covered Property

        /// <summary>
        /// Gets or sets OffPremises Utility FailureDamage ToCovered Property AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal OffPremisesUtilityFailureDamageToCoveredPropertyAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets OffPremises Utility FailureDamage ToCovered Property 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal OffPremisesUtilityFailureDamageToCoveredProperty360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets OffPremises Utility FailureDamage ToCovered Property Base Limit
        /// </summary>   
        public decimal OffPremisesUtilityFailureDamageToCoveredPropertyBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets OffPremises Utility FailureDamage ToCovered Property Premium
        /// </summary>   
        public decimal OffPremisesUtilityFailureDamageToCoveredPropertyPremium { get; set; }
        #endregion

        #region Step 30 - Outdoor Property

        /// <summary>
        /// Gets or sets Outdoor Property AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal OutdoorPropertyAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Outdoor Property 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal OutdoorProperty360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Outdoor Property Base Limit
        /// </summary>   
        public decimal OutdoorPropertyBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Outdoor Property Premium
        /// </summary>   
        public decimal OutdoorPropertyPremium { get; set; }
        #endregion

        #region Step 31 - Personal Effects and Property of Others

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PersonalEffectsAndPropertyOfOthersAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PersonalEffectsAndPropertyOfOthers360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Base Limit
        /// </summary>   
        public decimal PersonalEffectsAndPropertyOfOthersBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Premium
        /// </summary>   
        public decimal PersonalEffectsAndPropertyOfOthersPremium { get; set; }
        #endregion

        #region Step 32 - Personal Effects and Property of Others - Any Employee or Volunteer

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Any Employee or Volunteer Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRate { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Any Employee or Volunteer AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Any Employee or Volunteer 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteer360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Any Employee or Volunteer Base Limit
        /// </summary>   
        public decimal PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Personal Effects and Property of Others Any Employee or Volunteer Premium
        /// </summary>   
        public decimal PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium { get; set; }
        #endregion

        #region Step 33 - Pollutant Clean Up and Removal

        /// <summary>
        /// Gets or sets Pollutant Clean Up and Removal AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PollutantCleanUpAndRemovalAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Pollutant Clean Up and Removal 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PollutantCleanUpAndRemoval360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Pollutant Clean Up and Removal Base Limit
        /// </summary>   
        public decimal PollutantCleanUpAndRemovalBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Pollutant Clean Up and Removal Premium
        /// </summary>   
        public decimal PollutantCleanUpAndRemovalPremium { get; set; }
        #endregion

        #region Step 34 - Property In Transit

        /// <summary>
        /// Gets or sets Property In Transit AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PropertyInTransitAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Property In Transit Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal PropertyInTransitRate { get; set; }

        /// <summary>
        /// Gets or sets Property In Transit 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PropertyInTransit360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Property In Transit Base Limit
        /// </summary>   
        public decimal PropertyInTransitBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Property In Transit Premium
        /// </summary>   
        public decimal PropertyInTransitPremium { get; set; }
        #endregion

        #region Step 35 - Property Off-premises

        /// <summary>
        /// Gets or sets Property Off premises AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PropertyOffPremisesAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Property Off premises 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal PropertyOffPremises360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Property Off premises Base Limit
        /// </summary>   
        public decimal PropertyOffPremisesBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Property Off premises Premium
        /// </summary>   
        public decimal PropertyOffPremisesPremium { get; set; }
        #endregion

        #region Step 36 - Recharge of Fire Protection Equipment

        /// <summary>
        /// Gets or sets Recharge of Fire Protection Equipment AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal RechargeOfFireProtectionEquipmentAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Recharge of Fire Protection Equipment Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal RechargeOfFireProtectionEquipmentRate { get; set; }

        /// <summary>
        /// Gets or sets Recharge of Fire Protection Equipment 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal RechargeOfFireProtectionEquipment360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Recharge of Fire Protection Equipment Base Limit
        /// </summary>   
        public decimal RechargeOfFireProtectionEquipmentBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Recharge of Fire Protection Equipment Premium
        /// </summary>   
        public decimal RechargeOfFireProtectionEquipmentPremium { get; set; }
        #endregion

        #region Step 37 - Retaining Walls

        /// <summary>
        /// Gets or sets Retaining Walls AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal RetainingWallsAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Retaining Walls 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal RetainingWalls360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Retaining Walls Base Limit
        /// </summary>   
        public decimal RetainingWallsBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Retaining Walls Premium
        /// </summary>   
        public decimal RetainingWallsPremium { get; set; }
        #endregion

        #region Step 38 - Reward Payments

        /// <summary>
        /// Gets or sets Reward Payments AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal RewardPaymentsAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Reward Payments 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal RewardPayments360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Reward Payments Base Limit
        /// </summary>   
        public decimal RewardPaymentsBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Reward Payments Premium
        /// </summary>   
        public decimal RewardPaymentsPremium { get; set; }
        #endregion

        #region Step 39 - Salesperson’s Samples

        /// <summary>
        /// Gets or sets Salespersons Samples AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal SalespersonsSamplesAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Salespersons Samples 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal SalespersonsSamples360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Salespersons Samples Base Limit
        /// </summary>   
        public decimal SalespersonsSamplesBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Salespersons Samples Premium
        /// </summary>   
        public decimal SalespersonsSamplesPremium { get; set; }
        #endregion

        #region Step 40 -SCADA Upgrade

        /// <summary>
        /// Gets or sets SCADA Upgrade AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal SCADAUpgradeAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets SCADA Upgrade 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal SCADAUpgrade360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets SCADA Upgrade Base Limit
        /// </summary>   
        public decimal SCADAUpgradeBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets SCADA Upgrade Premium
        /// </summary>   
        public decimal SCADAUpgradePremium { get; set; }
        #endregion

        #region Step 41- Sod, Trees, Shrubs, and Plants - Any One
                
        /// <summary>
        /// Gets or sets Sod Trees Shrubs and Plants Any One Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal SodTreesShrubsAndPlantsAnyOneRate { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs and Plants Any One AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal SodTreesShrubsAndPlantsAnyOneAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs and Plants Any One 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal SodTreesShrubsAndPlantsAnyOne360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs and Plants Any One Base Limit
        /// </summary>   
        public decimal SodTreesShrubsAndPlantsAnyOneBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs and Plants Any One Premium
        /// </summary>   
        public decimal SodTreesShrubsAndPlantsAnyOnePremium { get; set; }
        #endregion

        #region Step 42  Sod, Trees, Shrubs, and Plants Occurrence

        /// <summary>
        /// Gets or sets Sod Trees Shrubs And Plants Occurrence AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal SodTreesShrubsAndPlantsOccurrenceAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs And Plants Occurrence 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal SodTreesShrubsAndPlantsOccurrence360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs And Plants Occurrence Base Limit
        /// </summary>   
        public decimal SodTreesShrubsAndPlantsOccurrenceBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Sod Trees Shrubs And Plants Occurrence Premium
        /// </summary>   
        public decimal SodTreesShrubsAndPlantsOccurrencePremium { get; set; }
        #endregion

        #region Step 43 - Spoilage

        /// <summary>
        /// Gets or sets Spoilage Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal SpoilageRate { get; set; }

        /// <summary>
        /// Gets or sets Spoilage Base Limit
        /// </summary>   
        public decimal SpoilageBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Spoilage Premium
        /// </summary>   
        public decimal SpoilagePremium { get; set; }
        #endregion

        #region Step 44 - Theft of Jewelry, Furs, Stamps, and Other Specified Items – Occurrence Limit

        /// <summary>
        /// Gets or sets Theft of Jewelry Furs Stamps And Other Specified Items Occurrence Limit Base Limit
        /// </summary>   
        public decimal TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitBaseLimit { get; set; }        
                
        /// <summary>
        /// Gets or sets Theft of Jewelry Furs Stamps And Other Specified Items Occurrence Limit Premium
        /// </summary>   
        public decimal TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium { get; set; }
        #endregion

        #region Step 45 - Undamaged Leasehold Improvements

        /// <summary>
        /// Gets or sets UndamagedLeaseholdImprovements AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal UndamagedLeaseholdImprovementsAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets UndamagedLeaseholdImprovements 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal UndamagedLeaseholdImprovements360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets UndamagedLeaseholdImprovements Base Limit
        /// </summary>   
        public decimal UndamagedLeaseholdImprovementsBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets UndamagedLeaseholdImprovements Premium
        /// </summary>   
        public decimal UndamagedLeaseholdImprovementsPremium { get; set; }
        #endregion

        #region Step 46 - Valuable Papers and Records Other than Electronic Data

        /// <summary>
        /// Gets or sets ValuablePapersAndRecordsOtherThanElectronicData AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal ValuablePapersAndRecordsOtherThanElectronicDataAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets ValuablePapersAndRecordsOtherThanElectronicData 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal ValuablePapersAndRecordsOtherThanElectronicData360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets ValuablePapersAndRecordsOtherThanElectronicData Base Limit
        /// </summary>   
        public decimal ValuablePapersAndRecordsOtherThanElectronicDataBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets ValuablePapersAndRecordsOtherThanElectronicData Premium
        /// </summary>   
        public decimal ValuablePapersAndRecordsOtherThanElectronicDataPremium { get; set; }
        #endregion

        #endregion 360 Coverage Modifications	

        #region Golf Courses

        #region Step 47 -Golf Courses - Tee to Green

        /// <summary>
        /// Gets or sets Golf Courses Tee to Green Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesTeeToGreenRate { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Tee to Green AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesTeeToGreenAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Tee to Green 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesTeeToGreen360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Tee to Green Base Limit
        /// </summary>   
        public decimal GolfCoursesTeeToGreenBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Tee to Green Premium
        /// </summary>   
        public decimal GolfCoursesTeeToGreenPremium { get; set; }
        #endregion

        #region Step 48 - Golf Courses Sprinkler and Underground Wiring

        /// <summary>
        /// Gets or sets Golf Courses Sprinkler and Underground Wiring Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesSprinklerAndUndergroundWiringRate { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Sprinkler and Underground Wiring AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesSprinklerAndUndergroundWiringAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Sprinkler and Underground Wiring 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesSprinklerAndUndergroundWiring360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Sprinkler and Underground Wiring Base Limit
        /// </summary>   
        public decimal GolfCoursesSprinklerAndUndergroundWiringBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Sprinkler and Underground Wiring Premium
        /// </summary>   
        public decimal GolfCoursesSprinklerAndUndergroundWiringPremium { get; set; }
        #endregion

        #region Step 49 - Golf Courses -Additional Golf Course Property

        /// <summary>
        /// Gets or sets Golf Courses Additional Golf Course Property Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesAdditionalGolfCoursePropertyRate { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Additional Golf Course Property AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesAdditionalGolfCoursePropertyAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Additional Golf Course Property 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal GolfCoursesAdditionalGolfCourseProperty360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Additional Golf Course Property Base Limit
        /// </summary>   
        public decimal GolfCoursesAdditionalGolfCoursePropertyBaseLimit { get; set; }

        /// <summary>
        /// Gets or sets Golf Courses Additional Golf Course Property Premium
        /// </summary>   
        public decimal GolfCoursesAdditionalGolfCoursePropertyPremium { get; set; }
        #endregion

        #endregion

        #region Optional Coverage	

        public Property360OptionalCoverageOutputViewModel property360OptionalCoverageOutputModel { get; set; }

        #endregion
      
    }
}
