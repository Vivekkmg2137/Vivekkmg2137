﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.Property.Output
{
    public class PropertyNewYork360OutputViewModel
    {
        #region Accounts Receivable Records	

        public decimal AccountsReceivableRecordsBaseLimit { get; set; }
        public decimal AccountsReceivableRecordsRate { get; set; }
        public decimal AccountReceivablePremium { get; set; }

        #endregion

        #region Building OrdinanceORLaw - Demolition Cost Coverage 

        public decimal BuildingOrdinanceORLawDemolitionCostBaseLimit { get; set; }
        public decimal BuildingOrdinanceORLawDemolitionCostRate { get; set; }
        public decimal BuildingOrdinanceORLawDemolitionCostCoveragePremium { get; set; }

        #endregion

        #region Building OrdinanceORLaw - Increased Cost of Construction Coverage	

        public decimal BuildingOrdinanceORLawIncreasedCostOfContructionBaseLimit { get; set; }
        public decimal BuildingOrdinanceORLawIncreasedCostOfContructionRate { get; set; }
        public decimal BuildingOrdinanceORLawIncreasedCostOfContructionPremium { get; set; }

        #endregion

        #region Changes in TemperatureORHumidity 
       
        public decimal ChangesInTemperatureORHumidityBaseLimit { get; set; }
        public decimal ChangesInTemperatureORHumidityRate { get; set; }
        public decimal ChangesInTemperatureORHumidityPremium { get; set; }

        #endregion

        #region Commandeered Property  
        
        public decimal CommandeeredPropertyBaseLimit { get; set; }
        public decimal CommandeeredPropertyRate { get; set; }
        public decimal CommandeeredPropertyPremium { get; set; }

        #endregion

        #region Communication Equipment Coverage  
        
        public decimal CommunicationEquipmentBaseLimit { get; set; }
        public decimal CommunicationEquipmentRate { get; set; }
        public decimal CommunicationEquipmentPremium { get; set; }

        #endregion

        #region Computer Equipment Coverage  
       
        public decimal ComputerEquipmentBaseLimit { get; set; }
        public decimal ComputerEquipmentRate { get; set; }
        public decimal ComputerEquipmentPremium { get; set; }

        #endregion

        #region Detached Signs Coverage	
       
        public decimal DetachedSignsBaseLimit { get; set; }
        public decimal DetachedSignsRate { get; set; }
        public decimal DetachedSignsPremium { get; set; }

        #endregion

        #region Electrical Damage Coverage
        
        public decimal ElectricalDamageBaseLimit { get; set; }
        public decimal ElectricalDamageRate { get; set; }
        public decimal ElectricalDamagePremium { get; set; }

        #endregion

        #region Extra Expense and Business Income Coverage
        
        public decimal ExtraExpenseAndBusinessIncomeBaseLimit { get; set; }
        public decimal ExtraExpenseAndBusinessIncomeRate { get; set; }
        public decimal ExtraExpenseAndBusinessIncomePremium { get; set; }

        #endregion

        #region Fairs, Exhibitions, ExpositionsORTrade Shows Coverage
       
        public decimal FairsExhibitionsExpositionsORTradeShowsBaseLimit { get; set; }
        public decimal FairsExhibitionsExpositionsORTradeShowsRate { get; set; }
        public decimal FairsExhibitionsExpositionsORTradeShowsPremium { get; set; }

        #endregion

        #region Fine Arts Coverage	 
       
        public decimal FineartsBaseLimit { get; set; }
        public decimal FineartsRate { get; set; }
        public decimal FineartsPremium { get; set; }

        #endregion

        #region Fire Department Service Charge Coverage	
       
        public decimal FireDepartmentServiceChargeBaseLimit { get; set; }
        public decimal FireDepartmentServiceChargeRate { get; set; }
        public decimal FireDepartmentServiceChargePremium { get; set; }

        #endregion

        #region  Flagpoles Coverage	  
        
        public decimal FlagpolesBaseLimit { get; set; }
        public decimal FlagpolesRate { get; set; }
        public decimal FlagpolesPremium { get; set; }

        #endregion

        #region Glass DisplayORTrophy Cases Coverage
        
        public decimal GlassDisplayORTrophyCasesBaseLimit  { get; set; }
        public decimal GlassDisplayORTrophyCasesRate { get; set; }
        public decimal GlassDisplayORTrophyCasesPremium { get; set; }

        #endregion

        #region Grounds, Maintenance Equipment Coverage
        
        public decimal GroundsMaintenanceEquipmentBaseLimit { get; set; }
        public decimal GroundsMaintenanceEquipmentRate { get; set; }
        public decimal GroundsMaintenanceEquipmentPremium { get; set; }

        #endregion

        #region Lock Replacement Coverage
       
        public decimal LockReplacementBaseLimit { get; set; }
        public decimal LockReplacementRate { get; set; }
        public decimal LockReplacementPremium { get; set; }

        #endregion

        #region Money, Securities and Stamps - Inside Premise Coverage
        
        public decimal MoneySecuritiesAndStampsInsidePremiseBaseLimit { get; set; }
        public decimal MoneySecuritiesAndStampsInsidePremiseRate { get; set; }
        public decimal MoneySecuritiesAndStampsInsidePremisePremium { get; set; }

        #endregion

        #region Money, Securities and Stamps - Outside Premise Coverage	
       
        public decimal MoneySecuritiesAndStampsOutsidePremiseBaseLimit { get; set; }
        public decimal MoneySecuritiesAndStampsOutsidePremiseRate { get; set; }
        public decimal MoneySecuritiesAndStampsOutsidePremisePremium { get; set; }

        #endregion

        #region Newly AcquiredORConstructed Property - Building Coverage
       
        public decimal NewlyAcquiredORConstructedPropertyBuildingBaseLimit { get; set; }
        public decimal NewlyAcquiredORConstructedPropertyBuildingRate { get; set; }
        public decimal NewlyAcquiredORConstructedPropertyBuildingPremium { get; set; }

        #endregion

        #region Newly AcquiredORConstructed Property - Personal Property Coverage
       
        public decimal NewlyAcquiredORConstructedPropertyPersonalPropertyBaseLimit { get; set; }
        public decimal NewlyAcquiredORConstructedPropertyPersonalPropertyRate { get; set; }
        public decimal NewlyAcquiredORConstructedPropertyPersonalPropertyPremium { get; set; }

        #endregion

        #region Off Premises Utility Failure Coverage
       
        public decimal OffPremisesUtilityFailureBaseLimit { get; set; }
        public decimal OffPremisesUtilityFailureRate { get; set; }
        public decimal OffPremisesUtilityFailurePremium { get; set; }

        #endregion

        #region Outdoor Property - Any one tree, shrubORplant Coverage
       
        public decimal OutdoorPropertyAnyOneTreeShrubORplantBaseLimit { get; set; }
        public decimal OutdoorPropertyAnyOneTreeShrubORplantRate { get; set; }
        public decimal OutdoorPropertyAnyOneTreeShrubORplantPremium { get; set; }

        #endregion

        #region Outdoor Property - Total limit Coverage
        
        public decimal OutdoorPropertyTotalLimitBaseLimit { get; set; }
        public decimal OutdoorPropertyTotalLimitRate { get; set; }
        public decimal OutdoorPropertyTotalLimitPremium { get; set; }

        #endregion

        #region Personal Effects and Property of Others - Any one employeeORvolunteer Coverage
       
        public decimal PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerBaseLimit { get; set; }
        public decimal PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRate { get; set; }
        public decimal PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerPremium { get; set; }

        #endregion

        #region Personal Effects and Property of Others - Any one occurrence Coverage
       
        public decimal PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceBaseLimit { get; set; }
        public decimal PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRate { get; set; }
        public decimal PersonalEffectsAndPropertyOfOthersAnyOneOccurrencePremium { get; set; }

        #endregion

        #region Pollutant Clean Up and Removal Coverage
       
        public decimal PollutantCleanUpAndRemovalBaseLimit { get; set; }
        public decimal PollutantCleanUpAndRemovalRate { get; set; }
        public decimal PollutantCleanUpAndRemovalPremium { get; set; }
        #endregion

        #region Property in Transit Coverage
       
        public decimal PropertyInTransitBaseLimit { get; set; }
        public decimal PropertyInTransitRate { get; set; }
        public decimal PropertyInTransitPremium { get; set; }

        #endregion

        #region Property Off-Premises Coverage
       
        public decimal PropertyOffPremisesBaseLimit { get; set; }
        public decimal PropertyOffPremisesRate { get; set; }
        public decimal PropertyOffPremisesPremium { get; set; }

        #endregion

        #region Spoilage Coverage
      
        public decimal SpoilageCoverageBaseLimit { get; set; }
        public decimal SpoilageCoverageRate { get; set; }
        public decimal SpoilageCoveragePremium { get; set; }

        #endregion

        #region Valuable Papers and Records Coverage
       
        public decimal ValuablePapersAndRecordsBaseLimit { get; set; }
        public decimal ValuablePapersAndRecordsRate { get; set; }
        public decimal ValuablePapersAndRecordsPremium { get; set; }

        #endregion

        #region Extra Expense and Tuition & Fees Coverage
      
        public decimal ExtraExpenseAndTuitionFeesBaseLimit { get; set; }
        public decimal ExtraExpenseAndTuitionFeesRate { get; set; }
        public decimal ExtraExpenseAndTuitionFeesPremium { get; set; }

        #endregion

        #region Valuable Papers	   
       
        public decimal ValuablePapersBaseLimit { get; set; }
        public decimal ValuablePapersRate { get; set; }
        public decimal ValuablePapersPremium { get; set; }

        #endregion

        #region Musical Instruments and Band Uniforms Coverage
       
        public decimal MusicalInstrumentsAndBandUniformsBaseLimit { get; set; }
        public decimal MusicalInstrumentsAndBandUniformsRate { get; set; }
        public decimal MusicalInstrumentsAndBandUniformsPremium { get; set; }

        #endregion

        #region Personal Property of EmployeesORVolunteers - Any one employeeORvolunteer 
        
        public decimal PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerBaseLimit { get; set; }
        public decimal PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRate { get; set; }
        public decimal PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerPremium { get; set; }

        #endregion

        #region Personal Property of EmployeesORVolunteers - Any one occurrence
       
        public decimal PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceBaseLimit { get; set; }
        public decimal PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRate { get; set; }
        public decimal PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrencePremium { get; set; }

        #endregion
    }
}
