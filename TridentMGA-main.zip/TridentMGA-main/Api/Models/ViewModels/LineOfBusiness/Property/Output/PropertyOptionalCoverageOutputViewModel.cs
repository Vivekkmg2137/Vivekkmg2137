﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.Property.Output
{
    public class PropertyOptionalCoverageOutputViewModel
    {
        #region Additional Covered Property

        /// <summary>
        /// Gets or sets Premium 
        /// </summary>
        public decimal AdditionalCoveredPropertyPremium { get; set; }

        #endregion

        #region Alabama Wind & Hail Certificate Credit 

        /// <summary>
        /// Gets or sets Premium 
        /// </summary>
        public decimal AlabamaWindAndHailCertificateCreditPremium { get; set; }

        #endregion

        #region Money, Securities, Stamps - Temporary Increased Limit of Insurance

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium
        /// </summary>
        public decimal MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium { get; set; }

        #endregion

        public List<PropertyOptionalOtherCoverageOutputViewModel> PropertyOptionalOthersCoverageOutputModel { get; set; }

    }

    public class PropertyOptionalOtherCoverageOutputViewModel
    {
        /// <summary>
        /// Gets or set Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Get or sets Premium
        /// </summary>
        public decimal Premium { get; set; }
    }
}
