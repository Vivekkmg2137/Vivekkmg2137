﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.LineOfBusiness.Property.Output
{
    public class PropertyStateSpecificOutputViewModel
    {
        #region  NY Property Model
        public decimal NewYorkTotalBuildingPremium { get; set; }

        /// <summary>
        /// Gets or sets CauseofLossRate.
        /// </summary>
        public decimal NewYorkCauseofLossFactor { get; set; }

        public decimal NewYorkInflationGuardFactor { get; set; }
        /// <summary>
        /// Gets or sets BaseRate.
        /// </summary>
        public decimal NewYorkBaseRate { get; set; }

        /// <summary>
        /// Gets or sets .
        /// </summary>
        public decimal NewYorkEarthquakeRate { get; set; }

        /// <summary>
        /// Gets or sets .
        /// </summary>
        public decimal NewYorkUWPremiumFireExposure { get; set; }

        /// <summary>
        /// Gets or sets .
        /// </summary>
        public decimal NewYorkFireInsuranceFeeCharge { get; set; }

        /// <summary>
        /// Gets or sets .
        /// </summary>
        public decimal NewYorkFireInsuranceRate { get; set; }

        /// <summary>
        /// Gets or sets .
        /// </summary>
        public decimal NewYorkWindAndHailLimit { get; set; }

        /// <summary>
        /// Gets or sets .
        /// </summary>
        public decimal NewYorkWindAndHailRate { get; set; }

        /// <summary>
        /// Gets or sets .
        /// </summary>
        public decimal NewYorkFloodRate { get; set; }

        /// <summary>
        /// Gets or sets decimal NewYorkProperty360Total Premiums. 
        /// </summary>
        public decimal NewYorkProperty360TotalPremiums { get; set; }
        #endregion

        /// <summary>
        /// Gets or sets PropertyNewYork360OutputModel.
        /// </summary>
        public PropertyNewYork360OutputViewModel PropertyNewYork360OutputModel { get; set; }
    }
}
