﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.PublicOfficials.Input
{
    public class PublicOfficialsInputViewModel
    {
        public PublicOfficialsCWInputViewModel CW { get; set;  }
        public PublicOfficialsNYInputViewModel NY { get; set; }
    }
}
