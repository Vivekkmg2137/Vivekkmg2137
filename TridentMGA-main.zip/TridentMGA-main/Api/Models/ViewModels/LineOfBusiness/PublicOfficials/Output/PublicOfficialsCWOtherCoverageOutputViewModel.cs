﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.PublicOfficials.Output
{
    public class PublicOfficialsCWOtherCoverageOutputViewModel
    {
        /// <summary>
        /// Gets or sets Other Coverage ID
        /// </summary>
        public int OtherCoverageID { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Description
        /// </summary>
        public string OtherCoverageDescription { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Limit
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Aggregate Limit
        /// </summary>
        public int OtherCoverageAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Deductible
        /// </summary>
        public int OtherCoverageDeductible { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Rate
        /// </summary>
        public decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Rating Basis
        /// </summary>
        public string OtherCoverageRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Return Method
        /// </summary>
        public string OtherCoverageReturnMethod { get; set; }

        /// <summary>
        /// Gets sets OtherCoverageUnModifiedWithoutExcessPremium
        /// </summary>
        public int OtherCoverageUnModifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets set OtherCoverageIncludedInExcessExposure
        /// </summary>
        public string OtherCoverageIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage UnModified Premium
        /// </summary>
        public int OtherCoverageUnModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Modified Premium
        /// </summary>
        public int OtherCoverageModifiedPremium { get; set; }
    }
}
