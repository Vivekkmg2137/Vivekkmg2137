﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.PublicOfficials.Output
{
    public class PublicOfficialsNYOptionalCoverageOutputViewModel
    {
        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period IsSelected
        /// </summary>
        public bool SupplExtendedReportingPeriodIsSelected { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Limit
        /// </summary>
        public int SupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Aggregate Limit
        /// </summary>
        public int SupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Deductible
        /// </summary>
        public int SupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rating Basis
        /// </summary>
        public string SupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Return Method
        /// </summary>
        public string SupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rate
        /// </summary>
        public decimal SupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodifed Premium
        /// </summary>
        public int SupplExtendedReportingPeriodUnModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodifed Premium
        /// </summary>
        public int SupplExtendedReportingPeriodModifiedPremium { get; set; }

        /// <summary>
        /// Gets set SupplExtendedReportingPeriodIncludedInExcessExpsure
        /// </summary>
        public string SupplExtendedReportingPeriodIncludedInExcessExpsure { get; set; }

        /// <summary>
        /// Gets Sets SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium
        /// </summary>
        public int SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium { get; set; }

        //"GRID START -OTHER COVERAGES"
        public List<PublicOfficialsNYOtherCoverageOutputViewModel> PublicOfficialsOtherCoverageModel { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Total Premium
        /// </summary>
        public int OtherCoveragesTotalPremium { get; set; }
    }
}
