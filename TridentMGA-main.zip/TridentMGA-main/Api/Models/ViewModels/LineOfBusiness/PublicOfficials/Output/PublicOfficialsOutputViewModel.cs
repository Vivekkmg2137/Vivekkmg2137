﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.LineOfBusiness.PublicOfficials.Output
{
    public class PublicOfficialsOutputViewModel
    {
        public PublicOfficialsCWOutputViewModel CW { get; set; }
        public PublicOfficialsNYOutputViewModel NY { get; set; }
    }
}
