﻿using Models.ViewModels.LineOfBusiness.Auto.AutoPhysicalDamage.Input;
using Models.ViewModels.LineOfBusiness.Auto.AutoLiability.Input;
using Models.ViewModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ViewModels.LineOfBusiness.EmploymentPractices.Input;
using Models.ViewModels.LineOfBusiness.EmploymentPracticesSchool.Input;
using Models.ViewModels.LineOfBusiness.Excess.Input;
using Models.ViewModels.LineOfBusiness.GeneralLiability.Input;
using Models.ViewModels.LineOfBusiness.InlandMarine.Input;
using Api.Models.ViewModels.LineOfBusiness.Ocp.Input;
using Models.ViewModels.LineOfBusiness.Property.Input;
using Api.Models.ViewModels.LineOfBusiness.DirectorsAndOfficers.Input;
using System;
using System.Collections.Generic;
using System.Text;
using Models.ViewModels.LineOfBusiness.Auto;
using Api.Models.ViewModels.LineOfBusiness.LawEnforcement.Input;
using Api.Models.ViewModels.LineOfBusiness.EducatorsLegal.Input;
using Api.Models.ViewModels.LineOfBusiness.PublicOfficials.Input;

namespace Models.ViewModels
{
    public class LineOfBusinessInputViewModel
    {
        /// <summary>
        /// Gets or sets Property
        /// </summary>
        public PropertyInputViewModel Property { get; set; }

        /// <summary>
        /// Gets or sets Auto
        /// </summary>
        public AutoInputViewModel Auto { get; set; }

        /// <summary>
        /// Gets or sets GeneralLiability
        /// </summary>
        public GeneralLiabilityInputViewModel GeneralLiability { get; set; }

        /// <summary>
        /// Gets or sets PublicOfficials
        /// </summary>
        public PublicOfficialsInputViewModel PublicOfficials { get; set; }

        /// <summary>
        /// Gets or sets EmploymentPractices
        /// </summary>
        public EmploymentPracticesInputViewModel EmploymentPractices { get; set; }

        /// <summary>
        /// Gets or sets EmploymentPracticesSchool 
        /// </summary>
        public EmploymentPracticesSchoolInputViewModel EmploymentPracticesSchool { get; set; }

        /// <summary>
        /// Gets or sets InlandMarine
        /// </summary>
        public InlandMarineInputViewModel InlandMarine { get; set; }

        /// <summary>
        /// Gets or sets Excess
        /// </summary>
        public ExcessInputViewModel Excess { get; set; }

        /// <summary>
        /// Gets or sets LawEnforcement
        /// </summary>
        public LawEnforcementInputViewModel LawEnforcement { get; set; }

        /// <summary>
        /// Gets or sets EducatorsLegal 
        /// </summary>
        public EducatorsLegalInputViewModel EducatorsLegal { get; set; }

        /// <summary>
        /// Gets or sets DirectorsAndOfficers
        /// </summary>
        public DirectorsAndOfficersInputViewModel DirectorsAndOfficers { get; set; }

        /// <summary>
        /// Gets or sets Ocp1
        /// </summary>
        public OcpInputViewModel Ocp1 { get; set; }

        /// <summary>
        /// Gets or sets Ocp2
        /// </summary>
        public OcpInputViewModel Ocp2 { get; set; }

        /// <summary>
        /// Gets or sets Ocp3
        /// </summary>
        public OcpInputViewModel Ocp3 { get; set; }

        /// <summary>
        /// Gets or sets Ocp4
        /// </summary>
        public OcpInputViewModel Ocp4 { get; set; }

        /// <summary>
        /// Gets or sets Ocp5
        /// </summary>
        public OcpInputViewModel Ocp5 { get; set; }
    }
}
