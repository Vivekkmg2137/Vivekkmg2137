﻿using Models.ViewModels.LineOfBusiness.Property.Output;
using System;
using System.Collections.Generic;
using System.Text;
using Api.Models.ViewModels.LineOfBusiness.LawEnforcement.Output;
using Api.Models.ViewModels.LineOfBusiness.EducatorsLegal.Output;
using Api.Models.ViewModels.LineOfBusiness.DirectorsAndOfficers.Output;
using Api.Models.ViewModels.LineOfBusiness.PublicOfficials.Output;
using Api.Models.ViewModels.LineOfBusiness.EmploymentPracticesSchool.Output;
using Api.Models.ViewModels.LineOfBusiness.EmploymentPractices.Output;
using Api.Models.ViewModels.LineOfBusiness.Auto;
using Api.Models.ViewModels.LineOfBusiness.Ocp.Output;
using Models.ViewModels.LineOfBusiness.GeneralLiability.output;

namespace Models.ViewModels
{
    public class LineOfBusinessOutputViewModel
    {
        /// <summary>
        /// Get or sets Property
        /// </summary>
        public PropertyOutputViewModel Property { get; set; }

        /// <summary>
        /// Gets or sets Auto
        /// </summary>
        public AutoOutputViewModel Auto { get; set; }

        /// <summary>
        /// Gets or sets GeneralLiability
        /// </summary>
        public GeneralLiabilityOutputViewModel GeneralLiability { get; set; }

        /// <summary>
        /// Gets or sets PublicOfficials
        /// </summary>
        public PublicOfficialsOutputViewModel PublicOfficials { get; set; }

        /// <summary>
        /// Gets or sets EmploymentPractices
        /// </summary>
        public EmploymentPracticesOutputViewModel EmploymentPractices { get; set; }

        /// <summary>
        /// Gets or sets EmploymentPracticesSchool
        /// </summary>
        public EmploymentPracticesSchoolOutputViewModel EmploymentPracticesSchool { get; set; }

        ///// <summary>
        ///// Gets or sets InlandMarine
        ///// </summary>
        //public InlandMarineOutputViewModel InlandMarine { get; set; }

        ///// <summary>
        ///// Gets or sets Excess
        ///// </summary>
        //public ExcessOutputViewModel Excess { get; set; }

        /// <summary>
        /// Gets or sets LawEnforcement
        /// </summary>
        public LawEnforcementOutputViewModel LawEnforcement { get; set; }

        /// <summary>
        /// Gets or sets EducatorsLegal 
        /// </summary>
        public EducatorsLegalOutputViewModel EducatorsLegal { get; set; }

        /// <summary>
        /// Gets or sets DirectorsAndOfficers
        /// </summary>
        public DirectorsAndOfficersOutputViewModel DirectorsAndOfficers { get; set; }

        /// <summary>
        /// Gets or sets Ocp1
        /// </summary>
        public OcpOutputViewModel Ocp1 { get; set; }

        /// <summary>
        /// Gets or sets Ocp2
        /// </summary>
        public OcpOutputViewModel Ocp2 { get; set; }

        /// <summary>
        /// Gets or sets Ocp3
        /// </summary>
        public OcpOutputViewModel Ocp3 { get; set; }

        /// <summary>
        /// Gets or sets Ocp4
        /// </summary>
        public OcpOutputViewModel Ocp4 { get; set; }

        /// <summary>
        /// Gets or sets Ocp5
        /// </summary>
        public OcpOutputViewModel Ocp5 { get; set; }        
    }
}
