﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.Policy
{
    public class LastTransactionViewModel
    {
        /// <summary>
        /// Gets or sets Premium.
        /// </summary>
        public decimal LastPremium { get; set; }
    }
}
