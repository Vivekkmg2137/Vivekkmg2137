﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.Policy
{
    public class LobIncludedViewModel
    {
        /// <summary>
        /// Get or Sets Property
        /// </summary>
        public bool Property { get; set; }

        /// <summary>
        /// Get or Sets GeneralLiability
        /// </summary>
        public bool GeneralLiability { get; set; }

        /// <summary>
        /// Get or Sets PublicOfficials
        /// </summary>
        public bool PublicOfficials { get; set; }

        /// <summary>
        /// Get or Sets EducatorsLegal
        /// </summary>
        public bool EducatorsLegal { get; set; }

        /// <summary>
        /// Get or Sets EmploymentPractices
        /// </summary>
        public bool EmploymentPractices { get; set; }

        /// <summary>
        /// Get or Sets EmploymentPracticesSchool
        /// </summary>
        public bool EmploymentPracticesSchool { get; set; }

        /// <summary>
        /// Get or Sets Auto
        /// </summary>
        public bool Auto { get; set; }

        /// <summary>
        /// Get or Sets InlandMarine
        /// </summary>
        public bool InlandMarine { get; set; }

        /// <summary>
        /// Get or Sets Excess
        /// </summary>
        public bool Excess { get; set; }

        /// <summary>
        /// Get or Sets LawEnforcement
        /// </summary>
        public bool LawEnforcement { get; set; }

        /// <summary>
        /// Get or Sets DirectorsAndOfficers
        /// </summary>
        public bool DirectorsAndOfficers { get; set; }

        /// <summary>
        /// Get or Sets Crime
        /// </summary>
        public bool Crime { get; set; }

        /// <summary>
        /// Get or Sets Ocp1
        /// </summary>
        public bool Ocp1 { get; set; }

        /// <summary>
        /// Get or Sets Ocp2
        /// </summary>
        public bool Ocp2 { get; set; }

        /// <summary>
        /// Get or Sets Ocp3
        /// </summary>
        public bool Ocp3 { get; set; }

        /// <summary>
        /// Get or Sets Ocp4
        /// </summary>
        public bool Ocp4 { get; set; }

        /// <summary>
        /// Get or Sets Ocp5
        /// </summary>
        public bool Ocp5 { get; set; }        
    }
}
