﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.Policy
{
    public class PolicyHeaderViewModel
    {
        ///<summary>
        /// Gets or sets Id.
        ///</summary>
        [JsonProperty(Order = 1)]
        public int Id { get; set; }

        ///<summary>
        /// Gets or sets Control Number.
        ///</summary>
        [JsonProperty(Order = 2)]
        public int ControlNumber { get; set; }

        /// <summary>
        /// Gets or sets QuoteId.
        /// </summary>
        [JsonProperty(Order = 3)]
        public int QuoteId { get; set; }

        ///<summary>
        /// Gets or sets State.
        ///</summary>
        [JsonProperty(Order = 4)]
        public string State { get; set; }

        
        ///<summary>
        /// Gets or sets IsEndorsement.
        ///</summary>
        [JsonProperty(Order = 5)]
        public bool IsEndorsement { get; set; } = false;


        /// <summary>
        /// Gets or sets Primary class.
        /// </summary>
        [JsonProperty(Order = 6)]
        public string NameInsured { get; set; }

        /// <summary>
        /// Gets or sets Primary class.
        /// </summary>
        [JsonProperty(Order = 7)]
        public string PrimaryClass { get; set; }

        /// <summary>
        /// Gets or sets Secondary Class.
        /// </summary>
        [JsonProperty(Order = 8)]
        public string SecondaryClass { get; set; }

        /// <summary>
        /// Gets or sets Policy Effective Date.
        /// </summary>
        [JsonProperty(Order = 9)]
        public DateTime PolicyEffectiveDate { get; set; } 

        /// <summary>
        /// Gets or sets PPolicy Expiration Date
        /// </summary>
        [JsonProperty(Order = 10)]
        public DateTime PolicyExpirationDate { get; set; } 

        /// <summary>
        /// Gets or sets Transaction Effective Date
        /// </summary>
        [JsonProperty(Order = 11)]
        public DateTime TransactionEffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [JsonProperty(Order = 12)]
        public string TransactionType { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [JsonProperty(Order = 13)]
        public string TransactionCode { get; set; }

        ///<summary>
        /// Gets or sets Desc.
        ///</summary>
        [JsonProperty(Order = 15)]
        public string Desc { get; set; }

        ///<summary>
        /// Gets or sets ClientId.
        ///</summary>
        [JsonProperty(Order = 16)]
        public string ClientId { get; set; }

        /// <summary>
        /// Gets or sets Company
        /// </summary>
         [JsonProperty(Order = 17)]
        public string Company { get; set; }

        /// <summary>
        /// Gets or sets PopulationADA
        /// </summary>
        [JsonProperty(Order = 18)]
        public long PopulationADA { get; set; }

        /// <summary>
        /// Gets or sets PopulationADA
        /// </summary>
        [JsonProperty(Order = 19)]
        public bool TerrorismCoverage { get; set; }

        /// <summary>
        /// Gets or sets LocationType
        /// </summary>
        public string LocationType { get; set; }
    }
}
