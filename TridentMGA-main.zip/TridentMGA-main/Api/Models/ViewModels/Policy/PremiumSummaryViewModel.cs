﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels.Policy
{
    public class PremiumSummaryViewModel
    {
        /// <summary>
        /// Gets or sets Premium.
        /// </summary>
        public decimal Premium { get; set; }
    }
}
