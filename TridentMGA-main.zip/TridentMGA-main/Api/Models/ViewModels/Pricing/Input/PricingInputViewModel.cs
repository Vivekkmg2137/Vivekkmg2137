﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models.ViewModels.Pricing.Input
{
    public class PricingInputViewModel
    {
        public bool TerrorismAcceptedRejected { get; set; }
        public string TierPlan { get; set; }
        public string NYFTZ { get; set; }

    }
}
