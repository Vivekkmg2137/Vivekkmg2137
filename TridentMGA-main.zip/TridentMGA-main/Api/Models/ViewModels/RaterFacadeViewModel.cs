﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels
{
    public class RaterFacadeViewModel
    {
        public RaterFacadeViewModel()
        {
           
        }
        public RaterInputFacadeViewModel RaterInputFacadeModel { get; set; }
        public RaterOutputFacadeViewModel RaterOutputFacadeModel { get; set; }
    }
}
