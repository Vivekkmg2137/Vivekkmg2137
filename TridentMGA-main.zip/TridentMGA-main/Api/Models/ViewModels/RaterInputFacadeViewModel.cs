﻿
using Api.Models.ViewModels.Pricing.Input;
using Models.ApiModels.Pricing.Input;
using Models.ViewModels.Policy;
//using Models.ViewModels.Pricing.Input;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels
{
    /// <summary>
    /// Input Model for Rater
    /// </summary>
    public class RaterInputFacadeViewModel
    {
        /// <summary>
        /// RaterInputFacadeViewModel
        /// </summary>
        public RaterInputFacadeViewModel()
        {
            LineOfBusiness = new LobIncludedViewModel();
        }

        /// <summary>
        /// LineOfBusiness
        /// </summary>
        [JsonProperty(Order = 1)]
        public LobIncludedViewModel LineOfBusiness { get; set; }

        /// <summary>
        /// PolicyHeaderModel
        /// </summary>
        [JsonProperty(Order = 2)]
        public PolicyHeaderViewModel PolicyHeaderModel { get; set; }

        /// <summary>
        /// LineOfBusinessInputModel
        /// </summary>
        [JsonProperty(Order = 3)]
        public LineOfBusinessInputViewModel LineOfBusinessInputModel { get; set; }

        /// <summary>
        /// PricingInputModel
        /// </summary>
        [JsonProperty(Order = 4)]  // these 2 will be the last property.
        public PricingInputViewModel PricingInputModel { get; set; }

        /// <summary>
        /// LastTransactionModel
        /// </summary>
        [JsonProperty(Order = 5)]
        public LastTransactionViewModel LastTransactionModel { get; set; }
    }
}
