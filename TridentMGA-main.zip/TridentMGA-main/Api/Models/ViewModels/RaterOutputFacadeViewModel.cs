﻿
using Models.ViewModels.Policy;
using Models.ViewModels.Pricing.Output;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ViewModels
{
    /// <summary>
    /// Output Model
    /// </summary>
    public class RaterOutputFacadeViewModel
    {
        /// <summary>
        /// RaterOutputFacade Model
        /// </summary>
        public RaterOutputFacadeViewModel()
        {
        }

        /// <summary>
        /// Response Model
        /// </summary>
        [JsonProperty(Order = 1)]
        public ResponseInfoModel ResponseModel { get; set; }

        /// <summary>
        /// Gets or sets LineOfBusiness Output Model
        /// </summary>
        [JsonProperty(Order = 2)]
        public LineOfBusinessOutputViewModel LineOfBusinessOutputModel { get; set; }

        /// <summary>
        /// Gets or sets Pricing Output Model
        /// </summary>
        [JsonProperty(Order = 3)]   // these 2 will be the last property.
        public PricingOutputViewModel PricingOutputModel { get; set; }

        /// <summary>
        /// Gets or sets Premium Summary Model
        /// </summary>
        [JsonProperty(Order = 4)]
        public PremiumSummaryViewModel PremiumSummaryModel { get; set; }
    }
}
