using FluentValidation;
using Logging;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;

namespace Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            //services.AddControllersWithViews();
            services.AddControllers();
            
            // Logging
            services.AddSingleton<ILoggingManager, LoggingManager>();
            
            //services
            //    .AddControllersWithViews()
            //    .AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = null);


            //Map the configuration
            services.AddSingleton<IConfiguration>(Configuration);

            //// Configure fluent validation for asp.net core
            //services.AddTransient<IValidatorFactory, ServiceProviderValidatorFactory>();

            // Register the NSwag Swagger services
            //services.AddSwaggerDocument();
            services.AddSwaggerDocument(config =>
            {
                config.PostProcess = document =>
                {
                    document.Info.Version = "v1";
                    document.Info.Title = "NetRate - Trident Rater API";
                    document.Info.Description = "API for Trident lines of business";
                    document.Info.TermsOfService = "None";
                    document.Info.Contact = new NSwag.OpenApiContact
                    {
                        Name = "KMG - Key Management Group",
                        Email = "manish.bisht@kmgus.com",
                        Url = "http://www.kmgus.com/"
                    };
                    document.Info.License = new NSwag.OpenApiLicense
                    {
                        Name = "MGA Systems",
                        Url = "http://www.mgasystems.com/"
                    };
                };
            });

            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            //else
            //{
            //    app.UseExceptionHandler("/Home/Error");
            //    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            //    app.UseHsts();
            //}
            app.UseHttpsRedirection();
            //app.UseStaticFiles();

            //// Register the NSwag Swagger generator and the Swagger UI middlewares
            //// http://localhost:<port>/swagger to view the Swagger UI.
            //// http://localhost:<port>/swagger/v1/swagger.json to view the Swagger specification
            app.UseOpenApi();
            app.UseSwaggerUi3();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();

                //endpoints.MapControllerRoute(
                //    name: "default",
                //    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
