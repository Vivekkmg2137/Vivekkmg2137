﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess
{
   public  class AutoDataAccess : DataAccess
    {
        public AutoDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {
        }

        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        private bool GetDataFromDataReaderBoolean(string procedureName, SqlParameter[] commandParameters)
        {
            bool expectedValue = false;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToBoolean(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting GetMinimumPremium Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="TierType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetMinimumPremium(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetMinimumPremium :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoMinimumPremium, commandParameters);
                
                this.logger.Info("AutoDataAccess.GetMinimumPremium :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetMinimumPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetLimitFactor From table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="LimitType"></param>
        /// <param name="limit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetLimitFactor(string state, string lineOfBusiness, string LimitType, string limit, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetLimitFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LimitType", Value = LimitType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoLimitFactor, commandParameters);

                this.logger.Info("AutoDataAccess.GetLimitFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetLimitFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetBaseRate From table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="RatingGroup"></param>
        /// <param name="locationType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetBaseRate(string state, string primaryClass, string lineOfBusiness, string RatingGroup, string locationType, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetBaseRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@RatingGroup", Value = RatingGroup, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoBaseRate, commandParameters);

                this.logger.Info("AutoDataAccess.GetBaseRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetBaseRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting DeductibleFactor from Deuctible lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="Deductible_SIRType"></param>
        /// <param name="deductible"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetDeductibleFactor(string state, string lineOfBusiness, string Deductible_SIRType, decimal deductible,string coverage, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetDeductibleFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIRType", Value = Deductible_SIRType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoDeductibleFactor, commandParameters);

                this.logger.Info("AutoDataAccess.GetDeductibleFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetDeductibleFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetPIPRate from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="Coverage"></param>
        /// <param name="locationType"></param>
        /// <param name="RatingGroup"></param>
        /// <param name="DependentCoverageLimit"></param>
        /// <param name="limit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetPIPRate(string state, string lineOfBusiness, string Coverage, string locationType, string RatingGroup, string DependentCoverageLimit, string limit, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetPIPRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[8];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = Coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@RatingGroup", Value = RatingGroup, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@DependentCoverageLimit", Value = DependentCoverageLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[6] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoPIPRate, commandParameters);

                this.logger.Info("AutoDataAccess.GetPIPRate :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetPIPRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetMEDRate from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="Coverage"></param>
        /// <param name="locationType"></param>
        /// <param name="RatingGroup"></param>
        /// <param name="limit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetMEDRate(string state, string lineOfBusiness, string Coverage, string locationType, string RatingGroup, string limit, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetMEDRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = Coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@RatingGroup", Value = RatingGroup, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoMedRate, commandParameters);
                this.logger.Info("AutoDataAccess.GetMEDRate :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetMEDRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetUMRate from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="Coverage"></param>
        /// <param name="locationType"></param>
        /// <param name="RatingGroup"></param>
        /// <param name="UMUIMStacking"></param>
        /// <param name="limit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetUMRate(string state, string lineOfBusiness, string Coverage, string locationType, string RatingGroup, bool UMUIMStacking, string limit, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetUMRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[8];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = Coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@RatingGroup", Value = RatingGroup, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@UMUIMStacking", Value = UMUIMStacking, SqlDbType = SqlDbType.NVarChar };
                commandParameters[6] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoUMRate, commandParameters);
                this.logger.Info("AutoDataAccess.GetUMRate :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetUMRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetUIMRate from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="Coverage"></param>
        /// <param name="locationType"></param>
        /// <param name="RatingGroup"></param>
        /// <param name="limit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetUIMRate(string state, string lineOfBusiness, string Coverage, string locationType, string RatingGroup, string limit, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetUIMRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = Coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@RatingGroup", Value = RatingGroup, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoUIMRate, commandParameters);
                this.logger.Info("AutoDataAccess.GetUIMRate :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetUIMRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetPopulationFactor from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="Population"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetPopulationFactor(string state, string primaryClass, string lineOfBusiness, decimal Population, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetPopulationFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Population", Value = Population, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoPopulationFactor, commandParameters);
                this.logger.Info("AutoDataAccess.GetPopulationFactor :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetPopulationFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetTierFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="TierType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetTierFactor(string state, string lineOfBusiness, string TierType, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetTierFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@TierType", Value = TierType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoTierFactor, commandParameters);
                this.logger.Info("AutoDataAccess.GetTierFactor :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetTierFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetSurchargeRate Form Table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="Coverage"></param>
        /// <param name="AutoClass"></param>
        /// <param name="PIPLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetSurchargeRate(string state, string lineOfBusiness, string Surcharge, string Coverage, string ClassCode, string PIPLimit, string TransactionCode, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetSurchargeRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[8];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Surcharge", Value = Surcharge, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = Coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@ClassCode", Value = ClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PIPLimit", Value = PIPLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[6] = new SqlParameter { ParameterName = "@TransactionCode", Value = TransactionCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoSurchargeRate, commandParameters);
                this.logger.Info("AutoDataAccess.GetSurchargeRate :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetSurchargeRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetNYMotorVehicleFee From table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="Coverage"></param>
        /// <param name="TransactionCode"></param>
        /// <param name="ClassCode"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetAutoNYFeeVehiclesCount(string state, string lineOfBusiness, string Coverage, string TransactionCode, string ClassCode, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetNYMotorVehicleFee :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = Coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@TransactionCode", Value = TransactionCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@ClassCode", Value = ClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoNYFeeVehiclesCount, commandParameters);
                this.logger.Info("AutoDataAccess.GetNYMotorVehicleFee :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetNYMotorVehicleFee :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetHiredandNonOwnedPremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetHiredandNonOwnedPremium(string state, string primaryClass, string lineOfBusiness, string coverageName, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetHiredandNonOwnedPremium :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoHiredAndNonOwnedPremium, commandParameters);
                this.logger.Info("AutoDataAccess.GetHiredandNonOwnedPremium :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetHiredandNonOwnedPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetOptionalCoveragePremium(string state, string primaryClass, string lineOfBusiness, string coverageName, string RatingBasis, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetOptionalCoveragePremium :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@RatingBasis", Value = RatingBasis, SqlDbType = SqlDbType.VarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoOptionalCoveragePremium, commandParameters);
                this.logger.Info("AutoDataAccess.GetOptionalCoveragePremium :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// GetValuationFactor
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="Valuation"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetValuationFactor(string state, string lineOfBusiness, string Valuation, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetValuationFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Valuation", Value = Valuation, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoValuationFactor, commandParameters);

                this.logger.Info("AutoDataAccess.GetValuationFactor :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetValuationFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        public decimal GetAutoSurchargeVehiclesCount(string state, string lineOfBusiness, string Surcharge, string Coverage, string ClassCode, string TransactionCode, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("AutoDataAccess.GetAutoSurchargeVehiclesCount :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Surcharge", Value = Surcharge, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = Coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@ClassCode", Value = ClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@TransactionCode", Value = TransactionCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetAutoSurchargeVehiclesCount, commandParameters);
                this.logger.Info("AutoDataAccess.GetAutoSurchargeVehiclesCount :: Completed");
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetAutoSurchargeVehiclesCount :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
        
        public DataTable GetAutoLimitFactor(string state, string lineOfBusiness, string limitType, string limit, DateTime policyEffectiveDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("AutoDataAccess.GetAutoLimitFactor Started");

                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LimitType", Value = limitType, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetAutoLimitFactor, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("AutoDataAccess.GetAutoLimitFactor Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetAutoLimitFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public DataTable GetAutoApplicableDeductible(string state, string lineOfBusiness, string dedSIR, decimal deductible, DateTime policyEffectiveDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PropertyDataAccess.GetAutoApplicableDeductible Started");

                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIR", Value =dedSIR, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.Decimal };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetAutoApplicableDeductible, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("AutoDataAccess.GetAutoApplicableDeductible Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetAutoApplicableDeductible :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public bool GetAutoApplicableMedPay(string state, string lineOfBusiness, string Valuation, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("GetAutoApplicableMedPay :: GetAutoApplicableMedPay in process");

                bool returnFlag = false;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = Valuation, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                returnFlag = this.GetDataFromDataReaderBoolean(StoredProcedureConstant.Trident_GetAutoApplicableMedPay, commandParameters);

                return returnFlag;
            }
            catch (Exception ex)
            {
                logger.Error("GetAutoApplicableMedPay :: GetAutoApplicableMedPay ::" + ex.Message);
                throw;
            }

        }

        public bool GetAutoApplicableUMCoverage(string state, string lineOfBusiness, string coverage, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("GetAutoApplicableUMCoverage :: GetAutoApplicableUMCoverage in process");

                bool returnFlag = false;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                returnFlag = this.GetDataFromDataReaderBoolean(StoredProcedureConstant.Trident_GetAutoApplicableUMCoverage, commandParameters);

                return returnFlag;
            }
            catch (Exception ex)
            {
                logger.Error("GetAutoApplicableUMCoverage :: GetAutoApplicableUMCoverage ::" + ex.Message);
                throw;
            }

        }

        public bool GetAutoApplicableUIMCoverage(string state, string lineOfBusiness, string coverage, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("GetAutoApplicableUIMCoverage :: GetAutoApplicableUIMCoverage in process");

                bool returnFlag = false;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                returnFlag = this.GetDataFromDataReaderBoolean(StoredProcedureConstant.Trident_GetAutoApplicableUIMCoverage, commandParameters);

                return returnFlag;
            }
            catch (Exception ex)
            {
                logger.Error("GetAutoApplicableUIMCoverage :: GetAutoApplicableUIMCoverage ::" + ex.Message);
                throw;
            }

        }
        public bool GetAutoApplicablePIPCoverage(string state, string lineOfBusiness, string coverage, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("GetAutoApplicablePIPCoverage :: GetAutoApplicablePIPCoverage in process");

                bool returnFlag = false;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                returnFlag = this.GetDataFromDataReaderBoolean(StoredProcedureConstant.Trident_GetAutoApplicablePIPCoverage, commandParameters);

                return returnFlag;
            }
            catch (Exception ex)
            {
                logger.Error("GetAutoApplicablePIPCoverage :: GetAutoApplicablePIPCoverage ::" + ex.Message);
                throw;
            }

        }

        public bool GetAutoApplicableOptionalCoverage(string state, string lineOfBusiness, string coverage, DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("GetAutoApplicableOptionalCoverage :: GetAutoApplicableOptionalCoverage in process");

                bool returnFlag = false;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                returnFlag = this.GetDataFromDataReaderBoolean(StoredProcedureConstant.Trident_GetAutoApplicableOptionalCoverage,
                    commandParameters);

                return returnFlag;
            }
            catch (Exception ex)
            {
                logger.Error("GetAutoApplicableOptionalCoverage :: GetAutoApplicableOptionalCoverage ::" + ex.Message);
                throw;
            }

        }

        public bool GetAutoApplicableSurcharge(string state, string lineOfBusiness, string coverage, DateTime policyEffectiveDate)
        {
            try
            {

                this.logger.Info("GetAutoApplicableSurcharge :: GetAutoApplicableSurcharge in process");
                bool returnFlag = false;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                returnFlag = this.GetDataFromDataReaderBoolean(StoredProcedureConstant.Trident_GetAutoApplicableSurcharge,
                    commandParameters);

                return returnFlag;
            }
            catch (Exception ex)
            {
                logger.Error("GetAutoApplicableSurcharge :: GetAutoApplicableSurcharge ::" + ex.Message);
                throw;
            }
        }

        public DataTable GetMinMaxValueForFactor(string state, string primaryClass, string lineOfBusiness, string factorType, DateTime policyEffectiveDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GetMinMaxValueForFactor.GetMinMaxValueForFactor Started");

                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetMinMaxValueForFactor, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("GetMinMaxValueForFactor.GetMinMaxValueForFactor Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GetMinMaxValueForFactor.GetMinMaxValueForFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public DataTable GetAutoBaseRate(string state, string primaryClass, string lineOfBusiness, string RatingGroup, string locationType, DateTime policyEffectiveDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("AutoDataAccess.GetAutoBaseRate Started");

                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@RatingGroup", Value = RatingGroup, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetAutoBaseRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("AutoDataAccess.GetAutoBaseRate Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetAutoBaseRate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public bool GetAutoApplicableClassCode(string state, string lineOfBusiness, string classCode, string RatingGroup, DateTime policyEffectiveDate)
        {
            bool returnFlag = false;
            try
            {
                this.logger.Info("AutoDataAccess.GetAutoApplicableClassCode Started");

                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@ClassCode", Value = classCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@RatingGroup", Value = RatingGroup, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                returnFlag = this.GetDataFromDataReaderBoolean(StoredProcedureConstant.Trident_GetAutoApplicableClassCode,
                   commandParameters);

                return returnFlag;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.GetAutoApplicableClassCode :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

    }
}
