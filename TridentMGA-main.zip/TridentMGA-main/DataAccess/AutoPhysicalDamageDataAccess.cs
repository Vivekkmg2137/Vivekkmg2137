﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;


namespace DataAccess
{
    public class AutoPhysicalDamageDataAccess:DataAccess
    {
        public AutoPhysicalDamageDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration,logger)
        {


        }

        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        public DataTable GetMinMaxValueForFactor(string state, string primaryClass, string lineOfBusiness, string factorType, DateTime policyEffectiveDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("AutoPhysicalDamageDataAccess.GetMinMaxValueForFactor Started");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetMinMaxValueForFactor, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("AutoPhysicalDamageDataAccess.GetMinMaxValueForFactor Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("AutoPhysicalDamageDataAccess.GetMinMaxValueForFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        private bool GetDataFromDataReaderBoolean(string procedureName, SqlParameter[] commandParameters)
        {
            bool expectedValue = false;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToBoolean(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }
        public bool GetAutoApplicableClassCode(string state, string lineOfBusiness, string classCode, string RatingGroup, DateTime policyEffectiveDate)
        {
            bool returnFlag = false;
            try
            {
                this.logger.Info("AutoPhysicalDamageDataAccess.GetAutoApplicableClassCode Started");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@ClassCode", Value = classCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@RatingGroup", Value = RatingGroup, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                returnFlag = this.GetDataFromDataReaderBoolean(StoredProcedureConstant.Trident_GetAutoApplicableClassCode,
                   commandParameters);
                this.logger.Info("AutoPhysicalDamageDataAccess.GetAutoApplicableClassCode Completed.");
                return returnFlag;
            }
            catch (Exception ex)
            {
                logger.Error("AutoDataAccess.AutoPhysicalDamageDataAccess :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public DataTable GetBaseRate(string state, string primaryClass, string lineOfBusiness, string RatingGroup, string locationType, DateTime policyEffectiveDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("AutoPhysicalDamageDataAccess.GetBaseRate Started");

                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@RatingGroup", Value = RatingGroup, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetAutoBaseRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("AutoPhysicalDamageDataAccess.GetBaseRate Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("AutoPhysicalDamageDataAccess.GetBaseRate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
    }
}
