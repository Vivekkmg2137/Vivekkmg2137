﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess
{
    /// <summary>
    /// CrimeDataAccess : Data access layer for calculation of PublicOfficials general premium.
    /// </summary>
    public class CrimeDataAccess : DataAccess
    {
        /// <summary>
        /// CrimeDataAccess
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public CrimeDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {
        }

        /// <summary>
        /// GetDataFromDataReader
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="commandParameters"></param>
        /// <returns></returns>
        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting RatingBasis from Rating Basis Parameter lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetRatingBasisParameter(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("CrimeDataAccess :: GetRatingBasisParameter in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetRatingBasisParameter, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("CrimeDataAccess :: GetRatingBasisParameter ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

    }
}
