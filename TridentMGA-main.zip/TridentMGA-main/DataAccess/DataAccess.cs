﻿using DataAccess.Utils;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace DataAccess
{
    public class DataAccess
    {
        protected ILoggingManager logger { get; private set; }
        protected IConfiguration configuration { get; private set; }
        protected DataSettings DataSettings { get; private set; }
        public bool IsAccessLookUpData { get; set; }


        /// <summary>
        /// Data access
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public DataAccess(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            //config["ConnectionStrings:SqlDBConnection"]
            //var issuer = Configuration["JwtBearerSettings:Issuer"];
            this.logger = logger;

            if (configuration != null)
            {
                //Load from configuration
                this.DataSettings = new DataSettings();
                this.DataSettings.SqlServerConnectionString = this.configuration["ConnectionStrings:SqlDBConnection"];
                this.DataSettings.NoSqlDBConnectionString = this.configuration["ConnectionStrings:NoSqlDBConnection"];
                IsAccessLookUpData = true;

                SqlConnectionStringBuilder sqlconnectionbuilder = new SqlConnectionStringBuilder(this.configuration["ConnectionStrings:SqlDBConnection"]);
                var dbName = sqlconnectionbuilder.InitialCatalog;
                var dbServer = sqlconnectionbuilder.DataSource;

                logger.Info("SqlConnection: " + this.DataSettings.SqlServerConnectionString);
                logger.Info("Database Name: " + dbName);
                logger.Info("Database Server: " + dbServer);
            }
            else //Load from local datasettings file
            {
                var file = "datasettings.json";
                var settings = new object();
                try
                {
                    var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                    var filePath = buildDir + @"\datasettings.json";
                    settings = JsonLoader.LoadFromFile<dynamic>(filePath);
                    IsAccessLookUpData = true;
                }
                catch
                {
                    file = "datasettings.json";
                    settings = JsonLoader.LoadFromFile<dynamic>(file);
                   
                }

                try
                {
                    DataSettings = JsonLoader.Deserialize<DataSettings>(settings);
                    IsAccessLookUpData = true;
                }
                catch (Exception ex)
                {
                    logger.Error("DataAccess :: Could not find datasettings.json");
                    logger.Error("DataAccess :: " + ex.Message);
                    throw;
                }
            }
            
        }        

        public DataSet fnTestDBConnection()
        {
            string Query = "Select * from lstStates";
            DataSet ds = SqlHelper.ExecuteDataset(DataSettings.SqlServerConnectionString, CommandType.Text, Query);
            return ds;
        }
    }
}
