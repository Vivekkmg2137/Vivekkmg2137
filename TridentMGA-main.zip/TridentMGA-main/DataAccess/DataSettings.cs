﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataAccess
{
    public class DataSettings
    {
        public string SqlServerConnectionString { get; set; }
        public string NoSqlDBConnectionString { get; set; }

        public MongoDBConnection MongoDBConnection { get; set; }
    }

    public class MongoDBConnection
    {
        public string Server { get; set; }
        public bool RequiresAuthentication { get; set; }
        public string Password { get; set; }
    }
}
