﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess
{
    /// <summary>
    /// DirectorsAndOfficersDataAccess
    /// </summary>
    public class DirectorsAndOfficersDataAccess : DataAccess
    {
        /// <summary>
        /// DirectorsAndOfficersDataAccess
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public DirectorsAndOfficersDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {

        }

        /// <summary>
        /// decimal
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="commandParameters"></param>
        /// <returns>decimal</returns>
        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// GetExcessExposureDataFromDataReader
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="commandParameters"></param>
        /// <returns>decimal</returns>
        private string GetExcessExposureDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            string expectedValue = "";
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToString(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting ProfLinesEPInclExclRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="EPCoverage"></param>
        /// <param name="Item"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesEPInclExclRate(string state, string lineOfBusiness, string EPInclusionExclusion, string Item, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesEPInclExclRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@EPCoverage", Value = EPInclusionExclusion, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Item", Value = Item, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPOInclExclRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesEPInclExclRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesEPInclExclRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting RatingBasis from Rating Basis Parameter lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetRatingBasisParameter(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesExposureRate :: Started");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetRatingBasisParameter, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("DODataAccess.GetProfLinesExposureRate :: Started");
            }
            catch (Exception ex)
            {
                logger.Error("DODataAccess :: GetRatingBasisParameter ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting ProfLinesExposureRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesExposureRate(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesExposureRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesExposureRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesExposureRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesExposureRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesLiabilityLimitRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesLiabilityLimitRate(string state, string lineOfBusiness, decimal liabilityLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesLiabilityLimitRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesLiabilityLimitRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesLiabilityLimitRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesAggregateLimitRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="aggregateLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesAggregateLimitRate(string state, string lineOfBusiness, decimal liabilityLimit, decimal aggregateLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesAggregateLimitRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesAggregateLimitRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesAggregateLimitRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesAggregateLimitRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesRetentionRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="deductible_SIRType"></param>
        /// <param name="retention"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesRetentionRate(string state, string lineOfBusiness, string deductible_SIRType, int retention, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesRetentionRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIRType", Value = deductible_SIRType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Retention", Value = retention, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetentionRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesRetentionRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesRetentionRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesPopulationRate fro table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="population"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPopulationRate(string state, string primaryClass, string lineOfBusiness, decimal population, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesPopulationRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Population", Value = population, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPopulationRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesPopulationRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesPopulationRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesLocationRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="locationType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesLocationRate(string state, string lineOfBusiness, string locationType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesLocationRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLocationRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesLocationRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesLocationRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesPolicyTypeRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPolicyTypeRate(string state, string lineOfBusiness, string policyType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesPolicyTypeRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyType", Value = policyType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPolicyTypeRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesPolicyTypeRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesPolicyTypeRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesCMPolicyYearRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="years"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesCMPolicyYearRate(string state, string lineOfBusiness, int years, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesCMPolicyYearRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Years", Value = years, SqlDbType = SqlDbType.Int };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesCMPolicyYearRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesCMPolicyYearRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesCMPolicyYearRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesRetroDateRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="retroYear"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesRetroDateRate(string state, string lineOfBusiness, string retroYear, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesRetroDateRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@RetroYear", Value = retroYear, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetroDateRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesRetroDateRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesRetroDateRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesTierRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="tierType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesTierRate(string state, string lineOfBusiness, string tierType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetProfLinesTierRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@TierType", Value = tierType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesTierRate, commandParameters);

                this.logger.Info("DODataAccess.GetProfLinesTierRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetProfLinesTierRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting MinimumPremium Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetMinimumPremium(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("DODataAccess.GetMinimumPremium :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesMinimumPremium, commandParameters);
                this.logger.Info("DODataAccess.GetMinimumPremium :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("DODataAccess.GetMinimumPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// GetOtherModRate
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetOtherModRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("DODataAccess :: GetOtherModRate in process");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesOtherModRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("DODataAccess :: GetOtherModRate completed");
            }
            catch (Exception ex)
            {
                logger.Error("DODataAccess :: GetOtherModRate ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// GetIRPMRate
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetIRPMRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("DODataAccess :: GetIRPMRate in process");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesIRPMRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("DODataAccess :: GetIRPMRate completed");
            }
            catch (Exception ex)
            {
                logger.Error("DODataAccess :: GeIRPMRate ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// GetLiabilityLimitRateMinimum
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetLiabilityLimitRateMinimum(string state, string lineOfBusiness, decimal liabilityLimitRate, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("DODataAccess :: GetLiabilityLimitRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimitRate, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("DODataAccess :: GetLiabilityLimitRate completed");
                return dataTable;
              
            }
            catch (Exception ex)
            {
                logger.Error("DODataAccess :: GetLiabilityLimitRate ::" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// GetAutoApplicableDeductible
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="dedSIR"></param>
        /// <param name="deductible"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetAutoApplicableDeductible(string state, string lineOfBusiness, string dedSIR, string deductible, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("DODataAccess.GetAutoApplicableDeductible Started");

                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIR", Value = dedSIR, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.VarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesApplicableDeductible, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                
                this.logger.Info("DODataAccess.GetAutoApplicableDeductible Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("DODataAccess.GetAutoApplicableDeductible :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetProfLinesApplicableOptionalCoverage
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClassCode"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesApplicableOptionalCoverage(string state, string primaryClassCode, string lineOfBusiness, string coverage, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("DODataAccess :: GetProfLinesApplicableOptionalCoverage in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesApplicableOptionalCoverage, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("DODataAccess :: GetProfLinesApplicableOptionalCoverage completed");
            }
            catch (Exception ex)
            {
                logger.Error("DODataAccess :: GetProfLinesApplicableOptionalCoverage ::" + ex.Message);
                throw;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting ProfLinesPOOptionalCoverageRate from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <Param name="limit"></Param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="RatingBasis"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpiratinDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPOOptionalCoverageRate(string state, string primaryClass, string lineOfBusiness, string coverageName, int limit, string RatingBasis, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesPOOptionalCoverageRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.Int };
                commandParameters[3] = new SqlParameter { ParameterName = "@RatingBasis", Value = RatingBasis, SqlDbType = SqlDbType.VarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPOOptionalCoverageRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesPOOptionalCoverageRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesPOOptionalCoverageRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetProfLinesExcessExposure Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverageName"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>string</returns>
        public string GetProfLinesExcessExposure(string state, string primaryClass, string coverageName, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesExcessExposure :: Started");

                string excessExposure = null;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                excessExposure = this.GetExcessExposureDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoverageInExcessExposure, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesExcessExposure :: Completed");

                return excessExposure;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesExcessExposure :: Exception :: " + ex.Message, ex);
                throw;
            }

        }
    }

}

