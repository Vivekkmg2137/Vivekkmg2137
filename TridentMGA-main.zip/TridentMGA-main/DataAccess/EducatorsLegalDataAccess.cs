﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess
{
    /// <summary>
    /// EducatorsLegalDataAccess : Data access layer for calculation of Employment Practices School general premium.
    /// </summary>
    public class EducatorsLegalDataAccess : DataAccess
    {
        public EducatorsLegalDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {

        }

        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        private string GetExcessExposureFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            string expectedValue = "";
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToString(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        private bool GetBooleanDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            bool expectedValue = false;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToBoolean(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting RatingBasis from Rating Basis Parameter lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public DataTable GetRatingBasisParameter(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("ELDataAccess :: GetRatingBasisParameter in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetRatingBasisParameter, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetRatingBasisParameter ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }


        /// <summary>
        /// Getting ExposureRate from ProfLinesBaseRate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public DataTable GetExposureRateMinMaxFactor(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GetELExposureRate :: GetELExposureRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesExposureRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("GetELExposureRate :: GetELExposureRate ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting EPInclusionExclusionRate from EPInclExcl lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public decimal GetEPInclusionExclusionRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("GetELInclusionExclusionRate :: GetELInclusionExclusionRate in process");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesInclExclRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetELInclusionExclusionRate :: GetELInclusionExclusionRate ::" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Getting EPInclusionExclusionRate from EPInclExcl lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public decimal GetELInclusionExclusionRate(string state, string lineOfBusiness, string coverage, string item, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("GetELInclusionExclusionRate :: GetELInclusionExclusionRate in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@EPCoverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Item", Value = item, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPOInclExclRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetELInclusionExclusionRate :: GetELInclusionExclusionRate ::" + ex.Message);
                throw ex;
            }
        }




        /// <summary>
        /// Getting LiabilityLimitRate from ProfLineLimit lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public DataTable GetLiabilityLimitRateMinimum(string state, string lineOfBusiness, decimal liabilityLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                // decimal baseRate = 0;
                this.logger.Info("GetELLiabilityLimitRate :: GetELLiabilityLimitRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                //  baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters);
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                return dataTable;

            }
            catch (Exception ex)
            {
                logger.Error("GetELLiabilityLimitRate :: GetELLiabilityLimitRate ::" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Getting AggregateLimitRate from ProfLinesAggregateLimit lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetAggregateLimitRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, decimal liabilityLimitRate, decimal aggregateLimit)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("GetELAggregateLimitRate :: GetELAggregateLimitRate in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimitRate, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesAggregateLimitRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetELAggregateLimitRate :: GetELAggregateLimitRate ::" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Getting RetentionRate from ProfLinesAggregateLimit lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetRetentionRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string dedSIRType, string retention)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("GetRetentionRateFactor :: GetRetentionRateFactor in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIRType", Value = dedSIRType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Retention", Value = retention, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetentionRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetRetentionRateFactor :: GetRetentionRateFactor ::" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Getting RetentionRate from ProfLinesAggregateLimit lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetPopulationRate(string state, string lineOfBusiness, string PrimaryClass, DateTime policyEffectiveDate, DateTime policyExpirationDate, decimal Population)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("GetPopulationRateFactor :: GetPopulationRateFactor in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = PrimaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Population", Value = Population, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPopulationRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetPopulationRateFactor :: GetPopulationRateFactor ::" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetLocationRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string LocationType)
        {
            try
            {
                this.logger.Info("GetELOptionalCoveragePremium :: GetLocationRate in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LocationType", Value = LocationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLocationRate, commandParameters);


                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetELOptionalCoveragePremium :: GetLocationRate ::" + ex.Message);
                throw ex;
            }

        }


        /// <summary>
        /// Getting Factor from Trident.PolicyType lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetPolicyTypeRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string PolicyType)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("GetPolicyTypeRate :: GetPolicyTypeRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyType", Value = PolicyType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPolicyTypeRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetPolicyTypeRate :: GetPolicyTypeRate ::" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Getting CM Factor from Trident.CMPolicyYear lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetYearsinCMRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, int Years)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("GetYearsinCMRate :: GetYearsinCMRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Years", Value = Years, SqlDbType = SqlDbType.Int };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesCMPolicyYearRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetYearsinCMRate :: GetYearsinCMRate ::" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Getting RetroDate Rate from Retro Date Factor lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetRetroDateRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string RetroYear)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("ELDataAccess :: GetRetroDateRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@RetroYear", Value = RetroYear, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetroDateRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetRetroDateRate ::" + ex.Message);
                throw ex;
            }
        }

        /// <summary>
        /// Getting Factor from Trident.ProfLinesLossExperience lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns 
        public decimal GetLossExperienceRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, bool isLossExpApplied)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("ELDataAccess :: GetLossExperienceRate in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@IsLossExpApplied", Value = isLossExpApplied, SqlDbType = SqlDbType.Bit };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLossExperienceRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetLossExperienceRate ::" + ex.Message);
                throw ex;
            }
        }


        /// <summary>
        /// Getting Tier Factor from Trident.TierFactors lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param> 
        /// <returns></returns>
        public decimal GetTierRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string TierType)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("ELDataAccess :: GetTierRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@TierType", Value = TierType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesTierRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetTierRate ::" + ex.Message);
                throw ex;
            }
        }


        /// <summary>
        /// Getting "DEFAULT IRPM from Trident.IRPM lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public DataTable GetIRPMRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("ELDataAccess :: GetIRPMRate in process");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesIRPMRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GeIRPMRate ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting Min & Max Other Mod columns from Trident.OtherMod lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public DataTable GetOtherModRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("ELDataAccess :: GetOtherModRate in process");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesOtherModRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetOtherModRate ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetOptionalCoveragePremium(string state, string coverageName, string lineOfBusiness, string primaryClass, int Limit, int AggregateLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("ELDataAccess :: GetELOptionalCoveragePremium in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[8];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = Limit, SqlDbType = SqlDbType.Int };
                commandParameters[5] = new SqlParameter { ParameterName = "@AggregateLimit", Value = AggregateLimit, SqlDbType = SqlDbType.Int };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoveragePremium, commandParameters);


                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetELOptionalCoveragePremium ::" + ex.Message);
                throw ex;
            }

        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetOptionalCoverageRate(string state, string primaryClass, string lineOfBusiness, string coverageName, int Limit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("ELDataAccess :: GetELOptionalCoverageRate in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = Limit, SqlDbType = SqlDbType.Int };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoverageRate, commandParameters);


                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetELOptionalCoverageRate ::" + ex.Message);
                throw ex;
            }

        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetOptionalMinimumPremium(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("ELDataAccess :: GetELOptionalCoveragePremium in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesMinimumPremium, commandParameters);


                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetELOptionalCoveragePremium ::" + ex.Message);
                throw ex;
            }

        }

        /// <summary>
        /// Read the Table -> Minimum Premium to get the EB Minimum Premium value.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="premiumType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetLOBTotalPremium(string state, string lineOfBusiness, string primaryClass, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("ELDataAccess :: GetLOBTotalPremium in process");
                decimal lOBTotalPremium = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesMinimumPremium, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            lOBTotalPremium = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return lOBTotalPremium;
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetLOBTotalPremium ::" + ex.Message);
                throw;
            }
        }

        public DataTable GetProfLinesApplicableDeductible(string state, string lineOfBusiness, string dedSIR, string deductible, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("ELDataAccess :: GetProfLinesApplicableDeductible in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIR", Value = dedSIR, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesApplicableDeductible, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("ELDataAccess :: GetProfLinesApplicableDeductible in completed");
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetProfLinesApplicableDeductible ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting ExposureRate from Base Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public DataTable GetProfLinesExposureRate(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("ELDataAccess :: GetProfLinesExposureRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesExposureRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("ELDataAccess :: GetProfLinesApplicableDeductible in completed");
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetProfLinesExposureRate ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        public decimal GetProfLinesApplicableOptionalCoverage(string state, string primaryClassCode, string lineOfBusiness, string coverage, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("ELDataAccess :: GetProfLinesApplicableOptionalCoverage in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesApplicableOptionalCoverage, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetProfLinesApplicableOptionalCoverage ::" + ex.Message);
                throw ex;
            }
            this.logger.Info("ELDataAccess :: GetProfLinesApplicableOptionalCoverage in completed");
            return rate;
        }

        public bool GetProfLinesCheckApplicableOptionalCoverage(string state, string primaryClassCode, string lineOfBusiness, string coverage, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            bool rate;
            try
            {
                this.logger.Info("ELDataAccess :: GetProfLinesApplicableOptionalCoverage in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetBooleanDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesApplicableOptionalCoverage, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetProfLinesApplicableOptionalCoverage ::" + ex.Message);
                throw ex;
            }
            this.logger.Info("ELDataAccess :: GetProfLinesApplicableOptionalCoverage in completed");
            return rate;
        }
        public decimal GetProfLinesOptionalCoveragePremium(string state, string primaryClassCode, string lineOfBusiness, string coverage, decimal limit, decimal aggregateLimit, string ratingBasis, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("ELDataAccess :: GetProfLinesApplicableOptionalCoverage in process");
                SqlParameter[] commandParameters = new SqlParameter[9];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.Decimal };
                commandParameters[5] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[6] = new SqlParameter { ParameterName = "@RatingBasis", Value = ratingBasis, SqlDbType = SqlDbType.NVarChar };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[8] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPOOptionalCoveragePremium, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetProfLinesApplicableOptionalCoverage ::" + ex.Message);
                throw ex;
            }
            this.logger.Info("ELDataAccess :: GetProfLinesApplicableOptionalCoverage in completed");
            return rate;
        }
        public decimal GetProfLinesApplicableOptionalRate(string state, string primaryClassCode, string lineOfBusiness, string coverage, decimal limit, string ratingBasis, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("ELDataAccess :: GetProfLinesApplicableOptionalRate in process");
                SqlParameter[] commandParameters = new SqlParameter[8];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.Decimal };
                commandParameters[5] = new SqlParameter { ParameterName = "@RatingBasis", Value = ratingBasis, SqlDbType = SqlDbType.NVarChar };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPOOptionalCoverageRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetProfLinesApplicableOptionalCoverage ::" + ex.Message);
                throw ex;
            }
            this.logger.Info("ELDataAccess :: GetProfLinesApplicableOptionalCoverage in completed");
            return rate;
        }

        public string GetExcessExposure(string state, string primaryClassCode, string lineOfBusiness, string coverage, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            string exposure = "";
            try
            {
                this.logger.Info("ELDataAccess :: GetExcessExposure in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };  
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                exposure = this.GetExcessExposureFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoverageInExcessExposure, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("ELDataAccess :: GetExcessExposure ::" + ex.Message);
                throw ex;
            }
            this.logger.Info("ELDataAccess :: GetProfLinesApplicableOptionalCoverage in completed");
            return exposure;
        }

    }
}
