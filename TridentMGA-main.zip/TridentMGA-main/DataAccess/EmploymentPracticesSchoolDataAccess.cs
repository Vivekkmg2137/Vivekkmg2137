﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess
{
    /// <summary>
    /// EmploymentPracticesSchoolDataAccess : Data access layer for calculation of Employment Practices School general premium.
    /// </summary>
    public class EmploymentPracticesSchoolDataAccess : DataAccess
    {
        public EmploymentPracticesSchoolDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {

        }

        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        private string GetExcessExposureFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            string expectedValue = "";
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToString(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting ExposureRate from ProfLinesBaseRate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public DataTable GetExposureRateMinMaxFactor(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GetEPSExposureRate :: GetEPSExposureRate in process");                
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesExposureRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSExposureRate :: GetEPSExposureRate ::" + ex.Message);
                throw;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting EPInclusionExclusionRate from EPInclExcl lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public decimal GetEPInclusionExclusionRateFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                decimal baseRate = 0;
                this.logger.Info("GetEPSInclusionExclusionRate :: GetEPSInclusionExclusionRate in process");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesInclExclRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSInclusionExclusionRate :: GetEPSInclusionExclusionRate ::" + ex.Message);
                throw;
            }
        }


        /// <summary>
        /// Getting LiabilityLimitRate from ProfLineLimit lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public DataTable GetLiabilityLimitRateMinimumFactor(string state,  string lineOfBusiness, decimal liabilityLimitRate, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            { 
                // decimal baseRate = 0;
                this.logger.Info("GetEPSLiabilityLimitRate :: GetEPSLiabilityLimitRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimitRate, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
              //  baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters);
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                return dataTable;

            }
            catch (Exception ex)
            {
                logger.Error("GetEPSLiabilityLimitRate :: GetEPSLiabilityLimitRate ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting AggregateLimitRate from ProfLinesAggregateLimit lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetAggregateLimitRateFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, decimal liabilityLimitRate, decimal aggregateLimit)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                decimal baseRate = 0;
                this.logger.Info("GetEPSAggregateLimitRate :: GetEPSAggregateLimitRate in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimitRate, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesAggregateLimitRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSAggregateLimitRate :: GetEPSAggregateLimitRate ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting RetentionRate from ProfLinesAggregateLimit lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetRetentionRateFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string dedSIRType, string retention)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                decimal baseRate = 0;
                this.logger.Info("GetRetentionRateFactor :: GetRetentionRateFactor in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };             
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIRType", Value = dedSIRType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Retention", Value = retention, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetentionRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetRetentionRateFactor :: GetRetentionRateFactor ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting RetentionRate from ProfLinesAggregateLimit lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetPopulationRateFactor(string state, string lineOfBusiness,string PrimaryClass, DateTime policyEffectiveDate, DateTime policyExpirationDate, decimal Population)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                decimal baseRate = 0;
                this.logger.Info("GetPopulationRateFactor :: GetPopulationRateFactor in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = PrimaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Population", Value = Population, SqlDbType = SqlDbType.NVarChar }; 
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPopulationRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetPopulationRateFactor :: GetPopulationRateFactor ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetEPSLocationRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string LocationType)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("GetEPSOptionalCoveragePremium :: GetEPSOptionalCoveragePremium in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LocationType", Value = LocationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLocationRate, commandParameters);


                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSOptionalCoveragePremium :: GetEPSOptionalCoveragePremium ::" + ex.Message);
                throw;
            }

        }


        /// <summary>
        /// Getting Factor from Trident.PolicyType lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetEPSPolicyTypeRateFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string PolicyType)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                decimal baseRate = 0;
                this.logger.Info("GetEPSPolicyTypeRate :: GetEPSPolicyTypeRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyType", Value = PolicyType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPolicyTypeRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSPolicyTypeRate :: GetEPSPolicyTypeRate ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting CM Factor from Trident.CMPolicyYear lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetEPSYearsinCMRateFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, int Years)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                decimal baseRate = 0;
                this.logger.Info("GetEPSYearsinCMRate :: GetEPSYearsinCMRate in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Years", Value = Years, SqlDbType = SqlDbType.Int }; 
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesCMPolicyYearRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSYearsinCMRate :: GetEPSYearsinCMRate ::" + ex.Message);
                throw;
            }
        }
    
        /// <summary>
        /// Getting RetroDate Rate from Retro Date Factor lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public decimal GetEPSRetroDateRateFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string RetroYear)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                decimal baseRate = 0;
                this.logger.Info("GetEPSRetroDateRate :: GetEPSRetroDateRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar }; 
                commandParameters[2] = new SqlParameter { ParameterName = "@RetroYear", Value = RetroYear, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetroDateRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSRetroDateRate :: GetEPSRetroDateRate ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting Factor from Trident.ProfLinesLossExperience lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns 
        public decimal GetEPSLossExperienceRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, bool isLossExpApplied)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("GetLossExperienceRate :: GetLossExperienceRate in process");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@IsLossExpApplied", Value = isLossExpApplied, SqlDbType = SqlDbType.Bit }; 
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLossExperienceRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetLossExperienceRate :: GetLossExperienceRate ::" + ex.Message);
                throw;
            }
        }


        /// <summary>
        /// Getting Tier Factor from Trident.TierFactors lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param> 
        /// <returns></returns>
        public decimal GetEPSTierRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate, string TierType)
        {
            try
            {
                decimal baseRate = 0;
                this.logger.Info("GetEPSTierRate :: GetEPSTierRate in process");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@TierType", Value = TierType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesTierRate, commandParameters);
                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSTierRate :: GetEPSTierRate ::" + ex.Message);
                throw;
            }
        }


        /// <summary>
        /// Getting "DEFAULT IRPM from Trident.IRPM lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public DataTable GetEPSIRPMRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            { 
                this.logger.Info("GetEPSIRPMRate :: GetEPSIRPMRate in process");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesIRPMRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSIRPMRate :: GetEPSIRPMRate ::" + ex.Message);
                throw;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting Min & Max Other Mod columns from Trident.OtherMod lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <param name="liabilityLimitRate"></param>
        /// <param name="aggregateLimit"></param>
        /// <returns></returns>
        public DataTable GetEPSOtherModRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            { 
                this.logger.Info("GetEPSOtherModRate :: GetEPSOtherModRate in process");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                 
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesOtherModRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSOtherModRate :: GetEPSOtherModRate ::" + ex.Message);
                throw;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetOptionalCoveragePremium(string state, string coverageName, string lineOfBusiness, string primaryClass, int Limit, int AggregateLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {               
                this.logger.Info("GetEPSOptionalCoveragePremium :: GetEPSOptionalCoveragePremium in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[8];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = Limit, SqlDbType = SqlDbType.Int };
                commandParameters[5] = new SqlParameter { ParameterName = "@AggregateLimit", Value = AggregateLimit, SqlDbType = SqlDbType.Int };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoveragePremium, commandParameters);

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSOptionalCoveragePremium :: GetEPSOptionalCoveragePremium ::" + ex.Message);
                throw;
            }

        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetOptionalCoverageRate(string state, string primaryClass, string lineOfBusiness, string coverageName, int Limit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GetEPSOptionalCoverageRate :: GetEPSOptionalCoverageRate in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = Limit, SqlDbType = SqlDbType.Int }; 
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoverageRate, commandParameters);

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetEPSOptionalCoverageRate :: GetEPSOptionalCoverageRate ::" + ex.Message);
                throw;
            }

        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetOptionalMinimumPremium(string state, string primaryClass, string lineOfBusiness,  DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("EPSDataAccess :: GetEPSOptionalCoveragePremium in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesMinimumPremium, commandParameters);

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("EPSDataAccess :: GetEPSOptionalCoveragePremium ::" + ex.Message);
                throw;
            }

        }

        /// <summary>
        /// Read the Table -> Minimum Premium to get the EB Minimum Premium value.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="premiumType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public decimal GetLOBTotalPremium(string state, string lineOfBusiness, string primaryClass, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("EPSDataAccess :: GetLOBTotalPremium in process");
                decimal lOBTotalPremium = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesMinimumPremium, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            lOBTotalPremium = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return lOBTotalPremium;
            }
            catch (Exception ex)
            {
                logger.Error("EPSDataAccess :: GetLOBTotalPremium ::" + ex.Message);
                throw;
            }
        }


        /// <summary>
        /// Read the Table -> Minimum Premium to get the EB Minimum Premium value.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="premiumType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public string GetExcessExposure(string state, string lineOfBusiness, string primaryClass, string coverage, DateTime policyEffectiveDate, DateTime policyExpirationDatee)
        {
            try
            {
                this.logger.Info("EmploymentPracticesDataAccess :: GetLOBTotalPremium in process");
                string excessExposure = "";
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDatee, SqlDbType = SqlDbType.DateTime };

                excessExposure = this.GetExcessExposureFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoverageInExcessExposure, commandParameters);

                return excessExposure;
            }
            catch (Exception ex)
            {
                logger.Error("EmploymentPracticesDataAccess :: GetLOBTotalPremium ::" + ex.Message);
                throw;
            }
        }

    }
}
