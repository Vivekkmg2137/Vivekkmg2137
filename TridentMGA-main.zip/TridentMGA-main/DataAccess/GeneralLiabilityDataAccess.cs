﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess
{
    public class GeneralLiabilityDataAccess : DataAccess
    {
        public GeneralLiabilityDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {
        }

        /// <summary>
        /// GetDataFromDataReader
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="commandParameters"></param>
        /// <returns>decimal</returns>
        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// GetDataFromDataReaderBoolean
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="commandParameters"></param>
        /// <returns>Boolean</returns>
        private bool GetDataFromDataReaderBoolean(string procedureName, SqlParameter[] commandParameters)
        {
            bool expectedValue = false;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToBoolean(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// GetDataFromDataReaderString
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="commandParameters"></param>
        /// <returns>string</returns>
        private string GetDataFromDataReaderString(string procedureName, SqlParameter[] commandParameters)
        {
            string expectedValue = "";
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToString(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting GetBaseRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetBaseRate(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetBaseRate :: Started");

                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLBaseRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("GeneralLiabilityDataAccess.GetBaseRate :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetBaseRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

       
        /// <summary>
        /// Getting GetLiabilityLimitRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetLiabilityLimitRate(string state, string lineOfBusiness, string liabilityLimit, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetLiabilityLimitRate :: Started");

                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLIncreasedLimits, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("GeneralLiabilityDataAccess.GetLiabilityLimitRate :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetLiabilityLimitRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetAggregateLimitFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetAggregateLimitFactor(string state, string lineOfBusiness, string liabilityLimit, int aggregateLimit, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetAggregateLimitFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.Int };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLAggregateLimits, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetAggregateLimitFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetAggregateLimitFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetRetentionFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="dedSIRType"></param>
        /// <param name="retention"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetRetentionFactor(string state, string lineOfBusiness, string dedSIRType, int retention, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetRetentionFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIRType", Value = dedSIRType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Retention", Value = retention, SqlDbType = SqlDbType.Int };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLDeductibleSIR, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetRetentionFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetRetentionFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetPopulationFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="population"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetPopulationFactor(string state, string primaryClass, string lineOfBusiness,decimal population, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetPopulationFactor :: Started");

                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Population", Value = population, SqlDbType = SqlDbType.Decimal };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLPopulationFactor, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("GeneralLiabilityDataAccess.GetPopulationFactor :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetPopulationFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetLocationFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="locationType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetLocationFactor(string state, string lineOfBusiness, string locationType, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetLocationFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLLocationRate, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetLocationFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetLocationFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetPolicyTypeFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetPolicyTypeFactor(string state, string lineOfBusiness, string policyType, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetPolicyTypeFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyType", Value = policyType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLPolicyType, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetPolicyTypeFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetPolicyTypeFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetYearsInCMFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetYearsInCMFactor(string state, string lineOfBusiness, string policyType, int years, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetYearsInCMFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyType", Value = policyType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Years", Value = years, SqlDbType = SqlDbType.Int };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLCMPolicyYearRate, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetYearsInCMFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetYearsInCMFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetRetroDateFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyType"></param>
        /// <param name="retroActiveDate"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetRetroDateFactor(string state, string lineOfBusiness, string retroYear, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetRetroDateFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@RetroYear", Value = retroYear, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLRetroDateRate, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetRetroDateFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetRetroDateFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetLossExperienceFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="lossExperienceApplied"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetLossExperienceFactor(string state, string lineOfBusiness, bool? isLossExpApplied, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetLossExperienceFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@IsLossExpApplied", Value = isLossExpApplied, SqlDbType = SqlDbType.Bit };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLLossExperienceRate, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetLossExperienceFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetLossExperienceFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetTerrorismFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetTerrorismFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetTerrorismFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLTerrorismFactors, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetTerrorismFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetTerrorismFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetTierFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="tierPlan"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetTierFactor(string state, string lineOfBusiness, string tierPlan, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetTierFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@TierPlan", Value = tierPlan, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLTierRate, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetTierFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetTierFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetCoverageLimitInExcessExposure Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>InExcessExposure</returns>
        public string GetCoverageLimitInExcessExposure(string state, string primaryClass, string lineOfBusiness, string coverage,string limit, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetCoverageLimitInExcessExposure :: Started");

                string InExcessExposure = null;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                InExcessExposure = this.GetDataFromDataReaderString(StoredProcedureConstant.Trident_GetGLCoverageLimitInExcessExposure, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetCoverageLimitInExcessExposure :: Completed");

                return InExcessExposure;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetCoverageLimitInExcessExposure :: Exception :: " + ex.Message, ex);
                throw;
            }

        }


        /// <summary>
        /// Getting GetGLEmployeeBenefitsLiabilityPremium Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="eBLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Premium</returns>
        public decimal GetGLEmployeeBenefitsLiabilityPremium(string state, string primaryClass, string lineOfBusiness, string eBLimit, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetGLEmployeeBenefitsLiabilityPremium :: Started");

                decimal Premium = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
               // commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@EBLimit", Value = eBLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };


                Premium = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLEmployeeBenefitsLiabilityPremium, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetGLEmployeeBenefitsLiabilityPremium :: Completed");

                return Premium;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetGLEmployeeBenefitsLiabilityPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetEBIncludedInExcessExposure Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public string GetEBIncludedInExcessExposure(string state, string primaryClass, string lineOfBusiness,string eBLimit, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetEBIncludedInExcessExposure :: Started");

                string InExcessExposure = null;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@EBLimit", Value = eBLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };


                InExcessExposure = this.GetDataFromDataReaderString(StoredProcedureConstant.Trident_GetGLEmployeeBenefitsLiabilityInExcessExposure, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetEBIncludedInExcessExposure :: Completed");

                return InExcessExposure;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetEBIncludedInExcessExposure :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetDataCompLimitInExcessExposure Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>InExcessExposure</returns>
        public string GetDataCompLimitInExcessExposure(string state, string primaryClass, string lineOfBusiness, string coverage, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetDataCompLimitInExcessExposure :: Started");

                string InExcessExposure = null;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                InExcessExposure = this.GetDataFromDataReaderString(StoredProcedureConstant.Trident_GetGLDataCompLimitInExcessExposure, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetDataCompLimitInExcessExposure :: Completed");

                return InExcessExposure;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetDataCompLimitInExcessExposure :: Exception :: " + ex.Message, ex);
                throw;
            }

        }


        /// <summary>
        /// Getting GetTierFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="subCoverage"></param>
        /// <param name="subCoveragelimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetDataCompLimitsPremium(string state, string primaryClass, string lineOfBusiness, string subCoverage, int subCoveragelimit, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetDataCompLimitsPremium :: Started");

                decimal Premium = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@SubCoverage", Value = subCoverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@SubCoveragelimit", Value = subCoveragelimit, SqlDbType = SqlDbType.Int };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                Premium= this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLDataCompLimitRate, commandParameters);
                
                this.logger.Info("GeneralLiabilityDataAccess.GetDataCompLimitsPremium :: Completed");

                return Premium;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetDataCompLimitsPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetEBIncludedInExcessExposure Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="populationADA"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetDataCompPopulationFactor(string state, string primaryClass, string lineOfBusiness, string coverage,decimal population, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetDataCompPopulationFactor :: Started");

                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Population", Value = population, SqlDbType = SqlDbType.Decimal };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLPopulationFactors, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }


                this.logger.Info("GeneralLiabilityDataAccess.GetDataCompPopulationFactor :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetDataCompPopulationFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }


        /// <summary>
        /// Getting GetDataCompCyberNYCMYears Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="yearsinClaimsMade"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetDataCompCyberNYCMYears(string state, string lineOfBusiness, string coverage, decimal year, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetDataCompCyberNYCMYears :: Started");

                decimal Factor = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Year", Value = year, SqlDbType = SqlDbType.Int };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };


                Factor = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLNYCMYearFactor, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetDataCompCyberNYCMYears :: Completed");

                return Factor;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetDataCompCyberNYCMYears :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetCyberLimitsPremium Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="computerAttackLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetCyberLimitsPremium(string state, string primaryClass, string lineOfBusiness, string coverage, decimal limit, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetCyberLimitsPremium :: Started");

                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.Decimal };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLCyberLimitPremium, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }


                this.logger.Info("GeneralLiabilityDataAccess.GetCyberLimitsPremium :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetCyberLimitsPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetCyberPopulation Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="populationADA"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetCyberPopulation(string state, string primaryClass, string lineOfBusiness,string coverage,decimal population, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetCyberPopulation :: Started");

                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Population", Value = population, SqlDbType = SqlDbType.Decimal };
                commandParameters[4] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLCyberPopulationFactor, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
               

                this.logger.Info("GeneralLiabilityDataAccess.GetCyberPopulation :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetCyberLimitsPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetCyberLimitInExcessExposure Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>Rate</returns>
        public string GetCyberLimitInExcessExposure(string state, string primaryClass, string lineOfBusiness, string coverage, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetCyberLimitInExcessExposure :: Started");

                string InExcessExposure = null;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                InExcessExposure = this.GetDataFromDataReaderString(StoredProcedureConstant.Trident_GetGLCyberLimitInExcessExposure, commandParameters);


                this.logger.Info("GeneralLiabilityDataAccess.GetCyberLimitInExcessExposure :: Completed");

                return InExcessExposure;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetCyberLimitInExcessExposure :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetUnmannedAircraftFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="aggregateLimit"></param>
        /// <param name="coverageOption"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>Rate</returns>
        public decimal GetUnmannedAircraftFactor(string state, string lineOfBusiness, string coverage, decimal aggregateLimit, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetUnmannedAircraftFactor :: Started");

                decimal Factor = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                Factor = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLUnmannedAircraftsFactor, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetUnmannedAircraftFactor :: Completed");

                return Factor;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetUnmannedAircraftFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetUnmannedAircrafts Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="coverageOption"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetUnmannedAircrafts(string state, string lineOfBusiness, string coverage, string coverageOption, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetUnmannedAircrafts :: Started");

                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@CoverageOption", Value = coverageOption, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };


                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLUnmannedAircrafts, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("GeneralLiabilityDataAccess.GetUnmannedAircrafts :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetUnmannedAircrafts :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetUnmannedAircrafts15ToLessThan55lbs Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="coverageOption"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetUnmannedAircrafts15ToLessThan55lbs(string state, string lineOfBusiness, string coverage, string coverageOption, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetUnmannedAircrafts15ToLessThan55lbs :: Started");

                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@CoverageOption", Value = coverageOption, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };


                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLUnmannedAircrafts15ToLessThan55lbs, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                

                this.logger.Info("GeneralLiabilityDataAccess.GetUnmannedAircrafts15ToLessThan55lbs :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetUnmannedAircrafts15ToLessThan55lbs :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetUnmannedAircrafts55lbs Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="coverageOption"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetUnmannedAircrafts55lbs(string state, string lineOfBusiness, string coverage, string coverageOption, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetUnmannedAircrafts55lbs :: Started");

                decimal Factor = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@CoverageOption", Value = coverageOption, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLUnmannedAircrafts55lbs, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                

                this.logger.Info("GeneralLiabilityDataAccess.GetUnmannedAircrafts55lbs :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetUnmannedAircrafts55lbs :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetMinimumPremium Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="unmannedAircraftOption"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetUnmannedAircraftsMinPremium(string state, string lineOfBusiness,string coverage, decimal aggregateLimit, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetMinimumPremium :: Started");

                decimal MinValue = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                MinValue = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLUnmannedAircraftsMinPremium, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetMinimumPremium :: Completed");

                return MinValue;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetMinimumPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetOptionalCoverageExcessExposure Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public string GetOptionalCoverageExcessExposure(string state, string primaryClass, string lineOfBusiness, string coverage, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetOptionalCoverageExcessExposure :: Started");

                string InExcessExposure = null;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };


                InExcessExposure = this.GetDataFromDataReaderString(StoredProcedureConstant.Trident_GetGLOptionalCoveragesInExcessExposure, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetOptionalCoverageExcessExposure :: Completed");

                return InExcessExposure;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetOptionalCoverageExcessExposure :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetOptionalCoverageRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="limit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetOptionalCoverageRate(string state, string primaryClass, string lineOfBusiness, string coverage,string limit,DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetOptionalCoverageRate :: Started");

                decimal rate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLOptionalCoveragesRate, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetOptionalCoverageRate :: Completed");

                return rate;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetOptionalCoverageRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        //Pending form BA side
        /// <summary>
        /// Getting GetOptionalCoveragePremium Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public decimal GetOptionalCoveragePremium(string state, string primaryClass, string lineOfBusiness, string coverage, DateTime policyEffectiveDate,DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetOptionalCoveragePremium :: Started");

                decimal Premium = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                Premium = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLOptionalCoveragesPremium, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetOptionalCoveragePremium :: Completed");

                return Premium;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting GetLOBMiniumPremium Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>Rate</returns>
        public decimal GetLOBMiniumPremium(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetLOBMiniumPremium :: Started");

                decimal LOBMinPremium = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                LOBMinPremium = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetGLLOBMiniumPremium, commandParameters);

                this.logger.Info("GeneralLiabilityDataAccess.GetLOBMiniumPremium :: Completed");

                return LOBMinPremium;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetLOBMiniumPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }


        /// <summary>
        /// Getting Get IRPMFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="tierPlan"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetIRPMFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetIRPMFactor :: Started");
                DataTable dataTable = null;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLIRPMRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("GeneralLiabilityDataAccess.GetIRPMFactor :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetIRPMFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting Get OtherMode Factor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="tierPlan"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetOtherModeFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetOtherModeactor :: Started");
                DataTable dataTable = null;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLIRPMRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("GeneralLiabilityDataAccess.GetOtherModeactor :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetOtherModeactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>Rate</returns>
        public DataTable GetCyberLimitDeductible(string state, string primaryClass, string lineOfBusiness, string coverage, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("GeneralLiabilityDataAccess.GetCyberLimitDeductible :: Started");
                DataTable dataTable = null;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetGLCyberLimitDeductible, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("GeneralLiabilityDataAccess.GetCyberLimitDeductible :: Completed");

                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("GeneralLiabilityDataAccess.GetCyberLimitDeductible :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

    }
}
