﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess
{
    /// <summary>
    /// LawDataAccess
    /// </summary>
    public class LawDataAccess : DataAccess
    {
        /// <summary>
        /// LawDataAccess
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public LawDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {

        }

        /// <summary>
        /// GetExcessExposureDataFromDataReader
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="commandParameters"></param>
        /// <returns>decimal</returns>
        private string GetExcessExposureDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            string expectedValue = "";
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToString(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// GetDataFromDataReader
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="commandParameters"></param>
        /// <returns>decimal</returns>
        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting ProfLinesExposureRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesExposureRate(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesExposureRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesExposureRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesExposureRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesExposureRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesLiabilityLimitRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesLiabilityLimitRate(string state, string lineOfBusiness, decimal liabilityLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesLiabilityLimitRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesLiabilityLimitRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesLiabilityLimitRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesAggregateLimitRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="aggregateLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesAggregateLimitRate(string state, string lineOfBusiness, decimal liabilityLimit, decimal aggregateLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesAggregateLimitRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesAggregateLimitRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesAggregateLimitRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesAggregateLimitRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesRetentionRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="deductible_SIRType"></param>
        /// <param name="retention"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesRetentionRate(string state, string lineOfBusiness, string deductible_SIRType, string retention, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesRetentionRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIRType", Value = deductible_SIRType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Retention", Value = retention, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetentionRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesRetentionRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesRetentionRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesPopulationRate fro table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="population"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPopulationRate(string state, string primaryClass, string lineOfBusiness, decimal population, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesPopulationRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Population", Value = population, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPopulationRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesPopulationRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesPopulationRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesLocationRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="locationType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesLocationRate(string state, string lineOfBusiness, string locationType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesLocationRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLocationRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesLocationRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesLocationRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesPolicyTypeRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPolicyTypeRate(string state, string lineOfBusiness, string policyType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesPolicyTypeRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyType", Value = policyType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPolicyTypeRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesPolicyTypeRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesPolicyTypeRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesCMPolicyYearRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="years"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesCMPolicyYearRate(string state, string lineOfBusiness, int years, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesCMPolicyYearRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Years", Value = years, SqlDbType = SqlDbType.Int };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesCMPolicyYearRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesCMPolicyYearRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesCMPolicyYearRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesRetroDateRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="retroYear"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesRetroDateRate(string state, string lineOfBusiness, string retroYear, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesRetroDateRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@RetroYear", Value = retroYear, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetroDateRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesRetroDateRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesRetroDateRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesLossExperienceRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="isLossExpApplied"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesLossExperienceRate(string state, string lineOfBusiness, bool? isLossExpApplied, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesLossExperienceRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@IsLossExpApplied", Value = isLossExpApplied, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLossExperienceRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesLossExperienceRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesLossExperienceRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesTierRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="tierType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesTierRate(string state, string lineOfBusiness, string tierType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesTierRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@TierType", Value = tierType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesTierRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesTierRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesTierRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesIRPMRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesIRPMRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesIRPMRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesIRPMRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesIRPMRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesIRPMRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesOtherModRate Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesOtherModRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesOtherModRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOtherModRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesOtherModRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesOtherModRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesUnmannedAircraftFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverageOption"></param>
        /// <param name="aggregateLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesUnmannedAircraftFactor(string state, string lineOfBusiness, string coverageOption, decimal aggregateLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesUnmannedAircraftFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@CoverageOption", Value = coverageOption, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesUnmannedAircraftFactor, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesUnmannedAircraftFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesUnmannedAircraftFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesUnmannedAircraftFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverageOption"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesUnmannedAircraftPremium(string state, string lineOfBusiness, string coverageOption, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesUnmannedAircraftPremium :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@CoverageOption", Value = coverageOption, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesUnmannedAircraftPremium, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesUnmannedAircraftPremium :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesUnmannedAircraftFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesUnmannedAircraftMinMaxFactor Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverageOption"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesUnmannedAircraftBaseRateFactor(string state, string lineOfBusiness, string coverageOption, int type, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesUnmannedAircraftBaseRateFactor :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@CoverageOption", Value = coverageOption, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Type", Value = type, SqlDbType = SqlDbType.Int };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesUnmannedAircraftMinMaxFactor, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesUnmannedAircraftBaseRateFactor :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesUnmannedAircraftBaseRateFactor :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesOptionalCoverageRate from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <Param name="limit"></Param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpiratinDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesOptionalCoverageRate(string state, string primaryClass, string lineOfBusiness, string coverageName, int limit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesOptionalCoverageRate :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.Int };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoverageRate, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesOptionalCoverageRate :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesOptionalCoverageRate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting ProfLinesOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <Param name="limit"></Param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpiratinDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesOptionalCoveragePremium(string state, string primaryClass, string lineOfBusiness, string coverageName, decimal limit, decimal aggregateLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesOptionalCoveragePremium :: Started");

                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[8];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.NVarChar };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoveragePremium, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesOptionalCoveragePremium :: Completed");

                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// Getting MinimumPremium Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetMinimumPremium(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetMinimumPremium :: Started");
                
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                baseRate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesMinimumPremium, commandParameters);
                
                this.logger.Info("LawDataAccess.GetMinimumPremium :: Completed");
                
                return baseRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetMinimumPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        /// <summary>
        /// GetProfLinesExposureRateMinMax
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesExposureRateMinMax(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesExposureRate :: Started");

                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesExposureRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("LawDataAccess.GetProfLinesExposureRate :: Completed");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("LawDataAccess.GetProfLinesExposureRate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetProfLinesLiabilityLimitRateMinMax
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesLiabilityLimitRateMinMax(string state, string lineOfBusiness, decimal liabilityLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesLiabilityLimitRate :: Started");

                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("LawDataAccess.GetProfLinesLiabilityLimitRate :: Completed");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("LawDataAccess.GetProfLinesLiabilityLimitRate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetProfLinesOtherModRateMinMax
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesOtherModRateMinMax(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesOtherModRateMinMax :: Started");

                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesOtherModRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("LawDataAccess.GetProfLinesOtherModRateMinMax :: Completed");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("LawDataAccess.GetProfLinesOtherModRateMinMax :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetProfLinesIRPMRateMinMax
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesIRPMRateMinMax(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesIRPMRateMinMax :: Started");

                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesIRPMRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("LawDataAccess.GetProfLinesIRPMRateMinMax :: Completed");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("LawDataAccess.GetProfLinesIRPMRateMinMax :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetProfLinesUnmannedAircraftMinMaxFactor
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverageOption"></param>
        /// <param name="type"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesUnmannedAircraftMinMaxFactor(string state, string lineOfBusiness, string coverageOption, int type, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesUnmannedAircraftMinMaxFactor :: Started");

                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@CoverageOption", Value = coverageOption, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Type", Value = type, SqlDbType = SqlDbType.Int };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesUnmannedAircraftMinMaxFactor, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("LawDataAccess.GetProfLinesUnmannedAircraftMinMaxFactor :: Completed");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("LawDataAccess.GetProfLinesUnmannedAircraftMinMaxFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting GetProfLinesExcessExposure Form table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverageName"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>string</returns>
        public string GetProfLinesExcessExposure(string state, string primaryClass, string coverageName, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                this.logger.Info("LawDataAccess.GetProfLinesExcessExposure :: Started");

                string excessExposure = null;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                excessExposure = this.GetExcessExposureDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesOptionalCoverageInExcessExposure, commandParameters);

                this.logger.Info("LawDataAccess.GetProfLinesExcessExposure :: Completed");

                return excessExposure;
            }
            catch (Exception ex)
            {
                this.logger.Error("LawDataAccess.GetProfLinesExcessExposure :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

    }
}
