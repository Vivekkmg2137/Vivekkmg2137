﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
    public class OCPDataAccess: DataAccess
    {

        public OCPDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {

            
        }

        public decimal GetOcpBasePremium(decimal Limit, decimal AggregateLimit, string Description, string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("GetOcpBasePremium :: GetOcpBasePremium in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Limit", Value = Limit, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggrLimit", Value = AggregateLimit, SqlDbType = SqlDbType.Int };
                commandParameters[4] = new SqlParameter { ParameterName = "@Description", Value = Description, SqlDbType = SqlDbType.VarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure,
                    StoredProcedureConstant.Trident_GetOCPRate, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            baseRate = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("GetOcpBasePremium :: GetOcpBasePremium ::" + ex.Message);
                throw;
            }

        }

        public decimal GetOCPMiscFactor(string state, string lineOfBusiness,string factorType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("GetOCPMiscFactor :: GetOCPMiscFactor in process");
                decimal miscFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure,
                    StoredProcedureConstant.Trident_GetOCPMiscFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            miscFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return miscFactor;
            }
            catch (Exception ex)
            {
                logger.Error("GetOCPMiscFactor :: GetOCPMiscFactor ::" + ex.Message);
                throw;
            }

        }

    }
}
