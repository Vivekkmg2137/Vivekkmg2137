﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess
{
    /// <summary>
    /// Property360DataAccess : Data access layer for calculation of property360 premium.
    /// </summary>
    public class Property360DataAccess : DataAccess
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Property360DataAccess"/> class.
        /// </summary>
        /// <param name="logger">ILoggingManager.</param>
        public Property360DataAccess(IConfiguration configuration, ILoggingManager logger)
            : base(configuration, logger)
        {
        }

        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting DeductibleFactor from DollarDeuctibleCredit lookup table
        /// </summary>
        /// <param name="deductible"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetDollarDeductibleFactor(decimal deductible, string state, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.860;
                }
                this.logger.Info("Property360DataAccess.GetDollarDeductibleFactor :: Started");
                decimal deductibleFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                deductibleFactor = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetDollarDeductibleFactor, commandParameters);

                this.logger.Info("Property360DataAccess.GetDollarDeductibleFactor :: Completed");
                return deductibleFactor;
            }
            catch (Exception ex)
            {
                this.logger.Error("Property360DataAccess.GetDollarDeductibleFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting GetBIEEDeductibleFactor
        /// </summary>
        /// <param name="deductible"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetBIEEDeductibleFactor(decimal deductible, string state, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.860;
                }
                this.logger.Info("Property360DataAccess.GetBIEEDeductibleFactor :: Started");
                decimal deductibleFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                deductibleFactor = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetBIEEDeductibleFactor, commandParameters);

                this.logger.Info("Property360DataAccess.GetBIEEDeductibleFactor :: Completed");
                return deductibleFactor;
            }
            catch (Exception ex)
            {
                this.logger.Error("Property360DataAccess.GetBIEEDeductibleFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }        

        /// <summary>
        /// Get360CoverageDeductibleFactor
        /// </summary>
        /// <param name="coverageName"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="deductibleType"></param>
        /// <returns></returns>
        public decimal Get360CoverageDeductibleFactor(string coverageName, string state, string lineOfBusiness, DateTime policyEffectiveDate,string deductibleType)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.860;
                }
                this.logger.Info("Property360DataAccess.Get360CoverageDeductibleFactor :: Started");
                decimal deductibleFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Type", Value = deductibleType, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@CoverageName", Value = coverageName, SqlDbType = SqlDbType.VarChar };

                deductibleFactor = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetCoverageDeductibleFactor, commandParameters);

                this.logger.Info("Property360DataAccess.Get360CoverageDeductibleFactor :: Completed");
                return deductibleFactor;
            }
            catch (Exception ex)
            {
                this.logger.Error("Property360DataAccess.Get360CoverageDeductibleFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetProperty360CoverageDetail
        /// </summary>
        /// <param name="coverageName"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="primaryClassCode"></param>
        /// <param name="factorType"></param>
        /// <returns></returns>
        public decimal GetProperty360CoverageDetail(string coverageName, string state, string lineOfBusiness, DateTime policyEffectiveDate,string primaryClassCode,string factorType)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.860;
                }
                this.logger.Info("Property360DataAccess.GetProperty360CoverageDetail :: Started");
                decimal detailFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@CoverageName", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Type", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                detailFactor = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetCoverageDetail, commandParameters);

                this.logger.Info("Property360DataAccess.GetProperty360CoverageDetail :: Completed");
                return detailFactor;
            }
            catch (Exception ex)
            {
                this.logger.Error("Property360DataAccess.GetProperty360CoverageDetail :: Exception :: " + ex.Message, ex);
               throw;
            }
        }

        /// <summary>
        /// GetMiscellaneousFactor
        /// </summary>
        /// <param name="factorType"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public DataTable GetTeeToGreenFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate,string factorType)
        {
            DataTable dataTable = null;
            try
            {                
                this.logger.Info("Property360DataAccess.GetTeeToGreenFactor :: Started");
                
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetTeeToGreenFactor, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables!=null && dataSet.Tables[0]!=null)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }               

                this.logger.Info("Property360DataAccess.GetTeeToGreenFactor :: Completed");                
            }
            catch (Exception ex)
            {
                this.logger.Error("Property360DataAccess.GetTeeToGreenFactor :: Exception :: " + ex.Message, ex);
               throw;
            }
            return dataTable;
        }

        /// <summary>
        /// GetBIEEDaysFactor
        /// </summary>
        /// <param name="numberOfDays"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetBIEEDaysFactor(int numberOfDays,string state,string lineOfBusiness,DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.860;
                }
                this.logger.Info("Property360DataAccess.GetBIEEDaysFactor :: Started");
                decimal factorValue = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@NumDays", Value = numberOfDays, SqlDbType = SqlDbType.Int };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                factorValue = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetBIEEDaysFactor, commandParameters);

                this.logger.Info("Property360DataAccess.GetBIEEDaysFactor :: Completed");
                return factorValue;
            }
            catch (Exception ex)
            {
                this.logger.Error("Property360DataAccess.GetBIEEDaysFactor :: Exception :: " + ex.Message, ex);
               throw;
            }
        }

        /// <summary>
        /// GetSpoilageRate
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="deductible"></param>
        /// <returns></returns>
        public decimal GetSpoilageRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, decimal deductible)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.860;
                }
                this.logger.Info("Property360DataAccess.GetSpoilageRate :: Started");
                decimal factorValue = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                factorValue = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetSpoilageRate, commandParameters);

                this.logger.Info("Property360DataAccess.GetSpoilageRate :: Completed");
                return factorValue;
            }
            catch (Exception ex)
            {
                this.logger.Error("Property360DataAccess.GetBIEEDaysFactor :: Exception :: " + ex.Message, ex);
               throw;
            }
        }

        /// <summary>
        /// GetCoverageDetailForAdditionalBenefits
        /// </summary>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public DataSet GetCoverageDetailForAdditionalBenefits(DateTime policyEffectiveDate)
        {
            try
            {
                this.logger.Info("Property360DataAccess.GetCoverageDetailForAdditionalBenefits :: Started");
                SqlParameter[] commandParameters = new SqlParameter[1];
                commandParameters[0] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                DataSet ds = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetCoverageDetailForAdditionalBenefits, commandParameters);
                this.logger.Info("Property360DataAccess.GetCoverageDetailForAdditionalBenefits :: Completed");
                return ds;
            }
            catch (Exception ex)
            {
                this.logger.Error("Property360DataAccess.GetCoverageDetailForAdditionalBenefits :: Exception :: " + ex.Message, ex);
               throw;
            }
        }

    }
}
