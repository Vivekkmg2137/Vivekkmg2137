﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
    /// <summary>
    /// PropertyDataAccess : Data access layer for calculation of property general premium.
    /// </summary>
    public class PropertyDataAccess : DataAccess
    {
        public PropertyDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {
        }

        //public BaseRaterModel GetQuoteDetail(int quoteId)
        //{
        //    return new BaseRaterModel { Id = quoteId, LineOfBusiness = "Propery", State = "NY" };
        //}

        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting BuildingBaseMLR from  MiscFactors lookup table
        /// </summary>
        /// <param name="primaryClass"></param>
        /// <param name="secondaryClass"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="factorFor"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns> </returns>
        public decimal GetBuildingOrContentBaseMLRFactor(string primaryClass, string secondaryClass, string state, string lineOfBusiness, string factorFor, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    if (factorFor == "Building")
                    {
                        return 0.030M;
                    }
                    else
                    {
                        return 0.120M;
                    }
                }
                else
                {
                    string factorType = "Class Group Rate";
                    string storedProcedureName = StoredProcedureConstant.Trident_GetBuildingBaseMLR;  // String enum

                    if (factorFor == "Contents")
                    {
                        storedProcedureName = StoredProcedureConstant.Trident_GetContentsBaseMLR;
                    }

                    this.logger.Info("PropertyDataAccess.GetBuildingOrContentBaseMLRFactor  :: Started");
                    decimal buildingOrContentBaseMLRFactor = 0;
                    SqlParameter[] commandParameters = new SqlParameter[6];
                    commandParameters[0] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                    commandParameters[1] = new SqlParameter { ParameterName = "@SecondaryClassCode", Value = secondaryClass, SqlDbType = SqlDbType.VarChar };
                    commandParameters[2] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                    commandParameters[3] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                    commandParameters[4] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                    commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                    buildingOrContentBaseMLRFactor = this.GetDataFromDataReader(storedProcedureName, commandParameters);
                    this.logger.Info("PropertyDataAccess.GetBuildingOrContentBaseMLRFactor  :: Completed");
                    return buildingOrContentBaseMLRFactor;
                }
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess.GetBuildingOrContentBaseMLRFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting BuildingAdditionalDeficiencyCharge from MajorLossRateCharges lookup table
        /// </summary>
        /// <param name="buildingDefPoints"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="chargeType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetBuildingMajorLossRateCharge(decimal buildingDefPoints, string state, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    if (buildingDefPoints > 5400)
                    {
                        return (decimal)0.950;
                    }
                    else
                    {
                        return (decimal)0.590;
                    }
                }
                else
                {
                    this.logger.Info("PropertyDataAccess.GetBuildingMajorLossRateCharge :: Started");
                    decimal buildingDeficiencyCharge = 0;
                    SqlParameter[] commandParameters = new SqlParameter[4];
                    commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                    commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                    commandParameters[2] = new SqlParameter { ParameterName = "@BuildingDefPts", Value = buildingDefPoints, SqlDbType = SqlDbType.VarChar };
                    commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                    buildingDeficiencyCharge = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetBuildingMajorLossRateCharge, commandParameters);
                    this.logger.Info("PropertyDataAccess.GetBuildingMajorLossRateCharge :: Completed");
                    return buildingDeficiencyCharge;
                }
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess :: GetBuildingMajorLossRateCharge ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting ContentAdditionalDeficiencyCharge from MajorLossRateCharges lookup table
        /// </summary>
        /// <param name="ContentDefPoints"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="chargeType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetContentsMajorLossRateCharge(decimal ContentsDefTotalPoints, string state, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    if (ContentsDefTotalPoints > 5400)
                        return (decimal)0.950;
                    else
                        return (decimal)0.590;
                }
                else
                {
                    this.logger.Info("PropertyDataAccess.GetContentsMajorLossRateCharge :: Started");
                    decimal contentDeficiencyCharge = 0;
                    SqlParameter[] commandParameters = new SqlParameter[4];
                    commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                    commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                    commandParameters[2] = new SqlParameter { ParameterName = "@ContentsDefPts", Value = ContentsDefTotalPoints, SqlDbType = SqlDbType.Decimal };
                    commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                    contentDeficiencyCharge = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetContentsMajorLossRateCharge, commandParameters);

                    this.logger.Info("PropertyDataAccess.GetContentsMajorLossRateCharge :: Completed");
                    return contentDeficiencyCharge;
                }
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess.GetContentsMajorLossRateCharge :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting charge from from MiscFactors lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="chargeType"></param>
        /// <param name="factorType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetBuildingAdditionalDefCharge(string state, string lineOfBusiness, decimal buildingDefPts, string factorType, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 0;
                }

                this.logger.Info("PropertyDataAccess.GetBuildingAdditionalDefCharge :: Started");
                decimal buildingAdditionalDefCharge = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@BuildingDefPts", Value = buildingDefPts, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                buildingAdditionalDefCharge = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetBuildingAddtlDefCharge, commandParameters);

                return buildingAdditionalDefCharge;
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess.GetBuildingAdditionalDefCharge :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting charge from from MiscFactors lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="chargeType"></param>
        /// <param name="factorType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetContentsAdditionalDefCharge(string state, string lineOfBusiness, decimal ContentsDefPts, string factorType, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 0;
                }

                this.logger.Info("PropertyDataAccess.GetContentsAdditionalDefCharge :: Started");
                decimal contentsAdditionalDefCharge = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@ContentsDefPts", Value = ContentsDefPts, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                contentsAdditionalDefCharge = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetContentsAddtlDefCharge, commandParameters);

                this.logger.Info("PropertyDataAccess.GetContentsAdditionalDefCharge :: Completed");
                return contentsAdditionalDefCharge;
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess.GetContentsAdditionalDefCharge :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting DeductibleFactor from DollarDeuctibleCredit lookup table
        /// </summary>
        /// <param name="deductible"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetDeductibleFactor(decimal deductible, string state, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.860;
                }
                this.logger.Info("PropertyDataAccess.GetDeductibleFactor :: Started");
                decimal deductibleFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                deductibleFactor = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetDollarDeductibleFactor, commandParameters);

                this.logger.Info("PropertyDataAccess.GetDeductibleFactor :: Completed");
                return deductibleFactor;
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess.GetDeductibleFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting EquipmentBreakdownDeductibleFactor from EBDeductibleFactors table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="equipmentBreakdownDeductible"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetEquipmentBreakdownDeductibleFactor(string state, string lineOfBusiness, string primaryClass, decimal equipmentBreakdownDeductible, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 1.000M;
                }

                this.logger.Info("PropertyDataAccess :: GetEquipmentBreakdownDeductibleFactor in process");
                decimal equipmentBreakdownDeductibleFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@EBDeductible", Value = equipmentBreakdownDeductible, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                equipmentBreakdownDeductibleFactor = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetEBDeductibleFactor, commandParameters);

                this.logger.Info("PropertyDataAccess.GetEquipmentBreakdownDeductibleFactor :: Completed");
                return equipmentBreakdownDeductibleFactor;
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess.GetEquipmentBreakdownDeductibleFactor :: Exception :: " + ex.Message);
                throw;
            }
        }
        /// <summary>
        /// Getting BusinessIncomeAndExtraExpenseDeductibleFactor from EBBIDeductibleFactors table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="businessIncomeAndExtraExpenseDeductible"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetBusinessIncomeAndExtraExpenseDeductibleFactor(string state, string lineOfBusiness, string primaryClass, decimal businessIncomeAndExtraExpenseDeductible, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 0.885M;
                }
                this.logger.Info("PropertyDataAccess.GetBusinessIncomeAndExtraExpenseDeductibleFactor :: Started");
                decimal aopDeductibleFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@EBBIDeductible", Value = businessIncomeAndExtraExpenseDeductible, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                aopDeductibleFactor = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetEBBIDeductibleFactor, commandParameters);
                this.logger.Info("PropertyDataAccess.GetBusinessIncomeAndExtraExpenseDeductibleFactor :: Completed");

                return aopDeductibleFactor;
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess.GetBusinessIncomeAndExtraExpenseDeductibleFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Getting EquipmentBreakdownLimitFactor from EBLimitFactors table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetEquipmentBreakdownLimitFactor(string state, string lineOfBusiness, string primaryClass, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.0085;
                }
                this.logger.Info("PropertyDataAccess :: GetEquipmentBreakdownLimitFactor in process");
                decimal equipmentBreakdownLimitFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetEBLimitFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            equipmentBreakdownLimitFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return equipmentBreakdownLimitFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetEquipmentBreakdownLimitFactor ::" + ex.Message);
                throw;
            }

        }

        /// <summary>
        /// Getting CoinsuranceFactor from CoinsuranceFactors table
        /// </summary>
        /// <param name="coinsurance"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetCoinsuranceFactor(string coinsurance, string state, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)1.050;
                }
                this.logger.Info("PropertyDataAccess :: GetCoinsuranceFactor in process");
                decimal coinsuranceFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Coinsurance", Value = coinsurance, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetCoinsurance, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            coinsuranceFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return coinsuranceFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetCoinsuranceFactor ::" + ex.Message);
                throw;
            }

        }

        /// <summary>
        /// Getting EquipmentBreakdownSpoilageDollarDeductible from EBSpoilageDollarDeductible
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="spoilageMinimumDeductible"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetEquipmentBreakdownSpoilageDollarDeductible(string state, string primaryClass, string lineOfBusiness, decimal spoilageMinimumDeductible, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 0;
                }
                this.logger.Info("PropertyDataAccess :: GetEquipmentBreakdownSpoilageDollarDeductible in process");
                decimal equipmentBreakdownSpoilagePercentageDeductibleFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@SpoilageDeductible", Value = spoilageMinimumDeductible, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetEBSpoilageDollarDeductibleFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            equipmentBreakdownSpoilagePercentageDeductibleFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return equipmentBreakdownSpoilagePercentageDeductibleFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetEquipmentBreakdownSpoilageDollarDeductible ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting EquipmentBreakdownSpoilagePercentageDeductibleFactor from EBSpoilagePercentageDeductible
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetEquipmentBreakdownSpoilagePercentageDeductibleFactor(string state, string lineOfBusiness, decimal spoilageDeductible, DateTime policyEffectiveDate) //, decimal spoilageDeductible
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 0;
                }
                this.logger.Info("PropertyDataAccess :: GetEquipmentBreakdownSpoilagePercentageDeductibleFactor in process");
                decimal equipmentBreakdownSpoilagePercentageDeductibleFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@SpoilageDeductible", Value = spoilageDeductible, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetEBSpoilagePercentageDeductibleFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            equipmentBreakdownSpoilagePercentageDeductibleFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return equipmentBreakdownSpoilagePercentageDeductibleFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetEquipmentBreakdownSpoilagePercentageDeductibleFactor ::" + ex.Message);
                throw;
            }

        }

        /// <summary>
        /// Getting PollutantCleanUpLimitFactor from EBCoverageLimitFactors
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="limit"></param>
        /// <param name="limitType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetPollutantCleanUpLimitFactor(string state, string lineOfBusiness, decimal limit, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.041;
                }
                this.logger.Info("PropertyDataAccess :: GetPollutantCleanUpLimitFactor in process");
                decimal pollutantCleanUpLimitFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetPollutantCleanUpLimitFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            pollutantCleanUpLimitFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return pollutantCleanUpLimitFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetPollutantCleanUpLimitFactor ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting RefrigerantContaminationLimitFactor from EBCoverageLimitFactors
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="limit"></param>
        /// <param name="limitType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetRefrigerantContaminationLimitFactor(string state, string lineOfBusiness, decimal limit, DateTime policyEffectiveDate)
        {
            try
            {
                if (!IsAccessLookUpData)
                {
                    return (decimal)0.027;
                }
                this.logger.Info("PropertyDataAccess :: GetRefrigerantContaminationLimitFactor in process");
                decimal refrigerantContaminationLimitFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetRefrigerantContaminationLimitFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            refrigerantContaminationLimitFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return refrigerantContaminationLimitFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetRefrigerantContaminationLimitFactor ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting GetSpoilageLimitFactor from EBCoverageLimitFactors
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="limit"></param>
        /// <param name="limitType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetSpoilageLimitFactor(string state, string lineOfBusiness, decimal limit, string SpoilageType, DateTime policyEffectiveDate)
        {
            try
            {
                if (!IsAccessLookUpData)
                {
                    return (decimal)0.028;
                }
                this.logger.Info("PropertyDataAccess :: GetSpoilageLimitFactor in process");
                decimal spoilageTypeLimitFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Type", Value = SpoilageType, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetSpoilageTypeLimitFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            spoilageTypeLimitFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return spoilageTypeLimitFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetSpoilageType1LimitFactor ::" + ex.Message);
                throw;
            }
        }


        /// <summary>
        /// Getting MarginClauseFactor from MarginClauseFactors table
        /// </summary>
        /// <param name="marginClause"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetMarginClauseFactors(string marginClause, string state, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)0.930;
                }
                this.logger.Info("PropertyDataAccess :: GetMarginClauseFactors in process");
                decimal marginClauseFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@MarginClause", Value = marginClause, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetMarginClause, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            marginClauseFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return marginClauseFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetMarginClauseFactors ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Read the Table -> Minimum Premium to get the EB Minimum Premium value.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="premiumType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetPropertyMinimumPremium(string state, string lineOfBusiness, string primaryClass, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("PropertyDataAccess :: GetPropertyMinimumPremium in process");
                decimal propertyMinimumPremium = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetEquipmentBreakdownTotalPremium, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            propertyMinimumPremium = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return propertyMinimumPremium;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetPropertyMinimumPremium ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Getting ValuationFactor from ValuationFactors table
        /// </summary>
        /// <param name="valuation"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetValuationFactors(string valuation, string state, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 1;
                }
                this.logger.Info("PropertyDataAccess :: GetValuationFactors in process");
                decimal valuationFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Valuation", Value = valuation, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetValuation, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            valuationFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return valuationFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetValuationFactors ::" + ex.Message);
                throw;
            }

        }

        /// <summary>
        /// Getting 'LCMFactor' from MiscFactors table.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="factorType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetNormalLossRateLCMFactor(string state, string lineOfBusiness, string factorType, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 0;
                }
                this.logger.Info("PropertyDataAccess :: GetNormalLossRateLCMFactor in process");
                decimal normalLossLCMFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetLCM, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            normalLossLCMFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return normalLossLCMFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetNormalLossRateLCMFactor ::" + ex.Message);
                throw;
            }

        }

        /// <summary>
        /// Getting ModifiedNormalLossRate from MiscFactors table.
        /// </summary>
        /// <param name="deductible"></param>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="normalLossRate"></param>
        /// <param name="factorType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal ModifiedNormalLossRate(decimal deductible, string state, string lineOfBusiness, decimal normalLossRate, string factorType, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 0;
                }
                this.logger.Info("PropertyDataAccess :: ModifiedNormalLossRate in process");
                decimal modifiedNormalLossRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@NormalLossRate", Value = normalLossRate, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetModifiedNormalLossRate, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            if (sqlDataReader[0] != DBNull.Value)
                            {
                                modifiedNormalLossRate = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);//
                            }
                        }
                    }
                }

                return modifiedNormalLossRate;
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess :: ModifiedNormalLossRate ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Refer to the lookup table to get the LCM factor
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="factorType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetMiscFactor(string state, string lineOfBusiness, string factorType, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return (decimal)1.6;
                }

                this.logger.Info("PropertyDataAccess.GetMiscFactor :: Started");
                decimal tierFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetMiscFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            if (sqlDataReader[0] != DBNull.Value)
                            {
                                tierFactor = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                            }
                        }
                    }
                }

                this.logger.Info("PropertyDataAccess.GetMiscFactor :: Completed");
                return tierFactor;
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyDataAccess.GetMiscFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Read the terrorism Factor based on the State, LOB & Effective Date selected in a policy
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetTerrorismFactor(string state, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 0;
                }
                this.logger.Info("PropertyDataAccess :: GetTerrorismFactor in process");
                decimal terrorismFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[3];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetTerrorismFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            if (sqlDataReader[0] != DBNull.Value)
                            {
                                terrorismFactor = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                            }
                        }
                    }
                }

                return terrorismFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetTerrorismFactor ::" + ex.Message);
                throw;
            }

        }

        /// <summary>
        /// Read the Table -> Minimum Premium to get the EB Minimum Premium value.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="premiumType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetLOBTotalPremium(string state, string lineOfBusiness, string primaryClass, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("PropertyDataAccess :: GetLOBTotalPremium in process");
                decimal lOBTotalPremium = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetLOBTotalPremium, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            lOBTotalPremium = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return lOBTotalPremium;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetLOBTotalPremium ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Read table using following as input parameters to get the Misc.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="factorType"></param>
        /// <param name="lineOfBusiness"></param>
        /// <returns></returns>
        public decimal GetMNFireSafetySurcharge(string state, string primaryClass, string lineOfBusiness, string factorType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("PropertyDataAccess :: GetInflationGuard in process");
                decimal nYFireInsuranceFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetMNFireSafetySurcharge, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            nYFireInsuranceFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return nYFireInsuranceFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetInflationGuard ::" + ex.Message);
                throw;
            }
        }


        #region NY DataAccess
        /// <summary>
        /// Read table using following as input parameters to get the Cause of Loss rate.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="causeOfLoss"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetCauseOfLoss(string state, string lineOfBusiness, string causeOfLoss, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("PropertyDataAccess :: GetCauseOfLoss in process");
                decimal causeOfLossFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@CauseOfLoss", Value = causeOfLoss, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetCauseOfLossFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            causeOfLossFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return causeOfLossFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetCauseOfLoss ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Read table using following as input parameters to get the Inflation Guard.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="inflationGuard"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetInflationGuard(string state, string lineOfBusiness, decimal inflationGuard, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("PropertyDataAccess :: GetInflationGuard in process");
                decimal inflationGuardFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@InflationGuard", Value = inflationGuard, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetInflationGuardFactor, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            inflationGuardFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return inflationGuardFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetInflationGuard ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Read table using following as input parameters to get the Base Rates.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="inflationGuard"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns></returns>
        public decimal GetBaseRates(string state, string primaryClass, decimal hazardGroup, decimal protectionClass, string constructionType, string lineOfBusiness, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("PropertyDataAccess :: GetInflationGuard in process");
                decimal baseRate = 0;
                SqlParameter[] commandParameters = new SqlParameter[7];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@HazardGroupId", Value = hazardGroup, SqlDbType = SqlDbType.Int };
                commandParameters[4] = new SqlParameter { ParameterName = "@ProtectionClassId", Value = protectionClass, SqlDbType = SqlDbType.Int };
                commandParameters[5] = new SqlParameter { ParameterName = "@ConstructionType", Value = constructionType, SqlDbType = SqlDbType.VarChar };
                commandParameters[6] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetNYBaseRates, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            baseRate = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return baseRate;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetInflationGuard ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// Read table using following as input parameters to get the Misc.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="factorType"></param>
        /// <param name="lineOfBusiness"></param>
        /// <returns></returns>
        public decimal GetNYFireInsuranceFee(string state, string primaryClass, string lineOfBusiness, string factorType, DateTime policyEffectiveDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("PropertyDataAccess :: GetInflationGuard in process");
                decimal nYFireInsuranceFactor = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetNYFireInsuranceFee, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            nYFireInsuranceFactor = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return nYFireInsuranceFactor;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess :: GetInflationGuard ::" + ex.Message);
                throw;
            }
        }
        #endregion

        public DataTable GetMinMaxValueForFactor(string state, string primaryClass, string lineOfBusiness, string factorType, DateTime policyEffectiveDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PropertyDataAccess.GetMinMaxValueForFactor Started");

                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@FactorType", Value = factorType, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetMinMaxValueForFactor, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("PropertyDataAccess.GetMinMaxValueForFactor Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess.GetMinMaxValueForFactor :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public DataTable GetMinMaxValueForHazard(string state, string lineOfBusiness, string category, string subCategory, string justification, DateTime policyEffectiveDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PropertyDataAccess.GetMinMaxValueForHazard Started");

                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Category", Value = category, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@SubCategory", Value = subCategory, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Justification", Value = justification, SqlDbType = SqlDbType.VarChar };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetMinMaxValueForHazard, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("PropertyDataAccess.GetMinMaxValueForHazard Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess.GetMinMaxValueForHazard :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

       

        public DataTable GetStateList(DateTime policyEffectiveDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PropertyDataAccess.GetStateList Started");

                SqlParameter[] commandParameters = new SqlParameter[1];
                commandParameters[0] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetStateList, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }

                this.logger.Info("PropertyDataAccess.GetStateList Completed.");
                return dataTable;
            }
            catch (Exception ex)
            {
                logger.Error("PropertyDataAccess.GetStateList :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
    }
}
