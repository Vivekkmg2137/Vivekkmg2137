﻿using Logging;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccess
{
    /// <summary>
    /// PublicOfficialsCDataAccess : Data access layer for calculation of PublicOfficials general premium.
    /// </summary>
    public class PublicOfficialsDataAccess : DataAccess
    {
        /// <summary>
        /// PublicOfficialsDataAccess
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public PublicOfficialsDataAccess(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {
        }

        /// <summary>
        /// GetDataFromDataReader
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="commandParameters"></param>
        /// <returns></returns>
        private decimal GetDataFromDataReader(string procedureName, SqlParameter[] commandParameters)
        {
            decimal expectedValue = 0;
            using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, procedureName, commandParameters))
            {
                if (sqlDataReader != null && sqlDataReader.HasRows)
                {
                    while (sqlDataReader.Read())
                    {
                        if (sqlDataReader[0] != DBNull.Value)
                        {
                            expectedValue = Convert.ToDecimal(sqlDataReader[0]); // sqlDataReader.GetDecimal(0);
                        }
                    }
                }
            }

            return expectedValue;
        }

        /// <summary>
        /// Getting RatingBasis from Rating Basis Parameter lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetRatingBasisParameter(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetRatingBasisParameter :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetRatingBasisParameter, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetRatingBasisParameter ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// Getting ExposureRate from Base Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesExposureRate(string state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesExposureRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesExposureRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesExposureRate ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// GetProfLinesPOInclExclRate
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="ePCoverage"></param>
        /// <param name="item"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPOInclExclRate(string state, string lineOfBusiness, String ePCoverage, String item, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesPOInclExclRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@EPCoverage", Value = ePCoverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Item", Value = item, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPOInclExclRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesPOInclExclRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting LiabilityLimitRate from Limit Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesLiabilityLimitRate(string state, string lineOfBusiness, decimal liabilityLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesLiabilityLimitRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesLiabilityLimitRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting AggregateLimitRate from Limit Aggregate Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="aggregateLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesAggregateLimitRate(string state, string lineOfBusiness, decimal liabilityLimit, decimal aggregateLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesLiabilityLimitRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesAggregateLimitRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesLiabilityLimitRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting AggregateLimitRate from Limit Aggregate Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="deductibleSIR"></param>
        /// <param name="retention"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesRetentionRate(string state, string lineOfBusiness, string deductibleSIR, string retention, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesRetentionRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIRType", Value = deductibleSIR, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Retention", Value = retention, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetentionRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesRetentionRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting PopulationRate from Limit Population Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClassCode"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="population"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPopulationRate(string state, string primaryClassCode, string lineOfBusiness, decimal population, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesPopulationRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Population", Value = population, SqlDbType = SqlDbType.Decimal };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPopulationRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesPopulationRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting PopulationRate from Limit Population Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="locationType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesLocationRate(string state, string lineOfBusiness, string locationType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesLocationRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LocationType", Value = locationType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLocationRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesLocationRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting PolicyTypeRate from Limit PolicyTypeRate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPolicyTypeRate(string state, string lineOfBusiness, string policyType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesPolicyTypeRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyType", Value = policyType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPolicyTypeRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesPolicyTypeRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting Years in CM Program Rate from Limit Years in CM Program Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="years"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesCMPolicyYearRate(string state, string lineOfBusiness, int years, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesCMPolicyYearRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@Years", Value = years, SqlDbType = SqlDbType.Int };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesCMPolicyYearRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesCMPolicyYearRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting Years in RetroDateRate in Retro Active Factor lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="retroYear"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesRetroDateRate(string state, string lineOfBusiness, string retroYear, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesRetroDateRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@RetroYear", Value = retroYear, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesRetroDateRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesRetroDateRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting Years in RetroDateRate in Retro Active Factor lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="isLossExpApplied"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesLossExperienceRate(string state, string lineOfBusiness, int isLossExpApplied, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesRetroDateRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@IsLossExpApplied", Value = isLossExpApplied, SqlDbType = SqlDbType.Bit };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesLossExperienceRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesLossExperienceRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// GetProfLinesApplicableOptionalCoverage
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClassCode"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesApplicableOptionalCoverage(string state, string primaryClassCode, string lineOfBusiness, string coverage, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesApplicableOptionalCoverage :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesApplicableOptionalCoverage, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesApplicableOptionalCoverage ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// GetProfLinesTierRate
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="tierType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesTierRate(string state, string lineOfBusiness, string tierType, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesTierRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@TierType", Value = tierType, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesTierRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesTierRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }


        /// <summary>
        /// Read the Table -> Minimum Premium to get the EB Minimum Premium value.
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="primaryClass"></param>
        /// <param name="premiumType"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetLOBTotalPremium(string state, string lineOfBusiness, string primaryClass, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return 25;
                }
                this.logger.Info("PublicOfficialsDataAccess.GetLOBTotalPremium :: Starting");
                decimal lOBTotalPremium = 0;
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.VarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesMinimumPremium, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            lOBTotalPremium = Convert.ToDecimal(sqlDataReader[0]); //sqlDataReader.GetDecimal(0);//
                        }
                    }
                }

                return lOBTotalPremium;
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetLOBTotalPremium ::" + ex.Message);
                throw;
            }
        }

        /// <summary>
        /// GetProfLinesLiabilityLimitRateMinMax
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="liabilityLimit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesLiabilityLimitRateMinMax(string state, string lineOfBusiness, decimal liabilityLimit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesLiabilityLimitRateMinMax :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = liabilityLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesLiabilityLimitRateMinMax in completed");
            }

            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesLiabilityLimitRateMinMax ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// GetProfLinesApplicableDeductible
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="dedSIR"></param>
        /// <param name="deductible"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesApplicableDeductible(string state, string lineOfBusiness, string dedSIR, string deductible, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesApplicableDeductible :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@DedSIR", Value = dedSIR, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Deductible", Value = deductible, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesApplicableDeductible, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesApplicableDeductible in completed");
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesApplicableDeductible ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// GetIRPMRateMinMax
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetIRPMRateMinMax(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetIRPMRateMinMax :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesIRPMRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("PublicOfficialsDataAccess.GetIRPMRateMinMax completed");
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetIRPMRateMinMax ::" + ex.Message);
                throw;
            }
            return dataTable;
        }

        /// <summary>
        /// GetOtherModRateMinMax
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetOtherModRateMinMax(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetOtherModRateMinMax :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesOtherModRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("PublicOfficialsDataAccess.GetOtherModRateMinMax completed");
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetOtherModRateMinMax ::" + ex.Message);
                throw;
            }
            return dataTable;
        }

        /// <summary>
        /// GetProfLinesApplicableOptionalCoverage
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClassCode"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetCheckProfLinesApplicableOptionalCoverage(string state, string primaryClassCode, string lineOfBusiness, string coverage, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesApplicableOptionalCoverage :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClassCode, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesApplicableOptionalCoverage, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesApplicableOptionalCoverage completed");
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesApplicableOptionalCoverage ::" + ex.Message);
                throw;
            }
            return dataTable;
        }

        ///<summary>
        /// Getting AggregateLimitRate from Limit Aggregate Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="limit"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>DataTable</returns>
        public DataTable GetProfLinesNYEPLimitRate(string state, string lineOfBusiness, decimal limit, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            DataTable dataTable = null;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesNYEPLimitRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[5];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LiabilityLimit", Value = limit, SqlDbType = SqlDbType.Decimal };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                using (DataSet dataSet = SqlHelper.ExecuteDataset(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesLiabilityLimitRate, commandParameters))
                {
                    if (dataSet != null && dataSet.Tables != null && dataSet.Tables[0] != null && dataSet.Tables[0].Rows.Count > 0)
                    {
                        dataTable = dataSet.Tables[0];
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesNYEPLimitRate ::" + ex.Message);
                throw ex;
            }
            return dataTable;
        }

        /// <summary>
        /// GetProfLinesPOOptionalCoveragePremium
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="limit"></param>
        /// <param name="aggregateLimit"></param>
        /// <param name="ratingBasis"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPOOptionalCoveragePremium(string state, string primaryClass, string lineOfBusiness, string coverage, decimal limit,decimal aggregateLimit, string ratingBasis, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;

            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesPOOptionalCoveragePremium :: Starting");

                SqlParameter[] commandParameters = new SqlParameter[9];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.Decimal };
                commandParameters[5] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[6] = new SqlParameter { ParameterName = "@RatingBasis", Value = ratingBasis, SqlDbType = SqlDbType.NVarChar };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[8] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPOOptionalCoveragePremium, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesPOOptionalCoveragePremium ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// GetProfLinesPOOptionalCoverageRate
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="coverage"></param>
        /// <param name="limit"></param>
        /// <param name="aggregateLimit"></param>
        /// <param name="ratingBasis"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns>decimal</returns>
        public decimal GetProfLinesPOOptionalCoverageRate(string state, string primaryClass, string lineOfBusiness, string coverage, decimal limit, decimal aggregateLimit, string ratingBasis, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;

            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesPOOptionalCoverageRate :: Starting");

                SqlParameter[] commandParameters = new SqlParameter[9];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverage, SqlDbType = SqlDbType.NVarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@Limit", Value = limit, SqlDbType = SqlDbType.Decimal };
                commandParameters[5] = new SqlParameter { ParameterName = "@AggregateLimit", Value = aggregateLimit, SqlDbType = SqlDbType.Decimal };
                commandParameters[6] = new SqlParameter { ParameterName = "@RatingBasis", Value = ratingBasis, SqlDbType = SqlDbType.NVarChar };
                commandParameters[7] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[8] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesPOOptionalCoverageRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesPOOptionalCoverageRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }


        /// <summary>
        /// Getting AggregateLimitRate from Limit Aggregate Rate lookup table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <param name="policyExpirationDate"></param>
        /// <returns></returns>
        public decimal GetProfLinesIRPMRate(string state, string lineOfBusiness, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            decimal rate = 0;
            try
            {
                this.logger.Info("PublicOfficialsDataAccess.GetProfLinesNYEPAggregateLimitRate :: Starting");
                SqlParameter[] commandParameters = new SqlParameter[4];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.NVarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[3] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };
                rate = this.GetDataFromDataReader(StoredProcedureConstant.Trident_GetProfLinesIRPMRate, commandParameters);
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetProfLinesIRPMRate ::" + ex.Message);
                throw ex;
            }
            return rate;
        }

        /// <summary>
        /// Getting GetOptionalCoveragePremium from table
        /// </summary>
        /// <param name="state"></param>
        /// <param name="primaryClass"></param>
        /// <param name="coverageName"></param>
        /// <param name="lineOfBusiness"></param>
        /// <param name="policyEffectiveDate"></param>
        /// <returns>string</returns>
        public string GetPOCoverageInExcessExposure(string state, string lineOfBusiness, string coverageName, string primaryClass, DateTime policyEffectiveDate, DateTime policyExpirationDate)
        {
            try
            {
                if (!this.IsAccessLookUpData)
                {
                    return "False";
                }
                this.logger.Info("PublicOfficialsDataAccess.GetPOCoverageInExcessExposure :: Starting");
                string excessExposure = "False";
                SqlParameter[] commandParameters = new SqlParameter[6];
                commandParameters[0] = new SqlParameter { ParameterName = "@StateCode", Value = state, SqlDbType = SqlDbType.VarChar };
                commandParameters[1] = new SqlParameter { ParameterName = "@PrimaryClassCode", Value = primaryClass, SqlDbType = SqlDbType.VarChar };
                commandParameters[2] = new SqlParameter { ParameterName = "@LOBCode", Value = lineOfBusiness, SqlDbType = SqlDbType.NVarChar };
                commandParameters[3] = new SqlParameter { ParameterName = "@Coverage", Value = coverageName, SqlDbType = SqlDbType.VarChar };
                commandParameters[4] = new SqlParameter { ParameterName = "@PolicyEffectiveDate", Value = policyEffectiveDate, SqlDbType = SqlDbType.DateTime };
                commandParameters[5] = new SqlParameter { ParameterName = "@PolicyExpirationDate", Value = policyExpirationDate, SqlDbType = SqlDbType.DateTime };

                using (SqlDataReader sqlDataReader = SqlHelper.ExecuteReader(this.DataSettings.SqlServerConnectionString, CommandType.StoredProcedure, StoredProcedureConstant.Trident_GetProfLinesOptionalCoverageInExcessExposure, commandParameters))
                {
                    if (sqlDataReader != null && sqlDataReader.HasRows)
                    {
                        while (sqlDataReader.Read())
                        {
                            if (sqlDataReader[0] != DBNull.Value)
                            {
                                excessExposure = sqlDataReader[0].ToString();
                            }
                        }
                    }
                }
                return excessExposure;
            }
            catch (Exception ex)
            {
                logger.Error("PublicOfficialsDataAccess.GetPOCoverageInExcessExposure ::" + ex.Message);
                throw;
            }

        }
    }
}
