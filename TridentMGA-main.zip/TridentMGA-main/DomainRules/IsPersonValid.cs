﻿using DomainValidationCore.Validation;
using Models;
using System.Text.RegularExpressions;

namespace DomainRules
{
    public class IsPersonValid : Validator<Person>
    {
        public IsPersonValid()
        {
            //Using standard
            Add("NameIsNotNullOrWhiteSpace", new Rule<Person>(new NameIsNotNullOrWhiteSpace(), "Name field is missing"));
            //Using Generics - Use this
            Add("NameIsNotNullOrWhiteSpace_Generic", new Rule<Person>(new IsNotNull<Person>(x => x.Name), "Generic Name field is missing"));

            Add("IsPersonInAdulthood", new Rule<Person>(new IsPersonInAdulthood(), "Your age must be at least 18 to sign"));
            Add("DocumentIsNotNullOrWhiteSpace", new Rule<Person>(new DocumentIsNotNullOrWhiteSpace(), "Document field is missing"));
            
            //Using standard
            Add("IsCpfValid", new Rule<Person>(new IsCpfValid(), "Invalid Document (CPF)"));
            //Using Generics and Regex - Use This
            Add("IsCpfValid_Generic", new Rule<Person>(new IsExpressionValid<Person>(x => Regex.IsMatch(x.Document, "\\d{11}")), "Invalid Document (CPF)"));

            //Using standard
            Add("IsBornAtValidDate", new Rule<Person>(new IsBornAtValidDate(), "BornAt field is missing"));
            //Using Generics - Use this
            Add("IsBornAtValidDate_Generic", new Rule<Person>(new IsNotNull<Person>(x => x.BirthDate), "BornAt field is missing"));
        }
    }
}
