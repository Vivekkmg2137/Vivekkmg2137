﻿using DomainValidationCore.Validation;
using Models.ApiModels.Policy;
using Models.ApiModels;
using System.Text.RegularExpressions;

namespace DomainRules
{
    public class IsPolicyHeaderValid : Validator<PolicyHeaderModel>
    {
        public IsPolicyHeaderValid()
        {
            //Using standard - use this for detailed multiline logic in a separate class
            Add("NameInsuredIsNotNullOrWhiteSpace", new Rule<PolicyHeaderModel>(new NameInsuredIsNotNullOrWhiteSpace(), "Name field is missing"));
           
            //Using Generics - Use this for inline processing
            Add("NameInsuredIsNotNullOrWhiteSpace_Generic", new Rule<PolicyHeaderModel>(new IsNotNull<PolicyHeaderModel>(x => x.NameInsured), "(Generic) Name field is missing"));

            //Using standard - use this for detailed multiline logic in a separate class
            Add("IsStateValid", new Rule<PolicyHeaderModel>(new IsStateValid(), "Invalid state"));
            //Using Generics and Regex - Use this for inline processing
            Add("IsStateValid_Generic", new Rule<PolicyHeaderModel>(new IsExpressionValid<PolicyHeaderModel>(x => Regex.IsMatch(x.State, "\\d{2}")), "(Generic) Invalid state"));

            //Using standard - use this for detailed multiline logic in a separate class
            Add("IsValidPolicyEffectiveDate", new Rule<PolicyHeaderModel>(new IsValidPolicyEffectiveDate(), "Effective date field is missing"));
            //Using Generics - Use this for inline processing
            Add("IsValidPolicyEffectiveDate_Generic", new Rule<PolicyHeaderModel>(new IsNotNull<PolicyHeaderModel>(x => x.PolicyEffectiveDate), "(Generic) effective date field is missing"));

            //Using standard - use this for detailed multiline logic in a separate class
            Add("IsValidControlNumber", new Rule<PolicyHeaderModel>(new IsValidControlNumber(), "Control number should be greater than 0"));
            Add("IsValidQuoteNumber", new Rule<PolicyHeaderModel>(new IsValidQuoteNumber(), "Quote number should be greater than 0"));
        }
    }
}
