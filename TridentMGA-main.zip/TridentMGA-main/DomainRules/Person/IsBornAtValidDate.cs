﻿using DomainValidationCore.Interfaces.Specification;
using Models;
using System;

namespace DomainRules
{
    public class IsBornAtValidDate : ISpecification<Person>
    {
        public bool IsSatisfiedBy(Person entity)
        {
            return entity.BirthDate != DateTime.MinValue;
        }
    }
}
