﻿using DomainValidationCore.Interfaces.Specification;
using Models;

namespace DomainRules
{
    public class IsPersonInAdulthood : ISpecification<Person>
    {
        public bool IsSatisfiedBy(Person entity)
        {
            return entity.Age > 17;
        }
    }
}
