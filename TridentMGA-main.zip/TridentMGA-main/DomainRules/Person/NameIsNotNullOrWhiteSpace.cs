﻿using DomainValidationCore.Interfaces.Specification;
using Models;

namespace DomainRules
{
    public class NameIsNotNullOrWhiteSpace : ISpecification<Person>
    {
        public bool IsSatisfiedBy(Person entity)
        {
            return !string.IsNullOrWhiteSpace(entity.Name);
        }
    }
}
