﻿using DomainValidationCore.Interfaces.Specification;
using Models.ApiModels.Policy;
using Models.ApiModels;

namespace DomainRules
{
    public class ClientIsNotNullOrWhiteSpace : ISpecification<PolicyHeaderModel>
    {
        public bool IsSatisfiedBy(PolicyHeaderModel entity)
        {
            return !string.IsNullOrWhiteSpace(entity.ClientId);
        }
    }
}
