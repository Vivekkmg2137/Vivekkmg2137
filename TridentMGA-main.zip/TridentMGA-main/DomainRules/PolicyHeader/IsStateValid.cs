﻿using DomainValidationCore.Interfaces.Specification;
using Models.ApiModels.Policy;
using Models.ApiModels;

namespace DomainRules
{
    public class IsStateValid : ISpecification<PolicyHeaderModel>
    {
        public bool IsSatisfiedBy(PolicyHeaderModel entity)
        {
            return entity.State.Length == 2 && long.TryParse(entity.State, out long i);
        }
    }
}
