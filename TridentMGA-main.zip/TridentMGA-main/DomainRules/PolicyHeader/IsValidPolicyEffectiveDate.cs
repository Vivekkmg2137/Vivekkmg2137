﻿using DomainValidationCore.Interfaces.Specification;
using Models.ApiModels.Policy;
using Models.ApiModels;
using System;

namespace DomainRules
{
    public class IsValidPolicyEffectiveDate : ISpecification<PolicyHeaderModel>
    {
        public bool IsSatisfiedBy(PolicyHeaderModel entity)
        {
            return entity.PolicyEffectiveDate != DateTime.MinValue;
        }
    }
}
