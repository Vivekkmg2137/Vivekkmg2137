﻿using DomainValidationCore.Interfaces.Specification;
using Models.ApiModels.Policy;
using Models.ApiModels;

namespace DomainRules
{
    public class NameInsuredIsNotNullOrWhiteSpace : ISpecification<PolicyHeaderModel>
    {
        public bool IsSatisfiedBy(PolicyHeaderModel entity)
        {
            return !string.IsNullOrWhiteSpace(entity.NameInsured);
        }
    }
}
