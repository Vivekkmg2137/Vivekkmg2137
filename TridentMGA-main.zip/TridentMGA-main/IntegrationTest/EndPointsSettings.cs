﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IntegrationTest
{
    public class EndPointsSettings
    {        
        public string Test_Environment { get; set; }
        public string ServerUrl_Local { get; set; }
        public string ServerUrl_KMG_Development { get; set; }
        public string ServerUrl_KMG_Staging { get; set; }
        public string ServerUrl_Azure_Development { get; set; }
        public string ServerUrl_Azure_Staging { get; set; }
        public string ServerUrl { get; set; }
        public ApiEndPoints ApiEndPoints { get; set; }
    }

    public class ApiEndPoints
    {
        public string PostEndPoint { get; set; }
        public string GetEndPoint { get; set; }
        public string RateEndPoint { get; set; }
    }
}
