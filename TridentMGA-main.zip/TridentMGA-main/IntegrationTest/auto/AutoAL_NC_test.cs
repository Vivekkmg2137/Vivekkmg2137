﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest.auto
{
    [TestClass]
    public class AutoAL_NC_test
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }

        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void AutoAL_NC_Rate()
        {
            //Get input model
            InputModel = InitTestCaseAutoAL_NC();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.Auto, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel);

            //Test

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ALModifiedFinalPremium, 3409);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.BasePremium, 4759);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.HiredAndNonOwnedModifiedPremium, 0);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.HiredAndNonOwnedUnModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.IRPMPremium, 3331);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.LiabilityModifiedPremium, 2545.61M);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.LiabilityUnModifiedPremium, 3636.59M);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ManualPremium, 4759);


            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.MedicalPaymentsModifiedPremium, 126);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium, 180);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.PersonalInjuryProtectionModifiedPremium, 0);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.TierPremium, 4759);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UnderinsuredModifiedPremium, 0);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UninsuredModifiedPremium, 501.2M);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UninsuredUnModifiedPremium, 716);

            //Schedule Rating
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.TotalSchedulePremium1, 3330);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.TotalSchedulePremium2, 3410);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.Difference1, 79);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.Difference2, -1);


        }


        public RaterInputFacadeViewModel InitTestCaseAutoAL_NC()
        {
            string json = string.Empty;
            try
            {
                using (StreamReader r = new StreamReader("auto_al_apd_nc.json"))
                {
                    json = r.ReadToEnd();
                }
            }
            catch (Exception ex)
            { throw; }
            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
