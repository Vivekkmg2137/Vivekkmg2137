﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest.auto
{
    [TestClass]
    public class AutoAL_NY_test
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }

        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void AutoAL_NY_Rate()
        {
            //Get input model
            InputModel = InitTestCaseAutoAL_NY();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.Auto, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Auto.NY);

            //Test

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.ALModifiedFinalPremium,3591);   //3397
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.BasePremium, 3372);  //3188
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.HiredAndNonOwnedModifiedPremium, 105);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.HiredAndNonOwnedUnModifiedPremium, 100);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.IRPMPremium, 3591);  //3397
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.LiabilityModifiedPremium, 2787.75M);  // 2630.25M

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.LiabilityUnModifiedPremium, 2655);//2505
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.ManualPremium, 3422); //3238

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.MedicalPaymentsModifiedPremium, 189M);// 178.5
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium, 180);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.PersonalInjuryProtectionModifiedPremium, 10.5M);
                                                                     
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 10);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.TierPremium, 3422);  //3238
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.UnderinsuredModifiedPremium, 0);
                                                                     
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.UninsuredModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.UninsuredUnModifiedPremium, 0);

            //Schedule Rating
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.TotalSchedulePremium1, 3440); //3240
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.TotalSchedulePremium2, 3590); //3400
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.Difference1, 151);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.Difference2, 1);

        }


        public RaterInputFacadeViewModel InitTestCaseAutoAL_NY()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("auto_al_apd_ny.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
