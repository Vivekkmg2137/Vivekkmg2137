﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest.auto
{

    [TestClass]
    public class AutoAPD_NC_test
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }

        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void AutoAPD_NC_Rate()
        {
            //Get input model
            InputModel = InitTestCaseAutoAPD_NC();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.Auto, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel);

            //Test

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.APDModifiedFinalPremium, 3076);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.BasePremium, 1818);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.IRPMPremium, 3076);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.ManualPremium, 3076);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.NonModifiedPremium, 1258);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.OtherModPremium, 3076);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TerrorismPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TierPremium, 3076);


            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalUnModifiedCollisionPremium, 437);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium, 509);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalUnModifiedSpecCauseofLossPremium, 872);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalVehiclesCount, 10);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalOCN, 420000);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalVehicleswithoutTrailersCount, 10);

            //Schedule Rating
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.TotalSchedulePremium1, 3330);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.TotalSchedulePremium2, 3410);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.Difference1, 79);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.Difference2, -1);
        }


        public RaterInputFacadeViewModel InitTestCaseAutoAPD_NC()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("auto_al_apd_nc.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
