﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest.auto
{

    [TestClass]
    public class AutoAPD_NY_test
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }

        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void AutoAPD_NY_Rate()
        {
            //Get input model
            InputModel = InitTestCaseAutoAPD_NY();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.Auto, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel);

            //Test

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.APDModifiedFinalPremium, 156);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.BasePremium, 758);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.IRPMPremium, 794);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.ManualPremium, 908);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.NonModifiedPremium, 150);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.OtherModPremium, 156);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TerrorismPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TierPremium, 908);


            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TotalUnModifiedCollisionPremium, 304);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium, 454);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TotalUnModifiedSpecCauseofLossPremium, 0);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TotalVehiclesCount, 10);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TotalOCN, 280000);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TotalVehicleswithoutTrailersCount, 10);

            //Schedule Rating
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.TotalSchedulePremium1, 3440);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.TotalSchedulePremium2, 3590);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.Difference1, 151);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.Difference2, 1);
        }


        public RaterInputFacadeViewModel InitTestCaseAutoAPD_NY()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("auto_al_apd_ny.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
