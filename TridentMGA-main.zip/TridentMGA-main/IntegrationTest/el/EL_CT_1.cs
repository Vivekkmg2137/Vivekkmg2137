using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest
{
    [TestClass]
    public class EL_CT_1
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }
        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void ELCTRate()
        {
            //Get input model
            InputModel = InitTestCaseELCT_1();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.EducatorsLegal, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW);

            //Test
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW.BasePremium, 6734);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ManualPremium, 8740);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ELModifiedFinalPremium, 12023);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ELUnmodifiedWithoutExcessPremium, 2006);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW.IRPMPremium, 7730);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW.OtherModPremium, 12023);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW.NonModifiedPremium, 2006);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TierPremium, 7730);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.CW.RetentionRate, 1.05M);
            
        }

        public RaterInputFacadeViewModel InitTestCaseELCT_1()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("el_CT.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
