using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest
{
    [TestClass]
    public class EL_NY_1
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }
        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void ELNYRate()
        {
            //Get input model
            InputModel = InitTestCaseELNY_1();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.EducatorsLegal, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY);

            //Test
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY.BasePremium, 16914);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY.ManualPremium, 16964);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY.ELModifiedFinalPremium, 22419);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY.ELNYUnmodifiedWithoutExcessPremium, 50);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY.IRPMPremium, 19501);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY.NonModifiedPremium, 50);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY.OtherModPremium, 22419);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TierPremium, 16964);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EducatorsLegal.NY.RetentionRate, 1);

        }

        public RaterInputFacadeViewModel InitTestCaseELNY_1()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("el_NY.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
