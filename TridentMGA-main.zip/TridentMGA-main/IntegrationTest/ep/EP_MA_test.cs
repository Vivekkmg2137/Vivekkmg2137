﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest.ep
{

    [TestClass]
    public class EP_MA_test
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }

        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void EP_MA_Rate()
        {
            //Get input model
            InputModel = InitTestCaseEP_MA();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.EmploymentPractices, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.EmploymentPractices);

            //Test

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EmploymentPractices.BasePremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EmploymentPractices.EPFinalModifiedPremium, 2063);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EmploymentPractices.IRPMPremium, 2063);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EmploymentPractices.ManualPremium, 2063);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EmploymentPractices.NonModifiedPremium, 2063);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EmploymentPractices.OtherModPremium, 2063);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.EmploymentPractices.TierPremium, 2063);

        }


        public RaterInputFacadeViewModel InitTestCaseEP_MA()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("EP_MA.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
