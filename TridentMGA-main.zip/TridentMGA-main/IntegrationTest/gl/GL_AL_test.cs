using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest.GL
{
    [TestClass]
    public class GL_AL_test
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }
        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void GLALRate()
        {
            //Get input model
            InputModel = InitTestCaseGL_AL();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.GeneralLiability, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.GeneralLiability);

            //Test
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.BasePremium, 998);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.ComputerAttackPremium, 1500);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.DamageToPremisesModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.DamageToPremisesUnmodifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.DamageToPremisesUnmodifiedwithoutExcessPremium, 70);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.DataCompromiseLiabilityBasepremium, 431);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.DataCompromiseLiabilityPremium, 1121);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.EBModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.EBUnmodifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.EBUnmodifiedWithoutExcessPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.GLFinalModifiedPremium, 25950);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.GLTotalUnmodifiedwithoutExcessPremium, 415);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.IRPMPremium, 14181);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.ManualPremium, 14224);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.MedicalPaymentsModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.MedicalPaymentsUnmodifiedPremium, 30);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.MedicalPaymentsUnmodifiedWithoutExcessPremium, 30);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.ModifiablePremium, -75);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.NetworkSecurityPremium, 1300);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.NonModifiedPremium, 9906);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.OtherModPremium, 13112);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.ResponseExpenseBasePremium, 2002);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.ResponseExpensePremium, 5205);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.TierPremium, 14224);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.TotalCyberModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.TotalCyberUnmodifiedPremium, 2800);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.TotalCyberUnmodifiedwithoutexcessPremium, 2800);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.TotalDataCompromiseModifiedPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.TotalDataCompromiseUnmodifiedPremium, 6326);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.TotalDataCompromiseUnmodifiedwithoutexcessPremium, 6326);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.UnmannedAircraftcoverage15lbsorLessPremium, 945);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.UnmannedAircraftcoverage15Pt1toLessThen55lbsPremium, 1400);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.UnmannedAircraftcoverageGreaterThenEqualto55lbsPremium, 1050);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.UnmannedAircraftModifiedTotalPremium, 2521);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.UnmannedAircraftTotalUnmodifiedWithoutExcessPremium, 3395);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.GeneralLiability.UnmannedAircraftUnModifiedTotalPremium, 3395);

        }

        public RaterInputFacadeViewModel InitTestCaseGL_AL()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("gl_AL.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
