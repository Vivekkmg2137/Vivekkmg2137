﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest.law
{
    [TestClass]
    public class LAW_NY_test
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }

        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void LAW_NY_Rate()
        {
            //Get input model
            InputModel = InitTestCaseLAW_NY();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.LawEnforcement, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.LawEnforcement);

            //Test

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.BasePremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.IRPMPremium, 900);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.LawFinalModifiedPremium, 900);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.LawTotalUnmodifiedWithoutExcessPremium, 3768);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.ManualPremium, 900);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.NonModifiedPremium, 0); //250
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.OtherModPremium, 900); 


            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.TierPremium, 900);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.UnmannedAircraftCoverage15lbsorLessPremium, 1275);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.UnmannedAircraftCoverage15PT1_to_lt55lbsPremium, 1063);
                        
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.UnmannedAircraftCoverage_gteq55lbsPremium, 850);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.UnmannedAircraftModifiedTotalPremium, 0);

            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.UnmannedAircraftUnModifiedTotalPremium, 0);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.LawEnforcement.UnmannedAircraftUnModifiedWithoutExcessTotalPremium, 3188);
        }


        public RaterInputFacadeViewModel InitTestCaseLAW_NY()
        {
            string json = string.Empty;
            try
            {
                using (StreamReader r = new StreamReader("law_NY.json"))
                {
                    json = r.ReadToEnd();
                }
            }
            catch (Exception ex)
            { throw; }
            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
