using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest
{
    [TestClass]
    public class ocp1_test_1
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }

        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void OCPRate()
        {
            //Get input model
            InputModel = InitTestCaseOCP_1();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.Ocp1, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            Request.AddJsonBody(InputModel);
            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Ocp1);

            //Test
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp1.BasePremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp1.ManualPremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp1.OCPFinalPremium, 200);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Ocp2);

           
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp2.BasePremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp2.ManualPremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp2.OCPFinalPremium, 200);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Ocp3);

            //Test
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp3.BasePremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp3.ManualPremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp3.OCPFinalPremium, 200);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Ocp4);

            //Test
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp4.BasePremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp4.ManualPremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp4.OCPFinalPremium, 200);

            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Ocp5);

            //Test
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp5.BasePremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp5.ManualPremium, 200);
            Assert.AreEqual(OutputModel.LineOfBusinessOutputModel.Ocp5.OCPFinalPremium, 200);
        }

        public RaterInputFacadeViewModel InitTestCaseOCP_1()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("ocp1_1.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
