using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest
{
    [TestClass]
    public class property_cw_test_1
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }

        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void PropertyCwRate()
        {
            //Get input model
            InputModel = InitTestCasePropertyCw_1();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.Property, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            //Request.AddBody(request.JsonSerializer.Serialize(new { A = "foo", B = "bar" }));
            //Request.AddJsonBody(request.JsonSerializer.Serialize(model));
            Request.AddJsonBody(InputModel);

            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Property);

            //Test
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.TotalExpTIV, (double)35000, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.BuildingTIV, (double)211999, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ContentTIV, (double)67906, 0.5);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.Premium1, (double)0, 0.5);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.Premium2, (double)0, 0.5);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium, (double)20000, 0.1);

            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ContentsDefTotalPointsNoPerils, (double)6599, 0.1);  
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ContentsAddtlChargeRateNoPerils, (double)1.5, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.BuildingModifiedMLRNoPerils, (double)1.162, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.BuildingCombinedRateNoPerils, (double)2.162, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.BuildingPremiumNoPerils, (double)4583.42, 0.1);

            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.BuildingPremiumTotal, (double)6338.77, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.BuildingPremiumForPerils, (double)1755.35, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ContentsModifiedMLRNoPerils, (double)1.186, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ContentsCombinedRateNoPerils, (double)2.186, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ContentsPremiumNoPerils, (double)1484.43, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ContentsPremiumTotal, (double)2046.01, 0.1);  
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ContentsPremiumForPerils, (double)561.58, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.OptionalCoverageTotalPremium, (double)0, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.BasePremium, (double)28385, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, (double)0, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ManualPremium, (double)47621, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium, (double)331, 0.1);

            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.WindBuildingPremium, (double)1087, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.WindContentPremium, (double)348, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.WindTotalPremium, (double)1435, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.FloodTotalPremium, (double)552, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.FloodBuildingPremium, (double)418, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.FloodContentPremium, (double)134, 0.1); 
        }

        public RaterInputFacadeViewModel InitTestCasePropertyCw_1()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("property_cw1.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }


        //public void PropertyCwGet()
        //{
        //    var request = new RestRequest(Method.GET);
        //    request.Resource = ServerUrl + GetEndPoint;
        //    request.RequestFormat = DataFormat.Json;
        //    request.AddHeader("Content-Type", "application/json");
        //    //request.AddBody(request.JsonSerializer.Serialize(new { A = "foo", B = "bar" }));

        //    var client = new RestClient();
        //    var response = client.Execute(request);
        //    var jsonOutput = ((RestSharp.RestResponseBase)response).Content;
        //    var model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(jsonOutput);

        //    Assert.AreEqual(model.LineOfBusiness.Property, true);
        //}
    }
}
