using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ViewModels;
using Newtonsoft.Json;
using Api.Controllers;
using RestSharp;
using System.IO;
using System;
using IntegrationTests.Utils;
using System.Reflection;

namespace IntegrationTest
{
    [TestClass]
    public class property_ny_test_1
    {
        public EndPointsSettings EndPointsSettings { get; private set; }
        public string ServerUrl { get; set; }
        public string GetEndPoint { get; set; }

        public string RateEndPoint { get; set; }

        public RaterInputFacadeViewModel InputModel { get; set; }

        public RaterOutputFacadeViewModel OutputModel { get; set; }

        public RestRequest Request { get; set; }

        public RestClient Client { get; set; }

        [TestInitialize]
        public void Initialize()
        {
            var file = "endpointssettings.json";
            var settings = new object();
            try
            {
                var buildDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                var filePath = buildDir + @"\endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(filePath);
            }
            catch
            {
                file = "endpointssettings.json";
                settings = JsonLoader.LoadFromFile<dynamic>(file);
            }

            try
            {
                EndPointsSettings = JsonLoader.Deserialize<EndPointsSettings>(settings);
            }
            catch (Exception ex)
            {
                throw;
            }

            ServerUrl = EndPointsSettings.ServerUrl;
            if (EndPointsSettings.Test_Environment == "KMG_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Development;
            }
            else if (EndPointsSettings.Test_Environment == "KMG_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_KMG_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Development")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Development;
            }
            else if (EndPointsSettings.Test_Environment == "Azure_Staging")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Azure_Staging;
            }
            else if (EndPointsSettings.Test_Environment == "Local")
            {
                ServerUrl = EndPointsSettings.ServerUrl_Local;
            }

            RateEndPoint = EndPointsSettings.ApiEndPoints.RateEndPoint;

            Request = new RestRequest();
            Client = new RestClient();
        }


        [TestMethod]
        public void PropertyNyRate()
        {
            //Get input model
            InputModel = InitTestCasePropertyNy_1();

            //Test
            Assert.AreEqual(InputModel.LineOfBusiness.Property, true);

            //POST
            Request.Method = Method.POST;
            Request.Resource = ServerUrl + RateEndPoint;
            Request.RequestFormat = DataFormat.Json;
            Request.AddHeader("Content-Type", "application/json");
            //Request.AddBody(request.JsonSerializer.Serialize(new { A = "foo", B = "bar" }));
            //Request.AddJsonBody(request.JsonSerializer.Serialize(model));
            Request.AddJsonBody(InputModel);

            var response = Client.Execute(Request);
            var postJsonResult = ((RestSharp.RestResponseBase)response).Content;

            OutputModel = JsonConvert.DeserializeObject<RaterOutputFacadeViewModel>(postJsonResult);

            Assert.IsTrue(OutputModel.ResponseModel.Successful);
            Assert.IsNotNull(OutputModel.LineOfBusinessOutputModel.Property);

            //Test
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.TotalTIV, (double)240445, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.BuildingTIV, (double)179139, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ContentTIV, (double)61306, 0.5);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium, (double)300, 0.1);

            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.OptionalCoverageTotalPremium, (double)9492, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.BasePremium, (double)498, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, (double)9492, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.ManualPremium, (double)9990, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium, (double)12, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.WindTotalPremium, (double)24, 0.1);
            Assert.AreEqual((double)OutputModel.LineOfBusinessOutputModel.Property.FloodTotalPremium, (double)12, 0.1);
        }

        public RaterInputFacadeViewModel InitTestCasePropertyNy_1()
        {
            string json = string.Empty;
            using (StreamReader r = new StreamReader("property_ny1.json"))
            {
                json = r.ReadToEnd();
            }

            RaterInputFacadeViewModel model = JsonConvert.DeserializeObject<RaterInputFacadeViewModel>(json);

            return model;
        }
    }
}
