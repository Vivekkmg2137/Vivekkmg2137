﻿using NLog;
using System;

namespace Logging
{
    /// <summary>
    /// Wrapper class for the NLog logging
    /// </summary>
    public class LoggingManager : ILoggingManager
    {
        private static ILogger logger = LogManager.GetCurrentClassLogger();

        public LoggingManager()
        {
        }

        public void Debug(string message)
        {
            logger.Debug(message);
        }

        public void Error(string message)
        {
            logger.Error(message);
        }

        public void Error(string message, Exception ex)
        {
            logger.Error(ex, message);
        }

        public void Error(Exception ex)
        {
            logger.Error(ex);
        }

        public void Info(string message)
        {
            logger.Info(message);
        }

        public void Warn(string message)
        {
            logger.Warn(message);
        }
    }
}
