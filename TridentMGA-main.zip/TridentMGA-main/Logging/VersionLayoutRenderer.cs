﻿using NLog;
using NLog.LayoutRenderers;
using System.Reflection;
using System.Text;

namespace Logging
{
    [LayoutRenderer("version")]
    public class VersionLayoutRenderer : LayoutRenderer
    {
        protected override void Append(StringBuilder builder, LogEventInfo logEvent)
        {
            string assemblyVersion = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion;
            builder.Append(assemblyVersion);
        }
    }
}
