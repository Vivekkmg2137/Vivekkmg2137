﻿using Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Auto
{
    public class AutoInputModel
    {
        public CWInputModel CW { get; set; }

        public CWInputModel NY { get; set; }
    }

    public class CWInputModel
    {
        public AutoLiabilityInputModel AutoLiabilityInputModel { get; set; }
        public bool HasAutoPhysicalDamage { get; set; }
        public AutoPhysicalDamageInputModel AutoPhysicalDamageInputModel { get; set; }
        public List<AutoScheduleVehiclesDetailsInputModel> AutoScheduleVehiclesDetailsInputModel { get; set; }
    }
}
