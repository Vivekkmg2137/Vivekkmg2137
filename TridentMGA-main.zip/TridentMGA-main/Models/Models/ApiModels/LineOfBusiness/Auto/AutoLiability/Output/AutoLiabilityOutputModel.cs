﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Output
{
    public class AutoLiabilityOutputModel
    {
        public decimal HiredAndNonOwnedModifiedPremium { get; set; }
        public int HiredAndNonOwnedUnModifiedPremium { get; set; }
        public decimal Deductible_SIRFactor { get; set; }
        public decimal LiabilityLimitRate { get; set; }
        public decimal LiabilityUnModifiedPremium { get; set; }
        public decimal LiabilityModifiedPremium { get; set; }
        public decimal MedicalPaymentsModifiedPremium { get; set; }
        public decimal MedicalPaymentsUnModifiedPremium { get; set; }
        public decimal UninsuredModifiedPremium { get; set; }
        public decimal UninsuredUnModifiedPremium { get; set; }
        public decimal UnderinsuredModifiedPremium { get; set; }
        public decimal UnderinsuredUnModifiedPremium { get; set; }
        public decimal PersonalInjuryProtectionRate { get; set; }
        public decimal PersonalInjuryProtectionModifiedPremium { get; set; }
        public decimal PersonalInjuryProtectionUnModifiedPremium { get; set; }
        public decimal ExcessAttendantCareNonEmergencyRate { get; set; }
        public decimal ExcessAttendantCareEmergencyRate { get; set; }
        public decimal ExcessAttendantCareBusesRate { get; set; }
        public int NonEmergencyUnitsCount { get; set; }
        public decimal NonEmergencyUnitsBaseRate { get; set; }
        public int EmergencyUnitsCount { get; set; }
        public decimal EmergencyUnitsBaseRate { get; set; }
        public int BusesCount { get; set; }
        public decimal BusesBaseRate { get; set; }
        public int TrailersCount { get; set; }
        public decimal TrailersBaseRate { get; set; }
        public int TotalVehiclesCount { get; set; }
        public int TotalVehiclesWithoutTrailersCount { get; set; }
        public int NonEmergencyPIPUnitsCount { get; set; }
        public int EmergencyPIPUnitsCount { get; set; }
        public int BusesPIPUnitsCount { get; set; }
        public int TotalPIPUnitswithoutTrailersCount { get; set; }
        public int NonEmergencyMedPayUnitsCount { get; set; }
        public int EmergencyMedPayUnitsCount { get; set; }
        public int BusesMedPayUnitsCount { get; set; }
        public int TotalMedPayUnitswithoutTrailersCount { get; set; }
        public decimal MIMCCAAssessmentRate { get; set; }
        public int MIMCCAAssessmentRatingExposure { get; set; }
        public decimal MIMCCAAssessmentCharge { get; set; }
        public decimal NCAutoLossRecoupmentSurchargeRate { get; set; }
        public int NCAutoLossRecoupmentSurchargeRatingExposure { get; set; }
        public decimal NCAutoLossRecoupmentSurchargeCharge { get; set; }
        public int NYMotorVehicleLawEnforcementFeeRatingExposure { get; set; }
        public decimal NYMotorVehicleLawEnforcementFeeRate { get; set; }
        public decimal NYMotorVehicleLawEnforcementFeeCharge { get; set; }
        public int BasePremium { get; set; }
        public int NonModifiedPremium { get; set; }
        public int ManualPremium { get; set; }
        public int IRPMPremium { get; set; }
        public decimal TerrorismRate { get; set; }
        public int TerrorismPremium { get; set; }
        public decimal LocationRate { get; set; }
        public decimal PopulationRate { get; set; }
        public decimal OtherModRate { get; set; }
        public int OtherModPremium { get; set; }
        public decimal TierRate { get; set; }
        public int TierPremium { get; set; }
        public int APRP { get; set; }
        public int ALModifiedFinalPremium { get; set; }


        #region Optional Coverage
        public AutoLiabilityOptionalCoverageOutputModel AutoLiabilityOptionalCoveragesOutputModel { get; set; }

        #endregion

        [JsonIgnore]
        public int MinimumPremium { get; set; }
        public decimal PersonalInjuryProtectionNonEmergencyRate { get; set; }
        public decimal PersonalInjuryProtectionEmergencyRate { get; set; }
        public decimal PersonalInjuryProtectionBusesRate { get; set; }
        public decimal BasicFPBNonEmergencyRate { get; set; }
        public decimal BasicFPBEmergencyRate { get; set; }
        public decimal BasicFPBBusesRate { get; set; }
        public decimal MedicalPaymentsNonEmergencyRate { get; set; }
        public decimal MedicalPaymentsEmergencyRate { get; set; }
        public decimal MedicalPaymentsBusesRate { get; set; }
        public decimal UninsuredNonEmergencyRate { get; set; }
        public decimal UninsuredEmergencyRate { get; set; }
        public decimal UninsuredBusesRate { get; set; }
        public decimal UninsuredBIPDNonEmergencyRate { get; set; }
        public decimal UninsuredBIPDEmergencyRate { get; set; }
        public decimal UninsuredBIPDBusesRate { get; set; }
        public decimal UnderinsuredNonEmergencyRate { get; set; }
        public decimal UnderinsuredEmergencyRate { get; set; }
        public decimal UnderinsuredBusesRate { get; set; }
    }

}
