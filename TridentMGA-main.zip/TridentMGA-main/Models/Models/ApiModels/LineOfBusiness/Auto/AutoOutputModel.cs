﻿using Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Output;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Auto
{
    public class AutoOutputModel
    {
        public OutputModel CW { get; set; }
        public OutputModel NY { get; set; }
    }

    public class OutputModel
    {
        public AutoLiabilityOutputModel AutoLiabilityOutputModel { get; set; }
        public AutoPhysicalDamageOutputModel AutoPhysicalDamageOutputModel { get; set; }
        public AutoScheduleVehiclesDetailsOutputModel AutoScheduleRatingOutputModel { get; set; }
    }
}

