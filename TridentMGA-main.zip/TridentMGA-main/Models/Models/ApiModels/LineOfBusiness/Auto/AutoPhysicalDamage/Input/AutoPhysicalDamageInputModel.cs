﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Input
{
    public class AutoPhysicalDamageInputModel
    {
        public AutoPhysicalDamageInputModel()
        {

        }

        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "APD";
        public decimal CompBaseRate { get; set; }
        public decimal CollisionBaseRate { get; set; }
        public decimal SpecCauseofLossBaseRate { get; set; }
        public int NonEmergencyUnitsCount { get; set; }
        public int EmergencyUnitsCount { get; set; }
        public int BusesCount { get; set; }
        public int TrailersCount { get; set; }
        public int TotalVehiclesCount { get; set; }
        public int TotalVehicleswithoutTrailersCount { get; set; }
        public int CompVehiclesCount { get; set; }
        public int CollVehiclesCount { get; set; }
        public int SpecifiedCauseofLossCount { get; set; }
        public string ComprehensiveSymbol { get; set; }
        public string CollisionSymbol { get; set; }
        public string SpecifiedCauseofLossSymbol { get; set; }
        public bool IRPMApplies { get; set; }
        public decimal OtherModRate { get; set; }
        public decimal IRPMRate { get; set; }

        #region Optional Coverage
        public AutoPhysicalDamageOptionalCoverageInputModel AutoPhysicalDamageOptionalCoverageInputModel { get; set; }

        #endregion
    }

}
