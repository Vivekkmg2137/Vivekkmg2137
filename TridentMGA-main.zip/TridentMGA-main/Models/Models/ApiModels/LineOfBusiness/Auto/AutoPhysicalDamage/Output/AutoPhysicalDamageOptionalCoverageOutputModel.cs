﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output
{
    public class AutoPhysicalDamageOptionalCoverageOutputModel
    {

        #region Garagekeepers - CA 99 37 Premium

        public int GaragekeepersCA9937CoverageID { get; set; }
        public bool GaragekeepersCA9937IsSelected { get; set; }
        public int GaragekeepersCA9937Limit { get; set; }
        public int GaragekeepersCA9937Deductible { get; set; }
        public string GaragekeepersCA9937RatingBasis { get; set; }
        public string GaragekeepersCA9937ReturnMethod { get; set; }
        public decimal GaragekeepersCA9937Rate { get; set; }
        public int GaragekeepersCA9937UnModifiedPremium { get; set; }

        #endregion

        #region Rental Reimbursement - CA 99 23 Premium

        public int RentalReimbursementCA9923CoverageID { get; set; }
        public bool RentalReimbursementCA9923IsSelected { get; set; }
        public int RentalReimbursementCA9923Limit { get; set; }
        public int RentalReimbursementCA9923Deductible { get; set; }
        public string RentalReimbursementCA9923RatingBasis { get; set; }
        public string RentalReimbursementCA9923ReturnMethod { get; set; }
        public decimal RentalReimbursementCA9923Rate { get; set; }
        public int RentalReimbursementCA9923UnModifiedPremium { get; set; }

        #endregion

        #region Rental Reimbursement - Emergency Service Vehicles - BA0004 Premium

        public int RentalReimbursementEmergencyServiceVehiclesBA0004CoverageID { get; set; }
        public bool RentalReimbursementEmergencyServiceVehiclesBA0004IsSelected { get; set; }
        public int RentalReimbursementEmergencyServiceVehiclesBA0004Limit { get; set; }
        public int RentalReimbursementEmergencyServiceVehiclesBA0004Deductible { get; set; }
        public string RentalReimbursementEmergencyServiceVehiclesBA0004RatingBasis { get; set; }
        public string RentalReimbursementEmergencyServiceVehiclesBA0004ReturnMethod { get; set; }
        public decimal RentalReimbursementEmergencyServiceVehiclesBA0004Rate { get; set; }
        public int RentalReimbursementEmergencyServiceVehiclesBA0004UnModifiedPremium { get; set; }

        #endregion

        #region Full Safety Glass Coverage - CA 04 21 Premium

        public int FullSafetyGlassCoverageCA0421CoverageID { get; set; }
        public bool FullSafetyGlassCoverageCA0421IsSelected { get; set; }
        public int FullSafetyGlassCoverageCA0421Limit { get; set; }
        public int FullSafetyGlassCoverageCA0421Deductible { get; set; }
        public string FullSafetyGlassCoverageCA0421RatingBasis { get; set; }
        public string FullSafetyGlassCoverageCA0421ReturnMethod { get; set; }
        public decimal FullSafetyGlassCoverageCA0421Rate { get; set; }
        public int FullSafetyGlassCoverageCA0421UnModifiedPremium { get; set; }

        #endregion

        public int OtherCoverageUnModifiedPremium { get; set; }
        public List<AutoPhysicalDamageOptionalOtherCoverageOutputModel> AutoPhysicalDamageOptionalOtherCoverageOutputModels { get; set; }
    }

   public class AutoPhysicalDamageOptionalOtherCoverageOutputModel
    {
        public int OtherCoverageID { get; set; }
        public string OtherCoverageDescription { get; set; }
        public int OtherCoverageLimit { get; set; }
        public int OtherCoverageDedcutible { get; set; }
        public decimal OtherCoverageRate { get; set; }
        public string OtherCoverageRatingBasis { get; set; }
        public string OtherCoverageReturnMethod { get; set; }
        public int OtherCoveragePremium { get; set; }

    }
}
