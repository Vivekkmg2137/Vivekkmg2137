﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output
{
    public class AutoPhysicalDamageOutputModel
    {
        public List<CollisionOutputModel> CollisionOutputModels { get; set; }
        public List<ComprehensiveOutputModel> ComprehensiveOutputModels { get; set; }
        public List<SpecifiedCausesofLossOutputModel> SpecifiedCausesofLossOutputModels { get; set; }
        public int TotalComprehensiveOCN { get; set; }
        public int TotalCollisionOCN { get; set; }
        public int TotalSpecifiedCauseofLossOCN { get; set; }
        public int TotalOCN { get; set; }
        public int TotalUnModifiedCollisionPremium { get; set; }
        public int TotalUnModifiedComprehensivePremium { get; set; }
        public int TotalUnModifiedSpecCauseofLossPremium { get; set; }
        public decimal CompBaseRate { get; set; }
        public decimal CollisionBaseRate { get; set; }
        public decimal SpecCauseofLossBaseRate { get; set; }
        public int TotalComprehensiveVehiclesCount { get; set; }
        public int TotalCollisionVehiclesCount { get; set; }
        public int TotalSpecifiedCauseofLossVehiclesCount { get; set; }
        public int TotalVehiclesCount { get; set; }
        public int TotalVehicleswithoutTrailersCount { get; set; }
        public decimal MNAutomobileTheftPreventionSurchargeRate { get; set; }
        public int MNAutomobileTheftPreventionSurchargeRatingExposure { get; set; }
        public decimal MNAutomobileTheftPreventionCharge { get; set; }
        public decimal MNFireSafetySurchargeRate { get; set; }
        public int MNFireSafetySurchargeRatingExposure { get; set; }
        public decimal MNFireSafetySurchargeCharge { get; set; }
        public int BasePremium { get; set; }
        public int NonModifiedPremium { get; set; }
        public int ManualPremium { get; set; }
        public int IRPMPremium { get; set; }
        public decimal TerrorismRate { get; set; }
        public int TerrorismPremium { get; set; }
        public decimal LocationRate { get; set; }
        public decimal PopulationRate { get; set; }
        public decimal OtherModRate { get; set; }
        public int OtherModPremium { get; set; }
        public decimal TierRate { get; set; }
        public int TierPremium { get; set; }
        public int APRP { get; set; }
        public int APDModifiedFinalPremium { get; set; }

        [JsonIgnore]
        public int MinimumPremium { get; set; }
        #region Optional Coverage

        public AutoPhysicalDamageOptionalCoverageOutputModel AutoPhysicalDamageOptionalCoveragesModel { get; set; }

        #endregion
    }
}
