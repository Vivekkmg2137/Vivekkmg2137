﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output
{
    public class ComprehensiveOutputModel
    {
        public int ComprehensiveOCNPerCategory { get; set; }
        public int ComprehensiveDeductibleperCategory { get; set; }
        public decimal ComprehensiveDeductibleFactorperCategory { get; set; }
        public int ComprehensiveVehiclesCountpercategory { get; set; }
        public string ComprehensiveValuationperCategory { get; set; }
        public decimal ComprehensiveValuationFactorperCategory { get; set; }
        public int ComprehensivePremiumperCategory { get; set; }
    }
}
