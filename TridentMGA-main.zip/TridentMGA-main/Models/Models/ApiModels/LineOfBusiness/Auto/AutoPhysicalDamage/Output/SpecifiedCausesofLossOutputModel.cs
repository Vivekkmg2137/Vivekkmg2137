﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output
{
    public class SpecifiedCausesofLossOutputModel
    {
        public int SpecCauseofLossOCNPerCategory { get; set; }
        public int SpecifiedCauseofLossDeductibleperCategory { get; set; }
        public decimal SpecCauseofLossDeductibleFactorperCategory { get; set; }
        public int SpecifiedCauseofLossVehiclesCountpercategory { get; set; }
        public string SpecifiedCauseofLossValuationperCategory { get; set; }
        public decimal SpecCauseofLossValuationFactorperCategory { get; set; }
        public int SpecCauseofLossPremiumperCategory { get; set; }
    }
}
