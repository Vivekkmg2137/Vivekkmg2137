﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Crime.Input
{
    /// <summary>
    /// EmployeeTheftExcessforSpecifiedEmployeesInputModel
    /// </summary>
    public class CrimeCWEmployeeTheftExcessforSpecifiedEmployeesInputModel
    {
        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsIsSelected.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsIsSelected { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsCoverageID.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsCoverageID { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsLimit.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsLimit { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsDeductible.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsDeductible { get; set; }

        /// <summary>
        /// Gets or sets ExcessforSpecifiedEmployeesorPositionsRatableEmployees.
        /// </summary>
        public int ExcessforSpecifiedEmployeesorPositionsRatableEmployees { get; set; }
    }
}
