﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Crime.Input
{
    /// <summary>
    /// CrimeCWOptionalCoveragesInputModel
    /// </summary>
    public class CrimeCWOptionalCoveragesInputModel
    {
        /// <summary>
        /// Gets or sets CrimeCWOtherCoveragesInputModel.
        /// </summary>
        public List<CrimeCWOtherCoveragesInputModel> CrimeOtherCoverages { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageTotalPremium.
        /// </summary>
        public int OtherCoverageTotalPremium { get; set; }

    }

    /// <summary>
    /// CrimeCWOtherCoveragesInputModel
    /// </summary>
    public class CrimeCWOtherCoveragesInputModel
    {
        /// <summary>
        /// Gets or sets OtherCoverageCoverageID.
        /// </summary>
        public int OtherCoverageCoverageID { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageDescription.
        /// </summary>
        public String OtherCoverageDescription { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageLimit.
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageDedcutible.
        /// </summary>
        public int OtherCoverageDedcutible { get; set; }

        /// <summary>
        /// Gets or sets ClassAEmployees.
        /// </summary>
        public Decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageRatingBasis.
        /// </summary>
        public String OtherCoverageRatingBasis {get;set;}

        /// <summary>
        /// Gets or sets OtherCoverageReturnMethod.
        /// </summary>
        public String OtherCoverageReturnMethod {get;set;}

        /// <summary>
        /// Gets or sets OtherCoverageUnmodifiedPremium.
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }
    }
}
