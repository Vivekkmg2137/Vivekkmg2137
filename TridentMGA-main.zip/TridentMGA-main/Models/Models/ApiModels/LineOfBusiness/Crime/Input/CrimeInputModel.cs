﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Crime.Input
{
    /// <summary>
    /// CrimeInputModel
    /// </summary>
    public class CrimeInputModel
    {
        /// <summary>
        /// Gets or sets CrimeCWInputModel
        /// </summary>
        public CrimeCWInputModel CW { get; set; }

        /// <summary>
        /// Gets or sets CrimeNYInputModel
        /// </summary>
        public CrimeNYInputModel NY { get; set; }
    }
}
