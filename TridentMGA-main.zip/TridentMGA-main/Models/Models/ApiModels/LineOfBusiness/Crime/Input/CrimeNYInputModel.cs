﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.Crime.Input
{
    public class CrimeNYInputModel
    {
        /// <summary>
        /// Gets or sets LineOfBusiness.
        /// </summary>
        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "CR";

        /// <summary>
        /// Gets or sets ClassAEmployees.
        /// </summary>
        public int ClassAEmployees { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyIsSelected
        /// </summary>
        public bool PublicEmployeeDishonestyIsSelected { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyLimit
        /// </summary>
        public int PublicEmployeeDishonestyLimit { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyDeductible
        /// </summary>
        public int PublicEmployeeDishonestyDeductible { get; set; }
        /// <summary>
        /// Gets or sets FaithfulPerformanceOfDutyIsSelected
        /// </summary>
        public bool FaithfulPerformanceOfDutyIsSelected { get; set; }
        /// <summary>
        /// Gets or sets FaithfulPerformanceOfDutyLimit
        /// </summary>
        public int FaithfulPerformanceOfDutyLimit { get; set; }
        /// <summary>
        /// Gets or sets FaithfulPerformanceOfDutyDeductible
        /// </summary>
        public int FaithfulPerformanceOfDutyDeductible { get; set; }
        /// <summary>
        /// Gets or sets CrimeNYPublicEmployeeDishonestyIncreasedLimits
        /// </summary>
        public List<CrimeNYPublicEmployeeDishonestyIncreasedLimitsInputModel> CrimeNYPublicEmployeeDishonestyIncreasedLimits { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyIncreasedLimitTotalPremium
        /// </summary>
        public int PublicEmployeeDishonestyIncreasedLimitTotalPremium { get; set; }
        /// <summary>
        /// Gets or sets ForgeryAndAlterationIsSelected
        /// </summary>
        public bool ForgeryAndAlterationIsSelected { get; set; }
        /// <summary>
        /// Gets or sets ForgeryAndAlterationLimit
        /// </summary>
        public int ForgeryAndAlterationLimit { get; set; }
        /// <summary>
        /// Gets or sets ForgeryAndAlterationDeductible
        /// </summary>
        public int ForgeryAndAlterationDeductible { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesLimitIsSelected
        /// </summary>
        public bool TheftDisappearanceAndDestructionInsideThePremisesLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesLimit
        /// </summary>
        public int TheftDisappearanceAndDestructionInsideThePremisesLimit { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesDeductible
        /// </summary>
        public int TheftDisappearanceAndDestructionInsideThePremisesDeductible { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesLimitIsSelected
        /// </summary>
        public bool TheftDisappearanceAndDestructionOutsideThePremisesLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesLimit
        /// </summary>
        public int TheftDisappearanceAndDestructionOutsideThePremisesLimit { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesDeductible
        /// </summary>
        public int TheftDisappearanceAndDestructionOutsideThePremisesDeductible { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitIsSelected
        /// </summary>
        public bool TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimit
        /// </summary>
        public int TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimit { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitStartDate
        /// </summary>
        public DateTime TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitStartDate { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitEndDate
        /// </summary>
        public DateTime TheftDisappearanceAndDestructionInsideThePremisesIncreasedLimitEndDate { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesIncreasedLimitIsSelected
        /// </summary>
        public bool TheftDisappearanceAndDestructionOutsideThePremisesIncreasedLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesIncreasedLimit
        /// </summary>
        public int TheftDisappearanceAndDestructionOutsideThePremisesIncreasedLimit { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesStartDate
        /// </summary>
        public DateTime TheftDisappearanceAndDestructionOutsideThePremisesStartDate { get; set; }
        /// <summary>
        /// Gets or sets TheftDisappearanceAndDestructionOutsideThePremisesEndDate
        /// </summary>
        public DateTime TheftDisappearanceAndDestructionOutsideThePremisesEndDate { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesLimitIsSelected
        /// </summary>
        public bool RobberyAndSafeBurglaryInsideThePremisesLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesLimit
        /// </summary>
        public int RobberyAndSafeBurglaryInsideThePremisesLimit { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesDeductible
        /// </summary>
        public int RobberyAndSafeBurglaryInsideThePremisesDeductible { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesLimitIsSelected
        /// </summary>
        public bool RobberyAndSafeBurglaryOutsideThePremisesLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesLimit
        /// </summary>
        public int RobberyAndSafeBurglaryOutsideThePremisesLimit { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesDeductible
        /// </summary>
        public int RobberyAndSafeBurglaryOutsideThePremisesDeductible { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryLimitIsSelected
        /// </summary>
        public bool RobberyAndSafeBurglarySafeBurglaryLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryLimit
        /// </summary>
        public int RobberyAndSafeBurglarySafeBurglaryLimit { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryDeductible
        /// </summary>
        public int RobberyAndSafeBurglarySafeBurglaryDeductible { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitIsSelected
        /// </summary>
        public bool RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesIncreasedLimit
        /// </summary>
        public int RobberyAndSafeBurglaryInsideThePremisesIncreasedLimit { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitStartDate
        /// </summary>
        public DateTime RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitStartDate { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitEndDate
        /// </summary>
        public DateTime RobberyAndSafeBurglaryInsideThePremisesIncreasedLimitEndDate { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitIsSelected
        /// </summary>
        public bool RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimit
        /// </summary>
        public int RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimit { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitStartDate
        /// </summary>
        public DateTime RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitStartDate { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitEndDate
        /// </summary>
        public DateTime RobberyAndSafeBurglaryOutsideThePremisesIncreasedLimitEndDate { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryIncreasedLimitIsSelected
        /// </summary>
        public bool RobberyAndSafeBurglarySafeBurglaryIncreasedLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryIncreasedLimit
        /// </summary>
        public int RobberyAndSafeBurglarySafeBurglaryIncreasedLimit { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryIncreasedLimitStartDate
        /// </summary>
        public DateTime RobberyAndSafeBurglarySafeBurglaryIncreasedLimitStartDate { get; set; }
        /// <summary>
        /// Gets or sets RobberyAndSafeBurglarySafeBurglaryIncreasedLimitEndDate
        /// </summary>
        public DateTime RobberyAndSafeBurglarySafeBurglaryIncreasedLimitEndDate { get; set; }
        /// <summary>
        /// Gets or sets ComputerFraudLimitIsSelected
        /// </summary>
        public bool ComputerFraudLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets ComputerFraudLimit
        /// </summary>
        public int ComputerFraudLimit { get; set; }
        /// <summary>
        /// Gets or sets ComputerFraudDeductible
        /// </summary>
        public int ComputerFraudDeductible { get; set; }
        /// <summary>
        /// Gets or sets IRPMApplies
        /// </summary>
        public bool IRPMApplies { get; set; }
        /// <summary>
        /// Gets or sets IRPMFactor
        /// </summary>
        public decimal IRPMFactor { get; set; }
        /// <summary>
        /// Gets or sets OtherModRate
        /// </summary>
        public decimal OtherModRate { get; set; }
        /// <summary>
        /// Gets or sets CrimeNYOptionalCoverages
        /// </summary>
        public List<CrimeNYOptionalCoveragesInputModel> CrimeNYOptionalCoverages { get; set; }
    }
}
