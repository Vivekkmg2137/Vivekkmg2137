﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Crime.Input
{
    /// <summary>
    /// CrimeNYOptionalCoveragesInputModel
    /// </summary>
    public class CrimeNYOptionalCoveragesInputModel
    {
        /// <summary>
        /// Gets or sets CrimeNYOtherCoverages
        /// </summary>
        public List<CrimeNYOtherCoveragesInputModel> CrimeNYOtherCoverages { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageTotalPremium
        /// </summary>
        public int OtherCoverageTotalPremium { get; set; }
    }

    public class CrimeNYOtherCoveragesInputModel
    {
        /// <summary>
        /// Gets or sets OtherCoverageCoverageID
        /// </summary>
        public int OtherCoverageCoverageID { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageDescription
        /// </summary>
        public string OtherCoverageDescription { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageLimit
        /// </summary>
        public int OtherCoverageLimit { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageDedcutible
        /// </summary>
        public int OtherCoverageDedcutible { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageRate
        /// </summary>
        public decimal OtherCoverageRate { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageRatingBasis
        /// </summary>
        public string OtherCoverageRatingBasis { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageReturnMethod
        /// </summary>
        public string OtherCoverageReturnMethod { get; set; }
        /// <summary>
        /// Gets or sets OtherCoverageUnmodifiedPremium
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }
    }
}
