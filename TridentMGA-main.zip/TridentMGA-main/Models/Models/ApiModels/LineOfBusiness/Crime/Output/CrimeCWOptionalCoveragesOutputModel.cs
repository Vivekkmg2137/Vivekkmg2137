﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Crime.Output
{
    /// <summary>
    /// CrimeCWOptionalCoveragesOutputModel
    /// </summary>
    public class CrimeCWOptionalCoveragesOutputModel
    {
        /// <summary>
        /// Gets or sets CrimeCWOtherCoveragesOutputViewModel
        /// </summary>
        public List<CrimeCWOtherCoveragesOutputViewModel> CrimeOtherCoverages { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageTotalPremium
        /// </summary>
        public int OtherCoverageTotalPremium { get; set; }

    }

    /// <summary>
    /// CrimeCWOtherCoveragesOutputViewModel
    /// </summary>
    public class CrimeCWOtherCoveragesOutputViewModel
    {
        /// <summary>
        /// Gets or sets OtherCoverageID
        /// </summary>
        public int OtherCoverageID { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageDescription
        /// </summary>
        public String OtherCoverageDescription { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageLimit
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// Gets or sets 
        /// </summary>
        public int OtherCoverageDedcutible { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageRate
        /// </summary>
        public Decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageRatingBasis
        /// </summary>
        public String OtherCoverageRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageReturnMethod
        /// </summary>
        public String OtherCoverageReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets OtherCoverageUnmodifiedPremium
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }

    }
}
