﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Crime.Output
{
    /// <summary>
    /// CrimeNYPublicEmployeeDishonestyIncreasedLimitsOutputModel
    /// </summary>
    public class CrimeNYPublicEmployeeDishonestyIncreasedLimitsOutputModel
    {
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyIncreasedLimitIsSelected.
        /// </summary>
        public bool PublicEmployeeDishonestyIncreasedLimitIsSelected { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyIncreasedLimitCoverageID.
        /// </summary>
        public int PublicEmployeeDishonestyIncreasedLimitCoverageID { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyIncreasedLimit.
        /// </summary>
        public int PublicEmployeeDishonestyIncreasedLimit { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyIncreasedLimitRatableExposure.
        /// </summary>
        public int PublicEmployeeDishonestyIncreasedLimitRatableExposure { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyIncreasedLimitEmployees.
        /// </summary>
        public int PublicEmployeeDishonestyIncreasedLimitEmployees { get; set; }
        /// <summary>
        /// Gets or sets PublicEmployeeDishonestyIncreasedLimitPremium.
        /// </summary>
        public int PublicEmployeeDishonestyIncreasedLimitPremium { get; set; }
    }
}
