﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Crime.Output
{
    /// <summary>
    /// CrimeOutputModel
    /// </summary>
    public class CrimeOutputModel
    {
        /// <summary>
        /// gets or sets CrimeCWOutputModel
        /// </summary>
        public CrimeCWOutputModel CW { get; set; }

        
    }
}
