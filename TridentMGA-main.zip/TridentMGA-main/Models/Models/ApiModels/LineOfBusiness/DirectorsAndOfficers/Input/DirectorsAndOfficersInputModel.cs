﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Input
{
    /// <summary>
    /// DirectorsAndOfficersInputModel
    /// </summary>
    public class DirectorsAndOfficersInputModel
    {
        /// <summary>
        /// Get or Set LineOfBusiness
        /// </summary>
        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "DO";

        /// <summary>
        /// Get or Set Exposure
        /// </summary>
        public int Exposure { get; set; }

        /// <summary>
        /// Get or Set ExposureRate
        /// </summary>
        public decimal ExposureRate { get; set; }

        /// <summary>
        /// Get or Set LiabilityLimit
        /// </summary>
        public int LiabilityLimit { get; set; }

        /// <summary>
        /// Get or Set AggregateLimit
        /// </summary>
        public int AggregateLimit { get; set; }

        /// <summary>
        /// Get or Set LiabilityLimitRate
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Get or Set EPInclusionExclusion
        /// </summary>
        public string EPInclusionExclusion { get; set; }

        /// <summary>
        /// Get or Set Deductible/SIR
        /// </summary>
        public string Deductible_SIR { get; set; }

        /// <summary>
        /// Get or Set Retention
        /// </summary>
        public int Retention { get; set; }

        /// <summary>
        /// Get or Set AggregateRetention
        /// </summary>
        public int AggregateRetention { get; set; }

        /// <summary>
        /// Get or Set Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Get or Set Expense
        /// </summary>
        public string Expense { get; set; }

        /// <summary>
        /// Get or Set PolicyType
        /// </summary>
        public string PolicyType { get; set; }

        /// <summary>
        /// Get or Set RetroDate
        /// </summary>
        public DateTime RetroDate { get; set; }

        /// <summary>
        /// Get or Set YearsinCMProgram
        /// </summary>
        public int YearsinCMProgram { get; set; }

        /// <summary>
        /// Get or Set IRPMApplies
        /// </summary>
        public bool IRPMApplies { get; set; }

        /// <summary>
        /// Get or Set IRPMFactor
        /// </summary>
        public decimal IRPMFactor { get; set; }

        /// <summary>
        /// Get or Set OtherModRate
        /// </summary>
        public decimal OtherModRate { get; set; }

        #region Optional Coverage

        /// <summary>
        /// DirectorsAndOfficersOptionalCoverageInputModel
        /// </summary>
        public DirectorsAndOfficersOptionalCoverageInputModel DirectorsAndOfficersOptionalCoverageModel { get; set; }

        #endregion

    }
}
