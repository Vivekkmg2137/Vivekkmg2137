﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.EducatorsLegal.Input
{
    public class EducatorsLegalCwInputModel
    {
        /// <summary>
        /// Gets or sets LineOfBusiness
        /// </summary>
        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "EL";
        /// <summary>
        /// Gets or sets Exposure.
        /// </summary>
        public int Exposure { get; set; }

        /// <summary>
        /// Gets or sets Exposure Rate.
        /// </summary>
        public decimal ExposureRate { get; set; }

        /// <summary>
        /// Gets or sets Liability Limit.
        /// </summary>
        public int LiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets Aggregate Limit.
        /// </summary>
        public int AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Liability Limit Rate.
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Gets or sets EP InclusionExclusion
        /// </summary>
        public string EPInclusionExclusion { get; set; }

        /// <summary>
        /// Gets or sets Deductible/SIR.
        /// </summary>
        public string DeductibleSIR { get; set; }

        /// <summary>
        /// Gets or sets Retention.
        /// </summary>
        public string Retention { get; set; }

        /// <summary>
        /// Gets or sets Aggregate Retention.
        /// </summary>
        public int AggregateRetention { get; set; }

        /// <summary>
        /// Gets or sets ExperienceFactor IsSelected
        /// </summary>
        public bool ExperienceFactorIsSelected { get; set; }
        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Expense.
        /// </summary>
        public string Expense { get; set; }


        /// <summary>
        /// Gets or sets PolicyType.
        /// </summary>
        public string PolicyType { get; set; }

        /// <summary>
        /// Gets or sets RetroDate.
        /// </summary>
        public DateTime RetroDate { get; set; }

        /// <summary>
        /// Gets or sets YearsinCMProgram.
        /// </summary>
        public int YearsinCMProgram { get; set; }

        /// <summary>
        /// Gets or sets IRPMApplies.
        /// </summary>
        public bool IRPMApplies { get; set; }

        /// <summary>
        /// Gets or sets IRPMFactor.
        /// </summary>
        public decimal IRPMFactor { get; set; }

        /// <summary>
        /// Gets or sets Other Mod Factor.
        /// </summary>
        public decimal OtherModRate { get; set; }



        //GRID START - OPTIONAL COVERAGES
        #region Optional Coverage
        public EducatorsLegalCwOptionalCoverageInputModel EducatorsLegalOptionalCoverage { get; set; }
        #endregion

    }
}
