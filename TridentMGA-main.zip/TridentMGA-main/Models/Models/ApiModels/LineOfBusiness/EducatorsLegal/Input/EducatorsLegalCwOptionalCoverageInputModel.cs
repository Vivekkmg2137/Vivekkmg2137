﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.EducatorsLegal.Input
{
    public class EducatorsLegalCwOptionalCoverageInputModel
    {
        /// <summary>
        /// Gets or sets NonMonetaryDefenseIsSelected
        /// </summary>
        public bool NonMonetaryDefenseIsSelected { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseLimit
        /// </summary>
        public int NonMonetaryDefenseLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseAggregateLimit
        /// </summary>
        public int NonMonetaryDefenseAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseDeductible
        /// </summary>
        public int NonMonetaryDefenseDeductible { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRatingBasis
        /// </summary>
        public string NonMonetaryDefenseRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseReturnMethod
        /// </summary>
        public string NonMonetaryDefenseReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRate
        /// </summary>
        public decimal NonMonetaryDefenseRate { get; set; }

        /// <summary>
        /// Gets or sets Non-Monetary Defense Unmodified Premium
        /// </summary>
        public int NonMonetaryDefenseUnmodifiedPremium { get; set; }
        /// <summary>
        /// Gets or sets Non-Monetary Defense Modified Premium
        /// </summary>
        public int NonMonetaryDefenseModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Non-Monetary Defense IncludedIn Excess Exposure
        /// </summary>
        public string NonMonetaryDefenseIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets IDEA IsSelected
        /// </summary>
        public bool IDEAIsSelected { get; set; }

        /// <summary>
        /// Gets or sets IDEA Limit
        /// </summary>
        public int IDEALimit { get; set; }

        /// <summary>
        /// Gets or sets IDEA Aggregate Limit
        /// </summary>
        public int IDEAAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets IDEA Deductible
        /// </summary>
        public int IDEADeductible { get; set; }

        /// <summary>
        /// Gets or sets IDEA Rating Basis
        /// </summary>
        public string IDEARatingBasis { get; set; }

        /// <summary>
        /// Gets or sets IDEA Return Method
        /// </summary>
        public string IDEAReturnMethod { get; set; }
        /// <summary>
        /// Gets or sets IDEA Rate
        /// </summary>
        public decimal IDEARate { get; set; }

        /// <summary>
        /// Gets or sets IDEA Unmodified Premium
        /// </summary>
        public int IDEAUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets IDEA Unmodified Premium
        /// </summary>
        public int IDEAModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets IDEA IncludedIn Excess Exposure
        /// </summary>
        public string IDEAIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period IsSelected
        /// </summary>
        public bool SupplExtendedReportingPeriodIsSelected { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Limit
        /// </summary>
        public int SupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Aggregate Limit
        /// </summary>
        public int SupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Deductible
        /// </summary>
        public int SupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rating Basis
        /// </summary>
        public string SupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Return Method
        /// </summary>
        public string SupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rate
        /// </summary>
        public decimal SupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodified Premium
        /// </summary>
        public int SupplExtendedReportingPeriodUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodified Premium
        /// </summary>
        public int SupplExtendedReportingPeriodModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Suppl. Extended Reporting Period  Inverse Condemnation Included In Excess Exposure
        /// </summary>
        public string SupplExtendedReportingPeriodInverseCondemnationIncludedInExcessExposure { get; set; }
        
        //"GRID START -OTHER COVERAGES"
        #region Optional Coverage
        public List<EducatorsLegalOtherCoverageInputModel> EducatorsLegalOtherCoverage { get; set; }
        #endregion

        /// <summary>
        /// Gets or sets Other Coverage Total Premium
        /// </summary>
        public int OtherCoverageTotalPremium { get; set; }

    }
}