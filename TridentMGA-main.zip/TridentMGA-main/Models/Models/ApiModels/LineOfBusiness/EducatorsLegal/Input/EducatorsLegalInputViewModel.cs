﻿using Models.ApiModels.LineOfBusiness.EducatorsLegal.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Models.ApiModels.LineOfBusiness.EducatorsLegal.Input
{
    public class EducatorsLegalInputModel
    {                          
        public EducatorsLegalCwInputModel CW { get; set; }
                               
        public EducatorsLegalNyInputModel NY { get; set; }
    }     
}
