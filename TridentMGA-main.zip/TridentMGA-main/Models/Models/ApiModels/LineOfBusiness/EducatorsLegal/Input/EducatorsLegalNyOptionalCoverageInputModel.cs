﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.EducatorsLegal.Input
{
    public class EducatorsLegalNyOptionalCoverageInputModel
    { 
        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period IsSelected
        /// </summary>
        public bool SupplExtendedReportingPeriodIsSelected { get; set; }


        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Limit
        /// </summary>
        public int SupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Aggregate Limit
        /// </summary>
        public int SupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Deductible
        /// </summary>
        public int SupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rating Basis
        /// </summary>
        public string SupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Return Method
        /// </summary>
        public string SupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rate
        /// </summary>
        public decimal SupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodified Premium
        /// </summary>
        public int SupplExtendedReportingPeriodUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodified Premium
        /// </summary>
        public int SupplExtendedReportingPeriodModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Suppl. Extended Reporting Period Included In Excess Exposure
        /// </summary>
        public string SupplExtendedReportingPeriodIncludedInExcessExposure { get; set; }
        //"GRID START -OTHER COVERAGES"
        #region Other Optional Coverage
        public List<EducatorsLegalNyOtherCoverageInputModel> EducatorsLegalOtherCoverage { get; set; }
        #endregion

        /// <summary>
        /// Gets or sets Other Coverage Total Premium
        /// </summary> 
        public int OtherCoverageTotalPremium { get; set; }
    }
}