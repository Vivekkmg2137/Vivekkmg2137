﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.EducatorsLegal.Output
{
    public class EducatorsLegalCwOutputModel
    {
        /// <summary>
        /// Gets or sets LineOfBusiness
        /// </summary>
        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "EL";

        /// <summary>
        /// Gets or sets Rating Basis
        /// </summary>  
        public string RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets RatingBasisParameter
        /// </summary>
        public int RatingBasisParameter { get; set; }

        /// <summary>
        /// Gets or sets Retro Year.
        /// </summary>
        public int RetroYear { get; set; }

        /// <summary>
        /// Gets or sets Exposure Rate.
        /// </summary>
        public decimal ExposureRate { get; set; }

        /// <summary>
        /// Gets or sets Liability Limit Rate.
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Gets or sets Aggregate Limit.
        /// </summary>
        public decimal AggregateLimitRate { get; set; }         

        /// <summary>
        /// Gets or sets EP InclusionExclusion Rate
        /// </summary>
        public decimal EPInclusionExclusionRate { get; set; }

        /// <summary>
        /// Gets or sets RetentionRate.
        /// </summary>
        public decimal RetentionRate { get; set; }
         
        /// <summary>
        /// Gets or sets PolicyType Rate
        /// </summary>
        public decimal PolicyTypeRate { get; set; }

        /// <summary>
        /// Gets or sets Experience Retention.
        /// </summary>
        public decimal ExperienceRetention { get; set; }

        /// <summary>
        /// Gets or sets RetroDate Rate.
        /// </summary>
        public decimal RetroDateRate { get; set; }

        /// <summary>
        /// Gets or sets YearsinCMRate
        /// </summary>
        public decimal YearsinCMRate { get; set; }
         
        //GRID START - OPTIONAL COVERAGES
        #region Optional Coverage
        public EducatorsLegalCwOptionalCoverageOutputModel EducatorsLegalOptionalCoverage { get; set; }
        #endregion

        /// <summary>
        /// Gets or sets Base Premium.
        /// </summary>
        public int BasePremium { get; set; }
        /// <summary>
        /// Gets or sets NonModified Premium.
        /// </summary>
        public int NonModifiedPremium { get; set; }
        /// <summary>
        /// Gets or sets Manual Premium.
        /// </summary>
        public int ManualPremium { get; set; }
        /// <summary>
        /// Gets or sets IRPM Factor.
        /// </summary>
        public decimal IRPMFactor { get; set; }
        /// <summary>
        /// Gets or sets IRPM Premium.
        /// </summary>
        public int IRPMPremium { get; set; }
        /// <summary>
        /// Gets or sets Terrorism Rate.
        /// </summary>
        public decimal TerrorismRate { get; set; }
        /// <summary>
        /// Gets or sets Terrorism Premium.
        /// </summary>
        public int TerrorismPremium { get; set; }
        /// <summary>
        /// Gets or sets OtherMod Rate.
        /// </summary>
        public decimal LocationRate { get; set; }
        /// <summary>
        /// Gets or sets OtherMod Rate.
        /// </summary>
        public decimal PopulationRate { get; set; }
        /// <summary>
        /// Gets or sets OtherMod Rate.
        /// </summary>
        public decimal OtherModRate { get; set; }
        /// <summary>
        /// Gets or sets OtherMod Premium.
        /// </summary>
        public int OtherModPremium { get; set; }
        /// <summary>
        /// Gets or sets Tier Rate.
        /// </summary>
        public decimal TierRate { get; set; }
        /// <summary>
        /// Gets or sets Tier Premium.
        /// </summary>
        public int TierPremium { get; set; }
        /// <summary>
        /// Gets or sets EL Final Modified Premium.
        /// </summary>
        public int ELModifiedFinalPremium { get; set; }

        /// <summary>
        /// Gets or sets EL Unmodified Without Excess Premium
        /// </summary>
        public int ELUnmodifiedWithoutExcessPremium { get; set; }
                
    }
}
