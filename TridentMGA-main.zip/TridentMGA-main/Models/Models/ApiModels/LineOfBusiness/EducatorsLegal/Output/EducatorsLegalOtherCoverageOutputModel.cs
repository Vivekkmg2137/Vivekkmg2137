﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.EducatorsLegal.Output
{
    public class EducatorsLegalOtherCoverageOutputModel
    {
        /// <summary>
        /// Gets or sets Other Coverage ID
        /// </summary>
        public int OtherCoverageID { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Description
        /// </summary>
        public string OtherCoverageDescription { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Limit
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Aggregate Limit
        /// </summary>
        public int OtherCoverageAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Deductible
        /// </summary>
        public int OtherCoverageDeductible { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Rate
        /// </summary>
        public decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Rating Basis
        /// </summary>
        public string OtherCoverageRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Return Method
        /// </summary>
        public string OtherCoverageReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage IncludedIn Excess Exposure
        /// </summary>
        public string OtherCoverageIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Unmodified Without Excess Premium
        /// </summary>
        public int OtherCoverageUnmodifiedWithoutExcessPremium { get; set; }
         
        /// <summary>
        /// Gets or sets Other Coverage Unmodified Premium
        /// </summary>
        public int OtherCoverageUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Modified Premium
        /// </summary> 
        public int OtherCoverageModifiedPremium { get; set; }
    }
}
