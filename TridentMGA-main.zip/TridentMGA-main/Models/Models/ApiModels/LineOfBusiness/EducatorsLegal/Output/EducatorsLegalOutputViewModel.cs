﻿using Models.ApiModels  .LineOfBusiness.EducatorsLegal.Output;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Models.ApiModels.LineOfBusiness.EducatorsLegal.Output
{
    public class EducatorsLegalOutputModel
    {
        public EducatorsLegalCwOutputModel CW { get; set; }

        public EducatorsLegalNyOutputModel NY { get; set; }
    }     
}
