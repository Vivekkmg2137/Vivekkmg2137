﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.EmploymentPracticesSchool.Input
{
    public class EmploymentPracticesSchoolOptionalCoverageInputModel
    {
        /// <summary>
        /// Gets or sets NonMonetaryDefenseIsSelected
        /// </summary>
        public bool NonMonetaryDefenseIsSelected { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseLimit
        /// </summary>
        public int NonMonetaryDefenseLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseAggregateLimit
        /// </summary>
        public int NonMonetaryDefenseAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseDeductible
        /// </summary>
        public int NonMonetaryDefenseDeductible { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRatingBasis
        /// </summary>
        public string NonMonetaryDefenseRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseReturnMethod
        /// </summary>
        public string NonMonetaryDefenseReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRate
        /// </summary>
        public decimal NonMonetaryDefenseRate { get; set; }

        /// <summary>
        /// Gets or sets Non-Monetary Defense Unmodified Premium
        /// </summary>
        public int NonMonetaryDefenseUnmodifiedPremium { get; set; }
        /// <summary>
        /// Gets or sets Non-Monetary Defense Modified Premium
        /// </summary>
        public int NonMonetaryDefenseModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Non-Monetary Defense Included In Excess Exposure
        /// </summary>
        public string NonMonetaryDefenseIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets EEOC IsSelected
        /// </summary>
        public bool EEOCIsSelected { get; set; }

        /// <summary>
        /// Gets or sets EEOC Limit
        /// </summary>
        public int EEOCLimit { get; set; }

        /// <summary>
        /// Gets or sets EEOC Aggregate Limit
        /// </summary>
        public int EEOCAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets EEOC Deductible
        /// </summary>
        public int EEOCDeductible { get; set; }

        /// <summary>
        /// Gets or sets EEOC Rating Basis
        /// </summary>
        public string EEOCRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets EEOC Return Method
        /// </summary>
        public string EEOCReturnMethod { get; set; }
        /// <summary>
        /// Gets or sets EEOC Rate
        /// </summary>
        public decimal EEOCRate { get; set; }

        /// <summary>
        /// Gets or sets EEOC Unmodified Premium
        /// </summary>
        public int EEOCUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets EEOC Unmodified Premium
        /// </summary>
        public int EEOCModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets EEOC Included In Excess Exposure
        /// </summary>
        public string EEOCIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActIsSelected
        /// </summary>
        public bool LossAdjustmentExpenseWrongfulActIsSelected { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActLimit
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActLimit { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActAggregate Limit
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActDeductible
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActDeductible { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActRating Basis
        /// </summary>
        public string LossAdjustmentExpenseWrongfulActRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful Act Return Method
        /// </summary>
        public string LossAdjustmentExpenseWrongfulActReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful Act Rate
        /// </summary>
        public decimal LossAdjustmentExpenseWrongfulActRate { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful Act Unmodified Premium
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful ActModified Premium
        /// </summary>
        public int LossAdjustmentExpenseWrongfulActModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Loss Adjustment Expense Wrongful Act Included In Excess Exposure
        /// </summary>
        public string LossAdjustmentExpenseWrongfulActIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period IsSelected
        /// </summary>
        public bool SupplExtendedReportingPeriodIsSelected { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Limit
        /// </summary>
        public int SupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Aggregate Limit
        /// </summary>
        public int SupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Deductible
        /// </summary>
        public int SupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rating Basis
        /// </summary>
        public string SupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Return Method
        /// </summary>
        public string SupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rate
        /// </summary>
        public decimal SupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodified Premium
        /// </summary>
        public int SupplExtendedReportingPeriodUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodified Premium
        /// </summary>
        public int SupplExtendedReportingPeriodModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Included In Excess Exposure
        /// </summary>
        public string SupplExtendedReportingPeriodIncludedInExcessExposure { get; set; }

        //"GRID START -OTHER COVERAGES"
        #region Optional Coverage
        public List<EmploymentPracticesSchoolOtherCoverageInputModel> EmploymentPracticesSchoolOtherCoverageModel { get; set; }
        #endregion
    }
}
