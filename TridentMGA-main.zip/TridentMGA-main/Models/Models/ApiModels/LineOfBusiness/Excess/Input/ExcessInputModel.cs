﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Excess.Input
{
    public class ExcessInputModel
    {
    }
}
