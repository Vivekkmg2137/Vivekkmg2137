﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.GeneralLiability.Input
{
    public class GeneralLiabilityInputModel
    {
        public GeneralLiabilityInputModel()
        {
        }

        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "GL";
        /// <summary>
        /// Gets or sets Exposure.
        /// </summary>
        public int Exposure { get; set; }

        /// <summary>
        /// Gets or sets ExposureRate.
        /// </summary>
        public decimal ExposureRate { get; set; }

        /// <summary>
        /// Gets or sets ADA.
        /// </summary>
        public int ADA { get; set; }

        /// <summary>
        /// Gets or sets ADARate.
        /// </summary>
        public decimal ADARate { get; set; }

        /// <summary>
        /// Gets or sets LiabilityLimit.
        /// </summary>
        public string LiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets LiabilityLimitRate.
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Gets or sets DamageToPremisesLimit.
        /// </summary>
        public string DamageToPremisesLimit { get; set; }

        /// <summary>
        /// Gets or sets DamageToPremisesUnmodifiedPremium.
        /// </summary>
        public int DamageToPremisesUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets DamageToPremisesIncludedInExcessExposure.
        /// </summary>
        public string DamageToPremisesIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets MedicalPaymentLimit.
        /// </summary>
        public string MedicalPaymentLimit { get; set; }

        /// <summary>
        /// Gets or sets MedicalPaymentUnmodifiedPremium.
        /// </summary>
        public int MedicalPaymentUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets MedicalPaymentIncludedInExcessExposure.
        /// </summary>
        public string MedicalPaymentIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets PersonalandAdvertisingInjuryLimit.
        /// </summary>
        public string PersonalandAdvertisingInjuryLimit { get; set; }

        /// <summary>
        /// Gets or sets AggregateLimit.
        /// </summary>
        public int AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets ProductsCompletedAggregateLimit.
        /// </summary>
        public int ProductsCompletedAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets PolicyType.
        /// </summary>
        public string PolicyType { get; set; }

        /// <summary>
        /// Gets or sets RetroActiveDate.
        /// </summary>
        public DateTime RetroActiveDate { get; set; }

        /// <summary>
        /// Gets or sets YearsinClaimsMadeProgram
        /// </summary>
        public int YearsinClaimsMadeProgram { get; set; }

        /// <summary>
        /// Gets or sets DeductibleSIR
        /// </summary>
        public string DeductibleSIR { get; set; }

        /// <summary>
        /// Gets or sets Retention
        /// </summary>
        public int Retention { get; set; }

        /// <summary>
        /// Gets or sets AggregateRetention
        /// </summary>
        public int AggregateRetention { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Expense
        /// </summary>
        public string Expense { get; set; }

        /// <summary>
        /// Gets or sets LossExperienceIsSelected
        /// </summary>
        public bool LossExperienceIsSelected { get; set; }

        /// <summary>
        /// Gets or sets IRPMFactor
        /// </summary>
        public decimal IRPMFactor { get; set; }

        /// <summary>
        /// Gets or sets OtherModFactor
        /// </summary>
        public decimal OtherModFactor { get; set; }

        /// <summary>
        /// Gets or sets IRPMApplies
        /// </summary>
        public bool IRPMApplies { get; set; }

        /// <summary>
        /// Gets or sets EBLimit
        /// </summary>
        public string EBLimit { get; set; }

        /// <summary>
        /// Gets or sets EBIncludedInExcessExposure
        /// </summary>
        public string EBIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets EBAggregateLimit
        /// </summary>
        public int EBAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets EBRetention
        /// </summary>
        public int EBRetention { get; set; }

        /// <summary>
        /// Gets or sets EBPolicyType
        /// </summary>
        public string EBPolicyType { get; set; }

        /// <summary>
        /// Gets or sets EBRetroactiveDate
        /// </summary>
        public DateTime EBRetroactiveDate { get; set; }

        /// <summary>
        /// Gets or sets EBUnmodifiedPremium
        /// </summary>
        public int EBUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseReferralIsSelected
        /// </summary>
        public bool DataCompromiseReferralIsSelected { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseLimit
        /// </summary>
        public int DataCompromiseLimit { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseDeductible
        /// </summary>
        public int DataCompromiseDeductible { get; set; }

        /// <summary>
        /// Gets or sets NYDataCompromiseYearsinClaimsMade
        /// </summary>
        public int NYDataCompromiseYearsinClaimsMade { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseIncludedInExcessExposure
        /// </summary>
        public string DataCompromiseIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets ResponseExpensePremium
        /// </summary>
        public int ResponseExpensePremium { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseLiabilityPremium
        /// </summary>
        public int DataCompromiseLiabilityPremium { get; set; }

        /// <summary>
        /// Gets or sets CyberReferralIsSelected
        /// </summary>
        public bool CyberReferralIsSelected { get; set; }

        /// <summary>
        /// Gets or sets ComputerAttackLimit
        /// </summary>
        public int ComputerAttackLimit { get; set; }

        /// <summary>
        /// Gets or sets ComputerAttackDeductible
        /// </summary>
        public int ComputerAttackDeductible { get; set; }

        /// <summary>
        /// Gets or sets ComputerAttackPremium
        /// </summary>
        public int ComputerAttackPremium { get; set; }

        /// <summary>
        /// Gets or sets NetworkSecurityAndElectronicMediaLiabilityLimit
        /// </summary>
        public int NetworkSecurityAndElectronicMediaLiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets NYCyberYearsinClaimsMade
        /// </summary>
        public int NYCyberYearsinClaimsMade { get; set; }

        /// <summary>
        /// Gets or sets NetworkSecurityDeductible
        /// </summary>
        public int NetworkSecurityDeductible { get; set; }

        /// <summary>
        /// Gets or sets NetworkSecurityPremium
        /// </summary>
        public int NetworkSecurityPremium { get; set; }

        /// <summary>
        /// Gets or sets CyberIncludedInExcessExposure
        /// </summary>
        public string CyberIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftOption
        /// </summary>
        public string UnmannedAircraftOption { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftAggregateLimit
        /// </summary>
        public int UnmannedAircraftAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverageIncludedinExcessExposure
        /// </summary>
        public string UnmannedAircraftcoverageIncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15lbsorLessRate
        /// </summary>
        public decimal UnmannedAircraftcoverage15lbsorLessRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15lbsorLessTotalUnits
        /// </summary>
        public int UnmannedAircraftcoverage15lbsorLessTotalUnits { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15Pt1toLessThen55lbsRate
        /// </summary>
        public decimal UnmannedAircraftcoverage15Pt1toLessThen55lbsRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15Pt1toLessThen55lbsTotalUnits
        /// </summary>
        public int UnmannedAircraftcoverage15Pt1toLessThen55lbsTotalUnits { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverageGreaterThenEqualto55lbsRate
        /// </summary>
        public decimal UnmannedAircraftcoverageGreaterThenEqualto55lbsRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverageGreaterThenEqualto55lbsTotalUnits
        /// </summary>
        public int UnmannedAircraftcoverageGreaterThenEqualto55lbsTotalUnits { get; set; }

        /// <summary>
        /// Gets or sets generalLiabilityOptionalCoverageInputModel
        /// </summary>
        public GeneralLiabilityOptionalCoverageInputModel GeneralLiabilityOptionalCoverageModel { get; set; }
    }
}
