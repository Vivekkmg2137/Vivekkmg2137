﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.GeneralLiability.output
{
    public class GeneralLiabilityOutputModel
    {
        /// <summary>
        /// Gets or sets Exposure
        /// </summary>
        public int Exposure { get; set; }

        /// <summary>
        /// Gets or sets ExposureRate
        /// </summary>
        public decimal ExposureRate { get; set; }


        /// <summary>
        /// Gets or sets ADA.
        /// </summary>
        public int ADA { get; set; }

        /// <summary>
        /// Gets or sets ADARate
        /// </summary>
        public decimal ADARate { get; set; }

        /// <summary>
        /// Gets or sets LiabilityLimitRate
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Gets or sets AggregateLimitFactor
        /// </summary>
        public decimal AggregateLimitFactor { get; set; }

        /// <summary>
        /// Gets or sets RetentionFactor
        /// </summary>
        public decimal RetentionFactor { get; set; }

        /// <summary>
        /// Gets or sets PopulationFactor
        /// </summary>
        public decimal PopulationFactor { get; set; }

        /// <summary>
        /// Gets or sets LocationFactor
        /// </summary>
        public decimal LocationFactor { get; set; }

        /// <summary>
        /// Gets or sets PolicyTypeFactor
        /// </summary>
        public decimal PolicyTypeFactor { get; set; }

        /// <summary>
        /// Gets or sets YearsinCMFactor
        /// </summary>
        public decimal YearsinCMFactor { get; set; }

        /// <summary>
        /// Gets or sets RetroDateFactor
        /// </summary>
        public decimal RetroDateFactor { get; set; }

        /// <summary>
        /// Gets or sets RetroYear
        /// </summary>
        public int RetroYear { get; set; }

        /// <summary>
        /// Gets or sets LossExperienceFactor
        /// </summary>
        public decimal LossExperienceFactor { get; set; }

        /// <summary>
        /// Gets or sets RatingBasis
        /// </summary>
        public string RatingBasis { get; set; }

        /// <summary>
        /// Gets or sets DamageToPremisesIncludedInExcessExposure
        /// </summary>
        public string DamageToPremisesIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets DamageToPremisesUnmodifiedwithoutExcessPremium
        /// </summary>
        public int DamageToPremisesUnmodifiedwithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets DamageToPremisesUnmodifiedPremium
        /// </summary>
        public int DamageToPremisesUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets DamageToPremisesModifiedPremium
        /// </summary>
        public int DamageToPremisesModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets MedicalPaymentsUnmodifiedWithoutExcessPremium
        /// </summary>
        public int MedicalPaymentsUnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets MedicalPaymentsUnmodifiedPremium
        /// </summary>
        public int MedicalPaymentsUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets MedicalPaymentsModifiedPremium
        /// </summary>
        public int MedicalPaymentsModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets MedicalPaymentsIncludedInExcessExposure
        /// </summary>
        public string MedicalPaymentsIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets EBUnmodifiedWithoutExcessPremium
        /// </summary>
        public int EBUnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets EBUnmodifiedPremium
        /// </summary>
        public int EBUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets EBModifiedPremium
        /// </summary>
        public int EBModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets EBIncludedInExcessExposure
        /// </summary>
        public string EBIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseDeductible
        /// </summary>
        public int DataCompromiseDeductible { get; set; }

        /// <summary>
        /// Gets or sets ResponseExpenseLimit
        /// </summary>
        public int ResponseExpenseLimit { get; set; }

        /// <summary>
        /// Gets or sets ResponseExpenseBasePremium
        /// </summary>
        public int ResponseExpenseBasePremium { get; set; }

        /// <summary>
        /// Gets or sets ResponseExpenseDeductible
        /// </summary>
        public int ResponseExpenseDeductible { get; set; }

        /// <summary>
        /// Gets or sets ForensicITReview
        /// </summary>
        public int ForensicITReview { get; set; }

        /// <summary>
        /// Gets or sets LegalReview
        /// </summary>
        public int LegalReview { get; set; }

        /// <summary>
        /// Gets or sets PublicRelations
        /// </summary>
        public int PublicRelations { get; set; }

        /// <summary>
        /// Gets or sets RegulatoryFinesandPenalties
        /// </summary>
        public string RegulatoryFinesandPenalties { get; set; }

        /// <summary>
        /// Gets or sets PCIFinesandPenalties
        /// </summary>
        public string PCIFinesandPenalties { get; set; }

        /// <summary>
        /// Gets or sets FirstPartyNamedMalware
        /// </summary>
        public int FirstPartyNamedMalware {get; set;}

        /// <summary>
        /// Gets or sets DataCompromiseLiabilityLimit
        /// </summary>
        public int DataCompromiseLiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseLiabilityBasepremium
        /// </summary>
        public int DataCompromiseLiabilityBasepremium { get; set; }

        /// <summary>
        /// Gets or sets DataCompromisePopulationRate
        /// </summary>
        public decimal DataCompromisePopulationRate { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseIncludedInExcessExposure
        /// </summary>
        public string DataCompromiseIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets DataCompromiseLiabilityDeductible
        /// </summary>
        public int DataCompromiseLiabilityDeductible { get; set; }

        /// <summary>
        /// Gets or sets NYDataCompromiseYearsinClaimMadeRate
        /// </summary>
        public decimal NYDataCompromiseYearsinClaimMadeRate { get; set; }

        /// <summary>
        /// Gets or sets NHVTDataCompromiseDefense
        /// </summary>
        public string NHVTDataCompromiseDefense { get; set; }

        /// <summary>
        /// Gets or sets NHVTDataCompromiseLiability
        /// </summary>
        public string NHVTDataCompromiseLiability { get; set; }

        /// <summary>
        /// Gets or sets ThirdPartyNamedMalware
        /// </summary>
        public int ThirdPartyNamedMalware {get; set;}

        /// <summary>
        /// Gets or sets DataCompromiseLiabilityPremium
        /// </summary>
        public int DataCompromiseLiabilityPremium { get; set; }

        /// <summary> 
        /// Gets or sets ResponseExpensePremium
        /// </summary>
        public int ResponseExpensePremium { get; set; }

        /// <summary>
        /// Gets or sets TotalDataCompromiseUnmodifiedwithoutexcessPremium
        /// </summary>
        public int TotalDataCompromiseUnmodifiedwithoutexcessPremium { get; set; }

        /// <summary>
        /// Gets or sets TotalDataCompromiseUnmodifiedPremium
        /// </summary>
        public int TotalDataCompromiseUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets TotalDataCompromiseModifiedPremium
        /// </summary>
        public int TotalDataCompromiseModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets ComputerAttackRate
        /// </summary>
        public decimal ComputerAttackRate { get; set; }

        /// <summary>
        /// Gets or sets NetworkSecurityAndElectronicMediaLiabilityRate
        /// </summary>
        public decimal NetworkSecurityAndElectronicMediaLiabilityRate { get; set; }

        /// <summary>
        /// Gets or sets Cyberpopulationrate
        /// </summary>
        public decimal Cyberpopulationrate { get; set; }

        /// <summary>
        /// Gets or sets NYCyberYearsinClaimsMadeRate
        /// </summary>
        public decimal NYCyberYearsinClaimsMadeRate { get; set; }

        /// <summary>
        /// Gets or sets ComputerAttackDeductible
        /// </summary>
        public int ComputerAttackDeductible { get; set; }

        /// <summary>
        /// Gets or sets ComputerAttackCyberExtortionLimit
        /// </summary>
        public int ComputerAttackCyberExtortionLimit { get; set; }

        /// <summary>
        /// Gets or sets NetworkSecurityDeductible
        /// </summary>
        public string NetworkSecurityDeductible { get; set; }

        /// <summary>
        /// Gets or sets NHVTNetworkSecurityDefenseLimit
        /// </summary>
        public string NHVTNetworkSecurityDefenseLimit { get; set; }

        /// <summary>
        /// Gets or sets NHVTNetworkSecurityLiabilityLimit
        /// </summary>
        public string NHVTNetworkSecurityLiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets NHVTElectronicMediaDefenseLimit
        /// </summary>
        public string NHVTElectronicMediaDefenseLimit { get; set; }

        /// <summary>
        /// Gets or sets NHVTElectronicMediaLiabilityLimit
        /// </summary>
        public int NHVTElectronicMediaLiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets ComputerAttackPremium
        /// </summary>
        public int ComputerAttackPremium { get; set; }

        /// <summary>
        /// Gets or sets NetworkSecurityPremium
        /// </summary>
        public int NetworkSecurityPremium { get; set; }

        /// <summary>
        /// Gets or sets TotalCyberUnmodifiedwithoutexcessPremium
        /// </summary>
        public int TotalCyberUnmodifiedwithoutexcessPremium { get; set; }

        /// <summary>
        /// Gets or sets CyberIncludedInExcessExposure
        /// </summary>
        public string CyberIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets TotalCyberUnmodifiedPremium
        /// </summary>
        public int TotalCyberUnmodifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets TotalCyberModifiedPremium
        /// </summary>
        public int TotalCyberModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftAggregateLimitRate
        /// </summary>
        public decimal UnmannedAircraftAggregateLimitRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverageIncludedinExcessExposure
        /// </summary>
        public string UnmannedAircraftcoverageIncludedinExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15lbsorLessRate
        /// </summary>
        public decimal UnmannedAircraftcoverage15lbsorLessRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15lbsorLessPremium
        /// </summary>
        public decimal UnmannedAircraftcoverage15lbsorLessPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15Pt1toLessThen55lbsRate
        /// </summary>
        public decimal UnmannedAircraftcoverage15Pt1toLessThen55lbsRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15Pt1toLessThen55lbsPremium
        /// </summary>
        public decimal UnmannedAircraftcoverage15Pt1toLessThen55lbsPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverageGreaterThenEqualto55lbslbsRate
        /// </summary>
        public decimal UnmannedAircraftcoverageGreaterThenEqualto55lbsRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverageGreaterThenEqualto55lbsPremium
        /// </summary>
        public int UnmannedAircraftcoverageGreaterThenEqualto55lbsPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftTotalUnmodifiedWithoutExcessPremium
        /// </summary>
        public int UnmannedAircraftTotalUnmodifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftUnModifiedTotalPremium
        /// </summary>
        public int UnmannedAircraftUnModifiedTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftModifiedTotalPremium
        /// </summary>
        public int UnmannedAircraftModifiedTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftTotalUnits
        /// </summary>
        public int UnmannedAircraftTotalUnits { get; set; }

        /// <summary>
        /// Gets or sets BasePremium
        /// </summary>
        public int BasePremium { get; set; }

        /// <summary>
        /// Gets or sets NonModifiedPremium
        /// </summary>
        public int NonModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets ModifiablePremium
        /// </summary>
        public int ModifiablePremium { get; set; }

        /// <summary>
        /// Gets or sets ManualPremium
        /// </summary>
        public int ManualPremium { get; set; }

        /// <summary>
        /// Gets or sets IRPMFactor
        /// </summary>
        public decimal IRPMFactor { get; set; }

        /// <summary>
        /// Gets or sets IRPMPremium
        /// </summary>
        public int IRPMPremium { get; set; }

        /// <summary>
        /// Gets or sets TerrorismFactor
        /// </summary>
        public decimal TerrorismFactor { get; set; }

        /// <summary>
        /// Gets or sets TerrorismPremium
        /// </summary>
        public int TerrorismPremium { get; set; }

        /// <summary>
        /// Gets or sets OtherModFactor
        /// </summary>
        public decimal OtherModFactor { get; set; }

        /// <summary>
        /// Gets or sets OtherModPremium
        /// </summary>
        public int OtherModPremium { get; set; }

        /// <summary>
        /// Gets or sets TierFactor
        /// </summary>
        public decimal TierFactor { get; set; }

        /// <summary>
        /// Gets or sets TierPremium
        /// </summary>
        public int TierPremium { get; set; }

        /// <summary>
        /// Gets or sets GLFinalModifiedPremium
        /// </summary>
        public int GLFinalModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets GLTotalUnmodifiedwithoutExcessPremium
        /// </summary>
        public int GLTotalUnmodifiedwithoutExcessPremium { get; set; }

        [JsonIgnore]
        public int MinimumPremium { get; set; }

        /// <summary>
        /// Gets or sets generalLiabilityOptionalCoverageOutputModel
        /// </summary>
        public GeneralLiabilityOptionalCoverageOutputModel GeneralLiabilityOptionalCoverageModel { get; set; }
    }
}
