﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.InlandMarine.Input
{
    public class InlandMarineInputModel
    {
    }
}
