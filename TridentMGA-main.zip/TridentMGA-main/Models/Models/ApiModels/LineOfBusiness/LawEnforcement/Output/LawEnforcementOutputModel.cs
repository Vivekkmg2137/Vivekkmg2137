﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.LawEnforcement.Output
{
    public class LawEnforcementOutputModel
    {
        /// <summary>
        /// Gets or sets RetroYear
        /// </summary>
        public int RetroYear { get; set; }

        /// <summary>
        /// Gets or sets ExposureRate
        /// </summary>
        public decimal ExposureRate { get; set; }

        /// <summary>
        /// Gets or sets LiabilityLimitRate
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Gets or sets AggregateLimitRate
        /// </summary>
        public decimal AggregateLimitRate { get; set; }

        /// <summary>
        /// Gets or sets RetentionRate
        /// </summary>
        public decimal RetentionRate { get; set; }

        /// <summary>
        /// Gets or sets PopulationRate
        /// </summary>
        public decimal PopulationRate { get; set; }

        /// <summary>
        /// Gets or sets LocationRate
        /// </summary>
        public decimal LocationRate { get; set; }

        /// <summary>
        /// Gets or sets PolicyTypeRate
        /// </summary>
        public decimal PolicyTypeRate { get; set; }

        /// <summary>
        /// Gets or sets RetroDateRate
        /// </summary>
        public decimal RetroDateRate { get; set; }

        /// <summary>
        /// Gets or sets YearsInCMRate
        /// </summary>
        public decimal YearsInCMRate { get; set; }

        /// <summary>
        /// Gets or sets LossExperienceRate
        /// </summary>
        public decimal LossExperienceRate { get; set; }

        /// <summary>
        /// Gets or sets RatingBasis
        /// </summary>
        public string RatingBasis { get; set; }

        #region UNMANNED AIRCRAFT COVERAGE

        /// <summary>
        /// Gets or sets UnmannedAircraftAggregateLimitRate
        /// </summary>
        public decimal UnmannedAircraftAggregateLimitRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverageIncludedinExcessExposure
        /// </summary>
        public string UnmannedAircraftCoverageIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15lbsorLessRate
        /// </summary>
        public decimal UnmannedAircraftCoverage15lbsorLessRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15lbsorLessPremium
        /// </summary>
        public int UnmannedAircraftCoverage15lbsorLessPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15PT1_to_lt55lbsRate
        /// </summary>
        public decimal UnmannedAircraftCoverage15PT1_to_lt55lbsRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage15PT1_to_lt55lbsPremium
        /// </summary>
        public int UnmannedAircraftCoverage15PT1_to_lt55lbsPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage_gteq55lbslbsRate
        /// </summary>
        public decimal UnmannedAircraftCoverage_gteq55lbslbsRate { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftcoverage_gteq55lbsPremium
        /// </summary>
        public int UnmannedAircraftCoverage_gteq55lbsPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftUnModifiedTotalPremium
        /// </summary>
        public int UnmannedAircraftUnModifiedTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftModifiedTotalPremium
        /// </summary>
        public int UnmannedAircraftModifiedTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftTotalUnits
        /// </summary>
        public int UnmannedAircraftTotalUnits { get; set; }

        /// <summary>
        /// Gets or sets UnmannedAircraftUnModifiedWithoutExcessTotalPremium
        /// </summary>
        public int UnmannedAircraftUnModifiedWithoutExcessTotalPremium { get; set; }

        #endregion

        #region Optional Coverage

        /// <summary>
        /// Gets or sets LawEnforcementOptionalCoverageOutputModel
        /// </summary>
        public LawEnforcementOptionalCoverageOutputModel LawEnforcementOptionalCoverageModel { get; set; }

        #endregion

        /// <summary>
        /// Gets or sets BasePremium
        /// </summary>
        public int BasePremium { get; set; }

        /// <summary>
        /// Gets or sets NonModifiedPremium
        /// </summary>
        public int NonModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets ManualPremium
        /// </summary>
        public int ManualPremium { get; set; }

        /// <summary>
        /// Gets or sets IRPMRate
        /// </summary>
        public decimal IRPMRate { get; set; }

        /// <summary>
        /// Gets or sets IRPMPremium
        /// </summary>
        public int IRPMPremium { get; set; }

        /// <summary>
        /// Gets or sets TerrorismRate
        /// </summary>
        public decimal TerrorismRate { get; set; }

        /// <summary>
        /// Gets or sets TerrorismPremium
        /// </summary>
        public int TerrorismPremium { get; set; }

        /// <summary>
        /// Gets or sets OtherModRate
        /// </summary>
        public decimal OtherModRate { get; set; }

        /// <summary>
        /// Gets or sets OtherModPremium
        /// </summary>
        public int OtherModPremium { get; set; }

        /// <summary>
        /// Gets or sets TierRate
        /// </summary>
        public decimal TierRate { get; set; }

        /// <summary>
        /// Gets or sets TierPremium
        /// </summary>
        public int TierPremium { get; set; }

        /// <summary>
        /// Gets or sets LawFinalModifiedPremium
        /// </summary>
        public int LawFinalModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets LawTotalUnmodifiedWithoutExcessPremium
        /// </summary>
        public int LawTotalUnmodifiedWithoutExcessPremium { get; set; }
    }
}
