﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace Models.ApiModels.LineOfBusiness.Ocp.Input
{
    public class OcpInputModel
    {

        public OcpInputModel()
        {
        }

        /// <summary>
        /// Gets or sets Limit
        /// </summary>
        public decimal Limit { get; set; }

        /// <summary>
        /// Gets or sets AggregateLimit
        /// </summary>
        public decimal AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets IRPMFlag
        /// </summary>
        public bool IRPMFlag { get; set; }

        /// <summary>
        /// Gets or sets LineOfBusiness
        /// </summary>
         [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "OCP";
    }
}
