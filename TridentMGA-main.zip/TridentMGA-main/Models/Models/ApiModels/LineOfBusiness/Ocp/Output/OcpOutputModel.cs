﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Ocp.Output
{
    public class OcpOutputModel
    {
        /// <summary>
        /// Gets or set BasePremium
        /// </summary>
        public decimal BasePremium { get; set; }

        /// <summary>
        /// Gets or set NonModifiedPremium
        /// </summary>
        public decimal NonModifiedPremium { get; set; }

        /// <summary>
        /// Gets or set ManualPremium
        /// </summary>
        public decimal ManualPremium { get; set; }

        /// <summary>
        /// Gets or set IRPMRate
        /// </summary>
        public decimal IRPMRate { get; set; }

        /// <summary>
        /// Gets or set IRPMPremium
        /// </summary>
        public decimal IRPMPremium { get; set; }

        /// <summary>
        /// Gets or set TerrorismRate
        /// </summary>
        public decimal TerrorismRate { get; set; }

        /// <summary>
        /// Gets or set TerrorismPremium
        /// </summary>
        public decimal TerrorismPremium { get; set; }

        /// <summary>
        /// Gets or set OtherModRate
        /// </summary>
        public decimal OtherModRate { get; set; }

        /// <summary>
        /// Gets or set OtherModPremium
        /// </summary>
        public decimal OtherModPremium { get; set; }

        /// <summary>
        /// Gets or set TierRate
        /// </summary>
        public decimal TierRate { get; set; }

        /// <summary>
        /// Gets or set TierPremium
        /// </summary>
        public decimal TierPremium { get; set; }

        /// <summary>
        /// Gets or set OCPFinalPremium
        /// </summary>
        public decimal OCPFinalPremium { get; set; }
    }
}
