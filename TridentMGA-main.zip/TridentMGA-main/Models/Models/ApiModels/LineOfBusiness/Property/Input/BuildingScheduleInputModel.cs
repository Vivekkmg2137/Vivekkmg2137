﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Property.Input
{
    public class BuildingScheduleInputModel
    {
        /// <summary>
        /// Gets or sets Loc value.
        /// </summary>
        public int Loc { get; set; }

        /// <summary>
        /// Gets or sets Bldg value.
        /// </summary>
        public int Bldg { get; set; }

        /// <summary>
        /// Gets or sets Agg value.
        /// </summary>
        public int Agg { get; set; }

        /// <summary>
        /// Gets or sets StreetAddress value.
        /// </summary>
        public string StreetAddress { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// Gets or sets Zip
        /// </summary>
        public string Zip { get; set; }

        /// <summary>
        ///Gets or sets OccupancyDescription
        /// </summary>
        public string OccupancyDescription { get; set; }

        /// <summary>
        /// Gets or sets ConstructionType.
        /// </summary>
        public string Construction { get; set; }

        /// <summary>
        /// Gets or Sets Valuation
        /// </summary>
        public string Valuation { get; set; }

        /// <summary>
        /// Gets or sets BuildingLimit.
        /// </summary>
        public decimal BuildingLimit { get; set; }

        /// <summary>
        /// Gets or sets ContentsLimit.
        /// </summary>
        public decimal ContentsLimit { get; set; }

        /// <summary>
        /// Gets or sets TotalLimit.
        /// </summary>
        public decimal TotalLimit { get; set; }

        /// <summary>
        /// Gets or sets HazardGroup.
        /// </summary>
        public decimal HazardGroup { get; set; }

        /// <summary>
        /// Gets or sets ProtectionClass.
        /// </summary>
        public decimal ProtectionClass { get; set; }

        /// <summary>
        /// Gets or sets YearBuilt
        /// </summary>
        public int YearBuilt { get; set; }

        /// <summary>
        /// Gets or sets SquareFootage
        /// </summary>
        public decimal SquareFootage { get; set; }
    }
}
