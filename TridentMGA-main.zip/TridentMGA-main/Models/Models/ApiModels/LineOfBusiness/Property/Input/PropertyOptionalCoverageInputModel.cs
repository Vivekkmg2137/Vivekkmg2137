﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Property.Input
{
    public class PropertyOptionalCoverageInputModel
    {
        #region Additional Covered Property
        /// <summary>
        /// Gets or sets IsAdditionalCoveredPropertyOptionalCoverageSelected
        /// </summary>
        public bool IsAdditionalCoveredPropertyOptionalCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCoveredPropertyOptionalCoverage
        /// </summary>
        public string AdditionalCoveredPropertyOptionalCoverage { get; private set; } = "Additional Covered Property";

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        public string AdditionalCoveredPropertyDescription { get; set; }

        /// <summary>
        /// Gets or sets Limit 
        /// </summary>
        public decimal AdditionalCoveredPropertyLimit { get; set; }

        /// <summary>
        /// Gets or sets Deductible 
        /// </summary>
        public decimal AdditionalCoveredPropertyDeductible { get; set; }

        /// <summary>
        /// Gets or sets RatingBasis 
        /// </summary>
        public string AdditionalCoveredPropertyRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Rate 
        /// </summary>
        public decimal AdditionalCoveredPropertyRate { get; set; }

        /// <summary>
        /// Gets or sets ReturnMethod 
        /// </summary>
        public string AdditionalCoveredPropertyReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Premium 
        /// </summary>
        public decimal AdditionalCoveredPropertyPremium { get; set; }

        #endregion

        #region Alabama Wind & Hail Certificate Credit 

        /// <summary>
        /// Gets or sets Alabama Wind And Hail Certificate Credit Coverage Selected
        /// </summary>
        public bool IsAlabamaWindAndHailCertificateCreditCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCoveredPropertyOptionalCoverage
        /// </summary>
        public string AlabamaWindAndHailCertificateCreditCoverage { get; private set; } = "Alabama Wind & Hail Certificate Credit";

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        public string AlabamaWindAndHailCertificateCreditDescription { get; set; }

        /// <summary>
        /// Gets or sets Limit 
        /// </summary>
        public decimal AlabamaWindAndHailCertificateCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets Deductible 
        /// </summary>
        public decimal AlabamaWindAndHailCertificateCreditDeductible { get; set; }

        /// <summary>
        /// Gets or sets RatingBasis 
        /// </summary>
        public string AlabamaWindAndHailCertificateCreditRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Rate 
        /// </summary>
        public decimal AlabamaWindAndHailCertificateCreditRate { get; set; }

        /// <summary>
        /// Gets or sets ReturnMethod 
        /// </summary>
        public string AlabamaWindAndHailCertificateCreditReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Premium 
        /// </summary>
        public decimal AlabamaWindAndHailCertificateCreditPremium { get; set; }

        #endregion

        #region Money, Securities, Stamps - Temporary Increased Limit of Insurance

        /// <summary>
        /// Gets or sets IsMoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceCoverageSelected
        /// </summary>
        public bool IsMoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceCoverage
        /// </summary>
        public string MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceCoverage { get; private set; } = "Money, Securities, Stamps - Temporary Increased Limit of Insurance";

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceDescription
        /// </summary>
        public string MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceDescription { get; set; }

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceLimit
        /// </summary>
        public decimal MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceLimit { get; set; }

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceDeductible
        /// </summary>
        public decimal MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceDeductible { get; set; }

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceBasis
        /// </summary>
        public string MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceBasis { get; set; }

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceRate
        /// </summary>
        public decimal MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceRate { get; set; }

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceReturnMethod
        /// </summary>
        public string MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium
        /// </summary>
        public decimal MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium { get; set; }
        #endregion

        public List<PropertyOptionalOtherCoverageInputModel> PropertyOptionalOthersCoverageInputModel { get; set; }
    }

    public class PropertyOptionalOtherCoverageInputModel
    {
        /// <summary>
        /// Gets or sets Id
        /// </summary>
        public int Id { get; set; }

        public bool IsOptionalCoverageSelected { get; set; }

        /// <summary>
        /// Gets or sets OptionalCoverage
        /// </summary>
        public string OptionalCoverageName { get; private set; } = "OTHER";
        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets Limit 
        /// </summary>
        public decimal Limit { get; set; }
        /// <summary>
        /// Gets or sets Deductible 
        /// </summary>
        public decimal Deductible { get; set; }
        /// <summary>
        /// Gets or sets RatingBasis 
        /// </summary>
        public string RatingBasis { get; set; }
        /// <summary>
        /// Gets or sets Rate 
        /// </summary>
        public decimal Rate { get; set; }
        /// <summary>
        /// Gets or sets ReturnMethod 
        /// </summary>
        public string ReturnMethod { get; set; }
        /// <summary>
        /// Gets or sets Premium 
        /// </summary>
        public decimal Premium { get; set; }
    }
}
