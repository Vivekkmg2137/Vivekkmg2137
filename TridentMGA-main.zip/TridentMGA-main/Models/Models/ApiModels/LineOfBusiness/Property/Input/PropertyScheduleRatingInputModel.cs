﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Property.Input
{
    public class PropertyScheduleRatingInputModel
    {
        public List<BuildingScheduleInputModel> buildingScheduleInputModels { get; set; }        
    }
}
