﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Property.Input
{
    public class PropertyStateSpecificInputModel
    {
        /// <summary>
     /// Gets or sets WindTotalPremium.
     /// </summary>
        public decimal NewYorkInputWindTotalPremium { get; set; }  //Execute this step only when Premium is manually entered

        /// <summary>
        /// Gets or sets EarthquakeTotalPremium.
        /// </summary>
        public decimal NewYorkInputEarthquakeTotalPremium { get; set; }//Execute this step only when Premium is manually entered

        /// <summary>
        /// Gets or sets FloodTotalPremium.
        /// </summary>
        public decimal NewYorkInputFloodTotalPremium { get; set; }//Execute this step only when Premium is manually entered

        public decimal NewYorkInflationGuard { get; set; }
        public string NewYorkCauseofLoss { get; set; }
        public decimal NewYorkWindAndHailRate { get; set; }
        public decimal NewYorkEarthquakeLimit { get; set; }
        public decimal NewYorkEarthquakeRate { get; set; }
        public decimal NewYorkFloodLimit { get; set; }
        public decimal NewYorkFloodRate { get; set; }

        /// <summary>
        /// Gets or sets Equipment Breakdown Limit.
        /// </summary>
        public decimal NewYorkEquipmentBreakdownLimit { get; set; }

        /// <summary>
        /// Gets or sets PropertyNY360InputModel.
        /// </summary>
        public PropertyNewYork360InputModel PropertyNewYork360InputModel { get; set; }
    }
}
