﻿using Models.ApiModels.LineOfBusiness.Property.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Property.Output
{
    public class BuildingScheduleOutputModel
    {
        /// <summary>
        /// Gets or sets Loc value.
        /// </summary>
        public int Loc { get; set; }

        /// <summary>
        /// Gets or sets Bldg value.
        /// </summary>
        public int Bldg { get; set; }

        /// <summary>
        /// BuildingPremium
        /// </summary>
        public decimal BuildingPremium { get; set; }

        /// <summary>
        /// ContentPremium
        /// </summary>
        public decimal ContentPremium { get; set; }

        /// <summary>
        /// Gets or sets TotalPremium
        /// </summary>
        public decimal TotalPremium { get; set; }

        public decimal ItvPerSqFt { get;set;}
    }
}
