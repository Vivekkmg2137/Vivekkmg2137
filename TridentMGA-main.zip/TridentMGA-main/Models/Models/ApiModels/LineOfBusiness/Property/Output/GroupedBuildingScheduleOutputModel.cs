﻿using Models.ApiModels.LineOfBusiness.Property.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Property.Output
{
    public class GroupedBuildingScheduleOutputModel : BuildingScheduleInputModel
    {
        public decimal TotalTIV { get; set; }
        public decimal BaseRate { get; set; }
        public decimal BuildingPremium { get; set; }
        public decimal SOVPercent { get; set; }
    }
}
