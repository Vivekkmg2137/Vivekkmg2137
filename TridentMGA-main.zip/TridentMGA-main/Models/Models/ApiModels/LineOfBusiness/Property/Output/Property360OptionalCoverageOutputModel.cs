﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Property.Output
{
    public class Property360OptionalCoverageOutputModel
    {
        public List<Property360OptionalLossOfMunicipalTaxRevenueOutputModel> LossOfMunicipalTaxRevenuesOutputModel { get; set; }
    }

    public class Property360OptionalLossOfMunicipalTaxRevenueOutputModel
    {
        /// <summary>
        /// Get or sets Id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets Loss of Municipal Tax Revenue Rate
        /// </summary>                                                                                                                                                                                                          
        public decimal LossOfMunicipalTaxRevenueRate { get; set; }

        /// <summary>
        /// Gets or sets Loss of Municipal Tax AOP Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal LossOfMunicipalTaxRevenueAOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Loss of Municipal Tax 360 Deductible Factor
        /// </summary>                                                                                                                                                                                                          
        public decimal LossOfMunicipalTaxRevenue360DeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Loss of Municipal Tax Revenue Premium
        /// </summary>   
        public decimal LossOfMunicipalTaxRevenuePremium { get; set; }
    }
}
