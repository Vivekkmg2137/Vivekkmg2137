﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Property.Output
{
    public class PropertyOptionalCoverageOutputModel
    {
        #region Additional Covered Property

        /// <summary>
        /// Gets or sets Premium 
        /// </summary>
        public decimal AdditionalCoveredPropertyPremium { get; set; }

        #endregion

        #region Alabama Wind & Hail Certificate Credit 

        /// <summary>
        /// Gets or sets Premium 
        /// </summary>
        public decimal AlabamaWindAndHailCertificateCreditPremium { get; set; }

        #endregion

        #region Money, Securities, Stamps - Temporary Increased Limit of Insurance

        /// <summary>
        /// Gets or sets MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium
        /// </summary>
        public decimal MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium { get; set; }

        #endregion

        public List<PropertyOptionalOtherCoverageOutputModel> PropertyOptionalOthersCoverageOutputModel { get; set; }

    }

    public class PropertyOptionalOtherCoverageOutputModel
    {
        /// <summary>
        /// Gets or set Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Get or sets Premium
        /// </summary>
        public decimal Premium { get; set; }
    }
}
