﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace Models.ApiModels.LineOfBusiness.Property.Output
{
    public class PropertyOutputModel 
    {
        public PropertyOutputModel()
        {
           
        }

        /// <summary>
        /// Gets or sets ProRatafactor.
        /// </summary>
        public decimal ProRatafactor { get; set; }

        /// <summary>
        /// Gets or sets Building TIV.
        /// </summary>
        public decimal BuildingTIV { get; set; }

        /// <summary>
        /// Gets or sets Contents TIV.
        /// </summary>
        public decimal ContentTIV { get; set; }        

        /// <summary>
        /// Gets or sets Total TIV.
        /// </summary>
        public decimal TotalTIV { get; set; }
        public decimal TIVAndAdditionalBenefits { get; set; }
        public decimal TotalExpTIV { get; set; }

              

        /// <summary>
        /// Gets or sets BuildingBaseMLR.
        /// </summary>
        public decimal BuildingBaseMLR { get; set; }

        /// <summary>
        /// Gets or sets BuildingAddtlDef Charge.
        /// </summary>
        public decimal BuildingAddtlDefCharge { get; set; }

        /// <summary>
        /// Gets or sets ContentsBaseMLR.
        /// </summary>
        public decimal ContentsBaseMLR { get; set; }

        /// <summary>
        /// Gets or sets ContentsAddtlDef Charge.
        /// </summary>
        public decimal ContentsAddtlDefCharge { get; set; }

        ///// <summary>
        ///// Gets or sets Deductible.
        ///// </summary>
        //public decimal AOPDeductible { get; set; }

        ///// <summary>
        ///// Gets or sets Coinsurance.
        ///// </summary>
        //public decimal? Coinsurance { get; set; }

        ///// <summary>
        ///// Gets or sets Margin Clause.
        ///// </summary>
        //public decimal? MarginClause { get; set; }

        ///// <summary>
        ///// Gets or sets Valuation.
        ///// </summary>
        //public string Valuation { get; set; }

        /// <summary>
        /// Gets or sets AOP Deductible Factor.
        /// </summary>
        public decimal AOPDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Coinsurance Factor.
        /// </summary>
        public decimal CoinsuranceFactor { get; set; }

        /// <summary>
        /// Gets or sets Margin Clause Factor.
        /// </summary>
        public decimal MarginClauseFactor { get; set; }

        /// <summary>
        /// Gets or sets Valuation Factor.
        /// </summary>
        public decimal ValuationFactor { get; set; }

        /// <summary>
        /// Gets or sets Building Modified MLR.
        /// </summary>
        public decimal BuildingModifiedMLR { get; set; }

        /// <summary>
        /// Gets or sets Contents Modified MLR.
        /// </summary>
        public decimal ContentsModifiedMLR { get; set; }

        /// <summary>
        /// Gets or sets Modified Normal Loss Rate.
        /// </summary>
        public decimal ModifiedNormalLossRate { get; set; }

        /// <summary>
        /// Gets or sets.
        /// </summary>
        public decimal BuildingFinalRate { get; set; }

        /// <summary>
        /// Gets or sets Contents Final Rate.
        /// </summary>
        public decimal ContentsFinalRate { get; set; }

        /// <summary>
        /// Gets or sets Building BPP Premium.
        /// </summary>
        public decimal BuildingBPPPremium { get; set; }

        ///// <summary>
        ///// Gets or sets Business Income And Extra Expense Limit.
        ///// </summary>
        //public decimal BusinessIncomeAndExtraExpenseLimit { get; set; }

        ///// <summary>
        ///// Gets or sets Equipment Breakdown IRPM.
        ///// </summary>
        //public decimal EquipmentBreakdownIRPM { get; set; }

        /// <summary>
        /// Gets or sets Equipment Breakdown IRPM Factor.
        /// </summary>
        public decimal EquipmentBreakdownIRPMFactor { get; set; }

        /// <summary>
        /// Gets or sets Equipment Breakdown Lk2imit Factor.
        /// </summary>
        public decimal EquipmentBreakdownLimitFactor { get; set; }

        /// <summary>
        /// Gets or sets Equipment Breakdown Deductible Factor.
        /// </summary>
        public decimal EquipmentBreakdownDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Business Income And Extra Expense Deductible Factor.
        /// </summary>
        public decimal EquipmentBreakdownBusinessIncomeAndExtraExpenseDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Pollutant CleanUp Limit Factor.
        /// </summary>
        public decimal PollutantCleanUpLimitFactor { get; set; }

        /// <summary>
        /// Gets or sets Refrigerant Contamination Limit Factor.
        /// </summary>
        public decimal RefrigerantContaminationLimitFactor { get; set; }

        ///// <summary>
        ///// Gets or sets SelectedSpoilageType
        ///// </summary>
        //public string SelectedSpoilageType { get; set; }

        /// <summary>
        /// Gets or sets EBSpoilageLimitFactor Factor.
        /// </summary>
        public decimal EBSpoilageLimitFactor { get; set; }


        /// <summary>
        /// Gets or sets Equipment BreakdownSpoilagePercentage Deductible Factor.
        /// </summary>
        public decimal EquipmentBreakdownSpoilagePercentageDeductibleFactor { get; set; }

        /// <summary>
        /// Gets or sets Equipment BreakdownSpoilageDollar Deductible.
        /// </summary>
        public decimal EquipmentBreakdownSpoilageDollarDeductible { get; set; }

        /// <summary>
        /// Gets or sets Equipment BreakdownBuildingOrContents Premium.
        /// </summary>
        public decimal EquipmentBreakdownBuildingOrContentsPremium { get; set; }

        /// <summary>
        /// Gets or sets Equipment BreakdownBusiness Income Premium.
        /// </summary>
        public decimal EquipmentBreakdownBusinessIncomePremium { get; set; }

        /// <summary>
        /// Gets or sets Premium1.
        /// </summary>
        public decimal Premium1 { get; set; }

        /// <summary>
        /// Gets or sets Premium2.
        /// </summary>
        public decimal Premium2 { get; set; }

        /// <summary>
        /// Gets or sets Equipment BreakdownTotal Premium.
        /// </summary>
        public decimal EquipmentBreakdownTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets Equipment Breakdown Limit.
        /// </summary>
        public decimal EquipmentBreakdownLimit { get; set; }

        /// <summary>
        /// Gets or sets Equipment Breakdown Rate.
        /// </summary>
        public decimal EquipmentBreakdownRate { get; set; }

        ///// <summary>
        ///// Gets or sets Sum NetNormalLoss Claims.
        ///// </summary>
        //public decimal SumNetNormalLossClaims { get; set; }

        /// <summary>
        /// Gets or sets LCM Factor.
        /// </summary>
        public decimal LCMFactor { get; set; }

        ///// <summary>
        ///// Gets or sets Normal LossTIV Value.
        ///// </summary>
        //public decimal NormalLossTIVValue { get; set; }

        ///// <summary>
        ///// Gets or sets Wind Building Points.
        ///// </summary>
        //public decimal WindBuildingPoints { get; set; }

        ///// <summary>
        ///// Gets or sets Flood Building Points.
        ///// </summary>
        //public decimal FloodBuildingPoints { get; set; }

        ///// <summary>
        ///// Gets or sets Earth quake Building Points.
        ///// </summary>
        //public decimal EarthquakeBuildingPoints { get; set; }

        /// <summary>
        /// Gets or sets Peril Building Points.
        /// </summary>
        public decimal PerilBuildingPoints { get; set; }

        ///// <summary>
        ///// Gets or sets Building Value.
        ///// </summary>
        //public decimal BuildingValue { get; set; }

        /// <summary>
        /// Gets or sets Building DefPointsNo Perils.
        /// </summary>
        public decimal BuildingDefPointsNoPerils { get; set; }

        /// <summary>
        /// Gets or sets Building AddtlChargeRateNo Perils.
        /// </summary>
        public decimal BuildingAddtlChargeRateNoPerils { get; set; }

        ///// <summary>
        ///// Gets or sets Wind Contents Points.
        ///// </summary>
        //public decimal WindContentsPoints { get; set; }

        ///// <summary>
        ///// Gets or sets Flood Contents Point.
        ///// </summary>
        //public decimal FloodContentsPoint { get; set; }

        ///// <summary>
        ///// Gets or sets Earthquake Contents Points.
        ///// </summary>
        //public decimal EarthquakeContentsPoints { get; set; }

        /// <summary>
        /// Gets or sets Peril Contents Points.
        /// </summary>
        public decimal PerilContentsPoints { get; set; }

        ///// <summary>
        ///// Gets or sets Contents Value.
        ///// </summary>
        //public decimal ContentsValue { get; set; }

        /// <summary>
        /// Gets or sets Contents DefPointsNo Perils.
        /// </summary>
        public decimal ContentsDefTotalPointsNoPerils { get; set; }

        /// <summary>
        /// Gets or sets Contents AddtlCharge RateNo Perils.
        /// </summary>
        public decimal ContentsAddtlChargeRateNoPerils { get; set; }

        /// <summary>
        /// Gets or sets Building ModifiedMLRNo Perils.
        /// </summary>
        public decimal BuildingModifiedMLRNoPerils { get; set; }

        /// <summary>
        /// Gets or sets Building CombinedRateNo Perils.
        /// </summary>
        public decimal BuildingCombinedRateNoPerils { get; set; }

        /// <summary>
        /// Gets or sets Building PremiumNo Perils.
        /// </summary>
        public decimal BuildingPremiumNoPerils { get; set; }

        /// <summary>
        /// Gets or sets Building Premium Total.
        /// </summary>
        public decimal BuildingPremiumTotal { get; set; }

        /// <summary>
        /// Gets or sets Building PremiumFor Perils.
        /// </summary>
        public decimal BuildingPremiumForPerils { get; set; }

        /// <summary>
        /// Gets or sets Contents ModifiedMLRNo Perils.
        /// </summary>
        public decimal ContentsModifiedMLRNoPerils { get; set; }

        /// <summary>
        /// Gets or sets Contents CombinedRateNo Perils.
        /// </summary>
        public decimal ContentsCombinedRateNoPerils { get; set; }

        /// <summary>
        /// Gets or sets Contents PremiumNo Perils.
        /// </summary>
        public decimal ContentsPremiumNoPerils { get; set; }

        /// <summary>
        /// Gets or sets Contents Premium Total.
        /// </summary>
        public decimal ContentsPremiumTotal { get; set; }

        /// <summary>
        /// Gets or sets Contents PremiumFor Perils.
        /// </summary>
        public decimal ContentsPremiumForPerils { get; set; }

        /// <summary>
        /// Gets or sets Wind Building Premium.
        /// </summary>
        public decimal WindBuildingPremium { get; set; }

        /// <summary>
        /// Gets or sets Wind Content Premium.
        /// </summary>
        public decimal WindContentPremium { get; set; }

        /// <summary>
        /// Gets or sets Wind Total Premium.
        /// </summary>
        public decimal WindTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets Flood Building Premium.
        /// </summary>
        public decimal FloodBuildingPremium { get; set; }

        /// <summary>
        /// Gets or sets Flood Content Premium.
        /// </summary>
        public decimal FloodContentPremium { get; set; }

        /// <summary>
        /// Gets or sets FLOOD TOTAL PREMIUM.
        /// </summary>
        public decimal FloodTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets Earthquake Building Premium.
        /// </summary>
        public decimal EarthquakeBuildingPremium { get; set; }

        /// <summary>
        /// Gets or sets Earthquake Content Premium.
        /// </summary>
        public decimal EarthquakeContentPremium { get; set; }

        /// <summary>
        /// Gets or sets EARTHQUAKE TOTAL PREMIUM.
        /// </summary>
        public decimal EarthquakeTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets NormalLossRate.
        /// </summary>
        public decimal NormalLossRate { get; set; }

        
        public decimal EquipmentBreakdownMinimumPremium { get; set; }

        #region Hazards Points

        public decimal ClimaticalHazardsBuildingPointsSubtotal { get; set; }
        public decimal ClimaticalHazardsContentPointsSubtotal { get; set; }
        public decimal DisasterExposureBuildingPointsSubtotal { get; set; }
        public decimal DisasterExposureContentPointsSubtotal { get; set; }
        public decimal SpecialOccupancyBuildingPointsSubtotal { get; set; }
        public decimal SpecialOccupancyContentPointsSubtotal { get; set; }
        public decimal PrivateProtectionBuildingPointsSubtotal { get; set; }
        public decimal PrivateProtectionContentPointsSubtotal { get; set; }
        public decimal SpecificInsuranceBuildingPointsSubtotal { get; set; }
        public decimal SpecificInsuranceContentPointsSubtotal { get; set; }
        public decimal PublicProtectionBuildingPointsSubtotal { get; set; }
        public decimal PublicProtectionContentPointsSubtotal { get; set; }
        public decimal ExternalExposureBuildingPointsSubtotal { get; set; }
        public decimal ExternalExposureContentPointsSubtotal { get; set; }
        public decimal ConstructionBuildingPointsSubtotal { get; set; }
        public decimal ConstructionContentPointsSubtotal { get; set; }
        public decimal CommoditiesBuildingPointsSubtotal { get; set; }
        public decimal CommoditiesContentPointsSubtotal { get; set; }
        public decimal FloodBuildingPointsSubtotal { get; set; }
        public decimal FloodContentPointsSubtotal { get; set; }
        public decimal EarthMovementBuildingPointsSubtotal { get; set; }
        public decimal EarthMovementContentPointsSubtotal { get; set; }
        public decimal ExclusionorReductionofCoverageBuildingPointsSubtotal { get; set; }
        public decimal ExclusionorReductionofCoverageContentPointsSubtotal { get; set; }
        public decimal BuildingDefTotalPoints { get; set; }
        public decimal ContentsDefTotalPoints { get; set; }

        #endregion

        /// </summary>
        public decimal OptionalCoverageTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets BasePremium Calculation.
        /// </summary>
        public decimal BasePremium { get; set; }        

        /// <summary>
        /// Gets or sets NonModifiedPremium Calculation.
        /// </summary>
        public decimal NonModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets ManualPremium Calculation.
        /// </summary>
        public decimal ManualPremium { get; set; }

        /// <summary>
        /// Gets or sets Property360 Premiums. : (Sum of 360 Coverage Modifications Premium + Sum of Golf Courses coverages Premium + Sum of  Optional Coverages Premium )
        /// </summary>
        public decimal Property360TotalPremiums { get; set; } 

        /// <summary>
        /// Gets or sets BusinessIncome And ExtraExpense Coverage Premium.
        /// </summary>
        public decimal BusinessIncomeAndExtraExpense360CoveragePremium { get; set; }

        /// <summary>
        /// Gets or sets Property360GolfCourceTotalPremium
        /// </summary>
        public decimal Property360GolfCourceTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets Property360OptionalCoverageTotalPremium
        /// </summary>
        public decimal Property360OptionalCoverageTotalPremium { get; set; }

        /// <summary>
        /// Gets or sets Property360ModificationCoverageTotalPremium
        /// </summary>
        public decimal Property360ModificationCoverageTotalPremium { get; set; }

        ///// <summary>
        ///// Gets or sets LargeRiskFactor.
        ///// </summary>
        //public decimal LargeRiskFactor { get; set; }



        /// <summary>
        /// Gets or sets LOBMinimum Premium.
        /// </summary>
        public decimal LOBMinimumPremium { get; set; }

        /// <summary>
        /// Gets or sets TierPremium Calculation.
        /// </summary>
        public decimal TierPremium { get; set; }

        /// <summary>
        /// Gets or sets Tier Factor.
        /// </summary>
        public decimal TierFactor { get; set; }

       

        /// <summary>
        /// Gets or sets IRPMPremium Calculation.
        /// </summary>
        public decimal IRPMPremium { get; set; }

        /// <summary>
        /// Gets or sets IRPM Factor.
        /// </summary>
        public decimal IRPMFactor { get; set; }
        

        /// <summary>
        /// Gets or sets OtherModPremium Calculation.
        /// </summary>
        public decimal OtherModPremium { get; set; }

        ///// <summary>
        ///// Gets or sets OtherMod Factor.
        ///// </summary>
        //public decimal OtherModFactor { get; set; }
        

        /// <summary>
        /// Gets or sets TerrorismPremium Calculation.
        /// </summary>
        public decimal TerrorismPremium { get; set; }

        /// <summary>
        /// Gets or sets Terrorism Factor.
        /// </summary>
        public decimal TerrorismFactor { get; set; }

        /// <summary>
        /// Gets or sets ModifiedPremium Calculation.
        /// </summary>
        public decimal ModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets FireSafetySurchargeRate
        /// </summary>
        public decimal FireSafetySurchargeRate { get; set; }

        /// <summary>
        /// Gets or sets FireSafetySurcharge
        /// </summary>
        public decimal FireSafetySurcharge { get; set; }
        
        /// <summary>
        /// Gets or sets Property360OutputModel.
        /// </summary>
        public Property360OutputModel Property360OutputModel { get; set; }

        #region Optional Coverage
        public PropertyOptionalCoverageOutputModel PropertyOptionalCoveragesModel { get; set; }
        #endregion

        public PropertyScheduleRatingOutputModel ScheduleRatingOutputModel { get; set; }

        public PropertyStateSpecificOutputModel PropertyStateSpecificOutputModel { get; set; }
    }

}
