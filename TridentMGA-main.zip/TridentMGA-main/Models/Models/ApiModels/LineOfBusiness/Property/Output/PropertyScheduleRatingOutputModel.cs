﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.Property.Output
{
    public class PropertyScheduleRatingOutputModel
    {
        public PropertyScheduleRatingOutputModel()
        {
            GroupedScheduleRatings = new List<GroupedBuildingScheduleOutputModel>();
            IndividualScheduleRating = new List<BuildingScheduleOutputModel>();
        }
        public List<GroupedBuildingScheduleOutputModel> GroupedScheduleRatings { get; set; }
        public List<BuildingScheduleOutputModel> IndividualScheduleRating { get; set; }

        /// <summary>
        /// Get or sets  TotalBuildings : It is equal to the total count of building added in Schedule
        /// </summary>
        public decimal TotalBuildings { get; set; }

        ///// <summary>
        ///// Get or sets  TotalBuildingLimit : It is equal to the total of building limits in Schedule
        ///// </summary>
        //public decimal TotalBuildingLimit { get; set; }

        ///// <summary>
        ///// Get or sets  TotalContentLimit : It is equal to the total of content limits in Schedule
        ///// </summary>
        //public decimal TotalContentLimit { get; set; }

        ///// <summary>
        ///// Get or sets  TotalPropertyLimit : It is equal to the total of property limits in Schedule
        ///// </summary>
        //public decimal TotalPropertyLimit { get; set; }

        /// <summary>
        /// Get or sets  TotalSquareFootage : It is equal to the total of square footage in Schedule
        /// </summary>
        public decimal TotalSquareFootage { get; set; }

        /// <summary>
        /// Gets or sets AvgPricePerSquareFoot :  Average of ITV $/ Sq. Ft. of all buildings from schedule
        /// </summary>
        public decimal AvgPricePerSquareFoot { get; set; }

        /// <summary>
        /// Gets or set FinalPropertyPremium
        /// </summary>
        public decimal FinalPropertyPremium { get; set; }

        /// <summary>
        /// Gets or set TotalBuildingPremium
        /// </summary>
        public decimal TotalBuildingPremium { get; set; }

        /// <summary>
        /// Gets or set TotalContentPremium
        /// </summary>
        public decimal TotalContentPremium { get; set; }

        /// <summary>
        /// Gets or set TotalSchedulePremium
        /// </summary>
        public decimal TotalSchedulePremium { get; set; }

        /// <summary>
        /// Difference
        /// </summary>
        public decimal Difference { get; set; }

        /// <summary>
        /// BuildingModifiedPremium
        /// </summary>
        public decimal BuildingModifiedPremium { get; set; }

        /// <summary>
        /// TotalPremium
        /// </summary>
        public decimal ModifiedTotalSchedulePremium { get; set; }

        /// <summary>
        /// PropertyRate
        /// </summary>
        public decimal PropertyRate { get; set; }

        //public decimal ModifiedTotalPremium { get; set; }   
    }
}
