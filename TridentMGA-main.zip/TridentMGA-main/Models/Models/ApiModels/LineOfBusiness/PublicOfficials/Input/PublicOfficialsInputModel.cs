﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.PublicOfficials.Input
{
    public class PublicOfficialsInputModel
    {
        public PublicOfficialsCWInputModel  CW { get; set; }
        public PublicOfficialsNYInputModel NY { get; set; }
    }
}
