﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Models.ApiModels.LineOfBusiness.PublicOfficials.Input
{
    public class PublicOfficialsNYInputModel
    {
        /// <summary>
        /// Gets or sets LineOfBusiness.
        /// </summary>
        [JsonIgnore]
        public string LineOfBusiness { get; private set; } = "PO";

        /// <summary>
        /// Gets or sets Exposure.
        /// </summary>
        public int Exposure { get; set; }

        /// <summary>
        /// Gets or sets Exposure Rate.
        /// </summary>
        public decimal ExposureRate { get; set; }

        /// <summary>
        /// Gets or sets Liability Limit.
        /// </summary>
        public int LiabilityLimit { get; set; }

        /// <summary>
        /// Gets or sets Aggregate Limit.
        /// </summary>
        public int AggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Liability Limit Rate.
        /// </summary>
        public decimal LiabilityLimitRate { get; set; }

        /// <summary>
        /// Gets or sets EPInclusionExclusion.
        /// </summary>
        public string EPInclusionExclusion { get; set; }

        /// <summary>
        /// Gets or sets NYEPInclusionExclusion
        /// </summary>
        public bool NYEPInclusionExclusion { get; set; }

        /// <summary>
        /// Gets or sets NYEPLimit
        /// </summary>
        public int NYEPLimit { get; set; }

        /// <summary>
        /// Gets or sets NYEPLimitRate
        /// </summary>
        public decimal NYEPLimitRate { get; set; }

        /// <summary>
        /// Gets or sets NYEPAggLimit
        /// </summary>
        public int NYEPAggLimit { get; set; }

        /// <summary>
        /// Gets or sets Deductible/SIR.
        /// </summary>
        public string DeductibleSIR { get; set; }

        /// <summary>
        /// Gets or sets Retention.
        /// </summary>
        public string Retention { get; set; }

        /// <summary>
        /// Gets or sets Aggregate Retention.
        /// </summary>
        public int AggregateRetention { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Expense.
        /// </summary>
        public string Expense { get; set; }

        /// <summary>
        /// Gets or sets PolicyType.
        /// </summary>
        public string PolicyType { get; set; }

        /// <summary>
        /// Gets or sets RetroDate.
        /// </summary>
        public DateTime RetroDate { get; set; }

        /// <summary>
        /// Gets or sets YearsinCMProgram.
        /// </summary>
        public int YearsInCMProgram { get; set; }

        /// <summary>
        /// Gets or sets IRPMApplies.
        /// </summary>
        public bool IRPMApplies { get; set; }

        /// <summary>
        /// Gets or sets IRPMFactor.
        /// </summary>
        public Decimal IRPMFactor { get; set; }

        /// <summary>
        /// Gets or sets Other Mod Rate.
        /// </summary>
        public Decimal OtherModRate { get; set; }

        //GRID START - OPTIONAL COVERAGES
        public PublicOfficialsNYOptionalCoverageInputModel PublicOfficialsOptionalCoverageModel { get; set; }
    }
}
