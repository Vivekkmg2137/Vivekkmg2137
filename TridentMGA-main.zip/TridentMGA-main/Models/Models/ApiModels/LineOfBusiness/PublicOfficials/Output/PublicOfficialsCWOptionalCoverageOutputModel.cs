﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.PublicOfficials.Output
{
    public class PublicOfficialsCWOptionalCoverageOutputModel
    {
        #region NonMonetaryDefense

        /// <summary>
        /// Gets or sets NonMonetaryDefenseIsSelected
        /// </summary>
        public bool NonMonetaryDefenseIsSelected { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseLimit
        /// </summary>
        public int NonMonetaryDefenseLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseAggregateLimit
        /// </summary>
        public int NonMonetaryDefenseAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseDeductible
        /// </summary>
        public int NonMonetaryDefenseDeductible { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRatingBasis
        /// </summary>
        public string NonMonetaryDefenseRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseReturnMethod
        /// </summary>
        public string NonMonetaryDefenseReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets NonMonetaryDefenseRate
        /// </summary>
        public Decimal NonMonetaryDefenseRate { get; set; }

        /// <summary>
        /// Gets or sets Non-Monetary Defense Unmodifed Premium
        /// </summary>
        public int NonMonetaryDefenseUnModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Non-Monetary Defense Modifed Premium
        /// </summary>
        public int NonMonetaryDefenseModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Non-Monetary Defense IncludedInExcessExposure
        /// </summary>
        public string NonMonetaryDefenseIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets or sets Non-Monetary Defense UnModified Without Excess Premium
        /// </summary>
        public int NonMonetaryDefenseUnModifiedWithoutExcessPremium { get; set; }
        #endregion

        #region InverseCondemnation

        /// <summary>
        /// Gets or sets Inverse CondemnationIsSelected
        /// </summary>
        public bool InverseCondemnationIsSelected { get; set; }

        /// <summary>
        /// Gets or sets Inverse CondemnationLimit
        /// </summary>
        public int InverseCondemnationLimit { get; set; }

        /// <summary>
        /// Gets or sets Inverse CondemnationAggregate Limit
        /// </summary>
        public int InverseCondemnationAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Inverse CondemnationDeductible
        /// </summary>
        public int InverseCondemnationDeductible { get; set; }

        /// <summary>
        /// Gets or sets Inverse CondemnationRating Basis
        /// </summary>
        public string InverseCondemnationRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Inverse Condemnation Return Method
        /// </summary>
        public string InverseCondemnationReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Inverse CondemnationRate
        /// </summary>
        public decimal InverseCondemnationRate { get; set; }

        /// <summary>
        /// Gets or sets Inverse CondemnationUnmodifed Premium
        /// </summary>
        public int InverseCondemnationUnModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Inverse CondemnationUnmodifed Premium
        /// </summary>
        public int InverseCondemnationModifiedPremium { get; set; }

        /// <summary>
        /// Gets set InverseCondemnationIncludedInExcessExposure
        /// </summary>
        public string InverseCondemnationIncludedInExcessExposure { get; set; }

        /// <summary>
        /// Gets Sets Inverse Condemnation UnModified Without Excess Premium
        /// </summary>
        public int InverseCondemnationUnModifiedWithoutExcessPremium { get; set; }

        #endregion

        #region SupplExtendedReportingPeriod

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period IsSelected
        /// </summary>
        public bool SupplExtendedReportingPeriodIsSelected { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Limit
        /// </summary>
        public int SupplExtendedReportingPeriodLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Aggregate Limit
        /// </summary>
        public int SupplExtendedReportingPeriodAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Deductible
        /// </summary>
        public int SupplExtendedReportingPeriodDeductible { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rating Basis
        /// </summary>
        public string SupplExtendedReportingPeriodRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Return Method
        /// </summary>
        public string SupplExtendedReportingPeriodReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Rate
        /// </summary>
        public decimal SupplExtendedReportingPeriodRate { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodifed Premium
        /// </summary>
        public int SupplExtendedReportingPeriodUnModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Suppl.Extended Reporting Period Unmodifed Premium
        /// </summary>
        public int SupplExtendedReportingPeriodModifiedPremium { get; set; }

        /// <summary>
        /// Gets set SupplExtendedReportingPeriodIncludedInExcessExpsure
        /// </summary>
        public string SupplExtendedReportingPeriodIncludedInExcessExpsure { get; set; }

        /// <summary>
        /// Gets Sets SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium
        /// </summary>
        public int SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium { get; set; }
        #endregion

        //"GRID START -OTHER COVERAGES"
        public List<PublicOfficialsCWOtherCoverageOutputModel> PublicOfficialsOtherCoverageModel { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Total Premium
        /// </summary>
        public int OtherCoveragesTotalPremium { get; set; }
    }
}
