﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.PublicOfficials.Output
{
    public class PublicOfficialsNYOtherCoverageOutputModel
    {
        /// <summary>
        /// Gets or sets Other Coverage ID
        /// </summary>
        public int OtherCoverageID { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Description
        /// </summary>
        public string OtherCoverageDescription { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Limit
        /// </summary>
        public int OtherCoverageLimit { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Aggregate Limit
        /// </summary>
        public int OtherCoverageAggregateLimit { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Deductible
        /// </summary>
        public int OtherCoverageDeductible { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Rate
        /// </summary>
        public decimal OtherCoverageRate { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Rating Basis
        /// </summary>
        public string OtherCoverageRatingBasis { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Return Method
        /// </summary>
        public string OtherCoverageReturnMethod { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage UnModified Premium
        /// </summary>
        public int OtherCoverageUnModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Modifed Premium
        /// </summary>
        ///  
        public int OtherCoverageModifiedPremium { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage UnModified Without Excess Premium
        /// </summary>
        public int OtherCoverageUnModifiedWithoutExcessPremium { get; set; }

        /// <summary>
        /// Gets or sets Other Coverage Included in Excess Exposure
        /// </summary>
        public string OtherCoverageIncludedInExcessExposure { get; set; }
    }
}
