﻿using Models.ApiModels.LineOfBusiness.PublicOfficials.Output;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.LineOfBusiness.PublicOfficials
{
    public class PublicOfficialsOutputModel
    {
        public PublicOfficialsCWOutputModel CW { get; set; }
        public PublicOfficialsNYOutputModel NY { get; set; }
    }
}
