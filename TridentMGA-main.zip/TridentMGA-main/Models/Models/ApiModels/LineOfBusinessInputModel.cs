﻿using Models.ApiModels.LineOfBusiness.Auto;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Input;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPracticesSchool.Input;
using Models.ApiModels.LineOfBusiness.Excess.Input;
using Models.ApiModels.LineOfBusiness.GeneralLiability.Input;
using Models.ApiModels.LineOfBusiness.InlandMarine.Input;
using Models.ApiModels.LineOfBusiness.LawEnforcement.Input;
using Models.ApiModels.LineOfBusiness.Ocp.Input;
using Models.ApiModels.LineOfBusiness.Property.Input;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Input;
using System;
using System.Collections.Generic;
using System.Text;
using Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Input;

namespace Models.ApiModels
{
    public class LineOfBusinessInputModel
    {
        public PropertyInputModel Property { get; set; }

        public AutoInputModel Auto { get; set; }

        public GeneralLiabilityInputModel GeneralLiability { get; set; }
               
        public EmploymentPracticesInputModel EmploymentPractices  { get; set; }

        public EmploymentPracticesSchoolInputModel EmploymentPracticesSchool { get; set; }
        
        public InlandMarineInputModel InlandMarine { get; set; }

        public ExcessInputModel Excess { get; set; }

        public OcpInputModel Ocp1 { get; set; }
        public OcpInputModel Ocp2 { get; set; }
        public OcpInputModel Ocp3 { get; set; }
        public OcpInputModel Ocp4 { get; set; }
        public OcpInputModel Ocp5 { get; set; }

        public LawEnforcementInputModel LawEnforcement { get; set; }
        /// <summary>
        /// Output Model for EL 
        /// </summary>
        public EducatorsLegalInputModel EducatorsLegal { get; set; }

        public PublicOfficialsInputModel PublicOfficials { get; set; }

        public DirectorsAndOfficersInputModel DirectorsAndOfficers { get; set; }
    }
}
