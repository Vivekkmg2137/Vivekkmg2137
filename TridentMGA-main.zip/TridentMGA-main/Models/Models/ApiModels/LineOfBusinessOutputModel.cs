﻿using Models.ApiModels.LineOfBusiness.Auto;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output;
using Models.ApiModels.LineOfBusiness.EmploymentPracticesSchool.Output;
using Models.ApiModels.LineOfBusiness.LawEnforcement.Output;
using Models.ApiModels.LineOfBusiness.Ocp.Output;
using Models.ApiModels.LineOfBusiness.Property.Output;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Output;
using System;
using System.Collections.Generic;
using System.Text;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Output;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Output;
using Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Output;
using Models.ApiModels.LineOfBusiness.PublicOfficials;
using Models.ApiModels.LineOfBusiness.GeneralLiability.output;

namespace Models.ApiModels
{
    public class LineOfBusinessOutputModel
    {
        public PropertyOutputModel Property { get; set; }

        public AutoOutputModel Auto { get; set; }

        public GeneralLiabilityOutputModel GeneralLiability { get; set; }

        public EmploymentPracticesOutputModel EmploymentPractices { get; set; }
        public EmploymentPracticesSchoolOutputModel EmploymentPracticesSchool { get; set; }
        
        public OcpOutputModel Ocp1 { get; set; } 
        public OcpOutputModel Ocp2 { get; set; } 
        public OcpOutputModel Ocp3 { get; set; } 
        public OcpOutputModel Ocp4 { get; set; } 
        public OcpOutputModel Ocp5 { get; set; }
        public LawEnforcementOutputModel LawEnforcement { get; set; }

        /// <summary>
        /// Input Model for EL 
        /// </summary>
        public EducatorsLegalOutputModel EducatorsLegal { get; set; }

        public PublicOfficialsOutputModel PublicOfficials { get; set; }

        public DirectorsAndOfficersOutputModel DirectorsAndOfficers { get; set; }
    }
}
