﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.Policy
{
    public class LastTransactionModel
    {
        /// <summary>
        /// Gets or sets Premium.
        /// </summary>
        public decimal LastPremium { get; set; }
    }
}
