﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.Policy
{
    public class PremiumSummaryModel
    {
        /// <summary>
        /// Gets or sets Premium.
        /// </summary>
        public decimal Premium { get; set; }
    }
}
