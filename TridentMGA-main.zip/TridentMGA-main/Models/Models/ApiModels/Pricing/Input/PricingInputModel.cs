﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.Pricing.Input
{
    public class PricingInputModel
    {
        public bool TerrorismAcceptedRejected { get; set; }
        public string TierPlan { get; set; }
        public string NYFTZ { get; set; }

    }
}
