﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels.Pricing.Output
{
    public class PricingOutputModel
    {
        public int PropertyLimit { get; set; }
        public int PropertyDeductible { get; set; }
        public string ALLimit { get; set; }
        public int ALDeductible { get; set; }
        public string APDLimit { get; set; }
        public string APDDeductible { get; set; }
        public string GLLimit { get; set; }
        public int GLDeductible { get; set; }
        public int POLimit { get; set; }
        public string PODeductible { get; set; }
        public int ELLimit { get; set; }
        public string ELDeductible { get; set; }
        public int DOLimit { get; set; }
        public int DODeductible { get; set; }
        public int EPLimit { get; set; }
        public int EPDeductible { get; set; }
        public int EPSLimit { get; set; }
        public int EPSDeductible { get; set; }
        public int LELimit { get; set; }
        public string LEDeductible { get; set; }
        public int IMLimit { get; set; }
        public int IMDeductible { get; set; }
        public int CRLimit { get; set; }
        public int CRDeductible { get; set; }
        public int ExLimit { get; set; }
        public int ExDeductible { get; set; }
        public int OCP1Limit { get; set; }
        public string OCP1Deductible { get; set; }
        public int OCP2Limit { get; set; }
        public string OCP2Deductible { get; set; }
        public int OCP3Limit { get; set; }
        public string OCP3Deductible { get; set; }
        public int OCP4Limit { get; set; }
        public string OCP4Deductible { get; set; }
        public int OCP5Limit { get; set; }
        public string OCP5Deductible { get; set; }
        public int TotalManualPremium { get; set; }
        public int TotalTierPremium { get; set; }
        public int TotalIRPMPremium { get; set; }
        public int TotalOtherModPremium { get; set; }
        public int TotalTerrorismPremium { get; set; }
        public int TotalFinalRatedPremium { get; set; }
    }
}
