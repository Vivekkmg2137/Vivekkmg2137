﻿using Models.ApiModels.Policy;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels
{
    /// <summary>
    /// RaterFacade Model
    /// </summary>
    public class RaterFacadeModel
    {
        public RaterFacadeModel()
        {           
        }

        /// <summary>
        /// Gets or sets RaterInput Facade Model
        /// </summary>
        public RaterInputFacadeModel RaterInputFacadeModel { get; set; }

        /// <summary>
        /// Gets or sets RaterOutput Facade Model
        /// </summary>
        public RaterOutputFacadeModel RaterOutputFacadeModel { get; set; }
    }
}
