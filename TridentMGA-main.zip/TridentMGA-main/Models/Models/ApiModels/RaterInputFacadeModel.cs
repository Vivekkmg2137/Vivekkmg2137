﻿using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels
{
    /// <summary>
    /// RaterInputFacadeModel
    /// </summary>
    public class RaterInputFacadeModel
    {
        /// <summary>
        /// RaterInputFacadeModel
        /// </summary>
        public RaterInputFacadeModel()
        {
            LineOfBusiness = new LobIncludedModel();
        }

        /// <summary>
        /// Gets or sets LineOfBusiness
        /// </summary>
        public LobIncludedModel LineOfBusiness { get; set; }

        /// <summary>
        /// Gets or sets PolicyHeader Model 
        /// </summary>
        public PolicyHeaderModel PolicyHeaderModel { get; set; }

        /// <summary>
        /// Gets or sets LineOfBusiness Input Model
        /// </summary>
        public LineOfBusinessInputModel LineOfBusinessInputModel { get; set; }

        /// <summary>
        /// Gets or sets Pricing Input Model
        /// </summary>        
        public PricingInputModel PricingInputModel { get; set; } // these 2 will be the last property.

        /// <summary>
        /// Gets or sets LastTransaction Model
        /// </summary>
        public LastTransactionModel LastTransactionModel { get; set; }
    }
}
