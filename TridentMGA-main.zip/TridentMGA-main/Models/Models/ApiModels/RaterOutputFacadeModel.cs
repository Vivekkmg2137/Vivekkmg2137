﻿using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Output;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models.ApiModels
{
    public class RaterOutputFacadeModel
    {
        public RaterOutputFacadeModel()
        {
        }

        public ResponseInfoModel ResponseModel { get; set; }

        public LineOfBusinessOutputModel LineOfBusinessOutputModel { get; set; }

        // these 2 will be the last property.
        public PricingOutputModel PricingOutputModel { get; set; }
        public PremiumSummaryModel PremiumSummaryModel { get; set; }        
    }
}
