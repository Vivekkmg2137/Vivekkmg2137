﻿using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Property.Output;
using Models.ApiModels.Policy;
using System;
using System.Collections.Generic;
using System.Text;
using Models.ApiModels.LineOfBusiness.Property.Input;
using Models.ApiModels.LineOfBusiness.Ocp.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output;
using Models.ApiModels.Pricing.Output;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Output;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Output;

namespace Models.Initialization
{
    /// <summary>
    /// InitializeFacade
    /// </summary>
    public class InitializeFacade
    {
        /// <summary>
        /// GetRaterFacadeModelFromInput
        /// </summary>
        /// <param name="inputLobModel"></param>
        /// <returns>RaterFacadeModel</returns>
        public RaterFacadeModel GetRaterFacadeModelFromInput(RaterInputFacadeModel inputLobModel)
        {
            RaterFacadeModel raterFacadeModel;

            if (inputLobModel == null)
            {
                throw new ApplicationException("Input Model can not be null");
            }

            if (inputLobModel.LineOfBusiness == null)
            {
                throw new ApplicationException("Input LineOfBusiness Model can not be null");
            }

            if (inputLobModel.PricingInputModel == null)
            {
                throw new ApplicationException("Input Pricing Model can not be null");
            }

            if (inputLobModel.LineOfBusinessInputModel == null)
            {
                throw new ApplicationException("LineOfBusiness Input Model can not be null");
            }
            else
            {
                ValidateSelectedLOBs(inputLobModel);
                raterFacadeModel = InitializeOutputModel(inputLobModel);
            }             

            return raterFacadeModel;
        }

        /// <summary>
        /// ValidateSelectedLOBs
        /// </summary>
        /// <param name="inputLobModel"></param>
        private static void ValidateSelectedLOBs(RaterInputFacadeModel inputLobModel)
        {
            var inputModel = inputLobModel.LineOfBusinessInputModel;

            if (inputLobModel.LineOfBusiness.Property == true && inputModel.Property == null)
            {
                throw new ApplicationException("Input Property Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.Auto == true && inputModel.Auto == null)
            {
                throw new ApplicationException("Input Auto Liability Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.Ocp1 == true && inputModel.Ocp1 == null)
            {
                throw new ApplicationException("Input OCP1 Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.Ocp2 == true && inputModel.Ocp2 == null)
            {
                throw new ApplicationException("Input OCP2 Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.Ocp3 == true && inputModel.Ocp3 == null)
            {
                throw new ApplicationException("Input OCP3 Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.Ocp4 == true && inputModel.Ocp4 == null)
            {
                throw new ApplicationException("Input OCP4 Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.Ocp5 == true && inputModel.Ocp5 == null)
            {
                throw new ApplicationException("Input OCP5 Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.EducatorsLegal == true && inputModel.EducatorsLegal == null)
            {
                throw new ApplicationException("Input Educators Legal Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.EmploymentPractices == true && inputModel.EmploymentPractices == null)
            {
                throw new ApplicationException("Input Employment Practices Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.EmploymentPracticesSchool == true && inputModel.EmploymentPracticesSchool == null)
            {
                throw new ApplicationException("Input Employment Practices School Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.Excess == true && inputModel.Excess == null)
            {
                throw new ApplicationException("Input Excess Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.GeneralLiability == true && inputModel.GeneralLiability == null)
            {
                throw new ApplicationException("Input General Liability Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.InlandMarine == true && inputModel.InlandMarine == null)
            {
                throw new ApplicationException("Input Inland Marine Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.PublicOfficials == true && inputModel.PublicOfficials == null)
            {
                throw new ApplicationException("Input Public Officials Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.LawEnforcement == true && inputModel.LawEnforcement == null)
            {
                throw new ApplicationException("Input Law Enforcement Model can not be null");
            }

            if (inputLobModel.LineOfBusiness.DirectorsAndOfficers == true && inputModel.DirectorsAndOfficers == null)
            {
                throw new ApplicationException("Input Directors And Officers Model can not be null");
            }
        }

        /// <summary>
        /// InitializeOutputModel
        /// </summary>
        /// <param name="inputLobModel"></param>
        /// <returns>RaterFacadeModel</returns>
        private static RaterFacadeModel InitializeOutputModel(RaterInputFacadeModel inputLobModel)
        {
            RaterFacadeModel raterFacadeModel = new RaterFacadeModel();
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel();
            raterFacadeModel.RaterInputFacadeModel = inputLobModel;

            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.PremiumSummaryModel = new PremiumSummaryModel();
            raterFacadeModel.RaterOutputFacadeModel.ResponseModel = new ResponseInfoModel();
            raterFacadeModel.RaterOutputFacadeModel.PricingOutputModel = new PricingOutputModel();

            var selectedLineOfBusiness = raterFacadeModel.RaterInputFacadeModel.LineOfBusiness;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            if (selectedLineOfBusiness.Property)
            {
                InitializePropertyModels(raterFacadeModel);
            }

            if (selectedLineOfBusiness.Ocp1)
            {
                outputModel.Ocp1 = new OcpOutputModel();
            }

            if (selectedLineOfBusiness.Ocp2)
            {
                outputModel.Ocp2 = new OcpOutputModel();
            }

            if (selectedLineOfBusiness.Ocp3)
            {
                outputModel.Ocp3 = new OcpOutputModel();
            }

            if (selectedLineOfBusiness.Ocp4)
            {
                outputModel.Ocp4 = new OcpOutputModel();
            }

            if (selectedLineOfBusiness.Ocp5)
            {
                outputModel.Ocp5 = new OcpOutputModel();
            }

            if (selectedLineOfBusiness.Auto)
            {
                InitializeAutoModels(raterFacadeModel);
            }

            if (selectedLineOfBusiness.EmploymentPractices)
            {
                InitializeEmploymentPracticesModels(raterFacadeModel);
            }

            if (selectedLineOfBusiness.EmploymentPracticesSchool)
            {
                InitializeEmploymentPracticesSchoolModels(raterFacadeModel);
            }

            if (selectedLineOfBusiness.PublicOfficials)
            {
                InitializePublicOfficialsModels(raterFacadeModel);
            }

            if (selectedLineOfBusiness.LawEnforcement)
            {
                InitializeLawEnforcementModels(raterFacadeModel);
            }

            if (selectedLineOfBusiness.DirectorsAndOfficers)
            {
                InitializeDirectorsAndOfficersModels(raterFacadeModel);
            }

            if (selectedLineOfBusiness.EducatorsLegal)
            {
                InitializeEducatorsLegal(raterFacadeModel);
            }

            if (selectedLineOfBusiness.Excess)
            {
                InitializeExcess(raterFacadeModel);
            }

            if (selectedLineOfBusiness.Crime)
            {
                InitializeCrime(raterFacadeModel);
            }

            if (selectedLineOfBusiness.GeneralLiability)
            {
                InitializeGeneralLiability(raterFacadeModel);
            }

            return raterFacadeModel;
        }

        /// <summary>
        /// InitializeCrime
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializeCrime(RaterFacadeModel raterFacadeModel)
        {
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            throw new NotImplementedException();
        }

        /// <summary>
        /// InitializeGeneralLiability
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializeGeneralLiability(RaterFacadeModel raterFacadeModel)
        {
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            outputModel.GeneralLiability = new ApiModels.LineOfBusiness.GeneralLiability.output.GeneralLiabilityOutputModel();

            if (inputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel != null)
            {
                outputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel = new ApiModels.LineOfBusiness.GeneralLiability.output.GeneralLiabilityOptionalCoverageOutputModel();

                if (inputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.GeneralLiabilityOptionalOtherCoverageModel != null)
                {
                    outputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.GeneralLiabilityOptionalOtherCoverageModel = new List<ApiModels.LineOfBusiness.GeneralLiability.output.GeneralLiabilityOptionalOtherCoverageOutputModel>();
                }
            }
        }

        /// <summary>
        /// InitializeExcess
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializeExcess(RaterFacadeModel raterFacadeModel)
        {
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            // throw new NotImplementedException();
        }

        /// <summary>
        /// InitializeEducatorsLegal
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializeEducatorsLegal(RaterFacadeModel raterFacadeModel)
        {
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            outputModel.EducatorsLegal = new EducatorsLegalOutputModel();
            if (raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
            {
                outputModel.EducatorsLegal.NY = new ApiModels.LineOfBusiness.EducatorsLegal.Output.EducatorsLegalNyOutputModel();
                outputModel.EducatorsLegal.CW = null;

                outputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage = new ApiModels.LineOfBusiness.EducatorsLegal.Output.EducatorsLegalNyOptionalCoverageOutputModel();

                if (inputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage != null)
                {
                    outputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage = new List<EducatorsLegalOtherCoverageOutputModel>();
                }
            }
            else
            {
                outputModel.EducatorsLegal.CW = new EducatorsLegalCwOutputModel();
                outputModel.EducatorsLegal.NY = null;

                outputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage = new ApiModels.LineOfBusiness.EducatorsLegal.Output.EducatorsLegalCwOptionalCoverageOutputModel();

                if (inputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage != null)
                {
                    outputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage = new List<EducatorsLegalOtherCoverageOutputModel>();
                }
            }
        }

        /// <summary>
        /// InitializeDirectorsAndOfficersModels
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializeDirectorsAndOfficersModels(RaterFacadeModel raterFacadeModel)
        {
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            outputModel.DirectorsAndOfficers = new ApiModels.LineOfBusiness.DirectorsAndOfficers.Output.DirectorsAndOfficersOutputModel();

            if (inputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel != null)
            {
                outputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel = new ApiModels.LineOfBusiness.DirectorsAndOfficers.Output.DirectorsAndOfficersOptionalCoverageOutputModel();

                if (inputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel != null)
                {
                    outputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel = new List<ApiModels.LineOfBusiness.DirectorsAndOfficers.Output.DirectorsAndOfficersOptionalOtherCoverageOutputModel>();
                }
            }
        }

        /// <summary>
        /// InitializeLawEnforcementModels
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializeLawEnforcementModels(RaterFacadeModel raterFacadeModel)
        {
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            outputModel.LawEnforcement = new ApiModels.LineOfBusiness.LawEnforcement.Output.LawEnforcementOutputModel();

            if (inputModel.LawEnforcement.LawEnforcementOptionalCoverageModel != null)
            {
                outputModel.LawEnforcement.LawEnforcementOptionalCoverageModel = new ApiModels.LineOfBusiness.LawEnforcement.Output.LawEnforcementOptionalCoverageOutputModel();

                if (inputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel != null)
                {
                    outputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel = new List<ApiModels.LineOfBusiness.LawEnforcement.Output.LawEnforcementOptionalOtherCoverageOutputModel>();
                }
            }
        }

        /// <summary>
        /// InitializePublicOfficialsModels
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializePublicOfficialsModels(RaterFacadeModel raterFacadeModel)
        {
            var policyHeaderModel = raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            outputModel.PublicOfficials = new ApiModels.LineOfBusiness.PublicOfficials.PublicOfficialsOutputModel();
            if (policyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
            {
                outputModel.PublicOfficials.NY = new ApiModels.LineOfBusiness.PublicOfficials.Output.PublicOfficialsNYOutputModel();
                outputModel.PublicOfficials.CW = null;

                outputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel = new PublicOfficialsNYOptionalCoverageOutputModel();

                if (inputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null)
                {
                    outputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel = new List<PublicOfficialsNYOtherCoverageOutputModel>();
                }
            }
            else
            {
                outputModel.PublicOfficials.CW = new ApiModels.LineOfBusiness.PublicOfficials.Output.PublicOfficialsCWOutputModel();
                outputModel.PublicOfficials.NY = null;

                outputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel = new PublicOfficialsCWOptionalCoverageOutputModel();

                if (inputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null)
                {
                    outputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel = new List<PublicOfficialsCWOtherCoverageOutputModel>();
                }
            }
        }

        /// <summary>
        /// InitializeEmploymentPracticesSchoolModels
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializeEmploymentPracticesSchoolModels(RaterFacadeModel raterFacadeModel)
        {
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            outputModel.EmploymentPracticesSchool = new ApiModels.LineOfBusiness.EmploymentPracticesSchool.Output.EmploymentPracticesSchoolOutputModel();
            if (inputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel != null)
            {
                outputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel = new ApiModels.LineOfBusiness.EmploymentPracticesSchool.Output.EmploymentPracticesSchoolOptionalCoverageOutputModel();
                if (inputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel.EmploymentPracticesSchoolOtherCoverageModel != null && inputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel.EmploymentPracticesSchoolOtherCoverageModel.Count > 0)
                {
                    outputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel.EmploymentPracticesSchoolOtherCoverageModel = new List<ApiModels.LineOfBusiness.EmploymentPracticesSchool.Output.EmploymentPracticesSchoolOtherCoverageOutputModel>();
                }
            }
        }

        /// <summary>
        /// InitializeEmploymentPracticesModels
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializeEmploymentPracticesModels(RaterFacadeModel raterFacadeModel)
        {
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            outputModel.EmploymentPractices = new ApiModels.LineOfBusiness.EmploymentPractices.Output.EmploymentPracticesOutputModel();

            if (inputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel != null)
            {
                outputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = new ApiModels.LineOfBusiness.EmploymentPractices.Output.EmploymentPracticesOptionalCoverageOutputModel();

                if (inputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel != null && inputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel.Count > 0)
                {
                    outputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel = new List<ApiModels.LineOfBusiness.EmploymentPracticesOutput.EmploymentPracticesOtherCoverageOutputModel>();
                }
            }
        }

        /// <summary>
        /// InitializeAutoModels
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializeAutoModels(RaterFacadeModel raterFacadeModel)
        {
            var policyHeaderModel = raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            if (policyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
            {
                if (inputModel.Auto.NY == null)
                {
                    throw new ApplicationException("Input Auto Liability NY input Model can not be null");
                }
                else
                {
                    if (inputModel.Auto.NY.AutoLiabilityInputModel == null)
                    {
                        throw new ApplicationException("Input Auto liability input model can not be null");
                    }
                    else if (inputModel.Auto.NY.HasAutoPhysicalDamage == true && inputModel.Auto.NY.AutoPhysicalDamageInputModel == null)
                    {
                        throw new ApplicationException("Input Auto Physical Damage Model can not be null");
                    }
                }
            }
            else
            {
                if (inputModel.Auto.CW == null)
                {
                    throw new ApplicationException("Input Auto Liability CW input Model can not be null");
                }
                else
                {
                    if (inputModel.Auto.CW.AutoLiabilityInputModel == null)
                    {
                        throw new ApplicationException("Input Auto liability input model can not be null");
                    }
                    else if (inputModel.Auto.CW.HasAutoPhysicalDamage == true && inputModel.Auto.CW.AutoPhysicalDamageInputModel == null)
                    {
                        throw new ApplicationException("Input Auto Physical Damage Model can not be null");
                    }
                }
            }

            outputModel.Auto = new ApiModels.LineOfBusiness.Auto.AutoOutputModel();
            if (policyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
            {
                outputModel.Auto.NY = new ApiModels.LineOfBusiness.Auto.OutputModel();
                outputModel.Auto.CW = null;

                outputModel.Auto.NY.AutoLiabilityOutputModel = new AutoLiabilityOutputModel();

                if (inputModel.Auto.NY.HasAutoPhysicalDamage)
                {
                    outputModel.Auto.NY.AutoPhysicalDamageOutputModel = new AutoPhysicalDamageOutputModel();
                }

                if (inputModel.Auto.NY.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel != null)
                {
                    outputModel.Auto.NY.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel = new AutoLiabilityOptionalCoverageOutputModel();
                    outputModel.Auto.NY.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AutoLiabilityOptionalOtherCoverageOutputModels = new List<AutoLiabilityOptionalOtherCoverageOutputModel>();
                }
            }
            else
            {
                outputModel.Auto.CW = new ApiModels.LineOfBusiness.Auto.OutputModel();
                outputModel.Auto.NY = null;
                outputModel.Auto.CW.AutoLiabilityOutputModel = new AutoLiabilityOutputModel();

                if (inputModel.Auto.CW.HasAutoPhysicalDamage)
                {
                    outputModel.Auto.CW.AutoPhysicalDamageOutputModel = new AutoPhysicalDamageOutputModel();
                    outputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel = new AutoPhysicalDamageOptionalCoverageOutputModel();
                    outputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.AutoPhysicalDamageOptionalOtherCoverageOutputModels = new List<AutoPhysicalDamageOptionalOtherCoverageOutputModel>();
                }
                if (inputModel.Auto.CW.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel != null)
                {
                    outputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel = new AutoLiabilityOptionalCoverageOutputModel();
                    outputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AutoLiabilityOptionalOtherCoverageOutputModels = new List<AutoLiabilityOptionalOtherCoverageOutputModel>();
                }
            }
        }

        /// <summary>
        /// InitializePropertyModels
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        private static void InitializePropertyModels(RaterFacadeModel raterFacadeModel)
        {
            var policyHeaderModel = raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel;
            var outputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel;

            if (policyHeaderModel.State.ToUpper() == StateCodeConstant.NY && inputModel.Property.PropertyStateSpecificInputModel == null)
            {
                throw new ApplicationException("Property State Specific Input Model can not be null");
            }

            outputModel.Property = new PropertyOutputModel();

            if (policyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
            {
                outputModel.Property.PropertyStateSpecificOutputModel = new PropertyStateSpecificOutputModel();

                if (inputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel != null)
                {
                    outputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel = new PropertyNewYork360OutputModel();
                }
                else
                {
                    outputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel = null;
                }
            }
            else
            {
                if (inputModel.Property.Property360InputModel != null)
                {
                    outputModel.Property.Property360OutputModel = new Property360OutputModel();
                }
                else
                {
                    outputModel.Property.Property360OutputModel = null;
                }
            }
        }
    }
}
