﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class Person
    {
        public int Id { get; set; }

        public string Name { get; set; }
        public string Surname { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public string Document { get; set; }
        public string Married { get; set; }
        public string Code { get; set; }

        public string Reason { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }
        public DateTime BirthDate { get; set; }

        public string Profession { get; set; }
        public bool IsProfessionFake { get; set; }
    }
}
