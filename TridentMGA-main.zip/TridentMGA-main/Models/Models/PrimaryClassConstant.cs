﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class PrimaryClassConstant
    {
        /// <summary>
        /// County
        /// </summary>
        public static string CO { get; private set; } = "CO";

        /// <summary>
        /// Electric / Gas Utility
        /// </summary>
        public static string EGU { get; private set; } = "EGU";

        /// <summary>
        /// Fire Department
        /// </summary>
        public static string FD { get; private set; } = "FD";

        /// <summary>
        /// Muni / School Combined
        /// </summary>
        public static string MSC { get; private set; } = "MSC";

        /// <summary>
        /// Municipality
        /// </summary>
        public static string MU { get; private set; } = "MU";

        /// <summary>
        /// Private / Non-Profit
        /// </summary>
        public static string PNP { get; private set; } = "PNP";

        /// <summary>
        /// School
        /// </summary>
        public static string SC { get; private set; } = "SC";

        /// <summary>
        /// Special District
        /// </summary>
        public static string SP { get; private set; } = "SP";

        /// <summary>
        /// Water / Sewer Utility
        /// </summary>
        public static string WSU { get; private set; } = "WSU";
    }
}
