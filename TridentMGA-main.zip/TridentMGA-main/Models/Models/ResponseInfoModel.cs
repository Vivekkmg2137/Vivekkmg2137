﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    /// <summary>
    /// ResponseInfo Model
    /// </summary>
    public class ResponseInfoModel
    {
        /// <summary>
        /// ResponseInfoModel
        /// </summary>
        public ResponseInfoModel()
        {
            Messages = new List<string>();
            SystemLog = new List<string>();
        }

        /// <summary>
        /// Gets or sets Successful
        /// </summary>
        public bool Successful { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets Messages
        /// </summary>
        public List<string> Messages { get; set; }

        /// <summary>
        /// Gets or sets EntityId
        /// </summary>
        public int EntityId { get; set; }

        /// <summary>
        /// Gets or sets Entity
        /// </summary>
        public object Entity { get; set; }

        /// <summary>
        /// Gets or sets JsonData
        /// </summary>
        public string JsonData { get; set; }

        /// <summary>
        /// Gets or sets SystemLog
        /// </summary>
        public List<string> SystemLog { get; set; }
    }
}
