﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class StateCodeConstant
    {
        #region StateCode
        public static string CW { get; private set; } = "CW";
        public static string NY { get; private set; } = "NY";
        public static string MN { get; private set; } = "MN";
        public static string MO { get; private set; } = "MO";
        public static string KS { get; private set; } = "KS";
        public static string AL { get; private set; } = "AL";
        public static string CO { get; private set; } = "CO";
        public static string CT { get; private set; } = "CT";
        public static string DE { get; private set; } = "DE";
        public static string GA { get; private set; } = "GA";
        public static string IL { get; private set; } = "IL";
        public static string IN { get; private set; } = "IN";
        public static string MA { get; private set; } = "MA";
        public static string ME { get; private set; } = "ME";
        public static string MI { get; private set; } = "MI";
        public static string MS { get; private set; } = "MS";
        public static string NC { get; private set; } = "NC";
        public static string NH { get; private set; } = "NH";
        public static string OH { get; private set; } = "OH";
        public static string PA { get; private set; } = "PA";
        public static string SC { get; private set; } = "SC";
        public static string TX { get; private set; } = "TX";
        public static string UT { get; private set; } = "UT";
        public static string VT { get; private set; } = "VT";
        public static string WY { get; private set; } = "WY";
        #endregion       
    }
}
