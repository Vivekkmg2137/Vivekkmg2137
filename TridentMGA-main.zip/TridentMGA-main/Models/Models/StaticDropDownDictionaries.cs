﻿// <copyright file="StaticDropDownDictionaries.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// StaticDropDownDictionaries
    /// </summary>
    public static class StaticDropDownDictionaries
    {
        /// <summary>
        /// GenderDictionary
        /// </summary>
        /// <returns>GenderDictionary list</returns>
        public static Dictionary<string, string> GenderDictionary()
        {
            var genderDictionary = new Dictionary<string, string>
            {
                { "Female", "Female" },
                 { "Male", "Male" },
                {"Unknown", "Unknown" }
            };

            return genderDictionary;
        }

        /// <summary>
        /// NPITypesDictionary
        /// </summary>
        /// <returns>NpiTypesDictionary list</returns>
        public static Dictionary<string, string> NPITypesDictionary()
        {
            var npiTypesDictionary = new Dictionary<string, string>
            {
                { "Actual", "Actual" },
                { "Dummy", "Dummy" }
            };

            return npiTypesDictionary;
        }

        /// <summary>
        /// CitizenShipDictionary
        /// </summary>
        /// <returns>CitizenShipDictionary list</returns>
        public static Dictionary<string, string> CitizenShipDictionary()
        {
            var citizenShipDictionary = new Dictionary<string, string>
            {
                { "Yes", "Yes" },
                { "No", "No" }
            };

            return citizenShipDictionary;
        }

        /// <summary>
        /// MarriedDictionary
        /// </summary>
        /// <returns>MarriedDictionary list</returns>
        public static Dictionary<string, string> MarriedDictionary()
        {
            var marriedDictionary = new Dictionary<string, string>
            {
                //{ "Yes", "Yes" },
                { "No", "No" },
                { "Yes", "Yes" }
            };

            return marriedDictionary;
        }

        /// <summary>
        /// PageSizeDictionary
        /// </summary>
        /// <returns>PageSizeDictionary list</returns>
        public static Dictionary<string, string> PageSizeDictionary()
        {
            var pageSizeDictionary = new Dictionary<string, string>
            {
                { "100", "100" },
                { "50", "50" },
                { "25", "25" },
                { "20", "20" },
            };

            return pageSizeDictionary;
        }

        /// <summary>
        /// CommanYesNoDictionary
        /// </summary>
        /// <returns>CommanYesNoDictionary list</returns>
        public static Dictionary<string, string> CommanYesNoDictionary()
        {
            var commanYesNoDictionary = new Dictionary<string, string>
            {
                { "No", "No" },
                { "Yes", "Yes" }
            };

            return commanYesNoDictionary;
        }

        /// <summary>
        /// DocumentExtension
        /// </summary>
        /// <returns>DocumentExtension list</returns>
        public static Dictionary<string, string> DocumentExtension()
        {
            var documentExtension = new Dictionary<string, string>
            {
                { ".pdf", "application/pdf" },
                { ".png", "image/png" },
                { ".jpeg", "image/jpeg" },
                { ".jpg", "image/jpeg" },
                { ".tif", "image/tiff" }
            };
            return documentExtension;
        }

        /// <summary>
        /// DocumentExtension
        /// </summary>
        /// <returns>DocumentExtension list</returns>
        public static Dictionary<string, string> DocumentExtensions()
        {
            var documentExtension = new Dictionary<string, string>
            {
                { ".PDF", "application/pdf" },
                { ".PNG", "image/png" },
                { ".JPEG", "image/jpeg" },
                { ".JPG", "image/jpeg" },
                { ".TIF", "image/tiff" }
            };
            return documentExtension;
        }

        /// <summary>
        /// ImageExtension
        /// </summary>
        /// <returns>DocumentExtension list</returns>
        public static Dictionary<string, string> ImageExtension()
        {
            var documentExtension = new Dictionary<string, string>
            {
                { ".png", "image/png" },
                { ".jpeg", "image/jpeg" },
                { ".jpg", "image/jpeg" },
                { ".tif", "image/tiff" }
            };
            return documentExtension;
        }

        /// <summary>
        /// PdfExtension
        /// </summary>
        /// <returns>PdfExtension list</returns>
        public static Dictionary<string, string> PdfExtension()
        {
            var documentExtension = new Dictionary<string, string>
            {
                { ".PDF", "application/pdf" }
            };
            return documentExtension;
        }


        /// <summary>
        /// FrequencyRange
        /// </summary>
        /// <returns>Frequency list</returns>
        public static Dictionary<string, string> FrequencyRange()
        {
            var frequency = new Dictionary<string, string>
            {
                { "10 Days", "10 Days" },
                { "15 Days", "15 Days" },
                { "20 Days", "20 Days" },
                { "25 Days", "25 Days" },
                { "30 Days", "30 Days" }
            };
            return frequency;
        }
        /// <summary>
        /// PursuingDictionary
        /// </summary>
        /// <returns>PursuingDictionary list</returns>
        public static Dictionary<bool, string> PursuingDictionary()
        {
            var pursuingDictionary = new Dictionary<bool, string>
            {
                { false, "No" },
                { true, "Yes" }
            };

            return pursuingDictionary;
        }


        /// <summary>
        /// Rank
        /// </summary>
        /// <returns>List</returns>
        public static Dictionary<string, string> Rank()
        {
            var rank = new Dictionary<string, string>
            {
                { "1", "1" },
                { "2", "2" },
                { "3", "3" },
                { "4", "4" },
                { "5", "5" }
            };
            return rank;
        }


        /// <summary>
        /// Master Approval Status Dictionary
        /// </summary>
        /// <returns>Dictionary</returns>
        public static Dictionary<string, string> ApprvalStatusDict()
        {
            var mstStatus = new Dictionary<string, string>
            {
                { "Approved", "Approved" },
                { "Rejected", "Rejected" },
                { "UnApproved", "UnApproved"}
            };

            return mstStatus;
        }

    }
}