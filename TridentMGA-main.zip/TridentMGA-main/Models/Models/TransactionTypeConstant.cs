﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class TransactionTypeConstant
    {
        public static string NEWBUSINESS { get; private set; } = "NEWBUSINESS";
        public static string RENEWAL { get; private set; } = "RENEWAL";
        public static string ENDORSEMENT { get; private set; } = "ENDORSEMENT";
        public static string CANCELLATION { get; private set; } = "CANCELLATION";
    }
}
