﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Output;
using System;
using System.Collections.Generic;
using Validations;

namespace RaterAutoLiability
{
    public class AutoALCwService : IAutoALService
    {
        private AutoDataAccess autoDataAccess { get; set; }
        readonly ILoggingManager logger;
        readonly IConfiguration configuration;

        public AutoALCwService(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.autoDataAccess = new AutoDataAccess(this.configuration, this.logger);
        }

        public DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        public FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new AutoALCWPreValidator(this.configuration, this.logger);
                var results = validator.Validate(model);

                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);

                throw;
            }
        }

        public FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new AutoALCWPostValidator(this.configuration, this.logger);
                var results = validator.Validate(model);
                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);
                throw;
            }
        }

        #region Auto AL

        public void Calculate(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.Calculate :: Started");

                #region Liablity Premium 

                CalculateLiablityPremium(model);

                #endregion

                #region PIP Premium

                CalculatePIPPremium(model);

                #endregion

                #region Basic FPBPremium

                CalculateBasicFPBPremium(model);

                #endregion

                #region MED Premium

                CalculateMEDPremium(model);

                #endregion

                #region UM Premium

                CalculateUMPremium(model);

                #endregion

                #region UM BI/PD Premium

                CalculateUMBIPDPremium(model);

                #endregion

                #region UIM Premium

                CalculateUIMPremium(model);

                #endregion

                #region Hired and NonOwned Premium

                CalculateHiredAndNonOwenedPremium(model);


                #endregion

                #region OptionalCoveragePremium & OtherCoveragePremium

                CalculateOptionalCoveragePremium(model);

                #endregion

                #region Calculate Base Premium

                CalculateBasePremium(model);

                #endregion

                #region Calculate Manual Premium

                CalculateManualPremium(model);

                #endregion

                #region Calculate Tier Premium

                CalculateTierPremium(model);

                #endregion

                #region Calculate IRPM Premium

                CalculateIRPMPremium(model);

                #endregion

                #region Calculate Other Mod Premium

                CalculateOtherModPremium(model);

                #endregion

                #region Calculate Terrorism Premium

                CalculateTerrorismPremium(model);


                #endregion

                #region MI MCCA Assessment Charge

                CalculateMIMCCAAssessementCharge(model);

                #endregion

                #region NC Auto Loss Recoupment Surcharge Charge

                CalculateNCAutoLossRecoupmentSurcharge(model);

                #endregion

                #region Calculate  Final Premium (non MI & NC)

                CalculateFinalPremiumForNonMIAndNC(model);

                #endregion

                #region Calculate  Final Premium (MI)

                CalculateFinalPremiumForMI(model);

                #endregion

                #region Calculate  Final Premium (NC)

                CalculateFinalPremiumForNC(model);

                #endregion

                #region Calculate  Liability Modified Premium

                CalculateLiabilityModifiedPremium(model);

                #endregion

                #region Calculate  Med Pay Modified Premium

                CalculateMedPeyModifiedPremium(model);

                #endregion

                #region Calculate UM And BIPD Modified Premium

                CalculateUMAndBIPDModifiedPremium(model);

                #endregion

                #region Calculate  UIM Modified Premium

                CalculateUIMModifiedPremium(model);

                #endregion

                #region Calculate PIP And Basic FPB Modified Premium

                CalculatePIPAndBasicFPBModifiedPremium(model);

                #endregion

                #region Calculate Hired & NonOwned Modified Premium

                CalculateHiredANDNonOwnedModifiedPremium(model);

                #endregion

                this.logger.Info("AutoALCwService.Calculate :: Completed");

            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateLiablityPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateLiablityPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
                var policyHeadeModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                policyHeadeModel.State = policyHeadeModel.State.ToUpper();
                policyHeadeModel.PrimaryClass = policyHeadeModel.PrimaryClass.ToUpper();
                policyHeadeModel.TransactionType = policyHeadeModel.TransactionType.ToUpper();

                //step 1 STATECODE Pre-Populated from IMS
                //step 2 PrimaryClass User Entry
                //step 3 PopulationADA User Entry
                //step 4 Commission Removed by BA

                if (inputProperty.AutoScheduleVehiclesDetailsInputModel != null && inputProperty.AutoScheduleVehiclesDetailsInputModel.Count > 0)
                {
                    //step 5 inputProperty.NonEmergencyUnitscount
                    outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.RatingGroup.ToUpper() == "NON EMERGENCY").Count;

                    //step 6 inputProperty.EmergencyUnitscount
                    outputProperty.AutoLiabilityOutputModel.EmergencyUnitsCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.RatingGroup.ToUpper() == "EMERGENCY").Count;

                    //step 7 inputProperty.BusesCount
                    outputProperty.AutoLiabilityOutputModel.BusesCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.RatingGroup.ToUpper() == "BUSES").Count;

                    //step 8 inputProperty.TrailersCount
                    outputProperty.AutoLiabilityOutputModel.TrailersCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.RatingGroup.ToUpper() == "TRAILERS").Count;

                    foreach (var scheduleInput in inputProperty.AutoScheduleVehiclesDetailsInputModel)
                    {
                        //step 9 inputProperty.NonEmergencyPIP Units
                        if (scheduleInput.RatingGroup.ToUpper() == "NON EMERGENCY" && ((!string.IsNullOrEmpty(inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit) && inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit.ToUpper() != "EXCLUDED")
                                                                                     || (!string.IsNullOrEmpty(inputProperty.AutoLiabilityInputModel.BasicFPBLimit) && inputProperty.AutoLiabilityInputModel.BasicFPBLimit.ToUpper() != "EXCLUDED")))
                        {
                            outputProperty.AutoLiabilityOutputModel.NonEmergencyPIPUnitsCount = outputProperty.AutoLiabilityOutputModel.NonEmergencyPIPUnitsCount + 1;
                        }
                        //step 10 inputProperty.EmergencyPIPUnits
                        else if (scheduleInput.RatingGroup.ToUpper() == "EMERGENCY" && ((!string.IsNullOrEmpty(inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit) && inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit.ToUpper() != "EXCLUDED")
                                                                                     || (!string.IsNullOrEmpty(inputProperty.AutoLiabilityInputModel.BasicFPBLimit) && inputProperty.AutoLiabilityInputModel.BasicFPBLimit.ToUpper() != "EXCLUDED")))
                        {
                            outputProperty.AutoLiabilityOutputModel.EmergencyPIPUnitsCount = outputProperty.AutoLiabilityOutputModel.EmergencyPIPUnitsCount + 1;
                        }
                        //step 11 inputProperty.BusesPIPUnits
                        else if (scheduleInput.RatingGroup.ToUpper() == "BUSES" && ((!string.IsNullOrEmpty(inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit) && inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit.ToUpper() != "EXCLUDED")
                                                                                     || (!string.IsNullOrEmpty(inputProperty.AutoLiabilityInputModel.BasicFPBLimit) && inputProperty.AutoLiabilityInputModel.BasicFPBLimit.ToUpper() != "EXCLUDED")))
                        {
                            outputProperty.AutoLiabilityOutputModel.BusesPIPUnitsCount = outputProperty.AutoLiabilityOutputModel.BusesPIPUnitsCount + 1;
                        }
                        //step 12 inputProperty.NonEmergencyMedPayUnit
                        if (scheduleInput.RatingGroup.ToUpper() == "NON EMERGENCY" && (!string.IsNullOrEmpty(inputProperty.AutoLiabilityInputModel.MedicalPaymentsLimit) && inputProperty.AutoLiabilityInputModel.MedicalPaymentsLimit.ToUpper() != "NO COVERAGE"))
                        {
                            outputProperty.AutoLiabilityOutputModel.NonEmergencyMedPayUnitsCount = outputProperty.AutoLiabilityOutputModel.NonEmergencyMedPayUnitsCount + 1;
                        }
                        //step 13 inputProperty.EmergencyMedPayUnits
                        else if (scheduleInput.RatingGroup.ToUpper() == "EMERGENCY" && (!string.IsNullOrEmpty(inputProperty.AutoLiabilityInputModel.MedicalPaymentsLimit) && inputProperty.AutoLiabilityInputModel.MedicalPaymentsLimit.ToUpper() != "NO COVERAGE"))
                        {
                            outputProperty.AutoLiabilityOutputModel.EmergencyMedPayUnitsCount = outputProperty.AutoLiabilityOutputModel.EmergencyMedPayUnitsCount + 1;
                        }
                        //step 14 inputProperty.BusesMedPayUnits
                        else if (scheduleInput.RatingGroup.ToUpper() == "BUSES" && (!string.IsNullOrEmpty(inputProperty.AutoLiabilityInputModel.MedicalPaymentsLimit) && inputProperty.AutoLiabilityInputModel.MedicalPaymentsLimit.ToUpper() != "NO COVERAGE"))
                        {
                            outputProperty.AutoLiabilityOutputModel.BusesMedPayUnitsCount = outputProperty.AutoLiabilityOutputModel.BusesMedPayUnitsCount + 1;
                        }

                    }

                }
                else
                {
                    outputProperty.AutoLiabilityOutputModel.NonEmergencyPIPUnitsCount = inputProperty.AutoLiabilityInputModel.NonEmergencyPIPUnitsCount;
                    outputProperty.AutoLiabilityOutputModel.EmergencyPIPUnitsCount = inputProperty.AutoLiabilityInputModel.EmergencyPIPUnitsCount;
                    outputProperty.AutoLiabilityOutputModel.BusesPIPUnitsCount = inputProperty.AutoLiabilityInputModel.BusesPIPUnitsCount;

                    outputProperty.AutoLiabilityOutputModel.NonEmergencyMedPayUnitsCount = inputProperty.AutoLiabilityInputModel.NonEmergencyMedPayUnitsCount;
                    outputProperty.AutoLiabilityOutputModel.EmergencyMedPayUnitsCount = inputProperty.AutoLiabilityInputModel.EmergencyMedPayUnitsCount;
                    outputProperty.AutoLiabilityOutputModel.BusesMedPayUnitsCount = inputProperty.AutoLiabilityInputModel.BusesMedPayUnitsCount;

                    outputProperty.AutoLiabilityOutputModel.EmergencyUnitsCount = inputProperty.AutoLiabilityInputModel.EmergencyUnitsCount;
                    outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsCount = inputProperty.AutoLiabilityInputModel.NonEmergencyUnitsCount;
                    outputProperty.AutoLiabilityOutputModel.BusesCount = inputProperty.AutoLiabilityInputModel.BusesCount;
                    outputProperty.AutoLiabilityOutputModel.TrailersCount = inputProperty.AutoLiabilityInputModel.TrailersCount;
                }

                // step 15 TotalPIPUnitswithoutTrailersCount =  Sum(Non Energency PIP Units + Emergency PIP Units +  Buses PIP Units)
                outputProperty.AutoLiabilityOutputModel.TotalPIPUnitswithoutTrailersCount = outputProperty.AutoLiabilityOutputModel.NonEmergencyPIPUnitsCount
                                                                                          + outputProperty.AutoLiabilityOutputModel.EmergencyPIPUnitsCount
                                                                                          + outputProperty.AutoLiabilityOutputModel.BusesPIPUnitsCount;

                // step 16 Total Med Pay Units = Sum(Non Energency Med Pay Units + Emergency Med Pay Units +  Buses Med Pay Units)
                outputProperty.AutoLiabilityOutputModel.TotalMedPayUnitswithoutTrailersCount = outputProperty.AutoLiabilityOutputModel.NonEmergencyMedPayUnitsCount
                                                                                             + outputProperty.AutoLiabilityOutputModel.EmergencyMedPayUnitsCount
                                                                                             + outputProperty.AutoLiabilityOutputModel.BusesMedPayUnitsCount;

                //step 17 TotalVehiclesCount = Non Emergency Units +  Emergency Units +  Buses + Trailers
                outputProperty.AutoLiabilityOutputModel.TotalVehiclesCount = outputProperty.AutoLiabilityOutputModel.EmergencyUnitsCount
                                                                           + outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsCount
                                                                           + outputProperty.AutoLiabilityOutputModel.BusesCount
                                                                           + outputProperty.AutoLiabilityOutputModel.TrailersCount;


                // step 18 TotalVehicleswithoutTrailersCount = TotalVehicleCount - Trailers 
                outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount = outputProperty.AutoLiabilityOutputModel.TotalVehiclesCount
                                                                                            - outputProperty.AutoLiabilityOutputModel.TrailersCount;

                // to get MinimumPremium
                outputProperty.AutoLiabilityOutputModel.MinimumPremium = Convert.ToInt32(autoDataAccess.GetMinimumPremium(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate));

                // Step 21 Calculate Liability Premium
                // Step 21.1 Liability Limit
                // Step 21.2 Retention

                // Step 21.3 NonEmergencyUnitsBaseRate 
                // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                // outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsBaseRate = autoDataAccess.GetBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Non Emergency", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                if (inputProperty.AutoLiabilityInputModel.NonEmergencyUnitsBaseRate < 0)
                {
                    outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsBaseRate = autoDataAccess.GetBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Non Emergency", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }
                else
                {
                    outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsBaseRate = inputProperty.AutoLiabilityInputModel.NonEmergencyUnitsBaseRate;
                }

                // Step 21.5 EmergencyUnitsBaseRate
                // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                //outputProperty.AutoLiabilityOutputModel.EmergencyUnitsBaseRate = autoDataAccess.GetBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Emergency", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                if (inputProperty.AutoLiabilityInputModel.EmergencyUnitsBaseRate < 0)
                {
                    outputProperty.AutoLiabilityOutputModel.EmergencyUnitsBaseRate = autoDataAccess.GetBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Emergency", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }
                else
                {
                    outputProperty.AutoLiabilityOutputModel.EmergencyUnitsBaseRate = inputProperty.AutoLiabilityInputModel.EmergencyUnitsBaseRate;
                }

                // Step 21.7 BusesBaseRate
                // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                // outputProperty.AutoLiabilityOutputModel.BusesBaseRate = autoDataAccess.GetBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Buses", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                if (inputProperty.AutoLiabilityInputModel.BusesBaseRate < 0)
                {
                    outputProperty.AutoLiabilityOutputModel.BusesBaseRate = autoDataAccess.GetBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Buses", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }
                else
                {
                    outputProperty.AutoLiabilityOutputModel.BusesBaseRate = inputProperty.AutoLiabilityInputModel.BusesBaseRate;
                }


                // Step 21.9 LiabilityLimitRate
                // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                //outputProperty.AutoLiabilityOutputModel.LiabilityLimitRate = autoDataAccess.GetLimitFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, inputProperty.AutoLiabilityInputModel.LimitType, inputProperty.AutoLiabilityInputModel.LiabilityLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                if (inputProperty.AutoLiabilityInputModel.LiabilityLimitRate < 0)
                {
                    outputProperty.AutoLiabilityOutputModel.LiabilityLimitRate = autoDataAccess.GetLimitFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, inputProperty.AutoLiabilityInputModel.LimitType, inputProperty.AutoLiabilityInputModel.LiabilityLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }
                else
                {
                    outputProperty.AutoLiabilityOutputModel.LiabilityLimitRate = inputProperty.AutoLiabilityInputModel.LiabilityLimitRate;
                }


                // Step 21.11 DeductibleSIRFactor
                outputProperty.AutoLiabilityOutputModel.Deductible_SIRFactor = autoDataAccess.GetDeductibleFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, inputProperty.AutoLiabilityInputModel.Deductible_SIR, inputProperty.AutoLiabilityInputModel.Retention, null, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);


                // Calculate LiabilityUnModifiedPremium = ROUND(((BaseRate * Non Emergency Units) +(BaseRate * Emergency Units)	+ (BaseRate * Buses))	* LimitsFactor	* DeductibleSIR)	

                outputProperty.AutoLiabilityOutputModel.LiabilityUnModifiedPremium = (((outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsBaseRate
                                                                                     * outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsCount)
                                                                                     + (outputProperty.AutoLiabilityOutputModel.EmergencyUnitsBaseRate
                                                                                     * outputProperty.AutoLiabilityOutputModel.EmergencyUnitsCount)
                                                                                     + (outputProperty.AutoLiabilityOutputModel.BusesBaseRate
                                                                                     * outputProperty.AutoLiabilityOutputModel.BusesCount))
                                                                                     * outputProperty.AutoLiabilityOutputModel.LiabilityLimitRate
                                                                                     * outputProperty.AutoLiabilityOutputModel.Deductible_SIRFactor);

                // Rounding
                outputProperty.AutoLiabilityOutputModel.LiabilityUnModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.LiabilityUnModifiedPremium, 2, MidpointRounding.AwayFromZero);


                this.logger.Info("AutoALCwService.CalculateLiablityPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoService.CalculateLiablityPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculatePIPPremium(RaterFacadeModel model)
        {
            try
            {
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() != StateCodeConstant.PA)
                {
                    this.logger.Info("AutoALCwService.CalculatePIPPremium :: Started");

                    var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                    var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
                    //step 22

                    // Step 22.5 PersonalInjuryProtectionRate
                    outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionNonEmergencyRate = autoDataAccess.GetPIPRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Personal Injury Protection", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Non Emergency", null, inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 22.7
                    outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionEmergencyRate = autoDataAccess.GetPIPRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Personal Injury Protection", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Emergency", null, inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 22.9
                    outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionBusesRate = autoDataAccess.GetPIPRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Personal Injury Protection", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Buses", null, inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 22.10 ExcessAttendantCareRate
                    outputProperty.AutoLiabilityOutputModel.ExcessAttendantCareNonEmergencyRate = autoDataAccess.GetPIPRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Excess Attendant Care", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Non Emergency", inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit, inputProperty.AutoLiabilityInputModel.ExcessAttendantCareLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 22.10 
                    outputProperty.AutoLiabilityOutputModel.ExcessAttendantCareEmergencyRate = autoDataAccess.GetPIPRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Excess Attendant Care", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Emergency", inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit, inputProperty.AutoLiabilityInputModel.ExcessAttendantCareLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 22.10 
                    outputProperty.AutoLiabilityOutputModel.ExcessAttendantCareBusesRate = autoDataAccess.GetPIPRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Excess Attendant Care", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Buses", inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit, inputProperty.AutoLiabilityInputModel.ExcessAttendantCareLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Calculate PersonalInjuryProtectionUnModifiedPremium (PIP Premium)

                    if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.MI)
                    {
                        outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium = (((outputProperty.AutoLiabilityOutputModel.NonEmergencyPIPUnitsCount
                                                                                                       * outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionNonEmergencyRate)
                                                                                                       + (outputProperty.AutoLiabilityOutputModel.EmergencyPIPUnitsCount
                                                                                                       * outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionEmergencyRate)
                                                                                                       + (outputProperty.AutoLiabilityOutputModel.BusesPIPUnitsCount
                                                                                                       * outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionBusesRate))
                                                                                                       * outputProperty.AutoLiabilityOutputModel.ExcessAttendantCareNonEmergencyRate
                                                                                                       * outputProperty.AutoLiabilityOutputModel.ExcessAttendantCareEmergencyRate
                                                                                                       * outputProperty.AutoLiabilityOutputModel.ExcessAttendantCareBusesRate);
                    }
                    else
                    {
                        outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium = (outputProperty.AutoLiabilityOutputModel.NonEmergencyPIPUnitsCount
                                                                                                       * outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionNonEmergencyRate)
                                                                                                       + (outputProperty.AutoLiabilityOutputModel.EmergencyPIPUnitsCount
                                                                                                       * outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionEmergencyRate)
                                                                                                       + (outputProperty.AutoLiabilityOutputModel.BusesPIPUnitsCount
                                                                                                       * outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionBusesRate);

                    }

                    // Rounding
                    outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 2, MidpointRounding.AwayFromZero);

                    this.logger.Info("AutoALCwService.CalculatePIPPremium :: Completed");
                }
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculatePIPPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateBasicFPBPremium(RaterFacadeModel model)
        {
            try
            {
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.PA)
                {
                    this.logger.Info("AutoALCwService.CalculateBasicFPBPremium :: Started");

                    var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                    var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                    // Step 23.4 
                    outputProperty.AutoLiabilityOutputModel.BasicFPBNonEmergencyRate = autoDataAccess.GetPIPRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Basic FPB", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Non Emergency", null, inputProperty.AutoLiabilityInputModel.BasicFPBLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 23.6
                    outputProperty.AutoLiabilityOutputModel.BasicFPBEmergencyRate = autoDataAccess.GetPIPRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Basic FPB", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Emergency", null, inputProperty.AutoLiabilityInputModel.BasicFPBLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 22.8 
                    outputProperty.AutoLiabilityOutputModel.BasicFPBBusesRate = autoDataAccess.GetPIPRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Basic FPB", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Buses", null, inputProperty.AutoLiabilityInputModel.BasicFPBLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Calculate PersonalInjuryProtectionUnModifiedPremium  
                    outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium = (outputProperty.AutoLiabilityOutputModel.NonEmergencyPIPUnitsCount
                                                                                                      * outputProperty.AutoLiabilityOutputModel.BasicFPBNonEmergencyRate)
                                                                                                      + (outputProperty.AutoLiabilityOutputModel.EmergencyPIPUnitsCount
                                                                                                      * outputProperty.AutoLiabilityOutputModel.BasicFPBEmergencyRate)
                                                                                                      + (outputProperty.AutoLiabilityOutputModel.BusesPIPUnitsCount
                                                                                                      * outputProperty.AutoLiabilityOutputModel.BasicFPBBusesRate);

                    // Rounding
                    outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 2, MidpointRounding.AwayFromZero);

                    this.logger.Info("AutoALCwService.CalculateBasicFPBPremium :: Completed");
                }
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateBasicFPBPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateMEDPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateMEDPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 24 CalculateMEDPremium
                // Step 24.4 MedicalPaymentsNonEmergencyRate
                outputProperty.AutoLiabilityOutputModel.MedicalPaymentsNonEmergencyRate = autoDataAccess.GetMEDRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Medical Payments", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Non Emergency", inputProperty.AutoLiabilityInputModel.MedicalPaymentsLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step 24.6 MedicalPaymentsEmergencyRate
                outputProperty.AutoLiabilityOutputModel.MedicalPaymentsEmergencyRate = autoDataAccess.GetMEDRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Medical Payments", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Emergency", inputProperty.AutoLiabilityInputModel.MedicalPaymentsLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step 24.8 MedicalPaymentsBusesRate
                outputProperty.AutoLiabilityOutputModel.MedicalPaymentsBusesRate = autoDataAccess.GetMEDRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Medical Payments", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Buses", inputProperty.AutoLiabilityInputModel.MedicalPaymentsLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Calculate MedicalPaymentsUnModifiedPremium
                outputProperty.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium = (outputProperty.AutoLiabilityOutputModel.NonEmergencyMedPayUnitsCount
                                                                                          * outputProperty.AutoLiabilityOutputModel.MedicalPaymentsNonEmergencyRate)
                                                                                          + (outputProperty.AutoLiabilityOutputModel.EmergencyMedPayUnitsCount
                                                                                          * outputProperty.AutoLiabilityOutputModel.MedicalPaymentsEmergencyRate)
                                                                                          + (outputProperty.AutoLiabilityOutputModel.BusesMedPayUnitsCount
                                                                                          * outputProperty.AutoLiabilityOutputModel.MedicalPaymentsBusesRate);


                // Rounding
                outputProperty.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium, 2, MidpointRounding.AwayFromZero);

                this.logger.Info("AutoALCwService.CalculateMEDPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateMEDPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateUMPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateUMPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 25 Calculate UMPremium

                // Step 25.5 
                outputProperty.AutoLiabilityOutputModel.UninsuredNonEmergencyRate = autoDataAccess.GetUMRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Uninsured", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Non Emergency", inputProperty.AutoLiabilityInputModel.UMUIMStacking, inputProperty.AutoLiabilityInputModel.UninsuredLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step 25.7
                outputProperty.AutoLiabilityOutputModel.UninsuredEmergencyRate = autoDataAccess.GetUMRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Uninsured", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Emergency", inputProperty.AutoLiabilityInputModel.UMUIMStacking, inputProperty.AutoLiabilityInputModel.UninsuredLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step 25.9
                outputProperty.AutoLiabilityOutputModel.UninsuredBusesRate = autoDataAccess.GetUMRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Uninsured", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Buses", inputProperty.AutoLiabilityInputModel.UMUIMStacking, inputProperty.AutoLiabilityInputModel.UninsuredLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Calculate UnderinsuredUnModifiedPremium

                outputProperty.AutoLiabilityOutputModel.UninsuredUnModifiedPremium = (outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsCount
                                                                                       * outputProperty.AutoLiabilityOutputModel.UninsuredNonEmergencyRate)
                                                                                       + (outputProperty.AutoLiabilityOutputModel.EmergencyUnitsCount
                                                                                       * outputProperty.AutoLiabilityOutputModel.UninsuredEmergencyRate)
                                                                                       + (outputProperty.AutoLiabilityOutputModel.BusesCount
                                                                                       * outputProperty.AutoLiabilityOutputModel.UninsuredBusesRate);

                // Rounding 
                outputProperty.AutoLiabilityOutputModel.UninsuredUnModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.UninsuredUnModifiedPremium, 2, MidpointRounding.AwayFromZero);

                this.logger.Info("AutoALCwService.CalculateUMPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateUMPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        public void CalculateUMBIPDPremium(RaterFacadeModel model)
        {
            try
            {
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.MS || model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.IN)
                {
                    this.logger.Info("AutoALCwService.CalculateUMBIPDPremium :: Started");

                    var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                    var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                    // Step 26 Calculate UIMPremium

                    // Step 26.5 UninsuredBIPDNonEmergencyRate
                    outputProperty.AutoLiabilityOutputModel.UninsuredBIPDNonEmergencyRate = autoDataAccess.GetUMRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Uninsured BI/PD", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Non Emergency", inputProperty.AutoLiabilityInputModel.UMUIMStacking, inputProperty.AutoLiabilityInputModel.UninsuredBIPDLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 26.7 
                    outputProperty.AutoLiabilityOutputModel.UninsuredBIPDEmergencyRate = autoDataAccess.GetUMRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Uninsured BI/PD", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Emergency", inputProperty.AutoLiabilityInputModel.UMUIMStacking, inputProperty.AutoLiabilityInputModel.UninsuredBIPDLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 26.9
                    outputProperty.AutoLiabilityOutputModel.UninsuredBIPDBusesRate = autoDataAccess.GetUMRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Uninsured BI/PD", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Buses", inputProperty.AutoLiabilityInputModel.UMUIMStacking, inputProperty.AutoLiabilityInputModel.UninsuredBIPDLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Calculate UninsuredUnModifiedPremium
                    outputProperty.AutoLiabilityOutputModel.UninsuredUnModifiedPremium = (outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsCount
                                                                                       * outputProperty.AutoLiabilityOutputModel.UninsuredBIPDNonEmergencyRate)
                                                                                       + (outputProperty.AutoLiabilityOutputModel.EmergencyUnitsCount
                                                                                       * outputProperty.AutoLiabilityOutputModel.UninsuredBIPDEmergencyRate)
                                                                                       + (outputProperty.AutoLiabilityOutputModel.BusesCount
                                                                                       * outputProperty.AutoLiabilityOutputModel.UninsuredBIPDBusesRate);

                    // Rounding 
                    outputProperty.AutoLiabilityOutputModel.UninsuredUnModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.UninsuredUnModifiedPremium, 2, MidpointRounding.AwayFromZero);

                    this.logger.Info("AutoALCwService.CalculateUMBIPDPremium :: Completed");
                }

            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateUMBIPDPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateUIMPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateUIMPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // IF UnderInsured Conversion = Yes Then pass Coverage = 'Underinsured Conversion' else pass Coverage = 'UnderInsured'
                string Coverage = inputProperty.AutoLiabilityInputModel.UnderinsuredConversion == true ? "Underinsured Conversion" : "Underinsured";

                // Step 27.5 UnderinsuredNonEmergencyRate
                outputProperty.AutoLiabilityOutputModel.UnderinsuredNonEmergencyRate = autoDataAccess.GetUIMRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, Coverage, model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Non Emergency", inputProperty.AutoLiabilityInputModel.UnderinsuredLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step 27.7 UnderinsuredEmergencyRate
                outputProperty.AutoLiabilityOutputModel.UnderinsuredEmergencyRate = autoDataAccess.GetUIMRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, Coverage, model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Emergency", inputProperty.AutoLiabilityInputModel.UnderinsuredLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step 27.9 UnderinsuredBusesRate
                outputProperty.AutoLiabilityOutputModel.UnderinsuredBusesRate = autoDataAccess.GetUIMRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, Coverage, model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, "Buses", inputProperty.AutoLiabilityInputModel.UnderinsuredLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Calculate  
                outputProperty.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium = (outputProperty.AutoLiabilityOutputModel.NonEmergencyUnitsCount
                                                                                       * outputProperty.AutoLiabilityOutputModel.UnderinsuredNonEmergencyRate)
                                                                                       + (outputProperty.AutoLiabilityOutputModel.EmergencyUnitsCount
                                                                                       * outputProperty.AutoLiabilityOutputModel.UnderinsuredEmergencyRate)
                                                                                       + (outputProperty.AutoLiabilityOutputModel.BusesCount
                                                                                       * outputProperty.AutoLiabilityOutputModel.UnderinsuredBusesRate);

                // Rounding
                outputProperty.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium, 2, MidpointRounding.AwayFromZero);

                this.logger.Info("AutoALCwService.CalculateUIMPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateUIMPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateHiredAndNonOwenedPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateHiredAndNonOwenedPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // step 28 Calculate Hired and NonOwned Premium

                if (inputProperty.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "INCLUDED" || inputProperty.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY")
                {
                    outputProperty.AutoLiabilityOutputModel.HiredAndNonOwnedUnModifiedPremium = Convert.ToInt32(autoDataAccess.GetHiredandNonOwnedPremium(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Hired and Non Owned", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate));
                }
                else
                {
                    outputProperty.AutoLiabilityOutputModel.HiredAndNonOwnedUnModifiedPremium = 0;
                }

                this.logger.Info("AutoALCwService.CalculateHiredAndNonOwenedPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateHiredAndNonOwenedPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateOptionalCoveragePremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                if (inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidIsSelected)
                {
                    //Output Json Variable are Assigned by input Json
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCoverageID = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidCoverageID;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025Limit = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidCA2025Limit;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025Deductible = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidCA2025Deductible;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025RatingBasis = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidCA2025RatingBasis;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025ReturnMethod = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidCA2025ReturnMethod;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025Rate = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidCA2025Rate;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidIsSelected = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidIsSelected;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025ModifiedPremium = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidCA2025ModifiedPremium;

                    // Step 29 Calculate Mutual Aid - CA 20 25 Premium
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025UnModifiedPremium = Convert.ToInt32(autoDataAccess.GetOptionalCoveragePremium(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Mutual Aid - CA 20 40", inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.MutualAidCA2025RatingBasis, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate));
                }

                if (inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001IsSelected)
                {
                    //Output Json Variable are Assigned by input Json
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001CoverageID = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001CoverageID;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001Limit = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001Limit;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001Deductible = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001Deductible;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001RatingBasis = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001RatingBasis;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001ReturnMethod = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001ReturnMethod;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001Rate = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001Rate;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001IsSelected = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001IsSelected;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001ModifiedPremium = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001ModifiedPremium;

                    // Step 30 Calculate Lessor - Additional Insured And Loss Payee - CA 20 01 Premium
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremium = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.LessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremium;

                }

                if (inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009IsSelected)
                {
                    //Output Json Variable are Assigned by input Json
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009CoverageID = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009CoverageID;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009Limit = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009Limit;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009Deductible = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009Deductible;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009RatingBasis = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009RatingBasis;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009ReturnMethod = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009ReturnMethod;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009Rate = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009Rate;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009IsSelected = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009IsSelected;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009ModifiedPremium = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009ModifiedPremium;

                    // Step 31 Calculate Additional Insured Endorsement - Auto - AG1009 Premium
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009UnModifiedPremium = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredEndorsementAutoAG1009UnModifiedPremium;

                }

                // Step 32 Calculate Additional Insured Designated Person Or Organization - CA201
                if (inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201IsSelected)
                {
                    //Output Json Variable are Assigned by input Json
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201CoverageID = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201CoverageID;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Limit = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Limit;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Deductible = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Deductible;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201RatingBasis = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201RatingBasis;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201ReturnMethod = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201ReturnMethod;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Rate = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Rate;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201IsSelected = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201IsSelected;
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201ModifiedPremium = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201ModifiedPremium;

                    // Step 32 Calculate Additional Insured Designated Person Or Organization - CA201
                    outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201UnModifiedPremium = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201UnModifiedPremium;
                }

                // Step 33 Calculate Other Premium
                if (inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AutoLiabilityOptionalOtherCoverageInputModels != null && inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AutoLiabilityOptionalOtherCoverageInputModels.Count > 0)
                {
                    foreach (var OtherCoverage in inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AutoLiabilityOptionalOtherCoverageInputModels)
                    {
                        if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                        {
                            OtherCoverage.OtherCoveragePremium = Convert.ToInt32(Math.Round(OtherCoverage.OtherCoverageRate * ((decimal)OtherCoverage.OtherCoverageLimit / 1000), 0, MidpointRounding.AwayFromZero));
                        }
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                        {
                            OtherCoverage.OtherCoveragePremium = Convert.ToInt32(Math.Round(OtherCoverage.OtherCoverageRate * ((decimal)OtherCoverage.OtherCoverageLimit / 100), 0, MidpointRounding.AwayFromZero));
                        }
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARGE")
                        {
                            OtherCoverage.OtherCoveragePremium = OtherCoverage.OtherCoveragePremium;
                            //Convert.ToInt32(autoDataAccess.GetOptionalCoveragePremium(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Other",OtherCoverage.OtherCoverageRatingBasis, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate));
                        }
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                        {
                            OtherCoverage.OtherCoveragePremium = 0;
                        }

                        inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.OtherCoverageUnModifiedPremium = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.OtherCoverageUnModifiedPremium
                                                                                                                                 + OtherCoverage.OtherCoveragePremium;


                        outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AutoLiabilityOptionalOtherCoverageOutputModels.Add(new AutoLiabilityOptionalOtherCoverageOutputModel
                        {
                            OtherCoverageID = OtherCoverage.OtherCoverageID,
                            OtherCoverageDescription = OtherCoverage.OtherCoverageDescription,
                            OtherCoverageLimit = OtherCoverage.OtherCoverageLimit,
                            OtherCoverageDedcutible = OtherCoverage.OtherCoverageDedcutible,
                            OtherCoverageRate = OtherCoverage.OtherCoverageRate,
                            OtherCoverageRatingBasis = OtherCoverage.OtherCoverageRatingBasis,
                            OtherCoverageReturnMethod = OtherCoverage.OtherCoverageReturnMethod,
                            OtherCoveragePremium = OtherCoverage.OtherCoveragePremium
                        });
                    }
                }

                outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.OtherCoverageUnModifiedPremium = inputProperty.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.OtherCoverageUnModifiedPremium;

                // (Step 34 Calculate Optional Coverages Premium & Step 36 Calculate Non Modified Premium Merge in Same step34 ) Calculate Optional Coverages Premium

                outputProperty.AutoLiabilityOutputModel.NonModifiedPremium = outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201UnModifiedPremium
                                                                           + outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009UnModifiedPremium
                                                                           + outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremium
                                                                           + outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025UnModifiedPremium
                                                                           + outputProperty.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.OtherCoverageUnModifiedPremium;

                this.logger.Info("AutoALCwService.CalculateOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateOptionalCoveragePremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateBasePremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateBasePremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                //step 35 Calculate Base Premium

                // Step 35.7 Get Population Factor 
                outputProperty.AutoLiabilityOutputModel.PopulationRate = autoDataAccess.GetPopulationFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);


                // Step Calculation BasePremium
                outputProperty.AutoLiabilityOutputModel.BasePremium = Convert.ToInt32(Math.Round(((outputProperty.AutoLiabilityOutputModel.LiabilityUnModifiedPremium
                                                                        + outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium
                                                                        + outputProperty.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium
                                                                        + outputProperty.AutoLiabilityOutputModel.UninsuredUnModifiedPremium
                                                                        + outputProperty.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium)
                                                                        * outputProperty.AutoLiabilityOutputModel.PopulationRate)
                                                                        + outputProperty.AutoLiabilityOutputModel.HiredAndNonOwnedUnModifiedPremium, 0, MidpointRounding.AwayFromZero));

                this.logger.Info("AutoALCwService.CalculateBasePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateBasePremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateManualPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateManualPremium :: Started");

                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 37 Calculate Manual Premium
                outputProperty.AutoLiabilityOutputModel.ManualPremium = outputProperty.AutoLiabilityOutputModel.BasePremium
                                                                      + outputProperty.AutoLiabilityOutputModel.NonModifiedPremium;


                // Step 37.4 Apply Minimum Premium rules
                if (outputProperty.AutoLiabilityOutputModel.ManualPremium < outputProperty.AutoLiabilityOutputModel.MinimumPremium)
                {
                    outputProperty.AutoLiabilityOutputModel.ManualPremium = outputProperty.AutoLiabilityOutputModel.MinimumPremium;
                }

                this.logger.Info("AutoALCwService.CalculateManualPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateManualPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateTierPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateTierPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // step 38 Calculate Tier Premium

                // Step 38.4 Get Tier Factor
                ///TODO : Tierplan should come from PricingInputModel.                
                string tierPlan = model.RaterInputFacadeModel.PricingInputModel.TierPlan;

                outputProperty.AutoLiabilityOutputModel.TierRate = autoDataAccess.GetTierFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, tierPlan, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Calculate TierPremium
                outputProperty.AutoLiabilityOutputModel.TierPremium = Convert.ToInt32(Math.Round(((outputProperty.AutoLiabilityOutputModel.ManualPremium
                                                                    - outputProperty.AutoLiabilityOutputModel.NonModifiedPremium)
                                                                    * outputProperty.AutoLiabilityOutputModel.TierRate)
                                                                    + outputProperty.AutoLiabilityOutputModel.NonModifiedPremium, 0, MidpointRounding.AwayFromZero));

                // Step 38.6 Apply Minimum Premium rules
                if (outputProperty.AutoLiabilityOutputModel.TierPremium < outputProperty.AutoLiabilityOutputModel.MinimumPremium)
                {
                    outputProperty.AutoLiabilityOutputModel.TierPremium = outputProperty.AutoLiabilityOutputModel.MinimumPremium;
                }
                this.logger.Info("AutoALCwService.CalculateTierPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateTierPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        public void CalculateIRPMPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateIRPMPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
                //step 39 Calculate IRPM Premium

                outputProperty.AutoLiabilityOutputModel.IRPMPremium = Convert.ToInt32(Math.Round((((outputProperty.AutoLiabilityOutputModel.TierPremium
                                                                    - outputProperty.AutoLiabilityOutputModel.NonModifiedPremium)
                                                                    * inputProperty.AutoLiabilityInputModel.IRPMRate)
                                                                    + outputProperty.AutoLiabilityOutputModel.NonModifiedPremium), 0, MidpointRounding.AwayFromZero));

                // Step 39.5 Apply Minimum Premium rules
                if (outputProperty.AutoLiabilityOutputModel.IRPMPremium < outputProperty.AutoLiabilityOutputModel.MinimumPremium)
                {
                    outputProperty.AutoLiabilityOutputModel.IRPMPremium = outputProperty.AutoLiabilityOutputModel.MinimumPremium;
                }
                this.logger.Info("AutoALCwService.CalculateIRPMPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateIRPMPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        public void CalculateOtherModPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateOtherModPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
                // Step 40 Calculate Other Mod Premium

                outputProperty.AutoLiabilityOutputModel.OtherModPremium = Convert.ToInt32(Math.Round((((outputProperty.AutoLiabilityOutputModel.IRPMPremium
                                                                        - outputProperty.AutoLiabilityOutputModel.NonModifiedPremium)
                                                                        * inputProperty.AutoLiabilityInputModel.OtherModRate)
                                                                        + outputProperty.AutoLiabilityOutputModel.NonModifiedPremium), 0, MidpointRounding.AwayFromZero));

                outputProperty.AutoLiabilityOutputModel.OtherModRate = inputProperty.AutoLiabilityInputModel.OtherModRate;

                // Step 40.6 Apply Minimum Premium rules
                if (outputProperty.AutoLiabilityOutputModel.OtherModPremium < outputProperty.AutoLiabilityOutputModel.MinimumPremium)
                {
                    outputProperty.AutoLiabilityOutputModel.OtherModPremium = outputProperty.AutoLiabilityOutputModel.MinimumPremium;
                }
                this.logger.Info("AutoALCwService.CalculateOtherModPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateOtherModPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateTerrorismPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateTerrorismPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 41 Calculate Terrorism Premium
                // Terrorism Factor Is Always 0
                outputProperty.AutoLiabilityOutputModel.TerrorismPremium = Convert.ToInt32(Math.Round(outputProperty.AutoLiabilityOutputModel.OtherModPremium
                                                                          * outputProperty.AutoLiabilityOutputModel.TerrorismRate, 0, MidpointRounding.AwayFromZero));

                this.logger.Info("AutoALCwService.CalculateTerrorismPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateTerrorismPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateMIMCCAAssessementCharge(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateMIMCCAAssessementCharge :: Started");

                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
                // step 42 Calculate MI MCCA Assessement Charge

                if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.MI)
                {
                    // Step 42.2 
                    outputProperty.AutoLiabilityOutputModel.MIMCCAAssessmentRatingExposure = outputProperty.AutoLiabilityOutputModel.TotalPIPUnitswithoutTrailersCount;

                    var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;

                    // Step 42.1 Get MIMCCAAssessmentRate
                    outputProperty.AutoLiabilityOutputModel.MIMCCAAssessmentRate = autoDataAccess.GetSurchargeRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "MI MCCA Assessment", "n/a", "All", inputProperty.AutoLiabilityInputModel.PersonalInjuryProtectionLimit, "n/a", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                    // Calculate MIMCCAAssessmentCharge
                    outputProperty.AutoLiabilityOutputModel.MIMCCAAssessmentCharge = outputProperty.AutoLiabilityOutputModel.MIMCCAAssessmentRate
                                                                                     * outputProperty.AutoLiabilityOutputModel.MIMCCAAssessmentRatingExposure;

                }
                this.logger.Info("AutoALCwService.CalculateMIMCCAAssessementCharge :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateMIMCCAAssessementCharge   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateNCAutoLossRecoupmentSurcharge(RaterFacadeModel model)
        {
            try
            {
                // Step 43
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NC)
                {
                    this.logger.Info("AutoALCwService.CalculateNCAutoLossRecoupmentSurcharge :: Started");

                    var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                    var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                    // Step Get NCAutoLossRecoupmentSurchargeRate
                    //todo
                    outputProperty.AutoLiabilityOutputModel.NCAutoLossRecoupmentSurchargeRate = autoDataAccess.GetSurchargeRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "NC Auto Loss Recoupment Surcharge", "n/a", "n/a", "n/a", "n/a", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);


                    // Step Calculate NCAutoLossRecoupmentSurchargeCharge
                    outputProperty.AutoLiabilityOutputModel.NCAutoLossRecoupmentSurchargeCharge = Math.Round((outputProperty.AutoLiabilityOutputModel.NCAutoLossRecoupmentSurchargeRate / 100)
                                                                                                 * outputProperty.AutoLiabilityOutputModel.OtherModPremium, 0, MidpointRounding.AwayFromZero);

                    this.logger.Info("AutoALCwService.CalculateNCAutoLossRecoupmentSurcharge :: Completed");
                }
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateNCAutoLossRecoupmentSurcharge   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateFinalPremiumForNonMIAndNC(RaterFacadeModel model)
        {
            try
            {
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() != StateCodeConstant.MI && model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() != StateCodeConstant.NC)
                {
                    this.logger.Info("AutoALCwService.CalculateFinalPremiumForNonMIAndNC :: Started");

                    var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                    var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                    // Step 45
                    // Calculate ALModifiedFinalPremium
                    outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium = outputProperty.AutoLiabilityOutputModel.OtherModPremium
                                                                                   + outputProperty.AutoLiabilityOutputModel.TerrorismPremium;


                    // Step 45.3 Apply Minimum Premium rules
                    if (outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium < outputProperty.AutoLiabilityOutputModel.MinimumPremium)
                    {
                        outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium = outputProperty.AutoLiabilityOutputModel.MinimumPremium;
                    }

                    this.logger.Info("AutoALCwService.CalculateFinalPremiumForNonMIAndNC :: Completed");
                }
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateFinalPremiumForNonMIAndNC :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateFinalPremiumForMI(RaterFacadeModel model)
        {
            try
            {
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.MI)
                {
                    this.logger.Info("AutoALCwService.CalculateFinalPremiumForMI :: Started");

                    var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                    var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                    // Step 46
                    // Calculate ALModifiedFinalPremium
                    outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium = Convert.ToInt32(Math.Round(outputProperty.AutoLiabilityOutputModel.OtherModPremium
                                                                                   + outputProperty.AutoLiabilityOutputModel.TerrorismPremium
                                                                                   + outputProperty.AutoLiabilityOutputModel.MIMCCAAssessmentCharge, 0, MidpointRounding.AwayFromZero));

                    // Step 46.3 Apply Minimum Premium rules
                    if (outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium < outputProperty.AutoLiabilityOutputModel.MinimumPremium)
                    {
                        outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium = outputProperty.AutoLiabilityOutputModel.MinimumPremium;
                    }

                    this.logger.Info("AutoALCwService.CalculateFinalPremiumForMI :: Completed");
                }
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateFinalPremiumForMI   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateFinalPremiumForNC(RaterFacadeModel model)
        {
            try
            {
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NC)
                {
                    this.logger.Info("AutoALCwService.CalculateFinalPremiumForNC :: Started");

                    var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                    var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                    // Step 45
                    // Calculate ALModifiedFinalPremium
                    outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium = Convert.ToInt32(Math.Round(outputProperty.AutoLiabilityOutputModel.OtherModPremium
                                                                                   + outputProperty.AutoLiabilityOutputModel.TerrorismPremium
                                                                                   + outputProperty.AutoLiabilityOutputModel.NCAutoLossRecoupmentSurchargeCharge, 0, MidpointRounding.AwayFromZero));


                    // Step 45.3 Apply Minimum Premium rules
                    if (outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium < outputProperty.AutoLiabilityOutputModel.MinimumPremium)
                    {
                        outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium = outputProperty.AutoLiabilityOutputModel.MinimumPremium;
                    }

                    this.logger.Info("AutoALCwService.CalculateFinalPremiumForNC :: Completed");
                }
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateFinalPremiumForNC   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateLiabilityModifiedPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateLiabilityModifiedPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 49 Calculate LiabilityModifiedPremium

                outputProperty.AutoLiabilityOutputModel.LiabilityModifiedPremium = outputProperty.AutoLiabilityOutputModel.LiabilityUnModifiedPremium
                                                                                 * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                 * inputProperty.AutoLiabilityInputModel.IRPMRate
                                                                                 * inputProperty.AutoLiabilityInputModel.OtherModRate;

                // Rounding
                outputProperty.AutoLiabilityOutputModel.LiabilityModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.LiabilityModifiedPremium, 2, MidpointRounding.AwayFromZero);

                this.logger.Info("AutoALCwService.CalculateLiabilityModifiedPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateLiabilityModifiedPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateMedPeyModifiedPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateMedPeyModifiedPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 50 Calculate MedicalPaymentsModifiedPremium

                outputProperty.AutoLiabilityOutputModel.MedicalPaymentsModifiedPremium = outputProperty.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium
                                                                                 * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                 * inputProperty.AutoLiabilityInputModel.IRPMRate
                                                                                 * inputProperty.AutoLiabilityInputModel.OtherModRate;

                // Rounding
                outputProperty.AutoLiabilityOutputModel.MedicalPaymentsModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.MedicalPaymentsModifiedPremium, 2, MidpointRounding.AwayFromZero);

                this.logger.Info("AutoALCwService.CalculateMedPeyModifiedPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateMedPeyModifiedPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateUMAndBIPDModifiedPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateUMAndBIPDModifiedPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 51 Calculate UninsuredModifiedPremium

                outputProperty.AutoLiabilityOutputModel.UninsuredModifiedPremium = outputProperty.AutoLiabilityOutputModel.UninsuredUnModifiedPremium
                                                                                 * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                 * inputProperty.AutoLiabilityInputModel.IRPMRate
                                                                                 * inputProperty.AutoLiabilityInputModel.OtherModRate;

                // Rounding
                outputProperty.AutoLiabilityOutputModel.UninsuredModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.UninsuredModifiedPremium, 2, MidpointRounding.AwayFromZero);

                this.logger.Info("AutoALCwService.CalculateUMAndBIPDModifiedPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateUMAndBIPDModifiedPremium   :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateUIMModifiedPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateUIMModifiedPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 52 Calculate UnderinsuredModifiedPremium

                outputProperty.AutoLiabilityOutputModel.UnderinsuredModifiedPremium = outputProperty.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium
                                                                                 * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                 * inputProperty.AutoLiabilityInputModel.IRPMRate
                                                                                 * inputProperty.AutoLiabilityInputModel.OtherModRate;

                // Rounding
                outputProperty.AutoLiabilityOutputModel.UnderinsuredModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.UnderinsuredModifiedPremium, 2, MidpointRounding.AwayFromZero);

                this.logger.Info("AutoALCwService.CalculateUIMModifiedPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateUIMModifiedPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculatePIPAndBasicFPBModifiedPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculatePIPAndBasicFPBModifiedPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 53 Calculate PersonalInjuryProtectionModifiedPremium

                outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionModifiedPremium = outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium
                                                                                 * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                 * inputProperty.AutoLiabilityInputModel.IRPMRate
                                                                                 * inputProperty.AutoLiabilityInputModel.OtherModRate;

                // Rounding
                outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionModifiedPremium, 2, MidpointRounding.AwayFromZero);

                this.logger.Info("AutoALCwService.CalculatePIPAndBasicFPBModifiedPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculatePIPAndBasicFPBModifiedPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateHiredANDNonOwnedModifiedPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoALCwService.CalculateHiredANDNonOwnedModifiedPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

                // Step 54 Calculate PersonalInjuryProtectionModifiedPremium

                outputProperty.AutoLiabilityOutputModel.HiredAndNonOwnedModifiedPremium = outputProperty.AutoLiabilityOutputModel.HiredAndNonOwnedUnModifiedPremium
                                                                                 * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                 * inputProperty.AutoLiabilityInputModel.IRPMRate
                                                                                 * inputProperty.AutoLiabilityInputModel.OtherModRate;

                // Rounding
                outputProperty.AutoLiabilityOutputModel.HiredAndNonOwnedModifiedPremium = Math.Round(outputProperty.AutoLiabilityOutputModel.HiredAndNonOwnedModifiedPremium, 2, MidpointRounding.AwayFromZero);

                this.logger.Info("AutoALCwService.CalculateHiredANDNonOwnedModifiedPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoALCwService.CalculateHiredANDNonOwnedModifiedPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
        #endregion
    }
}

