﻿using DataAccess;
using DomainRules;
using FluentValidation.Results;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Validations;

namespace RaterAutoLiability
{
    public class AutoAPDService : IAutoAPDService
    {
        private AutoDataAccess autoDataAccess { get; set; }

        readonly ILoggingManager logger;
        readonly IConfiguration configuration;
        public AutoAPDService(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.autoDataAccess = new AutoDataAccess(this.configuration, this.logger);
        }

        public DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        public FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                ValidationResult result = new ValidationResult();
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.NY)
                {
                    var validator = new AutoAPDNYPreValidator(this.configuration, this.logger);
                    result = validator.Validate(model);
                }
                else
                {
                    var validator = new AutoAPDCWPreValidator(this.configuration, this.logger);
                    result = validator.Validate(model);
                }


                return result;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);

                throw;
            }
        }

        public FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                ValidationResult result = new ValidationResult();
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.NY)
                {
                    var validator = new AutoAPDNYPostValidator(this.configuration, this.logger);
                    result = validator.Validate(model);
                }
                else
                {
                    var validator = new AutoAPDCWPostValidator(this.configuration, this.logger);
                    result = validator.Validate(model);
                }

                return result;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);
                throw;
            }
        }

        public void Calculate(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateAPDPremium :: Started");

                #region OptionalCoveragePremium & OtherCoveragePremium

                CalculateCollCompAndSpecifiedCasueofLossPremium(model);

                #endregion

                #region OptionalCoveragePremium & OtherCoveragePremium

                CalculateOptionalCoveragePremium(model);

                #endregion

                #region MN Automobile Theft Prevention Surcharge

                CalculateMNAutomobileTheftPreventionSurcharge(model);

                #endregion

                #region MN Fire Safety Surcharge

                CalculateMNFireSafetySurcharge(model);

                #endregion

                #region Base Premium

                CalculateBasePremium(model);

                #endregion

                #region Manual Premium

                CalculateManualPremium(model);

                #endregion

                #region Tier Premium

                CalculateTierPremium(model);

                #endregion

                #region IRPM Premium

                CalculateIRPMPremium(model);

                #endregion

                #region Other Mod Premium

                CalculateOtherModPremium(model);

                #endregion

                #region Terrorism Premium

                CalculateTerrorismPremium(model);

                #endregion

                #region Final Premium

                CalculateFinalPremium(model);

                #endregion


                this.logger.Info("AutoPhysicalDamageService.CalculateAPDPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateAPDPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateCollCompAndSpecifiedCasueofLossPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateCollCompAndSpecifiedCasueofLossPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                policyHeader.State = policyHeader.State.ToUpper();
                policyHeader.PrimaryClass = policyHeader.PrimaryClass.ToUpper();
                policyHeader.TransactionType = policyHeader.TransactionType.ToUpper();

                if (policyHeader.State == StateCodeConstant.NY)
                {
                    inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                    outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
                }

                //step 1 STATECODE Pre-Populated from IMS
                //step 2 PrimaryClass User Entry
                //step 3 PopulationADA User Entry
                //step 4 Location Type User Entry

                // to get MinimumPremium
                outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium = Convert.ToInt32(autoDataAccess.GetMinimumPremium(policyHeader.State, policyHeader.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, policyHeader.PolicyEffectiveDate));

                if (inputProperty.AutoScheduleVehiclesDetailsInputModel != null && inputProperty.AutoScheduleVehiclesDetailsInputModel.Count > 0)
                {

                    foreach (var scheduleInput in inputProperty.AutoScheduleVehiclesDetailsInputModel)
                    {
                        outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionSurchargeRatingExposure = Convert.ToInt32(outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionSurchargeRatingExposure
                                                                                                                + autoDataAccess.GetAutoSurchargeVehiclesCount(policyHeader.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "MN Automobile Theft Prevention Surcharge", "Comprehensive", scheduleInput.ClassCode, policyHeader.TransactionType, policyHeader.PolicyEffectiveDate));
                    }

                    // Grouping for comprehensive
                    var comprehensivegroupedList = inputProperty.AutoScheduleVehiclesDetailsInputModel.Where(x => x.CompDeductible != 0)
                                           .GroupBy(u => new { u.CompDeductible, u.Valuation }).Select(grp => grp.ToList()).ToList();


                    // Grouping for collision
                    var collisiongroupedList = inputProperty.AutoScheduleVehiclesDetailsInputModel.Where(x => x.CollDeductible != 0)
                                           .GroupBy(u => new { u.CollDeductible, u.Valuation }).Select(grp => grp.ToList()).ToList();


                    // Grouping for specifiedCausesofLoss
                    var specifiedCausesofLossgroupedList = inputProperty.AutoScheduleVehiclesDetailsInputModel.Where(x => x.SpecifiedCauseofLossDeductible != 0)
                                           .GroupBy(u => new { u.SpecifiedCauseofLossDeductible, u.Valuation }).Select(grp => grp.ToList()).ToList();


                    //step 5 inputProperty.NonEmergencyUnitscount
                    inputProperty.AutoPhysicalDamageInputModel.NonEmergencyUnitsCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.RatingGroup.ToUpper() == "NON EMERGENCY").Count;

                    //step 6 inputProperty.EmergencyUnitscount
                    inputProperty.AutoPhysicalDamageInputModel.EmergencyUnitsCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.RatingGroup.ToUpper() == "EMERGENCY").Count;

                    //step 7 inputProperty.BusesCount
                    inputProperty.AutoPhysicalDamageInputModel.BusesCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.RatingGroup.ToUpper() == "BUSES").Count;

                    //step  inputProperty.TrailersCount (as suggested by Manoj)
                    inputProperty.AutoPhysicalDamageInputModel.TrailersCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.RatingGroup.ToUpper() == "TRAILERS").Count;

                    // Step 8 Get Total Vehicle Count
                    inputProperty.AutoPhysicalDamageInputModel.TotalVehiclesCount = inputProperty.AutoPhysicalDamageInputModel.NonEmergencyUnitsCount
                                                                                  + inputProperty.AutoPhysicalDamageInputModel.EmergencyUnitsCount
                                                                                  + inputProperty.AutoPhysicalDamageInputModel.BusesCount
                                                                                  + inputProperty.AutoPhysicalDamageInputModel.TrailersCount;

                    outputProperty.AutoPhysicalDamageOutputModel.TotalVehiclesCount = inputProperty.AutoPhysicalDamageInputModel.TotalVehiclesCount;

                    //step  inputProperty.TrailersCount (as suggested by Manoj)
                    outputProperty.AutoPhysicalDamageOutputModel.TotalVehicleswithoutTrailersCount = outputProperty.AutoPhysicalDamageOutputModel.TotalVehiclesCount
                                                                                                    - inputProperty.AutoPhysicalDamageInputModel.TrailersCount;

                    // Step 8.1 Get Comp Vehicles Count
                    inputProperty.AutoPhysicalDamageInputModel.CompVehiclesCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.CompDeductible != 0).Count;

                    outputProperty.AutoPhysicalDamageOutputModel.TotalComprehensiveVehiclesCount = inputProperty.AutoPhysicalDamageInputModel.CompVehiclesCount;

                    // Step 8.3 Get Coll Vehicles Count
                    inputProperty.AutoPhysicalDamageInputModel.CollVehiclesCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.CollDeductible != 0).Count;

                    outputProperty.AutoPhysicalDamageOutputModel.TotalCollisionVehiclesCount = inputProperty.AutoPhysicalDamageInputModel.CollVehiclesCount;

                    // Step 8.5 Get Spec Cause of Loss Vehicles Count
                    inputProperty.AutoPhysicalDamageInputModel.SpecifiedCauseofLossCount = inputProperty.AutoScheduleVehiclesDetailsInputModel.FindAll(x => x.SpecifiedCauseofLossDeductible != 0).Count;

                    outputProperty.AutoPhysicalDamageOutputModel.TotalSpecifiedCauseofLossVehiclesCount = inputProperty.AutoPhysicalDamageInputModel.SpecifiedCauseofLossCount;

                    // Step 12 Calculate Collision Premium per category

                    List<CollisionOutputModel> collisionOutputModels = new List<CollisionOutputModel>();

                    if (collisiongroupedList != null && collisiongroupedList.Count > 0)
                    {
                        foreach (var collisionGroup in collisiongroupedList)
                        {
                            CollisionOutputModel collisionOutput = new CollisionOutputModel();

                            foreach (var collisionSubGroup in collisionGroup)
                            {
                                // Step 8.4 Get Coll Vehicles Count Per Category
                                collisionOutput.CollisionVehiclescountpercategory = collisionOutput.CollisionVehiclescountpercategory + 1;

                                // Step 11 Calculate Collision OCN per category 
                                collisionOutput.CollisionOCNPerCategory = collisionOutput.CollisionOCNPerCategory + collisionSubGroup.OCN;

                                // Assign CollisionDeductibleperCategory
                                collisionOutput.CollisionDeductibleperCategory = collisionSubGroup.CollDeductible;

                                // Assign CollisionValuationperCategory
                                collisionOutput.CollisionValuationperCategory = collisionSubGroup.Valuation;

                            }

                            // Step 12.2 Get Base Rate
                            if (inputProperty.AutoPhysicalDamageInputModel.CollisionBaseRate < 0)
                            {
                                DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(policyHeader.State, policyHeader.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Collision", policyHeader.LocationType, policyHeader.PolicyEffectiveDate);
                                if (dtAutorate != null)
                                {
                                    outputProperty.AutoPhysicalDamageOutputModel.CollisionBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                                }
                            }
                            else
                            {
                                outputProperty.AutoPhysicalDamageOutputModel.CollisionBaseRate = inputProperty.AutoPhysicalDamageInputModel.CollisionBaseRate;
                            }

                            //if (inputProperty.AutoPhysicalDamageInputModel.CollisionBaseRate != 0)
                            //{
                            //    outputProperty.AutoPhysicalDamageOutputModel.CollisionBaseRate = inputProperty.AutoPhysicalDamageInputModel.CollisionBaseRate;
                            //}
                            // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                            //else
                            //{
                            //    DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(policyHeader.State, policyHeader.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Collision", policyHeader.LocationType, policyHeader.PolicyEffectiveDate);
                            //    if (dtAutorate != null)
                            //    {
                            //        outputProperty.AutoPhysicalDamageOutputModel.CollisionBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                            //    }
                            //}

                            // Step 12.3 Get Collision Deductible Factor
                            collisionOutput.CollisionDeductibleFactorperCategory = autoDataAccess.GetDeductibleFactor(policyHeader.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, null, collisionOutput.CollisionDeductibleperCategory, "Collision", policyHeader.PolicyEffectiveDate);

                            // Step 12.4 Get Valuation Factor
                            collisionOutput.CollisionValuationFactorperCategory = autoDataAccess.GetValuationFactor(policyHeader.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, collisionOutput.CollisionValuationperCategory, policyHeader.PolicyEffectiveDate);

                            // Step 12.5 Get Population Factor
                            outputProperty.AutoPhysicalDamageOutputModel.PopulationRate = autoDataAccess.GetPopulationFactor(policyHeader.State, policyHeader.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, policyHeader.PopulationADA, policyHeader.PolicyEffectiveDate);


                            // Step Calculate Collision Premium per category
                            collisionOutput.CollisionPremiumperCategory = Convert.ToInt32(Math.Round(((decimal)collisionOutput.CollisionOCNPerCategory / 100) * outputProperty.AutoPhysicalDamageOutputModel.CollisionBaseRate
                                                                         * collisionOutput.CollisionDeductibleFactorperCategory * collisionOutput.CollisionValuationFactorperCategory
                                                                         * outputProperty.AutoPhysicalDamageOutputModel.PopulationRate, 0, MidpointRounding.AwayFromZero));


                            // Step 13 Calculate Total Collision Premium

                            outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedCollisionPremium = outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedCollisionPremium + collisionOutput.CollisionPremiumperCategory;

                            // SUM(Collision OCN Per Category)
                            outputProperty.AutoPhysicalDamageOutputModel.TotalCollisionOCN = outputProperty.AutoPhysicalDamageOutputModel.TotalCollisionOCN + collisionOutput.CollisionOCNPerCategory;

                            collisionOutputModels.Add(collisionOutput);
                        }
                    }

                    outputProperty.AutoPhysicalDamageOutputModel.CollisionOutputModels = collisionOutputModels;



                    // Step 15 Calculate Comprehensive Premium per category

                    List<ComprehensiveOutputModel> comprehensiveOutputModels = new List<ComprehensiveOutputModel>();

                    if (comprehensivegroupedList != null && comprehensivegroupedList.Count > 0)
                    {
                        foreach (var comprehensiveGroup in comprehensivegroupedList)
                        {
                            ComprehensiveOutputModel comprehensiveOutput = new ComprehensiveOutputModel();

                            foreach (var comprehensiveSubGroup in comprehensiveGroup)
                            {
                                // Step 8.2 Get Coll Vehicles Count Per Category
                                comprehensiveOutput.ComprehensiveVehiclesCountpercategory = comprehensiveOutput.ComprehensiveVehiclesCountpercategory + 1;

                                // Step 14 Calculate Comprehensive OCN per category 
                                comprehensiveOutput.ComprehensiveOCNPerCategory = comprehensiveOutput.ComprehensiveOCNPerCategory + comprehensiveSubGroup.OCN;

                                // Assign ComprehensiveDeductibleperCategory
                                comprehensiveOutput.ComprehensiveDeductibleperCategory = comprehensiveSubGroup.CompDeductible;

                                // Assign ComprehensiveValuationperCategory
                                comprehensiveOutput.ComprehensiveValuationperCategory = comprehensiveSubGroup.Valuation;
                            }

                            // Step 15.2 Get Base Rate
                            if (inputProperty.AutoPhysicalDamageInputModel.CompBaseRate < 0)
                            {
                                DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(policyHeader.State, policyHeader.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Comprehensive", policyHeader.LocationType, policyHeader.PolicyEffectiveDate);
                                if (dtAutorate != null)
                                {
                                    outputProperty.AutoPhysicalDamageOutputModel.CompBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                                }
                            }
                            else
                            {
                                outputProperty.AutoPhysicalDamageOutputModel.CompBaseRate = inputProperty.AutoPhysicalDamageInputModel.CompBaseRate;
                            }

                            //if (inputProperty.AutoPhysicalDamageInputModel.CompBaseRate != 0)
                            //{
                            //    outputProperty.AutoPhysicalDamageOutputModel.CompBaseRate = inputProperty.AutoPhysicalDamageInputModel.CompBaseRate;
                            //}
                            // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                            //else
                            //{
                            //    DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(policyHeader.State, policyHeader.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Comprehensive", policyHeader.LocationType, policyHeader.PolicyEffectiveDate);
                            //    if (dtAutorate != null)
                            //    {
                            //        outputProperty.AutoPhysicalDamageOutputModel.CompBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                            //    }
                            //}

                            // Step 15.3 Get Comprehensive Deductible Factor
                            comprehensiveOutput.ComprehensiveDeductibleFactorperCategory = autoDataAccess.GetDeductibleFactor(policyHeader.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, null, comprehensiveOutput.ComprehensiveDeductibleperCategory, "Comprehensive", policyHeader.PolicyEffectiveDate);

                            // Step 15.4 Get Valuation Factor
                            comprehensiveOutput.ComprehensiveValuationFactorperCategory = autoDataAccess.GetValuationFactor(policyHeader.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, comprehensiveOutput.ComprehensiveValuationperCategory, policyHeader.PolicyEffectiveDate);

                            // Step 15.5 Get Population Factor (Using Common PopulationRate in all Coverage)

                            // Calculate Comprehensive Premium per category
                            comprehensiveOutput.ComprehensivePremiumperCategory = Convert.ToInt32(Math.Round(((decimal)comprehensiveOutput.ComprehensiveOCNPerCategory / 100) * outputProperty.AutoPhysicalDamageOutputModel.CompBaseRate
                                                                                 * comprehensiveOutput.ComprehensiveDeductibleFactorperCategory * comprehensiveOutput.ComprehensiveValuationFactorperCategory
                                                                                 * outputProperty.AutoPhysicalDamageOutputModel.PopulationRate, 0, MidpointRounding.AwayFromZero));

                            //Step 16 Calculate Total Comprehensive Premium
                            outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium = outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium + comprehensiveOutput.ComprehensivePremiumperCategory;

                            // SUM(Comprehensive OCN Per Category)
                            outputProperty.AutoPhysicalDamageOutputModel.TotalComprehensiveOCN = outputProperty.AutoPhysicalDamageOutputModel.TotalComprehensiveOCN + comprehensiveOutput.ComprehensiveOCNPerCategory;

                            comprehensiveOutputModels.Add(comprehensiveOutput);
                        }
                    }

                    outputProperty.AutoPhysicalDamageOutputModel.ComprehensiveOutputModels = comprehensiveOutputModels;


                    // Step 18 Calculate Specified Cause of Loss Premium per category

                    List<SpecifiedCausesofLossOutputModel> specifiedCausesofLossOutputModels = new List<SpecifiedCausesofLossOutputModel>();

                    if (specifiedCausesofLossgroupedList != null && specifiedCausesofLossgroupedList.Count > 0)
                    {
                        foreach (var specifiedCausesofLossGroup in specifiedCausesofLossgroupedList)
                        {
                            SpecifiedCausesofLossOutputModel specifiedCausesofLossOutput = new SpecifiedCausesofLossOutputModel();
                            foreach (var specifiedCausesofLossSubGroup in specifiedCausesofLossGroup)
                            {
                                // Step 8.6 Get SpecifiedCauseofLossVehiclesCountpercategory
                                specifiedCausesofLossOutput.SpecifiedCauseofLossVehiclesCountpercategory = specifiedCausesofLossOutput.SpecifiedCauseofLossVehiclesCountpercategory + 1;

                                // Step 17 Calculate SpecCauseofLossOCNPerCategory
                                specifiedCausesofLossOutput.SpecCauseofLossOCNPerCategory = specifiedCausesofLossOutput.SpecCauseofLossOCNPerCategory + specifiedCausesofLossSubGroup.OCN;

                                // Assign SpecifiedCauseofLossDeductibleperCategory
                                specifiedCausesofLossOutput.SpecifiedCauseofLossDeductibleperCategory = specifiedCausesofLossSubGroup.SpecifiedCauseofLossDeductible;

                                // Assign SpecifiedCauseofLossValuationperCategory
                                specifiedCausesofLossOutput.SpecifiedCauseofLossValuationperCategory = specifiedCausesofLossSubGroup.Valuation;
                            }

                            // Step 18.2 Get Base Rate
                            if (inputProperty.AutoPhysicalDamageInputModel.SpecCauseofLossBaseRate < 0)
                            {
                                DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(policyHeader.State, policyHeader.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Specified Causes of Loss", policyHeader.LocationType, policyHeader.PolicyEffectiveDate);
                                if (dtAutorate != null)
                                {
                                    outputProperty.AutoPhysicalDamageOutputModel.SpecCauseofLossBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                                }
                            }
                            else
                            {
                                outputProperty.AutoPhysicalDamageOutputModel.SpecCauseofLossBaseRate = inputProperty.AutoPhysicalDamageInputModel.SpecCauseofLossBaseRate;
                            }

                            //if (inputProperty.AutoPhysicalDamageInputModel.SpecCauseofLossBaseRate != 0)
                            //{
                            //    outputProperty.AutoPhysicalDamageOutputModel.SpecCauseofLossBaseRate = inputProperty.AutoPhysicalDamageInputModel.SpecCauseofLossBaseRate;
                            //}
                            // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                            //else
                            //{
                            //    DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(policyHeader.State, policyHeader.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Specified Cause of Loss", policyHeader.LocationType, policyHeader.PolicyEffectiveDate);
                            //    if (dtAutorate != null)
                            //    {
                            //        outputProperty.AutoPhysicalDamageOutputModel.SpecCauseofLossBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                            //    }
                            //}

                            // Step 18.3 Get Specified Cause of Loss Deductible Factor
                            specifiedCausesofLossOutput.SpecCauseofLossDeductibleFactorperCategory = autoDataAccess.GetDeductibleFactor(policyHeader.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, null, specifiedCausesofLossOutput.SpecifiedCauseofLossDeductibleperCategory, "Specified Cause of Loss", policyHeader.PolicyEffectiveDate);

                            // Step 18.4 Get Valuation Factor
                            specifiedCausesofLossOutput.SpecCauseofLossValuationFactorperCategory = autoDataAccess.GetValuationFactor(policyHeader.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, specifiedCausesofLossOutput.SpecifiedCauseofLossValuationperCategory, policyHeader.PolicyEffectiveDate);

                            // Step 18.5 Get Population Factor (Using Common PopulationRate in all Coverage)

                            // Calculate Comprehensive Premium per category
                            specifiedCausesofLossOutput.SpecCauseofLossPremiumperCategory = Convert.ToInt32(Math.Round(((decimal)specifiedCausesofLossOutput.SpecCauseofLossOCNPerCategory / 100) * outputProperty.AutoPhysicalDamageOutputModel.SpecCauseofLossBaseRate
                                                                                          * specifiedCausesofLossOutput.SpecCauseofLossDeductibleFactorperCategory * specifiedCausesofLossOutput.SpecCauseofLossValuationFactorperCategory
                                                                                          * outputProperty.AutoPhysicalDamageOutputModel.PopulationRate, 0, MidpointRounding.AwayFromZero));

                            // Step 19 Calculate Total Specified Cause of Loss Premium
                            outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedSpecCauseofLossPremium = outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedSpecCauseofLossPremium + specifiedCausesofLossOutput.SpecCauseofLossPremiumperCategory;

                            // SUM(Specified Cause of Loss OCN Per Category)
                            outputProperty.AutoPhysicalDamageOutputModel.TotalSpecifiedCauseofLossOCN = outputProperty.AutoPhysicalDamageOutputModel.TotalSpecifiedCauseofLossOCN + specifiedCausesofLossOutput.SpecCauseofLossOCNPerCategory;

                            specifiedCausesofLossOutputModels.Add(specifiedCausesofLossOutput);
                        }
                    }

                    outputProperty.AutoPhysicalDamageOutputModel.SpecifiedCausesofLossOutputModels = specifiedCausesofLossOutputModels;

                    outputProperty.AutoPhysicalDamageOutputModel.TotalOCN = outputProperty.AutoPhysicalDamageOutputModel.TotalCollisionOCN
                                                                          + outputProperty.AutoPhysicalDamageOutputModel.TotalComprehensiveOCN
                                                                          + outputProperty.AutoPhysicalDamageOutputModel.TotalSpecifiedCauseofLossOCN;
                }

                this.logger.Info("AutoPhysicalDamageService.CalculateCollCompAndSpecifiedCasueofLossPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateCollCompAndSpecifiedCasueofLossPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public void CalculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            var ALInputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var ALOutputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                ALInputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                ALOutputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }
            var inputProperty = ALInputProperty.AutoPhysicalDamageInputModel.AutoPhysicalDamageOptionalCoverageInputModel;
            if (inputProperty != null)
            {
                ALOutputProperty.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel = new AutoPhysicalDamageOptionalCoverageOutputModel();
                ALOutputProperty.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.AutoPhysicalDamageOptionalOtherCoverageOutputModels = new List<AutoPhysicalDamageOptionalOtherCoverageOutputModel>();
            }
            var outputProperty = ALOutputProperty.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel;

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateOptionalCoveragePremium :: Started");

                // Step 20   Calculate Garagekeepers - CA 99 37 Premium
                if (inputProperty.GaragekeepersCA9937IsSelected)
                {
                    outputProperty.GaragekeepersCA9937UnModifiedPremium = Convert.ToInt32(Math.Round(((decimal)inputProperty.GaragekeepersCA9937Limit / 1000)
                                                                          * inputProperty.GaragekeepersCA9937Rate, 0, MidpointRounding.AwayFromZero));
                    outputProperty.GaragekeepersCA9937CoverageID = inputProperty.GaragekeepersCA9937CoverageID;
                    outputProperty.GaragekeepersCA9937Deductible = inputProperty.GaragekeepersCA9937Deductible;
                    outputProperty.GaragekeepersCA9937Limit = inputProperty.GaragekeepersCA9937Limit;
                    outputProperty.GaragekeepersCA9937Rate = inputProperty.GaragekeepersCA9937Rate;
                    outputProperty.GaragekeepersCA9937RatingBasis = inputProperty.GaragekeepersCA9937RatingBasis;
                    outputProperty.GaragekeepersCA9937ReturnMethod = inputProperty.GaragekeepersCA9937ReturnMethod;
                    outputProperty.GaragekeepersCA9937IsSelected = inputProperty.GaragekeepersCA9937IsSelected;
                }

                // Step 21   Calculate Rental Reimbursement - CA 99 23 Premium
                if (inputProperty.RentalReimbursementCA9923IsSelected)
                {
                    outputProperty.RentalReimbursementCA9923UnModifiedPremium = inputProperty.RentalReimbursementCA9923Premium;
                    outputProperty.RentalReimbursementCA9923CoverageID = inputProperty.RentalReimbursementCA9923CoverageID;
                    outputProperty.RentalReimbursementCA9923Deductible = inputProperty.RentalReimbursementCA9923Deductible;
                    outputProperty.RentalReimbursementCA9923Limit = inputProperty.RentalReimbursementCA9923Limit;
                    outputProperty.RentalReimbursementCA9923Rate = inputProperty.RentalReimbursementCA9923Rate;
                    outputProperty.RentalReimbursementCA9923RatingBasis = inputProperty.RentalReimbursementCA9923RatingBasis;
                    outputProperty.RentalReimbursementCA9923ReturnMethod = inputProperty.RentalReimbursementCA9923ReturnMethod;
                    outputProperty.RentalReimbursementCA9923IsSelected = inputProperty.RentalReimbursementCA9923IsSelected;
                }

                // Step 22  Calculate Rental Reimbursement - Emergency Service Vehicles - BA0004 Premium
                if (inputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004IsSelected)
                {
                    outputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004UnModifiedPremium = inputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004Premium;
                    outputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004CoverageID = inputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004CoverageID;
                    outputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004Deductible = inputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004Deductible;
                    outputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004Limit = inputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004Limit;
                    outputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004Rate = inputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004Rate;
                    outputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004RatingBasis = inputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004RatingBasis;
                    outputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004ReturnMethod = inputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004ReturnMethod;
                    outputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004IsSelected = inputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004IsSelected;
                }

                // Step 23  Calculate Full Safety Glass Coverage - CA 04 21 Premium
                if (inputProperty.FullSafetyGlassCoverageCA0421IsSelected)
                {
                    outputProperty.FullSafetyGlassCoverageCA0421UnModifiedPremium = Convert.ToInt32(Math.Round(inputProperty.FullSafetyGlassCoverageCA0421Rate
                                                                                   * ALOutputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium, 0, MidpointRounding.AwayFromZero));
                    outputProperty.FullSafetyGlassCoverageCA0421CoverageID = inputProperty.FullSafetyGlassCoverageCA0421CoverageID;
                    outputProperty.FullSafetyGlassCoverageCA0421Deductible = inputProperty.FullSafetyGlassCoverageCA0421Deductible;
                    outputProperty.FullSafetyGlassCoverageCA0421Limit = inputProperty.FullSafetyGlassCoverageCA0421Limit;
                    outputProperty.FullSafetyGlassCoverageCA0421Rate = inputProperty.FullSafetyGlassCoverageCA0421Rate;
                    outputProperty.FullSafetyGlassCoverageCA0421RatingBasis = inputProperty.FullSafetyGlassCoverageCA0421RatingBasis;
                    outputProperty.FullSafetyGlassCoverageCA0421ReturnMethod = inputProperty.FullSafetyGlassCoverageCA0421ReturnMethod;
                    outputProperty.FullSafetyGlassCoverageCA0421IsSelected = inputProperty.FullSafetyGlassCoverageCA0421IsSelected;
                }

                // Step 24 Calculate Other Premium
                if (inputProperty.AutoPhysicalDamageOptionalOtherCoverageInputModels != null && inputProperty.AutoPhysicalDamageOptionalOtherCoverageInputModels.Count > 0)
                {
                    foreach (var OtherCoverage in inputProperty.AutoPhysicalDamageOptionalOtherCoverageInputModels)
                    {
                        if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                        {
                            OtherCoverage.OtherCoveragePremium = Convert.ToInt32(Math.Round(OtherCoverage.OtherCoverageRate * ((decimal)OtherCoverage.OtherCoverageLimit / 1000), 0, MidpointRounding.AwayFromZero));
                        }
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                        {
                            OtherCoverage.OtherCoveragePremium = Convert.ToInt32(Math.Round(OtherCoverage.OtherCoverageRate * ((decimal)OtherCoverage.OtherCoverageLimit / 100), 0, MidpointRounding.AwayFromZero));
                        }
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARGE")
                        {
                            OtherCoverage.OtherCoveragePremium = OtherCoverage.OtherCoveragePremium;
                            //Convert.ToInt32(autoDataAccess.GetOptionalCoveragePremium(policyHeader.State, policyHeader.PrimaryClass, inputProperty.AutoLiabilityInputModel.LineOfBusiness, "Other",OtherCoverage.OtherCoverageRatingBasis, policyHeader.PolicyEffectiveDate));
                        }
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                        {
                            OtherCoverage.OtherCoveragePremium = 0;
                        }
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "APD COMPREHENSIVE  PREMIUM")
                        {
                            OtherCoverage.OtherCoveragePremium = Convert.ToInt32(Math.Round(OtherCoverage.OtherCoverageRate
                                                               * ALOutputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium, 0, MidpointRounding.AwayFromZero));
                        }

                        outputProperty.OtherCoverageUnModifiedPremium = outputProperty.OtherCoverageUnModifiedPremium + OtherCoverage.OtherCoveragePremium;

                        outputProperty.AutoPhysicalDamageOptionalOtherCoverageOutputModels.Add(new AutoPhysicalDamageOptionalOtherCoverageOutputModel()
                        {
                            OtherCoverageID = OtherCoverage.OtherCoverageID,
                            OtherCoverageDedcutible = OtherCoverage.OtherCoverageDedcutible,
                            OtherCoverageDescription = OtherCoverage.OtherCoverageDescription,
                            OtherCoverageLimit = OtherCoverage.OtherCoverageLimit,
                            OtherCoverageRate = OtherCoverage.OtherCoverageRate,
                            OtherCoverageRatingBasis = OtherCoverage.OtherCoverageRatingBasis,
                            OtherCoverageReturnMethod = OtherCoverage.OtherCoverageReturnMethod,
                            OtherCoveragePremium = OtherCoverage.OtherCoveragePremium
                        });

                    }
                }

                // (Step 25 Calculate Optional Coverages Premium & Step 29 Calculate Non Modified Premium Merge in Same step34 ) Calculate Optional Coverages Premium

                ALOutputProperty.AutoPhysicalDamageOutputModel.NonModifiedPremium = outputProperty.GaragekeepersCA9937UnModifiedPremium
                                                                                                    + outputProperty.RentalReimbursementCA9923UnModifiedPremium
                                                                                                    + outputProperty.RentalReimbursementEmergencyServiceVehiclesBA0004UnModifiedPremium
                                                                                                    + outputProperty.FullSafetyGlassCoverageCA0421UnModifiedPremium
                                                                                                    + outputProperty.OtherCoverageUnModifiedPremium;

                this.logger.Info("AutoPhysicalDamageService.CalculateOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        public void CalculateMNAutomobileTheftPreventionSurcharge(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateMNAutomobileTheftPreventionSurcharge :: Started");

                if (policyHeader.State.ToUpper() == StateCodeConstant.MN)
                {
                    // Step 26.1 Get RATE
                    outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionSurchargeRate = 1;

                    // Step 26.3 Calculate Surcharge
                    if (policyHeader.TransactionType.ToUpper() == TransactionTypeConstant.NEWBUSINESS || policyHeader.TransactionType.ToUpper() == TransactionTypeConstant.RENEWAL)
                    {
                        outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionCharge = outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionSurchargeRatingExposure
                                                                                                       * outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionSurchargeRate;
                    }
                    else if (policyHeader.TransactionType.ToUpper() == TransactionTypeConstant.ENDORSEMENT && policyHeader.TransactionEffectiveDate == policyHeader.PolicyEffectiveDate)
                    {
                        outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionCharge = 0;
                    }
                    else if (policyHeader.TransactionType.ToUpper() == "CANCELLATION" && policyHeader.TransactionEffectiveDate == policyHeader.PolicyEffectiveDate)
                    {
                        outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionCharge = outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionSurchargeRatingExposure
                                                                                                      * outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionSurchargeRate;
                    }

                    // rounding
                    outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionCharge = Math.Round(outputProperty.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionCharge, 2, MidpointRounding.AwayFromZero);
                }

                this.logger.Info("AutoPhysicalDamageService.CalculateMNAutomobileTheftPreventionSurcharge :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateMNAutomobileTheftPreventionSurcharge :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        public void CalculateMNFireSafetySurcharge(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateMNFireSafetySurcharge :: Started");

                if (policyHeader.State.ToUpper() == StateCodeConstant.MN)
                {
                    // Step 27.1 Get Rate
                    outputProperty.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeRate = autoDataAccess.GetSurchargeRate(policyHeader.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "MN Fire Safety Surcharge", "n/a", "n/a", "n/a", "n/a", policyHeader.PolicyEffectiveDate);

                    // Step 27.3 
                    outputProperty.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeRatingExposure = outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium;

                    // Step Calculate MN Fire Safety Surcharge
                    outputProperty.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeCharge = (outputProperty.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeRate / 100)
                                                                                               * outputProperty.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeRatingExposure;

                    // Rounding 
                    outputProperty.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeCharge = Math.Round(outputProperty.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeCharge, 2, MidpointRounding.AwayFromZero);
                }

                this.logger.Info("AutoPhysicalDamageService.CalculateMNFireSafetySurcharge :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateMNFireSafetySurcharge :: Exception :: " + ex.Message, ex);
                throw;
            }


        }

        public void CalculateBasePremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateBasePremium :: Started");

                // Step 28 Calculate Base Premium
                outputProperty.AutoPhysicalDamageOutputModel.BasePremium = (outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedCollisionPremium
                                                                    + outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium
                                                                    + outputProperty.AutoPhysicalDamageOutputModel.TotalUnModifiedSpecCauseofLossPremium);

                this.logger.Info("AutoPhysicalDamageService.CalculateBasePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateBasePremium :: Exception :: " + ex.Message, ex);
                throw;
            }


        }

        public void CalculateManualPremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateManualPremium :: Started");

                // Step 30 Calculate Manual Premium

                outputProperty.AutoPhysicalDamageOutputModel.ManualPremium = outputProperty.AutoPhysicalDamageOutputModel.BasePremium
                                                                           + outputProperty.AutoPhysicalDamageOutputModel.NonModifiedPremium;

                // Step 30.3 Apply Minimum Premium rules
                if (outputProperty.AutoPhysicalDamageOutputModel.ManualPremium < outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium)
                {
                    outputProperty.AutoPhysicalDamageOutputModel.ManualPremium = outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium;
                }


                this.logger.Info("AutoPhysicalDamageService.CalculateManualPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateManualPremium :: Exception :: " + ex.Message, ex);
                throw;
            }


        }

        public void CalculateTierPremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateTierPremium :: Started");

                string tierPlan = model.RaterInputFacadeModel.PricingInputModel.TierPlan;

                // Step 31.4 Get Tier Factor
                outputProperty.AutoPhysicalDamageOutputModel.TierRate = autoDataAccess.GetTierFactor(policyHeader.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, tierPlan, policyHeader.PolicyEffectiveDate);

                //Step 31 Calculate Tier Premium
                outputProperty.AutoPhysicalDamageOutputModel.TierPremium = Convert.ToInt32(Math.Round(((outputProperty.AutoPhysicalDamageOutputModel.ManualPremium
                                                                         - outputProperty.AutoPhysicalDamageOutputModel.NonModifiedPremium)
                                                                         * outputProperty.AutoPhysicalDamageOutputModel.TierRate)
                                                                         + outputProperty.AutoPhysicalDamageOutputModel.NonModifiedPremium, 0, MidpointRounding.AwayFromZero));


                // Step 31.6 Apply Minimum Premium rules
                if (outputProperty.AutoPhysicalDamageOutputModel.TierPremium < outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium)
                {
                    outputProperty.AutoPhysicalDamageOutputModel.TierPremium = outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium;
                }

                this.logger.Info("AutoPhysicalDamageService.CalculateTierPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateTierPremium :: Exception :: " + ex.Message, ex);
                throw;
            }


        }

        public void CalculateIRPMPremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateIRPMPremium :: Started");

                // Step 32.3 Get IRPM Factor(user entry)

                // Step 32 Calculate IRPM Premium
                outputProperty.AutoPhysicalDamageOutputModel.IRPMPremium = Convert.ToInt32(Math.Round(((outputProperty.AutoPhysicalDamageOutputModel.TierPremium
                                                                         - outputProperty.AutoPhysicalDamageOutputModel.NonModifiedPremium)
                                                                         * inputProperty.AutoPhysicalDamageInputModel.IRPMRate)
                                                                         + outputProperty.AutoPhysicalDamageOutputModel.NonModifiedPremium, 0, MidpointRounding.AwayFromZero));

                // Step 32.5 Apply Minimum Premium rules
                if (outputProperty.AutoPhysicalDamageOutputModel.IRPMPremium < outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium)
                {
                    outputProperty.AutoPhysicalDamageOutputModel.IRPMPremium = outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium;
                }

                this.logger.Info("AutoPhysicalDamageService.CalculateIRPMPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateIRPMPremium :: Exception :: " + ex.Message, ex);
                throw;
            }


        }

        public void CalculateOtherModPremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateOtherModPremium :: Started");

                // Step 33 Get Other Mod Factor(user entry)

                // Step 33 Calculate Other Mod Premium
                outputProperty.AutoPhysicalDamageOutputModel.OtherModPremium = Convert.ToInt32(Math.Round(((outputProperty.AutoPhysicalDamageOutputModel.IRPMPremium
                                                                             - outputProperty.AutoPhysicalDamageOutputModel.NonModifiedPremium)
                                                                             * inputProperty.AutoPhysicalDamageInputModel.OtherModRate)
                                                                             + outputProperty.AutoPhysicalDamageOutputModel.NonModifiedPremium, 0, MidpointRounding.AwayFromZero));

                outputProperty.AutoPhysicalDamageOutputModel.OtherModRate = inputProperty.AutoPhysicalDamageInputModel.OtherModRate;

                // Step  33.6 Apply Minimum Premium rules
                if (outputProperty.AutoPhysicalDamageOutputModel.OtherModPremium < outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium)
                {
                    outputProperty.AutoPhysicalDamageOutputModel.OtherModPremium = outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium;
                }

                this.logger.Info("AutoPhysicalDamageService.CalculateOtherModPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateOtherModPremium :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        public void CalculateTerrorismPremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateTerrorismPremium :: Started");

                // Step 34 Calculate Terrorism Premium
                outputProperty.AutoPhysicalDamageOutputModel.TerrorismPremium = Convert.ToInt32(Math.Round(outputProperty.AutoPhysicalDamageOutputModel.OtherModPremium
                                                                             * outputProperty.AutoPhysicalDamageOutputModel.TerrorismRate, 0, MidpointRounding.AwayFromZero));

                this.logger.Info("AutoPhysicalDamageService.CalculateTerrorismPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateTerrorismPremium :: Exception :: " + ex.Message, ex);
                throw;
            }


        }

        public void CalculateFinalPremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this.logger.Info("AutoPhysicalDamageService.CalculateFinalPremium :: Started");

                // Step 35 Calculate Final Premium
                outputProperty.AutoPhysicalDamageOutputModel.APDModifiedFinalPremium = outputProperty.AutoPhysicalDamageOutputModel.OtherModPremium
                                                                                     + outputProperty.AutoPhysicalDamageOutputModel.TerrorismPremium;


                // Step 35.3 Calculate Final Premium
                if (outputProperty.AutoPhysicalDamageOutputModel.APDModifiedFinalPremium < outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium)
                {
                    outputProperty.AutoPhysicalDamageOutputModel.APDModifiedFinalPremium = outputProperty.AutoPhysicalDamageOutputModel.MinimumPremium;
                }

                this.logger.Info("AutoPhysicalDamageService.CalculateFinalPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("AutoPhysicalDamageService.CalculateFinalPremium :: Exception :: " + ex.Message, ex);
                throw;
            }


        }
    }
}