﻿using DataAccess;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Output;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace RaterAutoLiability
{
    public class AutoScheduleRatingService
    {
        private AutoDataAccess autoDataAccess { get; set; }
        readonly ILoggingManager logger;
        readonly IConfiguration configuration;

        public AutoScheduleRatingService(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.autoDataAccess = new AutoDataAccess(this.configuration, this.logger);
        }

        /// <summary>
        /// CalculateScheduleRating : calculate schedule rating per vehicle for Auto.
        /// </summary>
        /// <param name="model"></param>

        public void CalculateScheduleRating(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;

            if (model.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            if (outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount == 0 && inputProperty.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() != "HNO ONLY")
            {
                ///TODO
                throw new Exception("outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount cannot be zero!");
            }


            if (inputProperty.AutoScheduleVehiclesDetailsInputModel != null && inputProperty.AutoScheduleVehiclesDetailsInputModel.Count > 0)
            {
                List<AutoSchedulePervehiclePremiumDetailsOutputModel> autoSchedulePervehiclePremiumDetailsOutputModels = new List<AutoSchedulePervehiclePremiumDetailsOutputModel>();
                foreach (var schedulePerVehicleInput in inputProperty.AutoScheduleVehiclesDetailsInputModel)
                {
                    AutoSchedulePervehiclePremiumDetailsOutputModel schedulePerVehicleOutput = new AutoSchedulePervehiclePremiumDetailsOutputModel();
                    if (schedulePerVehicleInput.RatingGroup.ToUpper() != "TRAILERS")
                    {
                        // Step - 9
                        //UMAndUIMPremiumpervehicle = ROUND (((UM Premium + UIM Premium) / Total Vehicles With out Trailers)) * Population Factor * Tier Factor * IRPM Factor)	
                        schedulePerVehicleOutput.UMUIMPremiumPerVehicle = Convert.ToInt32(Math.Round((((outputProperty.AutoLiabilityOutputModel.UninsuredUnModifiedPremium
                                                                                                      + outputProperty.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium)
                                                                                                      / outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount)
                                                                                                      * outputProperty.AutoLiabilityOutputModel.PopulationRate
                                                                                                      * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                                      * inputProperty.AutoLiabilityInputModel.IRPMRate), 0, MidpointRounding.AwayFromZero));
                        // Step - 10
                        //PIPPremiumpervehicle = ROUND((PIP Premium / Total Vehicles With out Trailers) * Population Factor * Tier Factor * IRPM Factor)	
                        schedulePerVehicleOutput.PIPPremiumPerVehicle = Convert.ToInt32(Math.Round(((outputProperty.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium
                                                                                                    / outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount)
                                                                                                    * outputProperty.AutoLiabilityOutputModel.PopulationRate
                                                                                                    * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                                    * inputProperty.AutoLiabilityInputModel.IRPMRate), 0, MidpointRounding.AwayFromZero));
                        // Step - 11
                        //MedPayPremiumpervehicle = ROUND((Med Pay Premium / Total Vehicles With out Trailers) * Population Factor * Tier Factor * IRPM Factor)	
                        schedulePerVehicleOutput.MedPayPremiumPerVehicle = Convert.ToInt32(Math.Round(((outputProperty.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium
                                                                                                      / outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount)
                                                                                                      * outputProperty.AutoLiabilityOutputModel.PopulationRate
                                                                                                      * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                                      * inputProperty.AutoLiabilityInputModel.IRPMRate), 0, MidpointRounding.AwayFromZero));
                        // Step -12
                        //OtherPremiumpervehicle = UM/UIM Premium per vehicle + PIP Premium per vehicle + Med Pay Premium per vehicle 
                        schedulePerVehicleOutput.OtherPremiumPerVehicle = schedulePerVehicleOutput.UMUIMPremiumPerVehicle
                                                                                      + schedulePerVehicleOutput.PIPPremiumPerVehicle
                                                                                      + schedulePerVehicleOutput.MedPayPremiumPerVehicle;

                        // step 13 finalALPremium coming from parameters (Basis on State)

                        //Step -14
                        //LiabilityPremiumpervehicle = ROUND ((Liability Premium / Total Vehicles With out Trailers)	* Population Factor * Tier Factor * IRPM Factor)	
                        schedulePerVehicleOutput.LiabilityPremiumPerVehicle = Convert.ToInt32(Math.Round(((outputProperty.AutoLiabilityOutputModel.LiabilityUnModifiedPremium
                                                                                                          / outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount)
                                                                                                          * outputProperty.AutoLiabilityOutputModel.PopulationRate
                                                                                                          * outputProperty.AutoLiabilityOutputModel.TierRate
                                                                                                          * inputProperty.AutoLiabilityInputModel.IRPMRate), 0, MidpointRounding.AwayFromZero));
                    }

                    schedulePerVehicleOutput.Vehicle = schedulePerVehicleInput.Vehicle;
                    schedulePerVehicleOutput.RatingGroup = schedulePerVehicleInput.RatingGroup;

                    if (inputProperty.HasAutoPhysicalDamage && inputProperty.AutoPhysicalDamageInputModel != null)
                    {
                        //Auto APD calculation
                        CalculateAPDScheduleRating(model, schedulePerVehicleInput, schedulePerVehicleOutput);
                    }

                    autoSchedulePervehiclePremiumDetailsOutputModels.Add(schedulePerVehicleOutput);
                }

                if (inputProperty.AutoScheduleVehiclesDetailsInputModel.Where(x => x.RatingGroup.ToUpper() != "TRAILERS").ToList().Count > 0)
                {
                    outputProperty.AutoScheduleRatingOutputModel = new AutoScheduleVehiclesDetailsOutputModel();
                    var firstWithoutTrailerVehicle = autoSchedulePervehiclePremiumDetailsOutputModels.First(x => x.RatingGroup.ToUpper() != "TRAILERS");
                    // Step -15
                    //TotalLiabilityPremiumpervehicle = (Liability Premium per vehicle + Other Premium per vehicle) * Total Vehicles With out Trailers
                    outputProperty.AutoScheduleRatingOutputModel.TotalSchedulePremium1 = (firstWithoutTrailerVehicle.LiabilityPremiumPerVehicle
                                                                                        + firstWithoutTrailerVehicle.OtherPremiumPerVehicle)
                                                                                        * outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount;

                    // Step -16
                    //Difference_A = Final AL Premium - Total  Liability Premium per vehicle -1
                    outputProperty.AutoScheduleRatingOutputModel.Difference1 = outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium
                                                                              - outputProperty.AutoScheduleRatingOutputModel.TotalSchedulePremium1;

                    // Step - 17
                    //LiabilityPremiumpervehicle = Liability Premium per vehicle + ROUND( Difference / Total Vehicles With out Trailers)

                    int LiabilityPremiumPerVehicle2 = Convert.ToInt32(firstWithoutTrailerVehicle.LiabilityPremiumPerVehicle
                                                      + Math.Round((decimal)outputProperty.AutoScheduleRatingOutputModel.Difference1
                                                      / outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount, 0, MidpointRounding.AwayFromZero));

                    autoSchedulePervehiclePremiumDetailsOutputModels.Where(x => x.RatingGroup.ToUpper() != "TRAILERS").ToList().ForEach(x => x.LiabilityPremiumPerVehicle = LiabilityPremiumPerVehicle2);

                    firstWithoutTrailerVehicle = autoSchedulePervehiclePremiumDetailsOutputModels.First(x => x.RatingGroup.ToUpper() != "TRAILERS");

                    // Step -18
                    //TotalLiabilityPremiumpervehicle = (Liability Premium per vehicle - 2 + Other Premium per vehicle) * Total Vehicles With out Trailers)

                    outputProperty.AutoScheduleRatingOutputModel.TotalSchedulePremium2 = (firstWithoutTrailerVehicle.LiabilityPremiumPerVehicle
                                                                                        + firstWithoutTrailerVehicle.OtherPremiumPerVehicle)
                                                                                        * outputProperty.AutoLiabilityOutputModel.TotalVehiclesWithoutTrailersCount;

                    // Step -19
                    //Difference_B = Final AL Premium	- Total Liability Premium per vehicle - 2
                    outputProperty.AutoScheduleRatingOutputModel.Difference2 = outputProperty.AutoLiabilityOutputModel.ALModifiedFinalPremium
                                                                              - outputProperty.AutoScheduleRatingOutputModel.TotalSchedulePremium2;

                    // Step -20
                    //FinalLiabilityPremiumpervehicle = Liability Premium per vehicle -2 + Difference
                    //firstWithoutTrailerVehicle.LiabilityPremiumPerVehicle = autoSchedulePervehiclePremiumDetailsOutputModels[0].LiabilityPremiumPerVehicle + outputProperty.AutoScheduleRatingOutputModel.Difference2;

                    firstWithoutTrailerVehicle.LiabilityPremiumPerVehicle = autoSchedulePervehiclePremiumDetailsOutputModels.Where(x=>x.RatingGroup.ToUpper()!= "TRAILERS").FirstOrDefault().LiabilityPremiumPerVehicle + outputProperty.AutoScheduleRatingOutputModel.Difference2;

                    // Step -21
                    //Calculate Final AL Liability Premium per vehicle : Liability Premium per vehicle- 2 + Other Premium per vehicle

                    autoSchedulePervehiclePremiumDetailsOutputModels.Where(x => x.RatingGroup.ToUpper() != "TRAILERS").ToList().ForEach(x => x.FinalLiabilityPremiumPerVehicle = (x.LiabilityPremiumPerVehicle + x.OtherPremiumPerVehicle));
                }

                outputProperty.AutoScheduleRatingOutputModel.AutoSchedulePerVehiclePremiumDetails = autoSchedulePervehiclePremiumDetailsOutputModels;

                //Step 2 Calculate Total Vehicle Premium with AL & APD Per Vehicle
                outputProperty.AutoScheduleRatingOutputModel.AutoSchedulePerVehiclePremiumDetails.ForEach(x => x.TotalVehiclePremiumwithALAndAPD = (x.APDPremiumPerVehicle + x.OtherPremiumPerVehicle + x.LiabilityPremiumPerVehicle));

            }
        }

        private void CalculateAPDScheduleRating(RaterFacadeModel model, AutoScheduleVehiclesDetailsInputModel schedulePerVehicleInput, AutoSchedulePervehiclePremiumDetailsOutputModel schedulePerVehicleOutput)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;
            if (policyHeader.State == StateCodeConstant.NY)
            {
                inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            decimal compAPDPremiumpervehicle = 0;
            decimal collAPDPremiumpervehicle = 0;
            decimal SpecifiedCauseofLossAPDPremiumpervehicle = 0;

            if (schedulePerVehicleInput.CompDeductible != 0)
            {
                decimal CompBaseRate = 0;

                // Step 1.2 Get Comp Base Rate
                // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                //DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Comprehensive", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                //if (dtAutorate != null)
                //{
                //    CompBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                //}
                if (inputProperty.AutoPhysicalDamageInputModel.CompBaseRate < 0)
                {
                    DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Comprehensive", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                    if (dtAutorate != null)
                    {
                        CompBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                    }
                }
                else
                {
                    CompBaseRate = inputProperty.AutoPhysicalDamageInputModel.CompBaseRate;
                }

                //Step 1.3 Get Comp Deductible Rate
                decimal CompDeductibleRate = autoDataAccess.GetDeductibleFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, null, schedulePerVehicleInput.CompDeductible, "Comprehensive", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                //Step 1.4 Get Comp Valuation Rate
                decimal CompValuationRate = autoDataAccess.GetValuationFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, schedulePerVehicleInput.Valuation, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Calculate compAPDPremiumpervehicle
                compAPDPremiumpervehicle = ((decimal)schedulePerVehicleInput.OCN / 100) * CompBaseRate * CompDeductibleRate * CompValuationRate;

            }

            if (schedulePerVehicleInput.CollDeductible != 0)
            {
                decimal CollBaseRate = 0;

                //Step 1.6 Get Coll Base Rate
                // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                //DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Collision", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                //if (dtAutorate != null)
                //{
                //    CollBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                //}
                if (inputProperty.AutoPhysicalDamageInputModel.CollisionBaseRate < 0)
                {
                    DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Collision", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                    if (dtAutorate != null)
                    {
                        CollBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                    }
                }
                else
                {
                    CollBaseRate = inputProperty.AutoPhysicalDamageInputModel.CollisionBaseRate;
                }

                //Step 1.7 Get Coll Deductible Rate<
                decimal CollDeductibleRate = autoDataAccess.GetDeductibleFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, null, schedulePerVehicleInput.CollDeductible, "Collision", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                //Step 1.8 Get Coll Valuation Rate
                decimal CollValuationRate = autoDataAccess.GetValuationFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, schedulePerVehicleInput.Valuation, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Calculate collAPDPremiumpervehicle
                collAPDPremiumpervehicle = ((decimal)schedulePerVehicleInput.OCN / 100) * CollBaseRate * CollDeductibleRate * CollValuationRate;
            }

            if (schedulePerVehicleInput.SpecifiedCauseofLossDeductible != 0)
            {
                decimal SpecifiedCauseofLossBaseRate = 0;
                //Step 1.10 Get Spec Cause of Loss Base Rate
                // Comment due BA issues(If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation)
                //DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Specified Cause of Loss", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                //if (dtAutorate != null)
                //{
                //    SpecifiedCauseofLossBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                //}
                if (inputProperty.AutoPhysicalDamageInputModel.SpecCauseofLossBaseRate < 0)
                {
                    DataTable dtAutorate = autoDataAccess.GetAutoBaseRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, "Specified Cause of Loss", model.RaterInputFacadeModel.PolicyHeaderModel.LocationType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                    if (dtAutorate != null)
                    {
                        SpecifiedCauseofLossBaseRate = Convert.ToDecimal(dtAutorate.Rows[0]["BaseRate"]);
                    }
                }
                else
                {
                    SpecifiedCauseofLossBaseRate = inputProperty.AutoPhysicalDamageInputModel.SpecCauseofLossBaseRate;
                }

                //Step 1.11 Get Spec Cause of Loss Deductible Rate
                decimal SpecifiedCauseofLossDeductibleRate = autoDataAccess.GetDeductibleFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, null, schedulePerVehicleInput.SpecifiedCauseofLossDeductible, "Specified Cause of Loss", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                //step 1.12 Get Spec Cause of Loss Valuation Rate
                decimal SpecifiedCauseofLossValuationRate = autoDataAccess.GetValuationFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.AutoPhysicalDamageInputModel.LineOfBusiness, schedulePerVehicleInput.Valuation, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Calculate collAPDPremiumpervehicle
                SpecifiedCauseofLossAPDPremiumpervehicle = ((decimal)schedulePerVehicleInput.OCN / 100) * SpecifiedCauseofLossBaseRate * SpecifiedCauseofLossDeductibleRate * SpecifiedCauseofLossValuationRate;
            }

            //Step 1 Calculate APD Premium Per Vehicle

            schedulePerVehicleOutput.APDPremiumPerVehicle = Convert.ToInt32(Math.Round(((compAPDPremiumpervehicle + collAPDPremiumpervehicle + SpecifiedCauseofLossAPDPremiumpervehicle)
                                                           * inputProperty.AutoPhysicalDamageInputModel.IRPMRate * outputProperty.AutoPhysicalDamageOutputModel.PopulationRate), 0, MidpointRounding.AwayFromZero));


            //Step 2 Calculate Total Vehicle Premium with AL & APD Per Vehicle
            //Total Vehicle Premium with AL & APD : Calculation of this step is done in above method (CalculateScheduleRating)

        }
    }
}
