﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaterAutoLiability
{
    public class AutoServiceWrapper
    {
        /// <summary>
        /// Logger.
        /// </summary>
        protected ILoggingManager logger { get; private set; }
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="AutoALCwService"/> class.
        /// </summary>
        public AutoServiceWrapper(IConfiguration configuration, ILoggingManager logger)
        {
            this.logger = logger;
            this.configuration = configuration;
        }

        /// <summary>
        /// ExecuteAutoLiabilityEngine : It's includes pre validation ,premium calculation , post validation.
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        /// <returns>ValidationResult</returns>
        public FluentValidation.Results.ValidationResult ExecuteAutoLiabilityEngine(RaterFacadeModel raterFacadeModel)
        {
            //Create service object
            IAutoALService service;
            if (raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
            {
                service= new AutoALNYService(this.configuration, this.logger);
            }
            else
            {
                service  = new AutoALCwService(this.configuration, this.logger);
            }

            // Prevalidate   //TODO : Open this prevalidations.
            var preValidateResults = service.PreValidate(raterFacadeModel);

            if (!preValidateResults.IsValid) return preValidateResults;

            // Since input pre validation are success, calculate premium
            service.Calculate(raterFacadeModel);

            if (raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
            {
                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.HasAutoPhysicalDamage)
                {
                    var apdService = new AutoAPDService(this.configuration, this.logger);
                    // Prevalidate   //TODO : Open this prevalidations.
                    var apdPreValidateResults = apdService.PreValidate(raterFacadeModel);

                    if (!apdPreValidateResults.IsValid) return apdPreValidateResults;

                    // Since input pre validation are success, calculate premium
                    apdService.Calculate(raterFacadeModel);

                    //Post validate
                    var apdPostValidateResults = apdService.PostValidate(raterFacadeModel);
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel != null)
                {
                    AutoScheduleRatingService autoScheduleRatingService = new AutoScheduleRatingService(this.configuration, this.logger);
                    autoScheduleRatingService.CalculateScheduleRating(raterFacadeModel);
                }
            }
            else
            {
                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.HasAutoPhysicalDamage)
                {
                    var apdService = new AutoAPDService(this.configuration, this.logger);
                    //// Prevalidate   //TODO : Open this prevalidations.
                    var apdPreValidateResults = apdService.PreValidate(raterFacadeModel);

                    if (!apdPreValidateResults.IsValid) return apdPreValidateResults;

                    // Since input pre validation are success, calculate premium
                    apdService.Calculate(raterFacadeModel);

                    //Post validate
                    var apdPostValidateResults = apdService.PostValidate(raterFacadeModel);
                }

                if (raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel != null)
                {
                    AutoScheduleRatingService autoScheduleRatingService = new AutoScheduleRatingService(this.configuration, this.logger);
                    autoScheduleRatingService.CalculateScheduleRating(raterFacadeModel);
                }
            }
            

            //Post validate
            var postValidateResults = service.PostValidate(raterFacadeModel);

            return postValidateResults;
        }
    }
}
