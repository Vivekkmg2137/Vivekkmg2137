﻿using Models;
using Models.ApiModels;

namespace RaterAutoLiability
{
    public interface IAutoALService
    {
        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model);

      
        void Calculate(RaterFacadeModel model);

        void CalculateLiablityPremium(RaterFacadeModel model);

        void CalculatePIPPremium(RaterFacadeModel model);

        void CalculateBasicFPBPremium(RaterFacadeModel model);

        void CalculateMEDPremium(RaterFacadeModel model);

        void CalculateUMPremium(RaterFacadeModel model);

        void CalculateUMBIPDPremium(RaterFacadeModel model);

        void CalculateUIMPremium(RaterFacadeModel model);

        void CalculateHiredAndNonOwenedPremium(RaterFacadeModel model);

        void CalculateOptionalCoveragePremium(RaterFacadeModel model);

        void CalculateBasePremium(RaterFacadeModel model);

        void CalculateManualPremium(RaterFacadeModel model);

        void CalculateTierPremium(RaterFacadeModel model);

        void CalculateIRPMPremium(RaterFacadeModel model);

        void CalculateOtherModPremium(RaterFacadeModel model);

        void CalculateTerrorismPremium(RaterFacadeModel model);

        void CalculateMIMCCAAssessementCharge(RaterFacadeModel model);

        void CalculateNCAutoLossRecoupmentSurcharge(RaterFacadeModel model);

        void CalculateFinalPremiumForNonMIAndNC(RaterFacadeModel model);

        void CalculateFinalPremiumForMI(RaterFacadeModel model);

        void CalculateFinalPremiumForNC(RaterFacadeModel model);

        void CalculateLiabilityModifiedPremium(RaterFacadeModel model);

        void CalculateMedPeyModifiedPremium(RaterFacadeModel model);

        void CalculateUMAndBIPDModifiedPremium(RaterFacadeModel model);

        void CalculateUIMModifiedPremium(RaterFacadeModel model);

        void CalculatePIPAndBasicFPBModifiedPremium(RaterFacadeModel model);

        void CalculateHiredANDNonOwnedModifiedPremium(RaterFacadeModel model);

    }
}