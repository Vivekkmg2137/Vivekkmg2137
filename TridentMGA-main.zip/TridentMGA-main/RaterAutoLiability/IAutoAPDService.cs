﻿using Models;
using Models.ApiModels;

namespace RaterAutoLiability
{
    public interface IAutoAPDService
    {
        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model);


        void Calculate(RaterFacadeModel model);

        void CalculateCollCompAndSpecifiedCasueofLossPremium(RaterFacadeModel model);

        void CalculateOptionalCoveragePremium(RaterFacadeModel model);

        void CalculateMNAutomobileTheftPreventionSurcharge(RaterFacadeModel model);

        void CalculateMNFireSafetySurcharge(RaterFacadeModel model);

        void CalculateBasePremium(RaterFacadeModel model);

        void CalculateManualPremium(RaterFacadeModel model);

        void CalculateTierPremium(RaterFacadeModel model);

        void CalculateIRPMPremium(RaterFacadeModel model);

        void CalculateOtherModPremium(RaterFacadeModel model);

        void CalculateTerrorismPremium(RaterFacadeModel model);

        void CalculateFinalPremium(RaterFacadeModel model);
    }
}