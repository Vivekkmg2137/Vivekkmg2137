﻿using DataAccess;
using DomainRules;
using Logging;
using Models.ViewModels;
using System;
using System.Collections.Generic;
using Validations;

namespace RaterAutoPhysicalDamage
{
   public class AutoPhysicalDamageCwService:IAutoPhysicalDamageService
    {
        private AutoPhysicalDamageDataAccess AutoPhysicalDamage;
        private ILoggingManager Logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="AutoPhysicalDamageCwService"/> class.
        /// </summary>
        /// <param name="logger">ILoggingManager.</param>
        public AutoPhysicalDamageCwService(ILoggingManager logger)
        {
            this.Logger = logger;
            this.AutoPhysicalDamage = new AutoPhysicalDamageDataAccess(logger);
        }

        /// <summary>
        /// ExecuteDomainRules : It will apply Domain rules.
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        /// <summary>
        /// ExecuteDomainRules : It will apply PreValidate rules.
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new AutoPhysicalDamagePreValidator(this.Logger);
                var results = validator.Validate(model);

                return results;
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message, ex);

                throw ex;
            }
        }

        public virtual FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new AutoPhysicalDamagePostValidator(this.Logger);
                var results = validator.Validate(model);
                return results;
            }
            catch (Exception ex)
            {
                this.Logger.Error(ex.Message, ex);
                throw;
            }
        }


        /// <summary>
        /// CalculatePremium : It will Calculate AutoPhysicalDamage premium.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>

        public virtual void Calculate(RaterFacadeModel model)
        {

        }
    }
}
