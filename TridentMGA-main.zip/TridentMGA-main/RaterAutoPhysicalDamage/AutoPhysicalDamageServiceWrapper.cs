﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RaterAutoPhysicalDamage
{
    public class AutoPhysicalDamageServiceWrapper
    {

    }
}
