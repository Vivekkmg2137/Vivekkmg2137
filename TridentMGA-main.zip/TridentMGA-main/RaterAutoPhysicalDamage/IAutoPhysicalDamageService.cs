﻿using Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaterAutoPhysicalDamage
{
    public interface IAutoPhysicalDamageService
    {

        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);
        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);
        FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model);
        void Calculate(RaterFacadeModel model);
    }
}
