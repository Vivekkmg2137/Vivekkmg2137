﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RaterCrime
{
    public class CrimeCWService : ICrimeCWService
    {
    }
}
