﻿using System;

namespace RaterCrime
{
    public class CrimeWrpper
    {
    }
}
