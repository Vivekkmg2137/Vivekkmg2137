﻿using Models;
using Models.ApiModels;

namespace RaterCrime
{
    /// <summary>
    /// ICrime CW Service
    /// </summary>
    public interface ICrimeCWService
    {
    }
}
