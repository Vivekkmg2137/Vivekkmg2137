﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Output;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Validations;

namespace RaterDO
{
    /// <summary>
    /// DirectorsAndOfficersService
    /// </summary>
    public class DirectorsAndOfficersService : IDirectorsAndOfficersService
    {
        /// <summary>
        /// DataAcess Object
        /// </summary>
        private DirectorsAndOfficersDataAccess dataAccess { get; set; }

        /// <summary>
        /// Logger Object
        /// </summary>
        protected ILoggingManager logger { get; private set; }

        /// <summary>
        /// Configuration Object
        /// </summary>
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// DirectorsAndOfficersService
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public DirectorsAndOfficersService(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.dataAccess = new DirectorsAndOfficersDataAccess(configuration, logger);
        }

        // lossExperienceFactor
        decimal lossExperienceFactor = 1.000M;

        // LOB MinimumPremium
        decimal lobMinimumPremium = 0;

        /// <summary>
        /// ExecuteDomainRules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            this.logger.Info("DirectorsAndOfficialsCWService.ExecuteDomainRules :: Starting");
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            this.logger.Info("DirectorsAndOfficialsCWService.ExecuteDomainRules :: Completed");

            return validationResult;
        }

        /// <summary>
        /// PreValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("DirectorsAndOfficersService.PreValidate :: Started");

                var validator = new DirectorsAndOfficersPreValidator(this.configuration, this.logger);
                var results = validator.Validate(model);

                this.logger.Info("DirectorsAndOfficersService.PreValidate :: Completed");

                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error("DirectorsAndOfficersService.PreValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// PostValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("DirectorsAndOfficersService.PostValidate :: Started");

                var validator = new DirectorsAndOfficersPostValidator(this.configuration, this.logger);
                var results = validator.Validate(model);

                this.logger.Info("DirectorsAndOfficersService.PostValidate :: Completed");

                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error("DirectorsAndOfficersService.PostValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region Directors And Officers

        /// <summary>
        /// Calculate
        /// </summary>
        /// <param name="model"></param>
        public void Calculate(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("DirectorsAndOfficers.Calculate :: Started");

                #region Step 1-16 InitialRates calculation

                CalculateInitialRates(model);

                #endregion

                #region Base Premium

                CalculateBasePremium(model);

                #endregion

                #region Optional Coverage

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel != null)
                {
                    CalculateOptionalCoverage(model);
                }

                #endregion

                #region Other Premiums

                CalculateOtherPremiums(model);

                #endregion

                this.logger.Info("DirectorsAndOfficers.Calculate :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("DirectorsAndOfficers.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateInitialRates
        /// </summary>
        /// <param name="model"></param>
        private void CalculateInitialRates(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("DirectorsAndOfficers.CalculateInitialRates :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers;
                var PolicyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                PolicyHeaderModel.State = PolicyHeaderModel.State.ToUpper();
                PolicyHeaderModel.PrimaryClass = PolicyHeaderModel.PrimaryClass.ToUpper();
                PolicyHeaderModel.TransactionType = PolicyHeaderModel.TransactionType.ToUpper();

                //step 10.1
                DataTable dataTableRatingBasis = this.dataAccess.GetRatingBasisParameter(PolicyHeaderModel.State,
                                                                                         PolicyHeaderModel.PrimaryClass,
                                                                                         inputModel.LineOfBusiness,
                                                                                         PolicyHeaderModel.PolicyEffectiveDate,
                                                                                         PolicyHeaderModel.PolicyExpirationDate);

                if (dataTableRatingBasis != null && dataTableRatingBasis.Rows.Count > 0 && dataTableRatingBasis.Rows[0] != null)
                {
                    if (dataTableRatingBasis.Rows[0]["RatingBasis"] != DBNull.Value)
                    {
                        outputModel.RatingBasis = Convert.ToString(dataTableRatingBasis.Rows[0]["RatingBasis"]);
                    }
                    if (dataTableRatingBasis.Rows[0]["RatingBasisParameter"] != DBNull.Value)
                    {
                        outputModel.RatingBasisParameter = Convert.ToInt32(dataTableRatingBasis.Rows[0]["RatingBasisParameter"]);
                    }
                }


                //step 11
                decimal yearFrac = this.YearFrac(inputModel.RetroDate,
                                                 PolicyHeaderModel.PolicyEffectiveDate);

                outputModel.RetroYear = (int)Math.Round(yearFrac, 0);

                this.logger.Info("DirectorsAndOfficers.CalculateInitialRates :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("DirectorsAndOfficers.CalculateInitialRates :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateBasePremium
        /// </summary>
        /// <param name="model"></param>
        public void CalculateBasePremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("DirectorsAndOfficers.CalculateBasePremium :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers;
                var PolicyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                #region Step 12.5 - Base Premium

                // Step  12.8  Get ExposureRate
                if (inputModel.ExposureRate < 0)
                {
                    outputModel.ExposureRate = this.dataAccess.GetProfLinesExposureRate(PolicyHeaderModel.State,
                                                                                        PolicyHeaderModel.PrimaryClass,
                                                                                        inputModel.LineOfBusiness,
                                                                                        PolicyHeaderModel.PolicyEffectiveDate,
                                                                                        PolicyHeaderModel.PolicyExpirationDate);
                }
                else
                {
                    outputModel.ExposureRate = inputModel.ExposureRate;
                }

                // step 12.9  Get EPInclusionExclusion Rate
                outputModel.EPInclusionExclusionRate = this.dataAccess.GetProfLinesEPInclExclRate(PolicyHeaderModel.State,
                                                                                                  inputModel.LineOfBusiness,
                                                                                                  "Excluded",
                                                                                                  null,
                                                                                                  PolicyHeaderModel.PolicyEffectiveDate,
                                                                                                  PolicyHeaderModel.PolicyExpirationDate);

                // 12.10 Get LiabilityLimit Rate
                if (inputModel.LiabilityLimitRate < 0)
                {
                    outputModel.LiabilityLimitRate = this.dataAccess.GetProfLinesLiabilityLimitRate(PolicyHeaderModel.State,
                                                                                                    inputModel.LineOfBusiness,
                                                                                                    inputModel.LiabilityLimit,
                                                                                                    PolicyHeaderModel.PolicyEffectiveDate,
                                                                                                    PolicyHeaderModel.PolicyExpirationDate);
                }
                else
                {
                    outputModel.LiabilityLimitRate = inputModel.LiabilityLimitRate;
                }

                // 12.11 Get AggregateLimit Rate
                outputModel.AggregateLimitRate = this.dataAccess.GetProfLinesAggregateLimitRate(PolicyHeaderModel.State,
                                                                                                inputModel.LineOfBusiness,
                                                                                                inputModel.LiabilityLimit,
                                                                                                inputModel.AggregateLimit,
                                                                                                PolicyHeaderModel.PolicyEffectiveDate,
                                                                                                PolicyHeaderModel.PolicyExpirationDate);

                // 12.12 and 12.13 Get Retention Rate
                outputModel.RetentionRate = this.dataAccess.GetProfLinesRetentionRate(PolicyHeaderModel.State,
                                                                                      inputModel.LineOfBusiness,
                                                                                      inputModel.Deductible_SIR,
                                                                                      inputModel.Retention,
                                                                                      PolicyHeaderModel.PolicyEffectiveDate,
                                                                                      PolicyHeaderModel.PolicyExpirationDate);

                // 12.14 Get Population Rate
                outputModel.PopulationRate = this.dataAccess.GetProfLinesPopulationRate(PolicyHeaderModel.State,
                                                                                        PolicyHeaderModel.PrimaryClass,
                                                                                        inputModel.LineOfBusiness,
                                                                                        PolicyHeaderModel.PopulationADA,
                                                                                        PolicyHeaderModel.PolicyEffectiveDate,
                                                                                        PolicyHeaderModel.PolicyExpirationDate);

                // 12.15 Get Location Rate
                outputModel.LocationRate = this.dataAccess.GetProfLinesLocationRate(PolicyHeaderModel.State,
                                                                                    inputModel.LineOfBusiness,
                                                                                    PolicyHeaderModel.LocationType,
                                                                                    PolicyHeaderModel.PolicyEffectiveDate,
                                                                                    PolicyHeaderModel.PolicyExpirationDate);

                // 12.16 Get Policy Type Rate
                outputModel.PolicyTypeRate = this.dataAccess.GetProfLinesPolicyTypeRate(PolicyHeaderModel.State,
                                                                                        inputModel.LineOfBusiness,
                                                                                        inputModel.PolicyType,
                                                                                        PolicyHeaderModel.PolicyEffectiveDate,
                                                                                        PolicyHeaderModel.PolicyExpirationDate);

                // 12.17 Get YearsInCM Rate
                outputModel.YearsInCMRate = this.dataAccess.GetProfLinesCMPolicyYearRate(PolicyHeaderModel.State,
                                                                                         inputModel.LineOfBusiness,
                                                                                         inputModel.YearsinCMProgram,
                                                                                         PolicyHeaderModel.PolicyEffectiveDate,
                                                                                         PolicyHeaderModel.PolicyExpirationDate);

                // 12.18 Get RetroDate Rate
                string stringRetroYear = string.Empty;
                stringRetroYear = outputModel.RetroYear.ToString();
                outputModel.RetroDateRate = this.dataAccess.GetProfLinesRetroDateRate(PolicyHeaderModel.State,
                                                                                      inputModel.LineOfBusiness,
                                                                                      stringRetroYear,
                                                                                      PolicyHeaderModel.PolicyEffectiveDate,
                                                                                      PolicyHeaderModel.PolicyExpirationDate);

                // 12.19 Get lossExperience Factor
                lossExperienceFactor = 1.000M;

                // step 12.5 Calculate Base Premium = (Step 12.6 / Step 12.7) * Step 12.8 * Step 12.9 * Step 12.10 * Step 12.11 * Step 12.12 *
                //                                     Step 12.13 * Step 12.14 * Step 12.15 * Step 12.16 * Step 12.17 * Step 12.18 * Step 12.19


                decimal basePremium = Convert.ToInt32((inputModel.Exposure
                                                     / outputModel.RatingBasisParameter)
                                                     * outputModel.ExposureRate
                                                     * outputModel.EPInclusionExclusionRate
                                                     * outputModel.LiabilityLimitRate
                                                     * outputModel.AggregateLimitRate
                                                     * outputModel.RetentionRate
                                                     * outputModel.PopulationRate
                                                     * outputModel.LocationRate
                                                     * outputModel.PolicyTypeRate
                                                     * outputModel.YearsInCMRate
                                                     * outputModel.RetroDateRate
                                                     * lossExperienceFactor);

                outputModel.BasePremium = Convert.ToInt32(Math.Round(basePremium, 0, MidpointRounding.AwayFromZero));

                #endregion`   

                this.logger.Info("DirectorsAndOfficers.CalculateBasePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("DirectorsAndOfficers.CalculateBasePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateOptionalCoverage
        /// </summary>
        /// <param name="model"></param>
        public void CalculateOptionalCoverage(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("DirectorsAndOfficers.CalculateOptionalCoverage :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers;
                var inputOptionalProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel;
                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel;
                var PolicyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                #region BA team removed this coverage
                //#region Step 13 Suppl.Extended Reporting Period  - User Entry 

                //outputOptionalProperty.SupplExtendedReportingPeriodIsSelected = inputOptionalProperty.SupplExtendedReportingPeriodIsSelected;
                //outputOptionalProperty.SupplExtendedReportingPeriodAggregateLimit = inputOptionalProperty.SupplExtendedReportingPeriodAggregateLimit;
                //outputOptionalProperty.SupplExtendedReportingPeriodDeductible = inputOptionalProperty.SupplExtendedReportingPeriodDeductible;
                //outputOptionalProperty.SupplExtendedReportingPeriodLimit = inputOptionalProperty.SupplExtendedReportingPeriodLimit;
                //outputOptionalProperty.SupplExtendedReportingPeriodModifiedPremium = inputOptionalProperty.SupplExtendedReportingPeriodModifiedPremium;
                //outputOptionalProperty.SupplExtendedReportingPeriodRate = inputOptionalProperty.SupplExtendedReportingPeriodRate;
                //outputOptionalProperty.SupplExtendedReportingPeriodRatingBasis = inputOptionalProperty.SupplExtendedReportingPeriodRatingBasis;
                //outputOptionalProperty.SupplExtendedReportingPeriodReturnMethod = inputOptionalProperty.SupplExtendedReportingPeriodReturnMethod;

                //#endregion
                #endregion

                #region Optional Coverage I - Other

                if (inputOptionalProperty.DirectorsAndOfficersOptionalOtherCoverageModel != null && inputOptionalProperty.DirectorsAndOfficersOptionalOtherCoverageModel.Count > 0)
                {
                    var otherCoverageOutputModelList = new List<DirectorsAndOfficersOptionalOtherCoverageOutputModel>();

                    foreach (var otherCoverage in inputOptionalProperty.DirectorsAndOfficersOptionalOtherCoverageModel)
                    {
                        DirectorsAndOfficersOptionalOtherCoverageOutputModel otherCoverageOutputModel = new DirectorsAndOfficersOptionalOtherCoverageOutputModel();

                        otherCoverageOutputModel.OtherCoverageID = otherCoverage.OtherCoverageID;
                        otherCoverageOutputModel.OtherCoverageDescription = otherCoverage.OtherCoverageDescription;
                        otherCoverageOutputModel.OtherCoverageLimit = otherCoverage.OtherCoverageLimit;
                        otherCoverageOutputModel.OtherCoverageAggregateLimit = otherCoverage.OtherCoverageAggregateLimit;
                        otherCoverageOutputModel.OtherCoverageRate = otherCoverage.OtherCoverageRate;
                        otherCoverageOutputModel.OtherCoverageDedcutible = otherCoverage.OtherCoverageDedcutible;
                        otherCoverageOutputModel.OtherCoverageReturnMethod = otherCoverage.OtherCoverageReturnMethod;
                        otherCoverageOutputModel.OtherCoverageRatingBasis = otherCoverage.OtherCoverageRatingBasis;
                        otherCoverageOutputModel.OtherCoverageModifiedPremium = otherCoverage.OtherCoverageModifiedPremium;
                        otherCoverageOutputModel.OtherCoverageUnmodifiedPremium = otherCoverage.OtherCoverageUnmodifiedPremium;
                        otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure = otherCoverage.OtherCoverageIncludedInExcessExposure;

                        //Step 14.4
                        //Other Coverage Rate				
                        //User Entry [Received as Input only if Rating Basis = 'per 100 of limit' OR 'per 1,000 of limit'
                        //if (otherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT"
                        //    || otherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                        //{
                        //    otherCoverage.OtherCoverageRate = otherCoverage.OtherCoverageRate;
                        //}


                        //Step 14.5	
                        //Other Premium	Other Coverage UnModified
                        //IF Rating Basis = "per 1,000 of limit" THEN Rate * (Limit / 1000)
                        //IF Rating Basis = "per 100 of limit" THEN Rate * (Limit / 100)
                        //IF Rating Basis = "Flat charge" THEN PREMIUM is user entered
                        //IF Rating Basis = ""No Charge" THEN 0
                        if (otherCoverage.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARGE")
                        {
                            // step 1
                            otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = otherCoverage.OtherCoverageUnmodifiedPremium;
                        }
                        else if (otherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                        {
                            // step 3
                            otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = Convert.ToInt32(otherCoverage.OtherCoverageRate
                                                                                                                * (otherCoverage.OtherCoverageLimit
                                                                                                                / 1000));
                        }
                        else if (otherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                        {
                            // step 3
                            otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = Convert.ToInt32(otherCoverage.OtherCoverageRate
                                                                                                                * (otherCoverage.OtherCoverageLimit
                                                                                                                / 100));

                        }
                        else if (otherCoverage.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                        {
                            // step 1
                            otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = 0;
                        }

                        otherCoverageOutputModel.OtherCoverageUnmodifiedPremium = Convert.ToInt32(otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium);

                        //step 14.6
                        if (string.IsNullOrEmpty(otherCoverage.OtherCoverageIncludedInExcessExposure))
                        {
                            otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure = this.dataAccess.GetProfLinesExcessExposure(PolicyHeaderModel.State,
                                                                                                                                        PolicyHeaderModel.PrimaryClass,
                                                                                                                                        otherCoverage.OtherCoverageDescription,
                                                                                                                                        inputModel.LineOfBusiness,
                                                                                                                                        PolicyHeaderModel.PolicyEffectiveDate,
                                                                                                                                        PolicyHeaderModel.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == 1000000)
                        {
                            // step 14.7
                            if (!string.IsNullOrEmpty(otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure) && otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                otherCoverageOutputModel.OtherCoverageUnmodifiedPremium = 0;
                            }
                        }

                        otherCoverageOutputModelList.Add(otherCoverageOutputModel);
                    }

                    outputOptionalProperty.DirectorsAndOfficersOptionalOtherCoverageModel = otherCoverageOutputModelList;
                }

                #endregion

                #region   Step 15 - OtherCoverages TotalPremium 

                decimal totalOtherPremium = Convert.ToDecimal(outputOptionalProperty.SupplExtendedReportingPeriodUnmodifiedPremium);

                if (inputOptionalProperty.DirectorsAndOfficersOptionalOtherCoverageModel != null)
                {
                    totalOtherPremium = totalOtherPremium 
                                        + outputOptionalProperty.DirectorsAndOfficersOptionalOtherCoverageModel.Sum(x => x.OtherCoverageUnmodifiedPremium);
                }

                outputOptionalProperty.OtherCoveragesTotalPremium = Convert.ToInt32(Math.Round(totalOtherPremium, 0, MidpointRounding.AwayFromZero));

                #endregion

                #region Step 16 - Get Non Modified Premium  

                outputModel.NonModifiedPremium = outputOptionalProperty.OtherCoveragesTotalPremium;

                #endregion

                this.logger.Info("DirectorsAndOfficers.CalculateOptionalCoverage :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("DirectorsAndOfficers.CalculateOptionalCoverage :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateOtherPremiums
        /// </summary>
        /// <param name="model"></param>
        public void CalculateOtherPremiums(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("DirectorsAndOfficers.CalculateOtherPremiums :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers;
                var PolicyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
                var PricingModel = model.RaterInputFacadeModel.PricingInputModel;
                var optionalCoverageOutputModel = outputModel.DirectorsAndOfficersOptionalCoverageModel;

                // to get LOB MinimumPremium
                lobMinimumPremium = Convert.ToInt32(this.dataAccess.GetMinimumPremium(PolicyHeaderModel.State,
                                                                                      PolicyHeaderModel.PrimaryClass,
                                                                                      inputModel.LineOfBusiness,
                                                                                      PolicyHeaderModel.PolicyEffectiveDate,
                                                                                      PolicyHeaderModel.PolicyExpirationDate));

                #region Step 17 - Manual Premium 

                outputModel.ManualPremium = outputModel.BasePremium + outputModel.NonModifiedPremium;

                if (outputModel.ManualPremium < lobMinimumPremium)
                {
                    outputModel.ManualPremium = Convert.ToInt32(lobMinimumPremium);
                }

                #endregion

                #region Step 18 - Tier Premium

                outputModel.TierRate = this.dataAccess.GetProfLinesTierRate(PolicyHeaderModel.State,
                                                                            inputModel.LineOfBusiness,
                                                                            PricingModel.TierPlan,
                                                                            PolicyHeaderModel.PolicyEffectiveDate,
                                                                            PolicyHeaderModel.PolicyExpirationDate);

                // step 18.2
                outputModel.TierPremium = Convert.ToInt32(Math.Round((outputModel.ManualPremium
                                                                    - outputModel.NonModifiedPremium)
                                                                    * outputModel.TierRate
                                                                    + outputModel.NonModifiedPremium));

                if (outputModel.TierPremium < lobMinimumPremium)
                {
                    outputModel.TierPremium = Convert.ToInt32(lobMinimumPremium);
                }

                #endregion

                #region Step 19 - IRPM Premium 

                outputModel.IRPMFactor = inputModel.IRPMFactor;

                // step 19.1
                var irpmPremium = ((outputModel.TierPremium
                                  - outputModel.NonModifiedPremium)
                                  * outputModel.IRPMFactor
                                  + outputModel.NonModifiedPremium);

                outputModel.IRPMPremium = Convert.ToInt32(Math.Round(irpmPremium, 0, MidpointRounding.AwayFromZero));

                if (outputModel.IRPMPremium < lobMinimumPremium)
                {
                    outputModel.IRPMPremium = Convert.ToInt32(lobMinimumPremium);
                }

                #endregion

                #region Step 20 - Other Mod Premium 

                //inputModel.IRPMFactor UserEntry
                outputModel.OtherModRate = inputModel.OtherModRate;

                // step 20.1
                outputModel.OtherModPremium = Convert.ToInt32(Math.Round(((outputModel.IRPMPremium
                                                                         - outputModel.NonModifiedPremium)
                                                                         * outputModel.OtherModRate
                                                                         + outputModel.NonModifiedPremium)
                                                                         , 0
                                                                         , MidpointRounding.AwayFromZero));

                if (outputModel.OtherModPremium < lobMinimumPremium)
                {
                    outputModel.OtherModPremium = Convert.ToInt32(lobMinimumPremium);
                }

                #endregion

                #region Step 21 - Terrorism Premium 

                outputModel.TerrorismPremium = Convert.ToInt32(Math.Round((outputModel.OtherModPremium
                                                                         * outputModel.TerrorismRate)
                                                                         , 0
                                                                         , MidpointRounding.AwayFromZero));

                #endregion

                #region Step 22 - Final Premium 

                outputModel.DOModifiedFinalPremium = outputModel.TerrorismPremium + outputModel.OtherModPremium;

                if (outputModel.DOModifiedFinalPremium < lobMinimumPremium)
                {
                    outputModel.DOModifiedFinalPremium = Convert.ToInt32(lobMinimumPremium);
                }

                #endregion

                //  check If Suppl. Extended Reporting Period Is Selected then
                if (optionalCoverageOutputModel!=null && inputModel.DirectorsAndOfficersOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputModel.ManualPremium = outputModel.ManualPremium
                                               - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    if (outputModel.ManualPremium < lobMinimumPremium)
                    {
                        outputModel.ManualPremium = Convert.ToInt32(Math.Round(lobMinimumPremium
                                                                               + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium
                                                                               , 0
                                                                               , MidpointRounding.AwayFromZero));
                    }

                    outputModel.TierPremium = outputModel.TierPremium
                                               - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    if (outputModel.TierPremium < lobMinimumPremium)
                    {
                        outputModel.TierPremium = Convert.ToInt32(Math.Round(lobMinimumPremium
                                                                           + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium
                                                                           , 0
                                                                           , MidpointRounding.AwayFromZero));
                    }

                    outputModel.IRPMPremium = outputModel.IRPMPremium
                                               - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    if (outputModel.IRPMPremium < lobMinimumPremium)
                    {
                        outputModel.IRPMPremium = Convert.ToInt32(Math.Round(lobMinimumPremium
                                                                           + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium
                                                                           , 0
                                                                           , MidpointRounding.AwayFromZero));
                    }

                    outputModel.OtherModPremium = outputModel.OtherModPremium
                                                - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    // This step will be executed only If calculated Other Mod Premium in step F.1 < LOB Minimum Premium
                    if (outputModel.OtherModPremium < lobMinimumPremium)
                    {
                        outputModel.OtherModPremium = Convert.ToInt32(Math.Round(lobMinimumPremium
                                                                               + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium
                                                                               , 0
                                                                               , MidpointRounding.AwayFromZero));
                    }

                    // Calculate  Suppl. Extended Reporting Unmodified Premium
                    outputModel.DOModifiedFinalPremium = outputModel.OtherModPremium
                                                        - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    // This step will be executed only If calculated Other Mod Premium is < LOB Minimum Premium
                    if (outputModel.DOModifiedFinalPremium < lobMinimumPremium)
                    {
                        outputModel.DOModifiedFinalPremium = Convert.ToInt32(lobMinimumPremium)
                                                            + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                #region DO UnmodifiedWithoutExcessPremium

                // step 23 DOUnmodifiedWithoutExcessPremium = Step 14.5
                if (optionalCoverageOutputModel.DirectorsAndOfficersOptionalOtherCoverageModel != null)
                {
                    outputModel.DOUnmodifiedWithoutExcessPremium = optionalCoverageOutputModel.DirectorsAndOfficersOptionalOtherCoverageModel.Sum(a => a.OtherCoverageUnModifiedWithoutExcessPremium);
                }

                #endregion

                this.logger.Info("DirectorsAndOfficers.CalculateOtherPremiums :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("DirectorsAndOfficers.CalculateOtherPremiums :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        #endregion

        #region Get Yearfrac

        /// <summary>
        /// YearFrac
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>decimal</returns>
        public decimal YearFrac(DateTime startDate, DateTime endDate)
        {
            this.logger.Info("LawService.YearFrac :: Starting");
            if (endDate < startDate)
            {
                return 0;
            }
            int endDay = endDate.Day;
            int startDay = startDate.Day;
            switch (startDay)
            {
                case 31:
                    {
                        startDay = 30;
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 30:
                    {
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 29:
                    {
                        if (startDate.Month == 2)
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;

                case 28:
                    {
                        if ((startDate.Month == 2) && (!DateTime.IsLeapYear(startDate.Year)))
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;
            }
            decimal yearFrac = (((endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDay - startDay)) / 360);

            this.logger.Info("LawService.YearFrac :: Completed");
            return yearFrac;
        }

        #endregion
    }
}
