﻿using Microsoft.Extensions.Configuration;
using Logging;
using Models.ApiModels;
using RaterDO;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaterDirectorsAndOfficers
{
    /// <summary>
    /// DirectorsAndOfficersServiceWrapper.
    /// </summary>
    public class DirectorsAndOfficersServiceWrapper
    {   
        /// <summary>
        /// logger Object
        /// </summary>
        protected ILoggingManager logger { get; private set; }

        /// <summary>
        /// configuration Object
        /// </summary>
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyCwService"/> class.
        /// </summary>
        /// <param name="logger">ILoggingManager.</param>
        public DirectorsAndOfficersServiceWrapper(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.logger = logger;
        }

        /// <summary>
        /// ExecuteDirectorsAndOfficersEngine : It's includes pre validation ,premium calculation , post validation.
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        /// <returns>ValidationResult</returns>
        public FluentValidation.Results.ValidationResult ExecuteDirectorsAndOfficersEngine(RaterFacadeModel raterFacadeModel)
        {
            //Create service object
            IDirectorsAndOfficersService service = new DirectorsAndOfficersService(this.configuration, this.logger); ;

            // Prevalidate
            var preValidateResults = service.PreValidate(raterFacadeModel);

            if (!preValidateResults.IsValid) return preValidateResults;

            // Since input pre validation are success, calculate premium
            service.Calculate(raterFacadeModel);

            //Post validate
            var postValidateResults = service.PostValidate(raterFacadeModel);

            return postValidateResults;
        }
    }
}
