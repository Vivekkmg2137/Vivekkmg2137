﻿using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaterDO
{
    /// <summary>
    /// IDirectorsAndOfficersService
    /// </summary>
    public interface IDirectorsAndOfficersService
    {
        /// <summary>
        /// ExecuteDomainRules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        /// <summary>
        /// PreValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);


        /// <summary>
        /// PostValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model);

        /// <summary>
        /// Calculate Premium
        /// </summary>
        /// <param name="model"></param>
        void Calculate(RaterFacadeModel model);

        /// <summary>
        /// Calculate Optional Coverage Premium
        /// </summary>
        /// <param name="model"></param>
        void CalculateOptionalCoverage(RaterFacadeModel model);

        /// <summary>
        /// Calculate Base Premium
        /// </summary>
        /// <param name="model"></param>
        void CalculateBasePremium(RaterFacadeModel model);

        /// <summary>
        /// Calculate Other Premiums
        /// </summary>
        /// <param name="model"></param>
        void CalculateOtherPremiums(RaterFacadeModel model);
    }
}
