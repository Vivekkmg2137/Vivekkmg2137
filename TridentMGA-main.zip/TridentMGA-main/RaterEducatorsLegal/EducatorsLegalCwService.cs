﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Output;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Validations;

namespace RateEducatorsLegal
{
    public class EducatorsLegalCwService : IEducatorsLegalService
    {
        private EducatorsLegalDataAccess _DataAccess { get; set; }

        protected ILoggingManager _Logger { get; private set; }

        protected IConfiguration _Configuration { get; private set; }

        public EducatorsLegalCwService(IConfiguration configuration, ILoggingManager logger)
        {
            this._Configuration = configuration;
            this._Logger = logger;
            this._DataAccess = new EducatorsLegalDataAccess(configuration, logger);
        }

        public virtual DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        public virtual FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EducatorsLegalService.PreValidate :: Starting");
                var validator = new EducatorsLegalCWPreValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);
                this._Logger.Info("EducatorsLegalService.PreValidate :: Completed");
                return results;

            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.PreValidate :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        public virtual FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EmploymentPracticesService.PostValidate :: Starting");
                var validator = new EducatorsLegalPostValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);
                this._Logger.Info("EmploymentPracticesService.PostValidate :: Completed");
                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.PostValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region  Educators Legel CW

        public virtual void Calculate(RaterFacadeModel model)
        {
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW;
            try
            {
                #region CalculationEL for CW

                CalculateLiabilityPremiums(model);

                #endregion

                #region Optional Coverages Premium

                if (inputModel.EducatorsLegalOptionalCoverage != null)
                {
                    CalculateOptionalCoveragePremium(model);
                }

                #endregion

                CalculateOthersPremium(model);

            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculationEL
        /// </summary>
        /// <param name="model"></param>
        private protected void CalculateLiabilityPremiums(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EducatorsLegalService.ELCalculation :: Started");

                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW;
                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                policyHeaderModel.State = policyHeaderModel.State.ToUpper();
                policyHeaderModel.PrimaryClass = policyHeaderModel.PrimaryClass.ToUpper();
                policyHeaderModel.TransactionType = policyHeaderModel.TransactionType.ToUpper();

                //Step 8 EPInclusionExclusion
                // if STATE CODE not equal 'NY' pass 'Excluded' as the default value for 'EP Coverage' to the table EPInclExclFactor
                inputModel.EPInclusionExclusion = "Excluded";

                // Step 10.3 Rating Basis                 
                //State Code, Primary Class
                var dataTableRatingBasis = this._DataAccess.GetRatingBasisParameter(policyHeaderModel.State,
                                                                                    policyHeaderModel.PrimaryClass,
                                                                                    inputModel.LineOfBusiness,
                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                    policyHeaderModel.PolicyExpirationDate);

                if (dataTableRatingBasis != null && dataTableRatingBasis.Rows.Count > 0 && dataTableRatingBasis.Rows[0] != null)
                {
                    if (dataTableRatingBasis.Rows[0]["RatingBasis"] != DBNull.Value)
                    {
                        outputModel.RatingBasis = Convert.ToString(dataTableRatingBasis.Rows[0]["RatingBasis"]);
                    }

                    if (dataTableRatingBasis.Rows[0]["RatingBasisParameter"] != DBNull.Value)
                    {
                        var ratingBasisParameter = Convert.ToDecimal(dataTableRatingBasis.Rows[0]["RatingBasisParameter"]);

                        outputModel.RatingBasisParameter = Convert.ToInt32(Math.Round(ratingBasisParameter, 0, MidpointRounding.AwayFromZero));
                    }
                }

                //Step-11   QUERY  
                //Math.Round((YearFrac(Policy Effective Date, Retro Active Date, 1),0)
                //Ex: If  Policy Eff Date = 05 / 11 / 2020 Retro Date = 05 / 11 / 2015 THEN YearFrac Returns the Value 5.0091. Perform RoundDown Refer to Example in J16 cell
                decimal yearFrac = this.YearFrac(inputModel.RetroDate, policyHeaderModel.PolicyEffectiveDate);
                outputModel.RetroYear = (int)Math.Round(yearFrac, 0);

                // Step 12.8   GetExposureRate                
                // User Entry If the Rater receives a value -Validate the value against the Base Rate Min, Base Rate Max column of the lookup table(To be handled in PreValidations) LookUp
                // If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation 
                // outputPOModel.ExposureRate =
                if (inputModel.ExposureRate >= 0)
                {
                    outputModel.ExposureRate = inputModel.ExposureRate;
                }
                else
                {
                    DataTable dataTable = _DataAccess.GetExposureRateMinMaxFactor(policyHeaderModel.State,
                                                                                  policyHeaderModel.PrimaryClass,
                                                                                  inputModel.LineOfBusiness,
                                                                                  policyHeaderModel.PolicyEffectiveDate,
                                                                                  policyHeaderModel.PolicyExpirationDate);

                    if (dataTable != null && dataTable.Rows.Count > 0 && dataTable.Rows[0]["BaseRate"] != DBNull.Value)
                    {
                        outputModel.ExposureRate = Convert.ToDecimal(dataTable.Rows[0]["BaseRate"]);
                    }
                }

                //  Step 12.9   Get EP Incl / Excl Rate  
                //  State Code, EP Coverage(Pass 'EP Coverage' as 'Excluded' to the table)
                outputModel.EPInclusionExclusionRate = _DataAccess.GetELInclusionExclusionRate(policyHeaderModel.State,
                                                                                               inputModel.LineOfBusiness,
                                                                                               inputModel.EPInclusionExclusion,
                                                                                               "Exclusion",
                                                                                               policyHeaderModel.PolicyEffectiveDate,
                                                                                               policyHeaderModel.PolicyExpirationDate);

                // Step 12.10	Get Liability Limit Rate              
                //Read table using following input parameters to get the Limit factor from column " Default Factor" - State Code, LOB code, Effective Date, Expiration Date, Liability Limit
                if (inputModel.LiabilityLimitRate >= 0)
                {
                    outputModel.LiabilityLimitRate = inputModel.LiabilityLimitRate;
                }
                else
                {
                    DataTable dataTableLimit = _DataAccess.GetLiabilityLimitRateMinimum(policyHeaderModel.State,
                                                                                        inputModel.LineOfBusiness,
                                                                                        inputModel.LiabilityLimit,
                                                                                        policyHeaderModel.PolicyEffectiveDate,
                                                                                        policyHeaderModel.PolicyExpirationDate);

                    if (dataTableLimit != null && dataTableLimit.Rows.Count > 0 && dataTableLimit.Rows[0]["Factor"] != DBNull.Value)
                    {
                        outputModel.LiabilityLimitRate = Convert.ToDecimal(dataTableLimit.Rows[0]["Factor"]);
                    }
                }

                // Step 12.11	Get Aggregate Limit Rate
                //- State Code, LOB code, Effective Date, Expiration Date, Liability Limit, Aggregate Limit.             
                outputModel.AggregateLimitRate = _DataAccess.GetAggregateLimitRate(policyHeaderModel.State,
                                                                                   inputModel.LineOfBusiness,
                                                                                   policyHeaderModel.PolicyEffectiveDate,
                                                                                   policyHeaderModel.PolicyExpirationDate,
                                                                                   inputModel.LiabilityLimit,
                                                                                   inputModel.AggregateLimit);

                //  Step 12.12 ,12.13 RetentionRate             
                // STATE CODE, DeductibleSIR (Pass the value as 'Deductible' if 'Deductible/SIR' is selected as 'Deductible'), Deductible STATE CODE, DeductibleSIR (Pass the value as 'SIR' if 'Deductible/SIR' is selected as 'SIR') SIR
                outputModel.RetentionRate = _DataAccess.GetRetentionRate(policyHeaderModel.State,
                                                                         inputModel.LineOfBusiness,
                                                                         policyHeaderModel.PolicyEffectiveDate,
                                                                         policyHeaderModel.PolicyExpirationDate,
                                                                         inputModel.DeductibleSIR,
                                                                         inputModel.Retention);

                // Step 12.14  Population RATE  
                // Use 'Population/ADA'(Step 3) to look up for RATE when PRIMARY CLASS = 'School'
                //Use 'Exposure'(Step 7) instead of 'Population/ADA' to lookup for RATE when PRIMARY CLASS = 'Muni/School Combined'"
                outputModel.PopulationRate = _DataAccess.GetPopulationRate(policyHeaderModel.State,
                                                                           inputModel.LineOfBusiness,
                                                                           policyHeaderModel.PrimaryClass,
                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                           policyHeaderModel.PolicyExpirationDate,
                                                                           policyHeaderModel.PopulationADA);

                ///TODO : Uncomment below code once client approved this changes.
                //if(policyHeaderModel.PrimaryClass== PrimaryClassConstant.SC)
                //{
                //    outputModel.PopulationRate = _DataAccess.GetPopulationRate(policyHeaderModel.State,
                //                                                               inputModel.LineOfBusiness,
                //                                                               policyHeaderModel.PrimaryClass,
                //                                                               policyHeaderModel.PolicyEffectiveDate,
                //                                                               policyHeaderModel.PolicyExpirationDate,
                //                                                               policyHeaderModel.PopulationADA);
                //}
                //else
                //{
                //    outputModel.PopulationRate = _DataAccess.GetPopulationRate(policyHeaderModel.State,
                //                                                               inputModel.LineOfBusiness,
                //                                                               policyHeaderModel.PrimaryClass,
                //                                                               policyHeaderModel.PolicyEffectiveDate,
                //                                                               policyHeaderModel.PolicyExpirationDate,
                //                                                               inputModel.Exposure);
                //}                

                // Step 12.15  Location RATE 
                //- State Code, LOB code, Effective Date, Expiration Date, LocationType.           
                outputModel.LocationRate = _DataAccess.GetLocationRate(policyHeaderModel.State,
                                                                       inputModel.LineOfBusiness,
                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                       policyHeaderModel.PolicyExpirationDate,
                                                                       policyHeaderModel.LocationType);


                // Step 12.16  Policy Type RATE
                //- State Code, LOB code, Effective Date, Expiration Date, Liability Limit, Aggregate Limit.            
                outputModel.PolicyTypeRate = _DataAccess.GetPolicyTypeRate(policyHeaderModel.State,
                                                                           inputModel.LineOfBusiness,
                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                           policyHeaderModel.PolicyExpirationDate,
                                                                           inputModel.PolicyType);

                // Step 12.17  Years in YearsinCMRate 
                // State Code, LOB code, Effective Date, Expiration Date, Years In CM Program
                outputModel.YearsinCMRate = _DataAccess.GetYearsinCMRate(policyHeaderModel.State,
                                                                         inputModel.LineOfBusiness,
                                                                         policyHeaderModel.PolicyEffectiveDate,
                                                                         policyHeaderModel.PolicyExpirationDate,
                                                                         inputModel.YearsinCMProgram);

                // Step 12.18  Retro Date RATE
                // Refer to Step 11  for 'Years Prior'
                //If the Years Prior is greater than 6 Pass the value '>6' to the table
                //If 'Policy Tytpe = 'Claims Made' THEN use the table to lookup the factors
                //Else '1.000'
                string stringRetroYear = string.Empty;
                if (inputModel.PolicyType.ToUpper() == "CLAIMS MADE")
                {
                    if (outputModel.RetroYear > 6)
                    {
                        stringRetroYear = ">6";
                    }
                    else
                    {
                        stringRetroYear = outputModel.RetroYear.ToString();
                    }
                    outputModel.RetroDateRate = _DataAccess.GetRetroDateRate(policyHeaderModel.State,
                                                                             inputModel.LineOfBusiness,
                                                                             policyHeaderModel.PolicyEffectiveDate,
                                                                             policyHeaderModel.PolicyExpirationDate,
                                                                             stringRetroYear);

                } 
                else
                {
                    outputModel.RetroDateRate = 1;
                }

                // Step 12.19  Get Loss Experience RATE 
                //- State Code, LOB code, Effective Date, Expiration Date, ExperienceFactorIsSelected. 
                outputModel.ExperienceRetention = _DataAccess.GetLossExperienceRate(policyHeaderModel.State,
                                                                                    inputModel.LineOfBusiness,
                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                    policyHeaderModel.PolicyExpirationDate,
                                                                                    inputModel.ExperienceFactorIsSelected);
                // Step 12.20  Pro Rata Factor (CrossLine)

                // Step 12.5 Calculate Base Premium	

                decimal BasePremium = (inputModel.Exposure
                                     / outputModel.RatingBasisParameter)
                                     * outputModel.ExposureRate
                                     * outputModel.EPInclusionExclusionRate
                                     * outputModel.LiabilityLimitRate
                                     * outputModel.AggregateLimitRate
                                     * outputModel.RetentionRate
                                     * outputModel.PopulationRate
                                     * outputModel.LocationRate
                                     * outputModel.PolicyTypeRate
                                     * outputModel.YearsinCMRate
                                     * outputModel.RetroDateRate
                                     * outputModel.ExperienceRetention;

                outputModel.BasePremium = (int)Math.Round(BasePremium, 0);
                
                this._Logger.Info("EducatorsLegalService.ELCalculation :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.ELCalculation :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateOptionalCoveragePremium
        /// </summary>
        /// <param name="model"></param>
        private protected void CalculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EducatorsLegal.CalculateOptionalCoveragePremium :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW;
                var optionalCoverageOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage;
                var optionalCoverageInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage;

                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                // User Entry
                if (optionalCoverageInputModel.IDEAIsSelected)
                {
                    optionalCoverageOutputModel.IDEAIsSelected = optionalCoverageInputModel.IDEAIsSelected;
                    optionalCoverageOutputModel.IDEAAggregateLimit = optionalCoverageInputModel.IDEAAggregateLimit;
                    optionalCoverageOutputModel.IDEADeductible = optionalCoverageInputModel.IDEADeductible;
                    optionalCoverageOutputModel.IDEALimit = optionalCoverageInputModel.IDEALimit;
                    optionalCoverageOutputModel.IDEAModifiedPremium = optionalCoverageInputModel.IDEAModifiedPremium;
                    optionalCoverageOutputModel.IDEARate = optionalCoverageInputModel.IDEARate;
                    optionalCoverageOutputModel.IDEARatingBasis = optionalCoverageInputModel.IDEARatingBasis;
                    optionalCoverageOutputModel.IDEAReturnMethod = optionalCoverageInputModel.IDEAReturnMethod;
                    optionalCoverageOutputModel.IDEAIncludedInExcessExposure = optionalCoverageInputModel.IDEAIncludedInExcessExposure;

                    //  Step 13.3   Calculate IDEA Premium  (QUERY)
                    //Pass the Primary Class & State Code to the Additional Coverages Premium table and
                    //if it is not found, Pass Primary Class as "All" and State Code as 'CW'.
                    //This means factor/rate applicable for all Primary Class & States               
                    var optionalCoveragePremium = _DataAccess.GetProfLinesOptionalCoveragePremium(policyHeaderModel.State,
                                                                                                  policyHeaderModel.PrimaryClass,
                                                                                                  inputModel.LineOfBusiness,
                                                                                                  "IDEA",
                                                                                                  optionalCoverageOutputModel.IDEALimit,
                                                                                                  optionalCoverageInputModel.IDEAAggregateLimit,
                                                                                                  optionalCoverageInputModel.IDEARatingBasis,
                                                                                                  policyHeaderModel.PolicyEffectiveDate,
                                                                                                  policyHeaderModel.PolicyExpirationDate);

                    optionalCoverageOutputModel.IDEAUnmodifiedWithoutExcessPremium = (int)Math.Round(optionalCoveragePremium, 0, MidpointRounding.ToZero);

                    optionalCoverageOutputModel.IDEAUnmodifiedPremium = Convert.ToInt32(optionalCoverageOutputModel.IDEAUnmodifiedWithoutExcessPremium);

                    //step 13.4
                    // If input value is blank then Refer to lookup table. otherwise "SupplExtendedReportingPeriod Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(optionalCoverageInputModel.IDEAIncludedInExcessExposure))
                    {
                        optionalCoverageOutputModel.IDEAIncludedInExcessExposure = this._DataAccess.GetExcessExposure(policyHeaderModel.State,
                                                                                                                      policyHeaderModel.PrimaryClass,
                                                                                                                      inputModel.LineOfBusiness,                                                                                                                      
                                                                                                                      "IDEA",
                                                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                                                      policyHeaderModel.PolicyExpirationDate);
                    }

                    //If LineOfBusiness Excess = True and Liability Limit = 1,000,000
                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == 1000000)
                    {
                        //step 13.5 IDEA Un-Modified Premium
                        // If  IDEA Included In Excess Exposure = True
                        if (!string.IsNullOrEmpty(optionalCoverageOutputModel.IDEAIncludedInExcessExposure) && optionalCoverageOutputModel.IDEAIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            optionalCoverageOutputModel.IDEAUnmodifiedPremium = 0;
                        }
                    }
                }

                // Step 13.4   Apply Prorata Factor - (Cross Line)

                // Step 14   Non Monetary Defense  User Entry                 
                if (optionalCoverageInputModel.NonMonetaryDefenseIsSelected)
                {
                    optionalCoverageOutputModel.NonMonetaryDefenseIsSelected = optionalCoverageInputModel.NonMonetaryDefenseIsSelected;
                    optionalCoverageOutputModel.NonMonetaryDefenseAggregateLimit = optionalCoverageInputModel.NonMonetaryDefenseAggregateLimit;
                    optionalCoverageOutputModel.NonMonetaryDefenseDeductible = optionalCoverageInputModel.NonMonetaryDefenseDeductible;
                    optionalCoverageOutputModel.NonMonetaryDefenseLimit = optionalCoverageInputModel.NonMonetaryDefenseLimit;
                    optionalCoverageOutputModel.NonMonetaryDefenseModifiedPremium = optionalCoverageInputModel.NonMonetaryDefenseModifiedPremium;
                    optionalCoverageOutputModel.NonMonetaryDefenseRate = optionalCoverageInputModel.NonMonetaryDefenseRate;
                    optionalCoverageOutputModel.NonMonetaryDefenseRatingBasis = optionalCoverageInputModel.NonMonetaryDefenseRatingBasis;
                    optionalCoverageOutputModel.NonMonetaryDefenseReturnMethod = optionalCoverageInputModel.NonMonetaryDefenseReturnMethod;
                    optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure = optionalCoverageInputModel.NonMonetaryDefenseIncludedInExcessExposure;

                    // Step 14.3 Calculate Non Monetary Defense 
                    //Pass the Primary Class & State Codeto the Additional Coverages Premium table and
                    //if it is not found, Pass Primary Class as "All" and State Code as 'CW'.
                    //This means factor/rate applicable for all Primary Class & States
                    //If Premium = n / a - Use '0' ROUND to nearest whole number

                    var nonMonetaryUnmodifiedPremium = _DataAccess.GetProfLinesOptionalCoveragePremium(policyHeaderModel.State,
                                                                                                       policyHeaderModel.PrimaryClass,
                                                                                                       inputModel.LineOfBusiness,
                                                                                                       "Non-Monetary Defense",
                                                                                                       optionalCoverageOutputModel.NonMonetaryDefenseLimit,
                                                                                                       optionalCoverageInputModel.NonMonetaryDefenseAggregateLimit,
                                                                                                       optionalCoverageInputModel.NonMonetaryDefenseRatingBasis,
                                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                                       policyHeaderModel.PolicyExpirationDate);

                    optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedWithoutExcessPremium = (int)Math.Round(nonMonetaryUnmodifiedPremium, 0, MidpointRounding.ToZero);

                    optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedPremium = Convert.ToInt32(optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedWithoutExcessPremium);

                    //step 14.4
                    // If input value is blank then Refer to lookup table. otherwise "NonMonetary Defense Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(optionalCoverageInputModel.NonMonetaryDefenseIncludedInExcessExposure))
                    {
                        optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure = this._DataAccess.GetExcessExposure(policyHeaderModel.State,
                                                                                                                                    policyHeaderModel.PrimaryClass,
                                                                                                                                    inputModel.LineOfBusiness,                                                                                                                                    
                                                                                                                                    "Non-Monetary Defense",
                                                                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                    policyHeaderModel.PolicyExpirationDate);
                    }

                    //If LineOfBusiness Excess = True and Liability Limit = 1,000,000
                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == 1000000)
                    {                       
                        //step 14.5 NonMonetaryDefense Un-Modified Premium
                        // If NonMonetaryDefense Included In Excess Exposure = True 
                        if (!string.IsNullOrEmpty(optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure) && optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedPremium = 0;
                        }
                    } 
                }

                // Step 15    Suppl.Extended Reporting Period Limit  - User Entry
                #region code commented by BA team.

                //if (optionalCoverageInputModel.SupplExtendedReportingPeriodIsSelected)
                //{
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodIsSelected = optionalCoverageInputModel.SupplExtendedReportingPeriodIsSelected;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodAggregateLimit = optionalCoverageInputModel.SupplExtendedReportingPeriodAggregateLimit;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodDeductible = optionalCoverageInputModel.SupplExtendedReportingPeriodDeductible;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodLimit = optionalCoverageInputModel.SupplExtendedReportingPeriodLimit;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodModifiedPremium = optionalCoverageInputModel.SupplExtendedReportingPeriodModifiedPremium;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodRate = optionalCoverageInputModel.SupplExtendedReportingPeriodRate;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodRatingBasis = optionalCoverageInputModel.SupplExtendedReportingPeriodRatingBasis;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodReturnMethod = optionalCoverageInputModel.SupplExtendedReportingPeriodReturnMethod;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodIncludedInExcessExposure = optionalCoverageInputModel.SupplExtendedReportingPeriodInverseCondemnationIncludedInExcessExposure;

                //    // Step 15.1  Rating Basis  - (Cross Line)

                //    // Step 15.2  RATE  - (Cross Line)

                //    // Step 15.3   Calculate Suppl. Extended Reporting Period  - (Cross Line)

                //    // Step 15.4   FINAL EL PREMIUM  - (Cross Line)

                //    // Step 15.5   Apply Prorata Factor - (Cross Line)
                //}
                #endregion

                #region Step 16 Calculate Other Premium 
                if (optionalCoverageInputModel.EducatorsLegalOtherCoverage != null)
                {
                    CalculateOtherOptionalCoveragePremium(model);
                }
                #endregion

                // step 17  = Step 17.1   + Step 17.2   + Step 17.3   +  Step 17.4   Refer to Step 16
                decimal optionalCoveragesPremium = Convert.ToDecimal(optionalCoverageOutputModel.IDEAUnmodifiedPremium +
                                                                     optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedPremium +
                                                                     optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium);

                int othersUnmodifiedPremium = optionalCoverageOutputModel.EducatorsLegalOtherCoverage != null ? optionalCoverageOutputModel.EducatorsLegalOtherCoverage.Sum(x => x.OtherCoverageUnmodifiedPremium) : 0;

                optionalCoveragesPremium = optionalCoveragesPremium + othersUnmodifiedPremium;

                optionalCoverageOutputModel.OtherCoverageTotalPremium = Convert.ToInt32(optionalCoveragesPremium);

                // Step 18
                outputModel.NonModifiedPremium = (int)Math.Round(optionalCoveragesPremium, 0, MidpointRounding.ToZero);

                this._Logger.Info("EducatorsLegalService.CalculateOptionalCoveragePremium :: Completed");

            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.ELCalculation :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #endregion 

        #region Optional Coverage  

        /// <summary>
        /// CalculateOtherOptionalCoveragePremium
        /// </summary>
        /// <param name="model"></param>
        private protected void CalculateOtherOptionalCoveragePremium(RaterFacadeModel model)
        {
            this._Logger.Info("EmploymentPracticesService.CalculateOtherOptionalCoveragePremium :: Starting");
            try
            {
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
                var inputmodel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal;
                var optionalCoverageOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage;

                var otherCoverageOutputModelList = new List<EducatorsLegalOtherCoverageOutputModel>();
                var otherCoverageInputModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage;

                foreach (var otherCoverageInput in otherCoverageInputModelList)
                {
                    EducatorsLegalOtherCoverageOutputModel otherCoverage = new EducatorsLegalOtherCoverageOutputModel();

                    otherCoverage.OtherCoverageID = otherCoverageInput.OtherCoverageID;
                    otherCoverage.OtherCoverageDescription = otherCoverageInput.OtherCoverageDescription;
                    otherCoverage.OtherCoverageDeductible = otherCoverageInput.OtherCoverageDeductible;
                    otherCoverage.OtherCoverageRatingBasis = otherCoverageInput.OtherCoverageRatingBasis;
                    otherCoverage.OtherCoverageRate = otherCoverageInput.OtherCoverageRate;
                    otherCoverage.OtherCoverageLimit = otherCoverageInput.OtherCoverageLimit;
                    otherCoverage.OtherCoverageAggregateLimit = otherCoverageInput.OtherCoverageAggregateLimit;
                    otherCoverage.OtherCoverageModifiedPremium = otherCoverageInput.OtherCoverageModifiedPremium;
                    otherCoverage.OtherCoverageReturnMethod = otherCoverageInput.OtherCoverageReturnMethod;
                    otherCoverage.OtherCoverageIncludedInExcessExposure = otherCoverageInput.OtherCoverageIncludedInExcessExposure;

                    // Step 16.5 Other Premium
                    // When Rating basis is  'Flat charge' then Other Coverage Unmodified Premium 
                    if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARGE")
                    {
                        otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = otherCoverageInput.OtherCoverageUnmodifiedPremium;
                    }
                    // When Rating basis is 'per 1000 of limit'
                    else if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                    {
                        // Rate * (Limit/1000)
                        otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(otherCoverage.OtherCoverageRate
                                                                                                 * (otherCoverage.OtherCoverageLimit
                                                                                                 / 1000));
                    }
                    // When Rating basis is 'per 100 of limit'
                    else if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                    {
                        // Rate * (Limit/100)
                        otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(otherCoverage.OtherCoverageRate 
                                                                                                 * (otherCoverage.OtherCoverageLimit 
                                                                                                 / 100));
                    }
                    // When Rating basis is 'No Charge'
                    else if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                    {
                        //step 1
                        otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = 0;
                    }
                    otherCoverage.OtherCoverageUnmodifiedPremium = Convert.ToInt32(otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium);

                    //step 16.6
                    // If input value is blank then Refer to lookup table. otherwise "Other Coverage Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(otherCoverageInput.OtherCoverageIncludedInExcessExposure))
                    {
                        otherCoverage.OtherCoverageIncludedInExcessExposure = this._DataAccess.GetExcessExposure(policyHeaderModel.State,
                                                                                                                 policyHeaderModel.PrimaryClass,
                                                                                                                 inputmodel.LineOfBusiness,                                                                                                                 
                                                                                                                 "Other",
                                                                                                                 policyHeaderModel.PolicyEffectiveDate,
                                                                                                                 policyHeaderModel.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputmodel.LiabilityLimit == 1000000)
                    {                        
                        //step 16.7 Other Coverage Un-Modified Premium
                        // If LineOfBusiness Excess = True and Other Coverage Included In Excess Exposure = True and Liability Limit = 1,000,000
                        if (!string.IsNullOrEmpty(otherCoverage.OtherCoverageIncludedInExcessExposure) && otherCoverage.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            otherCoverage.OtherCoverageUnmodifiedPremium = 0;
                        }
                    }
                    //end step 16 

                    otherCoverageOutputModelList.Add(otherCoverage);
                }

                optionalCoverageOutputModel.EducatorsLegalOtherCoverage = otherCoverageOutputModelList;

                this._Logger.Info("EmploymentPracticesService.CalculateOtherOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.ELCalculation :: Exception :: " + ex.Message, ex);
                throw;
            }

        }

        #endregion

        /// <summary>
        /// CalculateOthersPremium
        /// </summary>
        /// <param name="model"></param>
        private void CalculateOthersPremium(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EducatorsLegalService.CalculateOthersPremium :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW;
                var optionalCoverageOutputModel = outputModel.EducatorsLegalOptionalCoverage;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                // Step 19.3   Apply Minimum Premium rules 
                // Read Minimum Premium lookup table to get Minimum Premium
                decimal lobMinimumPremium = _DataAccess.GetLOBTotalPremium(policyHeaderModel.State,
                                                                           inputModel.LineOfBusiness,
                                                                           policyHeaderModel.PrimaryClass,
                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                           policyHeaderModel.PolicyExpirationDate);

                // 	Calculate Manual Premium (Refer to Step 12.5 and Refer to Step 18)
                outputModel.ManualPremium = outputModel.BasePremium + outputModel.NonModifiedPremium;

                if (outputModel.ManualPremium < lobMinimumPremium)
                {
                    outputModel.ManualPremium = Convert.ToInt32(lobMinimumPremium);
                }

                // Step 20 Calculate Tier Premium
                // Step-20.4  Tier Rate         
                outputModel.TierRate = _DataAccess.GetTierRate(policyHeaderModel.State,
                                                               inputModel.LineOfBusiness,
                                                               policyHeaderModel.PolicyEffectiveDate,
                                                               policyHeaderModel.PolicyExpirationDate,
                                                               model.RaterInputFacadeModel.PricingInputModel.TierPlan);

                outputModel.TierPremium = Convert.ToInt32((outputModel.ManualPremium 
                                                         - outputModel.NonModifiedPremium)
                                                         * outputModel.TierRate
                                                         + outputModel.NonModifiedPremium);

                // This step will be executed only If calculated Tier Premium is < LOB Minimum Premium
                if (outputModel.TierPremium < lobMinimumPremium)
                {
                    outputModel.TierPremium = Convert.ToInt32(lobMinimumPremium);
                }

                // Step 21  Calculate IRPM Premium

                outputModel.IRPMFactor = inputModel.IRPMFactor;

                outputModel.IRPMPremium = Convert.ToInt32((outputModel.TierPremium 
                                                         - outputModel.NonModifiedPremium)
                                                         * outputModel.IRPMFactor 
                                                         + outputModel.NonModifiedPremium);

                // This step will be executed only If calculated IRPM Premium is < LOB Minimum Premium
                if (outputModel.IRPMPremium < lobMinimumPremium)
                {
                    outputModel.IRPMPremium = Convert.ToInt32(lobMinimumPremium);
                }

                // Step 22 Other Modr Premium Calculation  
                outputModel.OtherModRate = inputModel.OtherModRate;

                //((Step 21 - Step 18)  * (Step 17 + Step 18))
                outputModel.OtherModPremium = Convert.ToInt32(((outputModel.IRPMPremium
                                                              - outputModel.NonModifiedPremium)
                                                              * outputModel.OtherModRate) 
                                                              + outputModel.NonModifiedPremium);

                // This step will be executed only If calculated Other Mod Premium in step F.1 < LOB Minimum Premium
                if (outputModel.OtherModPremium < lobMinimumPremium)
                {
                    outputModel.OtherModPremium = Convert.ToInt32(lobMinimumPremium);
                }

                //  Step 23 Calculate Terrorism Premium Calculation
                //Step 22 * Step 18 Get Terrorism Factor
                if (model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected)
                {
                    outputModel.TerrorismPremium = Convert.ToInt32(outputModel.OtherModPremium * outputModel.TerrorismRate);
                }

                // Step 24	Calculate  Final EL Premium     
                //  (Step 22 + Step 23)
                outputModel.ELModifiedFinalPremium = outputModel.TerrorismPremium + outputModel.OtherModPremium;

                // This step will be executed only If calculated Other Mod Premium is < LOB Minimum Premium
                if (outputModel.ELModifiedFinalPremium < lobMinimumPremium)
                {
                    outputModel.ELModifiedFinalPremium = Convert.ToInt32(lobMinimumPremium);
                }

                //  check If Suppl. Extended Reporting Period Is Selected then
                if (inputModel.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodIsSelected)
                {
                    // Calculate Suppl. Extended Reporting Period Unmodified Premium
                    outputModel.ManualPremium = outputModel.ManualPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    // This step will be executed only If calculated Manual Premium is < LOB Minimum Premium
                    if (outputModel.ManualPremium < lobMinimumPremium)
                    {
                        outputModel.ManualPremium = Convert.ToInt32(lobMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }

                    // Calculate Suppl. Extended Reporting Period Unmodified Premium
                    outputModel.TierPremium = outputModel.TierPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    // This step will be executed only If calculated Tier Premium in step C.1 < LOB Minimum Premium
                    if (outputModel.TierPremium < lobMinimumPremium)
                    {
                        outputModel.TierPremium = Convert.ToInt32(lobMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                    // Calculate  Suppl. Extended Reporting Unmodified Premium
                    outputModel.IRPMPremium = outputModel.IRPMPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    // This step will be executed only If calculated IRPM Premium is < LOB Minimum Premium
                    if (outputModel.IRPMPremium < lobMinimumPremium)
                    {
                        outputModel.IRPMPremium = Convert.ToInt32(lobMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }

                    outputModel.OtherModPremium = outputModel.OtherModPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    // This step will be executed only If calculated Other Mod Premium in step F.1 < LOB Minimum Premium
                    if (outputModel.OtherModPremium < lobMinimumPremium)
                    {
                        outputModel.OtherModPremium = Convert.ToInt32(Math.Round(lobMinimumPremium + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0, MidpointRounding.AwayFromZero));
                    }

                    // Calculate  Suppl. Extended Reporting Unmodified Premium
                    outputModel.ELModifiedFinalPremium = outputModel.OtherModPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    // This step will be executed only If calculated Other Mod Premium is < LOB Minimum Premium
                    if (outputModel.ELModifiedFinalPremium < lobMinimumPremium)
                    {
                        outputModel.ELModifiedFinalPremium = Convert.ToInt32(lobMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                // step 25 ELUnmodifiedWithoutExcessPremium	= Step 13.3 + Step 14.3 + Step 16.5

                decimal eLUnmodifiedWithoutExcessPremium = optionalCoverageOutputModel.IDEAUnmodifiedWithoutExcessPremium
                                                         + optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedWithoutExcessPremium
                                                         + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium;

                if (optionalCoverageOutputModel.EducatorsLegalOtherCoverage != null)
                {
                    eLUnmodifiedWithoutExcessPremium = eLUnmodifiedWithoutExcessPremium + optionalCoverageOutputModel.EducatorsLegalOtherCoverage.Sum(a => a.OtherCoverageUnmodifiedWithoutExcessPremium);
                }

                outputModel.ELUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(eLUnmodifiedWithoutExcessPremium, 0, MidpointRounding.AwayFromZero));

                this._Logger.Info("EducatorsLegalService.CalculateOthersPremium :: Completed");

            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.CalculateOthersPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }


        #region Get Yearfrac

        public decimal YearFrac(DateTime startDate, DateTime endDate)
        {
            int endDay = endDate.Day;
            int startDay = startDate.Day;
            try
            {
                this._Logger.Info("EducatorsLegalService.YearFrac :: Starting");


                if (endDate < startDate)
                {
                    //   throw new ArgumentOutOfRangeException("endDate cannot be less than startDate");
                    return 0;
                }

                switch (startDay)
                {
                    case 31:
                        {
                            startDay = 30;
                            if (endDay == 31)
                            {
                                endDay = 30;
                            }
                        }
                        break;

                    case 30:
                        {
                            if (endDay == 31)
                            {
                                endDay = 30;
                            }
                        }
                        break;

                    case 29:
                        {
                            if (startDate.Month == 2)
                            {
                                startDay = 30;
                                if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                                {
                                    endDay = 30;
                                }
                            }
                        }
                        break;

                    case 28:
                        {
                            if ((startDate.Month == 2) && (!DateTime.IsLeapYear(startDate.Year)))
                            {
                                startDay = 30;
                                if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                                {
                                    endDay = 30;
                                }
                            }
                        }
                        break;
                }
                this._Logger.Info("EducatorsLegalService.YearFrac :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.YearFrac :: Exception :: " + ex.Message, ex);
                throw;
            }
            return (((endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDay - startDay)) / 360);
        }
        #endregion
    }
}
