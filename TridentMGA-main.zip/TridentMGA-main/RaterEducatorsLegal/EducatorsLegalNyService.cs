﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Output;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace RateEducatorsLegal
{
    public class EducatorsLegalNyService : IEducatorsLegalService
    {
        private EducatorsLegalDataAccess _ELDataAccess { get; set; }
        protected new ILoggingManager _Logger { get; private set; }
        protected new IConfiguration configuration { get; private set; }

        public EducatorsLegalNyService(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this._Logger = logger;
            this._ELDataAccess = new EducatorsLegalDataAccess(configuration, logger);
        }
        public DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        public FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EducatorsLegalService.PreValidate :: Starting");
                //var validator = new EducatorsLegalPreValidator(this.configuration, this.logger);
                //var results = validator.Validate(model);
                var results = new FluentValidation.Results.ValidationResult(); // temprary
                this._Logger.Info("EducatorsLegalService.PreValidate :: Completed");
                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.PreValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EmploymentPracticesService.PostValidate :: Starting");
                //var validator = new EducatorsLegalPostValidator(this.configuration, this.logger);
                //var results = validator.Validate(model);
                var results = new FluentValidation.Results.ValidationResult(); // temprary
                this._Logger.Info("EmploymentPracticesService.PostValidate :: Completed");
                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.PostValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region Educators Legel Ny

        public void Calculate(RaterFacadeModel model)
        {
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY;
            try
            {
                #region CalculationEL for NY

                CalculateLiabilityPremiums(model);//todo1

                #endregion

                #region Optional Coverages Premium
                if (inputModel.EducatorsLegalOptionalCoverage != null)
                {
                    CalculateOptionalCoveragePremium(model);
                }
                #endregion

                CalculateOthersPremium(model);
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        private protected void CalculateLiabilityPremiums(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EducatorsLegalService.CalculationEL :: Started");

                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY;
                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                policyHeaderModel.State = policyHeaderModel.State.ToUpper();
                policyHeaderModel.PrimaryClass = policyHeaderModel.PrimaryClass.ToUpper();
                policyHeaderModel.TransactionType = policyHeaderModel.TransactionType.ToUpper();

                // Step 10.3   Get Rating Basis                 
                //State Code, Primary Class
                var dataTableRatingBasis = this._ELDataAccess.GetRatingBasisParameter(policyHeaderModel.State,
                                                                                      policyHeaderModel.PrimaryClass,
                                                                                      inputModel.LineOfBusiness,
                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                      policyHeaderModel.PolicyExpirationDate);

                if (dataTableRatingBasis != null && dataTableRatingBasis.Rows.Count > 0 && dataTableRatingBasis.Rows[0] != null)
                {
                    if (dataTableRatingBasis.Rows[0]["RatingBasis"] != DBNull.Value)
                    {
                        outputModel.RatingBasis = Convert.ToString(dataTableRatingBasis.Rows[0]["RatingBasis"]);
                    }

                    //12.9
                    if (dataTableRatingBasis.Rows[0]["RatingBasisParameter"] != DBNull.Value)
                    {
                        var ratingBasisParameter = Convert.ToDecimal(dataTableRatingBasis.Rows[0]["RatingBasisParameter"]);

                        outputModel.RatingBasisParameter = Convert.ToInt32(Math.Round(ratingBasisParameter, 0, MidpointRounding.AwayFromZero));
                    }
                }

                //Step-11   QUERY  
                //Math.Round((YearFrac(Policy Effective Date, Retro Active Date, 1),0)
                //Ex: If  Policy Eff Date = 05 / 11 / 2020 Retro Date = 05 / 11 / 2015 THEN YearFrac Returns the Value 5.0091. Perform RoundDown Refer to Example in J16 cell
                decimal yearFrac = this.YearFrac(inputModel.RetroDate, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                outputModel.RetroYear = (int)Math.Round(yearFrac, 0);

                // Step 12.10   GetExposureRate                
                // User Entry If the Rater receives a value -Validate the value against the Base Rate Min, Base Rate Max column of the lookup table(To be handled in PreValidations) LookUp
                // If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation               
                if (inputModel.ExposureRate >= 0)
                {
                    outputModel.ExposureRate = inputModel.ExposureRate;
                }
                else
                {
                    DataTable dataTable = _ELDataAccess.GetExposureRateMinMaxFactor(policyHeaderModel.State,
                                                                                   policyHeaderModel.PrimaryClass,
                                                                                   inputModel.LineOfBusiness,
                                                                                   policyHeaderModel.PolicyEffectiveDate,
                                                                                   policyHeaderModel.PolicyExpirationDate);

                    if (dataTable != null && dataTable.Rows.Count > 0 && dataTable.Rows[0]["BaseRate"] != DBNull.Value)
                    {
                        outputModel.ExposureRate = Convert.ToDecimal(dataTable.Rows[0]["BaseRate"]);
                    }
                }

                //  Step 12.11   Get EP Incl / Excl Rate
                //  State Code, EP Coverage(Pass 'EP Coverage' as 'Excluded' to the table), ITEM(Pass 'Exclusion')
                outputModel.EPInclusionExclusionRate = _ELDataAccess.GetELInclusionExclusionRate(policyHeaderModel.State,
                                                                                                 inputModel.LineOfBusiness,
                                                                                                 "Excluded",
                                                                                                 "Exclusion",
                                                                                                 policyHeaderModel.PolicyEffectiveDate,
                                                                                                 policyHeaderModel.PolicyExpirationDate);


                // Step 12.12	Get Liability Limit Rate              
                //Read table using following input parameters to get the Limit factor from column " Default Factor" - State Code, LOB code, Effective Date, Expiration Date, Liability Limit
                if (inputModel.LiabilityLimitRate >= 0)
                {
                    outputModel.LiabilityLimitRate = inputModel.LiabilityLimitRate;
                }
                else
                {
                    DataTable dataTableLimit = _ELDataAccess.GetLiabilityLimitRateMinimum(policyHeaderModel.State,
                                                                                          inputModel.LineOfBusiness,
                                                                                          inputModel.LiabilityLimit,
                                                                                          policyHeaderModel.PolicyEffectiveDate,
                                                                                          policyHeaderModel.PolicyExpirationDate);

                    if (dataTableLimit != null && dataTableLimit.Rows.Count > 0 && dataTableLimit.Rows[0]["Factor"] != DBNull.Value)
                    {
                        outputModel.LiabilityLimitRate = Convert.ToDecimal(dataTableLimit.Rows[0]["Factor"]);
                    }
                }

                // Step 12.13	Get Aggregate Limit Rate
                //- State Code, LOB code, Effective Date, Expiration Date, Liability Limit, Aggregate Limit.             
                outputModel.AggregateLimitRate = _ELDataAccess.GetAggregateLimitRate(policyHeaderModel.State,
                                                                                     inputModel.LineOfBusiness,
                                                                                     policyHeaderModel.PolicyEffectiveDate,
                                                                                     policyHeaderModel.PolicyExpirationDate,
                                                                                     inputModel.LiabilityLimit,
                                                                                     inputModel.AggregateLimit);

                // step 12.14-12.17
                // If EP Coverage  = 'Excluded', Do not use this step
                decimal IncludeBasePremium = 0;
                if (!string.IsNullOrEmpty(inputModel.EPInclusionExclusion) && inputModel.EPInclusionExclusion.ToUpper() != "EXCLUDED")
                {
                    // step 12.14  
                    // step 12.15 Rating Basis Parameter
                    // step 12.16  ExposureRate
                    // step 12.17 Get NYEPInclusionExclusionRate
                    outputModel.NYEPInclusionExclusionRate = _ELDataAccess.GetELInclusionExclusionRate(policyHeaderModel.State,
                                                                                                       inputModel.LineOfBusiness,
                                                                                                       inputModel.EPInclusionExclusion,
                                                                                                       "Inclusion",
                                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                                       policyHeaderModel.PolicyExpirationDate);


                    // Step 12.18  Get NYEPLimitRate
                    if (inputModel.NYEPLimitRate >= 0)
                    {
                        outputModel.NYEPLimitRate = inputModel.NYEPLimitRate;
                    }
                    else
                    {
                        DataTable dataTableNYLimit = _ELDataAccess.GetLiabilityLimitRateMinimum(policyHeaderModel.State,
                                                                                                "EP",
                                                                                                inputModel.LiabilityLimit,
                                                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                                                policyHeaderModel.PolicyExpirationDate);

                        if (dataTableNYLimit != null && dataTableNYLimit.Rows.Count > 0 && dataTableNYLimit.Rows[0]["Factor"] != DBNull.Value)
                        {
                            outputModel.NYEPLimitRate = Convert.ToDecimal(dataTableNYLimit.Rows[0]["Factor"]);
                        }
                    }

                    // Step 12.19  Get NYEPAggregateLimitRate
                    outputModel.NYEPAggregateLimitRate = _ELDataAccess.GetAggregateLimitRate(policyHeaderModel.State,
                                                                                             "EP",
                                                                                             policyHeaderModel.PolicyEffectiveDate,
                                                                                             policyHeaderModel.PolicyExpirationDate,
                                                                                             inputModel.LiabilityLimit,
                                                                                             inputModel.AggregateLimit);
                }


                //  Step 12.20 ,12.21	Get Deductible or SIR RATE                
                outputModel.RetentionRate = _ELDataAccess.GetRetentionRate(policyHeaderModel.State,
                                                                          inputModel.LineOfBusiness,
                                                                          policyHeaderModel.PolicyEffectiveDate,
                                                                          policyHeaderModel.PolicyExpirationDate,
                                                                          inputModel.DeductibleSIR,
                                                                          inputModel.Retention);


                // Step 12.22  Get Population RATE 
                // Use 'Population/ADA'(Step 3) to look up for RATE when PRIMARY CLASS = 'School'
                //Use 'Exposure'(Step 7) instead of 'Population/ADA' to lookup for RATE when PRIMARY CLASS = 'Muni/School Combined'"

                outputModel.PopulationRate = _ELDataAccess.GetPopulationRate(policyHeaderModel.State,
                                                                                 inputModel.LineOfBusiness,
                                                                                 policyHeaderModel.PrimaryClass,
                                                                                 policyHeaderModel.PolicyEffectiveDate,
                                                                                 policyHeaderModel.PolicyExpirationDate,
                                                                                 policyHeaderModel.PopulationADA);

                ///TODO : Uncomment below code once client approved this changes.
                //if (policyHeaderModel.PrimaryClass == PrimaryClassConstant.SC)
                //{
                //    outputModel.PopulationRate = _ELDataAccess.GetPopulationRate(policyHeaderModel.State,
                //                                                                 inputModel.LineOfBusiness,
                //                                                                 policyHeaderModel.PrimaryClass,
                //                                                                 policyHeaderModel.PolicyEffectiveDate,
                //                                                                 policyHeaderModel.PolicyExpirationDate,
                //                                                                 policyHeaderModel.PopulationADA);
                //}
                //else
                //{
                //    outputModel.PopulationRate = _ELDataAccess.GetPopulationRate(policyHeaderModel.State,
                //                                                                 inputModel.LineOfBusiness,
                //                                                                 policyHeaderModel.PrimaryClass,
                //                                                                 policyHeaderModel.PolicyEffectiveDate,
                //                                                                 policyHeaderModel.PolicyExpirationDate,
                //                                                                 inputModel.Exposure);
                //}


                // Step 12.23  Get Location RATE 
                //Read table "Trident.LocationType" using following input parameters to get the Retention Rate from column "LocationFactor"
                //- State Code, LOB code, Effective Date, Expiration Date, LocationType.            
                outputModel.LocationRate = _ELDataAccess.GetLocationRate(policyHeaderModel.State,
                                                                        inputModel.LineOfBusiness,
                                                                        policyHeaderModel.PolicyEffectiveDate,
                                                                        policyHeaderModel.PolicyExpirationDate,
                                                                        policyHeaderModel.LocationType);


                // Step 12.24  Get Policy Type RATE
                //Read table "Trident.PolicyType" using following input parameters to get the Retention Rate from column "Factor"
                //- State Code, LOB code, Effective Date, Expiration Date, PolicyType.            
                outputModel.PolicyTypeRate = _ELDataAccess.GetPolicyTypeRate(policyHeaderModel.State,
                                                                            inputModel.LineOfBusiness,
                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                            policyHeaderModel.PolicyExpirationDate,
                                                                            inputModel.PolicyType);

                // Step 12.25  Get Years in CM Program RATE
                // When Policy Type = Claims Made
                // Refer to the lookup table "Trident.CMPolicyYear" to get the Factor from column "CM Factor" using following input parameters.
                // State Code, LOB code, Effective Date, Expiration Date, Years In CM Program
                // When Policy Type = Occurence Years In CM Rate should be defaulted to 1.000
                outputModel.YearsinCMRate = _ELDataAccess.GetYearsinCMRate(policyHeaderModel.State,
                                                                          inputModel.LineOfBusiness,
                                                                          policyHeaderModel.PolicyEffectiveDate,
                                                                          policyHeaderModel.PolicyExpirationDate,
                                                                          inputModel.YearsinCMProgram);


                // Step 12.26  Get Retro Date RATE 
                string stringRetroYear = string.Empty;
                if (inputModel.PolicyType == "Claims Made")
                {
                    if (outputModel.RetroYear > 5)
                    {
                        stringRetroYear = ">5";
                    }
                    else
                    {
                        stringRetroYear = outputModel.RetroYear.ToString();
                    }
                    outputModel.RetroDateRate = _ELDataAccess.GetRetroDateRate(policyHeaderModel.State,
                                                                              inputModel.LineOfBusiness,
                                                                              policyHeaderModel.PolicyEffectiveDate,
                                                                              policyHeaderModel.PolicyExpirationDate,
                                                                              stringRetroYear);
                }
                else
                {
                    outputModel.RetroDateRate = 1;
                }

                // Step 12.27  Pro Rata Factor (CrossLine)


                // Step 12.7 Calculate Base Premium	 
                // Base Premium =  ROUND( (step 12.8 / step 12.9)	*  step 12.10 *  step 12.11  * step 12.12   * step 12.13) 
                //  + ( Step 12.14  to 12.19)	+  Step (12.20,12.21) * Step 12.22 * Step 12.23 * Step 12.24 * Step 12.25 *  Step 12.26) 

                decimal BasePremium = ((inputModel.Exposure
                                        / outputModel.RatingBasisParameter)
                                        * outputModel.ExposureRate
                                        * outputModel.EPInclusionExclusionRate
                                        * outputModel.LiabilityLimitRate
                                        * outputModel.AggregateLimitRate)
                                        + ((inputModel.Exposure
                                        / outputModel.RatingBasisParameter)
                                        * outputModel.ExposureRate
                                        * outputModel.NYEPInclusionExclusionRate
                                        * outputModel.NYEPLimitRate
                                        * outputModel.NYEPAggregateLimitRate)
                                        + outputModel.RetentionRate
                                        * outputModel.PopulationRate
                                        * outputModel.LocationRate
                                        * outputModel.PolicyTypeRate
                                        * outputModel.YearsinCMRate
                                        * outputModel.RetroDateRate;

                outputModel.BasePremium = (int)Math.Round(BasePremium, 0, MidpointRounding.AwayFromZero);
                // end step 12 

                this._Logger.Info("EducatorsLegalService.ELCalculation :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.ELCalculation :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        private protected void CalculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EducatorsLegal.CalculateOptionalCoveragePremium :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                var optionalCoverageOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage;
                var optionalCoverageInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage;

                decimal ProRataFactor = 1;

                // Step-13 Suppl.Extended Reporting Period Limit  -User Entry
                //if (optionalCoverageInputModel.SupplExtendedReportingPeriodIsSelected)
                //{
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodIsSelected = optionalCoverageInputModel.SupplExtendedReportingPeriodIsSelected;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodAggregateLimit = optionalCoverageInputModel.SupplExtendedReportingPeriodAggregateLimit;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodDeductible = optionalCoverageInputModel.SupplExtendedReportingPeriodDeductible;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodLimit = optionalCoverageInputModel.SupplExtendedReportingPeriodLimit;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodModifiedPremium = optionalCoverageInputModel.SupplExtendedReportingPeriodModifiedPremium;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodRate = optionalCoverageInputModel.SupplExtendedReportingPeriodRate;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodRatingBasis = optionalCoverageInputModel.SupplExtendedReportingPeriodRatingBasis;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodReturnMethod = optionalCoverageInputModel.SupplExtendedReportingPeriodReturnMethod;
                //    optionalCoverageOutputModel.SupplExtendedReportingPeriodInverseCondemnationIncludedInExcessExposure = optionalCoverageInputModel.SupplExtendedReportingPeriodIncludedInExcessExposure;


                //    // Step 13.4   Apply Prorata Factor - (Cross Line)
                //    //  Step 14 Get Limit(Non Monetary Defense Limit) - User Entry
                //}

                #region Step 14 Calculate Other Premium 

                if (optionalCoverageInputModel.EducatorsLegalOtherCoverage != null)
                {
                    CalculateOtherOptionalCoveragePremium(model, ProRataFactor);
                }

                #endregion

                // start step 15 
                //Sum of all the added optional coverage premium   
                decimal othersUnmodifiedPremium = optionalCoverageOutputModel.EducatorsLegalOtherCoverage != null ? optionalCoverageOutputModel.EducatorsLegalOtherCoverage.Sum(x => x.OtherCoverageUnmodifiedPremium) : 0;

                optionalCoverageOutputModel.OtherCoverageTotalPremium = Convert.ToInt32(othersUnmodifiedPremium + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium);
                // end step 15

                // Start Step 16 Get NonModifiedPremium = ROUND(
                // Step 16.1   Refer to Step 15        Optional Coverages Premium)  

                outputModel.NonModifiedPremium = (int)Math.Round(othersUnmodifiedPremium, 0, MidpointRounding.ToZero);

                // Start Step 17 

                this._Logger.Info("EducatorsLegalService.CalculateOptionalCoveragePremium :: Completed");

            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.ELCalculation :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
        #endregion 

        #region Get Yearfrac
        public decimal YearFrac(DateTime startDate, DateTime endDate)
        {
            int endDay = endDate.Day;
            int startDay = startDate.Day;
            try
            {
                this._Logger.Info("EducatorsLegalService.YearFrac :: Starting");


                if (endDate < startDate)
                {
                    //   throw new ArgumentOutOfRangeException("endDate cannot be less than startDate");
                    return 0;
                }

                switch (startDay)
                {
                    case 31:
                        {
                            startDay = 30;
                            if (endDay == 31)
                            {
                                endDay = 30;
                            }
                        }
                        break;

                    case 30:
                        {
                            if (endDay == 31)
                            {
                                endDay = 30;
                            }
                        }
                        break;

                    case 29:
                        {
                            if (startDate.Month == 2)
                            {
                                startDay = 30;
                                if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                                {
                                    endDay = 30;
                                }
                            }
                        }
                        break;

                    case 28:
                        {
                            if ((startDate.Month == 2) && (!DateTime.IsLeapYear(startDate.Year)))
                            {
                                startDay = 30;
                                if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                                {
                                    endDay = 30;
                                }
                            }
                        }
                        break;
                }
                this._Logger.Info("EducatorsLegalService.YearFrac :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.YearFrac :: Exception :: " + ex.Message, ex);
                throw;
            }
            return (((endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDay - startDay)) / 360);
        }
        #endregion

        #region Optional Coverage  
        private protected void CalculateOtherOptionalCoveragePremium(RaterFacadeModel model, decimal ProRataFactor)
        {
            this._Logger.Info("EducatorsLegalService.CalculateOtherOptionalCoveragePremium :: Starting");
            try
            {
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal;
                var inputmodel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY;

                var optionalCoverageOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage;
                List<EducatorsLegalOtherCoverageOutputModel> otherCoverageOutputModelList = new List<EducatorsLegalOtherCoverageOutputModel>();
                List<EducatorsLegalNyOtherCoverageInputModel> otherCoverageInputModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage;
                foreach (var otherCoverageInput in otherCoverageInputModelList)
                {
                    EducatorsLegalOtherCoverageOutputModel otherCoverage = new EducatorsLegalOtherCoverageOutputModel();

                    // User Entry
                    otherCoverage.OtherCoverageID = otherCoverageInput.OtherCoverageID;
                    otherCoverage.OtherCoverageDescription = otherCoverageInput.OtherCoverageDescription;
                    otherCoverage.OtherCoverageDeductible = otherCoverageInput.OtherCoverageDeductible;
                    otherCoverage.OtherCoverageRatingBasis = otherCoverageInput.OtherCoverageRatingBasis;
                    otherCoverage.OtherCoverageReturnMethod = otherCoverageInput.OtherCoverageReturnMethod;
                    otherCoverage.OtherCoverageRate = otherCoverageInput.OtherCoverageRate;
                    otherCoverage.OtherCoverageLimit = otherCoverageInput.OtherCoverageLimit;
                    otherCoverage.OtherCoverageAggregateLimit = otherCoverageInput.OtherCoverageAggregateLimit;
                    otherCoverage.OtherCoverageModifiedPremium = otherCoverageInput.OtherCoverageModifiedPremium;
                    otherCoverage.OtherCoverageIncludedInExcessExposure = otherCoverageInput.OtherCoverageIncludedInExcessExposure;

                    //  Step 14.2   Get Other Coverage Rate User Entry when  OtherCoverageRatingBasis is PER 100 OF LIMIT and PER 1000 OF LIMIT
                    if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT" || otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                    {
                        otherCoverage.OtherCoverageRate = otherCoverageInput.OtherCoverageRate;
                    }

                    // Step 14.5 Other Premium
                    // When Rating basis is 'Flat charge' then Other Coverage Unmodified Premium
                    if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARGE")
                    {
                        otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = otherCoverageInput.OtherCoverageUnmodifiedPremium;
                    }
                    // When Rating basis is 'per 1000 of limit'
                    else if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                    {
                        // Rate * (Limit/1000)
                        otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(otherCoverage.OtherCoverageRate * (otherCoverage.OtherCoverageLimit / 1000));
                    }
                    // When Rating basis is 'per 100 of limit'
                    else if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                    {
                        // Rate * (Limit/100)
                        otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(otherCoverage.OtherCoverageRate * (otherCoverage.OtherCoverageLimit / 100));
                    }
                    // When Rating basis is 'No Charge'
                    else if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                    {
                        //step 1
                        otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = 0;
                    }

                    otherCoverage.OtherCoverageUnmodifiedPremium = Convert.ToInt32(otherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium);

                    //step 14.6
                    // If input value is blank then Refer to lookup table. otherwise "Other Coverage Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(otherCoverageInput.OtherCoverageIncludedInExcessExposure))
                    {
                        otherCoverage.OtherCoverageIncludedInExcessExposure = this._ELDataAccess.GetExcessExposure(policyHeaderModel.State,
                                                                                                                   policyHeaderModel.PrimaryClass,
                                                                                                                   inputmodel.LineOfBusiness,                                                                                                                   
                                                                                                                   "Other",
                                                                                                                   policyHeaderModel.PolicyEffectiveDate,
                                                                                                                   policyHeaderModel.PolicyExpirationDate);
                    }

                    // If LineOfBusiness Excess = True and Liability Limit = 1,000,000
                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputmodel.LiabilityLimit == 1000000)
                    {
                        //step 14.7 Other Coverage Un-Modified Premium
                        // If Other Coverage Included In Excess Exposure = TRUE
                        if (!string.IsNullOrEmpty(otherCoverage.OtherCoverageIncludedInExcessExposure) && otherCoverage.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            otherCoverage.OtherCoverageUnmodifiedPremium = 0;
                        }
                    }
                    //end step 14 

                    otherCoverageOutputModelList.Add(otherCoverage);
                }
                optionalCoverageOutputModel.EducatorsLegalOtherCoverage = otherCoverageOutputModelList;
                this._Logger.Info("EmploymentPracticesService.CalculateOtherOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EducatorsLegalService.ELCalculation :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
        #endregion

        /// <summary>
        /// CalculateOthersPremium
        /// </summary>
        /// <param name="model"></param>
        private void CalculateOthersPremium(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EducatorsLegalService.CalculateOthersPremium :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY;
                var optionalCoverageOutputModel = outputModel.EducatorsLegalOptionalCoverage;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                // Step 17.3   Apply Minimum Premium rules 
                // Read Minimum Premium lookup table to get Minimum Premium
                decimal LOBMinimumPremium = _ELDataAccess.GetLOBTotalPremium(policyHeaderModel.State,
                                                                            inputModel.LineOfBusiness,
                                                                            policyHeaderModel.PrimaryClass,
                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                            policyHeaderModel.PolicyExpirationDate);

                // 	Calculate Manual Premium (Refer to Step 12.7 and Refer to Step 16)                 
                outputModel.ManualPremium = outputModel.BasePremium + outputModel.NonModifiedPremium;

                if (outputModel.ManualPremium < LOBMinimumPremium)
                {
                    outputModel.ManualPremium = Convert.ToInt32(LOBMinimumPremium);
                }

                // Step-18.4  TerrorismRate         
                outputModel.TierRate = _ELDataAccess.GetTierRate(policyHeaderModel.State,
                                                                 inputModel.LineOfBusiness,
                                                                 policyHeaderModel.PolicyEffectiveDate,
                                                                 policyHeaderModel.PolicyExpirationDate,
                                                                 model.RaterInputFacadeModel.PricingInputModel.TierPlan);

                // Step 18 Calculate Tier Premium
                // ((Step 18.2 - Step 18.3) *  Step 18.4) + Step 18.5 
                outputModel.TierPremium = Convert.ToInt32(Math.Round(((outputModel.ManualPremium
                                                                     - outputModel.NonModifiedPremium)
                                                                     * outputModel.TierRate
                                                                     + outputModel.NonModifiedPremium)
                                                                     , 0
                                                                     , MidpointRounding.AwayFromZero));

                // This step will be executed only If calculated Tier Premium is < LOB Minimum Premium
                if (outputModel.TierPremium < LOBMinimumPremium)
                {
                    outputModel.TierPremium = Convert.ToInt32(LOBMinimumPremium);
                }

                // Step 19.3 Calculate IRPM Rate                 
                outputModel.IRPMFactor = inputModel.IRPMFactor;

                //  Step 19  Calculate IRPM Premium
                // Step 19.1 - Step 19.2 * Step 19.3 + Step 19.4
                outputModel.IRPMPremium = Convert.ToInt32(Math.Round(((outputModel.TierPremium
                                                                     - outputModel.NonModifiedPremium)
                                                                     * outputModel.IRPMFactor
                                                                     + outputModel.NonModifiedPremium)
                                                                     , 0
                                                                     , MidpointRounding.AwayFromZero));

                // This step will be executed only If calculated IRPM Premium is < LOB Minimum Premium
                if (outputModel.IRPMPremium < LOBMinimumPremium)
                {
                    outputModel.IRPMPremium = Convert.ToInt32(LOBMinimumPremium);
                }

                //  step 20.3  Calculate OtherMod Rate
                outputModel.OtherModRate = inputModel.OtherModRate;

                //  Step 20 Other Mod Premium Calculation
                // ((Step 20.1 - Step 20.2)  * (Step 20.3 + Step 20.4))
                decimal otherModPremium = Convert.ToDecimal(((outputModel.IRPMPremium -
                                                              outputModel.NonModifiedPremium) *
                                                              outputModel.OtherModRate) +
                                                              outputModel.NonModifiedPremium);

                otherModPremium = Math.Round(otherModPremium, 0, MidpointRounding.AwayFromZero);

                outputModel.OtherModPremium = Convert.ToInt32(otherModPremium);

                // This step will be executed only If calculated Other Mod Premium in step F.1 < LOB Minimum Premium
                if (outputModel.OtherModPremium < LOBMinimumPremium)
                {
                    outputModel.OtherModPremium = Convert.ToInt32(LOBMinimumPremium);
                }

                //  Step 21 Calculate Terrorism Premium Calculation
                //Step 20 * Step 16 Get Terrorism Factor
                if (model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected)
                {
                    outputModel.TerrorismPremium = Convert.ToInt32(outputModel.OtherModPremium * outputModel.TerrorismRate);
                }

                // Step 22	Calculate  Final EL Premium     
                //  (Step 20 + Step 21)
                outputModel.ELModifiedFinalPremium = outputModel.TerrorismPremium + outputModel.OtherModPremium;

                // This step will be executed only If calculated Other Mod Premium is < LOB Minimum Premium
                if (outputModel.ELModifiedFinalPremium < LOBMinimumPremium)
                {
                    outputModel.ELModifiedFinalPremium = Convert.ToInt32(LOBMinimumPremium);
                }

                //  check If Suppl. Extended Reporting Period Is Selected then
                if (inputModel.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodIsSelected)
                {
                    // Calculate Suppl. Extended Reporting Period Unmodified Premium
                    outputModel.ManualPremium = outputModel.ManualPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    // This step will be executed only If calculated Manual Premium is < LOB Minimum Premium
                    if (outputModel.ManualPremium < LOBMinimumPremium)
                    {
                        outputModel.ManualPremium = Convert.ToInt32(LOBMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }

                    // Calculate Suppl. Extended Reporting Period Unmodified Premium
                    outputModel.TierPremium = outputModel.TierPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    // This step will be executed only If calculated Tier Premium is < LOB Minimum Premium
                    if (outputModel.TierPremium < LOBMinimumPremium)
                    {
                        outputModel.TierPremium = Convert.ToInt32(LOBMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }

                    // Calculate  Suppl. Extended Reporting Unmodified Premium
                    outputModel.IRPMPremium = outputModel.IRPMPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    // This step will be executed only If calculated IRPM Premium is < LOB Minimum Premium
                    if (outputModel.IRPMPremium < LOBMinimumPremium)
                    {
                        outputModel.IRPMPremium = Convert.ToInt32(LOBMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }

                    // Calculate Suppl. Extended Reporting Unmodified Premium
                    outputModel.OtherModPremium = outputModel.TierPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    // This step will be executed only If calculated Other Mod Premium in step C.1 < LOB Minimum Premium
                    if (outputModel.OtherModPremium < LOBMinimumPremium)
                    {
                        outputModel.OtherModPremium = Convert.ToInt32(LOBMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }

                    // Calculate  Suppl. Extended Reporting Unmodified Premium
                    outputModel.ELModifiedFinalPremium = outputModel.OtherModPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    // This step will be executed only If calculated Other Mod Premium is < LOB Minimum Premium
                    if (outputModel.ELModifiedFinalPremium < LOBMinimumPremium)
                    {
                        outputModel.ELModifiedFinalPremium = Convert.ToInt32(LOBMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                // end step 22
                // step 23 ELNYUnmodifiedWithoutExcessPremium = Step 14.5
                if (optionalCoverageOutputModel.EducatorsLegalOtherCoverage != null)
                {
                    decimal eLUnmodifiedWithoutExcessPremium = optionalCoverageOutputModel.EducatorsLegalOtherCoverage.Sum(a => a.OtherCoverageUnmodifiedWithoutExcessPremium);

                    outputModel.ELNYUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(eLUnmodifiedWithoutExcessPremium, 0, MidpointRounding.AwayFromZero));
                }
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesSchoolService.CalculateOthersPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
    }
}
