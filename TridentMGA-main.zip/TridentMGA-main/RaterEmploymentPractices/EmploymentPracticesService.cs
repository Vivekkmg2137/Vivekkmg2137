﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPracticesOutput;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Validations;

namespace RaterEmploymentPractices
{
    /// <summary>
    /// EmploymentPracticesService
    /// </summary>
    public class EmploymentPracticesService : IEmploymentPractices
    {
        /// <summary>
        /// DataAccess object
        /// </summary>
        private EmploymentPracticesDataAccess _DataAccess { get; set; }

        /// <summary>
        /// Logger object
        /// </summary>
        protected ILoggingManager _Logger { get; private set; }

        /// <summary>
        /// Configuration object
        /// </summary>
        protected IConfiguration _Configuration { get; private set; }

        /// <summary>
        /// Employment Practices Service
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public EmploymentPracticesService(IConfiguration configuration, ILoggingManager logger)
        {
            this._Configuration = configuration;
            this._Logger = logger;
            this._DataAccess = new EmploymentPracticesDataAccess(configuration, logger);
        }

        /// <summary>
        /// ExecuteDomainRules
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public virtual DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            this._Logger.Info("EmploymentPracticesService.ExecuteDomainRules :: Starting");

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            this._Logger.Info("EmploymentPracticesService.ExecuteDomainRules :: Completed");

            return validationResult;
        }

        /// <summary>
        /// Pre Validate
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public virtual FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EmploymentPracticesService.PreValidate :: Starting");

                var validator = new EmploymentPracticesPreValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);

                this._Logger.Info("EmploymentPracticesService.PreValidate :: Completed");

                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesService.PreValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Post Validate
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public virtual FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EmploymentPracticesService.PostValidate :: Starting");

                var validator = new EmploymentPracticesPostValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);

                this._Logger.Info("EmploymentPracticesService.PostValidate :: Completed");

                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesService.PostValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region EmploymentPractices

        /// <summary>
        /// Calculate
        /// </summary>
        /// <param name="model"></param>
        public void Calculate(RaterFacadeModel model)
        {
            this._Logger.Info("EmploymentPracticesService.Calculate :: Starting");

            try
            {
                #region Liablity Premium 

                CalculateLiablityPremium(model);

                #endregion

                #region Optional Coverages Premium

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel != null)
                {
                    CaculateOptionalCoveragePremium(model);
                }

                #endregion

                CalculateOthersPremium(model);

                this._Logger.Info("EmploymentPracticesService.Calculate :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Liablity Premium
        /// </summary>
        /// <param name="model"></param>
        /// <param name="outputModel"></param>
        public void CalculateLiablityPremium(RaterFacadeModel model)
        {
            this._Logger.Info("EmploymentPracticesService.CalculateLiablityPremium :: Starting");

            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

            policyHeaderModel.State = policyHeaderModel.State.ToUpper();
            policyHeaderModel.PrimaryClass = policyHeaderModel.PrimaryClass.ToUpper();
            policyHeaderModel.TransactionType = policyHeaderModel.TransactionType.ToUpper();

            //step 1
            //If Primary Class = "SC"
            //Rating Basis is "Per Student".
            //Else
            //Rating Basis is "Per $1,000 of Adjusted Gross Operating Expenditures/Payroll"
            //When  Primary Class = MU, CO, WSU, EGU, SP, FD, MSC, PNP :- Then Exposure = (Input / 1000)
            //When Primary Class = School(SC) :-Then Exposure = Input
            string[] primaryClassExperience = new string[8] { "MU", "CO", "WSU", "EGU", "SP", "FD", "MSC", "PNP" };

            outputModel.RatingBasis = "Per $1,000 of Adjusted Gross Operating Expenditures/Payroll";

            if (policyHeaderModel.PrimaryClass == "SC")
            {
                outputModel.RatingBasis = "Per Student";
            }

            if (primaryClassExperience.Contains(policyHeaderModel.PrimaryClass))
            {
                inputModel.Exposure = inputModel.Exposure / 1000;
            }

            //step2
            //If State is MO, there is a defined fixed rate w.r.t. Primary Class & rate will be pulled from ""trident.ProflLineBaseRate"" table.
            //Read table using State Code, LOB, Primary Class & Effective & Expiration Date to get the rate from 'Default Rate' column.

            //For all other states, the rate can be entered in ""Exposure Rate"" UI field &Rater will pull the rate from this UI field . 
            //Read table using following parameters to get the Min Rate & Max rate range from columns ""Base Rate Min"" & ""Base Rate Max"" respectively
            //tate Code, LOB, Primary Class &Effective & Expiration Date

            //NOTE -
            // 1# When input json has less than zero value for the Exposure Rate , the rater will 
            //(a) refer to the lookup table to identify the default rate
            //(b) use the default rate to calculate premium and
            //(c) pass the default rate in the output JSON for the UI.
            //2#  When input json has exposure rate value ≥ 0.0, the rater will
            //(a) verify that the state allows a range <= 0 and if it does not, then pass back an error.
            //(b)verify that the state allows a range and if it does then  -verifies that the value passed is within the acceptable range, if it is not, then pass back an error
            //(c) verify that the state allows a range and if it does then-> verifies that the value passed is within the acceptable range -> uses the passed value to calculate premium and -> pass back the same rate in the JSON output that was passed in the input"

            if (policyHeaderModel.State == StateCodeConstant.MO || inputModel.ExposureRate < 0)
            {
                DataTable dataTable = _DataAccess.GetExposureRateMinMaxFactor(policyHeaderModel.State,
                                                                              policyHeaderModel.PrimaryClass,
                                                                              inputModel.LineOfBusiness,
                                                                              policyHeaderModel.PolicyEffectiveDate,
                                                                              policyHeaderModel.PolicyExpirationDate);

                if (dataTable == null)
                {
                    outputModel.ExposureRate = 0;
                }
                else
                {
                    if (dataTable.Rows[0]["BaseRate"] != DBNull.Value)
                    {
                        outputModel.ExposureRate = Convert.ToDecimal(dataTable.Rows[0]["BaseRate"]);
                    }
                }
            }
            else
            {
                outputModel.ExposureRate = inputModel.ExposureRate;
            }

            //Step-3
            //Read table " Trident.EPInclExcl" using following input parameters to get the factor from column named as "Factor"
            //State Code, LOB, Effective Date, Expiration Date
            outputModel.EPInclusionExclusionRate = this._DataAccess.GetEPInclusionExclusionRateFactor(policyHeaderModel.State,
                                                                                                      inputModel.LineOfBusiness,
                                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                                      policyHeaderModel.PolicyExpirationDate);

            //Step-4
            //For State = KS, MO
            //Rate will be pulled from lookup table  Trident.ProfLineLimit" 
            //Read table using following input parameters to get the Limit factor from column " Default Factor"
            //- State Code, LOB code, Effective Date, Expiration Date, Liability Limit

            //For State = AL, CO, CT, DE, GA IL IN, MA, ME, MI, MN, MS, NC, NH, OH, PA, SC, TX, UT, VT, WY
            //Rater will pull the Limit factor from Liability Limit Rate UI field
            //Read table "Trident.ProfLineLimit" using following parameters to get the Min Rate & Max rate range from columns "MINIMUM FACTOR" & "MAXIMUM FACTOR" respectively
            //- State Code, LOB, Liability Limit &Effective & Expiration Date

            string[] stateCodes = new string[21] { "AL", "CO", "CT", "DE", "GA", "IL", "IN", "MA", "ME", "MI", "MN", "MS", "NC", "NH", "OH", "PA", "SC", "TX", "UT", "VT", "WY" };

            if ((policyHeaderModel.State == StateCodeConstant.MO || policyHeaderModel.State == StateCodeConstant.KS) || inputModel.LiabilityLimitRate < 0)
            {
                DataTable dataTable = _DataAccess.GetLiabilityLimitRateMinimumFactor(policyHeaderModel.State,
                                                                                     inputModel.LineOfBusiness,
                                                                                     inputModel.LiabilityLimit,
                                                                                     policyHeaderModel.PolicyEffectiveDate,
                                                                                     policyHeaderModel.PolicyExpirationDate);

                if (dataTable == null)
                {
                    outputModel.LiabilityLimitRate = 0;
                }
                else
                {
                    if (dataTable.Rows[0]["Factor"] != DBNull.Value)
                    {
                        outputModel.LiabilityLimitRate = Convert.ToDecimal(dataTable.Rows[0]["Factor"]);
                    }
                }
            }
            else if (stateCodes.Contains(policyHeaderModel.State))
            {
                outputModel.LiabilityLimitRate = inputModel.LiabilityLimitRate;
            }

            //Step-5
            //Read table "Trident.ProfLinesAggregateLimit" using following input parameters to get the Aggregate Limit factor from column "Rate"
            //State Code, LOB code, Effective Date, Expiration Date, Liability Limit, Aggregate Limit.

            outputModel.AggregateLimitRate = this._DataAccess.GetAggregateLimitRateFactor(policyHeaderModel.State,
                                                                                          inputModel.LineOfBusiness,
                                                                                          policyHeaderModel.PolicyEffectiveDate,
                                                                                          policyHeaderModel.PolicyExpirationDate,
                                                                                          inputModel.LiabilityLimit,
                                                                                          inputModel.AggregateLimit);

            //Step-6
            // Refer to "Deductible / SIR" input in json to determine if SIR OR Deductible has to pass for DeductibleSIR column.
            // Refer to table "Trident.SIR" using following input parameter to get the Retention factor from column named as 'Factor'.
            // StateCode, Line of Business, Effective Date, Expiration Date,Deductible / SIR, Retention

            outputModel.RetentionRate = this._DataAccess.GetRetentionRateFactor(policyHeaderModel.State,
                                                                                inputModel.LineOfBusiness,
                                                                                inputModel.DeductibleSIR,
                                                                                inputModel.Retention.ToString(),
                                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                                policyHeaderModel.PolicyExpirationDate);

            //Step-7
            //Read table "Trident.PopulationFactor" using following input paratmeters and get the population Factor from column "Rate"
            //StateCode, Line of Business, Effective Date, Expiration Date, Primary Class, Population
            //Use Population Range Min &Population range Max columns to compare the  Population UI field value &found the range in which entered population is falling.Use the population Factor associated with that range.

            outputModel.PopulationRate = this._DataAccess.GetPopulationRateFactor(policyHeaderModel.State,
                                                                                  inputModel.LineOfBusiness,
                                                                                  policyHeaderModel.PrimaryClass,
                                                                                  policyHeaderModel.PopulationADA,
                                                                                  policyHeaderModel.PolicyEffectiveDate,
                                                                                  policyHeaderModel.PolicyExpirationDate);

            //Step-8
            //Refer to the lookup table "Trident.LocationType" to get the Location Factor from column "Location Factor" using following input parameters.
            //State Code, LOB code, Effective Date, Expiration Date, Location Type

            outputModel.LocationRate = this._DataAccess.GetEPLocationRate(policyHeaderModel.State,
                                                                          inputModel.LineOfBusiness,
                                                                          policyHeaderModel.LocationType,
                                                                          policyHeaderModel.PolicyEffectiveDate,
                                                                          policyHeaderModel.PolicyExpirationDate);


            //Step-9
            //Refer to the lookup table "Trident.PolicyType" to get the Policy Type Factor from column "Factor" using following input parameters.
            //State Code, LOB code, Effective Date, Expiration Date, Policy Type

            outputModel.PolicyTypeRate = this._DataAccess.GetEPPolicyTypeRateFactor(policyHeaderModel.State,
                                                                                    inputModel.LineOfBusiness,
                                                                                    inputModel.PolicyType,
                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                    policyHeaderModel.PolicyExpirationDate);

            //Step-10
            //When Policy Type = Claims Made
            //Refer to the lookup table "Trident.CMPolicyYear" to get the Factor from column "CM Factor" using following input parameters.
            //State Code, LOB code, Effective Date, Expiration Date, Years In CM Program
            //When Policy Type = Occurence Years In CM Rate should be defaulted to 1.000

            if (inputModel.PolicyType.ToUpper() == "CLAIMS MADE")
            {
                outputModel.YearsinCMRate = this._DataAccess.GetEPYearsinCMRateFactor(policyHeaderModel.State,
                                                                                      inputModel.LineOfBusiness,
                                                                                      inputModel.YearsinCMProgram,
                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                      policyHeaderModel.PolicyExpirationDate);
            }
            else if (inputModel.PolicyType.ToUpper() == "OCCURRENCE")
            {
                outputModel.YearsinCMRate = 1;
            }

            //Step-11
            //When Policy Type = Claims Made, calculate the Retro Date Factor
            //Step 1 - Calculate the RetroYear by using formula "ROUNDDOWN(YearFrac(Policy Effective Date, Retro Active Date, 1)0)
            //Step 2 - Read table "Trident.RetroDateFactor" to get the Retro Factor from column"Factor" using following input parameters: State Code, LOB Code, Effective Date, Expiration Date & RetroYear
            //Note - If the Retro Year is greater than 6 Pass the value '>6' to the table
            //When Policy Type = Occurrence Apply 1.00 as the Retro Date rate

            // Step 11.1

            decimal yearFrac = this.YearFrac(inputModel.RetroActiveDate, policyHeaderModel.PolicyEffectiveDate);
            outputModel.RetroYear = Convert.ToInt32(Math.Round(yearFrac, 0));

            if (inputModel.PolicyType.ToUpper() == "CLAIMS MADE")
            {
                // Step 11.2
                string stringRetroYear = outputModel.RetroYear.ToString();

                if (outputModel.RetroYear > 6)
                {
                    stringRetroYear = ">6";
                }

                outputModel.RetroDateRate = this._DataAccess.GetEPRetroDateRateFactor(policyHeaderModel.State,
                                                                                      inputModel.LineOfBusiness,
                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                      policyHeaderModel.PolicyExpirationDate,
                                                                                      stringRetroYear);
            }
            else if (inputModel.PolicyType.ToUpper() == "OCCURRENCE")
            {
                outputModel.RetroDateRate = 1;
            }

            //Step -12
            //When State = CT, DE, ME, MA, NH, VT
            //Read table " Trident.ProfLinesLossExperience" to get the Loss Experience rate from column "Experience Factor" using following input parameters.
            //State Code, LOB Code, Effective Date, Expiration Date, Loss Experience Applied(if checkbox is selected, return True / Binary True else return False / Binary False).
            //CT, DE, ME, MA, NH, VT

            string[] stateCheckProfLinesLossExperience1 = new string[6] { "CT", "DE", "ME", "MA", "NH", "VT" };
            string[] stateCheckProfLinesLossExperience2 = new string[17] { "AL", "CO", "GA", "KS", "MI", "MN", "MS", "MO", "NC", "IL", "IN", "OH", "PA", "SC", "TX", "UT", "WY" };

            int lossExperienceIsSelected = inputModel.LossExperienceIsSelected ? 1 : 0;

            if (stateCheckProfLinesLossExperience1.Contains(policyHeaderModel.State))
            {
                outputModel.LossExperienceRate = this._DataAccess.GetEPSLossExperienceRate(policyHeaderModel.State,
                                                                                           inputModel.LineOfBusiness,
                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                           policyHeaderModel.PolicyExpirationDate,
                                                                                           lossExperienceIsSelected);
            }

            //When State = AL, CO, GA, KS, MI, MN, MS, MO, NC, IL, IN, OH, PA, SC, TX, UT, WY 
            //Read table "Trident.ProfLinesLossExperience" to get the Loss Experience rate from column "Experience Factor" using following input parameters.
            //State Code, LOB Code, Effective Date, Expiration Date.
            //AL, CO, GA, KS, MI, MN, MS, MO, NC, IL, IN, OH, PA, SC, TX, UT, WY 

            else if (stateCheckProfLinesLossExperience2.Contains(policyHeaderModel.State))
            {
                outputModel.LossExperienceRate = this._DataAccess.GetEPSLossExperienceRate(policyHeaderModel.State,
                                                                                           inputModel.LineOfBusiness,
                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                           policyHeaderModel.PolicyExpirationDate,
                                                                                           null);
            }

            //Step- 13
            //Pro-rata factor to be rounded to 3 digits
            //Todo ProRataFactor not exits
            //outputModel.ProRataFactor = 0;

            //Step-14
            //zero
            //Terrorism Factor doesn't apply.
            outputModel.TerrorismRate = 0;

            //Step-15
            // Read table "Trident.TierFactors" to get the Tier Rate from column "Tier Factor" using following input parameters:
            // For States -CT, DE, ME, MA, NH, VT
            // State Code, LOB Code, Effective Date, Expiration Date, Tier Plan Applies

            string[] stateCheckTierFactors1 = new string[6] { "CT", "DE", "ME", "MA", "NH", "VT" };

            string[] stateCheckTierFactors2 = new string[17] { "AL", "CO", "GA", "KS", "MI", "MN", "MS", "MO", "NC", "IL", "IN", "OH", "PA", "SC", "TX", "UT", "WY" };

            outputModel.TierRate = 0;

            if (stateCheckTierFactors1.Contains(policyHeaderModel.State))
            {
                outputModel.TierRate = this._DataAccess.GetEPTierRate(policyHeaderModel.State,
                                                                      inputModel.LineOfBusiness,
                                                                      model.RaterInputFacadeModel.PricingInputModel.TierPlan,
                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                      policyHeaderModel.PolicyExpirationDate);

            }
            else if (stateCheckTierFactors2.Contains(policyHeaderModel.State))
            {
                outputModel.TierRate = this._DataAccess.GetEPTierRate(policyHeaderModel.State,
                                                                      inputModel.LineOfBusiness,
                                                                      null,
                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                      policyHeaderModel.PolicyExpirationDate);
            }

            //Step-16
            //Input IRPM Factor
            outputModel.IRPMRate = inputModel.IRPMFactor;

            //Step-17
            //Other Mod Factor
            outputModel.OtherModRate = inputModel.OtherModFactor;

            this._Logger.Info("EmploymentPracticesService.CalculateLiablityPremium :: Completed");
        }

        /// <summary>
        /// Caculate Optional Coverage Premium
        /// </summary>
        /// <param name="model"></param>
        /// <param name="outputModel"></param>
        public void CaculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

            this._Logger.Info("EmploymentPracticesService.CaculateOptionalCoveragePremium :: Starting");

            decimal proRataFactor = 1;

            try
            {
                string[] stateCheckBackWagesFactors = new string[1];

                #region Optional Coverage I - Back Wages

                //Step-1
                //Back Wages
                //Back Wages Unmodified Premium
                //(Input) * Step 13
                //This coverage is applicable for States = AL, CO, GA, KS, MI, MN, MS, MO, IL , IN, NC, OH, PA, SC, TX, UT, WY

                stateCheckBackWagesFactors = new string[17] { "AL", "CO", "GA", "KS", "MI", "MN", "MS", "MO", "NC", "IL", "IN", "OH", "PA", "SC", "TX", "UT", "WY" };

                if (inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesIsSelected && stateCheckBackWagesFactors.Contains(policyHeaderModel.State))
                {
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesIsSelected = inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesIsSelected;
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesAggregateLimit = inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesAggregateLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesDeductible = inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesDeductible;
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesLimit = inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesModifiedPremium = inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesModifiedPremium;
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesRate = inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesRate;
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesRatingBasis = inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesRatingBasis;
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesReturnMethod = inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesReturnMethod;
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesIncludedInExcessExposure = inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesIncludedInExcessExposure;

                    //step 1
                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium
                                                                                                                                               * proRataFactor)
                                                                                                                                               , 0
                                                                                                                                               , MidpointRounding.AwayFromZero));

                    outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium = outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesUnModifiedWithoutExcessPremium;

                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(inputModel.EmploymentPracticesOptionalCoverageModel.BackWagesIncludedInExcessExposure))
                    {
                        outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesIncludedInExcessExposure = this._DataAccess.GetEPCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                                                inputModel.LineOfBusiness,
                                                                                                                                                                "Back Wages",
                                                                                                                                                                policyHeaderModel.PrimaryClass,
                                                                                                                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                policyHeaderModel.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == 1000000)
                    {
                        //step 3
                        // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                        if (!string.IsNullOrEmpty(outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesIncludedInExcessExposure) && outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium = 0;
                        }
                    }
                }

                #endregion

                #region Optional Coverage II -Loss Adjustment Expense Wrongful Act 

                //Step- 1
                //Loss Adjustment Expense Wrongful Act Unmodified  Premium
                //(Input) * Step 13
                //This coverage is applicable for States - CT, DE, MA, ME, NH, VT
                stateCheckBackWagesFactors = new string[6] { "CT", "DE", "MA", "ME", "NH", "VT" };

                if (inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIsSelected && stateCheckBackWagesFactors.Contains(policyHeaderModel.State))
                {
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIsSelected = inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIsSelected;
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActAggregateLimit = inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActAggregateLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDeductible = inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDeductible;
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActLimit = inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActModifiedPremium = inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActModifiedPremium;
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRate = inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRate;
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRatingBasis = inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRatingBasis;
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActReturnMethod = inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActReturnMethod;
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure = inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDefenseIncludedInExcessExposure;

                    //step 1
                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnModifiedWithoutExcessPremium = Convert.ToInt32(inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium
                                                                                                                                                        * proRataFactor);

                    outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnModifiedWithoutExcessPremium;

                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(inputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDefenseIncludedInExcessExposure))
                    {
                        outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure = this._DataAccess.GetEPCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                                                                       inputModel.LineOfBusiness,
                                                                                                                                                                                       "Loss Adjustment Expense Wrongful Act",
                                                                                                                                                                                       policyHeaderModel.PrimaryClass,
                                                                                                                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                                       policyHeaderModel.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == 1000000)
                    {
                        //step 3
                        // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                        if (!string.IsNullOrEmpty(outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure) && outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = 0;
                        }
                    }
                }

                #endregion

                #region Optional Coverage III - EEOC Coverage

                if (inputModel.EmploymentPracticesOptionalCoverageModel.EEOCIsSelected)
                {
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCIsSelected = inputModel.EmploymentPracticesOptionalCoverageModel.EEOCIsSelected;
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit = inputModel.EmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCDeductible = inputModel.EmploymentPracticesOptionalCoverageModel.EEOCDeductible;
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCLimit = inputModel.EmploymentPracticesOptionalCoverageModel.EEOCLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCModifiedPremium = inputModel.EmploymentPracticesOptionalCoverageModel.EEOCModifiedPremium;
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCRate = inputModel.EmploymentPracticesOptionalCoverageModel.EEOCRate;
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCRatingBasis = inputModel.EmploymentPracticesOptionalCoverageModel.EEOCRatingBasis;
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCReturnMethod = inputModel.EmploymentPracticesOptionalCoverageModel.EEOCReturnMethod;
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCIncludedInExcessExposure = inputModel.EmploymentPracticesOptionalCoverageModel.EEOCDefenseIncludedInExcessExposure;

                    //Step-3
                    //EEOC Premium
                    //Read table "Optional Coverage" to get the coevarage premium from column 'Premium' using following input parameters
                    //State Code, Coverage Name, LOB Code, Primary Class, EEOC Limit, EEOC Aggregate Limit
                    //When selected Primary Class is not found, use "All" as the Primary Class to read the table record

                    var eeocPremium = this._DataAccess.GetOptionalCoveragePremium(policyHeaderModel.State,
                                                                                  inputModel.LineOfBusiness,
                                                                                  "EEOC",
                                                                                  policyHeaderModel.PrimaryClass,
                                                                                  inputModel.EmploymentPracticesOptionalCoverageModel.EEOCLimit,
                                                                                  inputModel.EmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit,
                                                                                  policyHeaderModel.PolicyEffectiveDate,
                                                                                  policyHeaderModel.PolicyExpirationDate);

                    //eeocPremium = Math.Round(eeocPremium, 0, MidpointRounding.AwayFromZero);

                    //Step-4
                    //EEOC Unmodified Premium 
                    //Step3* step13
                    var eeocUnmodifiedPremium = eeocPremium * proRataFactor;

                    //step 1
                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(eeocUnmodifiedPremium
                                                                                                                                        , 0
                                                                                                                                        , MidpointRounding.AwayFromZero));

                    outputModel.EmploymentPracticesOptionalCoverageModel.EEOCUnmodifiedPremium = outputModel.EmploymentPracticesOptionalCoverageModel.EEOCUnModifiedWithoutExcessPremium;

                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(inputModel.EmploymentPracticesOptionalCoverageModel.EEOCDefenseIncludedInExcessExposure))
                    {
                        outputModel.EmploymentPracticesOptionalCoverageModel.EEOCIncludedInExcessExposure = this._DataAccess.GetEPCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                                           inputModel.LineOfBusiness,
                                                                                                                                                           "EEOC",
                                                                                                                                                           policyHeaderModel.PrimaryClass,
                                                                                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                           policyHeaderModel.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == 1000000)
                    {
                        //step 3
                        // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                        if (!string.IsNullOrEmpty(outputModel.EmploymentPracticesOptionalCoverageModel.EEOCIncludedInExcessExposure) && outputModel.EmploymentPracticesOptionalCoverageModel.EEOCIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputModel.EmploymentPracticesOptionalCoverageModel.EEOCUnmodifiedPremium = 0;
                        }
                    }
                }

                #endregion

                #region Optional Coverage IV - Non Monetary Defense

                if (inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIsSelected)
                {
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIsSelected = inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIsSelected;
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit = inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseDeductible = inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseDeductible;
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit = inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseModifiedPremium = inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseModifiedPremium;
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRate = inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRate;
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRatingBasis = inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRatingBasis;
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseReturnMethod = inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseReturnMethod;
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure = inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure;

                    //Step-3
                    //Non-Monetary Defense Premium
                    //Read table "Optional Coverage" to get the coevarage premium from column 'Premium' using following input parameters
                    //State Code, Coverage Name, LOB Code, Primary Class, Non-Monetary Defense Limit, Non-Monetary Defense Aggregate Limit
                    //When selected Primary Class is not found, use "All" as the Primary Class to read the table record

                    var nonMonetaryDefensePremium = this._DataAccess.GetOptionalCoveragePremium(policyHeaderModel.State,
                                                                                                inputModel.LineOfBusiness,
                                                                                                "Non-Monetary Defense",
                                                                                                policyHeaderModel.PrimaryClass,
                                                                                                inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit,
                                                                                                inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit,
                                                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                                                policyHeaderModel.PolicyExpirationDate);

                    //nonMonetaryDefensePremium = Math.Round(nonMonetaryDefensePremium, 0, MidpointRounding.AwayFromZero);

                    //Step-4
                    //Non-Monetary Defense Premium Unmodified Premium 
                    //Step3* step13

                    var nonMonetaryDefenseUnmodifedPremium = nonMonetaryDefensePremium * proRataFactor;

                    //step 1
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(nonMonetaryDefenseUnmodifedPremium
                                                                                                                                                     , 0
                                                                                                                                                     , MidpointRounding.AwayFromZero));
                    outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium = outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnModifiedWithoutExcessPremium;
                   
                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure))
                    {
                        outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure = this._DataAccess.GetEPCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                                                         inputModel.LineOfBusiness,
                                                                                                                                                                         "Non-Monetary Defense",
                                                                                                                                                                         policyHeaderModel.PrimaryClass,
                                                                                                                                                                         policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                         policyHeaderModel.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == 1000000)
                    {
                        //step 3
                        // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                        if (!string.IsNullOrEmpty(outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure) && outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium = 0;
                        }
                    }
                }

                #endregion

                #region Optional Coverage V - Suppl. Extended Reporting Period

                if (inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected && policyHeaderModel.TransactionType == TransactionTypeConstant.ENDORSEMENT)
                {
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected = inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected;
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit = inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodDeductible = inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodDeductible;
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodLimit = inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodLimit;
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium = inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium;
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate = inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate;
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis = inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis;
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod = inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod;
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure = inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure;

                    //Step-2
                    //Suppl. Extended Reporting Period Rate
                    //Read table "Optional Coverage" to get the Rate from column 'Rate' using following input parameters
                    //State Code, Coverage Name, LOB Code, Primary Class, Suppl.Extended Reporting Period Limit
                    //When selected Primary Class is not found, use "All" as the Primary Class to read the table record

                    var supplExtendedReportingPeriodRate = this._DataAccess.GetOptionalCoverageRate(policyHeaderModel.State,
                                                                                                    inputModel.LineOfBusiness,
                                                                                                    "Suppl. Extended Reporting Period",
                                                                                                    policyHeaderModel.PrimaryClass,
                                                                                                    inputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit,
                                                                                                    policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);

                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate = Math.Round(supplExtendedReportingPeriodRate
                                                                                                                       , 0
                                                                                                                       , MidpointRounding.AwayFromZero);

                    //Step-4
                    //Suppl. Extended Reporting Period Unmodified Premium 
                    // Step 2 * (Annualized Final EP Premium of the last bound transaction)
                    // TODO Annualized Final EP Premium of the last bound transaction not found
                    var annualizedFinalEPPremium = 1;

                    //step 1
                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate * annualizedFinalEPPremium));

                    outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium = outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium;
                  
                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input                        
                    if (string.IsNullOrEmpty(inputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure))
                    {
                        outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure = this._DataAccess.GetEPCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                                                                    inputModel.LineOfBusiness,
                                                                                                                                                                                    "Suppl. Extended Reporting Period",
                                                                                                                                                                                    policyHeaderModel.PrimaryClass,
                                                                                                                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                                    policyHeaderModel.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == 1000000)
                    {
                        //step 3
                        // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                        if (!string.IsNullOrEmpty(outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure) && outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
                        }
                    }
                }

                #endregion

                #region Optional Coverage VI -Other

                if (inputModel.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel != null)
                {
                    CalculateOtherOptionalCoveragePremium(model, proRataFactor);
                }

                #endregion


                //Step A - Base Premium Calculation
                //Step-A.1
                //Step 1 * Step 2 * Step 3 * Step 4 * Step 5 * Step 6 * Step 7 * Step 8 * Step 9 * Step 10 * Step 11  * Step 12 * Step 13

                 var basePremium = inputModel.Exposure
                                 * outputModel.ExposureRate
                                 * outputModel.EPInclusionExclusionRate
                                 * outputModel.LiabilityLimitRate
                                 * outputModel.AggregateLimitRate
                                 * outputModel.RetentionRate
                                 * outputModel.PopulationRate
                                 * outputModel.LocationRate
                                 * outputModel.PolicyTypeRate
                                 * outputModel.YearsinCMRate
                                 * outputModel.RetroDateRate
                                 * outputModel.LossExperienceRate
                                 * proRataFactor;

                outputModel.BasePremium = Convert.ToInt32(Math.Round(basePremium, 0, MidpointRounding.AwayFromZero));

                //Step B - Non-Modified Premium Calculation
                //Step-B.1
                //Sum of all the added optional coverage premium
                if (outputModel.EmploymentPracticesOptionalCoverageModel != null)
                {
                    outputModel.NonModifiedPremium = outputModel.EmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium
                                                   + outputModel.EmploymentPracticesOptionalCoverageModel.EEOCUnmodifiedPremium
                                                   + outputModel.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium
                                                   + outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium
                                                   + outputModel.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium;

                    if (outputModel.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel != null)
                    {
                        outputModel.NonModifiedPremium = outputModel.NonModifiedPremium
                                                       + outputModel.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel.Sum(x => x.OtherCoverageUnmodifiedPremium);

                    }
                }

                this._Logger.Info("EmploymentPracticesService.CaculateOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesService.CaculateOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }           
        }
        #endregion

        #region Optional Coverage VI -Other

        /// <summary>
        /// Calculate Other Optional Coverage Premium
        /// </summary>
        /// <param name="model"></param>
        /// <param name="proRataFactor"></param>
        /// <param name="outputModel"></param>
        public void CalculateOtherOptionalCoveragePremium(RaterFacadeModel model, decimal proRataFactor)
        {
            this._Logger.Info("EmploymentPracticesService.CalculateOtherOptionalCoveragePremium :: Starting");

            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

            List<EmploymentPracticesOtherCoverageOutputModel> otherCoverageOutputModelList = new List<EmploymentPracticesOtherCoverageOutputModel>();
            var otherCoverageInputModelList = inputModel.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel;

            try
            {
                if (otherCoverageInputModelList != null)
                {
                    foreach (var otherCoverageInputModel in otherCoverageInputModelList)
                    {
                        EmploymentPracticesOtherCoverageOutputModel otherCoverageOutputModel = new EmploymentPracticesOtherCoverageOutputModel();

                        otherCoverageOutputModel.OtherCoverageAggregateLimit = otherCoverageInputModel.OtherCoverageAggregateLimit;
                        otherCoverageOutputModel.OtherCoverageDeductible = otherCoverageInputModel.OtherCoverageDeductible;
                        otherCoverageOutputModel.OtherCoverageDescription = otherCoverageInputModel.OtherCoverageDescription;
                        otherCoverageOutputModel.OtherCoverageID = otherCoverageInputModel.OtherCoverageID;
                        otherCoverageOutputModel.OtherCoverageLimit = otherCoverageInputModel.OtherCoverageLimit;
                        otherCoverageOutputModel.OtherCoverageModifiedPremium = otherCoverageInputModel.OtherCoverageModifiedPremium;
                        otherCoverageOutputModel.OtherCoverageRate = otherCoverageInputModel.OtherCoverageRate;
                        otherCoverageOutputModel.OtherCoverageRatingBasis = otherCoverageInputModel.OtherCoverageRatingBasis;
                        otherCoverageOutputModel.OtherCoverageReturnMethod = otherCoverageInputModel.OtherCoverageReturnMethod;
                        otherCoverageOutputModel.OtherCoverageUnmodifiedPremium = otherCoverageInputModel.OtherCoverageUnmodifiedPremium;
                        otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure = otherCoverageInputModel.OtherCoverageIncludedInExcessExposure;

                        //Step-1
                        //When Rating basis is  'Flat charge'
                        //Other Coverage Unmodified Premium 
                        //(Input ) * Step 13
                        if (otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARGE")
                        {
                            otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((otherCoverageInputModel.OtherCoverageUnmodifiedPremium
                                                                                                                              * proRataFactor),
                                                                                                                              0,
                                                                                                                              MidpointRounding.AwayFromZero));
                        }

                        //Rating basis is  'per 1,000 of limit'
                        else if (otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                        {
                            //step-3
                            //(Step 1 /1000) * Step 2 * Step 13

                            var otherCoverageUnmodifiedPremium = (otherCoverageOutputModel.OtherCoverageLimit
                                                                  / 1000)
                                                                  * otherCoverageOutputModel.OtherCoverageRate
                                                                  * proRataFactor;

                            otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(otherCoverageUnmodifiedPremium,
                                                                                                                              0,
                                                                                                                              MidpointRounding.AwayFromZero));
                        }

                        //When Rating basis is 'per 100 of limit'
                        else if (otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                        {
                            //step-3
                            //(Step 1 /100) * Step 2 * Step 13

                            var otherCoverageUnmodifiedPremium = (otherCoverageOutputModel.OtherCoverageLimit
                                                                  / 100)
                                                                  * otherCoverageOutputModel.OtherCoverageRate
                                                                  * proRataFactor;

                            otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(otherCoverageUnmodifiedPremium,
                                                                                                                              0,
                                                                                                                              MidpointRounding.AwayFromZero));
                        }

                        //When Rating basis is 'No Charge'
                        else if (otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                        {
                            otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = 0;
                        }

                        otherCoverageOutputModel.OtherCoverageUnmodifiedPremium = otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium;

                        //step 2
                        // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                        if (string.IsNullOrEmpty(otherCoverageInputModel.OtherCoverageIncludedInExcessExposure))
                        {
                            otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure = this._DataAccess.GetEPCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                            inputModel.LineOfBusiness,
                                                                                                                                            "Other",
                                                                                                                                            policyHeaderModel.PrimaryClass,
                                                                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                            policyHeaderModel.PolicyExpirationDate);

                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == 1000000)
                        {    
                            //step 3
                            // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                            if (!string.IsNullOrEmpty(otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure) && otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                otherCoverageOutputModel.OtherCoverageUnmodifiedPremium = 0;
                            }
                        }

                        otherCoverageOutputModelList.Add(otherCoverageOutputModel);
                    }
                }

                outputModel.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel = otherCoverageOutputModelList;
            
                this._Logger.Info("EmploymentPracticesService.CalculateOtherOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesService.CalculateOtherOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #endregion

        /// <summary>
        /// CalculateOthersPremium
        /// </summary>
        /// <param name="model"></param>
        public void CalculateOthersPremium(RaterFacadeModel model)
        {
            this._Logger.Info("EmploymentPracticesService.CalculateOthersPremium :: Starting");

            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            
            try
            {
                //Step C - Manual Premium Calculation
                //Step-C.1
                //Step A.1 + Step B.1
                // Read Minimum Premium lookup table to get Minimum Premium
                decimal lOBMinimumPremium = this._DataAccess.GetLOBTotalPremium(policyHeaderModel.State,
                                                                                inputModel.LineOfBusiness,
                                                                                policyHeaderModel.PrimaryClass,
                                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                                policyHeaderModel.PolicyExpirationDate);

                decimal manualPremium = outputModel.BasePremium + outputModel.NonModifiedPremium;

                manualPremium = Math.Round(manualPremium, 0, MidpointRounding.AwayFromZero);

                outputModel.ManualPremium = Convert.ToInt32(manualPremium);

                //If Calculated Manual Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated Manual Premium by LOB MINIMUM PREMIUM.
                //Note - If Suppl.Extended Reporting Perio Is Selected = 1 Then Apply LOB Minimum Premium condition as mentioned below -
                //1.Calculated Manual Premium = (Manual Premium - (Suppl.Extended Reporting Period Unmodified Premium))
                //2.If Calculated Manual Premium in #1 is less than the LOB MINIMUM PREMIUM. Then
                //Manual Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium

                if (outputModel.ManualPremium < lOBMinimumPremium)
                {
                    outputModel.ManualPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium));
                }

                if (outputModel.EmploymentPracticesOptionalCoverageModel != null && outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputModel.ManualPremium = (outputModel.BasePremium - outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium);

                    if (outputModel.ManualPremium < lOBMinimumPremium)
                    {
                        outputModel.ManualPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium)) + outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                //Step D - Tier Premium Calculation
                //Step-D
                //((Step C.1  - Step B.1)  * Step 15 + Step B.1
                decimal tierPremium = Convert.ToInt32((manualPremium                      // before applied lobMinPremium.
                                                     - outputModel.NonModifiedPremium)
                                                     * outputModel.TierRate
                                                     + outputModel.NonModifiedPremium);

                tierPremium = Math.Round(tierPremium, 0, MidpointRounding.AwayFromZero);

                outputModel.TierPremium = Convert.ToInt32(tierPremium);

                //Manual Premium (Step C.1) used in the calculation should be the calculated Manual Premium before applying LOB Minimum Premium condition
                //If Calculated Tier Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated Tier Premium by LOB MINIMUM PREMIUM.
                //Note - If Suppl.Extended Reporting Period Is Selected = 1 Then Apply LOB Minimum Premium condition as mentioned below -
                //1.Calculated Tier Premium = (Tier Premium - (Suppl.Extended Reporting Period Unmodified Premium))
                //2.If Calculated Tier Premium in #1 is less than the LOB MINIMUM PREMIUM. Then
                //Tier Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium

                if (outputModel.TierPremium < lOBMinimumPremium)
                {
                    outputModel.TierPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium));
                }

                if (outputModel.EmploymentPracticesOptionalCoverageModel != null && outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputModel.TierPremium = (outputModel.TierPremium
                                             - outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium);

                    if (outputModel.TierPremium < lOBMinimumPremium)
                    {
                        outputModel.TierPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium))
                                                                           + outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                //Step E - IRPM Premium Calculation
                //Step E.1 - Get system calculated value
                //((Step D.1  - Step B.1)  * Step 16 + Step B.1

                var irpmPremium = (tierPremium
                                 - outputModel.NonModifiedPremium)
                                 * outputModel.IRPMRate
                                 + outputModel.NonModifiedPremium;

                irpmPremium = Math.Round(irpmPremium, 0, MidpointRounding.AwayFromZero);

                outputModel.IRPMPremium = Convert.ToInt32(irpmPremium);

                //Tier Premium (Step D.1) used in the calculation should be the calculated Tier Premium before applying LOB Minimum Premium condition
                //If Calculated IRPM Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated IRPM Premium by LOB MINIMUM PREMIUM.
                // Note - If Suppl.Extended Reporting Period Is Selected = 1 Then Apply LOB Minimum Premium condition as mentioned below -
                //1.Calculated IRPM Premium = (IRPM Premium - (Suppl.Extended Reporting Period Unmodified Premium))
                //2.If Calculated IRPM Premium in #1 is less than the LOB MINIMUM PREMIUM. Then
                //IRPM Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium

                if (outputModel.IRPMPremium < lOBMinimumPremium)
                {
                    outputModel.IRPMPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium,
                                                                         0,
                                                                         MidpointRounding.AwayFromZero));
                }
                if (outputModel.EmploymentPracticesOptionalCoverageModel != null && outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputModel.IRPMPremium = (outputModel.IRPMPremium
                                             - outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium);

                    if (outputModel.OtherModPremium < lOBMinimumPremium)
                    {
                        outputModel.IRPMPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium))
                                                                           + outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                //Step F - Other Mod Premium Calculation
                //Step F.1 - Get system calculated value
                //((Step E.1  - Step B.1)  * Step 17 + Step B.1

                var otherModPremium = (irpmPremium
                                     - outputModel.NonModifiedPremium)
                                     * outputModel.OtherModRate
                                     + outputModel.NonModifiedPremium;

                otherModPremium = Math.Round(otherModPremium, 0, MidpointRounding.AwayFromZero);

                outputModel.OtherModPremium = Convert.ToInt32(otherModPremium);

                //IRPM Premium (Step E.1) used in the calculation should be the calculated IRPM Premium before applying LOB Minimum Premium condition
                //If Calculated Other Mod Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated Other Mod Premium by LOB MINIMUM PREMIUM.
                //Note - If Suppl.Extended Reporting Period Is Selected = 1, apply LOB Minimum Premium condition as mentioned below -
                // 1.Calculated Other Mod Premium = (Other Mod Premium -(Suppl.Extended Reporting Period Unmodified Premium))
                //2.If Calculated Other Mod Premium in #1 is less than the LOB MINIMUM PREMIUM. Then
                //Other Mod Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium

                if (outputModel.OtherModPremium < lOBMinimumPremium)
                {
                    outputModel.OtherModPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium));
                }

                if (outputModel.EmploymentPracticesOptionalCoverageModel != null && outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputModel.OtherModPremium = outputModel.OtherModPremium
                                                - outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    if (outputModel.OtherModPremium < lOBMinimumPremium)
                    {
                        outputModel.OtherModPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium))
                                                                               + outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                //Step G - Terrorism Premium Calculation
                //Step G.1 - Get system calculated value
                //Step F.1 * Step 14
                //When Terrorism Accepted Rejected = Accept (1) Calculate Terrorism Premium
                // Else Don't Calculate Terrorism Premium

                if (model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected)
                {
                    outputModel.TerrorismPremium = Convert.ToInt32(Math.Round((outputModel.OtherModPremium
                                                                             * outputModel.TerrorismRate)
                                                                             , 0
                                                                             , MidpointRounding.AwayFromZero));
                }

                //Step H - Final Premium Calculation
                //Step H.1 - Get system calculated value
                //Step F.1 + Step G.1
                outputModel.EPFinalModifiedPremium = Convert.ToInt32(Math.Round((otherModPremium
                                                                               + outputModel.TerrorismPremium)
                                                                               , 0
                                                                               , MidpointRounding.AwayFromZero));

                //Other Mod Premium (Step F.1) used in the calculation should be the calculated Other Mod Premium before applying LOB Minimum Premium condition
                // If Calculated EP Final Modified Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated EP Final Modified Premium by LOB MINIMUM PREMIUM.
                //Note - (If Suppl.Extended Reporting Period optional coverage Is selected = 1), apply LOB Minimum Premium condition as mentioned below -
                //1.Calculated Final Premium = (Final premium - (Suppl.Extended Reporting Period Unmodified Premium))
                //2.If Calculated Final Premium calculated in 1# is less than the LOB MINIMUM PREMIUM. Then
                //EP Final Modified Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium

                if (outputModel.EPFinalModifiedPremium < lOBMinimumPremium)
                {
                    outputModel.EPFinalModifiedPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium, 0, MidpointRounding.AwayFromZero));
                }

                if (outputModel.EmploymentPracticesOptionalCoverageModel != null && outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputModel.EPFinalModifiedPremium = outputModel.EPFinalModifiedPremium
                                                       - outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    if (outputModel.EPFinalModifiedPremium < lOBMinimumPremium)
                    {
                        outputModel.EPFinalModifiedPremium = Convert.ToInt32(Math.Round(lOBMinimumPremium))
                                                                                      + outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                //Step I
                //EP Total Unmodified Without Excess Premium Calculation			
                // Step I.1 - Get system calculated value EP Total Unmodified Without Excess Premium = Sum of the Umodified Without Excess Pemium of all the added optional coverages
                // where Included In Excess Exposure = True.                
                var totalEPOPtionalUnModifiedWithoutExcessPremium = 0M;

                if (outputModel.EmploymentPracticesOptionalCoverageModel != null)
                {
                    var outputOptionalCoverageModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel;

                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.BackWagesIncludedInExcessExposure) && outputOptionalCoverageModel.BackWagesIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalEPOPtionalUnModifiedWithoutExcessPremium = totalEPOPtionalUnModifiedWithoutExcessPremium
                                                                      + outputOptionalCoverageModel.BackWagesUnModifiedWithoutExcessPremium;
                    }

                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.EEOCIncludedInExcessExposure) && outputOptionalCoverageModel.EEOCIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalEPOPtionalUnModifiedWithoutExcessPremium = totalEPOPtionalUnModifiedWithoutExcessPremium
                                                                      + outputOptionalCoverageModel.EEOCUnModifiedWithoutExcessPremium;
                    }

                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure) && outputOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalEPOPtionalUnModifiedWithoutExcessPremium = totalEPOPtionalUnModifiedWithoutExcessPremium
                                                                      + outputOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnModifiedWithoutExcessPremium;
                    }

                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure) && outputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalEPOPtionalUnModifiedWithoutExcessPremium = totalEPOPtionalUnModifiedWithoutExcessPremium
                                                                      + outputOptionalCoverageModel.NonMonetaryDefenseUnModifiedWithoutExcessPremium;
                    }

                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure) && outputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalEPOPtionalUnModifiedWithoutExcessPremium = totalEPOPtionalUnModifiedWithoutExcessPremium
                                                                      + outputModel.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium;
                    }

                    int othercoverageWithoutExcessPremium = 0;

                    if (outputOptionalCoverageModel.EmploymentPracticesOtherCoverageModel != null)
                    {
                        othercoverageWithoutExcessPremium = outputOptionalCoverageModel.EmploymentPracticesOtherCoverageModel.Where(y => !string.IsNullOrEmpty(y.OtherCoverageIncludedInExcessExposure)
                                                                        && y.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE").Sum(x => x.OtherCoverageUnModifiedWithoutExcessPremium);

                    }

                    totalEPOPtionalUnModifiedWithoutExcessPremium = totalEPOPtionalUnModifiedWithoutExcessPremium + othercoverageWithoutExcessPremium;

                    outputModel.EPTotalUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(totalEPOPtionalUnModifiedWithoutExcessPremium, 0, MidpointRounding.ToZero));
                }

                this._Logger.Info("EmploymentPracticesService.CalculateOthersPremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesService.CalculateOthersPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region Get Yearfrac
        /// <summary>
        /// YearFrac
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>decimal</returns>
        public decimal YearFrac(DateTime startDate, DateTime endDate)
        {
            this._Logger.Info("EmploymentPracticesService.YearFrac :: Starting");

            if (endDate < startDate)
            {
                return 0;
            }

            int endDay = endDate.Day;
            int startDay = startDate.Day;
            switch (startDay)
            {
                case 31:
                    {
                        startDay = 30;
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 30:
                    {
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 29:
                    {
                        if (startDate.Month == 2)
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;

                case 28:
                    {
                        if ((startDate.Month == 2) && (!DateTime.IsLeapYear(startDate.Year)))
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;
            }

            var yearFraction = (((endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDay - startDay)) / 360);

            this._Logger.Info("EmploymentPracticesService.YearFrac :: Completed");

            return yearFraction;
        }
        #endregion
    }
}
