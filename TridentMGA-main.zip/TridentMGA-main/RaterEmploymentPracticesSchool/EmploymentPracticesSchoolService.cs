﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EmploymentPracticesSchool.Output;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Validations;

namespace RateEmploymentPracticesSchool
{
    public class EmploymentPracticesSchoolService : IEmploymentPracticesSchoolService
    {
        /// <summary>
        /// DataAccess object
        /// </summary>
        private EmploymentPracticesSchoolDataAccess _DataAccess { get; set; }

        /// <summary>
        /// Logger object
        /// </summary>
        protected ILoggingManager _Logger { get; private set; }

        /// <summary>
        /// Configuration object
        /// </summary>
        protected IConfiguration _Configuration { get; private set; }

        private int LiabilityLimitExcessValue { get; set; } = 1000000;

        /// <summary>
        /// EmploymentPracticesSchoolService
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public EmploymentPracticesSchoolService(IConfiguration configuration, ILoggingManager logger)
        {
            this._Configuration = configuration;
            this._Logger = logger;
            this._DataAccess = new EmploymentPracticesSchoolDataAccess(configuration, logger);
        }

        /// <summary>
        /// ExecuteDomainRules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        /// <summary>
        /// PreValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EmploymentPracticesSchoolService.PreValidate :: Starting");

                var validator = new EmploymentPracticesSchoolPreValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);

                this._Logger.Info("EmploymentPracticesSchoolService.PreValidate :: Completed");

                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesSchoolService.PreValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// PostValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EmploymentPracticesSchoolService.PostValidate :: Starting");

                var validator = new EmploymentPracticesSchoolPostValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);

                this._Logger.Info("EmploymentPracticesSchoolService.PostValidate :: Completed");
                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesSchoolService.PostValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region EmploymentPractices

        /// <summary>
        /// Calculate
        /// </summary>
        /// <param name="model"></param>
        public void Calculate(RaterFacadeModel model)
        {
            try
            {
                #region CalculationEPS

                CalculationEPS(model);

                #endregion

                #region Optional Coverages Premium

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel != null)
                {
                    CalculateOptionalCoveragePremium(model);
                }

                #endregion

                CalculateOthersPremium(model);
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesSchoolService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculationEPS
        /// </summary>
        /// <param name="model"></param>
        public void CalculationEPS(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EmploymentPracticesSchoolService.CalculationEPS :: Started");

                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool;
                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                policyHeaderModel.State = policyHeaderModel.State.ToUpper();
                policyHeaderModel.PrimaryClass = policyHeaderModel.PrimaryClass.ToUpper();
                policyHeaderModel.TransactionType = policyHeaderModel.TransactionType.ToUpper();

                //step 1
                //For Primary Class = "Muni / School Combined" Rating Basis is "Per Student".
                if (policyHeaderModel.PrimaryClass.ToUpper() == "MSC")
                {
                    outputModel.RatingBasis = "Per Student";
                }

                //Step 2
                //The rate can be entered in "Exposure Rate" UI field & Rater will pull the rate from this UI field . 
                if (inputModel.ExposureRate >= 0)
                {
                    outputModel.ExposureRate = inputModel.ExposureRate;
                }
                else
                {
                    DataTable dataTable = _DataAccess.GetExposureRateMinMaxFactor(policyHeaderModel.State,
                                                                                  policyHeaderModel.PrimaryClass,
                                                                                  inputModel.LineOfBusiness,
                                                                                  policyHeaderModel.PolicyEffectiveDate,
                                                                                  policyHeaderModel.PolicyExpirationDate);

                    if (dataTable == null)
                    {
                        outputModel.ExposureRate = 0;
                    }
                    else
                    {
                        if (dataTable.Rows[0]["BaseRate"] != DBNull.Value)
                        {
                            outputModel.ExposureRate = Convert.ToDecimal(dataTable.Rows[0]["BaseRate"]);
                        }
                    }
                }

                //Step-3
                //Read table " Trident.EPInclExcl" using following input parameters to get the factor from column named as "Factor"
                //State Code, LOB, Effective Date, Expiration Date
                outputModel.EPInclusionExclusionRate = _DataAccess.GetEPInclusionExclusionRateFactor(policyHeaderModel.State,
                                                                                                     inputModel.LineOfBusiness,
                                                                                                     policyHeaderModel.PolicyEffectiveDate,
                                                                                                     policyHeaderModel.PolicyExpirationDate);

                //Step-4
                //Rater will pull the Limit factor from "Liability Limit Rate" input field.
                if (inputModel.LiabilityLimitRate >= 0)
                {
                    outputModel.LiabilityLimitRate = inputModel.LiabilityLimitRate;
                }
                else
                {
                    DataTable dataTableLimit = _DataAccess.GetLiabilityLimitRateMinimumFactor(policyHeaderModel.State,
                                                                                              inputModel.LineOfBusiness,
                                                                                              inputModel.LiabilityLimit,
                                                                                              policyHeaderModel.PolicyEffectiveDate,
                                                                                              policyHeaderModel.PolicyExpirationDate);
                    if (dataTableLimit == null)
                    {
                        outputModel.LiabilityLimitRate = 0;
                    }
                    else
                    {
                        if (dataTableLimit.Rows[0]["Factor"] != DBNull.Value)
                        {
                            outputModel.LiabilityLimitRate = Convert.ToDecimal(dataTableLimit.Rows[0]["Factor"]);
                        }
                    }
                }

                //Step - 5
                //Read table "Trident.ProfLinesAggregateLimit" using following input parameters to get the Aggregate Limit factor from column "Rate"
                //- State Code, LOB code, Effective Date, Expiration Date, Liability Limit, Aggregate Limit.       
                outputModel.AggregateLimitRate = _DataAccess.GetAggregateLimitRateFactor(policyHeaderModel.State,
                                                                                         inputModel.LineOfBusiness,
                                                                                         policyHeaderModel.PolicyEffectiveDate,
                                                                                         policyHeaderModel.PolicyExpirationDate,
                                                                                         inputModel.LiabilityLimit,
                                                                                         inputModel.AggregateLimit);

                //Step-6        
                //Use table "Trident.DeductibleSIR" to get the Retention factor from "Factor' column using following input parameters:
                //StateCode, Line of Business, Effective Date, Expiration Date, Retention          
                outputModel.RetentionRate = _DataAccess.GetRetentionRateFactor(policyHeaderModel.State,
                                                                               inputModel.LineOfBusiness,
                                                                               policyHeaderModel.PolicyEffectiveDate,
                                                                               policyHeaderModel.PolicyExpirationDate,
                                                                               "Deductible",
                                                                               inputModel.Retention.ToString());

                //Step-7     
                //Read table "Trident.PopulationFactor" using following input paratmeters and get the population Factor from column "Rate"
                //StateCode, Line of Business, Effective Date, Expiration Date, Primary Class, Population
                outputModel.PopulationRate = _DataAccess.GetPopulationRateFactor(policyHeaderModel.State,
                                                                                 inputModel.LineOfBusiness,
                                                                                 policyHeaderModel.PrimaryClass,
                                                                                 policyHeaderModel.PolicyEffectiveDate,
                                                                                 policyHeaderModel.PolicyExpirationDate,
                                                                                 policyHeaderModel.PopulationADA); // inputModel.Exposure

                //Step-8   
                //Refer to the lookup table "Trident.LocationType" to get the Location Factor from column "Location Factor" using following input parameters.
                //State Code, LOB code, Effective Date, Expiration Date, Location Type
                outputModel.LocationRate = _DataAccess.GetEPSLocationRate(policyHeaderModel.State,
                                                                          inputModel.LineOfBusiness,
                                                                          policyHeaderModel.PolicyEffectiveDate,
                                                                          policyHeaderModel.PolicyExpirationDate,
                                                                          policyHeaderModel.LocationType);

                //Step-9   
                //Refer to the lookup table ""Trident.PolicyType"" to get the Policy Type Factor from column ""Factor"" using following input parameters.
                //State Code, LOB code, Effective Date, Expiration Date, Policy Type
                outputModel.PolicyTypeRate = _DataAccess.GetEPSPolicyTypeRateFactor(policyHeaderModel.State,
                                                                                    inputModel.LineOfBusiness,
                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                    policyHeaderModel.PolicyExpirationDate,
                                                                                    inputModel.PolicyType);

                //Step-11     
                //When Policy Type = Claims Made, calculate the Retro Date Factor
                //Step 1 - Calculate the RetroYear by using formula "ROUNDDOWN(YearFrac(Policy Effective Date, Retro Active Date, 1)0)
                //Step 2 - Read table "Trident.RetroDateFactor" to get the Retro Factor from column"Factor" using following input parameters: State Code, LOB Code, Effective Date, Expiration Date & RetroYear
                //Note - If the Retro Year is greater than 6 Pass the value '>6' to the table
                //When Policy Type = Occurrence Apply 1.00 as the Retro Date rate

                decimal yearFrac = this.YearFrac(inputModel.RetroActiveDate, policyHeaderModel.PolicyEffectiveDate);
                outputModel.RetroYear = Convert.ToInt32(Math.Round(yearFrac, 0));

                if (inputModel.PolicyType.ToUpper() == "CLAIMS MADE")
                {
                    //Step-10   
                    //When Policy Type = Claims Made
                    //Refer to the lookup table "Trident.CMPolicyYear" to get the Factor from column "CM Factor" using following input parameters.
                    //State Code, LOB code, Effective Date, Expiration Date, Years In CM Program
                    //When Policy Type = Occurrence Years In CM Rate should be defaulted to 1.000
                    outputModel.YearsinCMRate = _DataAccess.GetEPSYearsinCMRateFactor(policyHeaderModel.State,
                                                                                      inputModel.LineOfBusiness,
                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                      policyHeaderModel.PolicyExpirationDate,
                                                                                      inputModel.YearsinCMProgram);

                                        
                    // Step 11.2
                    string stringRetroYear = string.Empty;

                    if (outputModel.RetroYear <= 6)
                    {
                        stringRetroYear = outputModel.RetroYear.ToString();
                    }
                    else
                    {
                        stringRetroYear = ">6";
                    }

                    outputModel.RetroDateRate = _DataAccess.GetEPSRetroDateRateFactor(policyHeaderModel.State,
                                                                                      inputModel.LineOfBusiness,
                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                      policyHeaderModel.PolicyExpirationDate,
                                                                                      stringRetroYear);
                }
                else if (inputModel.PolicyType.ToUpper() == "OCCURRENCE")
                {
                    outputModel.YearsinCMRate = 1;
                    outputModel.RetroDateRate = 1;
                }

                //Step-12        
                //Read table " Trident.ProfLinesLossExperience" to get the Experience Factor from column "Experience Factor" using following input parameters.
                //State Code, LOB Code, Effective Date, Expiration Date, Loss Experience Applied(if checkbox is selected, return True / Binary True else return False / Binary False).     
                outputModel.LossExperienceRate = _DataAccess.GetEPSLossExperienceRate(policyHeaderModel.State,
                                                                                      inputModel.LineOfBusiness,
                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                      policyHeaderModel.PolicyExpirationDate,
                                                                                      inputModel.LossExperienceIsSelected);
                //Step-14  TerrorismRate
                //Terrorism Factor doesn't apply.
                outputModel.TerrorismRate = 0;

                //Step-15     
                //Read table ""Trident.TierFactors"" to get the Tier factor from column ""Tier Factor"" using following input parameters:
                //State Code, LOB Code, Effective Date, Expiration Date, Tier Plan
                outputModel.TierRate = _DataAccess.GetEPSTierRate(policyHeaderModel.State,
                                                                  inputModel.LineOfBusiness,
                                                                  policyHeaderModel.PolicyEffectiveDate,
                                                                  policyHeaderModel.PolicyExpirationDate,
                                                                  model.RaterInputFacadeModel.PricingInputModel.TierPlan);

                //Step-16  
                outputModel.IRPMRate = inputModel.IRPMRate;

                //Step-17                   
                //Get the Other Mod Value from input Json.
                outputModel.OtherModRate = inputModel.OtherModRate;

                this._Logger.Info("EmploymentPracticesSchoolService.CalculationEPS :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesSchoolService.CalculationEPS :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateOptionalCoveragePremium
        /// </summary>
        /// <param name="model"></param>
        public void CalculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EmploymentPracticesSchoolService.CalculateOptionalCoveragePremium :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool;
                var optionalCoverageOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel;
                var optionalCoverageInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                decimal proRataFactor = 1;
                string[] StateCodes = new string[3] { "CT", "ME", "MA" };

                if (StateCodes.Contains(policyHeaderModel.State) && policyHeaderModel.PrimaryClass == "MSC")
                {
                    //Optional Coverage I -LossAdjustmentExpenseWrongfulAct
                    if (optionalCoverageInputModel.LossAdjustmentExpenseWrongfulActIsSelected)
                    {
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActIsSelected = inputModel.EmploymentPracticesSchoolOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIsSelected;
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActAggregateLimit = inputModel.EmploymentPracticesSchoolOptionalCoverageModel.LossAdjustmentExpenseWrongfulActAggregateLimit;
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActDeductible = inputModel.EmploymentPracticesSchoolOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDeductible;
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActLimit = inputModel.EmploymentPracticesSchoolOptionalCoverageModel.LossAdjustmentExpenseWrongfulActLimit;
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActModifiedPremium = inputModel.EmploymentPracticesSchoolOptionalCoverageModel.LossAdjustmentExpenseWrongfulActModifiedPremium;
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActRate = inputModel.EmploymentPracticesSchoolOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRate;
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActRatingBasis = inputModel.EmploymentPracticesSchoolOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRatingBasis;
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActReturnMethod = inputModel.EmploymentPracticesSchoolOptionalCoverageModel.LossAdjustmentExpenseWrongfulActReturnMethod;
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure = inputModel.EmploymentPracticesSchoolOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure;

                        //step 1
                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActUnmodifiedWithoutExcessPremium = Convert.ToInt32(optionalCoverageInputModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium
                                                                                                                                   * proRataFactor);

                        optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = Convert.ToInt32(optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActUnmodifiedWithoutExcessPremium);
                        
                        //step 2
                        // If input value is blank then Refer to lookup table. otherwise "Loss Adjustment Expense Wrongful Act Included in Excess Exposure" = input                            
                        if (string.IsNullOrEmpty(optionalCoverageInputModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure))
                        {
                            optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure = this._DataAccess.GetExcessExposure(policyHeaderModel.State,
                                                                                                                                                      inputModel.LineOfBusiness,
                                                                                                                                                      policyHeaderModel.PrimaryClass,
                                                                                                                                                      "Loss Adjustment Expense Wrongful Act",
                                                                                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                      policyHeaderModel.PolicyExpirationDate);
                        }

                        // If LineOfBusiness Excess = True and Liability Limit = 1,000,000
                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == LiabilityLimitExcessValue)
                        {                            
                            //step 3
                            // If  Loss Adjustment Expense Wrongful Act Included In Excess Exposure = True  
                            if (!string.IsNullOrEmpty(optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure) && optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = 0;
                            }
                        }
                    }

                    //Optional Coverage II -EEOC
                    if (optionalCoverageInputModel.EEOCIsSelected)
                    {
                        optionalCoverageOutputModel.EEOCLimit = optionalCoverageInputModel.EEOCLimit;
                        optionalCoverageOutputModel.EEOCIsSelected = optionalCoverageInputModel.EEOCIsSelected;
                        optionalCoverageOutputModel.EEOCAggregateLimit = optionalCoverageInputModel.EEOCAggregateLimit;
                        optionalCoverageOutputModel.EEOCDeductible = optionalCoverageInputModel.EEOCDeductible;
                        optionalCoverageOutputModel.EEOCReturnMethod = optionalCoverageInputModel.EEOCReturnMethod;
                        optionalCoverageOutputModel.EEOCRatingBasis = optionalCoverageInputModel.EEOCRatingBasis;
                        optionalCoverageOutputModel.EEOCRate = optionalCoverageInputModel.EEOCRate;
                        optionalCoverageOutputModel.EEOCModifiedPremium = optionalCoverageInputModel.EEOCModifiedPremium;
                        optionalCoverageOutputModel.EEOCIncludedInExcessExposure = optionalCoverageInputModel.EEOCIncludedInExcessExposure;

                        //step 3 EEOC Premium                    
                        //Read table "Optional Coverage" to get the coevarage premium from column 'Premium' using following input parameters
                        //State Code, Coverage Name, LOB Code, Primary Class, EEOC Limit, EEOC Aggregate Limit
                        //When selected Primary Class is not found, use "All" as the Primary Class to read the table record
                        var eeocPremium = this._DataAccess.GetOptionalCoveragePremium(policyHeaderModel.State,
                                                                                      "EEOC",
                                                                                      inputModel.LineOfBusiness,
                                                                                      policyHeaderModel.PrimaryClass,
                                                                                      optionalCoverageInputModel.EEOCLimit,
                                                                                      optionalCoverageInputModel.EEOCAggregateLimit,
                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                      policyHeaderModel.PolicyExpirationDate);

                        //step 4
                        optionalCoverageOutputModel.EEOCUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((eeocPremium
                                                                                                                   * proRataFactor)
                                                                                                                   , 0
                                                                                                                   , MidpointRounding.AwayFromZero));

                        optionalCoverageOutputModel.EEOCUnmodifiedPremium = optionalCoverageOutputModel.EEOCUnmodifiedWithoutExcessPremium;

                        //step 5
                        // If input value is blank then Refer to lookup table. otherwise "EEOC Included in Excess Exposure" = input                          
                        if (string.IsNullOrEmpty(optionalCoverageInputModel.EEOCIncludedInExcessExposure))
                        {
                            optionalCoverageOutputModel.EEOCIncludedInExcessExposure = this._DataAccess.GetExcessExposure(policyHeaderModel.State,
                                                                                                                          inputModel.LineOfBusiness,
                                                                                                                          policyHeaderModel.PrimaryClass,
                                                                                                                          "EEOC",
                                                                                                                          policyHeaderModel.PolicyEffectiveDate,
                                                                                                                          policyHeaderModel.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == LiabilityLimitExcessValue)
                        {
                            //step 6
                            // If LineOfBusiness Excess = True and EEOC Included In Excess Exposure = True and Liability Limit = 1,000,000
                            if (!string.IsNullOrEmpty(optionalCoverageOutputModel.EEOCIncludedInExcessExposure) && optionalCoverageOutputModel.EEOCIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                optionalCoverageOutputModel.EEOCUnmodifiedPremium = 0;
                            }
                        }
                    }

                    //Optional Coverage III - Non Monetary Defense
                    if (optionalCoverageInputModel.NonMonetaryDefenseIsSelected)
                    {
                        optionalCoverageOutputModel.NonMonetaryDefenseLimit = optionalCoverageInputModel.NonMonetaryDefenseLimit;
                        optionalCoverageOutputModel.NonMonetaryDefenseAggregateLimit = optionalCoverageInputModel.NonMonetaryDefenseAggregateLimit;
                        optionalCoverageOutputModel.NonMonetaryDefenseDeductible = optionalCoverageInputModel.NonMonetaryDefenseDeductible;
                        optionalCoverageOutputModel.NonMonetaryDefenseRatingBasis = optionalCoverageInputModel.NonMonetaryDefenseRatingBasis;
                        optionalCoverageOutputModel.NonMonetaryDefenseReturnMethod = optionalCoverageInputModel.NonMonetaryDefenseReturnMethod;
                        optionalCoverageOutputModel.NonMonetaryDefenseRate = optionalCoverageInputModel.NonMonetaryDefenseRate;
                        optionalCoverageOutputModel.NonMonetaryDefenseModifiedPremium = optionalCoverageInputModel.NonMonetaryDefenseModifiedPremium;
                        optionalCoverageOutputModel.NonMonetaryDefenseIsSelected = optionalCoverageInputModel.NonMonetaryDefenseIsSelected;
                        optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure = optionalCoverageInputModel.NonMonetaryDefenseIncludedInExcessExposure;

                        // step 3 
                        //Non-Monetary Defense Modified Premium
                        //Read table "Optional Coverage" to get the coevarage premium from column 'Premium' using following input parameters
                        //State Code, Coverage Name, LOB Code, Primary Class, EEOC Limit, EEOC Aggregate Limit
                        //When selected Primary Class is not found, use "All" as the Primary Class to read the table record
                        var nonMonetaryPremium = this._DataAccess.GetOptionalCoveragePremium(policyHeaderModel.State,
                                                                                             "Non-Monetary Defense",
                                                                                             inputModel.LineOfBusiness,
                                                                                             policyHeaderModel.PrimaryClass,
                                                                                             optionalCoverageInputModel.NonMonetaryDefenseLimit,
                                                                                             optionalCoverageInputModel.NonMonetaryDefenseAggregateLimit,
                                                                                             policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);

                        //step 4
                        optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((nonMonetaryPremium
                                                                                                                                 * proRataFactor)
                                                                                                                                 , 0
                                                                                                                                 , MidpointRounding.AwayFromZero));

                        optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedPremium = optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedWithoutExcessPremium;
                        
                        //step 5
                        // If input value is blank then Refer to lookup table. otherwise "NonMonetaryDefense Included in Excess Exposure" = input                            
                        if (string.IsNullOrEmpty(optionalCoverageInputModel.NonMonetaryDefenseIncludedInExcessExposure))
                        {
                            optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure = this._DataAccess.GetExcessExposure(policyHeaderModel.State,
                                                                                                                                        inputModel.LineOfBusiness,
                                                                                                                                        policyHeaderModel.PrimaryClass,
                                                                                                                                        "Non-Monetary Defense",
                                                                                                                                        policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                        policyHeaderModel.PolicyExpirationDate);
                        }

                        //If LineOfBusiness Excess = True and Liability Limit = 1,000,000
                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == LiabilityLimitExcessValue)
                        {
                            //step 6 Non-Monetary Defense Un-Modified Premium
                            // NonMonetaryDefense Included In Excess Exposure = True 
                            if (!string.IsNullOrEmpty(optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure) && optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedPremium = 0;
                            }
                        }
                    }

                    #region Optional Coverage VI -Other

                    if (optionalCoverageInputModel.EmploymentPracticesSchoolOtherCoverageModel != null)
                    {
                        CalculateOtherOptionalCoveragePremium(model, proRataFactor);
                    }

                    #endregion
                }

                #region Optional Coverage V - Suppl. Extended Reporting Period

                if (optionalCoverageInputModel.SupplExtendedReportingPeriodIsSelected && policyHeaderModel.TransactionType == TransactionTypeConstant.ENDORSEMENT)
                {
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodIsSelected = optionalCoverageInputModel.SupplExtendedReportingPeriodIsSelected;
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodAggregateLimit = optionalCoverageInputModel.SupplExtendedReportingPeriodAggregateLimit;
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodDeductible = optionalCoverageInputModel.SupplExtendedReportingPeriodDeductible;
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodLimit = optionalCoverageInputModel.SupplExtendedReportingPeriodLimit;
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodModifiedPremium = optionalCoverageInputModel.SupplExtendedReportingPeriodModifiedPremium;
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodRate = optionalCoverageInputModel.SupplExtendedReportingPeriodRate;
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodRatingBasis = optionalCoverageInputModel.SupplExtendedReportingPeriodRatingBasis;
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodReturnMethod = optionalCoverageInputModel.SupplExtendedReportingPeriodReturnMethod;
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodIncludedInExcessExposure = optionalCoverageInputModel.SupplExtendedReportingPeriodIncludedInExcessExposure;

                    // step 2
                    //Suppl. Extended Reporting Period Rate
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodRate = Convert.ToInt32(_DataAccess.GetOptionalCoverageRate(policyHeaderModel.State,
                                                                                                                                       policyHeaderModel.PrimaryClass,
                                                                                                                                       inputModel.LineOfBusiness,
                                                                                                                                       "Suppl.Extended Reporting Period",
                                                                                                                                       optionalCoverageInputModel.SupplExtendedReportingPeriodLimit,
                                                                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                       policyHeaderModel.PolicyExpirationDate));

                    //Annualized EPS Premium
                    var annualizedEPSPremium = 1;

                    // step 3
                    //Suppl. Extended Reporting Period Unmodified Premium 
                    // Step 2 * (Annualized Final EP Premium of the last bound transaction)
                    // TODO Annualized Final EP Premium of the last bound transaction not found

                    optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(optionalCoverageOutputModel.SupplExtendedReportingPeriodRate
                                                                                                                                      * annualizedEPSPremium
                                                                                                                                      , 0
                                                                                                                                      , MidpointRounding.AwayFromZero));

                    optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium = Convert.ToInt32(optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium);
                    
                    optionalCoverageOutputModel.SupplExtendedReportingPeriodIncludedInExcessExposure = optionalCoverageInputModel.SupplExtendedReportingPeriodIncludedInExcessExposure;

                    //step 5
                    // If input value is blank then Refer to lookup table. otherwise "SupplExtendedReportingPeriod Included in Excess Exposure" = input                        
                    if (string.IsNullOrEmpty(optionalCoverageInputModel.SupplExtendedReportingPeriodIncludedInExcessExposure))
                    {
                        optionalCoverageOutputModel.SupplExtendedReportingPeriodIncludedInExcessExposure = this._DataAccess.GetExcessExposure(policyHeaderModel.State,
                                                                                                                                              inputModel.LineOfBusiness,
                                                                                                                                              policyHeaderModel.PrimaryClass,
                                                                                                                                              "Suppl. Extended Reporting Period",
                                                                                                                                              policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                              policyHeaderModel.PolicyExpirationDate);
                    }

                    //If LineOfBusiness Excess = True and Liability Limit = 1,000,000
                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == LiabilityLimitExcessValue)
                    {
                        //step 6 Suppl Extended Reporting Period Un-Modified Premium
                        // If NonMonetaryDefense Included In Excess Exposure = True  
                        if (!string.IsNullOrEmpty(optionalCoverageOutputModel.SupplExtendedReportingPeriodIncludedInExcessExposure) && optionalCoverageOutputModel.SupplExtendedReportingPeriodIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
                        }
                    }
                }

                #endregion

                //Step A - Base Premium Calculation
                //Step-A.1
                //Step 1 * Step 2 * Step 3 * Step 4 * Step 5 * Step 6 * Step 7 * Step 8 * Step 9 * Step 10 * Step 11  * Step 12 * Step 13
                outputModel.BasePremium = Convert.ToInt32(Math.Round((inputModel.Exposure *
                                                                      outputModel.ExposureRate *
                                                                      outputModel.EPInclusionExclusionRate *
                                                                      outputModel.LiabilityLimitRate *
                                                                      outputModel.AggregateLimitRate *
                                                                      outputModel.RetentionRate *
                                                                      outputModel.PopulationRate *
                                                                      outputModel.LocationRate *
                                                                      outputModel.PolicyTypeRate *
                                                                      outputModel.YearsinCMRate *
                                                                      outputModel.RetroDateRate *
                                                                      outputModel.LossExperienceRate *
                                                                      proRataFactor)
                                                                      , 0
                                                                      , MidpointRounding.AwayFromZero));

                //Step B - Non-Modified Premium Calculation
                //Step-B.1
                //Sum of all the added optional coverage premium  

                outputModel.NonModifiedPremium = optionalCoverageOutputModel.EEOCUnmodifiedPremium +
                                                 optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium +
                                                 optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium +
                                                 optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedPremium;

                if (optionalCoverageOutputModel.EmploymentPracticesSchoolOtherCoverageModel != null)
                {
                    outputModel.NonModifiedPremium = outputModel.NonModifiedPremium +
                                                     optionalCoverageOutputModel.EmploymentPracticesSchoolOtherCoverageModel.Sum(x => x.OtherCoverageUnmodifiedPremium);

                }


                // Step I - EPS Total Unmodified Without Excess Premium Calculation
                // Sum of the Umodified Without Excess Pemium of all the added optional coverages where Included In Excess Exposure = True

                var totalUnmodifiedWithoutExcessPremium = 0M;
                int othercoverageWithoutExcessPremium = 0;
                if (optionalCoverageOutputModel != null)
                {
                    if (!string.IsNullOrEmpty(optionalCoverageOutputModel.EEOCIncludedInExcessExposure) && optionalCoverageOutputModel.EEOCIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + optionalCoverageOutputModel.EEOCUnmodifiedWithoutExcessPremium;
                    }
                    if (!string.IsNullOrEmpty(optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure) && optionalCoverageOutputModel.NonMonetaryDefenseIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + optionalCoverageOutputModel.NonMonetaryDefenseUnmodifiedWithoutExcessPremium;
                    }
                    if (!string.IsNullOrEmpty(optionalCoverageOutputModel.SupplExtendedReportingPeriodIncludedInExcessExposure) && optionalCoverageOutputModel.SupplExtendedReportingPeriodIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium;
                    }
                    if (!string.IsNullOrEmpty(optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure) && optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + optionalCoverageOutputModel.LossAdjustmentExpenseWrongfulActUnmodifiedWithoutExcessPremium;
                    }

                    if (optionalCoverageOutputModel.EmploymentPracticesSchoolOtherCoverageModel != null)
                    {
                        othercoverageWithoutExcessPremium = optionalCoverageOutputModel.EmploymentPracticesSchoolOtherCoverageModel.Where(y => !string.IsNullOrEmpty(y.OtherCoverageIncludedInExcessExposure) && y.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE").Sum(x => x.OtherCoverageUnmodifiedWithoutExcessPremium);
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + othercoverageWithoutExcessPremium;
                    }
                }
                outputModel.EPSTotalUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(totalUnmodifiedWithoutExcessPremium, 0, MidpointRounding.AwayFromZero));

                this._Logger.Info("EmploymentPracticesSchoolService.CalculateOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesSchoolService.EPSCalculation :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
        #endregion

        #region Optional Coverage VI -Other

        /// <summary>
        /// CalculateOtherOptionalCoveragePremium
        /// </summary>
        /// <param name="model"></param>
        /// <param name="proRataFactor"></param>
        public void CalculateOtherOptionalCoveragePremium(RaterFacadeModel model, decimal proRataFactor)
        {
            this._Logger.Info("EmploymentPracticesSchoolService.CalculateOtherOptionalCoveragePremium :: Starting");
            try
            {
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
                var outputOptionalCoveragePremiumModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel;
                var otherCoverageInputModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel.EmploymentPracticesSchoolOtherCoverageModel;
                var otherCoverageOutputModelList = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel.EmploymentPracticesSchoolOtherCoverageModel;

                foreach (var otherCoverageInput in otherCoverageInputModelList)
                {
                    EmploymentPracticesSchoolOtherCoverageOutputModel otherCoverageOutput = new EmploymentPracticesSchoolOtherCoverageOutputModel();

                    otherCoverageOutput.OtherCoverageAggregateLimit = otherCoverageInput.OtherCoverageAggregateLimit;
                    otherCoverageOutput.OtherCoverageDeductible = otherCoverageInput.OtherCoverageDeductible;
                    otherCoverageOutput.OtherCoverageDescription = otherCoverageInput.OtherCoverageDescription;
                    otherCoverageOutput.OtherCoverageID = otherCoverageInput.OtherCoverageID;
                    otherCoverageOutput.OtherCoverageLimit = otherCoverageInput.OtherCoverageLimit;
                    otherCoverageOutput.OtherCoverageModifiedPremium = otherCoverageInput.OtherCoverageModifiedPremium;
                    otherCoverageOutput.OtherCoverageRate = otherCoverageInput.OtherCoverageRate;
                    otherCoverageOutput.OtherCoverageRatingBasis = otherCoverageInput.OtherCoverageRatingBasis;
                    otherCoverageOutput.OtherCoverageReturnMethod = otherCoverageInput.OtherCoverageReturnMethod;
                    otherCoverageOutput.OtherCoverageUnmodifiedPremium = otherCoverageInput.OtherCoverageUnmodifiedPremium;
                    otherCoverageOutput.OtherCoverageIncludedInExcessExposure = otherCoverageInput.OtherCoverageIncludedInExcessExposure;

                    //Optional Coverage IV - Other
                    var otherCoverageUnmodifiedPremium = 0M;

                    // When Rating basis is 'Flat charge'
                    if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARGE")
                    {
                        //step 1 
                        otherCoverageUnmodifiedPremium = Math.Round((otherCoverageInput.OtherCoverageUnmodifiedPremium
                                                                     * proRataFactor)
                                                                     , 0
                                                                     , MidpointRounding.AwayFromZero);

                        otherCoverageOutput.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(otherCoverageUnmodifiedPremium);
                    }

                    // When Rating basis is 'per 1000 of limit'
                    else if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                    {
                        //step 3 - (Step 1 /1000) * Step 2 * Step 13
                        otherCoverageUnmodifiedPremium = Math.Round((otherCoverageInput.OtherCoverageLimit
                                                                    / 1000)
                                                                    * otherCoverageInput.OtherCoverageRate
                                                                    * proRataFactor
                                                                    , 0
                                                                    , MidpointRounding.AwayFromZero);

                        otherCoverageOutput.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(otherCoverageUnmodifiedPremium);
                    }

                    // When Rating basis is 'per 100 of limit'
                    else if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                    {
                        //step 3 - (Step 1 /100) * Step 2 * Step 13

                        otherCoverageUnmodifiedPremium = Math.Round((otherCoverageInput.OtherCoverageLimit
                                                                    / 100)
                                                                    * otherCoverageInput.OtherCoverageRate
                                                                    * proRataFactor
                                                                    , 0
                                                                    , MidpointRounding.AwayFromZero);

                        otherCoverageOutput.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(otherCoverageUnmodifiedPremium);
                    }

                    // When Rating basis is 'No Charge'
                    else if (otherCoverageInput.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                    {
                        //step 1
                        otherCoverageOutput.OtherCoverageUnmodifiedWithoutExcessPremium = 0;
                    }

                    otherCoverageOutput.OtherCoverageUnmodifiedPremium = Convert.ToInt32(otherCoverageOutput.OtherCoverageUnmodifiedWithoutExcessPremium);
                   
                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Other Coverage Included in Excess Exposure" = input

                    if (string.IsNullOrEmpty(otherCoverageInput.OtherCoverageIncludedInExcessExposure))
                    {
                        otherCoverageOutput.OtherCoverageIncludedInExcessExposure = this._DataAccess.GetExcessExposure(policyHeaderModel.State,
                                                                                                                       inputModel.LineOfBusiness,
                                                                                                                       policyHeaderModel.PrimaryClass,
                                                                                                                       "Other",
                                                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                                                       policyHeaderModel.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == LiabilityLimitExcessValue)
                    {
                        //step 3 Other Coverage Un-Modified Premium
                        // If Other Coverage Included In Excess Exposure = True
                        if (!string.IsNullOrEmpty(otherCoverageOutput.OtherCoverageIncludedInExcessExposure) && otherCoverageOutput.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            otherCoverageOutput.OtherCoverageUnmodifiedPremium = 0;
                        }
                    }

                    otherCoverageOutputModelList.Add(otherCoverageOutput);
                }

                this._Logger.Info("EmploymentPracticesSchoolService.CalculateOtherOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesSchoolService.EPSCalculation :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
        #endregion

        /// <summary>
        /// CalculateOthersPremium
        /// </summary>
        /// <param name="model"></param>
        private void CalculateOthersPremium(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("EmploymentPracticesSchoolService.CalculateOthersPremium :: Started");

                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool;
                var optionalCoverageOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                //Step C - Manual Premium Calculation
                // Read Minimum Premium lookup table to get Minimum Premium
                decimal lobMinimumPremium = _DataAccess.GetLOBTotalPremium(policyHeaderModel.State,
                                                                           inputModel.LineOfBusiness,
                                                                           policyHeaderModel.PrimaryClass,
                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                           policyHeaderModel.PolicyExpirationDate);

                //Step-C.1
                //Step A.1 + Step B.1
                decimal manualPremium = outputModel.BasePremium + outputModel.NonModifiedPremium;
                manualPremium = Math.Round(manualPremium, 0, MidpointRounding.AwayFromZero);

                outputModel.ManualPremium = Convert.ToInt32(manualPremium);

                // This step will be executed only If calculated Manual Premium in step C.1 < LOB Minimum Premium
                if (outputModel.ManualPremium < lobMinimumPremium)
                {
                    outputModel.ManualPremium = Convert.ToInt32(Math.Round(lobMinimumPremium, 0, MidpointRounding.AwayFromZero));
                }


                //Step D - Tier Premium Calculation 
                //((Step C.1  - Step B.1)  * Step 15 + Step B.1
                decimal tierPremium = Convert.ToInt32((manualPremium                      // before applied lobMinPremium.
                                                     - outputModel.NonModifiedPremium)
                                                     * outputModel.TierRate
                                                     + outputModel.NonModifiedPremium);

                tierPremium = Math.Round(tierPremium, 0, MidpointRounding.AwayFromZero);

                outputModel.TierPremium = Convert.ToInt32(tierPremium);
                // This step will be executed only If calculated Tier Premium in step C.1 < LOB Minimum Premium
                if (outputModel.TierPremium < lobMinimumPremium)
                {
                    outputModel.TierPremium = Convert.ToInt32(Math.Round(lobMinimumPremium, 0, MidpointRounding.AwayFromZero));
                }

                //Step E - IRPM Premium Calculation
                //Step E.1 - Get system calculated value
                //((Step D.1  - Step B.1)  * Step 16 + Step B.1
                var irpmPremium = (tierPremium
                                 - outputModel.NonModifiedPremium)
                                 * outputModel.IRPMRate
                                 + outputModel.NonModifiedPremium;

                irpmPremium = Math.Round(irpmPremium, 0, MidpointRounding.AwayFromZero);

                outputModel.IRPMPremium = Convert.ToInt32(irpmPremium);
                // This step will be executed only If calculated IRPM Premium in step C.1 < LOB Minimum Premium
                if (outputModel.IRPMPremium < lobMinimumPremium)
                {
                    outputModel.IRPMPremium = Convert.ToInt32(Math.Round(lobMinimumPremium, 0, MidpointRounding.AwayFromZero));
                }

                //Step F - Other Mod Premium Calculation
                //Step F.1 - Get system calculated value
                //((Step E.1  - Step B.1)  * Step 17 + Step B.1
                decimal otherModPremium = (irpmPremium
                                         - outputModel.NonModifiedPremium)
                                         * outputModel.OtherModRate
                                         + outputModel.NonModifiedPremium;

                otherModPremium = Math.Round(otherModPremium, 0, MidpointRounding.AwayFromZero);

                outputModel.OtherModPremium = Convert.ToInt32(otherModPremium);
                // This step will be executed only If calculated Other Mod Premium in step F.1 < LOB Minimum Premium
                if (outputModel.OtherModPremium < lobMinimumPremium)
                {
                    outputModel.OtherModPremium = Convert.ToInt32(Math.Round(lobMinimumPremium, 0, MidpointRounding.AwayFromZero));
                }

                //Step G - Terrorism Premium Calculation
                //Step G.1 - Get system calculated value
                //Step F.1 * Step 14
                //Todo
                if (model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected)
                {
                    decimal terrorismPremium = outputModel.OtherModPremium * outputModel.TerrorismRate;

                    outputModel.TerrorismPremium = Convert.ToInt32(terrorismPremium);
                }

                //Step H - Final Premium Calculation
                //Step H.1 - Get system calculated value
                //Step F.1 + Step G.1
                decimal finalPremium = otherModPremium + outputModel.TerrorismPremium;

                outputModel.EPSFinalModifiedPremium = Convert.ToInt32(Math.Round(finalPremium, 0, MidpointRounding.AwayFromZero));

                // This step will be executed only If calculated Other Mod Premium in step F.1 < LOB Minimum Premium
                if (outputModel.EPSFinalModifiedPremium < lobMinimumPremium)
                {
                    outputModel.EPSFinalModifiedPremium = Convert.ToInt32(Math.Round(lobMinimumPremium, 0, MidpointRounding.AwayFromZero));
                }

                //  check If Suppl. Extended Reporting Period Is Selected then
                if (optionalCoverageOutputModel != null && inputModel.EmploymentPracticesSchoolOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    // Calculate ManualPremium= (A.1 - Suppl. Extended Reporting Period Unmodified Premium)
                    outputModel.ManualPremium = outputModel.BasePremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    // This step will be executed only If calculated Manual Premium in step C.1 < LOB Minimum Premium
                    if (outputModel.ManualPremium < lobMinimumPremium)
                    {
                        outputModel.ManualPremium = Convert.ToInt32(Math.Round((lobMinimumPremium + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium), 0, MidpointRounding.AwayFromZero));
                    }

                    // Calculate TierPremium= (D.1 - Suppl. Extended Reporting Period Unmodified Premium)
                    outputModel.TierPremium = outputModel.TierPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    // This step will be executed only If calculated Tier Premium in step D.1 < LOB Minimum Premium
                    if (outputModel.TierPremium < lobMinimumPremium)
                    {
                        outputModel.TierPremium = Convert.ToInt32(Math.Round(lobMinimumPremium + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0, MidpointRounding.AwayFromZero));
                    }

                    // Calculate IRPMPremium= (E.1 - Suppl. Extended Reporting Unmodified Premium)
                    outputModel.IRPMPremium = outputModel.IRPMPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    // This step will be executed only If calculated IRPM Premium in step E.1 < LOB Minimum Premium
                    if (outputModel.IRPMPremium < lobMinimumPremium)
                    {
                        outputModel.IRPMPremium = Convert.ToInt32(Math.Round(lobMinimumPremium) + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium);
                    }

                    // Calculate OtherModPremium = (F.1 - Suppl. Extended Reporting Unmodified Premium)
                    outputModel.OtherModPremium = outputModel.OtherModPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    // This step will be executed only If calculated Other Mod Premium in step F.1 < LOB Minimum Premium
                    if (outputModel.OtherModPremium < lobMinimumPremium)
                    {
                        outputModel.OtherModPremium = Convert.ToInt32(Math.Round(lobMinimumPremium + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0, MidpointRounding.AwayFromZero));
                    }

                    // Calculate EPSFinalModifiedPremium = (G.1 - Suppl. Extended Reporting Unmodified Premium)
                    outputModel.EPSFinalModifiedPremium = outputModel.EPSFinalModifiedPremium - optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium;

                    // This step will be executed only If calculated Other Mod Premium in step G.1 < LOB Minimum Premium
                    if (outputModel.EPSFinalModifiedPremium < lobMinimumPremium)
                    {
                        outputModel.EPSFinalModifiedPremium = Convert.ToInt32(Math.Round(lobMinimumPremium + optionalCoverageOutputModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0, MidpointRounding.AwayFromZero));
                    }
                }

                this._Logger.Info("EmploymentPracticesSchoolService.CalculateOthersPremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesSchoolService.CalculateOthersPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region Get Yearfrac

        /// <summary>
        /// YearFrac
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>decimal</returns>
        public decimal YearFrac(DateTime startDate, DateTime endDate)
        {
            int endDay = endDate.Day;
            int startDay = startDate.Day;
            try
            {
                this._Logger.Info("EmploymentPracticesSchoolService.YearFrac :: Starting");


                if (endDate < startDate)
                {
                    //   throw new ArgumentOutOfRangeException("endDate cannot be less than startDate");
                    return 0;
                }

                switch (startDay)
                {
                    case 31:
                        {
                            startDay = 30;
                            if (endDay == 31)
                            {
                                endDay = 30;
                            }
                        }
                        break;

                    case 30:
                        {
                            if (endDay == 31)
                            {
                                endDay = 30;
                            }
                        }
                        break;

                    case 29:
                        {
                            if (startDate.Month == 2)
                            {
                                startDay = 30;
                                if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                                {
                                    endDay = 30;
                                }
                            }
                        }
                        break;

                    case 28:
                        {
                            if ((startDate.Month == 2) && (!DateTime.IsLeapYear(startDate.Year)))
                            {
                                startDay = 30;
                                if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                                {
                                    endDay = 30;
                                }
                            }
                        }
                        break;
                }
                this._Logger.Info("EmploymentPracticesSchoolService.YearFrac :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("EmploymentPracticesSchoolService.YearFrac :: Exception :: " + ex.Message, ex);
                throw;
            }
            return (((endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDay - startDay)) / 360);
        }
        #endregion        
    }
}
