﻿using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace RateEmploymentPracticesSchool
{
    public interface IEmploymentPracticesSchoolService
    {
        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model);

        void Calculate(RaterFacadeModel model);
        void CalculationEPS(RaterFacadeModel model);
        void CalculateOptionalCoveragePremium(RaterFacadeModel model);
    }
}
