﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.GeneralLiability.output;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Validations;

namespace RaterGeneralLiability
{
    public class GeneralLiabilityService : IGeneralLiabilityService
    {
        private readonly int ProRata = 1;
        private GeneralLiabilityDataAccess generalLiabilityDataAccess { get; set; }

        readonly ILoggingManager logger;

        readonly IConfiguration configuration;

        private readonly string[] LiabilityCheck = new string[2] { "1000000", "500/1000/500" };

        private int totalOtherCoverageUnmodifiedPremium = 0;
        private int totalOtherCoverageUnmodifiedwithoutExcessPremium = 0;

        public GeneralLiabilityService(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.generalLiabilityDataAccess = new GeneralLiabilityDataAccess(this.configuration, this.logger);
        }

        public DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            this.logger.Info("GeneralLiabilityService.ExecuteDomainRules :: Starting");
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            this.logger.Info("GeneralLiabilityService.ExecuteDomainRules :: Completed");
            return validationResult;
        }

        public FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.PreValidate :: Started");

                var validator = new GeneralLiabilityPreValidator(this.configuration, this.logger);
                var results = validator.Validate(model);

                this.logger.Info("GeneralLiabilityService.PreValidate :: Completed");
                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);

                throw;
            }
        }

        public FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.PostValidate :: Started");

                var validator = new GeneralLiabilityPostValidator(this.configuration, this.logger);
                var results = validator.Validate(model);

                this.logger.Info("GeneralLiabilityService.PostValidate :: Completed");

                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);
                throw;
            }
        }

        public void Calculate(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.Calculate :: Started");

                #region CalculateBasePremium

                CalculateBasePremium(model);

                #endregion

                #region CalculateDamageToPremisesPremium

                CalculateDamageToPremisesPremium(model);

                #endregion

                #region CalculateMedicalPaymentsPremium

                CalculateMedicalPaymentsPremium(model);

                #endregion

                #region CalculateEmployeeBenefitsPremium

                CalculateEmployeeBenefitsPremium(model);

                #endregion

                #region CalculateDataCompromisePremium

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.DataCompromiseLimit != 0)
                {
                    CalculateDataCompromisePremium(model);
                }

                #endregion

                #region CalculateCyberPremium
                if ((model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ComputerAttackLimit != 0 || model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.NetworkSecurityAndElectronicMediaLiabilityLimit != 0))
                {
                    CalculateCyberPremium(model);
                }

                #endregion

                #region CalculateUnmannedAircraftTotalPremium

                CalculateUnmannedAircraftTotalPremium(model);

                #endregion

                #region CalculateOptionalCoveragePremium

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel != null)
                {
                    CalculateOptionalCoveragePremium(model);
                }

                #endregion

                #region CalculateNonModifiedPremium

                CalculateNonModifiedPremium(model);

                #endregion

                #region CalculateModifiablePremium

                CalculateModifiablePremium(model);

                #endregion

                #region CalculateManualPremium

                CalculateManualPremium(model);

                #endregion

                #region CalculateTierPremium

                CalculateTierPremium(model);

                #endregion

                #region CalculateIRPMPremium

                CalculateIRPMPremium(model);

                #endregion

                #region CalculateOtherModPremium

                CalculateOtherModPremium(model);

                #endregion

                #region CalculateTerrorismPremium

                CalculateTerrorismPremium(model);

                #endregion

                #region CalculateFinalModifiedPremium

                CalculateFinalModifiedPremium(model);

                #endregion

                #region CalculateTotalUnmodifiedWithoutExcessPremium

                CalculateTotalUnmodifiedWithoutExcessPremium(model);

                #endregion

                this.logger.Info("GeneralLiabilityService.Calculate :: Completed");

            }
            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Base Premium for General Liability
        /// </summary>
        /// <param name="model"></param>
        public void CalculateBasePremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateBasePremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                policyHeader.State = policyHeader.State.ToUpper();
                policyHeader.PrimaryClass = policyHeader.PrimaryClass.ToUpper();
                policyHeader.TransactionType = policyHeader.TransactionType.ToUpper();

                string[] primaryClassCheck = new string[7] { "MU", "MSC", "CO", "WSU", "EGU", "SP", "PNP" };

                // Step 1 Get value from Input Json
                if (primaryClassCheck.Contains(policyHeader.PrimaryClass) || (policyHeader.PrimaryClass == PrimaryClassConstant.FD && policyHeader.State != StateCodeConstant.NY))
                {
                    outputProperty.Exposure = inputProperty.Exposure / 1000;

                    if (policyHeader.PrimaryClass == "WSU" || policyHeader.PrimaryClass == "EGU" || policyHeader.PrimaryClass == "PNP")
                    {
                        outputProperty.RatingBasis = "Payroll (less clerical)";
                    }
                    else if (policyHeader.PrimaryClass == "MSC")
                    {
                        outputProperty.RatingBasis = "Adjusted Gross Operating Expenditures and student";
                    }
                    else if (policyHeader.PrimaryClass == "CO" || policyHeader.PrimaryClass == "MU" || policyHeader.PrimaryClass == "SP" || policyHeader.PrimaryClass == "FD")
                    {
                        outputProperty.RatingBasis = "Adjusted Gross Operating Expenditures/Payroll";
                    }
                }
                else
                {
                    if (policyHeader.PrimaryClass == "SC")
                    {
                        outputProperty.Exposure = inputProperty.Exposure;
                        outputProperty.RatingBasis = "Student";
                    }
                    else if (policyHeader.PrimaryClass == PrimaryClassConstant.FD && policyHeader.State == StateCodeConstant.NY)
                    {
                        outputProperty.RatingBasis = "Firefighter, EMT and Paramedic";
                        outputProperty.Exposure = inputProperty.Exposure;
                    }
                }

                //Step 2 - Get Base rate from lookup table/Input Json
                if (policyHeader.State == StateCodeConstant.MO || policyHeader.State == StateCodeConstant.NY)
                {
                    DataTable dtExposureRate = generalLiabilityDataAccess.GetBaseRate(policyHeader.State, policyHeader.PrimaryClass, inputProperty.LineOfBusiness, policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);
                    if (dtExposureRate != null && dtExposureRate.Rows.Count > 0)
                    {
                        outputProperty.ExposureRate = Convert.ToDecimal(dtExposureRate.Rows[0]["BaseRate"]);
                    }
                }
                else
                {
                    if (inputProperty.ExposureRate < 0)
                    {
                        DataTable dtExposureRate = generalLiabilityDataAccess.GetBaseRate(policyHeader.State, policyHeader.PrimaryClass, inputProperty.LineOfBusiness, policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);
                        if (dtExposureRate != null && dtExposureRate.Rows.Count > 0)
                        {
                            outputProperty.ExposureRate = Convert.ToDecimal(dtExposureRate.Rows[0]["BaseRate"]);
                        }
                    }
                    else
                    {
                        outputProperty.ExposureRate = inputProperty.ExposureRate;
                    }
                }

                // output Json is not available in Sheet.
                if (policyHeader.PrimaryClass == "MSC")
                {
                    //Step 3 - Get value from Input Json
                    outputProperty.ADA = inputProperty.ADA;

                    //Step 4 - Get rate from lookup table/Json
                    if (inputProperty.ADARate < 0)
                    {
                        DataTable dtExposureRate = generalLiabilityDataAccess.GetBaseRate(policyHeader.State, policyHeader.PrimaryClass, inputProperty.LineOfBusiness, policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);
                        if (dtExposureRate != null && dtExposureRate.Rows.Count > 0)
                        {
                            outputProperty.ADARate = Convert.ToDecimal(dtExposureRate.Rows[0]["BaseRate"]);
                        }
                    }
                    else
                    {
                        outputProperty.ADARate = inputProperty.ADARate;
                    }
                }

                //Step 5 - Get LiabilityLimitRate from lookup table/Json
                var liabilityLimitRateState = new string[] { "AL", "CO", "CT", "DE", "GA", "IL", "IN", "MA", "ME", "MI", "MN", "MS", "NC", "NH", "OH", "PA", "SC", "TX", "UT", "VT", "WY" };

                if (policyHeader.State == "KS" || policyHeader.State == "MO" || policyHeader.State == "NY")
                {
                    DataTable dtLiabilityLimitRate = generalLiabilityDataAccess.GetLiabilityLimitRate(policyHeader.State, inputProperty.LineOfBusiness, inputProperty.LiabilityLimit, policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);

                    if (dtLiabilityLimitRate != null && dtLiabilityLimitRate.Rows.Count > 0)
                    {
                        outputProperty.LiabilityLimitRate = Convert.ToDecimal(dtLiabilityLimitRate.Rows[0]["DefaultRate"]);
                    }
                }
                else if (liabilityLimitRateState.Contains(policyHeader.State))
                {
                    if (inputProperty.LiabilityLimitRate < 0)
                    {
                        DataTable dtLiabilityLimitRate = generalLiabilityDataAccess.GetLiabilityLimitRate(policyHeader.State, inputProperty.LineOfBusiness, inputProperty.LiabilityLimit, policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);
                        if (dtLiabilityLimitRate != null && dtLiabilityLimitRate.Rows.Count > 0)
                        {
                            outputProperty.LiabilityLimitRate = Convert.ToDecimal(dtLiabilityLimitRate.Rows[0]["DefaultRate"]);
                        }
                    }
                    else
                    {
                        outputProperty.LiabilityLimitRate = inputProperty.LiabilityLimitRate;
                    }
                }

                //Step 6 - Get AggregateLimitFactor from lookup table
                outputProperty.AggregateLimitFactor = generalLiabilityDataAccess.GetAggregateLimitFactor(policyHeader.State,
                                                                                                         inputProperty.LineOfBusiness,
                                                                                                         inputProperty.LiabilityLimit,
                                                                                                         inputProperty.AggregateLimit,
                                                                                                         policyHeader.PolicyEffectiveDate,
                                                                                                         policyHeader.PolicyExpirationDate);

                //Step 7 - Get RetentionFactor from lookup tables
                outputProperty.RetentionFactor = generalLiabilityDataAccess.GetRetentionFactor(policyHeader.State,
                                                                                               inputProperty.LineOfBusiness,
                                                                                               inputProperty.DeductibleSIR,
                                                                                               inputProperty.Retention,
                                                                                               policyHeader.PolicyEffectiveDate,
                                                                                               policyHeader.PolicyExpirationDate);

                //Step 8 - Get PopulationFactor from lookup tables
                DataTable dtPopulationFactor = generalLiabilityDataAccess.GetPopulationFactor(policyHeader.State,
                                                                                              policyHeader.PrimaryClass,
                                                                                              inputProperty.LineOfBusiness,
                                                                                              policyHeader.PopulationADA,
                                                                                              policyHeader.PolicyEffectiveDate,
                                                                                              policyHeader.PolicyExpirationDate);

                if (dtPopulationFactor != null && dtPopulationFactor.Rows.Count > 0)
                {
                    outputProperty.PopulationFactor = Convert.ToDecimal(dtPopulationFactor.Rows[0]["Rate"]);
                }

                //Step 9 - Get LocationFactor from lookup tables
                outputProperty.LocationFactor = generalLiabilityDataAccess.GetLocationFactor(policyHeader.State,
                                                                                             inputProperty.LineOfBusiness,
                                                                                             policyHeader.LocationType,
                                                                                             policyHeader.PolicyEffectiveDate,
                                                                                             policyHeader.PolicyExpirationDate);

                //Step 10 - Get rate from lookup tables
                outputProperty.PolicyTypeFactor = generalLiabilityDataAccess.GetPolicyTypeFactor(policyHeader.State,
                                                                                                 inputProperty.LineOfBusiness,
                                                                                                 inputProperty.PolicyType,
                                                                                                 policyHeader.PolicyEffectiveDate,
                                                                                                 policyHeader.PolicyExpirationDate);


                decimal yearFrac = this.YearFrac(inputProperty.RetroActiveDate, policyHeader.PolicyEffectiveDate);

                outputProperty.RetroYear = (int)Math.Round(yearFrac, 0);

                string stringRetroYear = outputProperty.RetroYear >= 6 ? ">6" : outputProperty.RetroYear.ToString();

                if (inputProperty.PolicyType.ToUpper() == "OCCURRENCE")
                {
                    outputProperty.YearsinCMFactor = 1.00M;

                    outputProperty.RetroDateFactor = 1.00M;
                }
                else
                {
                    //Step 11 - Get YearsinCMFactor from lookup tables
                    outputProperty.YearsinCMFactor = generalLiabilityDataAccess.GetYearsInCMFactor(policyHeader.State,
                                                                                                   inputProperty.LineOfBusiness,
                                                                                                   inputProperty.PolicyType,
                                                                                                   inputProperty.YearsinClaimsMadeProgram,
                                                                                                   policyHeader.PolicyEffectiveDate,
                                                                                                   policyHeader.PolicyExpirationDate);

                    //Step 12 - Get RetroDateFactor from lookup tables
                    outputProperty.RetroDateFactor = generalLiabilityDataAccess.GetRetroDateFactor(policyHeader.State,
                                                                                                   inputProperty.LineOfBusiness,
                                                                                                   stringRetroYear,
                                                                                                   policyHeader.PolicyEffectiveDate,
                                                                                                   policyHeader.PolicyExpirationDate);
                }


                var lossExperienceAndTierState = new string[] { "CT", "DE", "ME", "MA", "NH", "VT" };
                var lossExperienceAndTierState1 = new string[] { "AL", "CO", "GA", "KS", "MI", "MN", "MS", "MO", "NC", "IL", "IN", "OH", "PA", "SC", "TX", "UT", "WY" };


                if (lossExperienceAndTierState.Contains(policyHeader.State))
                {
                    //For States -CT, DE, ME, MA, NH, VT
                    //Step 13 - Get LossExperienceFactor from lookup tables
                    outputProperty.LossExperienceFactor = generalLiabilityDataAccess.GetLossExperienceFactor(policyHeader.State,
                                                                                                             inputProperty.LineOfBusiness,
                                                                                                             inputProperty.LossExperienceIsSelected,
                                                                                                             policyHeader.PolicyEffectiveDate,
                                                                                                             policyHeader.PolicyExpirationDate);

                    //For States - CT, DE, ME, MA, NH, VT
                    //Step 16 - Get TierFactor from lookup table
                    outputProperty.TierFactor = generalLiabilityDataAccess.GetTierFactor(policyHeader.State,
                                                                                         inputProperty.LineOfBusiness,
                                                                                         model.RaterInputFacadeModel.PricingInputModel.TierPlan,
                                                                                         policyHeader.PolicyEffectiveDate,
                                                                                         policyHeader.PolicyExpirationDate);

                }
                else if (lossExperienceAndTierState1.Contains(policyHeader.State))
                {
                    //Step 13 - Get LossExperienceFactor from lookup tables
                    //When State =  AL, CO, GA, KS, MI. MN, MS, MO, NC, IL, IN, OH, PA, SC, TX, UT, WY
                    outputProperty.LossExperienceFactor = generalLiabilityDataAccess.GetLossExperienceFactor(policyHeader.State,
                                                                                                             inputProperty.LineOfBusiness,
                                                                                                             null,
                                                                                                             policyHeader.PolicyEffectiveDate,
                                                                                                             policyHeader.PolicyExpirationDate);

                    //Step 16 - Get TierFactor from lookup table
                    //When State =  AL, CO, GA, KS, MI. MN, MS, MO, NC, IL, IN, OH, PA, SC, TX, UT, WY
                    outputProperty.TierFactor = generalLiabilityDataAccess.GetTierFactor(policyHeader.State,
                                                                                         inputProperty.LineOfBusiness,
                                                                                         null,
                                                                                         policyHeader.PolicyEffectiveDate,
                                                                                         policyHeader.PolicyExpirationDate);
                }



                //Step 14 - Get system calculated value (ProRate)

                //Step 15- Get Terrorism factor from lookup table
                outputProperty.TerrorismFactor = generalLiabilityDataAccess.GetTerrorismFactor(policyHeader.State,
                                                                                               inputProperty.LineOfBusiness,
                                                                                               policyHeader.PolicyEffectiveDate,
                                                                                               policyHeader.PolicyExpirationDate);
                //Step 17 - Get IRPMFactor from input Json
                outputProperty.IRPMFactor = inputProperty.IRPMFactor;

                //Step 18 - Get Other Mod factor from Json
                outputProperty.OtherModFactor = inputProperty.OtherModFactor;

                //Step A - Base Premium Calculation	
                if (policyHeader.PrimaryClass.ToUpper() == "MSC")
                {

                    outputProperty.BasePremium = Convert.ToInt32(Math.Round(((outputProperty.Exposure
                                                                            * outputProperty.ExposureRate)
                                                                            + (outputProperty.ADA
                                                                            * outputProperty.ADARate))
                                                                            * outputProperty.LiabilityLimitRate
                                                                            * outputProperty.AggregateLimitFactor
                                                                            * outputProperty.RetentionFactor
                                                                            * outputProperty.PopulationFactor
                                                                            * outputProperty.LocationFactor
                                                                            * outputProperty.YearsinCMFactor
                                                                            * outputProperty.RetroDateFactor
                                                                            * outputProperty.LossExperienceFactor
                                                                            * ProRata
                                                                            , 0
                                                                            , MidpointRounding.AwayFromZero));
                }
                else
                {
                    outputProperty.BasePremium = Convert.ToInt32(Math.Round(outputProperty.Exposure
                                                                          * outputProperty.ExposureRate
                                                                          * outputProperty.LiabilityLimitRate
                                                                          * outputProperty.AggregateLimitFactor
                                                                          * outputProperty.RetentionFactor
                                                                          * outputProperty.PopulationFactor
                                                                          * outputProperty.LocationFactor
                                                                          * outputProperty.YearsinCMFactor
                                                                          * outputProperty.RetroDateFactor
                                                                          * outputProperty.LossExperienceFactor
                                                                          * ProRata
                                                                          , 0
                                                                          , MidpointRounding.AwayFromZero));
                }

                this.logger.Info("GeneralLiabilityService.CalculateBasePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateBasePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Calculate DamageToPremises Premium
        /// </summary>
        /// <param name="model"></param>
        public void CalculateDamageToPremisesPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateDamageToPremisesPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                // Step 19.1 - Get Premium from input Json
                outputProperty.DamageToPremisesUnmodifiedwithoutExcessPremium = inputProperty.DamageToPremisesUnmodifiedPremium
                                                                              * ProRata;

                outputProperty.DamageToPremisesUnmodifiedPremium = outputProperty.DamageToPremisesUnmodifiedwithoutExcessPremium;

                //Get DamageToPremisesIncludedInExcessExposure from input Json
                outputProperty.DamageToPremisesIncludedInExcessExposure = inputProperty.DamageToPremisesIncludedInExcessExposure;

                // Step 19.2 - Get DamageToPremisesIncludedInExcessExposure form lookup table
                if (String.IsNullOrEmpty(inputProperty.DamageToPremisesIncludedInExcessExposure))
                {
                    outputProperty.DamageToPremisesIncludedInExcessExposure = generalLiabilityDataAccess.GetCoverageLimitInExcessExposure(policyHeader.State,
                                                                                                                                          policyHeader.PrimaryClass,
                                                                                                                                          inputProperty.LineOfBusiness,
                                                                                                                                          "Damage to Premises",
                                                                                                                                          "Excluded",
                                                                                                                                          policyHeader.PolicyEffectiveDate,
                                                                                                                                          policyHeader.PolicyExpirationDate);
                }

                if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                {
                    //Step 19.3 - Get system calculated DamageToPremisesUnmodifiedPremium
                    if (!string.IsNullOrEmpty(outputProperty.DamageToPremisesIncludedInExcessExposure) && outputProperty.DamageToPremisesIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        outputProperty.DamageToPremisesUnmodifiedPremium = 0;
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateDamageToPremisesPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateDamageToPremisesPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate MedicalPayments Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateMedicalPaymentsPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateMedicalPaymentsPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                if (inputProperty.MedicalPaymentLimit.ToUpper() != "EXCLUDED")
                {
                    //Step 20.1 - Get MedicalPaymentsUnmodifiedWithoutExcessPremium from input Json
                    outputProperty.MedicalPaymentsUnmodifiedWithoutExcessPremium = inputProperty.MedicalPaymentUnmodifiedPremium * ProRata;

                    //Get MedicalPaymentsUnmodifiedPremium from input Json
                    outputProperty.MedicalPaymentsUnmodifiedPremium = outputProperty.MedicalPaymentsUnmodifiedWithoutExcessPremium;

                    //Get MedicalPaymentsIncludedInExcessExposure from input Json
                    outputProperty.MedicalPaymentsIncludedInExcessExposure = inputProperty.MedicalPaymentIncludedInExcessExposure;

                    //Step 20.2 - Get MedicalPaymentsIncludedInExcessExposure form lookup table
                    if (String.IsNullOrEmpty(outputProperty.MedicalPaymentsIncludedInExcessExposure))
                    {
                        outputProperty.MedicalPaymentsIncludedInExcessExposure = generalLiabilityDataAccess.GetCoverageLimitInExcessExposure(policyHeader.State,
                                                                                                                                             policyHeader.PrimaryClass,
                                                                                                                                             inputProperty.LineOfBusiness,
                                                                                                                                             "Medical Payments",
                                                                                                                                             inputProperty.MedicalPaymentLimit,
                                                                                                                                             policyHeader.PolicyEffectiveDate,
                                                                                                                                             policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 20.3 - Get system calculated MedicalPaymentsUnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputProperty.MedicalPaymentsIncludedInExcessExposure) && outputProperty.MedicalPaymentsIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputProperty.MedicalPaymentsUnmodifiedPremium = 0;
                        }
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateMedicalPaymentsPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateMedicalPaymentsPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Employee Benefits Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateEmployeeBenefitsPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateEmployeeBenefitsPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                //Step 21.2 - Get input from form lookup table
                outputProperty.EBUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(generalLiabilityDataAccess.GetGLEmployeeBenefitsLiabilityPremium(policyHeader.State,
                                                                                                                                                              policyHeader.PrimaryClass,
                                                                                                                                                              inputProperty.LineOfBusiness,
                                                                                                                                                              inputProperty.EBLimit,
                                                                                                                                                              policyHeader.PolicyEffectiveDate,
                                                                                                                                                              policyHeader.PolicyExpirationDate),
                                                                                                                                                              0,
                                                                                                                                                              MidpointRounding.AwayFromZero));
                outputProperty.EBUnmodifiedWithoutExcessPremium = outputProperty.EBUnmodifiedWithoutExcessPremium * ProRata;

                //Get EBUnmodifiedPremium from Json
                outputProperty.EBUnmodifiedPremium = outputProperty.EBUnmodifiedWithoutExcessPremium;

                ////Get EBIncludedInExcessExposure from Json
                outputProperty.EBIncludedInExcessExposure = inputProperty.EBIncludedInExcessExposure;

                //Step 21.3 - Get EBIncludedInExcessExposure form lookup table
                if (String.IsNullOrEmpty(outputProperty.EBIncludedInExcessExposure))
                {
                    outputProperty.EBIncludedInExcessExposure = generalLiabilityDataAccess.GetEBIncludedInExcessExposure(policyHeader.State,
                                                                                                                         policyHeader.PrimaryClass,
                                                                                                                         inputProperty.LineOfBusiness,
                                                                                                                         inputProperty.EBLimit,
                                                                                                                         policyHeader.PolicyEffectiveDate,
                                                                                                                         policyHeader.PolicyExpirationDate);
                }

                if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                {
                    //Step 21.4 - Get system calculated EBUnmodifiedPremium
                    if (!string.IsNullOrEmpty(outputProperty.EBIncludedInExcessExposure) && outputProperty.EBIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        outputProperty.EBUnmodifiedPremium = 0;
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateEmployeeBenefitsPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateEmployeeBenefitsPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Data Compromise Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateDataCompromisePremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateDataCompromisePremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                if (inputProperty.DataCompromiseReferralIsSelected == false)
                {
                    //Step 22.1 - Get ResponseExpenseLimit from input Json
                    outputProperty.ResponseExpenseLimit = inputProperty.DataCompromiseLimit;
                    outputProperty.DataCompromiseDeductible = inputProperty.DataCompromiseDeductible;
                    outputProperty.ResponseExpenseDeductible = inputProperty.DataCompromiseDeductible;

                    //Step 22.3 - Get ResponseExpenseBasePremium from lookup table
                    outputProperty.ResponseExpenseBasePremium = Convert.ToInt32(generalLiabilityDataAccess.GetDataCompLimitsPremium(policyHeader.State,
                                                                                                                                    policyHeader.PrimaryClass,
                                                                                                                                    inputProperty.LineOfBusiness,
                                                                                                                                    "Response Expense",
                                                                                                                                    outputProperty.ResponseExpenseLimit,
                                                                                                                                    policyHeader.PolicyEffectiveDate,
                                                                                                                                    policyHeader.PolicyExpirationDate));


                    //Step 22.4 - Get system calculated Limit
                    outputProperty.DataCompromiseLiabilityLimit = inputProperty.DataCompromiseLimit;

                    //Step 22.5 - Get DataCompromiseLiabilityBasepremium from lookup table
                    outputProperty.DataCompromiseLiabilityBasepremium = Convert.ToInt32(generalLiabilityDataAccess.GetDataCompLimitsPremium(policyHeader.State,
                                                                                                                                            policyHeader.PrimaryClass,
                                                                                                                                            inputProperty.LineOfBusiness,
                                                                                                                                            "Data Compromise Liability",
                                                                                                                                            outputProperty.DataCompromiseLiabilityLimit,
                                                                                                                                            policyHeader.PolicyEffectiveDate,
                                                                                                                                            policyHeader.PolicyExpirationDate));


                    //Step 22.6 - Get PopulationFactor from Json
                    //Not Required Step 22.6

                    //Step 22.7 - Get DataCompromisePopulationRate from lookup table
                    DataTable dtDataCompromisePopulationRate = generalLiabilityDataAccess.GetDataCompPopulationFactor(policyHeader.State,
                                                                                                                      policyHeader.PrimaryClass,
                                                                                                                      inputProperty.LineOfBusiness,
                                                                                                                      "Data Compromise",
                                                                                                                      policyHeader.PopulationADA,
                                                                                                                      policyHeader.PolicyEffectiveDate,
                                                                                                                      policyHeader.PolicyExpirationDate);

                    if (dtDataCompromisePopulationRate != null && dtDataCompromisePopulationRate.Rows.Count > 0)
                    {
                        outputProperty.DataCompromisePopulationRate = Convert.ToDecimal(dtDataCompromisePopulationRate.Rows[0]["Factor"]);
                    }

                    //Step 22.8- Get NYDataCompromiseYearsinClaimMadeRate from lookup table

                    outputProperty.NYDataCompromiseYearsinClaimMadeRate = 1.00M;
                    if (policyHeader.State == StateCodeConstant.NY)
                    {
                        outputProperty.NYDataCompromiseYearsinClaimMadeRate = generalLiabilityDataAccess.GetDataCompCyberNYCMYears(policyHeader.State,
                                                                                                                                   inputProperty.LineOfBusiness,
                                                                                                                                   "Data Compromise",
                                                                                                                                   inputProperty.NYCyberYearsinClaimsMade,
                                                                                                                                   policyHeader.PolicyEffectiveDate,
                                                                                                                                   policyHeader.PolicyExpirationDate);
                    }

                    //Step 22.9 - Get system calculated ResponseExpensePremium
                    outputProperty.ResponseExpensePremium = Convert.ToInt32(Math.Round(outputProperty.ResponseExpenseBasePremium
                                                                                     * outputProperty.DataCompromisePopulationRate));

                    //Step 22.10 - Get system calculated DataCompromiseLiabilityPremium
                    outputProperty.DataCompromiseLiabilityPremium = Convert.ToInt32(Math.Round(outputProperty.DataCompromiseLiabilityBasepremium
                                                                                             * outputProperty.DataCompromisePopulationRate
                                                                                             * outputProperty.NYDataCompromiseYearsinClaimMadeRate));

                    //Step 22.11- Get system calculated TotalDataCompromiseUnmodifiedwithoutexcessPremium
                    outputProperty.TotalDataCompromiseUnmodifiedwithoutexcessPremium = (outputProperty.ResponseExpensePremium
                                                                                      + outputProperty.DataCompromiseLiabilityPremium)
                                                                                      * ProRata;

                    //Get TotalDataCompromiseUnmodifiedPremium from Json
                    outputProperty.TotalDataCompromiseUnmodifiedPremium = outputProperty.TotalDataCompromiseUnmodifiedwithoutexcessPremium;

                    //Get DataCompromiseIncludedInExcessExposure from Json
                    outputProperty.DataCompromiseIncludedInExcessExposure = inputProperty.DataCompromiseIncludedInExcessExposure;

                    if (String.IsNullOrEmpty(outputProperty.DataCompromiseIncludedInExcessExposure))
                    {
                        //Step 22.12- Get system calculated DataCompromiseIncludedInExcessExposure
                        outputProperty.DataCompromiseIncludedInExcessExposure = generalLiabilityDataAccess.GetDataCompLimitInExcessExposure(policyHeader.State,
                                                                                                                                            policyHeader.PrimaryClass,
                                                                                                                                            inputProperty.LineOfBusiness,
                                                                                                                                            "Data Compromise",
                                                                                                                                            policyHeader.PolicyEffectiveDate,
                                                                                                                                            policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 22.13 - Get system calculated TotalDataCompromiseUnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputProperty.DataCompromiseIncludedInExcessExposure) && outputProperty.DataCompromiseIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputProperty.TotalDataCompromiseUnmodifiedPremium = 0;
                        }
                    }
                }
                else
                {
                    // User rated Data Compromise Premium Calculation

                    //Step 22.15 - Get ResponseExpenseLimit from Json
                    outputProperty.ResponseExpenseLimit = inputProperty.DataCompromiseLimit;
                    outputProperty.DataCompromiseDeductible = inputProperty.DataCompromiseDeductible;
                    outputProperty.ResponseExpenseDeductible = inputProperty.DataCompromiseDeductible;

                    //Step 22.16 - Get DataCompromiseLiabilityLimit from Json
                    outputProperty.DataCompromiseLiabilityLimit = inputProperty.DataCompromiseLimit;

                    //Step 22.17 - Get NYDataCompromiseYearsinClaimsMade form json
                    //Not required Step 22.17

                    //Step 22.18 - Get ResponseExpensePremium from input json
                    outputProperty.ResponseExpensePremium = inputProperty.ResponseExpensePremium;

                    //Step 22.19 - Get DataCompromiseLiabilityPremium from input json
                    outputProperty.DataCompromiseLiabilityPremium = inputProperty.DataCompromiseLiabilityPremium;

                    //Step 22.20 - Get TotalDataCompromiseUnmodifiedwithoutexcessPremium system calculated premium
                    outputProperty.TotalDataCompromiseUnmodifiedwithoutexcessPremium = (outputProperty.ResponseExpensePremium
                                                                                      + outputProperty.DataCompromiseLiabilityPremium)
                                                                                      * ProRata;

                    //Get TotalDataCompromiseUnmodifiedPremium from input json
                    outputProperty.TotalDataCompromiseUnmodifiedPremium = outputProperty.TotalDataCompromiseUnmodifiedwithoutexcessPremium;

                    ////Get DataCompromiseIncludedInExcessExposure from input json
                    outputProperty.DataCompromiseIncludedInExcessExposure = inputProperty.DataCompromiseIncludedInExcessExposure;

                    //Step 22.21- Get DataCompromiseIncludedInExcessExposure form lookup table
                    if (String.IsNullOrEmpty(outputProperty.DataCompromiseIncludedInExcessExposure))
                    {
                        outputProperty.DataCompromiseIncludedInExcessExposure = generalLiabilityDataAccess.GetDataCompLimitInExcessExposure(policyHeader.State,
                                                                                                                                            policyHeader.PrimaryClass,
                                                                                                                                            inputProperty.LineOfBusiness,
                                                                                                                                            "Data Compromise",
                                                                                                                                            policyHeader.PolicyEffectiveDate,
                                                                                                                                            policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 22.22 - Get system calculated TotalDataCompromiseUnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputProperty.DataCompromiseIncludedInExcessExposure) && outputProperty.DataCompromiseIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputProperty.TotalDataCompromiseUnmodifiedPremium = 0;
                        }
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateDataCompromisePremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateDataCompromisePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Cyber Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateCyberPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateCyberPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                //System Rated Cyber Premium Calculation	
                if (inputProperty.CyberReferralIsSelected == false)
                {
                    //Step 23.2 - Get ComputerAttackRate from table
                    DataTable dtComputerAttackRate = generalLiabilityDataAccess.GetCyberLimitsPremium(policyHeader.State,
                                                                                                      policyHeader.PrimaryClass,
                                                                                                      inputProperty.LineOfBusiness,
                                                                                                      "Computer Attack",
                                                                                                      inputProperty.ComputerAttackLimit,
                                                                                                      policyHeader.PolicyEffectiveDate,
                                                                                                      policyHeader.PolicyExpirationDate);
                    if (dtComputerAttackRate != null && dtComputerAttackRate.Rows.Count > 0)
                    {
                        outputProperty.ComputerAttackRate = Convert.ToDecimal(dtComputerAttackRate.Rows[0]["Premium"]);
                    }

                    //Step 23.4 - Get NetworkSecurityAndElectronicMediaLiabilityRate from lookup table
                    DataTable dtNetworkSecurityAndElectronicMediaLiabilityRate = generalLiabilityDataAccess.GetCyberLimitsPremium(policyHeader.State,
                                                                                                                                  policyHeader.PrimaryClass,
                                                                                                                                  inputProperty.LineOfBusiness,
                                                                                                                                  "Network Security Liability and Electronic Media Liability",
                                                                                                                                  inputProperty.NetworkSecurityAndElectronicMediaLiabilityLimit,
                                                                                                                                  policyHeader.PolicyEffectiveDate,
                                                                                                                                  policyHeader.PolicyExpirationDate);

                    if (dtNetworkSecurityAndElectronicMediaLiabilityRate != null && dtNetworkSecurityAndElectronicMediaLiabilityRate.Rows.Count > 0)
                    {
                        outputProperty.NetworkSecurityAndElectronicMediaLiabilityRate = Convert.ToDecimal(dtNetworkSecurityAndElectronicMediaLiabilityRate.Rows[0]["Premium"]);
                    }

                    //Step 23.6 - Get Cyberpopulationrate from lookup table
                    DataTable dtCyberpopulationrate = generalLiabilityDataAccess.GetCyberPopulation(policyHeader.State,
                                                                                                    policyHeader.PrimaryClass,
                                                                                                    inputProperty.LineOfBusiness,
                                                                                                    "Cyber",
                                                                                                    policyHeader.PopulationADA,
                                                                                                    policyHeader.PolicyEffectiveDate,
                                                                                                    policyHeader.PolicyExpirationDate);

                    if (dtCyberpopulationrate != null && dtCyberpopulationrate.Rows.Count > 0)
                    {
                        outputProperty.Cyberpopulationrate = Convert.ToDecimal(dtCyberpopulationrate.Rows[0]["Premium"]);
                    }

                    //Step 23.7 - Get NYCyberYearsinClaimsMadeRate from lookup table
                    outputProperty.NYCyberYearsinClaimsMadeRate = 1.00M;
                    if (policyHeader.State == StateCodeConstant.NY)
                    {
                        outputProperty.NYCyberYearsinClaimsMadeRate = generalLiabilityDataAccess.GetDataCompCyberNYCMYears(policyHeader.State,
                                                                                                                           inputProperty.LineOfBusiness,
                                                                                                                           "Cyber",
                                                                                                                           outputProperty.NYCyberYearsinClaimsMadeRate,
                                                                                                                           policyHeader.PolicyEffectiveDate,
                                                                                                                           policyHeader.PolicyExpirationDate);
                    }

                    //Step 23.8 - Get ComputerAttackPremium system calculated premium
                    outputProperty.ComputerAttackPremium = Convert.ToInt32(Math.Round(outputProperty.ComputerAttackRate
                                                                                    * outputProperty.Cyberpopulationrate
                                                                                    , 0
                                                                                    , MidpointRounding.AwayFromZero));

                    //Step 23.9 - Get NetworkSecurityPremium system calculated premium
                    outputProperty.NetworkSecurityPremium = Convert.ToInt32(Math.Round(outputProperty.NetworkSecurityAndElectronicMediaLiabilityRate
                                                                                     * outputProperty.Cyberpopulationrate
                                                                                     * outputProperty.NYCyberYearsinClaimsMadeRate));

                    //Step 23.10 - Get system calculated TotalCyberUnmodifiedwithoutexcessPremium
                    outputProperty.TotalCyberUnmodifiedwithoutexcessPremium = (outputProperty.ComputerAttackPremium
                                                                             + outputProperty.NetworkSecurityPremium)
                                                                             * ProRata;

                    ////Get TotalCyberUnmodifiedPremium form Json
                    outputProperty.TotalCyberUnmodifiedPremium = outputProperty.TotalCyberUnmodifiedwithoutexcessPremium;

                    //Get CyberIncludedInExcessExposure form Json
                    outputProperty.CyberIncludedInExcessExposure = inputProperty.CyberIncludedInExcessExposure;

                    //Step 23.11- Get CyberIncludedInExcessExposure form lookup table
                    if (String.IsNullOrEmpty(outputProperty.CyberIncludedInExcessExposure))
                    {
                        outputProperty.CyberIncludedInExcessExposure = generalLiabilityDataAccess.GetCyberLimitInExcessExposure(policyHeader.State,
                                                                                                                                policyHeader.PrimaryClass,
                                                                                                                                inputProperty.LineOfBusiness,
                                                                                                                                "Cyber",
                                                                                                                                policyHeader.PolicyEffectiveDate,
                                                                                                                                policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 23.12 - Get system calculated TotalCyberUnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputProperty.CyberIncludedInExcessExposure) && outputProperty.CyberIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputProperty.TotalCyberUnmodifiedPremium = 0;
                        }
                    }
                }
                else
                {
                    //User Rated Cyber Premium Calculation 
                    //Step 23.13 - Get ComputerAttackPremium input from Json
                    outputProperty.ComputerAttackPremium = inputProperty.ComputerAttackPremium;

                    //Step 23.14 - Get NetworkSecurityPremium input from Json
                    outputProperty.NetworkSecurityPremium = inputProperty.NetworkSecurityPremium;

                    //Step 23.15 - ((Step 23.12 + Step 23.13) * Step 14) Get TotalCyberUnmodifiedwithoutexcessPremium system calculated premium
                    outputProperty.TotalCyberUnmodifiedwithoutexcessPremium = (outputProperty.ComputerAttackPremium
                                                                             + outputProperty.NetworkSecurityPremium)
                                                                             * ProRata;

                    //Get TotalCyberUnmodifiedPremium  from input Json
                    outputProperty.TotalCyberUnmodifiedPremium = outputProperty.TotalCyberUnmodifiedwithoutexcessPremium;

                    //Get CyberIncludedInExcessExposure  from input Json
                    outputProperty.CyberIncludedInExcessExposure = inputProperty.CyberIncludedInExcessExposure;

                    //Step 23.16- Get CyberIncludedInExcessExposure form lookup table
                    if (String.IsNullOrEmpty(outputProperty.CyberIncludedInExcessExposure))
                    {
                        outputProperty.CyberIncludedInExcessExposure = generalLiabilityDataAccess.GetCyberLimitInExcessExposure(policyHeader.State,
                                                                                                                                policyHeader.PrimaryClass,
                                                                                                                                inputProperty.LineOfBusiness,
                                                                                                                                "Cyber",
                                                                                                                                policyHeader.PolicyEffectiveDate,
                                                                                                                                policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 23.17 - Get system calculated TotalCyberUnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputProperty.CyberIncludedInExcessExposure) && outputProperty.CyberIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputProperty.TotalCyberUnmodifiedPremium = 0;
                        }
                    }

                }

                this.logger.Info("GeneralLiabilityService.CalculateCyberPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateCyberPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Unmanned Aircraft Total Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateUnmannedAircraftTotalPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateUnmannedAircraftTotalPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;
                var unmannedAircraftState = new string[] { "AL", "CO", "GA", "KS", "DE", "ME", "MA", "MI", "MN", "IL", "IN", "OH", "NC", "NH", "NY", "PA", "SC", "TX", "UT", "VT", "WY" };
                int MinimumPremium = 0;

                //Step 24 Unmanned Aircraft Total Premium
                if (inputProperty.UnmannedAircraftOption.ToUpper() != "EXCLUDE - CG 21 09")
                {
                    //Step 24.1 - Get UnmannedAircraftAggregateLimitRate from lookup table 
                    outputProperty.UnmannedAircraftAggregateLimitRate = generalLiabilityDataAccess.GetUnmannedAircraftFactor(policyHeader.State,
                                                                                                                             inputProperty.LineOfBusiness,
                                                                                                                             "Unmanned Aircraft",
                                                                                                                             inputProperty.UnmannedAircraftAggregateLimit,
                                                                                                                             policyHeader.PolicyEffectiveDate,
                                                                                                                             policyHeader.PolicyExpirationDate);

                    //Step 24.3 - Get input form Json

                    if (policyHeader.State == StateCodeConstant.CT || policyHeader.State == StateCodeConstant.MS || policyHeader.State == StateCodeConstant.MO)
                    {
                        DataTable dtUnmannedAircrafts = generalLiabilityDataAccess.GetUnmannedAircrafts(policyHeader.State,
                                                                                                        inputProperty.LineOfBusiness,
                                                                                                        "Unmanned Aircraft",
                                                                                                        inputProperty.UnmannedAircraftOption,
                                                                                                        policyHeader.PolicyEffectiveDate,
                                                                                                        policyHeader.PolicyExpirationDate);

                        if (dtUnmannedAircrafts != null && dtUnmannedAircrafts.Rows.Count > 0)
                        {
                            outputProperty.UnmannedAircraftcoverage15lbsorLessRate = Convert.ToDecimal(dtUnmannedAircrafts.Rows[0]["Rate"]);
                        }


                        //Step 24.5 - Get  from lookup table 
                        DataTable dtUnmannedAircrafts15ToLessThan55lbs = generalLiabilityDataAccess.GetUnmannedAircrafts15ToLessThan55lbs(policyHeader.State,
                                                                                                                                          inputProperty.LineOfBusiness,
                                                                                                                                          "Unmanned Aircraft",
                                                                                                                                          inputProperty.UnmannedAircraftOption,
                                                                                                                                          policyHeader.PolicyEffectiveDate,
                                                                                                                                          policyHeader.PolicyExpirationDate);
                        if (dtUnmannedAircrafts15ToLessThan55lbs != null && dtUnmannedAircrafts15ToLessThan55lbs.Rows.Count > 0)
                        {
                            outputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate = Convert.ToDecimal(dtUnmannedAircrafts15ToLessThan55lbs.Rows[0]["Rate"]);
                        }

                        //Step 24.8 - Get UnmannedAircraftcoverageGreaterThenEqualto55lbsRate from lookup table 
                        DataTable dtUnmannedAircrafts55lbs = generalLiabilityDataAccess.GetUnmannedAircrafts55lbs(policyHeader.State,
                                                                                                                 inputProperty.LineOfBusiness,
                                                                                                                 "Unmanned Aircraft",
                                                                                                                 inputProperty.UnmannedAircraftOption,
                                                                                                                 policyHeader.PolicyEffectiveDate,
                                                                                                                 policyHeader.PolicyExpirationDate);

                        if (dtUnmannedAircrafts55lbs != null && dtUnmannedAircrafts55lbs.Rows.Count > 0)
                        {
                            outputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate = Convert.ToDecimal(dtUnmannedAircrafts55lbs.Rows[0]["Rate"]);
                        }


                    }
                    else if (unmannedAircraftState.Contains(policyHeader.State))
                    {

                        //Step 24.3 Unmanned Aircraft Coverage 15lbs or Less Total Units present in input Json.
                        if (inputProperty.UnmannedAircraftcoverage15lbsorLessRate < 0)
                        {
                            DataTable dtUnmannedAircrafts = generalLiabilityDataAccess.GetUnmannedAircrafts(policyHeader.State,
                                                                                                       inputProperty.LineOfBusiness,
                                                                                                       "Unmanned Aircraft",
                                                                                                       inputProperty.UnmannedAircraftOption,
                                                                                                       policyHeader.PolicyEffectiveDate,
                                                                                                       policyHeader.PolicyExpirationDate);

                            if (dtUnmannedAircrafts != null && dtUnmannedAircrafts.Rows.Count > 0)
                            {
                                outputProperty.UnmannedAircraftcoverage15lbsorLessRate = Convert.ToDecimal(dtUnmannedAircrafts.Rows[0]["Rate"]);
                            }

                        }
                        else
                        {
                            outputProperty.UnmannedAircraftcoverage15lbsorLessRate = inputProperty.UnmannedAircraftcoverage15lbsorLessRate;
                        }


                        //"Unmanned Aircraft 15.1 to < 55 lbs" Premium Calculation	
                        //Step 24.5 - Get UnmannedAircraftcoverage15Pt1toLessThen55lbsRate from lookup table 
                        if (inputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate < 0)
                        {
                            DataTable dtUnmannedAircrafts15ToLessThan55lbs = generalLiabilityDataAccess.GetUnmannedAircrafts15ToLessThan55lbs(policyHeader.State,
                                                                                                                                         inputProperty.LineOfBusiness,
                                                                                                                                         "Unmanned Aircraft",
                                                                                                                                         inputProperty.UnmannedAircraftOption,
                                                                                                                                         policyHeader.PolicyEffectiveDate,
                                                                                                                                         policyHeader.PolicyExpirationDate);
                            if (dtUnmannedAircrafts15ToLessThan55lbs != null && dtUnmannedAircrafts15ToLessThan55lbs.Rows.Count > 0)
                            {
                                outputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate = Convert.ToDecimal(dtUnmannedAircrafts15ToLessThan55lbs.Rows[0]["Rate"]);
                            }
                        }
                        else
                        {
                            outputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate = inputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate;
                        }

                        //Unmanned Aircraft ≥ 55 lbs" Premium Calculation	
                        //Step 24.8 - Get UnmannedAircraftcoverageGreaterThenEqualto55lbsRate from lookup table 
                        if (inputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate < 0)
                        {
                            DataTable dtUnmannedAircrafts55lbs = generalLiabilityDataAccess.GetUnmannedAircrafts55lbs(policyHeader.State,
                                                                                                                inputProperty.LineOfBusiness,
                                                                                                                "Unmanned Aircraft",
                                                                                                                inputProperty.UnmannedAircraftOption,
                                                                                                                policyHeader.PolicyEffectiveDate,
                                                                                                                policyHeader.PolicyExpirationDate);

                            if (dtUnmannedAircrafts55lbs != null && dtUnmannedAircrafts55lbs.Rows.Count > 0)
                            {
                                outputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate = Convert.ToDecimal(dtUnmannedAircrafts55lbs.Rows[0]["Rate"]);
                            }
                        }
                        else
                        {
                            outputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate = inputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate;
                        }

                    }


                    //Step 24.4 - (Step 24.1* Step 24.2 * Step 24.3) Get UnmannedAircraftcoverage15lbsorLessPremium system calcaulated Premium
                    outputProperty.UnmannedAircraftcoverage15lbsorLessPremium = Math.Round(outputProperty.UnmannedAircraftAggregateLimitRate
                                                                              * outputProperty.UnmannedAircraftcoverage15lbsorLessRate
                                                                              * inputProperty.UnmannedAircraftcoverage15lbsorLessTotalUnits
                                                                              , 0
                                                                              , MidpointRounding.AwayFromZero);
                    //Unmanned Aircraft Coverage 15lbs or Less Total Units not present in Json.



                    //Step 24.6 - Unmanned Aircraft Coverage 15.1 to <55 lbs Total Units present in input Json.
                    //Step 24.7 - (Step 24.1* Step 24.5 * Step 24.6) Get UnmannedAircraftcoverage15Pt1toLessThen55lbsPremium
                    outputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsPremium = Math.Round(outputProperty.UnmannedAircraftAggregateLimitRate
                                                                                       * outputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate
                                                                                       * inputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsTotalUnits, 0, MidpointRounding.AwayFromZero);




                    //Step 24.9 - Unmanned Aircraft Coverage ≥55 lbs Total Units present in input Json.
                    //Step 24.10 - (Step 24.1* Step 24.8 * Step 24.9) Get UnmannedAircraftcoverageGreaterThenEqualto55lbsPremium
                    outputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsPremium = Convert.ToInt32(Math.Round(outputProperty.UnmannedAircraftAggregateLimitRate
                                                                                          * outputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate
                                                                                          * inputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsTotalUnits
                                                                                          , 0
                                                                                          , MidpointRounding.AwayFromZero));


                    //Step 24.11 - (Step 24.3+ Step 24.6 + Step 24.9) Get UnmannedAircraftTotalUnits
                    outputProperty.UnmannedAircraftTotalUnits = inputProperty.UnmannedAircraftcoverage15lbsorLessTotalUnits
                                                              + inputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsTotalUnits
                                                              + inputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsTotalUnits;

                    //Step 24.12 - ((Step 24.4 + Step 24.7 + 24.10) * Step 14) Get system calcaulated Premium
                    outputProperty.UnmannedAircraftTotalUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((outputProperty.UnmannedAircraftcoverage15lbsorLessPremium
                                                                                       + outputProperty.UnmannedAircraftcoverage15Pt1toLessThen55lbsPremium
                                                                                       + outputProperty.UnmannedAircraftcoverageGreaterThenEqualto55lbsPremium) * ProRata, 0, MidpointRounding.AwayFromZero));

                    //Calulate MinimumPremium
                    MinimumPremium = Convert.ToInt32(generalLiabilityDataAccess.GetUnmannedAircraftsMinPremium(policyHeader.State,
                                                                                                               inputProperty.LineOfBusiness,
                                                                                                               "Unmanned Aircraft",
                                                                                                               inputProperty.UnmannedAircraftAggregateLimit,
                                                                                                               policyHeader.PolicyEffectiveDate,
                                                                                                               policyHeader.PolicyExpirationDate));

                    // todo Pending due to some wrong info

                    //Get UnmannedAircraftUnModifiedTotalPremium  from input Json
                    outputProperty.UnmannedAircraftUnModifiedTotalPremium = outputProperty.UnmannedAircraftTotalUnmodifiedWithoutExcessPremium;

                    //Get UnmannedAircraftcoverageIncludedinExcessExposure  from input Json
                    outputProperty.UnmannedAircraftcoverageIncludedinExcessExposure = inputProperty.UnmannedAircraftcoverageIncludedinExcessExposure;

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 24.14 -  Get system calcaulated Premium
                        if (!string.IsNullOrEmpty(outputProperty.UnmannedAircraftcoverageIncludedinExcessExposure) && outputProperty.UnmannedAircraftcoverageIncludedinExcessExposure.ToUpper() == "TRUE")
                        {
                            outputProperty.UnmannedAircraftUnModifiedTotalPremium = 0;
                        }
                    }

                    //Step 24.15 -  Get system calcaulated Premium
                    outputProperty.UnmannedAircraftModifiedTotalPremium = Convert.ToInt32(Math.Round(outputProperty.UnmannedAircraftUnModifiedTotalPremium
                                                                                                   * outputProperty.TierFactor
                                                                                                   * outputProperty.IRPMFactor
                                                                                                   * outputProperty.OtherModFactor));

                    if (outputProperty.UnmannedAircraftModifiedTotalPremium < MinimumPremium)
                    {
                        outputProperty.UnmannedAircraftModifiedTotalPremium = MinimumPremium;
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateUnmannedAircraftTotalPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateUnmannedAircraftTotalPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate CalculateOptionalCoveragePremium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateOptionalCoveragePremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
                var inputOptionalProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                string[] stateCheck = new string[18] { "AL", "CO", "GA", "IL", "IN", "KS", "MI", "MN", "MO", "MS", "NC", "NY", "OH", "PA", "SC", "TX", "UT", "WY" };
                string[] stateCheck3 = new string[20] { "AL", "CO", "GA", "IL", "IN", "KS", "MA", "ME", "MI", "MN", "MO", "MS", "NC", "NY", "OH", "PA", "SC", "TX", "UT", "WY" };

                //Step 25 - Cemetery Professional Liability -GL - 203
                if (stateCheck.Contains(policyHeader.State))
                {
                    if (inputOptionalProperty.CemeteryProfessionalLiabilityGL203IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203Limit = inputOptionalProperty.CemeteryProfessionalLiabilityGL203Limit;
                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203AggregateLimit = inputOptionalProperty.CemeteryProfessionalLiabilityGL203AggregateLimit;
                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203Deductible = inputOptionalProperty.CemeteryProfessionalLiabilityGL203Deductible;
                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203RatingBasis = inputOptionalProperty.CemeteryProfessionalLiabilityGL203RatingBasis;
                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203ReturnMethod = inputOptionalProperty.CemeteryProfessionalLiabilityGL203ReturnMethod;
                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203Rate = inputOptionalProperty.CemeteryProfessionalLiabilityGL203Rate;
                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203IsSelected = inputOptionalProperty.CemeteryProfessionalLiabilityGL203IsSelected;


                        //Step 25.1 - Get CemeteryProfessionalLiabilityGL203UnmodifiedWithoutExcessPremium from input Json
                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203UnmodifiedWithoutExcessPremium = inputOptionalProperty.CemeteryProfessionalLiabilityGL203UnmodifiedPremium
                                                                                                                * ProRata;

                        //calculated CemeteryProfessionalLiabilityGL203UnmodifiedPremium
                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203UnmodifiedPremium = outputOptionalProperty.CemeteryProfessionalLiabilityGL203UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.CemeteryProfessionalLiabilityGL203IncludedinExcessExposure = inputOptionalProperty.CemeteryProfessionalLiabilityGL203IncludedinExcessExposure;


                        if (String.IsNullOrEmpty(outputOptionalProperty.CemeteryProfessionalLiabilityGL203IncludedinExcessExposure))
                        {
                            // Step 25.2 - Get value form lookup table
                            outputOptionalProperty.CemeteryProfessionalLiabilityGL203IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                             policyHeader.PrimaryClass,
                                                                                                                                                                             inputProperty.LineOfBusiness,
                                                                                                                                                                             "Cemetery Professional Liability - GL-203",
                                                                                                                                                                             policyHeader.PolicyEffectiveDate,
                                                                                                                                                                             policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 25.3 - Get system calculated CemeteryProfessionalLiabilityGL203UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.CemeteryProfessionalLiabilityGL203IncludedinExcessExposure) && outputOptionalProperty.CemeteryProfessionalLiabilityGL203IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.CemeteryProfessionalLiabilityGL203UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                //Step 26 - Cyber - Suppl. Extended Reporting Period
                if (policyHeader.TransactionType == TransactionTypeConstant.ENDORSEMENT)
                {
                    if (inputOptionalProperty.CyberSupplExtendedReportingPeriodIsSelected)
                    {
                        //Step 26.1 - Get input from json
                        outputOptionalProperty.CyberSupplExtendedReportingPeriodLimit = inputOptionalProperty.CyberSupplExtendedReportingPeriodLimit;

                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.CyberSupplExtendedReportingPeriodAggregateLimit = inputOptionalProperty.CyberSupplExtendedReportingPeriodAggregateLimit;
                        outputOptionalProperty.CyberSupplExtendedReportingPeriodDeductible = inputOptionalProperty.CyberSupplExtendedReportingPeriodDeductible;
                        outputOptionalProperty.CyberSupplExtendedReportingPeriodRatingBasis = inputOptionalProperty.CyberSupplExtendedReportingPeriodRatingBasis;
                        outputOptionalProperty.CyberSupplExtendedReportingPeriodReturnMethod = inputOptionalProperty.CyberSupplExtendedReportingPeriodReturnMethod;
                        outputOptionalProperty.CyberSupplExtendedReportingPeriodIsSelected = inputOptionalProperty.CyberSupplExtendedReportingPeriodIsSelected;

                        //Step 26.2 - Get CyberSupplExtendedReportingPeriodRate from lookup table
                        outputOptionalProperty.CyberSupplExtendedReportingPeriodRate = generalLiabilityDataAccess.GetOptionalCoverageRate(policyHeader.State,
                                                                                                                                          policyHeader.PrimaryClass,
                                                                                                                                          inputProperty.LineOfBusiness,
                                                                                                                                          "Cyber - Suppl. Extended Reporting Period",
                                                                                                                                          inputOptionalProperty.CyberSupplExtendedReportingPeriodLimit,
                                                                                                                                          policyHeader.PolicyEffectiveDate,
                                                                                                                                          policyHeader.PolicyExpirationDate);

                        decimal annualizedNetworkSecurityPremiumFromTheLastBoundTransaction = 0;
                        //Step 26.3 - Get system calculated CyberSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium
                        outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(outputOptionalProperty.CyberSupplExtendedReportingPeriodRate
                                                                                                                                          * annualizedNetworkSecurityPremiumFromTheLastBoundTransaction
                                                                                                                                          , 0
                                                                                                                                          , MidpointRounding.AwayFromZero));

                        //calculated CyberSupplExtendedReportingPeriodUnmodifiedPremium
                        outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium = outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.CyberSupplExtendedReportingPeriodIncludedinExcessExposure = inputOptionalProperty.CyberSupplExtendedReportingPeriodIncludedinExcessExposure;

                        if (String.IsNullOrEmpty(outputOptionalProperty.CyberSupplExtendedReportingPeriodIncludedinExcessExposure))
                        {
                            //Step 26.4- Get CyberSupplExtendedReportingPeriodIncludedinExcessExposure form lookup table
                            outputOptionalProperty.CyberSupplExtendedReportingPeriodIncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                            policyHeader.PrimaryClass,
                                                                                                                                                                            inputProperty.LineOfBusiness,
                                                                                                                                                                            "Cyber - Suppl. Extended Reporting Period",
                                                                                                                                                                            policyHeader.PolicyEffectiveDate,
                                                                                                                                                                            policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 26.5 - Get system calculated CyberSupplExtendedReportingPeriodUnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.CyberSupplExtendedReportingPeriodIncludedinExcessExposure) && outputOptionalProperty.CyberSupplExtendedReportingPeriodIncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                if (inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIsSelected)
                {

                    //Step 27.1 - Get DataCompromiseSupplExtendedReportingPeriodLimit from json
                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodLimit = inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodLimit;

                    //Output Json Variable are Assigned by input Json
                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodAggregateLimit = inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodAggregateLimit;
                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodDeductible = inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodDeductible;
                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodRatingBasis = inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodRatingBasis;
                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodReturnMethod = inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodReturnMethod;
                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIsSelected = inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIsSelected;

                    var dataCompromiseSupplExtendedReportingPeriodLimit = inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodLimit;
                    // Step 27.2 - Get DataCompromiseSupplExtendedReportingPeriodRate from lookup table
                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodRate = generalLiabilityDataAccess.GetOptionalCoverageRate(policyHeader.State,
                                                                                                                                               policyHeader.PrimaryClass,
                                                                                                                                               inputProperty.LineOfBusiness,
                                                                                                                                               "Data Compromise - Suppl. Extended Reporting Period",
                                                                                                                                               dataCompromiseSupplExtendedReportingPeriodLimit,
                                                                                                                                               policyHeader.PolicyEffectiveDate,
                                                                                                                                               policyHeader.PolicyExpirationDate);

                    decimal annualizedDataCompromiseNetworkSecurityPremiumFromTheLastBoundTransaction = 0;

                    //Step 27.3 - Get system calculated DataCompromiseSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium
                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodRate
                                                                                                                                               * annualizedDataCompromiseNetworkSecurityPremiumFromTheLastBoundTransaction
                                                                                                                                               , 0
                                                                                                                                               , MidpointRounding.AwayFromZero));

                    //calculated DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium
                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium = outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium;

                    outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure = inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure;

                    if (string.IsNullOrEmpty(outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure))
                    {
                        //Step 27.4- Get DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure form lookup table
                        outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                                 policyHeader.PrimaryClass,
                                                                                                                                                                                 inputProperty.LineOfBusiness,
                                                                                                                                                                                 "Data Compromise - Suppl. Extended Reporting Period",
                                                                                                                                                                                 policyHeader.PolicyEffectiveDate,
                                                                                                                                                                                 policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 27.5 - Get system calculated DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure) && outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure.ToUpper() == "TRUE")
                        {
                            outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium = 0;
                        }
                    }
                }


                if (policyHeader.State == StateCodeConstant.OH || policyHeader.State == StateCodeConstant.WY)
                {
                    //Step 28 -  Employers Liability - GL-600
                    if (inputOptionalProperty.EmployersLiabilityGL600IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.EmployersLiabilityGL600Limit = inputOptionalProperty.EmployersLiabilityGL600Limit;
                        outputOptionalProperty.EmployersLiabilityGL600AggregateLimit = inputOptionalProperty.EmployersLiabilityGL600AggregateLimit;
                        outputOptionalProperty.EmployersLiabilityGL600Deductible = inputOptionalProperty.EmployersLiabilityGL600Deductible;
                        outputOptionalProperty.EmployersLiabilityGL600RatingBasis = inputOptionalProperty.EmployersLiabilityGL600RatingBasis;
                        outputOptionalProperty.EmployersLiabilityGL600ReturnMethod = inputOptionalProperty.EmployersLiabilityGL600ReturnMethod;
                        outputOptionalProperty.EmployersLiabilityGL600Rate = inputOptionalProperty.EmployersLiabilityGL600Rate;
                        outputOptionalProperty.EmployersLiabilityGL600IsSelected = inputOptionalProperty.EmployersLiabilityGL600IsSelected;

                        //Step 28.1 - Get EmployersLiabilityGL600UnmodifiedWithoutExcessPremium from input json
                        outputOptionalProperty.EmployersLiabilityGL600UnmodifiedWithoutExcessPremium = inputOptionalProperty.EmployersLiabilityGL600UnmodifiedPremium * ProRata;

                        outputOptionalProperty.EmployersLiabilityGL600UnmodifiedPremium = outputOptionalProperty.EmployersLiabilityGL600UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.EmployersLiabilityGL600IncludedinExcessExposure = inputOptionalProperty.EmployersLiabilityGL600IncludedinExcessExposure;

                        if (string.IsNullOrEmpty(outputOptionalProperty.EmployersLiabilityGL600IncludedinExcessExposure))
                        {
                            //Step 28.2- Get EmployersLiabilityGL600IncludedinExcessExposure form lookup table
                            outputOptionalProperty.EmployersLiabilityGL600IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                  policyHeader.PrimaryClass,
                                                                                                                                                                  inputProperty.LineOfBusiness,
                                                                                                                                                                  "Employers Liability - GL-600",
                                                                                                                                                                  policyHeader.PolicyEffectiveDate,
                                                                                                                                                                  policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 28.3 - Get system calculated EmployersLiabilityGL600UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.EmployersLiabilityGL600IncludedinExcessExposure) && outputOptionalProperty.EmployersLiabilityGL600IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.EmployersLiabilityGL600UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                if (stateCheck.Contains(policyHeader.State))
                {
                    //Step 29 - Failure to Supply Exclusion - GL - 304
                    if (inputOptionalProperty.FailuretoSupplyExclusionGL304IsSelected)
                    {
                        // Step 29.1 - Get FailuretoSupplyExclusionGL304Limit from input json
                        outputOptionalProperty.FailuretoSupplyExclusionGL304Limit = inputOptionalProperty.FailuretoSupplyExclusionGL304Limit;

                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.FailuretoSupplyExclusionGL304AggregateLimit = inputOptionalProperty.FailuretoSupplyExclusionGL304AggregateLimit;
                        outputOptionalProperty.FailuretoSupplyExclusionGL304Deductible = inputOptionalProperty.FailuretoSupplyExclusionGL304Deductible;
                        outputOptionalProperty.FailuretoSupplyExclusionGL304RatingBasis = inputOptionalProperty.FailuretoSupplyExclusionGL304RatingBasis;
                        outputOptionalProperty.FailuretoSupplyExclusionGL304ReturnMethod = inputOptionalProperty.FailuretoSupplyExclusionGL304ReturnMethod;
                        outputOptionalProperty.FailuretoSupplyExclusionGL304IsSelected = inputOptionalProperty.FailuretoSupplyExclusionGL304IsSelected;

                        //Step 29.2 - Get FailuretoSupplyExclusionGL304Rate from lookup table
                        outputOptionalProperty.FailuretoSupplyExclusionGL304Rate = generalLiabilityDataAccess.GetOptionalCoverageRate(policyHeader.State,
                                                                                                                                      policyHeader.PrimaryClass,
                                                                                                                                      inputProperty.LineOfBusiness,
                                                                                                                                      "Failure to Supply Exclusion - GL-304",
                                                                                                                                      inputOptionalProperty.FailuretoSupplyExclusionGL304Limit,
                                                                                                                                      policyHeader.PolicyEffectiveDate,
                                                                                                                                      policyHeader.PolicyExpirationDate);


                        //Step 29.3 - Get system calculated FailuretoSupplyExclusionGL304UnmodifiedWithoutExcessPremium
                        outputOptionalProperty.FailuretoSupplyExclusionGL304UnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(outputOptionalProperty.FailuretoSupplyExclusionGL304Rate
                                                                                                                                      * outputProperty.BasePremium
                                                                                                                                      * ProRata
                                                                                                                                      , 0
                                                                                                                                      , MidpointRounding.AwayFromZero));

                        outputOptionalProperty.FailuretoSupplyExclusionGL304UnmodifiedPremium = outputOptionalProperty.FailuretoSupplyExclusionGL304UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.FailuretoSupplyExclusionGL304IncludedinExcessExposure = inputOptionalProperty.FailuretoSupplyExclusionGL304IncludedinExcessExposure;


                        if (string.IsNullOrEmpty(outputOptionalProperty.FailuretoSupplyExclusionGL304IncludedinExcessExposure))
                        {
                            //Step 29.4- Get FailuretoSupplyExclusionGL304IncludedinExcessExposure form lookup table
                            outputOptionalProperty.FailuretoSupplyExclusionGL304IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                        policyHeader.PrimaryClass,
                                                                                                                                                                        inputProperty.LineOfBusiness,
                                                                                                                                                                        "Failure to Supply Exclusion - GL-304",
                                                                                                                                                                        policyHeader.PolicyEffectiveDate,
                                                                                                                                                                        policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 29.5 - Get system calculated FailuretoSupplyExclusionGL304IncludedinExcessExposure
                            if (!string.IsNullOrEmpty(outputOptionalProperty.FailuretoSupplyExclusionGL304IncludedinExcessExposure) && outputOptionalProperty.FailuretoSupplyExclusionGL304IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.FailuretoSupplyExclusionGL304UnmodifiedPremium = 0;
                            }
                        }
                    }

                    //Step 30 -  Failure to Supply Sublimit - GL-211
                    if (inputOptionalProperty.FailuretoSupplySublimitGL211IsSelected)
                    {
                        //Step 30.1 - Get FailuretoSupplySublimitGL211Limit from input json
                        outputOptionalProperty.FailuretoSupplySublimitGL211Limit = inputOptionalProperty.FailuretoSupplySublimitGL211Limit;

                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.FailuretoSupplySublimitGL211Aggregateimit = inputOptionalProperty.FailuretoSupplySublimitGL211Aggregateimit;
                        outputOptionalProperty.FailuretoSupplySublimitGL211Deductible = inputOptionalProperty.FailuretoSupplySublimitGL211Deductible;
                        outputOptionalProperty.FailuretoSupplySublimitGL211RatingBasis = inputOptionalProperty.FailuretoSupplySublimitGL211RatingBasis;
                        outputOptionalProperty.FailuretoSupplySublimitGL211ReturnMethod = inputOptionalProperty.FailuretoSupplySublimitGL211ReturnMethod;
                        outputOptionalProperty.FailuretoSupplySublimitGL211Rate = inputOptionalProperty.FailuretoSupplySublimitGL211Rate;
                        outputOptionalProperty.FailuretoSupplySublimitGL211IsSelected = inputOptionalProperty.FailuretoSupplySublimitGL211IsSelected;

                        var failuretoSupplySublimitGL211Limit = Convert.ToString(inputOptionalProperty.FailuretoSupplySublimitGL211Limit);

                        //Step 30.2 - Get FailuretoSupplySublimitGL211Rate from lookup table
                        outputOptionalProperty.FailuretoSupplySublimitGL211Rate = generalLiabilityDataAccess.GetOptionalCoverageRate(policyHeader.State,
                                                                                                                                     policyHeader.PrimaryClass,
                                                                                                                                     inputProperty.LineOfBusiness,
                                                                                                                                     "Failure to Supply Sublimit - GL-211",
                                                                                                                                     failuretoSupplySublimitGL211Limit,
                                                                                                                                     policyHeader.PolicyEffectiveDate,
                                                                                                                                     policyHeader.PolicyExpirationDate);


                        //Step 30.3 - Get system calculated FailuretoSupplyExclusionGL304UnmodifiedWithoutExcessPremium
                        outputOptionalProperty.FailuretoSupplySublimitGL211UnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(outputOptionalProperty.FailuretoSupplySublimitGL211Rate
                                                                                                                                     * outputProperty.BasePremium
                                                                                                                                     * ProRata
                                                                                                                                     , 0
                                                                                                                                     , MidpointRounding.AwayFromZero));

                        //Step 30.4- Get FailuretoSupplySublimitGL211IncludedinExcessExposure form lookup table
                        outputOptionalProperty.FailuretoSupplySublimitGL211UnmodifiedPremium = outputOptionalProperty.FailuretoSupplySublimitGL211UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.FailuretoSupplySublimitGL211IncludedinExcessExposure = inputOptionalProperty.FailuretoSupplySublimitGL211IncludedinExcessExposure;

                        if (string.IsNullOrEmpty(outputOptionalProperty.FailuretoSupplySublimitGL211IncludedinExcessExposure))
                        {
                            outputOptionalProperty.FailuretoSupplySublimitGL211IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                       policyHeader.PrimaryClass,
                                                                                                                                                                       inputProperty.LineOfBusiness,
                                                                                                                                                                       "Failure to Supply Sublimit - GL-211",
                                                                                                                                                                       policyHeader.PolicyEffectiveDate,
                                                                                                                                                                       policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 30.5 - Get system calculated FailuretoSupplySublimitGL211UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.FailuretoSupplySublimitGL211IncludedinExcessExposure) && outputOptionalProperty.FailuretoSupplySublimitGL211IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.FailuretoSupplySublimitGL211UnmodifiedPremium = 0;
                            }
                        }

                        //Step 30.6 - Get system calculated premium
                        outputOptionalProperty.FailuretoSupplySublimitGL211ModifiedPremium = Convert.ToInt32(Math.Round(outputOptionalProperty.FailuretoSupplySublimitGL211UnmodifiedPremium
                                                                                                                      * outputProperty.TierFactor
                                                                                                                      * outputProperty.IRPMFactor
                                                                                                                      * outputProperty.OtherModFactor));
                    }

                    //Step 31 - Fellow Employee - GL-206
                    if (inputOptionalProperty.FellowEmployeeGL206IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.FellowEmployeeGL206Limit = inputOptionalProperty.FellowEmployeeGL206Limit;
                        outputOptionalProperty.FellowEmployeeGL206AggregateLimit = inputOptionalProperty.FellowEmployeeGL206AggregateLimit;
                        outputOptionalProperty.FellowEmployeeGL206Deductible = inputOptionalProperty.FellowEmployeeGL206Deductible;
                        outputOptionalProperty.FellowEmployeeGL206RatingBasis = inputOptionalProperty.FellowEmployeeGL206RatingBasis;
                        outputOptionalProperty.FellowEmployeeGL206ReturnMethod = inputOptionalProperty.FellowEmployeeGL206ReturnMethod;
                        outputOptionalProperty.FellowEmployeeGL206IsSelected = inputOptionalProperty.FellowEmployeeGL206IsSelected;

                        var fellowEmpGL206Limit = Convert.ToString(outputOptionalProperty.FellowEmployeeGL206Limit);
                        //Step 31.1 - Get FellowEmployeeGL206Rate from lookup table
                        outputOptionalProperty.FellowEmployeeGL206Rate = generalLiabilityDataAccess.GetOptionalCoverageRate(policyHeader.State,
                                                                                                                            policyHeader.PrimaryClass,
                                                                                                                            inputProperty.LineOfBusiness,
                                                                                                                            "Fellow Employee - GL-206",
                                                                                                                            fellowEmpGL206Limit,
                                                                                                                            policyHeader.PolicyEffectiveDate,
                                                                                                                            policyHeader.PolicyExpirationDate);

                        //Step 31.2 - Get system calculated premium
                        outputOptionalProperty.FellowEmployeeGL206UnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(outputOptionalProperty.FellowEmployeeGL206Rate
                                                                                                                            * outputProperty.BasePremium
                                                                                                                            * ProRata));


                        outputOptionalProperty.FellowEmployeeGL206UnmodifiedPremium = outputOptionalProperty.FellowEmployeeGL206UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.FellowEmployeeGL206IncludedinExcessExposure = inputOptionalProperty.FellowEmployeeGL206IncludedinExcessExposure;

                        //Step 31.3 - Get FellowEmployeeGL206IncludedinExcessExposure from lookup table
                        if (string.IsNullOrEmpty(outputOptionalProperty.FellowEmployeeGL206IncludedinExcessExposure))
                        {
                            outputOptionalProperty.FellowEmployeeGL206IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                              policyHeader.PrimaryClass,
                                                                                                                                                              inputProperty.LineOfBusiness,
                                                                                                                                                              "Fellow Employee - GL-206",
                                                                                                                                                              policyHeader.PolicyEffectiveDate,
                                                                                                                                                              policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 31.4 - Get system calculated FellowEmployeeGL206UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.FellowEmployeeGL206IncludedinExcessExposure) && outputOptionalProperty.FellowEmployeeGL206IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.FellowEmployeeGL206UnmodifiedPremium = 0;
                            }
                        }

                        //Step 31.5 - Get system calculated premium
                        outputOptionalProperty.FellowEmployeeGL206ModifiedPremium = Convert.ToInt32(Math.Round(outputOptionalProperty.FellowEmployeeGL206UnmodifiedPremium
                                                                                                             * outputProperty.TierFactor
                                                                                                             * outputProperty.IRPMFactor
                                                                                                             * outputProperty.OtherModFactor));

                    }

                    //Step 32 - Limited Pollution Coverage - GL-210
                    if (inputOptionalProperty.LimitedPollutionCoverageGL210IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.LimitedPollutionCoverageGL210Limit = inputOptionalProperty.LimitedPollutionCoverageGL210Limit;
                        outputOptionalProperty.LimitedPollutionCoverageGL210AggregateLimit = inputOptionalProperty.LimitedPollutionCoverageGL210AggregateLimit;
                        outputOptionalProperty.LimitedPollutionCoverageGL210Deductible = inputOptionalProperty.LimitedPollutionCoverageGL210Deductible;
                        outputOptionalProperty.LimitedPollutionCoverageGL210RatingBasis = inputOptionalProperty.LimitedPollutionCoverageGL210RatingBasis;
                        outputOptionalProperty.LimitedPollutionCoverageGL210ReturnMethod = inputOptionalProperty.LimitedPollutionCoverageGL210ReturnMethod;
                        outputOptionalProperty.LimitedPollutionCoverageGL210IsSelected = inputOptionalProperty.LimitedPollutionCoverageGL210IsSelected;

                        var limitedPollutionCoverageGL210Limit = Convert.ToString(inputOptionalProperty.LimitedPollutionCoverageGL210Limit);

                        //Step 32.1 - Get LimitedPollutionCoverageGL210Rate from lookup table
                        outputOptionalProperty.LimitedPollutionCoverageGL210Rate = generalLiabilityDataAccess.GetOptionalCoverageRate(policyHeader.State,
                                                                                                                                      policyHeader.PrimaryClass,
                                                                                                                                      inputProperty.LineOfBusiness,
                                                                                                                                      "Limited Pollution Coverage - GL-210",
                                                                                                                                      limitedPollutionCoverageGL210Limit,
                                                                                                                                      policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);

                        //Step 32.2 - Get system calculated LimitedPollutionCoverageGL210UnmodifiedWithoutExcessPremium
                        outputOptionalProperty.LimitedPollutionCoverageGL210UnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(outputOptionalProperty.LimitedPollutionCoverageGL210Rate
                                                                                                                                      * outputProperty.BasePremium
                                                                                                                                      * ProRata));


                        outputOptionalProperty.LimitedPollutionCoverageGL210UnmodifiedPremium = outputOptionalProperty.LimitedPollutionCoverageGL210UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.LimitedPollutionCoverageGL210IncludedinExcessExposure = inputOptionalProperty.LimitedPollutionCoverageGL210IncludedinExcessExposure;

                        //Step 32.3 - Get LimitedPollutionCoverageGL210IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.LimitedPollutionCoverageGL210IncludedinExcessExposure))
                        {
                            outputOptionalProperty.LimitedPollutionCoverageGL210IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                        policyHeader.PrimaryClass,
                                                                                                                                                                        inputProperty.LineOfBusiness,
                                                                                                                                                                        "Limited Pollution Coverage - GL-210",
                                                                                                                                                                        policyHeader.PolicyEffectiveDate,
                                                                                                                                                                        policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 32.4 - Get system calculated LimitedPollutionCoverageGL210UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.LimitedPollutionCoverageGL210IncludedinExcessExposure) && outputOptionalProperty.LimitedPollutionCoverageGL210IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.LimitedPollutionCoverageGL210UnmodifiedPremium = 0;
                            }
                        }

                        //Step 32.5 - Get system calculated LimitedPollutionCoverageGL210ModifiedPremium
                        outputOptionalProperty.LimitedPollutionCoverageGL210ModifiedPremium = Convert.ToInt32(Math.Round(outputOptionalProperty.LimitedPollutionCoverageGL210UnmodifiedPremium
                                                                                                                       * outputProperty.TierFactor
                                                                                                                       * outputProperty.IRPMFactor
                                                                                                                       * outputProperty.OtherModFactor));
                    }
                }

                if (policyHeader.State == StateCodeConstant.PA)
                {
                    //Step 33 - PA Heart & Lung Benefits - Limit per Officer -GL 801
                    if (inputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801Limit = inputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801Limit;
                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801AggregateLimit = inputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801AggregateLimit;
                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801Deductible = inputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801Deductible;
                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801RatingBasis = inputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801RatingBasis;
                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801ReturnMethod = inputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801ReturnMethod;
                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801Rate = inputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801Rate;
                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IsSelected = inputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IsSelected;

                        //Step 33.1 - Get PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedWithoutExcessPremium from lookup table
                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedWithoutExcessPremium = Convert.ToInt32(generalLiabilityDataAccess.GetOptionalCoveragePremium(policyHeader.State,
                                                                                                                                                                                                policyHeader.PrimaryClass,
                                                                                                                                                                                                inputProperty.LineOfBusiness,
                                                                                                                                                                                                "PA Heart & Lung Benefits - Limit per Officer - GL 801",
                                                                                                                                                                                                policyHeader.PolicyEffectiveDate,
                                                                                                                                                                                                policyHeader.PolicyExpirationDate));

                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedPremium = outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure = inputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure;

                        //Step 33.2 - Get PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure))
                        {
                            outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                                     policyHeader.PrimaryClass,
                                                                                                                                                                                     inputProperty.LineOfBusiness,
                                                                                                                                                                                     "PA Heart & Lung Benefits - Limit per Officer - GL 801",
                                                                                                                                                                                     policyHeader.PolicyEffectiveDate,
                                                                                                                                                                                     policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 33.3 - Get system calculated PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure) && outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedPremium = 0;
                            }
                        }
                    }

                    //Step 34 - PA Heart & Lung Benefits - Policy Level Aggregate - GL 800	
                    if (inputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800Limit = inputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800Limit;
                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800AggregateLimit = inputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800AggregateLimit;
                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800Deductible = inputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800Deductible;
                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800RatingBasis = inputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800RatingBasis;
                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800ReturnMethod = inputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800ReturnMethod;
                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800Rate = inputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800Rate;
                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IsSelected = inputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IsSelected;

                        //Step 34.1 - Get PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedWithoutExcessPremium from lookup table
                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedWithoutExcessPremium = Convert.ToInt32(generalLiabilityDataAccess.GetOptionalCoveragePremium(policyHeader.State,
                                                                                                                                                                                                     policyHeader.PrimaryClass,
                                                                                                                                                                                                     inputProperty.LineOfBusiness,
                                                                                                                                                                                                     "PA Heart & Lung Benefits - Policy Level Aggregate - GL 800",
                                                                                                                                                                                                     policyHeader.PolicyEffectiveDate,
                                                                                                                                                                                                     policyHeader.PolicyExpirationDate));

                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedPremium = outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure = inputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure;

                        //Step 34.2 - Get PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure))
                        {
                            outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State, policyHeader.PrimaryClass, inputProperty.LineOfBusiness, "PA Heart & Lung Benefits - Policy Level Aggregate - GL 800", policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);
                        }
                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 34.3 - Get system calculated premium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure) && outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                string[] stateCheck1 = new string[6] { "CT", "DE", "MA", "ME", "NH", "VT" };

                if (stateCheck1.Contains(policyHeader.State))
                {
                    //Step 35 - Pesticide or Herbicide Applicator - AG 7314	
                    if (inputOptionalProperty.PesticideorHerbicideApplicatorAG7314IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314Limit = inputOptionalProperty.PesticideorHerbicideApplicatorAG7314Limit;
                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314AggregateLimit = inputOptionalProperty.PesticideorHerbicideApplicatorAG7314AggregateLimit;
                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314Deductible = inputOptionalProperty.PesticideorHerbicideApplicatorAG7314Deductible;
                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314RatingBasis = inputOptionalProperty.PesticideorHerbicideApplicatorAG7314RatingBasis;
                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314ReturnMethod = inputOptionalProperty.PesticideorHerbicideApplicatorAG7314ReturnMethod;
                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314Rate = inputOptionalProperty.PesticideorHerbicideApplicatorAG7314Rate;
                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314IsSelected = inputOptionalProperty.PesticideorHerbicideApplicatorAG7314IsSelected;

                        //Step 35.1 - Get PesticideorHerbicideApplicatorAG7314UnmodifiedWithoutExcessPremium from input json
                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314UnmodifiedWithoutExcessPremium = inputOptionalProperty.PesticideorHerbicideApplicatorAG7314UnmodifiedPremium * ProRata;

                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314UnmodifiedPremium = outputOptionalProperty.PesticideorHerbicideApplicatorAG7314UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure = inputOptionalProperty.PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure;

                        //Step 35.2 - Get PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure))
                        {
                            outputOptionalProperty.PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                               policyHeader.PrimaryClass,
                                                                                                                                                                               inputProperty.LineOfBusiness,
                                                                                                                                                                               "Pesticide or Herbicide Applicator - AG 7314",
                                                                                                                                                                               policyHeader.PolicyEffectiveDate,
                                                                                                                                                                               policyHeader.PolicyExpirationDate);
                        }
                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 35.3 - Get system calculated PesticideorHerbicideApplicatorAG7314UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure) && outputOptionalProperty.PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.PesticideorHerbicideApplicatorAG7314UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                string[] stateCheck2 = new string[15] { "CT", "GA", "IL", "IN", "KS", "MA", "ME", "MN", "MO", "MS", "NH", "OH", "PA", "TX", "VT" };

                if (stateCheck2.Contains(policyHeader.State) && (policyHeader.PrimaryClass == "SC" || policyHeader.PrimaryClass == "MSC"))
                {
                    //Step 36 - School Violent Event Response - AG GL 1000
                    if (inputOptionalProperty.SchoolViolentEventResponseAGGL1000IsSelected)
                    {

                        // Step 36.1 - Get limit from input Json
                        outputOptionalProperty.SchoolViolentEventResponseAGGL1000Limit = inputOptionalProperty.SchoolViolentEventResponseAGGL1000Limit;

                        // Step 36.2 - Get Aggregate Limit from input Json
                        outputOptionalProperty.SchoolViolentEventResponseAGGL1000AggregateLimit = inputOptionalProperty.SchoolViolentEventResponseAGGL1000AggregateLimit;

                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.SchoolViolentEventResponseAGGL1000Deductible = inputOptionalProperty.SchoolViolentEventResponseAGGL1000Deductible;
                        outputOptionalProperty.SchoolViolentEventResponseAGGL1000RatingBasis = inputOptionalProperty.SchoolViolentEventResponseAGGL1000RatingBasis;
                        outputOptionalProperty.SchoolViolentEventResponseAGGL1000ReturnMethod = inputOptionalProperty.SchoolViolentEventResponseAGGL1000ReturnMethod;
                        outputOptionalProperty.SchoolViolentEventResponseAGGL1000IsSelected = inputOptionalProperty.SchoolViolentEventResponseAGGL1000IsSelected;

                        var schoolViolentEventResponseAGGL1000Limit = Convert.ToString(inputOptionalProperty.SchoolViolentEventResponseAGGL1000Limit);
                        //Step 36.3 - Get SchoolViolentEventResponseAGGL1000Rate from lookup table
                        outputOptionalProperty.SchoolViolentEventResponseAGGL1000Rate = generalLiabilityDataAccess.GetOptionalCoverageRate(policyHeader.State,
                                                                                                                                           policyHeader.PrimaryClass,
                                                                                                                                           inputProperty.LineOfBusiness,
                                                                                                                                           "School Violent Event Response - AG GL 1000",
                                                                                                                                           schoolViolentEventResponseAGGL1000Limit,
                                                                                                                                           policyHeader.PolicyEffectiveDate,
                                                                                                                                           policyHeader.PolicyExpirationDate);
                        //Step 36.4 - Get System calculated Premium
                        if (policyHeader.PrimaryClass == "SC")
                        {
                            outputOptionalProperty.SchoolViolentEventResponseAGGL1000UnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(outputProperty.Exposure
                                                                                                                                               * outputOptionalProperty.SchoolViolentEventResponseAGGL1000Rate
                                                                                                                                               * ProRata));
                        }
                        else
                        {
                            outputOptionalProperty.SchoolViolentEventResponseAGGL1000UnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(outputProperty.ADA
                                                                                                                                               * outputOptionalProperty.SchoolViolentEventResponseAGGL1000Rate
                                                                                                                                               * ProRata));
                        }

                        outputOptionalProperty.SchoolViolentEventResponseAGGL1000UnmodifiedPremium = outputOptionalProperty.SchoolViolentEventResponseAGGL1000UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.SchoolViolentEventResponseAGGL1000IncludedinExcessExposure = inputOptionalProperty.SchoolViolentEventResponseAGGL1000IncludedinExcessExposure;

                        //Step 36.5 - Get SchoolViolentEventResponseAGGL1000IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.SchoolViolentEventResponseAGGL1000IncludedinExcessExposure))
                        {
                            outputOptionalProperty.SchoolViolentEventResponseAGGL1000IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State, policyHeader.PrimaryClass, inputProperty.LineOfBusiness, "School Violent Event Response - AG GL 1000", policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 36.6 - Get system calculated SchoolViolentEventResponseAGGL1000UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.SchoolViolentEventResponseAGGL1000IncludedinExcessExposure) && outputOptionalProperty.SchoolViolentEventResponseAGGL1000IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.SchoolViolentEventResponseAGGL1000UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                if (stateCheck.Contains(policyHeader.State))
                {
                    //Step 37 -  Sewer Backup Aggregate Limit - GL-217
                    if (inputOptionalProperty.SewerBackupAggregateLimitGL217IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.SewerBackupAggregateLimitGL217Limit = inputOptionalProperty.SewerBackupAggregateLimitGL217Limit;
                        outputOptionalProperty.SewerBackupAggregateLimitGL217AggregateLimit = inputOptionalProperty.SewerBackupAggregateLimitGL217AggregateLimit;
                        outputOptionalProperty.SewerBackupAggregateLimitGL217Deductible = inputOptionalProperty.SewerBackupAggregateLimitGL217Deductible;
                        outputOptionalProperty.SewerBackupAggregateLimitGL217RatingBasis = inputOptionalProperty.SewerBackupAggregateLimitGL217RatingBasis;
                        outputOptionalProperty.SewerBackupAggregateLimitGL217ReturnMethod = inputOptionalProperty.SewerBackupAggregateLimitGL217ReturnMethod;
                        outputOptionalProperty.SewerBackupAggregateLimitGL217Rate = inputOptionalProperty.SewerBackupAggregateLimitGL217Rate;
                        outputOptionalProperty.SewerBackupAggregateLimitGL217IsSelected = inputOptionalProperty.SewerBackupAggregateLimitGL217IsSelected;

                        //Step 37.1 - Get SewerBackupAggregateLimitGL217UnmodifiedWithoutExcessPremium from input Json
                        outputOptionalProperty.SewerBackupAggregateLimitGL217UnmodifiedWithoutExcessPremium = inputOptionalProperty.SewerBackupAggregateLimitGL217UnmodifiedPremium * ProRata;

                        outputOptionalProperty.SewerBackupAggregateLimitGL217UnmodifiedPremium = outputOptionalProperty.SewerBackupAggregateLimitGL217UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.SewerBackupAggregateLimitGL217IncludedinExcessExposure = inputOptionalProperty.SewerBackupAggregateLimitGL217IncludedinExcessExposure;

                        //Step 37.2 - Get SchoolViolentEventResponseAGGL1000IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.SewerBackupAggregateLimitGL217IncludedinExcessExposure))
                        {
                            outputOptionalProperty.SewerBackupAggregateLimitGL217IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State, policyHeader.PrimaryClass, inputProperty.LineOfBusiness, "Sewer Backup Aggregate Limit - GL-217", policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 37.3 - Get system calculated SchoolViolentEventResponseAGGL1000UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.SewerBackupAggregateLimitGL217IncludedinExcessExposure) && outputOptionalProperty.SewerBackupAggregateLimitGL217IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.SewerBackupAggregateLimitGL217UnmodifiedPremium = 0;
                            }
                        }
                    }

                    //Step 38 - Sewer Backup Sublimit - GL-260
                    if (inputOptionalProperty.SewerBackupSublimitGL260IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.SewerBackupSublimitGL260Limit = inputOptionalProperty.SewerBackupSublimitGL260Limit;
                        outputOptionalProperty.SewerBackupSublimitGL260AggregateLimit = inputOptionalProperty.SewerBackupSublimitGL260AggregateLimit;
                        outputOptionalProperty.SewerBackupSublimitGL260Deductible = inputOptionalProperty.SewerBackupSublimitGL260Deductible;
                        outputOptionalProperty.SewerBackupSublimitGL260RatingBasis = inputOptionalProperty.SewerBackupSublimitGL260RatingBasis;
                        outputOptionalProperty.SewerBackupSublimitGL260ReturnMethod = inputOptionalProperty.SewerBackupSublimitGL260ReturnMethod;
                        outputOptionalProperty.SewerBackupSublimitGL260Rate = inputOptionalProperty.SewerBackupSublimitGL260Rate;
                        outputOptionalProperty.SewerBackupSublimitGL260IsSelected = inputOptionalProperty.SewerBackupSublimitGL260IsSelected;

                        //Step 38.1 - Get Premium from input Json
                        outputOptionalProperty.SewerBackupSublimitGL260UnmodifiedWithoutExcessPremium = inputOptionalProperty.SewerBackupSublimitGL260UnmodifiedPremium * ProRata;

                        outputOptionalProperty.SewerBackupSublimitGL260UnmodifiedPremium = outputOptionalProperty.SewerBackupSublimitGL260UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.SewerBackupSublimitGL260IncludedinExcessExposure = inputOptionalProperty.SewerBackupSublimitGL260IncludedinExcessExposure;

                        //Step 38.2 - Get SewerBackupSublimitGL260IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.SewerBackupSublimitGL260IncludedinExcessExposure))
                        {
                            outputOptionalProperty.SewerBackupSublimitGL260IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                   policyHeader.PrimaryClass,
                                                                                                                                                                   inputProperty.LineOfBusiness,
                                                                                                                                                                   "Sewer Backup Sublimit - GL-260",
                                                                                                                                                                   policyHeader.PolicyEffectiveDate,
                                                                                                                                                                   policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 38.3 - Get system calculated SchoolViolentEventResponseAGGL1000UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.SewerBackupSublimitGL260IncludedinExcessExposure) && outputOptionalProperty.SewerBackupSublimitGL260IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.SewerBackupSublimitGL260UnmodifiedPremium = 0;
                            }
                        }
                    }

                    //Step 39 - Additional Insured - Controlling Interest - CG 20 05
                    if (inputOptionalProperty.AdditionalInsuredControllingInterestCG2005IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005Limit = inputOptionalProperty.AdditionalInsuredControllingInterestCG2005Limit;
                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005AggregateLimit = inputOptionalProperty.AdditionalInsuredControllingInterestCG2005AggregateLimit;
                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005Deductible = inputOptionalProperty.AdditionalInsuredControllingInterestCG2005Deductible;
                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005RatingBasis = inputOptionalProperty.AdditionalInsuredControllingInterestCG2005RatingBasis;
                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005ReturnMethod = inputOptionalProperty.AdditionalInsuredControllingInterestCG2005ReturnMethod;
                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005Rate = inputOptionalProperty.AdditionalInsuredControllingInterestCG2005Rate;
                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005IsSelected = inputOptionalProperty.AdditionalInsuredControllingInterestCG2005IsSelected;

                        //Step 39.1 - Get AdditionalInsuredControllingInterestCG2005UnmodifiedWithoutExcessPremium from input Json
                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredControllingInterestCG2005UnmodifiedPremium;

                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredControllingInterestCG2005UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure;

                        //Step 39.2 - Get AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure))
                        {
                            outputOptionalProperty.AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                                     policyHeader.PrimaryClass,
                                                                                                                                                                                     inputProperty.LineOfBusiness,
                                                                                                                                                                                     "Additional Insured - Controlling Interest - CG 20 05",
                                                                                                                                                                                     policyHeader.PolicyEffectiveDate,
                                                                                                                                                                                     policyHeader.PolicyExpirationDate);
                        }
                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 39.3 - Get system calculated AdditionalInsuredControllingInterestCG2005UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.AdditionalInsuredControllingInterestCG2005UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                if (stateCheck3.Contains(policyHeader.State))
                {
                    //Step 40 - Additional Insured - Designated Person or Organization - CG 20 26
                    if (inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026Limit = inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026Limit;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026AggregateLimit = inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026AggregateLimit;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026Deductible = inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026Deductible;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026RatingBasis = inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026RatingBasis;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026ReturnMethod = inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026ReturnMethod;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026Rate = inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026Rate;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected = inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected;

                        //Step 40.1 - Get AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedWithoutExcessPremium from input Json
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium;

                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure;

                        //Step 40.2 - Get AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure))
                        {
                            outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                                                policyHeader.PrimaryClass,
                                                                                                                                                                                                inputProperty.LineOfBusiness,
                                                                                                                                                                                                "Additional Insured - Designated Person or Organization - CG 20 26",
                                                                                                                                                                                                policyHeader.PolicyEffectiveDate,
                                                                                                                                                                                                policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 40.3 - Get system calculated AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                if (stateCheck1.Contains(policyHeader.State))
                {
                    //Step 41 - Additional Insured - Designated Person Or Organization For a Specified Event - AG 7305
                    if (inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Limit = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Limit;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305AggregateLimit = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305AggregateLimit;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Deductible = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Deductible;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305RatingBasis = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305RatingBasis;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305ReturnMethod = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305ReturnMethod;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Rate = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305Rate;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IsSelected = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IsSelected;

                        //Step 41.1 - Get AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedWithoutExcessPremium from input Json
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedPremium;

                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure;

                        //Step 41.2 - Get AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure))
                        {
                            outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                                                                  policyHeader.PrimaryClass,
                                                                                                                                                                                                                  inputProperty.LineOfBusiness,
                                                                                                                                                                                                                  "Additional Insured - Designated Person Or Organization For a Specified Event - AG 7305",
                                                                                                                                                                                                                  policyHeader.PolicyEffectiveDate,
                                                                                                                                                                                                                  policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 41.3 - Get system calculated AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedPremium = 0;
                            }
                        }
                    }

                    //Step 42 - Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306
                    if (inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Limit = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Limit;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306AggregateLimit = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306AggregateLimit;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Deductible = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Deductible;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306RatingBasis = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306RatingBasis;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306ReturnMethod = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306ReturnMethod;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Rate = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306Rate;
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelected = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelected;

                        //Step 42.1 - Get AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedWithoutExcessPremium from input Json
                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremium;

                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure;

                        //Step 42.2 - Get AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure))
                        {
                            outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                                                                     policyHeader.PrimaryClass,
                                                                                                                                                                                                                     inputProperty.LineOfBusiness,
                                                                                                                                                                                                                     "Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306",
                                                                                                                                                                                                                     policyHeader.PolicyEffectiveDate,
                                                                                                                                                                                                                     policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 42.3 - Get system calculated AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremium = 0;
                            }
                        }
                    }

                    //Step 43 -  Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34
                    if (inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Limit = inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Limit;
                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034AggregateLimit = inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034AggregateLimit;
                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Deductible = inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Deductible;
                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034RatingBasis = inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034RatingBasis;
                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034ReturnMethod = inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034ReturnMethod;
                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Rate = inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034Rate;
                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IsSelected = inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IsSelected;

                        //Step 43.1 - Get Premium from input Json
                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium;

                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure;

                        //Step 43.2 - Get AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure))
                        {
                            outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure =
                                generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                             policyHeader.PrimaryClass,
                                                                                             inputProperty.LineOfBusiness,
                                                                                             "Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34",
                                                                                             policyHeader.PolicyEffectiveDate,
                                                                                             policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 43.3 - Get system calculated AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium = 0;
                            }
                        }

                    }
                }


                //Step 44 - Additional Insured - Lessor of Leased Equipment - CG 20 28
                if (inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IsSelected)
                {
                    //Output Json Variable are Assigned by input Json
                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028Limit = inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028Limit;
                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028AggregateLimit = inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028AggregateLimit;
                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028Deductible = inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028Deductible;
                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028RatingBasis = inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028RatingBasis;
                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028ReturnMethod = inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028ReturnMethod;
                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028Rate = inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028Rate;
                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IsSelected = inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IsSelected;

                    //Step 44.1 - Get AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedWithoutExcessPremium from input Json
                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium;

                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedWithoutExcessPremium;

                    outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure;

                    //Step 44.2 - Get AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure form lookup table
                    if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure))
                    {
                        outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                                                                     policyHeader.PrimaryClass,
                                                                                                                                                                                     inputProperty.LineOfBusiness,
                                                                                                                                                                                     "Additional Insured - Lessor of Leased Equipment - CG 20 28",
                                                                                                                                                                                     policyHeader.PolicyEffectiveDate,
                                                                                                                                                                                     policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 44.3 - Get system calculated AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure.ToUpper() == "TRUE")
                        {
                            outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium = 0;
                        }
                    }
                }

                if (stateCheck1.Contains(policyHeader.State))
                {
                    //Step 45 - Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307	
                    if (inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Limit = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Limit;
                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307AggregateLimit = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307AggregateLimit;
                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Deductible = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Deductible;
                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307RatingBasis = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307RatingBasis;
                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307ReturnMethod = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307ReturnMethod;
                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Rate = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307Rate;
                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelected = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelected;

                        //Step 45.1 - Get Premium from input Json
                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium;

                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure;

                        //Step 45.2 - Get AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure))
                        {
                            outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure =
                                            generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                         policyHeader.PrimaryClass,
                                                                                                         inputProperty.LineOfBusiness,
                                                                                                         "Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307",
                                                                                                         policyHeader.PolicyEffectiveDate,
                                                                                                         policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 45.3 - Get system calculated AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                //Step 46 - Additional Insured - Managers or Lessors of Premises - CG 20 11	
                if (inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IsSelected)
                {
                    //Output Json Variable are Assigned by input Json
                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011Limit = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011Limit;
                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011AggregateLimit = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011AggregateLimit;
                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011Deductible = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011Deductible;
                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011RatingBasis = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011RatingBasis;
                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011ReturnMethod = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011ReturnMethod;
                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011Rate = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011Rate;
                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IsSelected = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IsSelected;

                    //Step 46.1 - Get AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedWithoutExcessPremium from input Json
                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium;

                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedWithoutExcessPremium;

                    outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure;

                    //Step 46.2 - Get AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure form lookup table
                    if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure))
                    {
                        outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure =
                            generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                         policyHeader.PrimaryClass,
                                                                                         inputProperty.LineOfBusiness,
                                                                                         "Additional Insured - Managers or Lessors of Premises - CG 20 11",
                                                                                         policyHeader.PolicyEffectiveDate,
                                                                                         policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 46.3 - Get system calculated AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure.ToUpper() == "TRUE")
                        {
                            outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium = 0;
                        }
                    }
                }

                string[] stateCheck4 = new string[23] { "AL", "CO", "CT", "DE", "GA", "IL", "IN", "KS", "MA", "ME", "MI", "MN", "MO", "MS", "NC", "NY", "OH", "PA", "SC", "TX", "UT", "VT", "WY" };

                if (stateCheck4.Contains(policyHeader.State))
                {
                    //Step 47 - Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18	
                    if (inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018Limit = inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018Limit;
                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018AggregateLimit = inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018AggregateLimit;
                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018Deductible = inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018Deductible;
                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018RatingBasis = inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018RatingBasis;
                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018ReturnMethod = inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018ReturnMethod;
                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018Rate = inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018Rate;
                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected = inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected;

                        //Step 47.1 - Get AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedWithoutExcessPremium from input Json
                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium;

                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure;

                        //Step 47.2 - Get AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure))
                        {
                            outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State, policyHeader.PrimaryClass, inputProperty.LineOfBusiness, "Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18", policyHeader.PolicyEffectiveDate, policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 47.3 - Get system calculated AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                //Step 48 - Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24	
                if (inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IsSelected)
                {
                    //Output Json Variable are Assigned by input Json
                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Limit = inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Limit;
                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024AggregateLimit = inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024AggregateLimit;
                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Deductible = inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Deductible;
                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024RatingBasis = inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024RatingBasis;
                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024ReturnMethod = inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024ReturnMethod;
                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Rate = inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024Rate;
                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IsSelected = inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IsSelected;

                    //Step 48.1 - Get AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedWithoutExcessPremium from input Json
                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium;

                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedWithoutExcessPremium;

                    outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure;

                    //Step 48.2 - Get AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure form lookup table
                    if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure))
                    {
                        outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure =
                            generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                         policyHeader.PrimaryClass,
                                                                                         inputProperty.LineOfBusiness,
                                                                                         "Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24",
                                                                                         policyHeader.PolicyEffectiveDate,
                                                                                         policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 48.3 - Get system calculated AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure.ToUpper() == "TRUE")
                        {
                            outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium = 0;
                        }
                    }
                }

                string[] stateCheck5 = new string[16] { "AL", "CO", "CT", "GA", "IL", "IN", "KS", "MA", "ME", "MO", "MS", "NH", "OH", "PA", "TX", "VT" };

                if (stateCheck5.Contains(policyHeader.State) && (policyHeader.PrimaryClass == "SC" || policyHeader.PrimaryClass == "MSC"))
                {
                    //Step 49 - Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310	
                    if (inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Limit = inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Limit;
                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310AggregateLimit = inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310AggregateLimit;
                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Deductible = inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Deductible;
                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310RatingBasis = inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310RatingBasis;
                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310ReturnMethod = inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310ReturnMethod;
                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Rate = inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310Rate;
                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected = inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected;

                        //Step 49.1 - Get AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedWithoutExcessPremium from input Json
                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium;

                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure;

                        //Step 49.2 - Get AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure))
                        {
                            outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure =
                                generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                             policyHeader.PrimaryClass,
                                                                                             inputProperty.LineOfBusiness,
                                                                                             "Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24",
                                                                                             policyHeader.PolicyEffectiveDate,
                                                                                             policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 49.3 - Get system calculated AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                //Step 50 - Additional Insured - Users of Golfmobiles - CG 20 08	
                if (inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IsSelected)
                {
                    //Output Json Variable are Assigned by input Json
                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008Limit = inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008Limit;
                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008AggregateLimit = inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008AggregateLimit;
                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008Deductible = inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008Deductible;
                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008RatingBasis = inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008RatingBasis;
                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008ReturnMethod = inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008ReturnMethod;
                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008Rate = inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008Rate;
                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IsSelected = inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IsSelected;

                    //Step 50.1 - Get AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedWithoutExcessPremium from input Json
                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedWithoutExcessPremium = inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium;

                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium = outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedWithoutExcessPremium;

                    outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure = inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure;

                    //Step 50.2 - Get AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure form lookup table
                    if (String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure))
                    {
                        outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure =
                            generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                         policyHeader.PrimaryClass,
                                                                                         inputProperty.LineOfBusiness,
                                                                                         "Additional Insured - Users of Golfmobiles - CG 20 08",
                                                                                         policyHeader.PolicyEffectiveDate,
                                                                                         policyHeader.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                    {
                        //Step 50.3 - Get system calculated AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium
                        if (!string.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure.ToUpper() == "TRUE")
                        {
                            outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium = 0;
                        }
                    }
                }

                if (stateCheck1.Contains(policyHeader.State))
                {
                    //Step 51 - Limited Additional Insured - Designated Person Or Organization For Designated Premises - AG 7309	
                    if (inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Limit = inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Limit;
                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309AggregateLimit = inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309AggregateLimit;
                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Deductible = inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Deductible;
                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309RatingBasis = inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309RatingBasis;
                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309ReturnMethod = inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309ReturnMethod;
                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Rate = inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309Rate;
                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IsSelected = inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IsSelected;

                        //Step 51.1 - Get LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedWithoutExcessPremium from input json
                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedWithoutExcessPremium = inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium;

                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium = outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedWithoutExcessPremium;

                        outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure = inputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure;

                        //Step 51.2 - Get LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure form lookup table
                        if (String.IsNullOrEmpty(outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure))
                        {
                            outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure =
                                generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                             policyHeader.PrimaryClass,
                                                                                             inputProperty.LineOfBusiness,
                                                                                             "Additional Insured - Users of Golfmobiles - CG 20 08",
                                                                                             policyHeader.PolicyEffectiveDate,
                                                                                             policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 51.3 - Get system calculated LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium
                            if (!string.IsNullOrEmpty(outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure) && outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium = 0;
                            }
                        }
                    }
                }

                //Step 52 - Other	
                if (inputOptionalProperty.GeneralLiabilityOptionalOtherCoverageModel != null && inputOptionalProperty.GeneralLiabilityOptionalOtherCoverageModel.Count > 0)
                {
                    foreach (var OtherCoverage in inputOptionalProperty.GeneralLiabilityOptionalOtherCoverageModel)
                    {
                        int OtherCoverageUnmodifiedwithoutExcessPremium = 0;
                        string OtherCoverageIncludedInExcessExposure = null;
                        int OtherCoverageUnmodifiedPremium = 0;

                        //Step 52.1 When Rating basis is  'Flat charge'
                        if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARGE")
                        {
                            //Step 52.1.1 - Get OtherCoverageUnmodifiedwithoutExcessPremium entered value
                            OtherCoverageUnmodifiedwithoutExcessPremium = OtherCoverage.OtherCoverageUnmodifiedPremium * ProRata;
                        }
                        //Step 52.2 Rating basis is  'per 1,000 of limit'	
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                        {
                            //Step 52.2.1 - Get OtherCoverageUnmodifiedwithoutExcessPremium entered value
                            OtherCoverageUnmodifiedwithoutExcessPremium = Convert.ToInt32(Math.Round((OtherCoverage.OtherCoverageLimit
                                                                                                     / 1000)
                                                                                                     * OtherCoverage.OtherCoverageRate
                                                                                                     * ProRata
                                                                                                     , 0
                                                                                                     , MidpointRounding.AwayFromZero));
                        }
                        //Step 52.3 - When Rating basis is 'per 100 of limit'
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                        {
                            //Step 52.3.1 - Get OtherCoverageUnmodifiedwithoutExcessPremium entered value
                            OtherCoverageUnmodifiedwithoutExcessPremium = Convert.ToInt32(Math.Round((OtherCoverage.OtherCoverageLimit
                                                                                                     / 100)
                                                                                                     * OtherCoverage.OtherCoverageRate
                                                                                                     * ProRata
                                                                                                     , 0
                                                                                                     , MidpointRounding.AwayFromZero));

                        }
                        //Step 52.4 When Rating basis is 'No Charge'
                        else if (OtherCoverage.OtherCoverageRatingBasis.ToUpper() == "No Charge")
                        {
                            //Step 52.4.1 - Get OtherCoverageUnmodifiedwithoutExcessPremium entered value
                            OtherCoverageUnmodifiedwithoutExcessPremium = 0;
                        }

                        OtherCoverageUnmodifiedPremium = OtherCoverageUnmodifiedwithoutExcessPremium;
                        OtherCoverageIncludedInExcessExposure = OtherCoverage.OtherCoverageIncludedinExcessExposure;
                        if (String.IsNullOrEmpty(OtherCoverageIncludedInExcessExposure))
                        {
                            OtherCoverageIncludedInExcessExposure = generalLiabilityDataAccess.GetOptionalCoverageExcessExposure(policyHeader.State,
                                                                                                                                 policyHeader.PrimaryClass,
                                                                                                                                 inputProperty.LineOfBusiness,
                                                                                                                                 "Other",
                                                                                                                                 policyHeader.PolicyEffectiveDate,
                                                                                                                                 policyHeader.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && LiabilityCheck.Contains(inputProperty.LiabilityLimit))
                        {
                            //Step 52.4.3 - Get system calculated OtherCoverageUnmodifiedPremium
                            if (!string.IsNullOrEmpty(OtherCoverageIncludedInExcessExposure) && OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                OtherCoverageUnmodifiedPremium = 0;
                            }
                        }

                        totalOtherCoverageUnmodifiedPremium = totalOtherCoverageUnmodifiedPremium + OtherCoverageUnmodifiedPremium;
                        if (!String.IsNullOrEmpty(OtherCoverage.OtherCoverageIncludedinExcessExposure) && OtherCoverage.OtherCoverageIncludedinExcessExposure.ToUpper() == "TRUE")
                        {
                            totalOtherCoverageUnmodifiedwithoutExcessPremium = totalOtherCoverageUnmodifiedwithoutExcessPremium + OtherCoverageUnmodifiedwithoutExcessPremium;
                        }

                        outputOptionalProperty.GeneralLiabilityOptionalOtherCoverageModel.Add(new GeneralLiabilityOptionalOtherCoverageOutputModel
                        {
                            OtherCoverageID = OtherCoverage.OtherCoverageID,
                            OtherCoverageLimit = OtherCoverage.OtherCoverageLimit,
                            OtherCoverageAggregateLimit = OtherCoverage.OtherCoverageAggregateLimit,
                            OtherCoverageDeductible = OtherCoverage.OtherCoverageDeductible,
                            OtherCoverageDescription = OtherCoverage.OtherCoverageDescription,
                            OtherCoverageRate = OtherCoverage.OtherCoverageRate,
                            OtherCoverageReturnMethod = OtherCoverage.OtherCoverageReturnMethod,
                            OtherCoverageRatingBasis = OtherCoverage.OtherCoverageRatingBasis,
                            OtherCoverageIncludedinExcessExposure = OtherCoverageIncludedInExcessExposure,
                            OtherCoverageUnmodifiedWithoutExcessPremium = OtherCoverageUnmodifiedwithoutExcessPremium,
                            OtherCoverageUnmodifiedPremium = OtherCoverageUnmodifiedPremium
                        });
                    }
                }


                this.logger.Info("GeneralLiabilityService.CalculateOptionalCoveragePremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Non-Modified Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateNonModifiedPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateNonModifiedPremium :: Started");

                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;

                //Step B - Non-Modified Premium Calculation
                // Step B.1 - Get system calculated value
                //(Step 19.3 + Step 20.3 + Step 21.4 + Step 22.13/Step 22.22 + Step 23.12/Step 23.17 + Step 25.1 + Step 26.5 + Step 27.5 + Step 28.3 +Step 33.3 + 
                //Step 34.3 + Step 35.3 + Step 36.6+ Step 37.3 + Step 38.3+ Step 39.3 + Step 40.3+ Step 41.3 + Step 42.3+ Step 43.3 + Step 44.3+ Step 45.3 + 
                //Step 46.3 + Step 47.3 + Step 48.3 + Step 49.3 + Step 50.3 + Step 51.3 + Step 52.1.3 + Step 52.2.5 + Step 52.3.5 + Step52.4.3)
                outputProperty.NonModifiedPremium = outputProperty.DamageToPremisesUnmodifiedPremium
                                                  + outputProperty.MedicalPaymentsUnmodifiedPremium
                                                  + outputProperty.EBUnmodifiedPremium
                                                  + outputProperty.TotalDataCompromiseUnmodifiedPremium
                                                  + outputProperty.TotalCyberUnmodifiedPremium
                                                  + outputOptionalProperty.CemeteryProfessionalLiabilityGL203UnmodifiedWithoutExcessPremium
                                                  + outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                  + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium
                                                  + outputOptionalProperty.EmployersLiabilityGL600UnmodifiedPremium
                                                  + outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedPremium
                                                  + outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedPremium
                                                  + outputOptionalProperty.PesticideorHerbicideApplicatorAG7314UnmodifiedPremium
                                                  + outputOptionalProperty.SchoolViolentEventResponseAGGL1000UnmodifiedPremium
                                                  + outputOptionalProperty.SewerBackupAggregateLimitGL217UnmodifiedPremium
                                                  + outputOptionalProperty.SewerBackupSublimitGL260UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredControllingInterestCG2005UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium
                                                  + outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium
                                                  + outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium
                                                  + totalOtherCoverageUnmodifiedPremium;


                this.logger.Info("GeneralLiabilityService.CalculateNonModifiedPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateNonModifiedPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Modifiable Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateModifiablePremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateModifiablePremium :: Started");

                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;

                //Step C - Modifiable Premium Calculation
                //Step C.1 - Get system calculated value
                //(Step 29.5 + Step 30.5 + Step 31.4 + Step 32.4)
                outputProperty.ModifiablePremium = outputOptionalProperty.FailuretoSupplyExclusionGL304UnmodifiedPremium
                                                 + outputOptionalProperty.FailuretoSupplySublimitGL211UnmodifiedPremium
                                                 + outputOptionalProperty.FellowEmployeeGL206UnmodifiedPremium
                                                 + outputOptionalProperty.LimitedPollutionCoverageGL210UnmodifiedPremium;


                this.logger.Info("GeneralLiabilityService.CalculateModifiablePremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateModifiablePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Manual Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateManualPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateManualPremium :: Started");

                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                //Step D - Manual Premium Calculation
                //Step D.1 - Get system calculated value(Step A.1 + Step B.1 + Step C.1 )
                if (inputProperty.UnmannedAircraftOption.ToUpper() == "EXCLUDE - CG 21 09")
                {
                    outputProperty.ManualPremium = outputProperty.BasePremium
                                                 + outputProperty.NonModifiedPremium
                                                 + outputProperty.ModifiablePremium;
                }
                //(Step A.1 + Step B.1 + Step C.1 + Step 24.14)
                else
                {
                    outputProperty.ManualPremium = outputProperty.BasePremium
                                                 + outputProperty.NonModifiedPremium
                                                 + outputProperty.ModifiablePremium
                                                 + outputProperty.UnmannedAircraftUnModifiedTotalPremium;
                }

                outputProperty.MinimumPremium = Convert.ToInt32(generalLiabilityDataAccess.GetLOBMiniumPremium(policyHeader.State,
                                                                                                               policyHeader.PrimaryClass,
                                                                                                               inputProperty.LineOfBusiness,
                                                                                                               policyHeader.PolicyEffectiveDate,
                                                                                                               policyHeader.PolicyExpirationDate));

                //Apply Minimum Premium rules
                if (outputProperty.ManualPremium < outputProperty.MinimumPremium)
                {
                    outputProperty.ManualPremium = outputProperty.MinimumPremium;
                }
                //Note - If Cyber Suppl. Extended Reporting Period Is Selected =1 OR  Data Compromise Suppl. Extended Reporting Period Is Selected =1 
                if (outputOptionalProperty.CyberSupplExtendedReportingPeriodIsSelected || outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIsSelected)
                {
                    //Apply LOB Minimum Premium condition as mentioned below -
                    // 1.Calculated Manual Premium = (Manual Premium - (Cyber Suppl.Extended Reporting Period Unmodified Premium + Data Compromie Suppl. Extended Reporting Period Unmodified Premium))
                    outputProperty.ManualPremium = (outputProperty.ManualPremium
                                                 - (outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                 + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium));

                    //2. If Calculated Manual Premium in #1 is less than the LOB MINIMUM PREMIUM.
                    //Then
                    // Manual Premium = LOB MINIMUM PREMIUM +Cyber Suppl.Extended Reporting Period modified Premium + Data compromise Suppl. Extended Reporting Period Unmodified Premium
                    if (outputProperty.ManualPremium < outputProperty.MinimumPremium)
                    {
                        outputProperty.ManualPremium = outputProperty.MinimumPremium
                                                     + outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                     + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateManualPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateManualPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Tier Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateTierPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateTierPremium :: Started");

                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;

                //Step E - Tier Premium Calculation
                //Step E.1 - Get system calculated value(((Step D.1  - Step B.1)  * Step 14 + Step B.1)
                outputProperty.TierPremium = (outputProperty.ManualPremium
                                            - outputProperty.NonModifiedPremium)
                                            * ProRata
                                            + outputProperty.NonModifiedPremium;


                //Apply Minimum Premium rules
                if (outputProperty.TierPremium < outputProperty.MinimumPremium)
                {
                    outputProperty.TierPremium = outputProperty.MinimumPremium;
                }

                //Note - If Cyber Suppl. Extended Reporting Period Is Selected =1 OR  Data Compromise Suppl. Extended Reporting Period Is Selected =1 
                if (outputOptionalProperty.CyberSupplExtendedReportingPeriodIsSelected || outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIsSelected)
                {
                    //Apply LOB Minimum Premium condition as mentioned below -
                    // 1.Calculated Tier Premium = (Tier Premium - (Cyber Suppl.Extended Reporting Period Unmodified Premium + Data Compromie Suppl. Extended Reporting Period Unmodified Premium))
                    outputProperty.TierPremium = (outputProperty.TierPremium -
                                                 (outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium));

                    //2. If Calculated Tier Premium in #1 is less than the LOB MINIMUM PREMIUM.
                    //Then
                    // Tier Premium = LOB MINIMUM PREMIUM +Cyber Suppl.Extended Reporting Period modified Premium + Data compromise Suppl. Extended Reporting Period Unmodified Premium
                    if (outputProperty.TierPremium < outputProperty.MinimumPremium)
                    {
                        outputProperty.TierPremium = outputProperty.MinimumPremium
                                                   + outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                   + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateTierPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateTierPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate IRPM Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateIRPMPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateIRPMPremium :: Started");

                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;

                //Step F - IRPM Premium Calculation
                //Step F.1 - Get system calculated value(((Step E.1  - Step B.1)  * Step 17 + Step B.1)
                outputProperty.IRPMPremium = Convert.ToInt32(Math.Round((outputProperty.TierPremium
                                                                       - outputProperty.NonModifiedPremium)
                                                                       * outputProperty.IRPMFactor
                                                                       + outputProperty.NonModifiedPremium));

                //Apply Minimum Premium rules
                if (outputProperty.IRPMPremium < outputProperty.MinimumPremium)
                {
                    outputProperty.IRPMPremium = outputProperty.MinimumPremium;
                }

                //Note - If Cyber Suppl. Extended Reporting Period Is Selected =1 OR  Data Compromise Suppl. Extended Reporting Period Is Selected =1 
                if (outputOptionalProperty.CyberSupplExtendedReportingPeriodIsSelected || outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIsSelected)
                {
                    //Apply LOB Minimum Premium condition as mentioned below -
                    // 1.Calculated IRPM Premium = (IRPM Premium - (Cyber Suppl.Extended Reporting Period Unmodified Premium + Data Compromie Suppl. Extended Reporting Period Unmodified Premium))
                    outputProperty.IRPMPremium = (outputProperty.IRPMPremium
                                               - (outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                               + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium));

                    //2. If Calculated IRPM Premium in #1 is less than the LOB MINIMUM PREMIUM.
                    //Then
                    // IRPM Premium = LOB MINIMUM PREMIUM +Cyber Suppl.Extended Reporting Period modified Premium + Data compromise Suppl. Extended Reporting Period Unmodified Premium
                    if (outputProperty.IRPMPremium < outputProperty.MinimumPremium)
                    {
                        outputProperty.IRPMPremium = outputProperty.MinimumPremium
                                                   + outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                   + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateIRPMPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateIRPMPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Other Mod Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateOtherModPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateOtherModPremium :: Started");

                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;

                //Step G - Other Mod Premium Calculation
                //Step G.1 - Get system calculated value(((Step F.1  - Step B.1)  * Step 18 + Step B.1)
                outputProperty.OtherModPremium = Convert.ToInt32(Math.Round((outputProperty.IRPMPremium
                                                                           - outputProperty.NonModifiedPremium)
                                                                           * outputProperty.OtherModFactor
                                                                           + outputProperty.NonModifiedPremium
                                                                           , 0
                                                                           , MidpointRounding.AwayFromZero));

                //Apply Minimum Premium rules
                if (outputProperty.OtherModPremium < outputProperty.MinimumPremium)
                {
                    outputProperty.OtherModPremium = outputProperty.MinimumPremium;
                }

                //Note - If Cyber Suppl. Extended Reporting Period Is Selected =1 OR  Data Compromise Suppl. Extended Reporting Period Is Selected =1 
                if (outputOptionalProperty.CyberSupplExtendedReportingPeriodIsSelected || outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIsSelected)
                {
                    //Apply LOB Minimum Premium condition as mentioned below -
                    // 1.Calculated OtherMod Premium = (OtherMod Premium - (Cyber Suppl.Extended Reporting Period Unmodified Premium + Data Compromie Suppl. Extended Reporting Period Unmodified Premium))
                    outputProperty.OtherModPremium = (outputProperty.OtherModPremium
                                                   - (outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                   + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium));

                    //2. If Calculated OtherMod Premium in #1 is less than the LOB MINIMUM PREMIUM.
                    // OtherMod Premium = LOB MINIMUM PREMIUM + Cyber Suppl.Extended Reporting Period modified Premium + Data compromise Suppl. Extended Reporting Period Unmodified Premium
                    if (outputProperty.OtherModPremium < outputProperty.MinimumPremium)
                    {
                        outputProperty.OtherModPremium = outputProperty.MinimumPremium
                                                       + outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                       + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateOtherModPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateOtherModPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Terrorism Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateTerrorismPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateTerrorismPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;

                //Step H - Terrorism Premium Calculation
                //Step H.1 - Get system calculated value (Step G.1 - (Step 22.13/Step 22.22 + Step 23.12/Step 23.17)) * Step 15
                outputProperty.TerrorismPremium = Convert.ToInt32(Math.Round((outputProperty.OtherModPremium
                                                                           - (outputProperty.TotalDataCompromiseUnmodifiedPremium
                                                                           + outputProperty.TotalCyberUnmodifiedPremium)
                                                                           * outputProperty.TerrorismFactor)
                                                                           , 0
                                                                           , MidpointRounding.AwayFromZero));


                this.logger.Info("GeneralLiabilityService.CalculateTerrorismPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateTerrorismPremium :: Exception :: " + ex.Message, ex);
                throw;

            }
        }

        /// <summary>
        /// Calculate  Final Modified Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateFinalModifiedPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateFinalModifiedPremium :: Started");

                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;

                //Step I - Final Modified Premium Calculation	
                //Step I.1 - Get system calculated value(Step G.1 + Step H.1)
                outputProperty.GLFinalModifiedPremium = outputProperty.OtherModPremium
                                                      + outputProperty.TerrorismPremium;

                //Apply Minimum Premium rules
                if (outputProperty.GLFinalModifiedPremium < outputProperty.MinimumPremium)
                {
                    outputProperty.GLFinalModifiedPremium = outputProperty.MinimumPremium;
                }

                //Note - If Cyber Suppl. Extended Reporting Period Is Selected =1 OR  Data Compromise Suppl. Extended Reporting Period Is Selected =1 
                if (outputOptionalProperty.CyberSupplExtendedReportingPeriodIsSelected || outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIsSelected)
                {
                    //Apply LOB Minimum Premium condition as mentioned below -
                    // 1.Calculated GLFinalModified Premium = (GLFinalModified Premium - (Cyber Suppl.Extended Reporting Period Unmodified Premium + Data Compromie Suppl. Extended Reporting Period Unmodified Premium))
                    outputProperty.GLFinalModifiedPremium = outputProperty.GLFinalModifiedPremium
                                                         - (outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                          + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium);

                    //2. If Calculated GLFinalModified Premium in #1 is less than the LOB MINIMUM PREMIUM.
                    // GLFinalModified Premium = LOB MINIMUM PREMIUM +Cyber Suppl.Extended Reporting Period modified Premium + Data compromise Suppl. Extended Reporting Period Unmodified Premium
                    if (outputProperty.GLFinalModifiedPremium < outputProperty.MinimumPremium)
                    {
                        outputProperty.GLFinalModifiedPremium = outputProperty.MinimumPremium
                                                              + outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium
                                                              + outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium;
                    }
                }

                this.logger.Info("GeneralLiabilityService.CalculateFinalModifiedPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateFinalModifiedPremium :: Exception :: " + ex.Message, ex);
                throw;

            }
        }

        /// <summary>
        /// Calculate  Total Unmodified without Excess Premium
        /// </summary> 
        /// <param name="model"></param>
        public void CalculateTotalUnmodifiedWithoutExcessPremium(RaterFacadeModel model)
        {
            try
            {
                this.logger.Info("GeneralLiabilityService.CalculateTotalUnmodifiedWithoutExcessPremium :: Started");

                var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;

                //Step J - Total Unmodified without Excess Premium Calculation	
                //Step I.1 - Get system calculated value
                //(Step  19.1 + Step 20.1 + Step 21.2 + Step 22.11 / Step 22.20 + Step 23.10 / Step 23.15 + Step 25.1 
                //+ Step 26.3 + Step 27.3 + Step 28.1 + Step 33.1 + Step 34.1 + Step 35.1 + Step 36.4 + Step 37.1 + Step 38.1
                //+ Step 39.1 + Step 40.1 + Step 41.1 + Step 42.1 + Step 43.1 + Step 44.1 + Step 45.1 + Step 46.1 + Step 47.1 
                //+ Step 48.1 + Step 49.1 + Step 50.1 + Step 51.1 + Step 52.1.1 + Step 52.2.3 + Step 52.3.3 + 52.4.1 + Step 24.12
                //+ Step 29.3 + Step 30.3 + Step 31.2 + Step 32.2)
                outputProperty.GLTotalUnmodifiedwithoutExcessPremium = ((!String.IsNullOrEmpty(outputProperty.DamageToPremisesIncludedInExcessExposure) && outputProperty.DamageToPremisesIncludedInExcessExposure.ToUpper() == "TRUE") ? outputProperty.DamageToPremisesUnmodifiedwithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputProperty.MedicalPaymentsIncludedInExcessExposure) && outputProperty.MedicalPaymentsIncludedInExcessExposure.ToUpper() == "TRUE") ? outputProperty.MedicalPaymentsUnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputProperty.EBIncludedInExcessExposure) && outputProperty.EBIncludedInExcessExposure.ToUpper() == "TRUE") ? outputProperty.EBUnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputProperty.DataCompromiseIncludedInExcessExposure) && outputProperty.DataCompromiseIncludedInExcessExposure.ToUpper() == "TRUE") ? outputProperty.TotalDataCompromiseUnmodifiedwithoutexcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputProperty.CyberIncludedInExcessExposure) && outputProperty.CyberIncludedInExcessExposure.ToUpper() == "TRUE") ? outputProperty.TotalCyberUnmodifiedwithoutexcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputProperty.UnmannedAircraftcoverageIncludedinExcessExposure) && outputProperty.UnmannedAircraftcoverageIncludedinExcessExposure.ToUpper() == "TRUE") ? outputProperty.UnmannedAircraftTotalUnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.CemeteryProfessionalLiabilityGL203IncludedinExcessExposure) && outputOptionalProperty.CemeteryProfessionalLiabilityGL203IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.CemeteryProfessionalLiabilityGL203UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.CyberSupplExtendedReportingPeriodIncludedinExcessExposure) && outputOptionalProperty.CyberSupplExtendedReportingPeriodIncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure) && outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.EmployersLiabilityGL600IncludedinExcessExposure) && outputOptionalProperty.EmployersLiabilityGL600IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.EmployersLiabilityGL600UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure) && outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure) && outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure) && outputOptionalProperty.PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.PesticideorHerbicideApplicatorAG7314UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.SchoolViolentEventResponseAGGL1000IncludedinExcessExposure) && outputOptionalProperty.SchoolViolentEventResponseAGGL1000IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.SchoolViolentEventResponseAGGL1000UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.SewerBackupAggregateLimitGL217IncludedinExcessExposure) && outputOptionalProperty.SewerBackupAggregateLimitGL217IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.SewerBackupAggregateLimitGL217UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.SewerBackupSublimitGL260IncludedinExcessExposure) && outputOptionalProperty.SewerBackupSublimitGL260IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.SewerBackupSublimitGL260UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredControllingInterestCG2005UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure) && outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure) && outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.FailuretoSupplyExclusionGL304IncludedinExcessExposure) && outputOptionalProperty.FailuretoSupplyExclusionGL304IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.FailuretoSupplyExclusionGL304UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.FailuretoSupplySublimitGL211IncludedinExcessExposure) && outputOptionalProperty.FailuretoSupplySublimitGL211IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.FailuretoSupplySublimitGL211UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.FellowEmployeeGL206IncludedinExcessExposure) && outputOptionalProperty.FellowEmployeeGL206IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.FellowEmployeeGL206UnmodifiedWithoutExcessPremium : 0)
                                                                      + ((!String.IsNullOrEmpty(outputOptionalProperty.LimitedPollutionCoverageGL210IncludedinExcessExposure) && outputOptionalProperty.LimitedPollutionCoverageGL210IncludedinExcessExposure.ToUpper() == "TRUE") ? outputOptionalProperty.LimitedPollutionCoverageGL210UnmodifiedWithoutExcessPremium : 0)
                                                                      + totalOtherCoverageUnmodifiedwithoutExcessPremium;


                this.logger.Info("GeneralLiabilityService.CalculateTotalUnmodifiedWithoutExcessPremium :: Completed");
            }

            catch (Exception ex)
            {
                this.logger.Error("GeneralLiabilityService.CalculateTotalUnmodifiedWithoutExcessPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region Get Yearfrac

        /// <summary>
        /// YearFrac
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>decimal</returns>
        public decimal YearFrac(DateTime startDate, DateTime endDate)
        {
            this.logger.Info("LawService.YearFrac :: Starting");
            if (endDate < startDate)
            {
                return 0;
            }
            int endDay = endDate.Day;
            int startDay = startDate.Day;
            switch (startDay)
            {
                case 31:
                    {
                        startDay = 30;
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 30:
                    {
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 29:
                    {
                        if (startDate.Month == 2)
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;

                case 28:
                    {
                        if ((startDate.Month == 2) && (!DateTime.IsLeapYear(startDate.Year)))
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;
            }
            decimal yearFrac = (((endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDay - startDay)) / 360);

            this.logger.Info("LawService.YearFrac :: Completed");
            return yearFrac;
        }

        #endregion
    }
}

