﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaterGeneralLiability
{
    public class GeneralLiabilityServiceWrapper
    {
        /// <summary>
        /// Logger.
        /// </summary>
        protected ILoggingManager logger { get; private set; }
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="GeneralLiabilityService"/> class.
        /// </summary>
        public GeneralLiabilityServiceWrapper(IConfiguration configuration, ILoggingManager logger)
        {
            this.logger = logger;
            this.configuration = configuration;
        }

        public FluentValidation.Results.ValidationResult ExecuteGeneralLiabilityEngine(RaterFacadeModel raterFacadeModel)
        {
            IGeneralLiabilityService service;

            service = new GeneralLiabilityService(this.configuration, this.logger);

            // Prevalidate   //TODO : Open this prevalidations.
            var preValidateResults = service.PreValidate(raterFacadeModel);

            if (!preValidateResults.IsValid) return preValidateResults;

            // Since input pre validation are success, calculate premium
            service.Calculate(raterFacadeModel);

            //Post validate
            var postValidateResults = service.PostValidate(raterFacadeModel);

            return postValidateResults;
        }

    }
}
