﻿using Models;
using Models.ApiModels;

namespace RaterGeneralLiability
{
    public interface IGeneralLiabilityService
    {
        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model);

        void Calculate(RaterFacadeModel model);

        void CalculateBasePremium(RaterFacadeModel model);

        void CalculateDamageToPremisesPremium(RaterFacadeModel model);

        void CalculateMedicalPaymentsPremium(RaterFacadeModel model);

        void CalculateEmployeeBenefitsPremium(RaterFacadeModel model);

        void CalculateDataCompromisePremium(RaterFacadeModel model);

        void CalculateCyberPremium(RaterFacadeModel model);

        void CalculateUnmannedAircraftTotalPremium(RaterFacadeModel model);

        void CalculateOptionalCoveragePremium(RaterFacadeModel model);

        void CalculateNonModifiedPremium(RaterFacadeModel model);

        void CalculateModifiablePremium(RaterFacadeModel model);

        void CalculateManualPremium(RaterFacadeModel model);

        void CalculateTierPremium(RaterFacadeModel model);

        void CalculateIRPMPremium(RaterFacadeModel model);

        void CalculateOtherModPremium(RaterFacadeModel model);

        void CalculateTerrorismPremium(RaterFacadeModel model);

        void CalculateFinalModifiedPremium(RaterFacadeModel model);

        void CalculateTotalUnmodifiedWithoutExcessPremium(RaterFacadeModel model);

    }
}
