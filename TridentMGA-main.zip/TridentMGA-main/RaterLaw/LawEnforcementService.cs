﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.LawEnforcement.Output;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Validations;

namespace RaterLawEnforcement
{
    public class LawEnforcementService : ILawEnforcementService
    {
        private LawDataAccess _LawDataAccess { get; set; }
        protected ILoggingManager _Logger { get; private set; }
        protected IConfiguration _Configuration { get; private set; }

        int LiabilityLimitRangeForExcessExposure = 1000000;

        // ProRatafactor
        decimal _proRataFactor = 1.000M;

        // MinimumPremium
        int _minimumPremium = 0;

        /// <summary>
        /// LawEnforcementService
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public LawEnforcementService(IConfiguration configuration, ILoggingManager logger)
        {
            this._Configuration = configuration;
            this._Logger = logger;
            this._LawDataAccess = new LawDataAccess(configuration, logger);
        }

        /// <summary>
        /// ExecuteDomainRules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        /// <summary>
        /// PreValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("LawEnforcementService.PreValidate :: Started");

                var validator = new LawPreValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);

                this._Logger.Info("LawEnforcementService.PreValidate :: Completed");

                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("LawEnforcementService.PreValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// PostValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("LawEnforcementService.PostValidate :: Started");

                var validator = new LawPostValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);

                this._Logger.Info("LawEnforcementService.PostValidate :: Completed");

                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("LawEnforcementService.PostValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region Law Enforcement Calculation

        /// <summary>
        /// Calculate
        /// </summary>
        /// <param name="model"></param>
        public void Calculate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("LawEnforcementService.Calculate :: Started");

                #region Step 1-16 InitialRates calculation

                CalculateInitialRates(model);

                #endregion

                #region Step 17 Unmanned Aircraft Total Premium

                CalculateUnmannedAircraftPremium(model);

                #endregion

                #region Optional Coverage

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel != null)
                {
                    CalculateOptionalCoverage(model);
                }

                #endregion

                #region Base Premium

                CalculateBasePremium(model);

                #endregion              

                #region Other Premium

                CalculateOtherPremium(model);

                #endregion

                this._Logger.Info("LawEnforcementService.Calculate :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("LawEnforcementService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateInitialRates
        /// </summary>
        /// <param name="model"></param>
        private void CalculateInitialRates(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("LawEnforcementService.CalculateInitialRates :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                policyHeaderModel.State = policyHeaderModel.State.ToUpper();
                policyHeaderModel.PrimaryClass = policyHeaderModel.PrimaryClass.ToUpper();
                policyHeaderModel.TransactionType = policyHeaderModel.TransactionType.ToUpper();

                //step 1 
                //inputProperty.Officer 
                //Rating Basis - Per Officer1
                outputProperty.RatingBasis = "Per Officer";

                // Step 2
                if ((policyHeaderModel.State == StateCodeConstant.MO || policyHeaderModel.State == StateCodeConstant.NY) || inputProperty.ExposureRate < 0)
                {
                    outputProperty.ExposureRate = this._LawDataAccess.GetProfLinesExposureRate(policyHeaderModel.State,
                                                                                               policyHeaderModel.PrimaryClass,
                                                                                               inputProperty.LineOfBusiness,
                                                                                               policyHeaderModel.PolicyEffectiveDate,
                                                                                               policyHeaderModel.PolicyExpirationDate);
                }
                else
                {
                    outputProperty.ExposureRate = inputProperty.ExposureRate;
                }

                // step 3
                string[] stateCodes = new string[21] { "AL", "CO", "CT", "DE", "GA", "IL", "IN", "MA", "ME", "MI", "MN", "MS", "NC", "NH", "OH", "PA", "SC", "TX", "UT", "VT", "WY" };

                if ((policyHeaderModel.State == StateCodeConstant.MO || policyHeaderModel.State == StateCodeConstant.KS || policyHeaderModel.State == StateCodeConstant.NY)
                    || (inputProperty.LiabilityLimitRate < 0 && stateCodes.Contains(policyHeaderModel.State)))
                {
                    //state, string primaryClass, string lineOfBusiness, DateTime policyEffectiveDate, DateTime PolicyExpirationDate
                    outputProperty.LiabilityLimitRate = this._LawDataAccess.GetProfLinesLiabilityLimitRate(policyHeaderModel.State,
                                                                                                           inputProperty.LineOfBusiness,
                                                                                                           inputProperty.LiabilityLimit,
                                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                                           policyHeaderModel.PolicyExpirationDate);
                }
                else if (stateCodes.Contains(policyHeaderModel.State))
                {
                    outputProperty.LiabilityLimitRate = inputProperty.LiabilityLimitRate;
                }

                // step 4
                outputProperty.AggregateLimitRate = this._LawDataAccess.GetProfLinesAggregateLimitRate(policyHeaderModel.State,
                                                                                                       inputProperty.LineOfBusiness,
                                                                                                       inputProperty.LiabilityLimit,
                                                                                                       inputProperty.AggregateLimit,
                                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                                       policyHeaderModel.PolicyExpirationDate);

                // step 5
                outputProperty.RetentionRate = this._LawDataAccess.GetProfLinesRetentionRate(policyHeaderModel.State,
                                                                                             inputProperty.LineOfBusiness,
                                                                                             inputProperty.Deductible_SIR,
                                                                                             inputProperty.Retention,
                                                                                             policyHeaderModel.PolicyEffectiveDate,
                                                                                             policyHeaderModel.PolicyExpirationDate);

                // step 6
                outputProperty.PopulationRate = this._LawDataAccess.GetProfLinesPopulationRate(policyHeaderModel.State,
                                                                                               policyHeaderModel.PrimaryClass,
                                                                                               inputProperty.LineOfBusiness,
                                                                                               policyHeaderModel.PopulationADA,
                                                                                               policyHeaderModel.PolicyEffectiveDate,
                                                                                               policyHeaderModel.PolicyExpirationDate);

                // step 7
                outputProperty.LocationRate = this._LawDataAccess.GetProfLinesLocationRate(policyHeaderModel.State,
                                                                                           inputProperty.LineOfBusiness,
                                                                                           policyHeaderModel.LocationType,
                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                           policyHeaderModel.PolicyExpirationDate);

                //mstep 8
                outputProperty.PolicyTypeRate = this._LawDataAccess.GetProfLinesPolicyTypeRate(policyHeaderModel.State,
                                                                                               inputProperty.LineOfBusiness,
                                                                                               inputProperty.PolicyType,
                                                                                               policyHeaderModel.PolicyEffectiveDate,
                                                                                               policyHeaderModel.PolicyExpirationDate);

                decimal yearFrac = this.YearFrac(inputProperty.RetroActiveDate, policyHeaderModel.PolicyEffectiveDate);

                outputProperty.RetroYear = (int)Math.Round(yearFrac, 0);

                if (inputProperty.PolicyType.ToUpper() == "CLAIMS MADE")
                {
                    // step 9
                    // When Policy Type = Claims Made
                    // Refer to the lookup table "Trident.CMPolicyYear" to get the Factor from column "CM Factor" using following input parameters.
                    // State Code, LOB code, Effective Date, Expiration Date, Years In CM Program
                    // When Policy Type = Occurence Years In CM Rate should be defaulted to 1.000
                    outputProperty.YearsInCMRate = this._LawDataAccess.GetProfLinesCMPolicyYearRate(policyHeaderModel.State,
                                                                                                    inputProperty.LineOfBusiness,
                                                                                                    inputProperty.YearsinCMProgram,
                                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                                    policyHeaderModel.PolicyExpirationDate);

                    //step 10 
                    //When Policy Type = Claims Made, calculate the Retro Date Factor
                    //Step 1 - Calculate the RetroYear by using formula "ROUNDDOWN(YearFrac(Policy Effective Date, Retro Active Date, 1)0)
                    //Step 2 - Read table "Trident.RetroDateFactor" to get the Retro Factor from column"Factor" using following input parameters: State Code, LOB Code, Effective Date, Expiration Date & RetroYear
                    //Note - If the Retro Year is greater than 6 Pass the value '>6' to the table
                    //When Policy Type = Occurrence Apply 1.00 as the Retro Date rate 
                    string stringRetroYear = string.Empty;

                    if (outputProperty.RetroYear <= 6)
                    {
                        stringRetroYear = outputProperty.RetroYear.ToString();
                    }
                    else
                    {
                        stringRetroYear = ">6";
                    }

                    outputProperty.RetroDateRate = this._LawDataAccess.GetProfLinesRetroDateRate(policyHeaderModel.State,
                                                                                                 inputProperty.LineOfBusiness,
                                                                                                 stringRetroYear,
                                                                                                 policyHeaderModel.PolicyEffectiveDate,
                                                                                                 policyHeaderModel.PolicyExpirationDate);
                }
                else if (inputProperty.PolicyType.ToUpper() == "OCCURRENCE")
                {
                    outputProperty.YearsInCMRate = 1;
                    outputProperty.RetroDateRate = 1;
                }

                // step 12 ProRataFactor
                _proRataFactor = 1.000M;

                // step 13
                //Terrorism Factor doesn't apply.
                outputProperty.TerrorismRate = 0;

                //When State = CT, DE, ME, MA, NH, VT
                string[] stateCheckCode1 = new string[6] { "CT", "DE", "ME", "MA", "NH", "VT" };

                //When State = AL, CO, GA, KS, MI. MN, MS, MO, NC, IL, IN, OH, PA, SC, TX, UT, WY, NY
                string[] stateCheckCode2 = new string[18] { "AL", "CO", "GA", "KS", "MI", "MN", "MS", "MO", "NC", "IL", "IN", "OH", "PA", "SC", "TX", "UT", "WY", "NY" };

                if (stateCheckCode1.Contains(policyHeaderModel.State))
                {
                    //step 11
                    outputProperty.LossExperienceRate = this._LawDataAccess.GetProfLinesLossExperienceRate(policyHeaderModel.State,
                                                                                                           inputProperty.LineOfBusiness,
                                                                                                           inputProperty.ExperienceFactor,
                                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                                           policyHeaderModel.PolicyExpirationDate);

                    //step 14
                    outputProperty.TierRate = this._LawDataAccess.GetProfLinesTierRate(policyHeaderModel.State,
                                                                                       inputProperty.LineOfBusiness,
                                                                                       model.RaterInputFacadeModel.PricingInputModel.TierPlan,
                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                       policyHeaderModel.PolicyExpirationDate);
                }
                else if (stateCheckCode2.Contains(policyHeaderModel.State))
                {
                    //step 11
                    outputProperty.LossExperienceRate = this._LawDataAccess.GetProfLinesLossExperienceRate(policyHeaderModel.State,
                                                                                                           inputProperty.LineOfBusiness,
                                                                                                           null,
                                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                                           policyHeaderModel.PolicyExpirationDate);

                    //step 14
                    outputProperty.TierRate = this._LawDataAccess.GetProfLinesTierRate(policyHeaderModel.State,
                                                                                       inputProperty.LineOfBusiness,
                                                                                       null,
                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                       policyHeaderModel.PolicyExpirationDate);
                }

                // step 15
                outputProperty.IRPMRate = inputProperty.IRPMRate;

                // step 16
                outputProperty.OtherModRate = inputProperty.OtherModRate;

                this._Logger.Info("LawEnforcementService.CalculateInitialRates :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("LawEnforcementService.CalculateInitialRates :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateUnmannedAircraftPremium
        /// </summary>
        /// <param name="model"></param>
        private void CalculateUnmannedAircraftPremium(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("LawEnforcementService.CalculateUnmannedAircraftPremium :: Completed");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                outputProperty.UnmannedAircraftCoverageIncludedInExcessExposure = inputProperty.UnmannedAircraftCoverageIncludedInExcessExposure;

                if (!string.IsNullOrEmpty(inputProperty.UnmannedAircraftOption) && inputProperty.UnmannedAircraftOption.ToUpper() == "EXCLUDE - LE103")
                {
                    outputProperty.UnmannedAircraftModifiedTotalPremium = 0;
                    outputProperty.UnmannedAircraftUnModifiedTotalPremium = 0;
                }
                else
                {
                    // step 17.1
                    outputProperty.UnmannedAircraftAggregateLimitRate = this._LawDataAccess.GetProfLinesUnmannedAircraftFactor(policyHeaderModel.State,
                                                                                                                               inputProperty.LineOfBusiness,
                                                                                                                               inputProperty.UnmannedAircraftOption,
                                                                                                                               inputProperty.UnmannedAircraftAggregateLimit,
                                                                                                                               policyHeaderModel.PolicyEffectiveDate,
                                                                                                                               policyHeaderModel.PolicyExpirationDate);

                    outputProperty.UnmannedAircraftAggregateLimitRate = Math.Round(outputProperty.UnmannedAircraftAggregateLimitRate, 3);

                    #region "Unmanned Aircraft 15 lbs or Less" Premium Calculation

                    string[] stateCodeUnmannedAircraft1 = new string[3] { "CT", "MS", "MO" };

                    string[] stateCodeUnmannedAircraft2 = new string[21] { "AL", "CO", "GA", "KS", "DE", "ME", "MA", "MI", "MN", "IL", "IN", "OH", "NC", "NH", "NY", "PA", "SC", "TX", "UT", "VT", "WY" };

                    if (stateCodeUnmannedAircraft1.Contains(policyHeaderModel.State))
                    {
                        // step 17.2
                        outputProperty.UnmannedAircraftCoverage15lbsorLessRate = this._LawDataAccess.GetProfLinesUnmannedAircraftBaseRateFactor(policyHeaderModel.State,
                                                                                                                                                inputProperty.LineOfBusiness,
                                                                                                                                                inputProperty.UnmannedAircraftOption,
                                                                                                                                                15,
                                                                                                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                policyHeaderModel.PolicyExpirationDate);
                        
                        outputProperty.UnmannedAircraftCoverage15lbsorLessRate = Math.Round(outputProperty.UnmannedAircraftCoverage15lbsorLessRate, 3);
                        // step 17.5
                        outputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate = this._LawDataAccess.GetProfLinesUnmannedAircraftBaseRateFactor(policyHeaderModel.State,
                                                                                                                                                     inputProperty.LineOfBusiness,
                                                                                                                                                     inputProperty.UnmannedAircraftOption,
                                                                                                                                                     1555,
                                                                                                                                                     policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                     policyHeaderModel.PolicyExpirationDate);

                        outputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate = Math.Round(outputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate, 3);
                        // step 17.8
                        outputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate = this._LawDataAccess.GetProfLinesUnmannedAircraftBaseRateFactor(policyHeaderModel.State,
                                                                                                                                                    inputProperty.LineOfBusiness,
                                                                                                                                                    inputProperty.UnmannedAircraftOption,
                                                                                                                                                    55,
                                                                                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                    policyHeaderModel.PolicyExpirationDate);
                    }
                    else if (stateCodeUnmannedAircraft2.Contains(policyHeaderModel.State))
                    {
                        // step 17.2
                        outputProperty.UnmannedAircraftCoverage15lbsorLessRate = inputProperty.UnmannedAircraftCoverage15lbsorLessRate;

                        if (inputProperty.UnmannedAircraftCoverage15lbsorLessRate < 0)
                        {

                            outputProperty.UnmannedAircraftCoverage15lbsorLessRate = this._LawDataAccess.GetProfLinesUnmannedAircraftBaseRateFactor(policyHeaderModel.State,
                                                                                                                                                    inputProperty.LineOfBusiness,
                                                                                                                                                    inputProperty.UnmannedAircraftOption,
                                                                                                                                                    15,
                                                                                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                    policyHeaderModel.PolicyExpirationDate);
                        }

                        // step 17.5
                        outputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate = inputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate;

                        if (inputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate < 0)
                        {
                            outputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate = this._LawDataAccess.GetProfLinesUnmannedAircraftBaseRateFactor(policyHeaderModel.State,
                                                                                                                                                         inputProperty.LineOfBusiness,
                                                                                                                                                         inputProperty.UnmannedAircraftOption,
                                                                                                                                                         1555,
                                                                                                                                                         policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                         policyHeaderModel.PolicyExpirationDate);
                        }

                        // step 17.8
                        outputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate = inputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate;

                        if (inputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate < 0)
                        {
                            // step 17.8
                            outputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate = this._LawDataAccess.GetProfLinesUnmannedAircraftBaseRateFactor(policyHeaderModel.State,
                                                                                                                                                      inputProperty.LineOfBusiness,
                                                                                                                                                      inputProperty.UnmannedAircraftOption,
                                                                                                                                                      55,
                                                                                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                      policyHeaderModel.PolicyExpirationDate);
                        }
                        outputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate = Math.Round(outputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate, 3);
                    }

                    // step 17.4
                    outputProperty.UnmannedAircraftCoverage15lbsorLessPremium = Convert.ToInt32(Math.Round((outputProperty.UnmannedAircraftAggregateLimitRate
                                                                                                          * outputProperty.UnmannedAircraftCoverage15lbsorLessRate
                                                                                                          * inputProperty.UnmannedAircraftCoverage15lbsorLessTotalUnits)
                                                                                                          , 0
                                                                                                          , MidpointRounding.AwayFromZero));

                    // step 17.7
                    outputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsPremium = Convert.ToInt32(Math.Round((outputProperty.UnmannedAircraftAggregateLimitRate
                                                                                                               * outputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate
                                                                                                               * inputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsTotalUnits)
                                                                                                               , 0
                                                                                                               , MidpointRounding.AwayFromZero));
                   
                    // step 17.10
                    outputProperty.UnmannedAircraftCoverage_gteq55lbsPremium = Convert.ToInt32(Math.Round((outputProperty.UnmannedAircraftAggregateLimitRate
                                                                                                         * outputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate
                                                                                                         * inputProperty.UnmannedAircraftCoverage_gteq55lbsTotalUnits)
                                                                                                         , 0
                                                                                                         , MidpointRounding.AwayFromZero));

                    // step 17.11
                    outputProperty.UnmannedAircraftTotalUnits = inputProperty.UnmannedAircraftCoverage15lbsorLessTotalUnits
                                                              + inputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsTotalUnits
                                                              + inputProperty.UnmannedAircraftCoverage_gteq55lbsTotalUnits;

                    // step 17.12
                    outputProperty.UnmannedAircraftUnModifiedWithoutExcessTotalPremium = Convert.ToInt32(Math.Round(((outputProperty.UnmannedAircraftCoverage15lbsorLessPremium
                                                                                                                    + outputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsPremium
                                                                                                                    + outputProperty.UnmannedAircraftCoverage_gteq55lbsPremium)
                                                                                                                    * _proRataFactor)
                                                                                                                    , 0
                                                                                                                    , MidpointRounding.AwayFromZero));

                    // to get UnmannedAircraft
                    var UnmannedAircraftMinimumPremium = Convert.ToInt32(this._LawDataAccess.GetProfLinesUnmannedAircraftPremium(policyHeaderModel.State,
                                                                                                                                 inputProperty.LineOfBusiness,
                                                                                                                                 inputProperty.UnmannedAircraftOption,
                                                                                                                                 policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                 policyHeaderModel.PolicyExpirationDate));

                    if (outputProperty.UnmannedAircraftUnModifiedWithoutExcessTotalPremium < UnmannedAircraftMinimumPremium)
                    {
                        outputProperty.UnmannedAircraftUnModifiedWithoutExcessTotalPremium = UnmannedAircraftMinimumPremium;
                    }

                    outputProperty.UnmannedAircraftUnModifiedTotalPremium = outputProperty.UnmannedAircraftUnModifiedWithoutExcessTotalPremium;

                    outputProperty.UnmannedAircraftCoverageIncludedInExcessExposure = inputProperty.UnmannedAircraftCoverageIncludedInExcessExposure;

                    // step 17.13
                    if (string.IsNullOrEmpty(inputProperty.UnmannedAircraftCoverageIncludedInExcessExposure))
                    {
                        outputProperty.UnmannedAircraftCoverageIncludedInExcessExposure = this._LawDataAccess.GetProfLinesExcessExposure(policyHeaderModel.State,
                                                                                                                                         policyHeaderModel.PrimaryClass,
                                                                                                                                         inputProperty.UnmannedAircraftOption,
                                                                                                                                         inputProperty.LineOfBusiness,
                                                                                                                                         policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                         policyHeaderModel.PolicyExpirationDate);
                    }

                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess == true && inputProperty.LiabilityLimit == LiabilityLimitRangeForExcessExposure)
                    {
                        // step 17.14
                        if (!string.IsNullOrEmpty(outputProperty.UnmannedAircraftCoverageIncludedInExcessExposure) && outputProperty.UnmannedAircraftCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputProperty.UnmannedAircraftUnModifiedTotalPremium = 0;
                        }
                    }

                    // step 17.15
                    outputProperty.UnmannedAircraftModifiedTotalPremium = Convert.ToInt32(Math.Round((outputProperty.UnmannedAircraftUnModifiedTotalPremium
                                                                                                    * outputProperty.TierRate
                                                                                                    * outputProperty.IRPMRate
                                                                                                    * outputProperty.OtherModRate)
                                                                                                    , 0
                                                                                                    , MidpointRounding.AwayFromZero));

                    #endregion

                }

                this._Logger.Info("LawEnforcementService.CalculateUnmannedAircraftPremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("LawEnforcementService.CalculateUnmannedAircraftPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateOptionalCoverage
        /// </summary>
        /// <param name="model"></param>
        public void CalculateOptionalCoverage(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("LawEnforcementService.CalculateOptionalCoverage :: Started");

                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;
                var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
                var inputOptionalCoverageModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel;
                var outputOptionalCoverageModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel;
                var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                if (policyHeaderModel.State != StateCodeConstant.NY)
                {
                    #region Optional Coverage I Additional Insured - Law Enforcement Agencies - AG LE 0006

                    if (inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIsSelected)
                    {
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIsSelected = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIsSelected;
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedinExcessExposure = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedInExcessExposure;
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesLimit = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesLimit;
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesAggregateLimit = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesAggregateLimit;
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesDeductible = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesDeductible;
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesRatingBasis = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesRatingBasis;
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesReturnMethod = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesReturnMethod;
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesRate = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesRate;
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesModifiedPremium = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesModifiedPremium;

                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedWithoutExcessPremium = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium;

                        if (policyHeaderModel.TransactionType == "CANCELLATION")
                        {
                            // step 1 
                            outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium = 0;
                        }

                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium = outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedWithoutExcessPremium;
                        outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedinExcessExposure = inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedInExcessExposure;
                       
                        //step 2
                        if (string.IsNullOrEmpty(inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedInExcessExposure))
                        {
                            outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedinExcessExposure = this._LawDataAccess.GetProfLinesExcessExposure(policyHeaderModel.State,
                                                                                                                                                                                 policyHeaderModel.PrimaryClass,
                                                                                                                                                                                 inputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedInExcessExposure,
                                                                                                                                                                                 inputModel.LineOfBusiness,
                                                                                                                                                                                 policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                                 policyHeaderModel.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess == true && inputModel.LiabilityLimit == LiabilityLimitRangeForExcessExposure)
                        {
                            // step 3
                            if (!string.IsNullOrEmpty(outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedinExcessExposure) && outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedinExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium = 0;
                            }
                        }
                    }

                    #endregion

                    #region Optional Coverage II - Suppl.Extended Reporting Period

                    if (inputOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected && policyHeaderModel.TransactionType == TransactionTypeConstant.ENDORSEMENT)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected = inputOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected;
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit = inputOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit;
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodDeductible = inputOptionalCoverageModel.SupplExtendedReportingPeriodDeductible;
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis = inputOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis;
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod = inputOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod;
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium = inputOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium;
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure = inputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure;

                        // step 1
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodLimit = inputOptionalCoverageModel.SupplExtendedReportingPeriodLimit;

                        // step 2
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodRate = this._LawDataAccess.GetProfLinesOptionalCoverageRate(policyHeaderModel.State,
                                                                                                                                            policyHeaderModel.PrimaryClass,
                                                                                                                                            inputModel.LineOfBusiness,
                                                                                                                                            "Suppl. Extended Reporting Period",
                                                                                                                                            inputOptionalCoverageModel.SupplExtendedReportingPeriodLimit,
                                                                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                            policyHeaderModel.PolicyExpirationDate);

                        //TODO It will be done latter.
                        decimal annualizedFinalLawEnforcementPremiumOfLastBoundTransction = 0;
                        // step 3
                        outputOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((outputOptionalCoverageModel.SupplExtendedReportingPeriodRate
                                                                                                                                           * annualizedFinalLawEnforcementPremiumOfLastBoundTransction)
                                                                                                                                           , 0
                                                                                                                                           , MidpointRounding.AwayFromZero));

                        outputOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium = outputOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium;

                        //step 4
                        if (string.IsNullOrEmpty(inputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure))
                        {
                            outputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure = this._LawDataAccess.GetProfLinesExcessExposure(policyHeaderModel.State,
                                                                                                                                                              policyHeaderModel.PrimaryClass,
                                                                                                                                                              "Suppl. Extended Reporting Period",
                                                                                                                                                              inputModel.LineOfBusiness,
                                                                                                                                                              policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                              policyHeaderModel.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess == true && inputModel.LiabilityLimit == LiabilityLimitRangeForExcessExposure)
                        {
                            // step 5
                            if (!string.IsNullOrEmpty(outputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure) && outputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
                            }
                        }
                    }

                    #endregion

                    #region Optional Coverage IV -  Non Monetary Defense

                    if (policyHeaderModel.State != StateCodeConstant.DE && (policyHeaderModel.PrimaryClass == PrimaryClassConstant.SC || policyHeaderModel.PrimaryClass == PrimaryClassConstant.MSC))
                    {
                        if (inputOptionalCoverageModel.NonMonetaryDefenseIsSelected)
                        {
                            //Output Json Variable are Assigned by input Json
                            outputOptionalCoverageModel.NonMonetaryDefenseIsSelected = inputOptionalCoverageModel.NonMonetaryDefenseIsSelected;
                            outputOptionalCoverageModel.NonMonetaryDefenseDeductible = inputOptionalCoverageModel.NonMonetaryDefenseDeductible;
                            outputOptionalCoverageModel.NonMonetaryDefenseRatingBasis = inputOptionalCoverageModel.NonMonetaryDefenseRatingBasis;
                            outputOptionalCoverageModel.NonMonetaryDefenseReturnMethod = inputOptionalCoverageModel.NonMonetaryDefenseReturnMethod;
                            outputOptionalCoverageModel.NonMonetaryDefenseRate = inputOptionalCoverageModel.NonMonetaryDefenseRate;
                            outputOptionalCoverageModel.NonMonetaryDefenseModifiedPremium = inputOptionalCoverageModel.NonMonetaryDefenseModifiedPremium;
                            outputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure = inputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure;

                            // step 1
                            outputOptionalCoverageModel.NonMonetaryDefenseLimit = inputOptionalCoverageModel.NonMonetaryDefenseLimit;

                            // step 2
                            outputOptionalCoverageModel.NonMonetaryDefenseAggregateLimit = inputOptionalCoverageModel.NonMonetaryDefenseAggregateLimit;

                            var nonMonetaryDefenseUnmodifiedPremium = this._LawDataAccess.GetProfLinesOptionalCoveragePremium(policyHeaderModel.State,
                                                                                                                              policyHeaderModel.PrimaryClass,
                                                                                                                              inputModel.LineOfBusiness,
                                                                                                                              "Non-Monetary Defense",
                                                                                                                              inputOptionalCoverageModel.NonMonetaryDefenseLimit,
                                                                                                                              inputOptionalCoverageModel.NonMonetaryDefenseAggregateLimit,
                                                                                                                              policyHeaderModel.PolicyEffectiveDate,
                                                                                                                              policyHeaderModel.PolicyExpirationDate);

                            // step 3
                            outputOptionalCoverageModel.NonMonetaryDefenseUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((nonMonetaryDefenseUnmodifiedPremium
                                                                                                                                     * _proRataFactor)
                                                                                                                                     , 0
                                                                                                                                     , MidpointRounding.AwayFromZero));

                            outputOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium = outputOptionalCoverageModel.NonMonetaryDefenseUnmodifiedWithoutExcessPremium;
                           
                            //step 4                              
                            if (string.IsNullOrEmpty(inputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure))
                            {
                                outputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure = this._LawDataAccess.GetProfLinesExcessExposure(policyHeaderModel.State,
                                                                                                                                                        policyHeaderModel.PrimaryClass,
                                                                                                                                                        "Non-Monetary Defense",
                                                                                                                                                        inputModel.LineOfBusiness,
                                                                                                                                                        policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                        policyHeaderModel.PolicyExpirationDate);
                            }

                            if (model.RaterInputFacadeModel.LineOfBusiness.Excess == true && inputModel.LiabilityLimit == LiabilityLimitRangeForExcessExposure)
                            {                                
                                // step 5
                                if (!string.IsNullOrEmpty(outputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure) && outputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure.ToUpper() == "TRUE")
                                {
                                    outputOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium = 0;
                                }
                            }
                        }
                    }

                    #endregion

                    #region Optional Coverage V - Line of Duty Death Benefits

                    if (inputOptionalCoverageModel.LineOfDutyDeathBenefitsIsSelected)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsIsSelected = inputOptionalCoverageModel.LineOfDutyDeathBenefitsIsSelected;
                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsDeductible = inputOptionalCoverageModel.LineOfDutyDeathBenefitsDeductible;
                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsRatingBasis = inputOptionalCoverageModel.LineOfDutyDeathBenefitsRatingBasis;
                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsReturnMethod = inputOptionalCoverageModel.LineOfDutyDeathBenefitsReturnMethod;
                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsRate = inputOptionalCoverageModel.LineOfDutyDeathBenefitsRate;
                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsModifiedPremium = inputOptionalCoverageModel.LineOfDutyDeathBenefitsModifiedPremium;
                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsIncludedInExcessExposure = inputOptionalCoverageModel.LineOfDutyDeathBenefitsIncludedInExcessExposure;

                        // step 1
                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsLimit = inputOptionalCoverageModel.LineOfDutyDeathBenefitsLimit;

                        // step 2
                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsAggregateLimit = inputOptionalCoverageModel.LineOfDutyDeathBenefitsAggregateLimit;

                        // step 3
                        var lineOfDutyUnmodifiedPremium = this._LawDataAccess.GetProfLinesOptionalCoveragePremium(policyHeaderModel.State,
                                                                                                                  policyHeaderModel.PrimaryClass,
                                                                                                                  inputModel.LineOfBusiness,
                                                                                                                  "Line of Duty Death Benefits",
                                                                                                                  inputOptionalCoverageModel.LineOfDutyDeathBenefitsLimit,
                                                                                                                  inputOptionalCoverageModel.LineOfDutyDeathBenefitsAggregateLimit,
                                                                                                                  policyHeaderModel.PolicyEffectiveDate,
                                                                                                                  policyHeaderModel.PolicyExpirationDate);

                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((lineOfDutyUnmodifiedPremium
                                                                                                                                      * _proRataFactor)
                                                                                                                                      , 0
                                                                                                                                      , MidpointRounding.AwayFromZero));

                        outputOptionalCoverageModel.LineOfDutyDeathBenefitsUnmodifiedPremium = outputOptionalCoverageModel.LineOfDutyDeathBenefitsUnmodifiedWithoutExcessPremium;

                        //step 4
                        if (string.IsNullOrEmpty(inputOptionalCoverageModel.LineOfDutyDeathBenefitsIncludedInExcessExposure))
                        {
                            outputOptionalCoverageModel.LineOfDutyDeathBenefitsIncludedInExcessExposure = this._LawDataAccess.GetProfLinesExcessExposure(policyHeaderModel.State,
                                                                                                                                                         policyHeaderModel.PrimaryClass,
                                                                                                                                                         "Line of Duty Death Benefits",
                                                                                                                                                         inputModel.LineOfBusiness,
                                                                                                                                                         policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                         policyHeaderModel.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess == true && inputModel.LiabilityLimit == LiabilityLimitRangeForExcessExposure)
                        {
                            // step 5
                            if (!string.IsNullOrEmpty(outputOptionalCoverageModel.LineOfDutyDeathBenefitsIncludedInExcessExposure) && outputOptionalCoverageModel.LineOfDutyDeathBenefitsIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalCoverageModel.LineOfDutyDeathBenefitsUnmodifiedPremium = 0;
                            }
                        }
                    }

                    #endregion
                }
                else
                {
                    #region Optional Coverage III - NY-Suppl. Extended Reporting Period 

                    if (inputOptionalCoverageModel.NYSupplExtendedReportingPeriodIsSelected && policyHeaderModel.TransactionType == TransactionTypeConstant.ENDORSEMENT)
                    {
                        //Output Json Variable are Assigned by input Json
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodIsSelected = inputOptionalCoverageModel.NYSupplExtendedReportingPeriodIsSelected;
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodAggregateLimit = inputOptionalCoverageModel.NYSupplExtendedReportingPeriodAggregateLimit;
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodDeductible = inputOptionalCoverageModel.NYSupplExtendedReportingPeriodDeductible;
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodRatingBasis = inputOptionalCoverageModel.NYSupplExtendedReportingPeriodRatingBasis;
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodReturnMethod = inputOptionalCoverageModel.NYSupplExtendedReportingPeriodReturnMethod;
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodModifiedPremium = inputOptionalCoverageModel.NYSupplExtendedReportingPeriodModifiedPremium;
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodIncludedInExcessExposure = inputOptionalCoverageModel.NYSupplExtendedReportingPeriodIncludedInExcessExposure;

                        // step 1
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodLimit = inputOptionalCoverageModel.NYSupplExtendedReportingPeriodLimit;

                        // step 2
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodRate = this._LawDataAccess.GetProfLinesOptionalCoverageRate(policyHeaderModel.State,
                                                                                                                                              policyHeaderModel.PrimaryClass,
                                                                                                                                              inputModel.LineOfBusiness,
                                                                                                                                              "Suppl. Extended Reporting Period Limit",
                                                                                                                                              inputOptionalCoverageModel.NYSupplExtendedReportingPeriodLimit,
                                                                                                                                              policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                              policyHeaderModel.PolicyExpirationDate);

                        //TODO It will be done latter.
                        decimal annualizedPremiumOfLastBoundTransction = 0;
                        // step 3
                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((outputOptionalCoverageModel.NYSupplExtendedReportingPeriodRate
                                                                                                                                             * annualizedPremiumOfLastBoundTransction)
                                                                                                                                             , 0
                                                                                                                                             , MidpointRounding.AwayFromZero));

                        outputOptionalCoverageModel.NYSupplExtendedReportingPeriodUnmodifiedPremium = outputOptionalCoverageModel.NYSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium;

                        //step 4
                        if (string.IsNullOrEmpty(inputOptionalCoverageModel.NYSupplExtendedReportingPeriodIncludedInExcessExposure))
                        {
                            outputOptionalCoverageModel.NYSupplExtendedReportingPeriodIncludedInExcessExposure = this._LawDataAccess.GetProfLinesExcessExposure(policyHeaderModel.State,
                                                                                                                                                                policyHeaderModel.PrimaryClass,
                                                                                                                                                                "Suppl. Extended Reporting Period Limit",
                                                                                                                                                                inputModel.LineOfBusiness,
                                                                                                                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                policyHeaderModel.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess == true && inputModel.LiabilityLimit == LiabilityLimitRangeForExcessExposure)
                        {
                            // step 5
                            if (!string.IsNullOrEmpty(outputOptionalCoverageModel.NYSupplExtendedReportingPeriodIncludedInExcessExposure) && outputOptionalCoverageModel.NYSupplExtendedReportingPeriodIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOptionalCoverageModel.NYSupplExtendedReportingPeriodUnmodifiedPremium = 0;
                            }
                        }
                    }

                    #endregion
                }

                #region Optional Coverage VI - Other

                if (inputOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel != null && inputOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel.Count > 0)
                {
                    foreach (var inputOtherCoverage in inputOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel)
                    {
                        LawEnforcementOptionalOtherCoverageOutputModel outputOtherCoverage = new LawEnforcementOptionalOtherCoverageOutputModel();

                        outputOtherCoverage.OtherCoverageID = inputOtherCoverage.OtherCoverageID;
                        outputOtherCoverage.OtherCoverageDescription = inputOtherCoverage.OtherCoverageDescription;
                        outputOtherCoverage.OtherCoverageLimit = inputOtherCoverage.OtherCoverageLimit;
                        outputOtherCoverage.OtherCoverageAggregateLimit = inputOtherCoverage.OtherCoverageAggregateLimit;
                        outputOtherCoverage.OtherCoverageDedcutible = inputOtherCoverage.OtherCoverageDedcutible;
                        outputOtherCoverage.OtherCoverageRate = inputOtherCoverage.OtherCoverageRate;
                        outputOtherCoverage.OtherCoverageRatingBasis = inputOtherCoverage.OtherCoverageRatingBasis;
                        outputOtherCoverage.OtherCoverageReturnMethod = inputOtherCoverage.OtherCoverageReturnMethod;
                        outputOtherCoverage.OtherCoverageModifiedPremium = inputOtherCoverage.OtherCoverageModifiedPremium;
                        outputOtherCoverage.OtherCoverageIncludedInExcessExposure = inputOtherCoverage.OtherCoverageIncludedInExcessExposure;

                        if (inputOtherCoverage.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARGE")
                        {
                            // step 1
                            outputOtherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((inputOtherCoverage.OtherCoverageUnmodifiedPremium
                                                                                                                        * _proRataFactor)
                                                                                                                        , 0
                                                                                                                        , MidpointRounding.AwayFromZero));

                        }
                        else if (inputOtherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                        {
                            // step 1
                            outputOtherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(((inputOtherCoverage.OtherCoverageLimit
                                                                                                                           / 1000)
                                                                                                                           * inputOtherCoverage.OtherCoverageRate
                                                                                                                           * _proRataFactor)
                                                                                                                           , 0
                                                                                                                           , MidpointRounding.AwayFromZero));
                        }
                        else if (inputOtherCoverage.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                        {
                            // step 1
                            outputOtherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(((inputOtherCoverage.OtherCoverageLimit
                                                                                                                           / 100)
                                                                                                                           * inputOtherCoverage.OtherCoverageRate
                                                                                                                           * _proRataFactor)
                                                                                                                           , 0
                                                                                                                           , MidpointRounding.AwayFromZero));


                        }
                        else if (inputOtherCoverage.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                        {
                            // step 1
                            outputOtherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium = 0;
                        }

                        outputOtherCoverage.OtherCoverageUnmodifiedPremium = outputOtherCoverage.OtherCoverageUnmodifiedWithoutExcessPremium;
                        
                        if (string.IsNullOrEmpty(inputOtherCoverage.OtherCoverageIncludedInExcessExposure))
                        {
                            outputOtherCoverage.OtherCoverageIncludedInExcessExposure = this._LawDataAccess.GetProfLinesExcessExposure(policyHeaderModel.State,
                                                                                                                                       policyHeaderModel.PrimaryClass,
                                                                                                                                       "Other",
                                                                                                                                       inputModel.LineOfBusiness,
                                                                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                       policyHeaderModel.PolicyExpirationDate);
                        }

                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess == true && inputModel.LiabilityLimit == LiabilityLimitRangeForExcessExposure)
                        {
                            // step 3
                            if (!string.IsNullOrEmpty(outputOtherCoverage.OtherCoverageIncludedInExcessExposure) && outputOtherCoverage.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                            {
                                outputOtherCoverage.OtherCoverageUnmodifiedPremium = 0;
                            }
                        }

                        outputOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel.Add(outputOtherCoverage);
                    }
                }

                #endregion

                #region Step B - Non-Modified Premium

                // step B.1
                outputModel.NonModifiedPremium = outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium
                                               + outputOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium
                                               + outputOptionalCoverageModel.NYSupplExtendedReportingPeriodUnmodifiedPremium
                                               + outputOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium
                                               + outputOptionalCoverageModel.LineOfDutyDeathBenefitsUnmodifiedPremium;


                if (outputOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel != null)
                {
                    outputModel.NonModifiedPremium = outputModel.NonModifiedPremium
                                                   + outputOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel.Sum(x => x.OtherCoverageUnmodifiedPremium);
                }

                #endregion

                this._Logger.Info("LawEnforcementService.CalculateOptionalCoverage :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("LawEnforcementService.CalculateOptionalCoverage :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateBasePremium
        /// </summary>
        /// <param name="model"></param>
        public void CalculateBasePremium(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("LawEnforcementService.CalculateBasePremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;
                var PolicyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                #region Step A - Base Premium

                //step A.1
                outputProperty.BasePremium = Convert.ToInt32(inputProperty.Officer
                                                           * outputProperty.ExposureRate
                                                           * outputProperty.LiabilityLimitRate
                                                           * outputProperty.AggregateLimitRate
                                                           * outputProperty.RetentionRate
                                                           * outputProperty.PopulationRate
                                                           * outputProperty.LocationRate
                                                           * outputProperty.PolicyTypeRate
                                                           * outputProperty.YearsInCMRate
                                                           * outputProperty.RetroDateRate
                                                           * outputProperty.LossExperienceRate
                                                           * _proRataFactor);

                #endregion`   

                this._Logger.Info("LawEnforcementService.CalculateBasePremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("LawEnforcementService.CalculateBasePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateOtherPremium
        /// </summary>
        /// <param name="model"></param>
        public void CalculateOtherPremium(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("LawEnforcementService.CalculateOtherModPremium :: Started");

                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
                var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;
                var inputOptionalCoverageModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel;
                var outputOptionalCoverageModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel;
                var PolicyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

                // to get MinimumPremium
                this._minimumPremium = Convert.ToInt32(this._LawDataAccess.GetMinimumPremium(PolicyHeaderModel.State,
                                                                                             PolicyHeaderModel.PrimaryClass,
                                                                                             inputProperty.LineOfBusiness,
                                                                                             PolicyHeaderModel.PolicyEffectiveDate,
                                                                                             PolicyHeaderModel.PolicyExpirationDate));
                #region Manual Premium

                //Step C = Step A.1 + Step B.1 + Step 17.12
                //If Calculated Manual Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated Manual Premium by LOB MINIMUM PREMIUM.
                decimal manualPremium = (outputModel.BasePremium
                                       + outputModel.NonModifiedPremium
                                       + outputModel.UnmannedAircraftUnModifiedTotalPremium);

                outputModel.ManualPremium = Convert.ToInt32(manualPremium);

                if (outputModel.ManualPremium < this._minimumPremium)
                {
                    outputModel.ManualPremium = this._minimumPremium;
                }

                #endregion

                #region Tier Premium
                //Step D - Tier Premium Calculation
                //Manual Premium (Step C.1) used in the calculation should be the calculated Manual Premium before applying LOB Minimum Premium condition
                //If Calculated Tier Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated Tier Premium by LOB MINIMUM PREMIUM.                
                //((Step C.1  - Step B.1)  * Step 15 + Step B.1
                decimal tierPremium = Math.Round((((manualPremium                      // before applied lobMinPremium.
                                                  - outputModel.NonModifiedPremium)
                                                  * outputModel.TierRate)
                                                  + outputModel.NonModifiedPremium),
                                                  0,
                                                  MidpointRounding.AwayFromZero);

                outputModel.TierPremium = Convert.ToInt32(tierPremium);

                if (outputModel.TierPremium < this._minimumPremium)
                {
                    outputModel.TierPremium = this._minimumPremium;
                }

                #endregion

                #region IRPM Premium
                //Step E - IRPM Premium Calculation
                //Step E.1 - Get system calculated value
                //((Step D.1  - Step B.1)  * Step 16 + Step B.1
                //Tier Premium (Step D.1) used in the calculation should be the calculated Tier Premium before applying LOB Minimum Premium condition
                //If Calculated IRPM Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated IRPM Premium by LOB MINIMUM PREMIUM.
                var irpmPremium = Math.Round((((tierPremium
                                              - outputModel.NonModifiedPremium)
                                              * outputModel.IRPMRate)
                                              + outputModel.NonModifiedPremium),
                                              0,
                                              MidpointRounding.AwayFromZero);

                outputModel.IRPMPremium = Convert.ToInt32(irpmPremium);

                if (outputModel.IRPMPremium < this._minimumPremium)
                {
                    outputModel.IRPMPremium = this._minimumPremium;
                }

                #endregion

                #region OtherMod Premium
                //Step F - Other Mod Premium Calculation
                //Step F.1 - Get system calculated value
                //((Step E.1  - Step B.1)  * Step 17 + Step B.1
                //IRPM Premium (Step E.1) used in the calculation should be the calculated IRPM Premium before applying LOB Minimum Premium condition
                //If Calculated Other Mod Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated Other Mod Premium by LOB MINIMUM PREMIUM.
                var otherModPremium = Math.Round(((irpmPremium
                                                 - outputModel.NonModifiedPremium)
                                                 * outputModel.OtherModRate
                                                 + outputModel.NonModifiedPremium),
                                                 0,
                                                 MidpointRounding.AwayFromZero);

                outputModel.OtherModPremium = Convert.ToInt32(otherModPremium);

                if (outputModel.OtherModPremium < this._minimumPremium)
                {
                    outputModel.OtherModPremium = this._minimumPremium;
                }

                #endregion

                #region Terrorism Premium
                //Step G - Terrorism Premium Calculation
                //Step G.1 - Get system calculated value
                //Step F.1 * Step 14
                //When Terrorism Accepted Rejected = Accept (1) Calculate Terrorism Premium
                // Else Don't Calculate Terrorism Premium
                if (model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected)
                {
                    outputModel.TerrorismPremium = Convert.ToInt32(Math.Round(outputModel.OtherModPremium
                                                                            * outputModel.TerrorismRate));
                }

                #endregion

                #region LawFinalModified Premium

                //Step H - Final Premium Calculation
                //Step H.1 - Get system calculated value
                //Step F.1 + Step G.1
                //Other Mod Premium (Step F.1) used in the calculation should be the calculated Other Mod Premium before applying LOB Minimum Premium condition
                //If Calculated EP Final Modified Premium is less than the LOB MINIMUM PREMIUM. Then Override the Calculated EP Final Modified Premium by LOB MINIMUM PREMIUM.
                outputModel.LawFinalModifiedPremium = Convert.ToInt32(otherModPremium
                                                                    + outputModel.TerrorismPremium);

                if (outputModel.LawFinalModifiedPremium < this._minimumPremium)
                {
                    outputModel.LawFinalModifiedPremium = this._minimumPremium;
                }

                #endregion

                bool supplExtendedIsSelected = false;
                int supplExtendedUnmodifiedPremium = 0;

                if (inputProperty.LawEnforcementOptionalCoverageModel != null && (inputProperty.LawEnforcementOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected || inputProperty.LawEnforcementOptionalCoverageModel.NYSupplExtendedReportingPeriodIsSelected))
                {
                    supplExtendedIsSelected = true;

                    supplExtendedUnmodifiedPremium = (PolicyHeaderModel.State != StateCodeConstant.NY) ? inputProperty.LawEnforcementOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium : inputProperty.LawEnforcementOptionalCoverageModel.NYSupplExtendedReportingPeriodUnmodifiedPremium;
                }

                if (supplExtendedIsSelected)
                {
                    #region Manual premium

                    //Step C
                    //Note - If Suppl.Extended Reporting Perio Is Selected = 1 Then Apply LOB Minimum Premium condition as mentioned below -
                    //1.Calculated Manual Premium = (Manual Premium - (Suppl.Extended Reporting Period Unmodified Premium))
                    //2.If Calculated Manual Premium in #1 is less than the LOB MINIMUM PREMIUM. Then
                    //Manual Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium

                    outputModel.ManualPremium = (outputModel.BasePremium
                                               - supplExtendedUnmodifiedPremium);

                    if (outputModel.ManualPremium < this._minimumPremium)
                    {
                        outputModel.ManualPremium = this._minimumPremium
                                                  + supplExtendedUnmodifiedPremium;
                    }

                    #endregion

                    #region Tier Premium

                    //Step D
                    //Note - If Suppl.Extended Reporting Period Is Selected = 1 Then Apply LOB Minimum Premium condition as mentioned below -
                    //1.Calculated Tier Premium = (Tier Premium - (Suppl.Extended Reporting Period Unmodified Premium))
                    //2.If Calculated Tier Premium in #1 is less than the LOB MINIMUM PREMIUM. Then
                    //Tier Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium

                    outputModel.TierPremium = (outputModel.TierPremium
                                             - supplExtendedUnmodifiedPremium);

                    if (outputModel.TierPremium < this._minimumPremium)
                    {
                        outputModel.TierPremium = this._minimumPremium
                                                + supplExtendedUnmodifiedPremium;
                    }

                    #endregion

                    #region IRPM Premium

                    //Step E
                    //Note - If Suppl.Extended Reporting Period Is Selected = 1 Then Apply LOB Minimum Premium condition as mentioned below -
                    //1.Calculated IRPM Premium = (IRPM Premium - (Suppl.Extended Reporting Period Unmodified Premium))
                    //2.If Calculated IRPM Premium in #1 is less than the LOB MINIMUM PREMIUM. Then
                    //IRPM Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium
                    outputModel.IRPMPremium = (outputModel.IRPMPremium
                                             - supplExtendedUnmodifiedPremium);

                    if (outputModel.IRPMPremium < this._minimumPremium)
                    {
                        outputModel.IRPMPremium = this._minimumPremium
                                                + supplExtendedUnmodifiedPremium;
                    }

                    #endregion

                    #region OtherMod Premium

                    //Step F
                    //Note - If Suppl.Extended Reporting Period Is Selected = 1, apply LOB Minimum Premium condition as mentioned below -
                    // 1.Calculated Other Mod Premium = (Other Mod Premium -(Suppl.Extended Reporting Period Unmodified Premium))
                    //2.If Calculated Other Mod Premium in #1 is less than the LOB MINIMUM PREMIUM. Then
                    //Other Mod Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium                
                    outputModel.OtherModPremium = outputModel.OtherModPremium
                                                - supplExtendedUnmodifiedPremium;

                    if (outputModel.OtherModPremium < this._minimumPremium)
                    {
                        outputModel.OtherModPremium = this._minimumPremium
                                                    + supplExtendedUnmodifiedPremium;
                    }

                    #endregion

                    #region LawFinalModified Premium
                    //Step H
                    //Note - (If Suppl.Extended Reporting Period optional coverage Is selected = 1), apply LOB Minimum Premium condition as mentioned below -
                    //1.Calculated Final Premium = (Final premium - (Suppl.Extended Reporting Period Unmodified Premium))
                    //2.If Calculated Final Premium calculated in 1# is less than the LOB MINIMUM PREMIUM. Then
                    //EP Final Modified Premium = LOB MINIMUM PREMIUM +Suppl.Extended Reporting Period Unmodified Premium
                    outputModel.LawFinalModifiedPremium = outputModel.LawFinalModifiedPremium
                                                        - supplExtendedUnmodifiedPremium;

                    if (outputModel.LawFinalModifiedPremium < this._minimumPremium)
                    {
                        outputModel.LawFinalModifiedPremium = this._minimumPremium
                                                            + supplExtendedUnmodifiedPremium;
                    }

                    #endregion
                }

                #region Law Total Unmodified Without Excess Premium Calculation

                // step- I.1
                var totalUnmodifiedWithoutExcessPremium = 0M;
                if (outputOptionalCoverageModel != null)
                {
                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedinExcessExposure) && outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIncludedinExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + outputOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedWithoutExcessPremium;
                    }

                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure) && outputOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + outputOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium;
                    }

                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure) && outputOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + outputOptionalCoverageModel.NonMonetaryDefenseUnmodifiedWithoutExcessPremium;
                    }

                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.LineOfDutyDeathBenefitsIncludedInExcessExposure) && outputOptionalCoverageModel.LineOfDutyDeathBenefitsIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + outputOptionalCoverageModel.LineOfDutyDeathBenefitsUnmodifiedWithoutExcessPremium;
                    }

                    if (!string.IsNullOrEmpty(outputOptionalCoverageModel.NYSupplExtendedReportingPeriodIncludedInExcessExposure) && outputOptionalCoverageModel.NYSupplExtendedReportingPeriodIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + outputOptionalCoverageModel.NYSupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium;
                    }

                    ///TODO : How we will know UnmannedAircraft is selected or not ?
                    if (!string.IsNullOrEmpty(outputModel.UnmannedAircraftCoverageIncludedInExcessExposure) && outputModel.UnmannedAircraftCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + outputModel.UnmannedAircraftUnModifiedWithoutExcessTotalPremium;
                    }

                    int othercoverageWithoutExcessPremium = 0;

                    if (outputOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel != null)
                    {
                        othercoverageWithoutExcessPremium = outputOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel.Where(y => !string.IsNullOrEmpty(y.OtherCoverageIncludedInExcessExposure) && y.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE").Sum(x => x.OtherCoverageUnmodifiedWithoutExcessPremium);
                    }

                    totalUnmodifiedWithoutExcessPremium = totalUnmodifiedWithoutExcessPremium + othercoverageWithoutExcessPremium;

                    outputModel.LawTotalUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(totalUnmodifiedWithoutExcessPremium, 0, MidpointRounding.ToZero));
                }
                #endregion

                this._Logger.Info("LawEnforcementService.CalculateOtherModPremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("LawEnforcementService.CalculateOtherModPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #endregion

        #region Get Yearfrac

        /// <summary>
        /// YearFrac
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>decimal</returns>
        public decimal YearFrac(DateTime startDate, DateTime endDate)
        {
            this._Logger.Info("LawEnforcementService.YearFrac :: Starting");
            if (endDate < startDate)
            {
                // throw new ArgumentOutOfRangeException("endDate cannot be less than startDate");
                return 0;
            }
            int endDay = endDate.Day;
            int startDay = startDate.Day;
            switch (startDay)
            {
                case 31:
                    {
                        startDay = 30;
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 30:
                    {
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 29:
                    {
                        if (startDate.Month == 2)
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;

                case 28:
                    {
                        if ((startDate.Month == 2) && (!DateTime.IsLeapYear(startDate.Year)))
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;
            }
            this._Logger.Info("LawEnforcementService.YearFrac :: Completed");
            return (((endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDay - startDay)) / 360);
        }
        #endregion
    }
}
