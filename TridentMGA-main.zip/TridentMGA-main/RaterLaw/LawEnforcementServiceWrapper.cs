﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaterLawEnforcement
{
    public class LawEnforcementServiceWrapper
    {        /// <summary>
             /// Logger.
             /// </summary>
        protected ILoggingManager logger { get; private set; }
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyCwService"/> class.
        /// </summary>
        /// <param name="logger">ILoggingManager.</param>
        public LawEnforcementServiceWrapper(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.logger = logger;
        }

        /// <summary>
        /// ExecuteOcpEngine : It's includes pre validation ,premium calculation , post validation.
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        /// <returns>ValidationResult</returns>
        public FluentValidation.Results.ValidationResult ExecuteLawEnforcementEngine(RaterFacadeModel raterFacadeModel)
        {
            //Create service object
            ILawEnforcementService service = new LawEnforcementService(this.configuration, this.logger); ;

            // Prevalidate
            var preValidateResults = service.PreValidate(raterFacadeModel);

            if (!preValidateResults.IsValid) return preValidateResults;

            // Since input pre validation are success, calculate premium
            service.Calculate(raterFacadeModel);

            //Post validate
            var postValidateResults = service.PostValidate(raterFacadeModel);

            return postValidateResults;
        }
    }
}
