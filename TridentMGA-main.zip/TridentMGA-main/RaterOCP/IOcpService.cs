﻿using Models;
using Models.ApiModels;


namespace RaterOCP
{
     

    public interface IOcpService
    {
        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model);

        /// <summary>
        /// Calculate 
        /// </summary>
        /// <param name="model">RaterFacadeModel.</param>

        void Calculate(RaterFacadeModel model);        
    }
}
