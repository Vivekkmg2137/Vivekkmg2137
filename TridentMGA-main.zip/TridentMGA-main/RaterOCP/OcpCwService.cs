﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using DataAccess;
using System;
using System.Data;
using System.Collections.Generic;
using DomainRules;
using Validations;
using Models.ApiModels.LineOfBusiness.Ocp.Output;
using Models.ApiModels.LineOfBusiness.Ocp.Input;

namespace RaterOCP
{
    public class OCPCwService : IOcpService
    {
        private OCPDataAccess OCPDataAccess;
        protected ILoggingManager logger { get; private set; }
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="OCPCwService"/> class.
        /// </summary>
        /// <param name="logger">ILoggingManager.</param>
        public OCPCwService(IConfiguration configuration, ILoggingManager logger)
        {

            this.logger = logger;
            this.OCPDataAccess = new OCPDataAccess(configuration, logger);
        }

        /// <summary>
        /// ExecuteDomainRules : It will apply Domain rules.
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        /// <summary>
        /// ExecuteDomainRules : It will apply PreValidate rules.
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new OCPPreValidator(this.configuration, this.logger);
                var results = validator.Validate(model);

                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// ExecuteDomainRules : It will apply PostValidate rules.
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new OCPPostValidator(this.configuration, this.logger);
                var results = validator.Validate(model);
                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate : It will calculate OCP premium.
        /// </summary>
        /// <param name="model"></param>
        public void Calculate(RaterFacadeModel model)
        {
            try
            {
                if (model.RaterInputFacadeModel.LineOfBusiness.Ocp1)
                {
                    model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1 = new OcpOutputModel();
                    OCPCalculation(model, model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1, model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1); 
                }

                if (model.RaterInputFacadeModel.LineOfBusiness.Ocp2)
                {
                    model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp2 = new OcpOutputModel();
                    OCPCalculation(model, model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp2, model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp2);
                }
                if (model.RaterInputFacadeModel.LineOfBusiness.Ocp3)
                {
                    model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp3 = new OcpOutputModel();
                    OCPCalculation(model, model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp3, model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp3);
                }
                if (model.RaterInputFacadeModel.LineOfBusiness.Ocp4)
                {
                    model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp4 = new OcpOutputModel();
                    OCPCalculation(model, model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp4, model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp4);
                }
                if (model.RaterInputFacadeModel.LineOfBusiness.Ocp5)
                {
                    model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp5 = new OcpOutputModel();
                    OCPCalculation(model, model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp5, model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp5);
                }
            }
            catch (Exception ex)
            {
                logger.Error("OCPCwService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        private void OCPCalculation(RaterFacadeModel model,OcpOutputModel ocpOutputModel, OcpInputModel ocpInputModel)
        {
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            policyHeader.State = policyHeader.State.ToUpper();
            policyHeader.PrimaryClass = policyHeader.PrimaryClass.ToUpper();
            policyHeader.TransactionType = policyHeader.TransactionType.ToUpper();

            //Step A -BASE PREMIUM
            //Step A.1
            if (ocpOutputModel==null)
            {
                ocpOutputModel = new OcpOutputModel();
            }
            if (model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == "CANCELLED")
            {
                ocpOutputModel.BasePremium = 0;
            }
            else
            {
                ocpOutputModel.BasePremium = OCPDataAccess.GetOcpBasePremium(ocpInputModel.Limit, ocpInputModel.AggregateLimit, ocpInputModel.Description, model.RaterInputFacadeModel.PolicyHeaderModel.State, ocpInputModel.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate);
            }

            //Step B - NON-MODIFIED PREMIUM
            ocpOutputModel.NonModifiedPremium = 0;

            //Step C - MANUAL PREMIUM
            //C.1 OCPManualPremium = Step A.1 
            ocpOutputModel.ManualPremium = ocpOutputModel.BasePremium;

            //Step D - TIER PREMIUM
            //Step D.1 Tier factor
            ocpOutputModel.TierRate = OCPDataAccess.GetOCPMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, ocpInputModel.LineOfBusiness, "Tier Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate);

            //Step D.2 OCP Tier premium (Step C.1 * Step D.1)
            ocpOutputModel.TierPremium = ocpOutputModel.ManualPremium * ocpOutputModel.TierRate;

            //Step E -IRPM PREMIUM
            //Step E.1 IRPM factor
            ocpOutputModel.IRPMRate = OCPDataAccess.GetOCPMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, ocpInputModel.LineOfBusiness, "IRPM Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate);

            //Step E.2 OCP IRPM premium (Step C.1 * Step E.1)
            ocpOutputModel.IRPMPremium = ocpOutputModel.ManualPremium * ocpOutputModel.IRPMRate;

            //Step F - OTHER MOD PREMIUM
            //Step F.1 Other Mod factor 
            ocpOutputModel.OtherModRate= OCPDataAccess.GetOCPMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, ocpInputModel.LineOfBusiness, "Other Mod", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate);

            //Step F.2 OCP Other Mod premium (Step C.1 * Step F.1)
            ocpOutputModel.OtherModPremium = ocpOutputModel.ManualPremium * ocpOutputModel.OtherModRate;

            //Step G TERRORISM PREMIUM
            ocpOutputModel.TerrorismRate = 0;

            ocpOutputModel.TerrorismPremium = 0;

            //Step H -MODIFIED PREMIUM
            //H.1 Modified Premium = Step A.1
            ocpOutputModel.OCPFinalPremium = ocpOutputModel.BasePremium;
        }
    }
}
