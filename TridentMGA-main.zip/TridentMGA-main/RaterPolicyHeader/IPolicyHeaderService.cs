﻿using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaterPolicyHeader
{
    interface IPolicyHeaderService
    {
        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);
    }
}
