﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using Validations;

namespace RaterPolicyHeader
{
    public class PolicyHeaderService : IPolicyHeaderService
    {
        private PropertyDataAccess _PropertyDataAccess { get; set; }
        protected ILoggingManager _Logger { get; private set; }

        readonly IConfiguration configuration;

        public PolicyHeaderService(IConfiguration configuration, ILoggingManager logger)
        {
            this._Logger = logger;
            this.configuration = configuration;
            this._PropertyDataAccess = new PropertyDataAccess(this.configuration, this._Logger);
        }

        public DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        public FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new PolicyHeaderPreValidation(this.configuration, this._Logger);
                var results = validator.Validate(model);

                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error(ex.Message, ex);
                throw;
            }
        }
    }
}
