﻿using Models;
using Models.ApiModels;

namespace RaterPricing
{
    public interface IPricingService
    {
        /// <summary>
        /// Domain rules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Results</returns>
        //DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        /// <summary>
        /// CalculatePremium : Calculate final premium from property.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        void GetLOBsSummaryDetails(RaterFacadeModel model);
    }
}
