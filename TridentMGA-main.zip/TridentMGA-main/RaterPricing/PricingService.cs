﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Output;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Input;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Output;
using Models.ApiModels.Pricing.Output;
using System;
using System.Linq;

namespace RaterPricing
{
    /// <summary>
    /// Pricing Service
    /// </summary>
    public class PricingService : IPricingService
    {
        /// <summary>
        /// Logger.
        /// </summary>
        protected ILoggingManager _Logger { get; private set; }

        /// <summary>
        /// Configuration
        /// </summary>
        protected IConfiguration _Configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="PricingService"/> class.
        /// </summary>
        /// <param name="logger">ILoggingManager.</param>
        public PricingService(IConfiguration configuration, ILoggingManager logger)
        {
            this._Configuration = configuration;
            this._Logger = logger;
        }

        //public virtual DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        //{
        //    var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
        //    var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

        //    if (!validationResult.IsValid)
        //    {
        //        List<string> errorList = new List<string>();
        //        foreach (var error in validationResult.Errors)
        //        {
        //            errorList.Add(error.Message);
        //        }
        //    }

        //    return validationResult;
        //}

        /// <summary>
        /// CalculatePremium : It will Calculate Pricing premium.
        /// </summary>
        /// <param name="model">RaterPricingModel.</param>
        public virtual void GetLOBsSummaryDetails(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("PricingService.CalculatePremium :: Started");

                GetLOBsDetails(model);

                this._Logger.Info("PricingService.Calculate :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetLOBsDetails : Get all selected lobs details.
        /// </summary>
        /// <param name="model"></param>
        private void GetLOBsDetails(RaterFacadeModel model)
        {
            var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

            policyHeader.State = policyHeader.State.ToUpper();
            policyHeader.PrimaryClass = policyHeader.PrimaryClass.ToUpper();
            policyHeader.TransactionType = policyHeader.TransactionType.ToUpper();

            if (model.RaterInputFacadeModel.LineOfBusiness.Property)
            {
                GetPropertyDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.Auto)
            {
                GetAutoDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.EmploymentPractices)
            {
                GetEmploymentPracticesDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.EmploymentPracticesSchool)
            {
                GetEmploymentPracticesSchoolDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.LawEnforcement)
            {
                GetLawEnforcementDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.Ocp1)
            {
                GetOCP1Details(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.Ocp2)
            {
                GetOCP2Details(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.Ocp3)
            {
                GetOCP3Details(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.Ocp4)
            {
                GetOCP4Details(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.Ocp5)
            {
                GetOCP5Details(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.PublicOfficials)
            {
                GetPublicOfficialsDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.DirectorsAndOfficers)
            {
                GetDirectorsAndOfficersDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.EducatorsLegal)
            {
                GetEducatorsLegalDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.Crime)
            {
                GetCrimeDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.GeneralLiability)
            {
                GetGeneralLiabilityDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.InlandMarine)
            {
                GetInlandMarineDetails(model);
            }

            if (model.RaterInputFacadeModel.LineOfBusiness.Excess)
            {
                GetExcessDetails(model);
            }
        }

        /// <summary>
        /// GetExcessDetails
        /// </summary>
        /// <param name="model"></param>
        private void GetExcessDetails(RaterFacadeModel model)
        {
            //throw new NotImplementedException();
        }

        /// <summary>
        /// GetInlandMarineDetails
        /// </summary>
        /// <param name="model"></param>
        private void GetInlandMarineDetails(RaterFacadeModel model)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// GetGeneralLiabilityDetails
        /// </summary>
        /// <param name="model"></param>
        private void GetGeneralLiabilityDetails(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;

            try
            {
                this._Logger.Info("PricingService.GetGeneralLiabilityDetails :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.GLFinalModifiedPremium);

                outputPricingModel.GLLimit = inputModel.LiabilityLimit;
                outputPricingModel.GLDeductible = inputModel.Retention;

                this._Logger.Info("PricingService.GetGeneralLiabilityDetails :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetGeneralLiabilityDetails :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetCrimeDetails
        /// </summary>
        /// <param name="model"></param>
        private void GetCrimeDetails(RaterFacadeModel model)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// GetEducatorsLegalDetails
        /// </summary>
        /// <param name="model"></param>
        private void GetEducatorsLegalDetails(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            
            EducatorsLegalNyInputModel nyInputModel;
            EducatorsLegalNyOutputModel nyOutputModel;
            EducatorsLegalCwInputModel cwInputModel;
            EducatorsLegalCwOutputModel cwOutputModel;

            try
            {
                this._Logger.Info("PricingService.GetEducatorsLegalDetails :: Started");

                if (model.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.NY)
                {
                    nyOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY;
                    nyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY;

                    GetTotalPremiums(outputPricingModel, nyOutputModel, nyOutputModel.ELModifiedFinalPremium);

                    outputPricingModel.ELLimit = nyInputModel.LiabilityLimit;
                    outputPricingModel.ELDeductible = nyInputModel.Retention;
                }
                else
                {
                    cwOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW;
                    cwInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW;

                    GetTotalPremiums(outputPricingModel, cwOutputModel, cwOutputModel.ELModifiedFinalPremium);

                    outputPricingModel.ELLimit = cwInputModel.LiabilityLimit;
                    outputPricingModel.ELDeductible = cwInputModel.Retention;
                }

                this._Logger.Info("PricingService.GetEducatorsLegalDetails :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetEducatorsLegalDetails :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetDirectorsAndOfficersDetails
        /// </summary>
        /// <param name="model"></param>
        private void GetDirectorsAndOfficersDetails(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;

            try
            {
                this._Logger.Info("PricingService.GetDirectorsAndOfficersDetails :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.DOModifiedFinalPremium);

                outputPricingModel.DOLimit = inputModel.LiabilityLimit;
                outputPricingModel.DODeductible = inputModel.Retention;

                this._Logger.Info("PricingService.GetDirectorsAndOfficersDetails :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetDirectorsAndOfficersDetails :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetPublicOfficialsDetails
        /// </summary>
        /// <param name="model"></param>
        private void GetPublicOfficialsDetails(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;

            PublicOfficialsNYInputModel nyInputModel;
            PublicOfficialsNYOutputModel nyOutputModel;
            PublicOfficialsCWInputModel cwInputModel;
            PublicOfficialsCWOutputModel cwOutputModel;

            try
            {
                this._Logger.Info("PricingService.GetPublicOfficialsDetails :: Started");

                if (model.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.NY)
                {
                    nyOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY;
                    nyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;

                    GetTotalPremiums(outputPricingModel, nyOutputModel, nyOutputModel.PONYModifiedFinalPremium);

                    outputPricingModel.POLimit = nyInputModel.LiabilityLimit;
                    outputPricingModel.PODeductible = nyInputModel.Retention;
                }
                else
                {
                    cwOutputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW;
                    cwInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW;

                    GetTotalPremiums(outputPricingModel, cwOutputModel, cwOutputModel.POModifiedFinalPremium);

                    outputPricingModel.POLimit = cwInputModel.LiabilityLimit;
                    outputPricingModel.PODeductible = cwInputModel.Retention;
                }

                this._Logger.Info("PricingService.GetPublicOfficialsDetails :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetPublicOfficialsDetails :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetOCP5Details : Get OCP5 details.
        /// </summary>
        /// <param name="model"></param>
        private void GetOCP5Details(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp5;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp5;

            try
            {
                this._Logger.Info("PricingService.GetOCP5Details :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.OCPFinalPremium);

                outputPricingModel.OCP5Limit = Convert.ToInt32(inputModel.Limit);
                outputPricingModel.OCP5Deductible = "N/A";

                this._Logger.Info("PricingService.GetOCP5Details :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetOCP5Details :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetOCP4Details : Get OCP4 details.
        /// </summary>
        /// <param name="model"></param>
        private void GetOCP4Details(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp4;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp4;

            try
            {
                this._Logger.Info("PricingService.GetOCP4Details :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.OCPFinalPremium);

                outputPricingModel.OCP4Limit = Convert.ToInt32(inputModel.Limit);
                outputPricingModel.OCP4Deductible = "N/A";

                this._Logger.Info("PricingService.GetOCP4Details :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetOCP4Details :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetOCP3Details : Get OCP3 details.
        /// </summary>
        /// <param name="model"></param>
        private void GetOCP3Details(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp3;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp3;

            try
            {
                this._Logger.Info("PricingService.GetOCP3Details :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.OCPFinalPremium);

                outputPricingModel.OCP3Limit = Convert.ToInt32(inputModel.Limit);
                outputPricingModel.OCP3Deductible = "N/A";

                this._Logger.Info("PricingService.GetOCP3Details :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetOCP3Details :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetOCP2Details : Get OCP2 details.
        /// </summary>
        /// <param name="model"></param>
        private void GetOCP2Details(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp2;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp2;

            try
            {
                this._Logger.Info("PricingService.GetOCP2Details :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.OCPFinalPremium);

                outputPricingModel.OCP2Limit = Convert.ToInt32(inputModel.Limit);
                outputPricingModel.OCP2Deductible = "N/A";

                this._Logger.Info("PricingService.GetOCP2Details :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetOCP2Details :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetOCP1Details : Get OCP1 details.
        /// </summary>
        /// <param name="model"></param>
        private void GetOCP1Details(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1;

            try
            {
                this._Logger.Info("PricingService.GetOCP1Details :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.OCPFinalPremium);

                outputPricingModel.OCP1Limit = Convert.ToInt32(inputModel.Limit);
                outputPricingModel.OCP1Deductible = "N/A";

                this._Logger.Info("PricingService.GetOCP1Details :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetOCP1Details :: Exception :: " + ex.Message, ex);
                throw;

            }
        }

        /// <summary>
        /// GetLawEnforcementDetails : Get Law enforcement details.
        /// </summary>
        /// <param name="model"></param>
        private void GetLawEnforcementDetails(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;

            try
            {
                this._Logger.Info("PricingService.GetLawEnforcementDetails :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.LawFinalModifiedPremium);

                outputPricingModel.LELimit = inputModel.LiabilityLimit;
                outputPricingModel.LEDeductible = inputModel.Retention;

                this._Logger.Info("PricingService.GetLawEnforcementDetails :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetLawEnforcementDetails :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetEmploymentPracticesSchoolDetails : Get Employment practices school details.
        /// </summary>
        /// <param name="model"></param>
        private void GetEmploymentPracticesSchoolDetails(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;

            try
            {
                this._Logger.Info("PricingService.GetEmploymentPracticesSchoolDetails :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.EPSFinalModifiedPremium);

                outputPricingModel.EPSLimit = inputModel.LiabilityLimit;
                outputPricingModel.EPSDeductible = inputModel.Retention;

                this._Logger.Info("PricingService.GetEmploymentPracticesSchoolDetails :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetEmploymentPracticesSchoolDetails :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetEmploymentPracticesDetails  : Get Employment practices details.
        /// </summary>
        /// <param name="model"></param>
        private void GetEmploymentPracticesDetails(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;

            try
            {
                this._Logger.Info("PricingService.GetEmploymentPracticesDetails :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.EPFinalModifiedPremium);

                outputPricingModel.EPLimit = inputModel.LiabilityLimit;
                outputPricingModel.EPDeductible = inputModel.Retention;

                this._Logger.Info("PricingService.GetEmploymentPracticesDetails :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetEmploymentPracticesDetails :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetAutoDetails  : Get Auto details.
        /// </summary>
        /// <param name="model"></param>
        private void GetAutoDetails(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW;

            if (model.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.NY)
            {
                inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY;
                outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY;
            }

            try
            {
                this._Logger.Info("PricingService.GetAutoDetails :: Started");

                outputPricingModel.ALLimit = Convert.ToString(inputModel.AutoLiabilityInputModel.LiabilityLimit);
                outputPricingModel.ALDeductible = inputModel.AutoLiabilityInputModel.Retention;

                GetTotalPremiums(outputPricingModel, outputModel.AutoLiabilityOutputModel, outputModel.AutoLiabilityOutputModel.ALModifiedFinalPremium);

                if (inputModel.HasAutoPhysicalDamage)
                {
                    if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
                    {
                        if (outputModel.AutoPhysicalDamageOutputModel.TotalCollisionOCN == outputModel.AutoPhysicalDamageOutputModel.TotalComprehensiveOCN)
                        {
                            outputPricingModel.APDLimit = Convert.ToString(outputModel.AutoPhysicalDamageOutputModel.TotalCollisionOCN);
                        }
                        else
                        {
                            outputPricingModel.APDLimit = "Various";
                        }
                    }
                    else
                    {
                        if (outputModel.AutoPhysicalDamageOutputModel.TotalCollisionOCN == outputModel.AutoPhysicalDamageOutputModel.TotalComprehensiveOCN && outputModel.AutoPhysicalDamageOutputModel.TotalComprehensiveOCN == outputModel.AutoPhysicalDamageOutputModel.TotalSpecifiedCauseofLossOCN)
                        {
                            outputPricingModel.APDLimit = Convert.ToString(outputModel.AutoPhysicalDamageOutputModel.TotalCollisionOCN);
                        }
                        else
                        {
                            outputPricingModel.APDLimit = "Various";
                        }
                    }

                    var firstVehicle = inputModel.AutoScheduleVehiclesDetailsInputModel.FirstOrDefault();
                    bool flag = true;


                    foreach (var item in inputModel.AutoScheduleVehiclesDetailsInputModel)
                    {
                        if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
                        {
                            if (!(item.CollDeductible == item.CompDeductible && item.CollDeductible == firstVehicle.CollDeductible && item.CollDeductible == firstVehicle.CompDeductible))
                            {
                                flag = false;
                                break;
                            }
                        }
                        else
                        {
                            if (!(item.CollDeductible == item.CompDeductible && item.CompDeductible == item.SpecifiedCauseofLossDeductible && item.CollDeductible == firstVehicle.CollDeductible && item.CollDeductible == firstVehicle.CompDeductible && item.CollDeductible == firstVehicle.SpecifiedCauseofLossDeductible))
                            {
                                flag = false;
                                break;
                            }
                        }

                    }

                    if (flag == true)
                    {
                        outputPricingModel.APDDeductible = Convert.ToString(firstVehicle.CollDeductible);
                    }
                    else
                    {
                        outputPricingModel.APDDeductible = "Various";
                    }

                    GetTotalPremiums(outputPricingModel, outputModel.AutoPhysicalDamageOutputModel, outputModel.AutoPhysicalDamageOutputModel.APDModifiedFinalPremium);
                }

                this._Logger.Info("PricingService.GetAutoDetails :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetAutoDetails :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetPropertyDetails : Get Property details.
        /// </summary>
        /// <param name="model"></param>
        private void GetPropertyDetails(RaterFacadeModel model)
        {
            var outputPricingModel = model.RaterOutputFacadeModel.PricingOutputModel;
            var outputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;

            try
            {
                this._Logger.Info("PricingService.GetPropertyDetails :: Started");

                GetTotalPremiums(outputPricingModel, outputModel, outputModel.ModifiedPremium);

                outputPricingModel.PropertyLimit = Convert.ToInt32(outputModel.TotalTIV);
                outputPricingModel.PropertyDeductible = Convert.ToInt32(inputModel.AOPDeductible);

                this._Logger.Info("PricingService.GetPropertyDetails :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PricingService.GetPropertyDetails :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// GetTotalPremiums : Get total premium details.
        /// </summary>
        /// <param name="pricingOutputModel"></param>
        /// <param name="outputModel"></param>
        /// <param name="finalPremium"></param>
        private void GetTotalPremiums(PricingOutputModel pricingOutputModel, dynamic outputModel, decimal finalPremium)
        {
            pricingOutputModel.TotalManualPremium = pricingOutputModel.TotalManualPremium + Convert.ToInt32(outputModel.ManualPremium);
            pricingOutputModel.TotalTierPremium = pricingOutputModel.TotalTierPremium + Convert.ToInt32(outputModel.TierPremium);
            pricingOutputModel.TotalIRPMPremium = pricingOutputModel.TotalIRPMPremium + Convert.ToInt32(outputModel.IRPMPremium);
            pricingOutputModel.TotalOtherModPremium = pricingOutputModel.TotalOtherModPremium + Convert.ToInt32(outputModel.OtherModPremium);
            pricingOutputModel.TotalTerrorismPremium = pricingOutputModel.TotalTerrorismPremium + Convert.ToInt32(outputModel.TerrorismPremium);
            pricingOutputModel.TotalFinalRatedPremium = pricingOutputModel.TotalFinalRatedPremium + Convert.ToInt32(finalPremium);
        }
    }
}
