﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using Models;

namespace RaterPricing
{
    public class PricingServiceWrapper
    {
        /// <summary>
        /// Logger.
        /// </summary>
        protected ILoggingManager logger { get; private set; }
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="PricingService"/> class.
        /// </summary>
        /// <param name="logger">ILoggingManager.</param>
        public PricingServiceWrapper(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;

            this.logger = logger;
        }

        /// <summary>
        /// ExecutePropertyEngine : It's includes premium calculation.
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        /// <returns>ValidationResult</returns>
        public RaterFacadeModel ExecutePricingEngine(RaterFacadeModel raterFacadeModel)
        {
            //Create service object
            IPricingService service = new PricingService(this.configuration, this.logger);
            
            // Since input pre validation are success, calculate premium
            service.GetLOBsSummaryDetails(raterFacadeModel);

            return raterFacadeModel;
        }
    }
}
