﻿namespace RaterProperty
{
    using Models;
    using Models.ApiModels;

    public interface IPropertyService
    {
        /// <summary>
        /// Domain rules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Results</returns>
        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        /// <summary>
        /// Runs pre validation rules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);

        /// <summary>
        /// Runs post validation rules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model);

        /// <summary>
        /// CalculatePremium : Calculate final premium from property.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        void Calculate(RaterFacadeModel model);

        ///// <summary>
        ///// CalculateBuildingBPPPremium : Calculate Building BPP Premium.
        ///// </summary>
        ///// <param name="model">RaterPropertyModel.</param>
        //void CalculateBuildingBPPPremium(RaterFacadeModel model);

        ///// <summary>
        ///// CalculateEquipmentBreakdownPremium : Calculate Equipment breakdown premium.
        ///// </summary>
        ///// <param name="model">RaterPropertyModel.</param>
        //void CalculateEquipmentBreakdownPremium(RaterFacadeModel model);

        ///// <summary>
        ///// CalculateWindFloodEarthquakePremium : Calculate Wind flood Earthquake premium.
        ///// </summary>
        ///// <param name="model">RaterPropertyModel.</param>
        //void CalculateWindFloodEarthquakePremium(RaterFacadeModel model);

        ///// <summary>
        ///// CalculateOptionalCoveragePremium : Calculate optional coverage premium.
        ///// </summary>
        ///// <param name="model">RaterPropertyModel.</param>
        //void CalculateOptionalCoveragePremium(RaterFacadeModel model);

        ///// <summary>
        ///// CalculateFinalPropertyPremium : Calculate final property premium.
        ///// </summary>
        ///// <param name="model">RaterPropertyModel.</param>
        //void CalculateFinalPropertyPremium(RaterFacadeModel model);

        
        ///// <summary>
        ///// CalculateProperty360CoveragePremium : Calculate property 360 coverage premium.
        ///// </summary>
        ///// <param name="model">RaterPropertyModel.</param>
        //void CalculateProperty360CoveragePremium(RaterFacadeModel model);

        ///// <summary>
        ///// CalculateProperty360BIEECoveragePremiumsTest
        ///// </summary>
        ///// <param name="model"></param>
        //void CalculateProperty360BIEECoveragePremiums(RaterFacadeModel raterPropertyModel);

        ///// <summary>
        ///// CalculateProperty360CoverageModificationPremiumsTest
        ///// </summary>
        ///// <param name="model"></param>
        //void CalculateProperty360CoverageModificationPremiums(RaterFacadeModel raterPropertyModel);

        ///// <summary>
        ///// CalculateProperty360GolfCoursesPremiumsTest
        ///// </summary>
        ///// <param name="model"></param>
        //void CalculateProperty360GolfCoursesPremiums(RaterFacadeModel raterPropertyModel);

        ///// <summary>
        ///// CalculateProperty360OptionalCoverageTest
        ///// </summary>
        ///// <param name="model"></param>
        //void CalculateProperty360OptionalCoverage(RaterFacadeModel raterPropertyModel);

        ///// <summary>
        ///// CalculateSchedulePremium
        ///// </summary>
        ///// <param name="raterPropertyModel"></param>
        //void CalculateSchedulePremium(RaterFacadeModel raterPropertyModel);
    }
}