﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using DataAccess;
using System;
using System.Data;
using Validations;
using Models.ApiModels;
using Models.Initialization;
using System.Collections.Generic;
using System.Linq;
using DomainRules;
using Models.ApiModels.Policy;
using Models.ApiModels.LineOfBusiness.Property.Output;

namespace RaterProperty
{
    public class PropertyCwService : IPropertyService
    {
        private readonly int buildingDefPointsLimit = 6750;
        private readonly int contentDefPointsLimit = 6750;
        private readonly int buildingDefPointsNoPerilsLimit = 6750;
        private readonly int contentDefPointsNoPerilsLimit = 6750;
        private readonly int deductibleLimit = 5000;
        private PropertyDataAccess propertyDataAccess;

        /// <summary>
        /// Logger.
        /// </summary>
        protected ILoggingManager logger { get; private set; }
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyCwService"/> class.
        /// </summary>
        /// <param name="logger">ILoggingManager.</param>
        public PropertyCwService(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.propertyDataAccess = new PropertyDataAccess(this.configuration, this.logger);
        }

        public virtual DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        public virtual FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new PropertyPreValidator(this.configuration, this.logger);
                var results = validator.Validate(model);

                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyCwService.PreValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        public virtual FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new PropertyPostValidator(this.configuration, this.logger);
                var results = validator.Validate(model);
                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyCwService.PostValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculatePremium : It will Calculate Property premium.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        public virtual void Calculate(RaterFacadeModel model)
        {
            Property360DataAccess property360DataAccess = new Property360DataAccess(this.configuration, this.logger);
            Dictionary<string, decimal> additionalBenefits = new Dictionary<string, decimal>();
            try
            {
                this.logger.Info("PropertyBaseService.CalculatePremium :: Started");

                // Step 1: Calculate Building BPP Premium
                this.CalculateBuildingBPPPremium(model);

                // Step 2 : Calculate Equipment Breakdown Premium
                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownCoverage)
                {                    
                    this.CalculateEquipmentBreakdownPremium(model); 
                }

                // Step 3 :Calculate WindFlood Earthquake Premium
                this.CalculateWindFloodEarthquakePremium(model);

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel != null)
                {
                    // Step 4 : Calculate Option Coverage premium
                    this.CalculateOptionalCoveragePremium(model);
                }

                DataTable AdditionalBenefits = property360DataAccess.GetCoverageDetailForAdditionalBenefits(model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).Tables[0];
                foreach (DataRow dr in AdditionalBenefits.Rows)
                {
                    string key = dr["CoverageName"].ToString();
                    decimal value = dr["BaseLimit"] == DBNull.Value ? 0 : Convert.ToDecimal(dr["BaseLimit"]);
                    if (!additionalBenefits.ContainsKey(key))
                    {
                        additionalBenefits.Add(key, value);
                    }
                }

                // Property 360 Coverage premium
                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel != null)
                {
                    this.CalculateProperty360CoveragePremium(model, additionalBenefits);
                }
                else
                {
                    model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel = null;
                }

                if (additionalBenefits != null && additionalBenefits.Count > 0)
                {
                    model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TIVAndAdditionalBenefits = additionalBenefits.Sum(x => x.Value);
                }

                // Step 5 : Calculate Final Premium
                this.CalculateFinalPropertyPremium(model);

                this.logger.Info("PropertyCwService.Calculate :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyCwService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Building BPP premium.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected virtual void CalculateBuildingBPPPremium(RaterFacadeModel model)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;
                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                policyHeader.State = policyHeader.State.ToUpper();
                policyHeader.PrimaryClass = policyHeader.PrimaryClass.ToUpper();
                policyHeader.TransactionType = policyHeader.TransactionType.ToUpper();

                this.logger.Info("PropertyBaseService.CalculateBuildingBPPPremium :: Started");

                // Changes According UI Fields.
                outputProperty.TotalExpTIV = inputProperty.TIVExpPeriod1stYear + inputProperty.TIVExpPeriod2ndYear + inputProperty.TIVExpPeriod3rdYear;
                if (outputProperty.TotalExpTIV == 0)
                {
                    throw new Exception("OutputModel.Property.TotalExpTIV cannot be zero!");
                }
                //BuildingTIV = It is the total of all Building Limits
                //ContentsTIV = It is the total of all Content Limits

                // Sum of Total Building TIV & Contents TIV (Input field)
                // Step 3 ( Step 1 + step 2) : TotalTIV = (BuildingTIV + ContentsTIV)
                outputProperty.TotalTIV = inputProperty.BuildingTIV + inputProperty.ContentTIV;
                outputProperty.BuildingTIV = inputProperty.BuildingTIV;
                outputProperty.ContentTIV = inputProperty.ContentTIV;

                CalculateBuildingAndContentDefPoints(model);

                // Step-6 Getting BuildingBaseMLR from MiscFactors lookup table .
                outputProperty.BuildingBaseMLR = this.propertyDataAccess.GetBuildingOrContentBaseMLRFactor(model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, model.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "Building", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step-7
                if (outputProperty.BuildingDefTotalPoints > this.buildingDefPointsLimit)
                {
                    // Getting charge from Building Addtl Def Charge lookup table .
                    outputProperty.BuildingAddtlDefCharge = this.propertyDataAccess.GetBuildingAdditionalDefCharge(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness,outputProperty.BuildingDefTotalPoints, "Increased Def Point Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // 13-07-2021
                    // Round BuildingAddtlDefCharge up to 3 digit.
                    outputProperty.BuildingAddtlDefCharge = Math.Round(outputProperty.BuildingAddtlDefCharge, 3, MidpointRounding.AwayFromZero);
                }
                else
                {
                    // Getting BuildingAddtlDefCharge from MajorLossRateCharges lookup table
                    outputProperty.BuildingAddtlDefCharge = this.propertyDataAccess.GetBuildingMajorLossRateCharge(outputProperty.BuildingDefTotalPoints, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // 13-07-2021
                    // Round BuildingAddtlDefCharge up to 3 digit.
                    outputProperty.BuildingAddtlDefCharge = Math.Round(outputProperty.BuildingAddtlDefCharge, 3, MidpointRounding.AwayFromZero);
                }

                // Step-8 Getting ContentsBaseMLR from MiscFactors lookup table .
                outputProperty.ContentsBaseMLR = this.propertyDataAccess.GetBuildingOrContentBaseMLRFactor(model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, model.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "Contents", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate); // Getting BuildingBaseMLR from MiscFactors table           

                // Step-9
                if (outputProperty.ContentsDefTotalPoints > this.contentDefPointsLimit)
                {
                    // Getting charge from Content Addtl Def Charge lookup table .
                    outputProperty.ContentsAddtlDefCharge = this.propertyDataAccess.GetContentsAdditionalDefCharge(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness,outputProperty.ContentsDefTotalPoints, "Increased Def Point Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // 13-07-2021
                    // Round ContentsAddtlDefCharge up to 3 digit.
                    outputProperty.ContentsAddtlDefCharge = Math.Round(outputProperty.ContentsAddtlDefCharge, 3, MidpointRounding.AwayFromZero);
                }
                else
                {
                    // Getting ContentsAddtlDefCharge from MajorLossRateCharges lookup table
                    outputProperty.ContentsAddtlDefCharge = this.propertyDataAccess.GetContentsMajorLossRateCharge(outputProperty.ContentsDefTotalPoints, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // 13-07-2021
                    // Round ContentsAddtlDefCharge up to 3 digit.
                    outputProperty.ContentsAddtlDefCharge = Math.Round(outputProperty.ContentsAddtlDefCharge, 3, MidpointRounding.AwayFromZero);
                }

                // Step-10 Getting AOPDeductibleFactor from DollarDeuctibleCredit lookup table
                outputProperty.AOPDeductibleFactor = this.propertyDataAccess.GetDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step-11 Getting CoinsuranceFactor from CoinsuranceFactors table
                outputProperty.CoinsuranceFactor = this.propertyDataAccess.GetCoinsuranceFactor(inputProperty.Coinsurance, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step-12 Getting MarginClauseFactor from MarginClauseFactors table
                outputProperty.MarginClauseFactor = this.propertyDataAccess.GetMarginClauseFactors(inputProperty.MarginClause, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step-13 Getting ValuationFactor from ValuationFactors table
                outputProperty.ValuationFactor = this.propertyDataAccess.GetValuationFactors(inputProperty.Valuation, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step 14 ((Step 6  + Step 7 )*Step 10 * Step 11* Step 12 * Step 13)
                // BuildingModifiedMLR : (BuildingBaseMLR + BuildingAddtlDefCharge) * AOPDeductibleFactor * model.CoinsuranceFactor * model.MarginClauseFactor * model.ValuationFactor;
                outputProperty.BuildingModifiedMLR = (outputProperty.BuildingBaseMLR
                                                                 + outputProperty.BuildingAddtlDefCharge)
                                                                 * outputProperty.AOPDeductibleFactor
                                                                 * outputProperty.CoinsuranceFactor
                                                                 * outputProperty.MarginClauseFactor
                                                                 * outputProperty.ValuationFactor;

                // Round BuildingModifiedMLR up to 3 digit.
                outputProperty.BuildingModifiedMLR = Math.Round(outputProperty.BuildingModifiedMLR, 3, MidpointRounding.AwayFromZero);

                // Step 15 ((Step 8  + Step 9)*Step 10 * Step 11* Step 12 * Step 13)
                // ContentsModifiedMLR : ((ContentsBaseMLR + ContentsAddtlDefCharge) * AOPDeductibleFactor * CoinsuranceFactor * MarginClauseFactor * ValuationFactor)
                outputProperty.ContentsModifiedMLR = (outputProperty.ContentsBaseMLR
                                                                 + outputProperty.ContentsAddtlDefCharge)
                                                                 * outputProperty.AOPDeductibleFactor
                                                                 * outputProperty.CoinsuranceFactor
                                                                 * outputProperty.MarginClauseFactor
                                                                 * outputProperty.ValuationFactor;

                // Round ContentsModifiedMLR up to 3 digit.
                outputProperty.ContentsModifiedMLR = Math.Round(outputProperty.ContentsModifiedMLR, 3, MidpointRounding.AwayFromZero);

                if (inputProperty.AOPDeductible >= this.deductibleLimit)
                {
                    outputProperty.ModifiedNormalLossRate = 0;
                }
                else
                {
                    // Getting 'LCMFactor' from MiscFactors table.
                    outputProperty.LCMFactor = this.propertyDataAccess.GetNormalLossRateLCMFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "Normal Loss Rate LCM", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Sum net Normal Loss Claims, Normal Loss TIV Value used to calculate the premium are user entered values.
                    outputProperty.NormalLossRate = (inputProperty.SumNetNormalLossClaims * outputProperty.LCMFactor) / (outputProperty.TotalExpTIV / 100);
                    // Round NormalLossRate up to 3 digit.
                    outputProperty.NormalLossRate = Math.Round(outputProperty.NormalLossRate, 3, MidpointRounding.AwayFromZero);

                    // Getting ModifiedNormalLossRate from MiscFactors table.
                    outputProperty.ModifiedNormalLossRate = this.propertyDataAccess.ModifiedNormalLossRate(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, outputProperty.NormalLossRate, "Min Max NLR", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }

                // Step 17 (Step 14 + Step 16) : BuildingFinalRate (BuildingModifiedMLR + ModifiedNormalLossRate)
                outputProperty.BuildingFinalRate = outputProperty.BuildingModifiedMLR + outputProperty.ModifiedNormalLossRate;

                // Step 18 (Step 15 + Step 16) : ContentsFinalRate (ContentsModifiedMLR + ModifiedNormalLossRate)
                outputProperty.ContentsFinalRate = outputProperty.ContentsModifiedMLR + outputProperty.ModifiedNormalLossRate;

                // Step 19 (Step 17 * (Step 1/100) + Step 18 *(Step 2/100)) : BuildingBPPPremium (BuildingFinalRate * (BuildingTIV / 100)) + (ContentsFinalRate * (ContentsTIV / 100))
                outputProperty.BuildingBPPPremium = ((outputProperty.BuildingFinalRate
                                                                  * (inputProperty.BuildingTIV
                                                                  / 100))
                                                                  + (outputProperty.ContentsFinalRate
                                                                  * (inputProperty.ContentTIV
                                                                  / 100)));

                outputProperty.BuildingBPPPremium = Math.Round(outputProperty.BuildingBPPPremium, MidpointRounding.AwayFromZero);

                this.logger.Info("PropertyBaseService.CalculateBuildingBPPPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyBaseService.CalculateBuildingBPPPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        private void CalculateBuildingAndContentDefPoints(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

            //Add following field in the JSON file. These are applicable for states=AL, CO, DE, IL, IN, MA, MI, MN, NC, SC, TX, UT, VT, WY  
            string[] stateCheck1 = new string[14] { "AL", "CO", "DE", "IL", "IN", "MA", "MI", "MN", "NC", "SC", "TX", "UT", "VT", "WY" };
            string[] stateCheck2 = new string[9] { "CT", "GA", "KS", "ME", "MS", "MO", "NH", "OH", "PA" };

            #region Changes According UI Fields (Property- fill-in Deficiency).

            // Sub Total

            if (stateCheck1.Contains(model.RaterInputFacadeModel.PolicyHeaderModel.State))
            {
                outputProperty.DisasterExposureBuildingPointsSubtotal = inputProperty.DisasterExposureBuildingPoints;

                outputProperty.DisasterExposureContentPointsSubtotal = inputProperty.DisasterExposureContentPoints;
                // WindBuildingPoints
                outputProperty.ClimaticalHazardsBuildingPointsSubtotal = inputProperty.ClimaticalHazardsHurricaneBuildingPoints
                                                                       + inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints
                                                                       + inputProperty.ClimaticalHazardsWinterStormBuildingPoints;
                // + inputProperty.ClimaticalHazardsAllOtherBuildingPoints;
                // WindContentsPoints
                outputProperty.ClimaticalHazardsContentPointsSubtotal = inputProperty.ClimaticalHazardsHurricaneContentPoints
                                                                      + inputProperty.ClimaticalHazardsSevereConvectiveContentPoints
                                                                      + inputProperty.ClimaticalHazardsWinterStormContentPoints;
                // + inputProperty.ClimaticalHazardsAllOtherContentPoints;
                // Total BuildingDefTotalPoints
                outputProperty.BuildingDefTotalPoints = outputProperty.DisasterExposureBuildingPointsSubtotal + outputProperty.ClimaticalHazardsBuildingPointsSubtotal
                                                                      + inputProperty.OccupancyHazardsBuildingPoints
                                                                      + inputProperty.LackofPrivateProtectionBuildingPoints
                                                                      + inputProperty.AmendedLimitorAddCoverageBuildingPoints
                                                                      + inputProperty.InadequatePublicProtectionBuildingPoints
                                                                      + inputProperty.ExtraExternalExposureBuildingPoints
                                                                      + inputProperty.DeficiencyConstructionBuildingPoints
                                                                      + inputProperty.UnusualCombustionBuildingPoints
                                                                      + inputProperty.FloodExposureBuildingPoints
                                                                      + inputProperty.EarthquakeExposureBuildingPoints
                                                                      + inputProperty.ExcludedorReducedCoverageBuildingPoints;

                // Total ContentsDefTotalPoints
                outputProperty.ContentsDefTotalPoints = outputProperty.DisasterExposureContentPointsSubtotal + outputProperty.ClimaticalHazardsContentPointsSubtotal
                                                                      + inputProperty.OccupancyHazardsContentPoints
                                                                      + inputProperty.LackofPrivateProtectionContentPoints
                                                                      + inputProperty.AmendedLimitorAddCoverageContentPoints
                                                                      + inputProperty.InadequatePublicProtectionContentPoints
                                                                      + inputProperty.ExtraExternalExposureContentPoints
                                                                      + inputProperty.DeficiencyConstructionContentPoints
                                                                      + inputProperty.UnusualCombustionContentPoints
                                                                      + inputProperty.FloodExposureContentPoints
                                                                      + inputProperty.EarthquakeExposureContentPoints
                                                                      + inputProperty.ExcludedorReducedCoverageContentPoints;

                // FloodBuildingPoints
                outputProperty.FloodBuildingPointsSubtotal = inputProperty.FloodExposureBuildingPoints;
                // FloodContentsPoint
                outputProperty.FloodContentPointsSubtotal = inputProperty.FloodExposureContentPoints;
                // EarthquakeBuildingPoints
                outputProperty.EarthMovementBuildingPointsSubtotal = inputProperty.EarthquakeExposureBuildingPoints;
                // EarthquakeContentsPoints
                outputProperty.EarthMovementContentPointsSubtotal = inputProperty.EarthquakeExposureContentPoints;

            }

            #endregion

            #region Changes According UI Fields (Property- dropdown Deficiency).

            if (stateCheck2.Contains(model.RaterInputFacadeModel.PolicyHeaderModel.State))
            {
                // Sub Total Building A
                outputProperty.DisasterExposureBuildingPointsSubtotal = inputProperty.DisasterExposureDispersionBuildingPoints
                                                                 + inputProperty.DisasterExposurePMLBuildingPoints;
                // Building B 
                // WindBuildingPoints
                outputProperty.ClimaticalHazardsBuildingPointsSubtotal = inputProperty.ClimaticalHazardsHurricaneBuildingPoints
                                                                      + inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints
                                                                      + inputProperty.ClimaticalHazardsWinterStormBuildingPoints;
                //+ inputProperty.ClimaticalHazardsAllOtherBuildingPoints;
                // Building C
                outputProperty.SpecialOccupancyBuildingPointsSubtotal = inputProperty.SpecialOccupancyHazardsBuildingPoints
                                                                      + inputProperty.SpecialOccupancyProcessingBuildingPoints
                                                                      + inputProperty.SpecialOccupancyBusinessIncomePMLBuildingPoints
                                                                      + inputProperty.SpecialOccupancyNumberofOccupantsBuildingPoints;

                // Building D
                outputProperty.PrivateProtectionBuildingPointsSubtotal = inputProperty.PrivateProtectionFireSuppressionBuildingPoints
                                                                      + inputProperty.PrivateProtectionFireProtectionBuildingPoints
                                                                      + inputProperty.PrivateProtectionCentralMonitoringBuildingPoints;

                // Building E
                outputProperty.SpecificInsuranceBuildingPointsSubtotal = inputProperty.SpecificInsuranceBuildingPoints;

                // Building F
                outputProperty.PublicProtectionBuildingPointsSubtotal = inputProperty.PublicProtectionLowHazardBuildingPoints
                                                                      + inputProperty.PublicProtectionMediumHazardBuildingPoints
                                                                      + inputProperty.PublicProtectionHighHazardBuildingPoints;

                // Building G
                outputProperty.ExternalExposureBuildingPointsSubtotal = inputProperty.ExternalExposureBuildingPoints
                                                                      + inputProperty.ExternalExposureSeparationBuildingPoints;

                // Building H
                outputProperty.ConstructionBuildingPointsSubtotal = inputProperty.ConstructionBuildingPoints
                                                                  + inputProperty.ConstructionEngineeringBuildingPoints
                                                                  + inputProperty.ConstructionAttractionValueBuildingPoints;

                // Building I
                outputProperty.CommoditiesBuildingPointsSubtotal = inputProperty.CommoditiesBuildingPoints;

                // Building J
                // FloodBuildingPoints
                outputProperty.FloodBuildingPointsSubtotal = inputProperty.FloodCoveredZoneBuildingPoints1
                                                           + inputProperty.FloodCoveredZoneBuildingPoints2
                                                           + inputProperty.FloodCoveredZoneBuildingPoints3
                                                           + inputProperty.FloodCoveredZoneBuildingPoints4
                                                           + inputProperty.FloodCoveredZoneBuildingPoints5;

                // Building K
                // EarthquakeBuildingPoints
                outputProperty.EarthMovementBuildingPointsSubtotal = inputProperty.EarthMovementTerritoryBuildingPoints1
                                                                  + inputProperty.EarthMovementTerritoryBuildingPoints2
                                                                  + inputProperty.EarthMovementLimitBuildingPoints;

                // Building L
                outputProperty.ExclusionorReductionofCoverageBuildingPointsSubtotal = inputProperty.ExclusionorReductionofCoverageBuildingPoints;

                // Sub Total Content A

                outputProperty.DisasterExposureContentPointsSubtotal = inputProperty.DisasterExposureDispersionContentPoints
                                                                      + inputProperty.DisasterExposurePMLContentPoints;
                // Content B
                // WindContentsPoints
                outputProperty.ClimaticalHazardsContentPointsSubtotal = inputProperty.ClimaticalHazardsHurricaneContentPoints
                                                                      + inputProperty.ClimaticalHazardsSevereConvectiveContentPoints
                                                                      + inputProperty.ClimaticalHazardsWinterStormContentPoints;
                // + inputProperty.ClimaticalHazardsAllOtherContentPoints;
                // Content C
                outputProperty.SpecialOccupancyContentPointsSubtotal = inputProperty.SpecialOccupancyHazardsContentPoints
                                                                      + inputProperty.SpecialOccupancyProcessingContentPoints
                                                                      + inputProperty.SpecialOccupancyBusinessIncomePMLContentPoints
                                                                      + inputProperty.SpecialOccupancyNumberofOccupantsContentPoints;

                // Content D
                outputProperty.PrivateProtectionContentPointsSubtotal = inputProperty.PrivateProtectionFireSuppressionContentPoints
                                                                      + inputProperty.PrivateProtectionFireProtectionContentPoints
                                                                      + inputProperty.PrivateProtectionCentralMonitoringContentPoints;

                // Content E
                outputProperty.SpecificInsuranceContentPointsSubtotal = inputProperty.SpecificInsuranceContentPoints;

                // Content F
                outputProperty.PublicProtectionContentPointsSubtotal = inputProperty.PublicProtectionLowHazardContentPoints
                                                                      + inputProperty.PublicProtectionMediumHazardContentPoints
                                                                      + inputProperty.PublicProtectionHighHazardContentPoints;

                // Content G
                outputProperty.ExternalExposureContentPointsSubtotal = inputProperty.ExternalExposureContentPoints
                                                                      + inputProperty.ExternalExposureSeparationContentPoints;

                // Content H
                outputProperty.ConstructionContentPointsSubtotal = inputProperty.ConstructionContentPoints
                                                                  + inputProperty.ConstructionEngineeringContentPoints
                                                                  + inputProperty.ConstructionAttractionValueContentPoints;

                // Content I
                outputProperty.CommoditiesContentPointsSubtotal = inputProperty.CommoditiesContentPoints;

                // Content J
                // FloodContentsPoint
                outputProperty.FloodContentPointsSubtotal = inputProperty.FloodCoveredZoneContentPoints1
                                                           + inputProperty.FloodCoveredZoneContentPoints2
                                                           + inputProperty.FloodCoveredZoneContentPoints3
                                                           + inputProperty.FloodCoveredZoneContentPoints4
                                                           + inputProperty.FloodCoveredZoneContentPoints5;

                // Content K
                // EarthquakeContentsPoints
                outputProperty.EarthMovementContentPointsSubtotal = inputProperty.EarthMovementTerritoryContentPoints1
                                                                  + inputProperty.EarthMovementTerritoryContentPoints2
                                                                  + inputProperty.EarthMovementLimitContentPoints;

                // Content L
                outputProperty.ExclusionorReductionofCoverageContentPointsSubtotal = inputProperty.ExclusionorReductionofCoverageContentPoints;


                // Total Building and Content

                outputProperty.BuildingDefTotalPoints = outputProperty.DisasterExposureBuildingPointsSubtotal
                                                   + outputProperty.ClimaticalHazardsBuildingPointsSubtotal
                                                   + outputProperty.SpecialOccupancyBuildingPointsSubtotal
                                                   + outputProperty.PrivateProtectionBuildingPointsSubtotal
                                                   + outputProperty.SpecificInsuranceBuildingPointsSubtotal
                                                   + outputProperty.PublicProtectionBuildingPointsSubtotal
                                                   + outputProperty.ExternalExposureBuildingPointsSubtotal
                                                   + outputProperty.ConstructionBuildingPointsSubtotal
                                                   + outputProperty.CommoditiesBuildingPointsSubtotal
                                                   + outputProperty.FloodBuildingPointsSubtotal
                                                   + outputProperty.EarthMovementBuildingPointsSubtotal
                                                   + outputProperty.ExclusionorReductionofCoverageBuildingPointsSubtotal;

                outputProperty.ContentsDefTotalPoints = outputProperty.DisasterExposureContentPointsSubtotal
                                                   + outputProperty.ClimaticalHazardsContentPointsSubtotal
                                                   + outputProperty.SpecialOccupancyContentPointsSubtotal
                                                   + outputProperty.PrivateProtectionContentPointsSubtotal
                                                   + outputProperty.SpecificInsuranceContentPointsSubtotal
                                                   + outputProperty.PublicProtectionContentPointsSubtotal
                                                   + outputProperty.ExternalExposureContentPointsSubtotal
                                                   + outputProperty.ConstructionContentPointsSubtotal
                                                   + outputProperty.CommoditiesContentPointsSubtotal
                                                   + outputProperty.FloodContentPointsSubtotal
                                                   + outputProperty.EarthMovementContentPointsSubtotal
                                                   + outputProperty.ExclusionorReductionofCoverageContentPointsSubtotal;
            }

            #endregion
        }

        /// <summary>
        /// Calculate Equipment Breakdown premium.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected virtual void CalculateEquipmentBreakdownPremium(RaterFacadeModel model)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

                this.logger.Info("PropertyBaseService.CalculateEquipmentBreakdownPremium :: Started");

                // Step-5 Getting EquipmentBreakdownDeductibleFactor from EBDeductibleFactors table
                outputProperty.EquipmentBreakdownDeductibleFactor = this.propertyDataAccess.GetEquipmentBreakdownDeductibleFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.EquipmentBreakdownDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                //Step C.2    Equipment Breakdown Limit = Step 1 + Step 3
                outputProperty.EquipmentBreakdownLimit = inputProperty.BusinessIncomeAndExtraExpenseLimit
                                                                    + outputProperty.TotalTIV; ///TODO

                // Referred Equipment Breakdown coverage calculation
                if (inputProperty.ReferredEquipmentBreakdownCoverage == true)
                {
                    //Step C.1	Equipment Breakdown Total Premium	=	Input field                    

                    if (outputProperty.EquipmentBreakdownDeductibleFactor == 0)
                    {
                        throw new Exception("OutputModel.Property.EquipmentBreakdownDeductibleFactor cannot be zero!");
                    }

                    //Step c.3 = (Step C.1 *100)/(Step 5 * Step C.2)
                    outputProperty.EquipmentBreakdownRate = ((inputProperty.InputEquipmentBreakdownTotalPremium
                                                                         * 100)
                                                                         / (outputProperty.EquipmentBreakdownLimit
                                                                         * outputProperty.EquipmentBreakdownDeductibleFactor)
                                                                         );

                    outputProperty.EquipmentBreakdownRate = Math.Round(outputProperty.EquipmentBreakdownRate, 4, MidpointRounding.AwayFromZero);
                }
                else
                {
                    // Step-2 ((Input field/100))
                    // EquipmentBreakdownIRPMFactor : (EquipmentBreakdownIRPM / 100)
                    outputProperty.EquipmentBreakdownIRPMFactor = inputProperty.IRPM / 100;

                    // Step-4 Getting EquipmentBreakdownLimitFactor from EBLimitFactors table
                    outputProperty.EquipmentBreakdownLimitFactor = this.propertyDataAccess.GetEquipmentBreakdownLimitFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);


                    // Step-6 Getting BusinessIncomeAndExtraExpenseDeductibleFactor from EBBIDeductibleFactors table
                    outputProperty.EquipmentBreakdownBusinessIncomeAndExtraExpenseDeductibleFactor = this.propertyDataAccess.GetBusinessIncomeAndExtraExpenseDeductibleFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.BusinessIncomeAndExtraExpenseDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step-7 Getting PollutantCleanUpLimitFactor from EBCoverageLimitFactors
                    outputProperty.PollutantCleanUpLimitFactor = this.propertyDataAccess.GetPollutantCleanUpLimitFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, inputProperty.PollutantCleanUpLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step-8 Getting RefrigerantContaminationLimitFactor from EBCoverageLimitFactors
                    outputProperty.RefrigerantContaminationLimitFactor = this.propertyDataAccess.GetRefrigerantContaminationLimitFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, inputProperty.RefrigerantContaminationLimit, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    if (!string.IsNullOrEmpty(inputProperty.SelectedSpoilageType))
                    {
                        // Step-9 Getting SpoilageType1LimitFactor from EBCoverageLimitFactors
                        outputProperty.EBSpoilageLimitFactor = this.propertyDataAccess.GetSpoilageLimitFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, inputProperty.EBSpoilageLimit, inputProperty.SelectedSpoilageType, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                    }

                    // Step-13 (Step 3/100)* Step 4 * Step 5
                    // EquipmentBreakdownBuildingOrContentsPremium : ((TotalTIV / 100) * EquipmentBreakdownDeductibleFactor * EquipmentBreakdownLimitFactor)
                    outputProperty.EquipmentBreakdownBuildingOrContentsPremium = ((outputProperty.TotalTIV / 100) * outputProperty.EquipmentBreakdownDeductibleFactor * outputProperty.EquipmentBreakdownLimitFactor);

                    // Step-14 ((Step 1/100) * Step 4 * Step 6)
                    // EquipmentBreakdownBusinessIncomePremium : ((BusinessIncomeAndExtraExpenseLimit / 100) * BusinessIncomeAndExtraExpenseDeductibleFactor * EquipmentBreakdownLimitFactor)
                    outputProperty.EquipmentBreakdownBusinessIncomePremium = ((inputProperty.BusinessIncomeAndExtraExpenseLimit / 100) * outputProperty.EquipmentBreakdownBusinessIncomeAndExtraExpenseDeductibleFactor * outputProperty.EquipmentBreakdownLimitFactor);

                    // Read the Table -> Minimum Premium to get the EB Minimum Premium value.
                    outputProperty.EquipmentBreakdownMinimumPremium = propertyDataAccess.GetPropertyMinimumPremium(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    //Equipment Breakdown w/o Spoilage Deductible  Calculation
                    if (inputProperty.SpoilageDeductible == 0 && inputProperty.SpoilageMinimumDeductible == 0)
                    {
                        outputProperty.EquipmentBreakdownSpoilagePercentageDeductibleFactor = 1;   // Default set 1
                        // Step A.1 - Get system calculated value : ((Step 13 + Step 14) * (1+Step 7 + Step 8 +Step 9 + Step 10)) * Step 2
                        outputProperty.EquipmentBreakdownTotalPremium = ((outputProperty.EquipmentBreakdownBuildingOrContentsPremium
                                                                                     + outputProperty.EquipmentBreakdownBusinessIncomePremium)
                                                                                     * (1
                                                                                     + outputProperty.PollutantCleanUpLimitFactor
                                                                                     + outputProperty.RefrigerantContaminationLimitFactor
                                                                                     + outputProperty.EBSpoilageLimitFactor))
                                                                                     * outputProperty.EquipmentBreakdownIRPMFactor;

                        outputProperty.EquipmentBreakdownTotalPremium = Math.Round(outputProperty.EquipmentBreakdownTotalPremium, MidpointRounding.AwayFromZero);
                    }

                    //Equipment Breakdown with Spoilage Deductible  Calculation
                    else
                    {
                        // Step-11 Getting EquipmentBreakdownSpoilagePercentageDeductibleFactor from EBSpoilagePercentageDeductible
                        outputProperty.EquipmentBreakdownSpoilagePercentageDeductibleFactor = propertyDataAccess.GetEquipmentBreakdownSpoilagePercentageDeductibleFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, inputProperty.SpoilageDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                        // Step-12 Getting EquipmentBreakdownSpoilageDollarDeductible from EBSpoilageDollarDeductible
                        outputProperty.EquipmentBreakdownSpoilageDollarDeductible = propertyDataAccess.GetEquipmentBreakdownSpoilageDollarDeductible(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.LineOfBusiness, inputProperty.SpoilageMinimumDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                        // Step-15 ((Step 13 + Step 14) * (1+Step 7 + Step 8))
                        // Premium1 : (EquipmentBreakdownBuildingOrContentsPremium + EquipmentBreakdownBusinessIncomePremium) * (1 + PollutantCleanUpLimitFactor + RefrigerantContaminationLimitFactor)
                        outputProperty.Premium1 = (outputProperty.EquipmentBreakdownBuildingOrContentsPremium
                                                             + outputProperty.EquipmentBreakdownBusinessIncomePremium)
                                                             * (1
                                                             + outputProperty.PollutantCleanUpLimitFactor
                                                             + outputProperty.RefrigerantContaminationLimitFactor);

                        // Step-16 (Step 15 * (Step 9 + Step 10) * Step 11 * Step 12)
                        // Premium2 : Premium1 * (SpoilageType1LimitFactor + SpoilageType2LimitFactor) * EquipmentBreakdownSpoilagePercentageDeductibleFactor * EquipmentBreakdownSpoilageDollarDeductible
                        outputProperty.Premium2 = outputProperty.Premium1
                                                             * (outputProperty.EBSpoilageLimitFactor)
                                                             * outputProperty.EquipmentBreakdownSpoilagePercentageDeductibleFactor
                                                             * outputProperty.EquipmentBreakdownSpoilageDollarDeductible;

                        // Step-B.1 ((Step 15 + Step 16) * Step 2)
                        // EquipmentBreakdownTotalPremium : ((Premium1 + Premium2) * EquipmentBreakdownIRPMFactor)
                        outputProperty.EquipmentBreakdownTotalPremium = (outputProperty.Premium1
                                                                                    + outputProperty.Premium2)
                                                                                    * outputProperty.EquipmentBreakdownIRPMFactor;

                        outputProperty.EquipmentBreakdownTotalPremium = Math.Round(outputProperty.EquipmentBreakdownTotalPremium, MidpointRounding.AwayFromZero);
                    }

                    //Minimum premium check
                    if (outputProperty.EquipmentBreakdownTotalPremium < outputProperty.EquipmentBreakdownMinimumPremium)
                    {
                        outputProperty.EquipmentBreakdownTotalPremium = outputProperty.EquipmentBreakdownMinimumPremium;
                    }
                }
                this.logger.Info("PropertyBaseService.CalculateEquipmentBreakdownPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyBaseService.CalculateEquipmentBreakdownPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate WindFloodEarthquake premium.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected virtual void CalculateWindFloodEarthquakePremium(RaterFacadeModel model)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

                this.logger.Info("PropertyBaseService.CalculateWindFloodEarthquakePremium :: Started");
                
                // Step 9 (Input field on UI) : 
                // Step 10 (Refer to the lookup table to get the LCM factor)
                outputProperty.LCMFactor = this.propertyDataAccess.GetNormalLossRateLCMFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "Normal Loss Rate LCM", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step 11 (Input field on UI) : Normal Loss TIV Value

                // Calculate Building Points
                // Step 17 (Input field on UI) : WindBuildingPoints
                // Step 18 (Input field on UI) : FloodBuildingPoints
                // Step 19 (Input field on UI) : EarthquakeBuildingPoints

                // Step 21 (Step 17 + Step 18 + Step 19) : PerilBuildingPoints
                outputProperty.PerilBuildingPoints = outputProperty.ClimaticalHazardsBuildingPointsSubtotal
                                                                + outputProperty.FloodBuildingPointsSubtotal
                                                                + outputProperty.EarthMovementBuildingPointsSubtotal;

                // Step 22 ( Total Building Limit ) BuildingTIV

                // Step 23 (Step 20 - Step 21) : BuildingDefPointsNoPerils (BuildingDefPoints - PerilBuildingPoints)
                outputProperty.BuildingDefPointsNoPerils = outputProperty.BuildingDefTotalPoints
                                                                       - outputProperty.PerilBuildingPoints;

                // Step 24
                if (outputProperty.BuildingDefPointsNoPerils > this.buildingDefPointsNoPerilsLimit)
                {
                    // Getting charge from MiscFactors table sheet.
                    outputProperty.BuildingAddtlChargeRateNoPerils = this.propertyDataAccess.GetBuildingAdditionalDefCharge(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, outputProperty.BuildingDefPointsNoPerils, "Increased Def Point Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }
                else
                {
                    // Getting BuildingAddtlDefCharge from MajorLossRateCharges lookup table
                    outputProperty.BuildingAddtlChargeRateNoPerils = this.propertyDataAccess.GetBuildingMajorLossRateCharge(outputProperty.BuildingDefPointsNoPerils, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }

                // Calculate Contents Points
                // Step 25 (Input field on UI) : WindContentsPoints
                // Step 26 (Input field on UI) : FloodContentsPoint
                // Step 27 (Input field on UI) : EarthquakeContentsPoints

                // Step 29 (Step 25 + Step 26+ Step 27) : PerilContentsPoints
                outputProperty.PerilContentsPoints = outputProperty.ClimaticalHazardsContentPointsSubtotal
                                                      + outputProperty.FloodContentPointsSubtotal
                                                      + outputProperty.EarthMovementContentPointsSubtotal;

                // Step 30 ( Total Content Limit )
                // Step 31 (Step 28 - Step 29) : ContentsDefTotalPointsNoPerils (ContentsDefTotalPoints - PerilContentsPoints)
                outputProperty.ContentsDefTotalPointsNoPerils = outputProperty.ContentsDefTotalPoints - outputProperty.PerilContentsPoints;

                // Step 32
                if (outputProperty.ContentsDefTotalPointsNoPerils > this.contentDefPointsNoPerilsLimit)
                {
                    // Getting charge from MiscFactors table sheet.
                    outputProperty.ContentsAddtlChargeRateNoPerils = this.propertyDataAccess.GetContentsAdditionalDefCharge(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness,outputProperty.ContentsDefTotalPointsNoPerils, "Increased Def Point Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }
                else
                {
                    // Getting BuildingAddtlDefCharge from MajorLossRateCharges lookup table
                    outputProperty.ContentsAddtlChargeRateNoPerils = this.propertyDataAccess.GetContentsMajorLossRateCharge(outputProperty.ContentsDefTotalPointsNoPerils, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }

                #region Step A - Steps to calculate Wind/Flood/Earthquake Building Premium

                // Step A.1 ((Step 1 + Step 24)* Step 5 * Step 6 * Step 7 * Step 8) : BuildingModifiedMLRNoPerils ((BuildingBaseMLR + BuildingAddtlChargeRateNoPerils) * AOPDeductibleFacto * CoinsuranceFactor * MarginClauseFactor * ValuationFactor)
                outputProperty.BuildingModifiedMLRNoPerils = (outputProperty.BuildingBaseMLR
                                                                          + outputProperty.BuildingAddtlChargeRateNoPerils)
                                                                          * outputProperty.AOPDeductibleFactor
                                                                          * outputProperty.CoinsuranceFactor
                                                                          * outputProperty.MarginClauseFactor
                                                                          * outputProperty.ValuationFactor;
                // Round it to 3 digit
                outputProperty.BuildingModifiedMLRNoPerils = Math.Round(outputProperty.BuildingModifiedMLRNoPerils, 3, MidpointRounding.AwayFromZero);

                // Step A.2 (Step 14 + Step A.1) : BuildingCombinedRateNoPerils (ModifiedNormalLossRate + BuildingModifiedMLRNoPerils)
                outputProperty.BuildingCombinedRateNoPerils = outputProperty.ModifiedNormalLossRate
                                                                         + outputProperty.BuildingModifiedMLRNoPerils;

                // Step A.3 ((Step A.2 * Step 22)/100) : BuildingPremiumNoPerils ((BuildingCombinedRateNoPerils * BuildingTIV) / 100)
                outputProperty.BuildingPremiumNoPerils = (outputProperty.BuildingCombinedRateNoPerils
                                                                     * inputProperty.BuildingTIV)
                                                                     / 100;

                // Round it to 2 digit
                outputProperty.BuildingPremiumNoPerils = Math.Round(outputProperty.BuildingPremiumNoPerils, 2, MidpointRounding.AwayFromZero);

                // Step A.4 ((Step 22 * Step 15)/100) : BuildingPremiumTotal ((BuildingValue * BuildingFinalRate) / 100)
                outputProperty.BuildingPremiumTotal = (inputProperty.BuildingTIV
                                                                  * outputProperty.BuildingFinalRate)
                                                                  / 100;
                // Round it to 2 digit
                outputProperty.BuildingPremiumTotal = Math.Round(outputProperty.BuildingPremiumTotal, 2, MidpointRounding.AwayFromZero);

                // Step A.5 (Step A.4 - Step A.3) : BuildingPremiumForPerils (BuildingPremiumTotal - BuildingPremiumNoPerils)
                outputProperty.BuildingPremiumForPerils = outputProperty.BuildingPremiumTotal
                                                                      - outputProperty.BuildingPremiumNoPerils;

                // Round it to 2 digit
                outputProperty.BuildingPremiumForPerils = Math.Round(outputProperty.BuildingPremiumForPerils, 2, MidpointRounding.AwayFromZero);

                #endregion

                #region Step B -Steps to calculate Wind / Flood / Earthquake Content Premium

                // Step B.1 ((Step 3 + Step 32)* Step 5 * Step 6 * Step 7 * Step 8) : ContentsModifiedMLRNoPerils ((ContentsBaseMLR + ContentsAddtlChargeRateNoPerils) * AOPDeductibleFactor * CoinsuranceFactor * MarginClauseFactor * ValuationFactor)
                outputProperty.ContentsModifiedMLRNoPerils = (outputProperty.ContentsBaseMLR
                                                                         + outputProperty.ContentsAddtlChargeRateNoPerils)
                                                                         * outputProperty.AOPDeductibleFactor
                                                                         * outputProperty.CoinsuranceFactor
                                                                         * outputProperty.MarginClauseFactor
                                                                         * outputProperty.ValuationFactor;

                // Round it to 3 digit
                outputProperty.ContentsModifiedMLRNoPerils = Math.Round(outputProperty.ContentsModifiedMLRNoPerils, 3, MidpointRounding.AwayFromZero);

                // Step B.2 (Step 14 + Step B.1) : ContentsCombinedRateNoPerils (ModifiedNormalLossRate + ContentsModifiedMLRNoPerils)
                outputProperty.ContentsCombinedRateNoPerils = outputProperty.ModifiedNormalLossRate
                                                                          + outputProperty.ContentsModifiedMLRNoPerils;

                // Step B.3 ((Step B.2 * Step 30)/100) : ContentsPremiumNoPerils ((ContentsCombinedRateNoPerils * ContentsValue) / 100)
                outputProperty.ContentsPremiumNoPerils = (outputProperty.ContentsCombinedRateNoPerils
                                                                     * inputProperty.ContentTIV)
                                                                     / 100;
                // Round it to 2 digit
                outputProperty.ContentsPremiumNoPerils = Math.Round(outputProperty.ContentsPremiumNoPerils, 2, MidpointRounding.AwayFromZero);

                // Step B.4 ((Step 30 * Step 16)/100) : ContentsPremiumTotal ((ContentsValue * ContentsFinalRate) / 100)
                outputProperty.ContentsPremiumTotal = (inputProperty.ContentTIV
                                                                  * outputProperty.ContentsFinalRate)
                                                                  / 100;

                // Round it to 2 digit
                outputProperty.ContentsPremiumTotal = Math.Round(outputProperty.ContentsPremiumTotal, 2, MidpointRounding.AwayFromZero);

                // Step B.5 (Step B.4 - Step B.3) : ContentsPremiumForPerils (ContentsPremiumTotal - ContentsPremiumNoPerils)
                outputProperty.ContentsPremiumForPerils = outputProperty.ContentsPremiumTotal
                                                                      - outputProperty.ContentsPremiumNoPerils;

                // Round it to 2 digit
                outputProperty.ContentsPremiumForPerils = Math.Round(outputProperty.ContentsPremiumForPerils, 2, MidpointRounding.AwayFromZero);

                #endregion

                if (inputProperty.WindstormAndHailCoverage || inputProperty.FloodCoverage || inputProperty.EarthquakeCoverage)
                {
                    if (outputProperty.PerilBuildingPoints == 0)
                    {
                        throw new Exception("OutputModel.Property.PerilBuildingPoints cannot be zero!");
                    }
                    if (outputProperty.PerilContentsPoints == 0)
                    {
                        throw new Exception("OutputModel.Property.PerilContentsPoints cannot be zero!");
                    }
                }

                #region Step C - WIND PREMIUM CALCULATION

                // Execute Step C only when Included radio button is selected for Windstorm & Hail Coverage
                if (inputProperty.WindstormAndHailCoverage == true)
                {
                    // Step C.1 ((Step 17/Step 21)*Step A.5) : WindBuildingPremium ((WindBuildingPoints / PerilBuildingPoints) * BuildingPremiumForPerils)
                    outputProperty.WindBuildingPremium = ((outputProperty.ClimaticalHazardsBuildingPointsSubtotal
                                                                     / outputProperty.PerilBuildingPoints)
                                                                     * outputProperty.BuildingPremiumForPerils);

                    // Round to nearest digit
                    outputProperty.WindBuildingPremium = Math.Round(outputProperty.WindBuildingPremium, MidpointRounding.AwayFromZero);

                    // Step C.2 ((Step 25/Step 29)*Step B.5) : WindContentPremium ((WindContentsPoints / PerilContentsPoints) * ContentsPremiumForPerils)
                    outputProperty.WindContentPremium = ((outputProperty.ClimaticalHazardsContentPointsSubtotal
                                                                    / outputProperty.PerilContentsPoints)
                                                                    * outputProperty.ContentsPremiumForPerils);

                    // Round to nearest digit
                    outputProperty.WindContentPremium = Math.Round(outputProperty.WindContentPremium, MidpointRounding.AwayFromZero);

                    // Step C.3 (Step C.1 + Step C.2) : WINDTOTALPREMIUM (WindBuildingPremium + WindContentPremium)
                    outputProperty.WindTotalPremium = (outputProperty.WindBuildingPremium + outputProperty.WindContentPremium);

                    // Round to nearest digit
                    outputProperty.WindTotalPremium = Math.Round(outputProperty.WindTotalPremium, MidpointRounding.AwayFromZero);

                }
                #endregion

                #region Step D - FLOOD PREMIUM CALCULATION

                // Execute Step D only when Included radio button is selected for Flood Coverage
                if (inputProperty.FloodCoverage == true)
                {
                    // Step D.1 ((Step 18/Step 21)*Step A.5) : FloodBuildingPremium ((FloodBuildingPoints / PerilBuildingPoints) * BuildingPremiumForPerils)
                    outputProperty.FloodBuildingPremium = ((outputProperty.FloodBuildingPointsSubtotal / outputProperty.PerilBuildingPoints) * outputProperty.BuildingPremiumForPerils);

                    outputProperty.FloodBuildingPremium = Math.Round(outputProperty.FloodBuildingPremium, MidpointRounding.AwayFromZero);

                    // Step D.2 ((Step 26/Step 29)*Step B.5) : FloodContentPremium ((FloodContentPremium / PerilContentsPoints) * ContentsPremiumForPerils)
                    outputProperty.FloodContentPremium = ((outputProperty.FloodContentPointsSubtotal
                                                                      / outputProperty.PerilContentsPoints)
                                                                      * outputProperty.ContentsPremiumForPerils);

                    outputProperty.FloodContentPremium = Math.Round(outputProperty.FloodContentPremium, MidpointRounding.AwayFromZero);

                    // Step D.3 (Step D.1 + Step D.2) : FLOODTOTALPREMIUM (FloodBuildingPremium + FloodContentPremium)
                    outputProperty.FloodTotalPremium = (outputProperty.FloodBuildingPremium
                                                                   + outputProperty.FloodContentPremium);

                    outputProperty.FloodTotalPremium = Math.Round(outputProperty.FloodTotalPremium, MidpointRounding.AwayFromZero);
                }

                #endregion

                #region Step E -EARTHQUAKE PREMIUM CALCULATION
                // Execute Step E only when Included radio button is selected for Earthquake Coverage
                if (inputProperty.EarthquakeCoverage == true)
                {
                    // Step E.1 ((Step 19/Step 21)*Step A.5) : EarthquakeBuildingPremium ((EarthquakeBuildingPoints / PerilBuildingPoints) * BuildingPremiumForPerils)
                    outputProperty.EarthquakeBuildingPremium = ((outputProperty.EarthMovementBuildingPointsSubtotal
                                                                            / outputProperty.PerilBuildingPoints)
                                                                            * outputProperty.BuildingPremiumForPerils);

                    outputProperty.EarthquakeBuildingPremium = Math.Round(outputProperty.EarthquakeBuildingPremium, MidpointRounding.AwayFromZero);

                    // Step E.2 ((Step 27/Step 29)*Step B.5) : EarthquakeContentPremium ((EarthquakeContentsPoints / PerilContentsPoints) * ContentsPremiumForPerils)
                    outputProperty.EarthquakeContentPremium = ((outputProperty.EarthMovementContentPointsSubtotal
                                                                          / outputProperty.PerilContentsPoints)
                                                                          * outputProperty.ContentsPremiumForPerils);

                    outputProperty.EarthquakeContentPremium = Math.Round(outputProperty.EarthquakeContentPremium, MidpointRounding.AwayFromZero);

                    // Step E.3 (Step E.1 + Step E.2) : EARTHQUAKETOTALPREMIUM (EarthquakeBuildingPremium + EarthquakeContentPremium)
                    outputProperty.EarthquakeTotalPremium = (outputProperty.EarthquakeBuildingPremium + outputProperty.EarthquakeContentPremium);

                    outputProperty.EarthquakeTotalPremium = Math.Round(outputProperty.EarthquakeTotalPremium, MidpointRounding.AwayFromZero);
                }

                // Add AllOther Content & Building Points in Subtotal for Display.
                outputProperty.ClimaticalHazardsBuildingPointsSubtotal = outputProperty.ClimaticalHazardsBuildingPointsSubtotal + inputProperty.ClimaticalHazardsAllOtherBuildingPoints;
                outputProperty.ClimaticalHazardsContentPointsSubtotal = outputProperty.ClimaticalHazardsContentPointsSubtotal + inputProperty.ClimaticalHazardsAllOtherBuildingPoints;

                #endregion



                this.logger.Info("PropertyBaseService.CalculateWindFloodEarthquakePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyBaseService.CalculateWindFloodEarthquakePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate OptionalCoverage premium.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected virtual void CalculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

                outputProperty.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageOutputModel();
                outputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageOutputModel = new List<PropertyOptionalOtherCoverageOutputModel>();
                var outputOptionalOthersCoverages = outputProperty.PropertyOptionalCoveragesModel;               

                this.logger.Info("PropertyBaseService.CalculateOptionalCoveragePremium :: Started");

                if (inputProperty.PropertyOptionalCoveragesModel.IsAdditionalCoveredPropertyOptionalCoverageSelected)
                {
                    outputProperty.OptionalCoverageTotalPremium = outputProperty.OptionalCoverageTotalPremium + inputProperty.PropertyOptionalCoveragesModel.AdditionalCoveredPropertyPremium;
                    outputProperty.PropertyOptionalCoveragesModel.AdditionalCoveredPropertyPremium= inputProperty.PropertyOptionalCoveragesModel.AdditionalCoveredPropertyPremium;
                }

                if (inputProperty.PropertyOptionalCoveragesModel.IsAlabamaWindAndHailCertificateCreditCoverageSelected)
                {
                    outputProperty.OptionalCoverageTotalPremium = outputProperty.OptionalCoverageTotalPremium + inputProperty.PropertyOptionalCoveragesModel.AlabamaWindAndHailCertificateCreditPremium;
                    outputProperty.PropertyOptionalCoveragesModel.AlabamaWindAndHailCertificateCreditPremium = inputProperty.PropertyOptionalCoveragesModel.AlabamaWindAndHailCertificateCreditPremium;
                }

                if (inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel != null && inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel.Count > 0)
                {
                    inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel=inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel.Where(x => x.IsOptionalCoverageSelected).ToList();
                    
                    // Calculating OptionalCoverageTotalPremium
                    foreach (var optionalCoverage in inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                    {
                        // Step 3 ((Step 1 /1000) * Step 2) OtherPremium : (OtherLimit / 1000) * OtherRate
                        if (optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER" && optionalCoverage.RatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                        {
                            optionalCoverage.Premium = ((optionalCoverage.Limit / 1000) * optionalCoverage.Rate);
                        }

                        // Step 3 ((Step 1 /1000) * Step 2) OtherPremium : (OtherLimit / 100) * OtherRate
                        else if (optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER" && optionalCoverage.RatingBasis.ToUpper() == "PER 100 OF LIMIT")
                        {
                            optionalCoverage.Premium = ((optionalCoverage.Limit / 100) * optionalCoverage.Rate);
                        }

                        optionalCoverage.Premium = Math.Round(optionalCoverage.Premium, MidpointRounding.AwayFromZero);

                        outputProperty.OptionalCoverageTotalPremium = outputProperty.OptionalCoverageTotalPremium + optionalCoverage.Premium;
                        outputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageOutputModel.Add(new PropertyOptionalOtherCoverageOutputModel()
                        {
                            Id = optionalCoverage.Id,
                            Premium = optionalCoverage.Premium
                        });
                    }
                }
                
                this.logger.Info("PropertyBaseService.CalculateOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyBaseService.CalculateOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate the final property premium.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected virtual void CalculateFinalPropertyPremium(RaterFacadeModel model)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

                //TIV + Additional Benefits.
                outputProperty.TIVAndAdditionalBenefits = outputProperty.TIVAndAdditionalBenefits + outputProperty.TotalTIV;

                this.logger.Info("PropertyBaseService.CalculateFinalPropertyPremium :: Started");

                // Equipment Breakdown Premium  from Step II -> Step A.1 and Step II -> Step B.1
                if (inputProperty.ReferredEquipmentBreakdownCoverage == true)
                {
                    //outputProperty.EquipmentBreakdown = inputProperty.InputEquipmentBreakdownTotalPremium;
                    outputProperty.EquipmentBreakdownTotalPremium = inputProperty.InputEquipmentBreakdownTotalPremium;
                }
                else
                {
                    //outputProperty.EquipmentBreakdown = outputProperty.EquipmentBreakdownTotalPremium;
                    outputProperty.EquipmentBreakdownTotalPremium = outputProperty.EquipmentBreakdownTotalPremium;
                }

                // Building BPP Premium from Step I -> Step 19
                // BuildingAndContents = BuildingBPPPremium;

                // (Policy Expiration Date  -Transaction Effective Date)/(Policy Expiration Date - Policy Effective  Date)
                if ((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).TotalDays == 0)
                {
                    throw new Exception("Difference between PolicyHeaderModel.PolicyExpirationDate and PolicyHeaderModel.PolicyEffectiveDate cannot be zero!");
                }

                outputProperty.ProRatafactor = Math.Round(Convert.ToDecimal((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate).TotalDays / (model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).TotalDays), 2, MidpointRounding.AwayFromZero);

                // Read Minimum Premium lookup table to get Minimum Premium
                outputProperty.LOBMinimumPremium = this.propertyDataAccess.GetLOBTotalPremium(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step A- Base Premium Calculation. 
                // BasePremiumCalculation : ((BuildingAndContents + EquipmentBreakdown) * ProRatafactor)
                outputProperty.BasePremium = ((outputProperty.BuildingBPPPremium
                                               + outputProperty.EquipmentBreakdownTotalPremium)
                                               * outputProperty.ProRatafactor);

                outputProperty.BasePremium = Math.Round(outputProperty.BasePremium, MidpointRounding.AwayFromZero);

                // Step B.1- Non-Modified Premium Calculation 
                // NonModifiedPremiumCalculation : inputProperty.OptionalCoverageTotalPremium
                //Step B.2 (B.1 * ProRatafactor) 
                outputProperty.NonModifiedPremium = (outputProperty.OptionalCoverageTotalPremium
                                                                * outputProperty.ProRatafactor);

                outputProperty.NonModifiedPremium = Math.Round(outputProperty.NonModifiedPremium, MidpointRounding.AwayFromZero);

                // Property360 = Sum of 360 Coverage Modifications Premium + Sum of Golf Courses coverages Premium + Sum of Optional Coverages Premium
                // BusinessIncomeAndExtraExpenseCoveragePremium = Step IV - 360 Coverage
                // LargeRiskFactor = Input field

                // Step C -Manual Premium Calculation
                // ManualPremiumCalculation : (BuildingAndContents + BusinessIncomeAndExtraExpenseCoveragePremium + Property360Premiums) * LargeRiskFactor) + EquipmentBreakdown + NonModifiedPremium) * ProRatafactor
                outputProperty.ManualPremium = (((((outputProperty.BuildingBPPPremium
                                                  + outputProperty.BusinessIncomeAndExtraExpense360CoveragePremium
                                                  + outputProperty.Property360TotalPremiums)
                                                  * inputProperty.LargeRiskFactor)
                                                  + outputProperty.EquipmentBreakdownTotalPremium)
                                                  + outputProperty.NonModifiedPremium)
                                                  * outputProperty.ProRatafactor);

                outputProperty.ManualPremium = Math.Round(outputProperty.ManualPremium, MidpointRounding.AwayFromZero);

                // Step C.8
                // "This step will be executed only If calculated Manual Premium in step C.7 < LOB Minimum Premium"
                if (outputProperty.ManualPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.ManualPremium = outputProperty.LOBMinimumPremium;
                }

                // Step D - Tier Premium Calculation
                // Read "Misc' table for 'Tier Factor' as "Factor Type" by passing State, LOB, Effective date.
                outputProperty.TierFactor = this.propertyDataAccess.GetMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "Tier Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // TierPremiumCalculation : ((ManualPremiumCalculation - NonModifiedPremiumCalculation) * TierFactor) + NonModifiedPremiumCalculation
                outputProperty.TierPremium = (((outputProperty.ManualPremium
                                                - outputProperty.NonModifiedPremium)
                                                * outputProperty.TierFactor)
                                                + outputProperty.NonModifiedPremium);

                outputProperty.TierPremium = Math.Round(outputProperty.TierPremium, MidpointRounding.AwayFromZero);

                // Step D. 5
                // "This step will be executed only If calculated Tier Premium in step D.4 < LOB Minimum Premium"
                if (outputProperty.TierPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.TierPremium = outputProperty.LOBMinimumPremium;
                }

                // Step E - IRPM Premium Calculation
                // Read "Misc' table for 'IRPM Factor' as "Factor Type" by passing State, LOB, Effective date.
                outputProperty.IRPMFactor = this.propertyDataAccess.GetMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "IRPM Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // IRPMPremiumCalculation : ((TierPremiumCalculation - NonModifiedPremiumCalculation) * IRPMFactor) + NonModifiedPremiumCalculation
                outputProperty.IRPMPremium = (((outputProperty.TierPremium
                                                         - outputProperty.NonModifiedPremium)
                                                         * outputProperty.IRPMFactor)
                                                         + outputProperty.NonModifiedPremium);

                outputProperty.IRPMPremium = Math.Round(outputProperty.IRPMPremium, MidpointRounding.AwayFromZero);

                // Step E.5
                //"This step will be executed only If calculated IRPM Premium in step E.4 < LOB Minimum Premium"
                if (outputProperty.IRPMPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.IRPMPremium = outputProperty.LOBMinimumPremium;
                }

                // Step F - Other Mod Premium Calculation
                // Read "Misc' table for 'Other Mod' as "Factor Type" by passing State, LOB, Effective date.
                inputProperty.OtherModFactor = this.propertyDataAccess.GetMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "Other Mod", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // OtherModPremiumCalculation : ((IRPMPremiumCalculation - NonModifiedPremiumCalculation) * OtherModFactor) + NonModifiedPremiumCalculation
                outputProperty.OtherModPremium = (((outputProperty.IRPMPremium
                                                    - outputProperty.NonModifiedPremium)
                                                    * inputProperty.OtherModFactor)
                                                    + outputProperty.NonModifiedPremium);

                outputProperty.OtherModPremium = Math.Round(outputProperty.OtherModPremium, MidpointRounding.AwayFromZero);

                // Step F.5
                // "This step will be executed only If calculated Other Mod Premium in step F.4 < LOB Minimum Premium"
                if (outputProperty.OtherModPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.OtherModPremium = outputProperty.LOBMinimumPremium;
                }

                if (model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage)
                {
                    // Step G - Terrorism Premium Calculation
                    // Read the terrorism Factor based on the State, LOB & Effective Date selected in a policy.
                    outputProperty.TerrorismFactor = this.propertyDataAccess.GetTerrorismFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // TerrorismPremiumCalculation : (OtherModPremiumCalculation * TerrorismFactor)
                    outputProperty.TerrorismPremium = (outputProperty.OtherModPremium
                                                                  * outputProperty.TerrorismFactor);

                    outputProperty.TerrorismPremium = Math.Round(outputProperty.TerrorismPremium, MidpointRounding.AwayFromZero);
                }

                // Step H - Modified Premium Calculation
                // ModifiedPremiumCalculation : (OtherModPremiumCalculation + TerrorismPremium)
                outputProperty.ModifiedPremium = (outputProperty.OtherModPremium + outputProperty.TerrorismPremium);

                outputProperty.ModifiedPremium = Math.Round(outputProperty.ModifiedPremium, MidpointRounding.AwayFromZero);

                // "This step will be executed only If calculated Modified Premium in step H.2 < LOB Minimum Premium"
                if (outputProperty.ModifiedPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.ModifiedPremium = outputProperty.LOBMinimumPremium;
                }

                // Property schedule rating calculation
                if (model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.NEWBUSINESS || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.RENEWAL || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.ENDORSEMENT)
                {
                    if (inputProperty.ScheduleRatingInputModels != null && inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels != null)
                    {
                        this.CalculateSchedulePremium(model);
                    }
                }

                var isPackagePolicy = this.IsPackagePolicy(model.RaterInputFacadeModel.LineOfBusiness);

                // Step I -NY Fire Insurance Fee                
                if (model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.MN &&
                    ((!isPackagePolicy && (model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.NEWBUSINESS || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType == TransactionTypeConstant.RENEWAL)) ||
                    (isPackagePolicy && (model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.NEWBUSINESS || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.RENEWAL || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.ENDORSEMENT))))
                {
                    // Step I.1
                    outputProperty.FireSafetySurchargeRate = this.propertyDataAccess.GetMNFireSafetySurcharge(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.LineOfBusiness, "MN Fire Safety Surcharge Rate", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate);
                    // Step I.2
                    outputProperty.FireSafetySurcharge = (outputProperty.OtherModPremium
                                                                     * outputProperty.FireSafetySurchargeRate);

                    outputProperty.FireSafetySurcharge = Math.Round(outputProperty.FireSafetySurcharge, 2, MidpointRounding.AwayFromZero);
                }

                this.logger.Info("PropertyBaseService.CalculateFinalPropertyPremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyBaseService.CalculateFinalPropertyPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region Property 360

        /// <summary>
        /// CalculateProperty360CoveragePremium
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private protected virtual void CalculateProperty360CoveragePremium(RaterFacadeModel model, Dictionary<string, decimal> additionalBenefits)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;
                
                this.logger.Info("PropertyBaseService.CalculateProperty360CoveragePremium :: Started");

                // Step A- Building Final Rate = Output of Step I - Building BPP Premium -> Step 17
                // Step B- Content Final Rate = Output of Step I - Building BPP Premium -> Step 18

                // Step C- BI & EE Rate
                decimal v1 = Math.Round(this.propertyDataAccess.GetMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "BI and EE Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate), 3, MidpointRounding.AwayFromZero);
                outputProperty.Property360OutputModel.BusinessIncomeAndExtraExpenseRate = outputProperty.BuildingFinalRate * v1;
                outputProperty.Property360OutputModel.BusinessIncomeAndExtraExpenseRate = Math.Round(outputProperty.Property360OutputModel.BusinessIncomeAndExtraExpenseRate, 3, MidpointRounding.AwayFromZero);


                // Step [1-6] Business Income & Extra Expense Coverages
                this.CalculateProperty360BIEECoveragePremiums(model, additionalBenefits);

                // Step [7-46] 360 Coverage Modifications
                this.CalculateProperty360CoverageModificationPremiums(model, additionalBenefits);

                // Step [47-49] 360 Golf Courses
                this.CalculateProperty360GolfCoursesPremiums(model, additionalBenefits);

                // Step [50] 360 Optional Coverage
                this.CalculateProperty360OptionalCoverage(model);

                outputProperty.Property360TotalPremiums = (outputProperty.Property360ModificationCoverageTotalPremium
                                                                   + outputProperty.Property360GolfCourceTotalPremium
                                                                   + outputProperty.Property360OptionalCoverageTotalPremium);

                // 14-07-2021
                // Round Property360TotalPremiums up to nearest digit.
                outputProperty.Property360TotalPremiums = Math.Round(outputProperty.Property360TotalPremiums, MidpointRounding.AwayFromZero);

                this.logger.Info("PropertyBaseService.CalculateProperty360CoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyBaseService.CalculateProperty360CoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateProperty360BIEECoveragePremiums : Calculate BI EE CoveragePremiums
        /// </summary>
        /// <param name="model"></param>
        protected void CalculateProperty360BIEECoveragePremiums(RaterFacadeModel model, Dictionary<string, decimal> additionalBenefits)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

            var property360InputModel = inputProperty.Property360InputModel;
            var property360OutputModel = outputProperty.Property360OutputModel;

            Property360DataAccess property360DataAccess = new Property360DataAccess(this.configuration, this.logger);
            decimal minimumPremium = 0;

            if (property360OutputModel.BusinessIncomeAndExtraExpenseRate == 0)
            {
                // Step C- BI & EE Rate
                decimal v1 = Math.Round(this.propertyDataAccess.GetMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "BI and EE Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate), 3, MidpointRounding.AwayFromZero);
                property360OutputModel.BusinessIncomeAndExtraExpenseRate = outputProperty.BuildingFinalRate * v1;
                property360OutputModel.BusinessIncomeAndExtraExpenseRate = Math.Round(property360OutputModel.BusinessIncomeAndExtraExpenseRate, 3, MidpointRounding.AwayFromZero);
            }

            #region Step 1 - Business Income & Extra Expense (BI & EE)
            if (property360InputModel.IsBusinessIncomeAndExtraExpenseCoverageSelected)
            {
                if (property360InputModel.BusinessIncomeAndExtraExpenseRevisedLimit == 0)
                {
                    property360OutputModel.BusinessIncomeAndExtraExpensePremium = 0;
                }
                else
                {
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.BusinessIncomeAndExtraExpenseCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 1.1 property360InputModel.BusinessIncomeAndExtraExpenseRevisedLimit  : input field

                    // Step 1.2
                    property360OutputModel.BusinessIncomeAndExtraExpenseDeductibleFactor = property360DataAccess.GetBIEEDeductibleFactor(property360InputModel.BusinessIncomeAndExtraExpenseDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 1.3
                    property360OutputModel.BusinessIncomeAndExtraExpenseDaysFactor = property360DataAccess.GetBIEEDaysFactor(property360InputModel.BusinessIncomeAndExtraExpenseDays, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 1.4
                    property360OutputModel.BusinessIncomeAndExtraExpenseBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.BusinessIncomeAndExtraExpenseCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 1.5 = ((Step 1.1 - Step 1.4)/100)*Step C + ((Step 1.2-1) *((Step 1.1/100) * Step C)) + (Step 1.3 - 1) * ((Step 1.1/100) * Step C))
                    // Step 1.5 = Step C * (((Step 1.1 - Step 1.4)/100) + (Step 1.2-1)*(Step 1.1/100) + (Step 1.3 - 1)*(Step 1.1/100))
                    property360OutputModel.BusinessIncomeAndExtraExpensePremium = (((property360InputModel.BusinessIncomeAndExtraExpenseRevisedLimit
                                                                             - property360OutputModel.BusinessIncomeAndExtraExpenseBaseLimit)
                                                                             / 100)
                                                                             +
                                                                             ((property360OutputModel.BusinessIncomeAndExtraExpenseDeductibleFactor
                                                                               - 1)
                                                                             * (property360InputModel.BusinessIncomeAndExtraExpenseRevisedLimit
                                                                             / 100))
                                                                             +
                                                                             ((property360OutputModel.BusinessIncomeAndExtraExpenseDaysFactor
                                                                             - 1)
                                                                             * (property360InputModel.BusinessIncomeAndExtraExpenseRevisedLimit
                                                                             / 100)))
                                                                             * property360OutputModel.BusinessIncomeAndExtraExpenseRate;
                    property360OutputModel.BusinessIncomeAndExtraExpensePremium = Math.Round(property360OutputModel.BusinessIncomeAndExtraExpensePremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.BusinessIncomeAndExtraExpensePremium < minimumPremium)
                    {
                        property360OutputModel.BusinessIncomeAndExtraExpensePremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.BusinessIncomeAndExtraExpensePremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.BusinessIncomeAndExtraExpenseCoverageName, property360InputModel.BusinessIncomeAndExtraExpenseRevisedLimit, property360InputModel.IsBusinessIncomeAndExtraExpenseCoverageSelected, additionalBenefits);

            #endregion

            #region Step 2 - Dependent Property Business Income
            if (property360InputModel.IsDependentPropertyCoverageSelected)
            {
                if (property360InputModel.DependentPropertyRevisedLimit == 0)
                {
                    property360OutputModel.DependentPropertyPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.DependentPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 2.1 property360Model.DependentPropertyRevisedLimit : Input field

                    // Step 2.2 
                    property360OutputModel.DependentPropertyDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.DependentPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "DED");

                    // Step 2.3 
                    property360OutputModel.DependentPropertyBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.DependentPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 2.4 = ((Step 2.1 - Step 2.3)/100)*Step C + (Step 2.2-1) 
                    property360OutputModel.DependentPropertyPremium = ((property360InputModel.DependentPropertyRevisedLimit
                                                                 - property360OutputModel.DependentPropertyBaseLimit)
                                                                 / 100)
                                                                 * property360OutputModel.BusinessIncomeAndExtraExpenseRate
                                                                 + (property360OutputModel.DependentPropertyDeductibleFactor - 1);

                    property360OutputModel.DependentPropertyPremium = Math.Round(property360OutputModel.DependentPropertyPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.DependentPropertyPremium < minimumPremium)
                    {
                        property360OutputModel.DependentPropertyPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.DependentPropertyPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.DependentPropertyCoverageName, property360InputModel.DependentPropertyRevisedLimit, property360InputModel.IsDependentPropertyCoverageSelected, additionalBenefits);
            #endregion

            #region Step 3- Interruption of Computer Operations
            if (property360InputModel.IsInterruptionOfComputerOperationsCoverageSelected)
            {
                if (property360InputModel.InterruptionOfComputerOperationsRevisedLimit == 0)
                {
                    property360OutputModel.InterruptionOfComputerOperationsPremium = 0;
                }
                else
                {

                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.InterruptionOfComputerOperationsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");
                    // Step 3.1 property360Model.InterruptionOfComputerOperationsRevisedLimit : Input field

                    // Step 3.2
                    property360OutputModel.InterruptionOfComputerOperationsDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.InterruptionOfComputerOperationsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "DED");

                    // Step 3.3
                    property360OutputModel.InterruptionOfComputerOperationsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.InterruptionOfComputerOperationsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 3.4 = ((Step 3.1 - Step 3.3)/100)*Step C + (Step 3.2-1) 
                    property360OutputModel.InterruptionOfComputerOperationsPremium = ((property360InputModel.InterruptionOfComputerOperationsRevisedLimit
                                                                                - property360OutputModel.InterruptionOfComputerOperationsBaseLimit)
                                                                                / 100)

                                                                                * property360OutputModel.BusinessIncomeAndExtraExpenseRate

                                                                                + (property360OutputModel.InterruptionOfComputerOperationsDeductibleFactor - 1);

                    property360OutputModel.InterruptionOfComputerOperationsPremium = Math.Round(property360OutputModel.InterruptionOfComputerOperationsPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.InterruptionOfComputerOperationsPremium < minimumPremium)
                    {
                        property360OutputModel.InterruptionOfComputerOperationsPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.InterruptionOfComputerOperationsPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.InterruptionOfComputerOperationsCoverageName, property360InputModel.InterruptionOfComputerOperationsRevisedLimit, property360InputModel.IsInterruptionOfComputerOperationsCoverageSelected, additionalBenefits);
            #endregion

            #region Step 4 - Lease Cancellation Moving Expenses
            if (property360InputModel.IsLeaseCancellationMovingExpensesCoverageSelected)
            {
                if (property360InputModel.LeaseCancellationMovingExpensesRevisedLimit == 0)
                {
                    property360OutputModel.LeaseCancellationMovingExpensesPremium = 0;
                }
                else
                {

                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.LeaseCancellationMovingExpensesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");
                    // Step 4.1 property360Model.LeaseCancellationMovingExpensesRevisedLimit : Input field

                    // Step 4.2
                    property360OutputModel.LeaseCancellationMovingExpensesDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.LeaseCancellationMovingExpensesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "DED");

                    // Step 4.3
                    property360OutputModel.LeaseCancellationMovingExpensesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.LeaseCancellationMovingExpensesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 4.4 = ((Step 4.1 - Step 4.3)/ 100)*Step C + (Step 4.2 - 1) 
                    property360OutputModel.LeaseCancellationMovingExpensesPremium = ((property360InputModel.LeaseCancellationMovingExpensesRevisedLimit
                                                                                - property360OutputModel.LeaseCancellationMovingExpensesBaseLimit)
                                                                                / 100)
                                                                                * property360OutputModel.BusinessIncomeAndExtraExpenseRate
                                                                                + (property360OutputModel.LeaseCancellationMovingExpensesDeductibleFactor - 1);

                    property360OutputModel.LeaseCancellationMovingExpensesPremium = Math.Round(property360OutputModel.LeaseCancellationMovingExpensesPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.LeaseCancellationMovingExpensesPremium < minimumPremium)
                    {
                        property360OutputModel.LeaseCancellationMovingExpensesPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.LeaseCancellationMovingExpensesPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.LeaseCancellationMovingExpensesCoverageName, property360InputModel.LeaseCancellationMovingExpensesRevisedLimit, property360InputModel.IsLeaseCancellationMovingExpensesCoverageSelected, additionalBenefits);
            #endregion

            #region Step 5 - Newly Acquired or Constructed Property  – Business Income

            if (property360InputModel.IsNewlyAcquiredOrConstructedPropertyCoverageSelected)
            {
                if (property360InputModel.NewlyAcquiredOrConstructedPropertyRevisedLimit == 0)
                {
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.NewlyAcquiredOrConstructedPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");
                    // Step 5.1 property360Model.NewlyAcquiredOrConstructedPropertyRevisedLimit : Input field

                    // Step 5.2
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.NewlyAcquiredOrConstructedPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "DED");

                    // Step 5.3
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.NewlyAcquiredOrConstructedPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 5.4 = ((Step 5.1 - Step 5.3)/ 100)*Step C + (Step 5.2 - 1) 
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium = ((property360InputModel.NewlyAcquiredOrConstructedPropertyRevisedLimit
                                                                                - property360OutputModel.NewlyAcquiredOrConstructedPropertyBaseLimit)
                                                                                / 100)

                                                                                * property360OutputModel.BusinessIncomeAndExtraExpenseRate

                                                                                + (property360OutputModel.NewlyAcquiredOrConstructedPropertyDeductibleFactor - 1);

                    property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium = Math.Round(property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium < minimumPremium)
                    {
                        property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.NewlyAcquiredOrConstructedPropertyCoverageName, property360InputModel.NewlyAcquiredOrConstructedPropertyRevisedLimit, property360InputModel.IsNewlyAcquiredOrConstructedPropertyCoverageSelected, additionalBenefits);
            #endregion

            #region Step 6 - Off Premises Utility Failure - Business Income and Extra Expense

            if (property360InputModel.IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageSelected)
            {
                if (property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit == 0)
                {
                    property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium = 0;
                }
                else
                {

                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");
                    // Step 6.1 property360Model.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit : Input field

                    // Step 6.2
                    property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseDeductibleFactor = property360DataAccess.GetBIEEDeductibleFactor(property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseBIDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 6.3
                    property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 6.4 = ((Step 6.1 - Step 6.3)/ 100)*Step C * Step 6.2 
                    property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium = ((property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit
                                                                                - property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseBaseLimit)
                                                                                / 100)

                                                                                * property360OutputModel.BusinessIncomeAndExtraExpenseRate

                                                                                * property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseDeductibleFactor;

                    property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium = Math.Round(property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium < minimumPremium)
                    {
                        property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageName, property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit, property360InputModel.IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageSelected, additionalBenefits);
            #endregion

            // Step E-Business Income & Extra Expense Coverages Total Premium

            // Step E = Step 1.5 + Step 2.4 + Step 3.4 + Step 4.4 + Step 5.4 + Step 6.4

            outputProperty.BusinessIncomeAndExtraExpense360CoveragePremium = property360OutputModel.BusinessIncomeAndExtraExpensePremium
                                                                                 + property360OutputModel.DependentPropertyPremium
                                                                                 + property360OutputModel.InterruptionOfComputerOperationsPremium
                                                                                 + property360OutputModel.LeaseCancellationMovingExpensesPremium
                                                                                 + property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium
                                                                                 + property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium;
        }


        /// <summary>
        /// CalculateProperty360CoverageModificationPremiums : Calculate Modified premium
        /// </summary>
        /// <param name="model"></param>
        protected void CalculateProperty360CoverageModificationPremiums(RaterFacadeModel model, Dictionary<string, decimal> additionalBenefits)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

            var property360InputModel = inputProperty.Property360InputModel;
            var property360OutputModel = outputProperty.Property360OutputModel;

            Property360DataAccess property360DataAccess = new Property360DataAccess(this.configuration, this.logger);

            decimal minimumPremium = 0;

            #region Step 7.1 Ordinance or Law - Coverage B

            if (property360InputModel.IsOrdinanceOrLawCoverageBSelected)
            {
                if (property360InputModel.OrdinanceOrLawCoverageBRevisedLimit == 0)
                {
                    property360OutputModel.OrdinanceOrLawCoverageBPremium = 0;
                }
                else
                {
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OrdinanceOrLawCoverageBName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 7.1.1 property360Model.OrdinanceOrLawCoverageBRevisedLimit

                    // Step 7.1.2 
                    property360OutputModel.OrdinanceOrLawCoverageBBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OrdinanceOrLawCoverageBName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 7.1.3 = ((Step 7.1.1 - Step 7.1.2)/100) * Step A
                    property360OutputModel.OrdinanceOrLawCoverageBPremium = ((property360InputModel.OrdinanceOrLawCoverageBRevisedLimit
                                                                      - property360OutputModel.OrdinanceOrLawCoverageBBaseLimit)
                                                                      / 100)
                                                                      * outputProperty.BuildingFinalRate;

                    property360OutputModel.OrdinanceOrLawCoverageBPremium = Math.Round(property360OutputModel.OrdinanceOrLawCoverageBPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.OrdinanceOrLawCoverageBPremium < minimumPremium)
                    {
                        property360OutputModel.OrdinanceOrLawCoverageBPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.OrdinanceOrLawCoverageBPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.OrdinanceOrLawCoverageBName, property360InputModel.OrdinanceOrLawCoverageBRevisedLimit, property360InputModel.IsOrdinanceOrLawCoverageBSelected, additionalBenefits);
            #endregion

            #region Step 7.2 Ordinance or Law - Coverage C

            if (property360InputModel.IsOrdinanceOrLawCoverageCSelected)
            {
                if (property360InputModel.OrdinanceOrLawCoverageCRevisedLimit == 0)
                {
                    property360OutputModel.OrdinanceOrLawCoverageCPremium = 0;
                }
                else
                {
                    minimumPremium = 0;

                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OrdinanceOrLawCoverageCName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 7.2.1 property360Model.OrdinanceOrLawCoverageCRevisedLimit

                    // Step 7.2.2 
                    property360OutputModel.OrdinanceOrLawCoverageCBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OrdinanceOrLawCoverageCName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 7.2.3 = (Step 7.2.1 - Step 7.2.2)/100 * Step A
                    property360OutputModel.OrdinanceOrLawCoverageCPremium = (property360InputModel.OrdinanceOrLawCoverageCRevisedLimit
                                                                      - property360OutputModel.OrdinanceOrLawCoverageCBaseLimit)
                                                                      / 100
                                                                      * outputProperty.BuildingFinalRate;

                    property360OutputModel.OrdinanceOrLawCoverageCPremium = Math.Round(property360OutputModel.OrdinanceOrLawCoverageCPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.OrdinanceOrLawCoverageCPremium < minimumPremium)
                    {
                        property360OutputModel.OrdinanceOrLawCoverageCPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.OrdinanceOrLawCoverageCPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.OrdinanceOrLawCoverageCName, property360InputModel.OrdinanceOrLawCoverageCRevisedLimit, property360InputModel.IsOrdinanceOrLawCoverageCSelected, additionalBenefits);
            #endregion

            #region Step 8 - Accounts Receivable Records

            if (property360InputModel.IsAccountsReceivableRecordsCoverageSelected)
            {
                if (property360InputModel.AccountsReceivableRecordsRevisedLimit == 0)
                {
                    property360OutputModel.AccountsReceivableRecordsPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.AccountsReceivableRecordsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 8.1 property360Model.AccountsReceivableRecordsRevisedLimit : Input field

                    // Step 8.2 
                    property360OutputModel.AccountsReceivableRecordsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.AccountsReceivableRecordsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 8.3 
                    property360OutputModel.AccountsReceivableRecordsAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 8.4 
                    property360OutputModel.AccountsReceivableRecords360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.AccountsReceivableRecords360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 8.5 = (((Step 8.1 - Step 8.2)/100) + (Step 8.4 - Step 8.3)* (Step 8.1/100)) * Step B
                    property360OutputModel.AccountsReceivableRecordsPremium = (((property360InputModel.AccountsReceivableRecordsRevisedLimit
                                                                          - property360OutputModel.AccountsReceivableRecordsBaseLimit)
                                                                          / 100)
                                                                          + (property360OutputModel.AccountsReceivableRecords360DeductibleFactor
                                                                          - property360OutputModel.AccountsReceivableRecordsAOPDeductibleFactor)
                                                                          * (property360InputModel.AccountsReceivableRecordsRevisedLimit
                                                                          / 100))
                                                                          * outputProperty.ContentsFinalRate;

                    property360OutputModel.AccountsReceivableRecordsPremium = Math.Round(property360OutputModel.AccountsReceivableRecordsPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.AccountsReceivableRecordsPremium < minimumPremium)
                    {
                        property360OutputModel.AccountsReceivableRecordsPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.AccountsReceivableRecordsPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.AccountsReceivableRecordsCoverageName, property360InputModel.AccountsReceivableRecordsRevisedLimit, property360InputModel.IsAccountsReceivableRecordsCoverageSelected, additionalBenefits);
            #endregion

            #region Step 9 -  Appurtenant Structures

            if (property360InputModel.IsAppurtenantStructuresCoverageSelected)
            {
                if (property360InputModel.AppurtenantStructuresRevisedLimit == 0)
                {
                    property360OutputModel.AppurtenantStructuresPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.AppurtenantStructuresCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 9.1 property360Model.AppurtenantStructuresRevisedLimit : Input field

                    // Step 9.2 
                    property360OutputModel.AppurtenantStructuresBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.AppurtenantStructuresCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 9.3 
                    property360OutputModel.AppurtenantStructuresAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 9.4 
                    property360OutputModel.AppurtenantStructures360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.AppurtenantStructures360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 9.5 = (((Step 9.1 - Step 9.2)/100) + (Step 9.4 - Step 9.3)* (Step 9.1/100)) * Step A
                    property360OutputModel.AppurtenantStructuresPremium = (((property360InputModel.AppurtenantStructuresRevisedLimit
                                                                          - property360OutputModel.AppurtenantStructuresBaseLimit)
                                                                          / 100)
                                                                          + (property360OutputModel.AppurtenantStructures360DeductibleFactor
                                                                          - property360OutputModel.AppurtenantStructuresAOPDeductibleFactor)
                                                                          * (property360InputModel.AppurtenantStructuresRevisedLimit
                                                                          / 100))
                                                                          * outputProperty.BuildingFinalRate;

                    property360OutputModel.AppurtenantStructuresPremium = Math.Round(property360OutputModel.AppurtenantStructuresPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.AppurtenantStructuresPremium < minimumPremium)
                    {
                        property360OutputModel.AppurtenantStructuresPremium = minimumPremium;
                    }
                }

            }
            else
            {
                property360OutputModel.AppurtenantStructuresPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.AppurtenantStructuresCoverageName, property360InputModel.AppurtenantStructuresRevisedLimit, property360InputModel.IsAppurtenantStructuresCoverageSelected, additionalBenefits);
            #endregion

            #region Step 10 -  Audio Visual and Communication Equipment

            if (property360InputModel.IsAudioVisualAndCommunicationEquipmentCoverageSelected)
            {
                if (property360InputModel.AudioVisualAndCommunicationEquipmentRevisedLimit == 0)
                {
                    property360OutputModel.AudioVisualAndCommunicationEquipmentPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.AudioVisualAndCommunicationEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 10.1 property360Model.AudioVisualAndCommunicationEquipmentRevisedLimit : Input field

                    // Step 10.2 
                    property360OutputModel.AudioVisualAndCommunicationEquipmentBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.AudioVisualAndCommunicationEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 10.3 
                    property360OutputModel.AudioVisualAndCommunicationEquipmentAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.AudioVisualAndCommunicationEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 10.4 
                    property360OutputModel.AudioVisualAndCommunicationEquipment360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.AudioVisualAndCommunicationEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 10.5 = (((Step 10.1 - Step 10.2)/100) + (Step 10.4 - Step 10.3)* (Step 10.1/100)) * Step B
                    property360OutputModel.AudioVisualAndCommunicationEquipmentPremium = (((property360InputModel.AudioVisualAndCommunicationEquipmentRevisedLimit
                                                                          - property360OutputModel.AudioVisualAndCommunicationEquipmentBaseLimit)
                                                                          / 100)
                                                                          + (property360OutputModel.AudioVisualAndCommunicationEquipment360DeductibleFactor
                                                                          - property360OutputModel.AudioVisualAndCommunicationEquipmentAOPDeductibleFactor)
                                                                          * (property360InputModel.AudioVisualAndCommunicationEquipmentRevisedLimit
                                                                          / 100))
                                                                          * outputProperty.ContentsFinalRate;

                    property360OutputModel.AudioVisualAndCommunicationEquipmentPremium = Math.Round(property360OutputModel.AudioVisualAndCommunicationEquipmentPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.AudioVisualAndCommunicationEquipmentPremium < minimumPremium)
                    {
                        property360OutputModel.AudioVisualAndCommunicationEquipmentPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.AudioVisualAndCommunicationEquipmentPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.AudioVisualAndCommunicationEquipmentCoverageName, property360InputModel.AudioVisualAndCommunicationEquipmentRevisedLimit, property360InputModel.IsAudioVisualAndCommunicationEquipmentCoverageSelected, additionalBenefits);
            #endregion

            #region Step 11 - Changes in Temperature or Humidity

            if (property360InputModel.IsChangesInTemperatureOrHumidityCoverageSelected)
            {
                if (property360InputModel.ChangesInTemperatureOrHumidityRevisedLimit == 0)
                {
                    property360OutputModel.ChangesInTemperatureOrHumidityPremium = 0;
                }
                else
                {

                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ChangesInTemperatureOrHumidityCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");
                    // Step 11.1 property360Model.ChangesInTemperatureOrHumidityRevisedLimit : Input field

                    // Step 11.2 
                    property360OutputModel.ChangesInTemperatureOrHumidityBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ChangesInTemperatureOrHumidityCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 11.3 
                    property360OutputModel.ChangesInTemperatureOrHumidityAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 11.4 
                    property360OutputModel.ChangesInTemperatureOrHumidity360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.ChangesInTemperatureOrHumidity360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 11.5 = (((Step 11.1 - Step 11.2)/100) + (Step 11.4 - Step 11.3)* (Step 11.1/100)) * Step B
                    property360OutputModel.ChangesInTemperatureOrHumidityPremium = (((property360InputModel.ChangesInTemperatureOrHumidityRevisedLimit
                                                                          - property360OutputModel.ChangesInTemperatureOrHumidityBaseLimit)
                                                                          / 100)
                                                                          + (property360OutputModel.ChangesInTemperatureOrHumidity360DeductibleFactor
                                                                          - property360OutputModel.ChangesInTemperatureOrHumidityAOPDeductibleFactor)
                                                                          * (property360InputModel.ChangesInTemperatureOrHumidityRevisedLimit
                                                                          / 100))
                                                                          * outputProperty.ContentsFinalRate;

                    property360OutputModel.ChangesInTemperatureOrHumidityPremium = Math.Round(property360OutputModel.ChangesInTemperatureOrHumidityPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.ChangesInTemperatureOrHumidityPremium < minimumPremium)
                    {
                        property360OutputModel.ChangesInTemperatureOrHumidityPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.ChangesInTemperatureOrHumidityPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.ChangesInTemperatureOrHumidityCoverageName, property360InputModel.ChangesInTemperatureOrHumidityRevisedLimit, property360InputModel.IsChangesInTemperatureOrHumidityCoverageSelected, additionalBenefits);
            #endregion

            #region Step 12 - Commandeered Property

            if (property360InputModel.IsCommandeeredPropertyCoverageSelected)
            {
                if (property360InputModel.CommandeeredPropertyRevisedLimit == 0)
                {
                    property360OutputModel.CommandeeredPropertyPremium = 0;
                }
                else
                {

                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.CommandeeredPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");
                    // Step 12.1 property360Model.CommandeeredPropertyRevisedLimit : Input field

                    // Step 12.2 
                    property360OutputModel.CommandeeredPropertyBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.CommandeeredPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 12.3 
                    property360OutputModel.CommandeeredPropertyAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.CommandeeredPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 12.4 
                    property360OutputModel.CommandeeredProperty360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.CommandeeredPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 12.5 = (((Step 12.1 - Step 12.2)/100) + (Step 12.4 - Step 12.3)* (Step 12.1/100)) * Step B
                    property360OutputModel.CommandeeredPropertyPremium = (((property360InputModel.CommandeeredPropertyRevisedLimit
                                                                          - property360OutputModel.CommandeeredPropertyBaseLimit)
                                                                          / 100)
                                                                          + (property360OutputModel.CommandeeredProperty360DeductibleFactor
                                                                          - property360OutputModel.CommandeeredPropertyAOPDeductibleFactor)
                                                                          * (property360InputModel.CommandeeredPropertyRevisedLimit
                                                                          / 100))
                                                                          * outputProperty.ContentsFinalRate;

                    property360OutputModel.CommandeeredPropertyPremium = Math.Round(property360OutputModel.CommandeeredPropertyPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.CommandeeredPropertyPremium < minimumPremium)
                    {
                        property360OutputModel.CommandeeredPropertyPremium = minimumPremium;
                    }
                }

            }
            else
            {
                property360OutputModel.CommandeeredPropertyPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.CommandeeredPropertyCoverageName, property360InputModel.CommandeeredPropertyRevisedLimit, property360InputModel.IsCommandeeredPropertyCoverageSelected, additionalBenefits);
            #endregion

            #region Step 13 - Computer Equipment

            if (property360InputModel.IsComputerEquipmentCoverageSelected)
            {
                if (property360InputModel.ComputerEquipmentRevisedLimit == 0)
                {
                    property360OutputModel.ComputerEquipmentPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ComputerEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 13.1 property360Model.ComputerEquipmentRevisedLimit : Input field

                    // Step 13.2 
                    property360OutputModel.ComputerEquipmentBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ComputerEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 13.3 
                    property360OutputModel.ComputerEquipmentAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 13.4 
                    property360OutputModel.ComputerEquipment360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.ComputerEquipment360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 13.5 = (((Step 13.1 - Step 13.2)/100) + (Step 13.4 - Step 13.3)* (Step 13.1/100)) * Step B
                    property360OutputModel.ComputerEquipmentPremium = (((property360InputModel.ComputerEquipmentRevisedLimit
                                                                - property360OutputModel.ComputerEquipmentBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.ComputerEquipment360DeductibleFactor
                                                                - property360OutputModel.ComputerEquipmentAOPDeductibleFactor)
                                                                * (property360InputModel.ComputerEquipmentRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.ComputerEquipmentPremium = Math.Round(property360OutputModel.ComputerEquipmentPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.ComputerEquipmentPremium < minimumPremium)
                    {
                        property360OutputModel.ComputerEquipmentPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.ComputerEquipmentPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.ComputerEquipmentCoverageName, property360InputModel.ComputerEquipmentRevisedLimit, property360InputModel.IsComputerEquipmentCoverageSelected, additionalBenefits);
            #endregion

            #region Step 14- Debris Removal - Your Premises

            if (property360InputModel.IsDebrisRemovalYourPremisesCoverageSelected)
            {
                if (property360InputModel.DebrisRemovalYourPremisesRevisedLimit == 0)
                {
                    property360OutputModel.DebrisRemovalYourPremisesPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.DebrisRemovalYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 14.1 property360Model.DebrisRemovalYourPremisesRevisedLimit : Input field

                    // Step 14.2 
                    property360OutputModel.DebrisRemovalYourPremisesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.DebrisRemovalYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 14.3 
                    property360OutputModel.DebrisRemovalYourPremisesAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.DebrisRemovalYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 14.4 
                    property360OutputModel.DebrisRemovalYourPremises360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.DebrisRemovalYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 14.5 = (((Step 14.1 - Step 14.2)/100) + (Step 14.4 - Step 14.3)* (Step 14.1/100)) * Step A
                    property360OutputModel.DebrisRemovalYourPremisesPremium = (((property360InputModel.DebrisRemovalYourPremisesRevisedLimit
                                                                - property360OutputModel.DebrisRemovalYourPremisesBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.DebrisRemovalYourPremises360DeductibleFactor
                                                                - property360OutputModel.DebrisRemovalYourPremisesAOPDeductibleFactor)
                                                                * (property360InputModel.DebrisRemovalYourPremisesRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.DebrisRemovalYourPremisesPremium = Math.Round(property360OutputModel.DebrisRemovalYourPremisesPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.DebrisRemovalYourPremisesPremium < minimumPremium)
                    {
                        property360OutputModel.DebrisRemovalYourPremisesPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.DebrisRemovalYourPremisesPremium = 0;
            }


            CalculateTIVAndAdditionalBenefits(property360InputModel.DebrisRemovalYourPremisesCoverageName, property360InputModel.DebrisRemovalYourPremisesRevisedLimit, property360InputModel.IsDebrisRemovalYourPremisesCoverageSelected, additionalBenefits);
            #endregion

            #region Step 15 - Debris Removal -   Wind Blown Debris

            if (property360InputModel.IsDebrisRemovalWindBlownDebrisCoverageSelected)
            {
                if (property360InputModel.DebrisRemovalWindBlownDebrisRevisedLimit == 0)
                {
                    property360OutputModel.DebrisRemovalWindBlownDebrisPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.DebrisRemovalWindBlownDebrisCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 15.1 property360Model.DebrisRemovalWindBlownDebrisRevisedLimit : Input field

                    // Step 15.2 
                    property360OutputModel.DebrisRemovalWindBlownDebrisBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.DebrisRemovalWindBlownDebrisCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 15.3 
                    property360OutputModel.DebrisRemovalWindBlownDebrisAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.DebrisRemovalWindBlownDebrisCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 15.4 
                    property360OutputModel.DebrisRemovalWindBlownDebris360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.DebrisRemovalWindBlownDebrisCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 15.5 = (((Step 15.1 - Step 15.2)/100) + (Step 15.4 - Step 15.3)* (Step 15.1/100)) * Step A
                    property360OutputModel.DebrisRemovalWindBlownDebrisPremium = (((property360InputModel.DebrisRemovalWindBlownDebrisRevisedLimit
                                                                - property360OutputModel.DebrisRemovalWindBlownDebrisBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.DebrisRemovalWindBlownDebris360DeductibleFactor
                                                                - property360OutputModel.DebrisRemovalWindBlownDebrisAOPDeductibleFactor)
                                                                * (property360InputModel.DebrisRemovalWindBlownDebrisRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.DebrisRemovalWindBlownDebrisPremium = Math.Round(property360OutputModel.DebrisRemovalWindBlownDebrisPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.DebrisRemovalWindBlownDebrisPremium < minimumPremium)
                    {
                        property360OutputModel.DebrisRemovalWindBlownDebrisPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.DebrisRemovalWindBlownDebrisPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.DebrisRemovalWindBlownDebrisCoverageName, property360InputModel.DebrisRemovalWindBlownDebrisRevisedLimit, property360InputModel.IsDebrisRemovalWindBlownDebrisCoverageSelected, additionalBenefits);
            #endregion

            #region Step 16 - Electronic Data

            if (property360InputModel.IsElectronicDataCoverageSelected)
            {
                if (property360InputModel.ElectronicDataRevisedLimit == 0)
                {
                    property360OutputModel.ElectronicDataPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ElectronicDataCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 16.1 property360Model.ElectronicDataRevisedLimit : Input field

                    // Step 16.2 
                    property360OutputModel.ElectronicDataBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ElectronicDataCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 16.3 
                    property360OutputModel.ElectronicDataAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 16.4 
                    property360OutputModel.ElectronicData360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.ElectronicData360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 16.5 = (((Step 16.1 - Step 16.2)/100) + (Step 16.4 - Step 16.3)* (Step 16.1/100)) * Step B
                    property360OutputModel.ElectronicDataPremium = (((property360InputModel.ElectronicDataRevisedLimit
                                                                - property360OutputModel.ElectronicDataBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.ElectronicData360DeductibleFactor
                                                                - property360OutputModel.ElectronicDataAOPDeductibleFactor)
                                                                * (property360InputModel.ElectronicDataRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.ElectronicDataPremium = Math.Round(property360OutputModel.ElectronicDataPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.ElectronicDataPremium < minimumPremium)
                    {
                        property360OutputModel.ElectronicDataPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.ElectronicDataPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.ElectronicDataCoverageName, property360InputModel.ElectronicDataRevisedLimit, property360InputModel.IsElectronicDataCoverageSelected, additionalBenefits);
            #endregion

            #region Step 17 -Fine Arts

            if (property360InputModel.IsFineArtsCoverageSelected)
            {
                if (property360InputModel.FineArtsRevisedLimit == 0)
                {
                    property360OutputModel.FineArtsPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.FineArtsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 17.1 property360Model.FineArtsRevisedLimit : Input field

                    // Step 17.2 
                    property360OutputModel.FineArtsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.FineArtsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 17.3 
                    property360OutputModel.FineArtsAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 17.4 
                    property360OutputModel.FineArts360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.FineArts360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 17.5 = (((Step 17.1 - Step 17.2)/100) + (Step 17.4 - Step 17.3)* (Step 17.1/100)) * Step B
                    property360OutputModel.FineArtsPremium = (((property360InputModel.FineArtsRevisedLimit
                                                                - property360OutputModel.FineArtsBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.FineArts360DeductibleFactor
                                                                - property360OutputModel.FineArtsAOPDeductibleFactor)
                                                                * (property360InputModel.FineArtsRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.FineArtsPremium = Math.Round(property360OutputModel.FineArtsPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.FineArtsPremium < minimumPremium)
                    {
                        property360OutputModel.FineArtsPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.FineArtsPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.FineArtsCoverageName, property360InputModel.FineArtsRevisedLimit, property360InputModel.IsFineArtsCoverageSelected, additionalBenefits);
            #endregion

            #region Step 18 -Fire Department Service Charge

            if (property360InputModel.IsFireDepartmentServiceChargeCoverageSelected)
            {
                if (property360InputModel.FireDepartmentServiceChargeRevisedLimit == 0)
                {
                    property360OutputModel.FireDepartmentServiceChargePremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.FireDepartmentServiceChargeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 18.1 property360Model.FireDepartmentServiceChargeRevisedLimit : Input field

                    // Step 18.2 
                    property360OutputModel.FireDepartmentServiceChargeBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.FireDepartmentServiceChargeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 18.3 
                    property360OutputModel.FireDepartmentServiceChargeAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.FireDepartmentServiceChargeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 18.4 
                    property360OutputModel.FireDepartmentServiceCharge360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.FireDepartmentServiceChargeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 18.5 = (((Step 18.1 - Step 18.2)/100) + (Step 18.4 - Step 18.3)* (Step 18.1/100)) * Step B
                    property360OutputModel.FireDepartmentServiceChargePremium = (((property360InputModel.FireDepartmentServiceChargeRevisedLimit
                                                                - property360OutputModel.FireDepartmentServiceChargeBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.FireDepartmentServiceCharge360DeductibleFactor
                                                                - property360OutputModel.FireDepartmentServiceChargeAOPDeductibleFactor)
                                                                * (property360InputModel.FireDepartmentServiceChargeRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.FireDepartmentServiceChargePremium = Math.Round(property360OutputModel.FireDepartmentServiceChargePremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.FireDepartmentServiceChargePremium < minimumPremium)
                    {
                        property360OutputModel.FireDepartmentServiceChargePremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.FireDepartmentServiceChargePremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.FireDepartmentServiceChargeCoverageName, property360InputModel.FireDepartmentServiceChargeRevisedLimit, property360InputModel.IsFireDepartmentServiceChargeCoverageSelected, additionalBenefits);
            #endregion

            #region Step 19 - Fungus, Wet Rot, Dry Rot and Bacteria

            if (property360InputModel.IsFungusWetRotDryRotAndBacteriaCoverageSelected)
            {
                if (property360InputModel.FungusWetRotDryRotAndBacteriaRevisedLimit == 0)
                {
                    property360OutputModel.FungusWetRotDryRotAndBacteriaPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.FungusWetRotDryRotAndBacteriaCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 19.1 property360Model.FungusWetRotDryRotAndBacteriaRevisedLimit : Input field

                    // Step 19.2 
                    property360OutputModel.FungusWetRotDryRotAndBacteriaBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.FungusWetRotDryRotAndBacteriaCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 19.3 
                    property360OutputModel.FungusWetRotDryRotAndBacteriaAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.FungusWetRotDryRotAndBacteriaCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 19.4 
                    property360OutputModel.FungusWetRotDryRotAndBacteria360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.FungusWetRotDryRotAndBacteriaCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 19.5 = (((Step 19.1 - Step 19.2)/100) + (Step 19.4 - Step 19.3)* (Step 19.1/100)) * Step A
                    property360OutputModel.FungusWetRotDryRotAndBacteriaPremium = (((property360InputModel.FungusWetRotDryRotAndBacteriaRevisedLimit
                                                                - property360OutputModel.FungusWetRotDryRotAndBacteriaBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.FungusWetRotDryRotAndBacteria360DeductibleFactor
                                                                - property360OutputModel.FungusWetRotDryRotAndBacteriaAOPDeductibleFactor)
                                                                * (property360InputModel.FungusWetRotDryRotAndBacteriaRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.FungusWetRotDryRotAndBacteriaPremium = Math.Round(property360OutputModel.FungusWetRotDryRotAndBacteriaPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.FungusWetRotDryRotAndBacteriaPremium < minimumPremium)
                    {
                        property360OutputModel.FungusWetRotDryRotAndBacteriaPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.FungusWetRotDryRotAndBacteriaPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.FungusWetRotDryRotAndBacteriaCoverageName, property360InputModel.FungusWetRotDryRotAndBacteriaRevisedLimit, property360InputModel.IsFungusWetRotDryRotAndBacteriaCoverageSelected, additionalBenefits);
            #endregion

            #region Step 20 - Glass Display or Trophy Cases
            if (property360InputModel.IsGlassDisplayOrTrophyCasesCoverageSelected)
            {
                if (property360InputModel.GlassDisplayOrTrophyCasesRevisedLimit == 0)
                {
                    property360OutputModel.GlassDisplayOrTrophyCasesPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GlassDisplayOrTrophyCasesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 20.1 property360Model.GlassDisplayOrTrophyCasesRevisedLimit : Input field

                    // Step 20.2 
                    property360OutputModel.GlassDisplayOrTrophyCasesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GlassDisplayOrTrophyCasesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 20.3 
                    property360OutputModel.GlassDisplayOrTrophyCasesAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.GlassDisplayOrTrophyCasesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 20.4 
                    property360OutputModel.GlassDisplayOrTrophyCases360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.GlassDisplayOrTrophyCasesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 20.5 = (((Step 20.1 - Step 20.2)/100) + (Step 20.4 - Step 20.3)* (Step 20.1/100)) * Step B
                    property360OutputModel.GlassDisplayOrTrophyCasesPremium = (((property360InputModel.GlassDisplayOrTrophyCasesRevisedLimit
                                                                - property360OutputModel.GlassDisplayOrTrophyCasesBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.GlassDisplayOrTrophyCases360DeductibleFactor
                                                                - property360OutputModel.GlassDisplayOrTrophyCasesAOPDeductibleFactor)
                                                                * (property360InputModel.GlassDisplayOrTrophyCasesRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.GlassDisplayOrTrophyCasesPremium = Math.Round(property360OutputModel.GlassDisplayOrTrophyCasesPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.GlassDisplayOrTrophyCasesPremium < minimumPremium)
                    {
                        property360OutputModel.GlassDisplayOrTrophyCasesPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.GlassDisplayOrTrophyCasesPremium = 0;
            }
            CalculateTIVAndAdditionalBenefits(property360InputModel.GlassDisplayOrTrophyCasesCoverageName, property360InputModel.GlassDisplayOrTrophyCasesRevisedLimit, property360InputModel.IsGlassDisplayOrTrophyCasesCoverageSelected, additionalBenefits);
            #endregion

            #region Step 21 - Inventory and Appraisal
            if (property360InputModel.IsInventoryAndAppraisalCoverageSelected)
            {
                if (property360InputModel.InventoryAndAppraisalRevisedLimit == 0)
                {
                    property360OutputModel.InventoryAndAppraisalPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.InventoryAndAppraisalCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 21.1 property360Model.InventoryAndAppraisalRevisedLimit : Input field

                    // Step 21.2 
                    property360OutputModel.InventoryAndAppraisalBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.InventoryAndAppraisalCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 21.3 
                    property360OutputModel.InventoryAndAppraisalAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 21.4 
                    property360OutputModel.InventoryAndAppraisal360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.InventoryAndAppraisal360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 21.5 = (((Step 21.1 - Step 21.2)/100) + (Step 21.4 - Step 21.3)* (Step 21.1/100)) * Step B
                    property360OutputModel.InventoryAndAppraisalPremium = (((property360InputModel.InventoryAndAppraisalRevisedLimit
                                                                - property360OutputModel.InventoryAndAppraisalBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.InventoryAndAppraisal360DeductibleFactor
                                                                - property360OutputModel.InventoryAndAppraisalAOPDeductibleFactor)
                                                                * (property360InputModel.InventoryAndAppraisalRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.InventoryAndAppraisalPremium = Math.Round(property360OutputModel.InventoryAndAppraisalPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.InventoryAndAppraisalPremium < minimumPremium)
                    {
                        property360OutputModel.InventoryAndAppraisalPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.InventoryAndAppraisalPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.InventoryAndAppraisalCoverageName, property360InputModel.InventoryAndAppraisalRevisedLimit, property360InputModel.IsInventoryAndAppraisalCoverageSelected, additionalBenefits);
            #endregion

            #region Step 22 - Key/Card

            if (property360InputModel.IsKeyCardCoverageSelected)
            {
                if (property360InputModel.KeyCardRevisedLimit == 0)
                {
                    property360OutputModel.KeyCardPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.KeyCardCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 22.1 property360Model.KeyCardRevisedLimit : Input field

                    // Step 22.2 
                    property360OutputModel.KeyCardBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.KeyCardCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 22.3 
                    property360OutputModel.KeyCardAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 22.4 
                    property360OutputModel.KeyCard360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.KeyCard360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 22.5 = (((Step 22.1 - Step 22.2)/100) + (Step 22.4 - Step 22.3)* (Step 22.1/100)) * Step B
                    property360OutputModel.KeyCardPremium = (((property360InputModel.KeyCardRevisedLimit
                                                                - property360OutputModel.KeyCardBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.KeyCard360DeductibleFactor
                                                                - property360OutputModel.KeyCardAOPDeductibleFactor)
                                                                * (property360InputModel.KeyCardRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.KeyCardPremium = Math.Round(property360OutputModel.KeyCardPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.KeyCardPremium < minimumPremium)
                    {
                        property360OutputModel.KeyCardPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.KeyCardPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.KeyCardCoverageName, property360InputModel.KeyCardRevisedLimit, property360InputModel.IsKeyCardCoverageSelected, additionalBenefits);
            #endregion

            #region Step 23 - Lock Replacement

            if (property360InputModel.IsLockReplacementCoverageSelected)
            {
                if (property360InputModel.LockReplacementRevisedLimit == 0)
                {
                    property360OutputModel.LockReplacementPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.LockReplacementCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 23.1 property360Model.LockReplacementRevisedLimit : Input field

                    // Step 23.2 
                    property360OutputModel.LockReplacementBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.LockReplacementCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 23.3 
                    property360OutputModel.LockReplacementRate = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.LockReplacementCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    // Step 23.4 
                    property360OutputModel.LockReplacementAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.LockReplacementCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 23.5 
                    property360OutputModel.LockReplacement360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.LockReplacementCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 23.6 = (((Step 23.1 - Step 23.2)/ 100) +(Step 23.5 - Step 23.4)*(Step 23.1 / 100)) *Step 23.3
                    property360OutputModel.LockReplacementPremium = (((property360InputModel.LockReplacementRevisedLimit
                                                                - property360OutputModel.LockReplacementBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.LockReplacement360DeductibleFactor
                                                                - property360OutputModel.LockReplacementAOPDeductibleFactor)
                                                                * (property360InputModel.LockReplacementRevisedLimit
                                                                / 100))
                                                                * property360OutputModel.LockReplacementRate;

                    property360OutputModel.LockReplacementPremium = Math.Round(property360OutputModel.LockReplacementPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.LockReplacementPremium < minimumPremium)
                    {
                        property360OutputModel.LockReplacementPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.LockReplacementPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.LockReplacementCoverageName, property360InputModel.LockReplacementRevisedLimit, property360InputModel.IsLockReplacementCoverageSelected, additionalBenefits);
            #endregion

            #region Step 24 - Money and Securities -On Your Premises

            if (property360InputModel.IsMoneyAndSecuritiesOnYourPremisesCoverageSelected)
            {
                if (property360InputModel.MoneyAndSecuritiesOnYourPremisesRevisedLimit == 0)
                {
                    property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.MoneyAndSecuritiesOnYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 24.1 property360Model.MoneyAndSecuritiesOnYourPremisesRevisedLimit : Input field

                    // Step 24.2 
                    property360OutputModel.MoneyAndSecuritiesOnYourPremisesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.MoneyAndSecuritiesOnYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 24.3 
                    property360OutputModel.MoneyAndSecuritiesOnYourPremisesAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.MoneyAndSecuritiesOnYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 24.4 
                    property360OutputModel.MoneyAndSecuritiesOnYourPremises360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.MoneyAndSecuritiesOnYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 24.5 = (((Step 24.1 - Step 24.2)/ 100) +(Step 24.4 - Step 24.3)*(Step 24.1 / 100)) * StepB
                    property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium = (((property360InputModel.MoneyAndSecuritiesOnYourPremisesRevisedLimit
                                                                - property360OutputModel.MoneyAndSecuritiesOnYourPremisesBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.MoneyAndSecuritiesOnYourPremises360DeductibleFactor
                                                                - property360OutputModel.MoneyAndSecuritiesOnYourPremisesAOPDeductibleFactor)
                                                                * (property360InputModel.MoneyAndSecuritiesOnYourPremisesRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium = Math.Round(property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium < minimumPremium)
                    {
                        property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.MoneyAndSecuritiesOnYourPremisesCoverageName, property360InputModel.MoneyAndSecuritiesOnYourPremisesRevisedLimit, property360InputModel.IsMoneyAndSecuritiesOnYourPremisesCoverageSelected, additionalBenefits);
            #endregion

            #region Step 25 - Money and Securities - Away From Your Premises

            if (property360InputModel.IsMoneyAndSecuritiesAwayFromYourPremisesCoverageSelected)
            {
                if (property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit == 0)
                {
                    property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 25.1 property360Model.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit : Input field

                    // Step 25.2 
                    property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 25.3 
                    property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 25.4 
                    property360OutputModel.MoneyAndSecuritiesAwayFromYourPremises360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 25.5 = (((Step 25.1 - Step 25.2)/ 100) +(Step 25.4 - Step 25.3)*(Step 25.1 / 100)) * StepB
                    property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium = (((property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit
                                                                - property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.MoneyAndSecuritiesAwayFromYourPremises360DeductibleFactor
                                                                - property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesAOPDeductibleFactor)
                                                                * (property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium = Math.Round(property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium < minimumPremium)
                    {
                        property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesCoverageName, property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit, property360InputModel.IsMoneyAndSecuritiesAwayFromYourPremisesCoverageSelected, additionalBenefits);
            #endregion

            #region Step 26 - Newly Acquired or Constructed Property -Buildings

            if (property360InputModel.IsNewlyAcquiredOrConstructedPropertyBuildingsCoverageSelected)
            {
                if (property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit == 0)
                {
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 26.1 property360Model.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit : Input field

                    // Step 26.2 
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 26.3 
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 26.4 
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildings360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.NewlyAcquiredOrConstructedPropertyBuildings360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 26.5 = (((Step 26.1 - Step 26.2)/ 100) +(Step 26.4 - Step 26.3)*(Step 26.1 / 100)) * Step A
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium = (((property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit
                                                                - property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildings360DeductibleFactor
                                                                - property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsAOPDeductibleFactor)
                                                                * (property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium = Math.Round(property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium < minimumPremium)
                    {
                        property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsCoverageName, property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit, property360InputModel.IsNewlyAcquiredOrConstructedPropertyBuildingsCoverageSelected, additionalBenefits);
            #endregion

            #region Step 27 - Newly Acquired or Constructed Property Your Business Personal Property

            if (property360InputModel.IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageSelected)
            {
                if (property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit == 0)
                {
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 27.1 property360Model.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit : Input field

                    // Step 27.2 
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 27.3 
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 27.4 
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalProperty360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalProperty360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 27.5 = (((Step 27.1 - Step 27.2)/ 100) +(Step 27.4 - Step 27.3)*(Step 27.1 / 100)) * Step B
                    property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium = (((property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit
                                                                - property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalProperty360DeductibleFactor
                                                                - property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyAOPDeductibleFactor)
                                                                * (property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium = Math.Round(property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium < minimumPremium)
                    {
                        property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageName, property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit, property360InputModel.IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageSelected, additionalBenefits);
            #endregion

            #region Step 28 - Non-owned Detached Trailers

            if (property360InputModel.IsNonOwnedDetachedTrailersCoverageSelected)
            {
                if (property360InputModel.NonOwnedDetachedTrailersRevisedLimit == 0)
                {
                    property360OutputModel.NonOwnedDetachedTrailersPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.NonOwnedDetachedTrailersCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 28.1 property360Model.NonOwnedDetachedTrailersRevisedLimit : Input field

                    // Step 28.2 
                    property360OutputModel.NonOwnedDetachedTrailersBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.NonOwnedDetachedTrailersCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 28.3 
                    property360OutputModel.NonOwnedDetachedTrailersAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 28.4 
                    property360OutputModel.NonOwnedDetachedTrailers360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.NonOwnedDetachedTrailers360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 28.5 = (((Step 28.1 - Step 28.2)/ 100) +(Step 28.4 - Step 28.3)*(Step 28.1 / 100)) * Step A
                    property360OutputModel.NonOwnedDetachedTrailersPremium = (((property360InputModel.NonOwnedDetachedTrailersRevisedLimit
                                                                - property360OutputModel.NonOwnedDetachedTrailersBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.NonOwnedDetachedTrailers360DeductibleFactor
                                                                - property360OutputModel.NonOwnedDetachedTrailersAOPDeductibleFactor)
                                                                * (property360InputModel.NonOwnedDetachedTrailersRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.NonOwnedDetachedTrailersPremium = Math.Round(property360OutputModel.NonOwnedDetachedTrailersPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.NonOwnedDetachedTrailersPremium < minimumPremium)
                    {
                        property360OutputModel.NonOwnedDetachedTrailersPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.NonOwnedDetachedTrailersPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.NonOwnedDetachedTrailersCoverageName, property360InputModel.NonOwnedDetachedTrailersRevisedLimit, property360InputModel.IsNonOwnedDetachedTrailersCoverageSelected, additionalBenefits);
            #endregion

            #region Step 29 - Off Premises Utility Failure - Damage to Covered Property

            if (property360InputModel.IsOffPremisesUtilityFailureDamageToCoveredPropertyCoverageSelected)
            {
                if (property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit == 0)
                {
                    property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 29.1 property360Model.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit : Input field

                    // Step 29.2 
                    property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 29.3 
                    property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 29.4 
                    property360OutputModel.OffPremisesUtilityFailureDamageToCoveredProperty360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.OffPremisesUtilityFailureDamageToCoveredProperty360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 29.5 = (((Step 29.1 - Step 29.2)/ 100) +(Step 29.4 - Step 29.3)*(Step 29.1 / 100)) * Step A
                    property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium = (((property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit
                                                                - property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.OffPremisesUtilityFailureDamageToCoveredProperty360DeductibleFactor
                                                                - property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyAOPDeductibleFactor)
                                                                * (property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium = Math.Round(property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium < minimumPremium)
                    {
                        property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyCoverageName, property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit, property360InputModel.IsOffPremisesUtilityFailureDamageToCoveredPropertyCoverageSelected, additionalBenefits);
            #endregion

            #region Step 30 - Outdoor Property

            if (property360InputModel.IsOutdoorPropertyCoverageSelected)
            {
                if (property360InputModel.OutdoorPropertyRevisedLimit == 0)
                {
                    property360OutputModel.OutdoorPropertyPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OutdoorPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 30.1 property360Model.OutdoorPropertyRevisedLimit : Input field

                    // Step 30.2 
                    property360OutputModel.OutdoorPropertyBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.OutdoorPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 30.3 
                    property360OutputModel.OutdoorPropertyAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 30.4 
                    property360OutputModel.OutdoorProperty360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.OutdoorProperty360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 30.5 = (((Step 30.1 - Step 30.2)/ 100) +(Step 30.4 - Step 30.3)*(Step 30.1 / 100)) * Step A
                    property360OutputModel.OutdoorPropertyPremium = (((property360InputModel.OutdoorPropertyRevisedLimit
                                                                - property360OutputModel.OutdoorPropertyBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.OutdoorProperty360DeductibleFactor
                                                                - property360OutputModel.OutdoorPropertyAOPDeductibleFactor)
                                                                * (property360InputModel.OutdoorPropertyRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.OutdoorPropertyPremium = Math.Round(property360OutputModel.OutdoorPropertyPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.OutdoorPropertyPremium < minimumPremium)
                    {
                        property360OutputModel.OutdoorPropertyPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.OutdoorPropertyPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.OutdoorPropertyCoverageName, property360InputModel.OutdoorPropertyRevisedLimit, property360InputModel.IsOutdoorPropertyCoverageSelected, additionalBenefits);
            #endregion

            #region Step 31 - Personal Effects and Property of Others

            if (property360InputModel.IsPersonalEffectsAndPropertyOfOthersCoverageSelected)
            {
                if (property360InputModel.PersonalEffectsAndPropertyOfOthersRevisedLimit == 0)
                {
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PersonalEffectsAndPropertyOfOthersCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 31.1 property360Model.PersonalEffectsAndPropertyOfOthersRevisedLimit : Input field

                    // Step 31.2 
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PersonalEffectsAndPropertyOfOthersCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 31.3 
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 31.4 
                    property360OutputModel.PersonalEffectsAndPropertyOfOthers360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.PersonalEffectsAndPropertyOfOthers360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 31.5 = (((Step 31.1 - Step 31.2)/ 100) +(Step 31.4 - Step 31.3)*(Step 31.1 / 100)) * Step B
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium = (((property360InputModel.PersonalEffectsAndPropertyOfOthersRevisedLimit
                                                                - property360OutputModel.PersonalEffectsAndPropertyOfOthersBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.PersonalEffectsAndPropertyOfOthers360DeductibleFactor
                                                                - property360OutputModel.PersonalEffectsAndPropertyOfOthersAOPDeductibleFactor)
                                                                * (property360InputModel.PersonalEffectsAndPropertyOfOthersRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium = Math.Round(property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium < minimumPremium)
                    {
                        property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.PersonalEffectsAndPropertyOfOthersCoverageName, property360InputModel.PersonalEffectsAndPropertyOfOthersRevisedLimit, property360InputModel.IsPersonalEffectsAndPropertyOfOthersCoverageSelected, additionalBenefits);
            #endregion

            #region Step 32 - Personal Effects and Property of Others - Any Employee or Volunteer

            if (property360InputModel.IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageSelected)
            {
                if (property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit == 0)
                {
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 32.1 property360Model.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit : Input field

                    // Step 32.2 
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 32.3 
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRate = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    // Step 32.4
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 32.5 
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteer360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteer360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 32.6 = (((Step 32.1 - Step 32.2)/100 ) + ((Step 31.5 - Step 31.4)* (Step 32.1/100))) * Step 32.3
                    property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium = (((property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit
                                                                - property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteer360DeductibleFactor
                                                                - property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerAOPDeductibleFactor)
                                                                * (property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit
                                                                / 100))
                                                                * property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRate;

                    property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium = Math.Round(property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium < minimumPremium)
                    {
                        property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageName, property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit, property360InputModel.IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageSelected, additionalBenefits);
            #endregion

            #region Step 33 - Pollutant Clean Up and Removal
            if (property360InputModel.IsModificationPollutantCleanUpAndRemovalCoverageSelected)
            {
                if (property360InputModel.ModificationPollutantCleanUpAndRemovalRevisedLimit == 0)
                {
                    property360OutputModel.PollutantCleanUpAndRemovalPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ModificationPollutantCleanUpAndRemovalCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 33.1 property360Model.PollutantCleanUpAndRemovalRevisedLimit : Input field

                    // Step 33.2 
                    property360OutputModel.PollutantCleanUpAndRemovalBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ModificationPollutantCleanUpAndRemovalCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 33.3 
                    property360OutputModel.PollutantCleanUpAndRemovalAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 33.4 
                    property360OutputModel.PollutantCleanUpAndRemoval360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.ModificationPollutantCleanUpAndRemoval360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 33.5 = (((Step 33.1 - Step 33.2)/ 100) +(Step 33.4 - Step 33.3)*(Step 33.1 / 100)) * Step A
                    property360OutputModel.PollutantCleanUpAndRemovalPremium = (((property360InputModel.ModificationPollutantCleanUpAndRemovalRevisedLimit
                                                                - property360OutputModel.PollutantCleanUpAndRemovalBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.PollutantCleanUpAndRemoval360DeductibleFactor
                                                                - property360OutputModel.PollutantCleanUpAndRemovalAOPDeductibleFactor)
                                                                * (property360InputModel.ModificationPollutantCleanUpAndRemovalRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;


                    property360OutputModel.PollutantCleanUpAndRemovalPremium = Math.Round(property360OutputModel.PollutantCleanUpAndRemovalPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.PollutantCleanUpAndRemovalPremium < minimumPremium)
                    {
                        property360OutputModel.PollutantCleanUpAndRemovalPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.PollutantCleanUpAndRemovalPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.ModificationPollutantCleanUpAndRemovalCoverageName, property360InputModel.ModificationPollutantCleanUpAndRemovalRevisedLimit, property360InputModel.IsModificationPollutantCleanUpAndRemovalCoverageSelected, additionalBenefits);
            #endregion

            #region Step 34 - Property In Transit

            if (property360InputModel.IsPropertyInTransitCoverageSelected)
            {
                if (property360InputModel.PropertyInTransitRevisedLimit == 0)
                {
                    property360OutputModel.PropertyInTransitPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PropertyInTransitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 34.1 property360Model.PropertyInTransitRevisedLimit : Input field

                    // Step 34.2 
                    property360OutputModel.PropertyInTransitBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PropertyInTransitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 34.3 
                    property360OutputModel.PropertyInTransitRate = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PropertyInTransitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    // Step 34.4 
                    property360OutputModel.PropertyInTransitAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.PropertyInTransitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 34.5 
                    property360OutputModel.PropertyInTransit360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.PropertyInTransitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 34.6 = (((Step 34.1 - Step 34.2)/ 100) +(Step 34.5 - Step 34.4)*(Step 34.1 / 100)) * Step 34.3
                    property360OutputModel.PropertyInTransitPremium = (((property360InputModel.PropertyInTransitRevisedLimit
                                                                - property360OutputModel.PropertyInTransitBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.PropertyInTransit360DeductibleFactor
                                                                - property360OutputModel.PropertyInTransitAOPDeductibleFactor)
                                                                * (property360InputModel.PropertyInTransitRevisedLimit
                                                                / 100))
                                                                * property360OutputModel.PropertyInTransitRate;

                    property360OutputModel.PropertyInTransitPremium = Math.Round(property360OutputModel.PropertyInTransitPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.PropertyInTransitPremium < minimumPremium)
                    {
                        property360OutputModel.PropertyInTransitPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.PropertyInTransitPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.PropertyInTransitCoverageName, property360InputModel.PropertyInTransitRevisedLimit, property360InputModel.IsPropertyInTransitCoverageSelected, additionalBenefits);
            #endregion

            #region Step 35 - Property Off-premises
            if (property360InputModel.IsPropertyOffPremisesCoverageSelected)
            {
                if (property360InputModel.PropertyOffPremisesRevisedLimit == 0)
                {
                    property360OutputModel.PropertyOffPremisesPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PropertyOffPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 35.1 property360Model.PropertyOffPremisesRevisedLimit : Input field

                    // Step 35.2 
                    property360OutputModel.PropertyOffPremisesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.PropertyOffPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 35.3 
                    property360OutputModel.PropertyOffPremisesAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 35.4 
                    property360OutputModel.PropertyOffPremises360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.PropertyOffPremises360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 35.5 = (((Step 35.1 - Step 35.2)/ 100) +(Step 35.4 - Step 35.3)*(Step 35.1 / 100)) * Step B
                    property360OutputModel.PropertyOffPremisesPremium = (((property360InputModel.PropertyOffPremisesRevisedLimit
                                                                - property360OutputModel.PropertyOffPremisesBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.PropertyOffPremises360DeductibleFactor
                                                                - property360OutputModel.PropertyOffPremisesAOPDeductibleFactor)
                                                                * (property360InputModel.PropertyOffPremisesRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.PropertyOffPremisesPremium = Math.Round(property360OutputModel.PropertyOffPremisesPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.PropertyOffPremisesPremium < minimumPremium)
                    {
                        property360OutputModel.PropertyOffPremisesPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.PropertyOffPremisesPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.PropertyOffPremisesCoverageName, property360InputModel.PropertyOffPremisesRevisedLimit, property360InputModel.IsPropertyOffPremisesCoverageSelected, additionalBenefits);
            #endregion

            #region Step 36 - Recharge of Fire Protection Equipment

            if (property360InputModel.IsRechargeOfFireProtectionEquipmentCoverageSelected)
            {
                if (property360InputModel.RechargeOfFireProtectionEquipmentRevisedLimit == 0)
                {
                    property360OutputModel.RechargeOfFireProtectionEquipmentPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.RechargeOfFireProtectionEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 36.1 property360Model.RechargeOfFireProtectionEquipmentRevisedLimit : Input field

                    // Step 36.2 
                    property360OutputModel.RechargeOfFireProtectionEquipmentBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.RechargeOfFireProtectionEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 36.3 
                    property360OutputModel.RechargeOfFireProtectionEquipmentRate = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.RechargeOfFireProtectionEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    // Step 36.4 
                    property360OutputModel.RechargeOfFireProtectionEquipmentAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.RechargeOfFireProtectionEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 36.5
                    property360OutputModel.RechargeOfFireProtectionEquipment360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.RechargeOfFireProtectionEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 36.6 = (((Step 36.1 - Step 36.2)/ 100) +(Step 36.5 - Step 36.4)*(Step 36.1 / 100)) * Step 36.3
                    property360OutputModel.RechargeOfFireProtectionEquipmentPremium = (((property360InputModel.RechargeOfFireProtectionEquipmentRevisedLimit
                                                                - property360OutputModel.RechargeOfFireProtectionEquipmentBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.RechargeOfFireProtectionEquipment360DeductibleFactor
                                                                - property360OutputModel.RechargeOfFireProtectionEquipmentAOPDeductibleFactor)
                                                                * (property360InputModel.RechargeOfFireProtectionEquipmentRevisedLimit
                                                                / 100))
                                                                * property360OutputModel.RechargeOfFireProtectionEquipmentRate;

                    property360OutputModel.RechargeOfFireProtectionEquipmentPremium = Math.Round(property360OutputModel.RechargeOfFireProtectionEquipmentPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.RechargeOfFireProtectionEquipmentPremium < minimumPremium)
                    {
                        property360OutputModel.RechargeOfFireProtectionEquipmentPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.RechargeOfFireProtectionEquipmentPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.RechargeOfFireProtectionEquipmentCoverageName, property360InputModel.RechargeOfFireProtectionEquipmentRevisedLimit, property360InputModel.IsRechargeOfFireProtectionEquipmentCoverageSelected, additionalBenefits);
            #endregion

            #region Step 37 - Retaining Walls
            if (property360InputModel.IsRetainingWallsCoverageSelected)
            {
                if (property360InputModel.RetainingWallsRevisedLimit == 0)
                {
                    property360OutputModel.RetainingWallsPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.RetainingWallsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 37.1 property360Model.RetainingWallsRevisedLimit : Input field

                    // Step 37.2 
                    property360OutputModel.RetainingWallsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.RetainingWallsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 37.3 
                    property360OutputModel.RetainingWallsAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 37.4 
                    property360OutputModel.RetainingWalls360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.RetainingWalls360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 37.5 = (((Step 37.1 - Step 37.2)/ 100) +(Step 37.4 - Step 37.3)*(Step 37.1 / 100)) * Step A
                    property360OutputModel.RetainingWallsPremium = (((property360InputModel.RetainingWallsRevisedLimit
                                                                - property360OutputModel.RetainingWallsBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.RetainingWalls360DeductibleFactor
                                                                - property360OutputModel.RetainingWallsAOPDeductibleFactor)
                                                                * (property360InputModel.RetainingWallsRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.RetainingWallsPremium = Math.Round(property360OutputModel.RetainingWallsPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.RetainingWallsPremium < minimumPremium)
                    {
                        property360OutputModel.RetainingWallsPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.RetainingWallsPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.RetainingWallsCoverageName, property360InputModel.RetainingWallsRevisedLimit, property360InputModel.IsRetainingWallsCoverageSelected, additionalBenefits);
            #endregion

            #region Step 38 - Reward Payments
            if (property360InputModel.IsRewardPaymentsCoverageSelected)
            {
                if (property360InputModel.RewardPaymentsRevisedLimit == 0)
                {
                    property360OutputModel.RewardPaymentsPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.RewardPaymentsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 38.1 property360Model.RewardPaymentsRevisedLimit : Input field

                    // Step 38.2 
                    property360OutputModel.RewardPaymentsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.RewardPaymentsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 38.3 
                    property360OutputModel.RewardPaymentsAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.RewardPaymentsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 38.4 
                    property360OutputModel.RewardPayments360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.RewardPaymentsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 38.5 = (((Step 38.1 - Step 38.2)/ 100) +(Step 38.4 - Step 38.3)*(Step 38.1 / 100)) * Step A
                    property360OutputModel.RewardPaymentsPremium = (((property360InputModel.RewardPaymentsRevisedLimit
                                                                - property360OutputModel.RewardPaymentsBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.RewardPayments360DeductibleFactor
                                                                - property360OutputModel.RewardPaymentsAOPDeductibleFactor)
                                                                * (property360InputModel.RewardPaymentsRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.RewardPaymentsPremium = Math.Round(property360OutputModel.RewardPaymentsPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.RewardPaymentsPremium < minimumPremium)
                    {
                        property360OutputModel.RewardPaymentsPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.RewardPaymentsPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.RewardPaymentsCoverageName, property360InputModel.RewardPaymentsRevisedLimit, property360InputModel.IsRewardPaymentsCoverageSelected, additionalBenefits);
            #endregion

            #region Step 39 - Salesperson’s Samples
            if (property360InputModel.IsSalespersonsSamplesCoverageSelected)
            {
                if (property360InputModel.SalespersonsSamplesRevisedLimit == 0)
                {
                    property360OutputModel.SalespersonsSamplesPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SalespersonsSamplesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 39.1 property360Model.SalespersonsSamplesRevisedLimit : Input field

                    // Step 39.2 
                    property360OutputModel.SalespersonsSamplesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SalespersonsSamplesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 39.3 
                    property360OutputModel.SalespersonsSamplesAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 39.4 
                    property360OutputModel.SalespersonsSamples360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.SalespersonsSamples360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 39.5 = (((Step 39.1 - Step 39.2)/ 100) +(Step 39.4 - Step 39.3)*(Step 39.1 / 100)) * Step B
                    property360OutputModel.SalespersonsSamplesPremium = (((property360InputModel.SalespersonsSamplesRevisedLimit
                                                                - property360OutputModel.SalespersonsSamplesBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.SalespersonsSamples360DeductibleFactor
                                                                - property360OutputModel.SalespersonsSamplesAOPDeductibleFactor)
                                                                * (property360InputModel.SalespersonsSamplesRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.SalespersonsSamplesPremium = Math.Round(property360OutputModel.SalespersonsSamplesPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.SalespersonsSamplesPremium < minimumPremium)
                    {
                        property360OutputModel.SalespersonsSamplesPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.SalespersonsSamplesPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.SalespersonsSamplesCoverageName, property360InputModel.SalespersonsSamplesRevisedLimit, property360InputModel.IsSalespersonsSamplesCoverageSelected, additionalBenefits);
            #endregion

            #region Step 40 -SCADA Upgrade
            if (property360InputModel.IsSCADAUpgradeCoverageSelected)
            {
                if (property360InputModel.SCADAUpgradeRevisedLimit == 0)
                {
                    property360OutputModel.SCADAUpgradePremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SCADAUpgradeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 40.1 property360Model.SCADAUpgradeRevisedLimit : Input field

                    // Step 40.2 
                    property360OutputModel.SCADAUpgradeBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SCADAUpgradeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 40.3 
                    property360OutputModel.SCADAUpgradeAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 40.4 
                    property360OutputModel.SCADAUpgrade360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.SCADAUpgrade360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 40.5 = (((Step 40.1 - Step 40.2)/ 100) +(Step 40.4 - Step 40.3)*(Step 40.1 / 100)) * Step B
                    property360OutputModel.SCADAUpgradePremium = (((property360InputModel.SCADAUpgradeRevisedLimit
                                                                - property360OutputModel.SCADAUpgradeBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.SCADAUpgrade360DeductibleFactor
                                                                - property360OutputModel.SCADAUpgradeAOPDeductibleFactor)
                                                                * (property360InputModel.SCADAUpgradeRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.SCADAUpgradePremium = Math.Round(property360OutputModel.SCADAUpgradePremium, MidpointRounding.AwayFromZero); //180
                    if (property360OutputModel.SCADAUpgradePremium < minimumPremium)
                    {
                        property360OutputModel.SCADAUpgradePremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.SCADAUpgradePremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.SCADAUpgradeCoverageName, property360InputModel.SCADAUpgradeRevisedLimit, property360InputModel.IsSCADAUpgradeCoverageSelected, additionalBenefits);
            #endregion

            #region Step 41- Sod, Trees, Shrubs, and Plants - Any One
            if (property360InputModel.IsSodTreesShrubsAndPlantsAnyOneCoverageSelected)
            {
                if (property360InputModel.SodTreesShrubsAndPlantsAnyOneRevisedLimit == 0)
                {
                    property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SodTreesShrubsAndPlantsAnyOneCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 41.1 property360Model.SodTreesShrubsAndPlantsAnyOneRevisedLimit : Input field

                    // Step 41.2 
                    property360OutputModel.SodTreesShrubsAndPlantsAnyOneBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SodTreesShrubsAndPlantsAnyOneCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 41.3 
                    property360OutputModel.SodTreesShrubsAndPlantsAnyOneRate = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SodTreesShrubsAndPlantsAnyOneCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    // Step 41.4 
                    property360OutputModel.SodTreesShrubsAndPlantsAnyOneAOPDeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.SodTreesShrubsAndPlantsAnyOneCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "AOP");

                    // Step 41.5 
                    property360OutputModel.SodTreesShrubsAndPlantsAnyOne360DeductibleFactor = property360DataAccess.Get360CoverageDeductibleFactor(property360InputModel.SodTreesShrubsAndPlantsAnyOneCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "360");

                    // Step 41.6 = (((Step 41.1 - Step 41.2)/ 100) +(Step 41.5 - Step 41.4)*(Step 41.1 / 100)) * Step 41.3
                    property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium = (((property360InputModel.SodTreesShrubsAndPlantsAnyOneRevisedLimit
                                                                - property360OutputModel.SodTreesShrubsAndPlantsAnyOneBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.SodTreesShrubsAndPlantsAnyOne360DeductibleFactor
                                                                - property360OutputModel.SodTreesShrubsAndPlantsAnyOneAOPDeductibleFactor)
                                                                * (property360InputModel.SodTreesShrubsAndPlantsAnyOneRevisedLimit
                                                                / 100))
                                                                * property360OutputModel.SodTreesShrubsAndPlantsAnyOneRate;

                    property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium = Math.Round(property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium < minimumPremium)
                    {
                        property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.SodTreesShrubsAndPlantsAnyOneCoverageName, property360InputModel.SodTreesShrubsAndPlantsAnyOneRevisedLimit, property360InputModel.IsSodTreesShrubsAndPlantsAnyOneCoverageSelected, additionalBenefits);
            #endregion

            #region Step 42  Sod, Trees, Shrubs, and Plants -Occurrence
            if (property360InputModel.IsSodTreesShrubsAndPlantsOccurrenceCoverageSelected)
            {
                if (property360InputModel.SodTreesShrubsAndPlantsOccurrenceRevisedLimit == 0)
                {
                    property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SodTreesShrubsAndPlantsOccurrenceCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 42.1 property360Model.SodTreesShrubsAndPlantsOccurrenceRevisedLimit : Input field

                    // Step 42.2 
                    property360OutputModel.SodTreesShrubsAndPlantsOccurrenceBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SodTreesShrubsAndPlantsOccurrenceCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 42.3 
                    property360OutputModel.SodTreesShrubsAndPlantsOccurrenceAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 42.4 
                    property360OutputModel.SodTreesShrubsAndPlantsOccurrence360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.SodTreesShrubsAndPlantsOccurrence360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 42.5 = (((Step 42.1 - Step 42.2)/ 100) +(Step 42.4 - Step 42.3)*(Step 42.1 / 100)) * Step A
                    property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium = (((property360InputModel.SodTreesShrubsAndPlantsOccurrenceRevisedLimit
                                                                - property360OutputModel.SodTreesShrubsAndPlantsOccurrenceBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.SodTreesShrubsAndPlantsOccurrence360DeductibleFactor
                                                                - property360OutputModel.SodTreesShrubsAndPlantsOccurrenceAOPDeductibleFactor)
                                                                * (property360InputModel.SodTreesShrubsAndPlantsOccurrenceRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium = Math.Round(property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium < minimumPremium)
                    {
                        property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.SodTreesShrubsAndPlantsOccurrenceCoverageName, property360InputModel.SodTreesShrubsAndPlantsOccurrenceRevisedLimit, property360InputModel.IsSodTreesShrubsAndPlantsOccurrenceCoverageSelected, additionalBenefits);
            #endregion

            #region Step 43 - Spoilage
            if (property360InputModel.IsSpoilageCoverageSelected)
            {
                if (property360InputModel.SpoilageRevisedLimit == 0)
                {
                    property360OutputModel.SpoilagePremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SpoilageCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 43.1 property360Model.SpoilageRevisedLimit : Input field

                    // Step 43.2 
                    property360OutputModel.SpoilageBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.SpoilageCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 43.2 
                    property360OutputModel.SpoilageRate = property360DataAccess.GetSpoilageRate(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, inputProperty.Property360InputModel.SpoilageDeductible);

                    // Step 43.5 = (Step 43.1 - Step 43.2)/100 )* Step 43.3 
                    property360OutputModel.SpoilagePremium = ((property360InputModel.SpoilageRevisedLimit
                                                                - property360OutputModel.SpoilageBaseLimit)
                                                                / 100)
                                                                * property360OutputModel.SpoilageRate;

                    property360OutputModel.SpoilagePremium = Math.Round(property360OutputModel.SpoilagePremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.SpoilagePremium < minimumPremium)
                    {
                        property360OutputModel.SpoilagePremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.SpoilagePremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.SpoilageCoverageName, property360InputModel.SpoilageRevisedLimit, property360InputModel.IsSpoilageCoverageSelected, additionalBenefits);
            #endregion

            #region Step 44 - Theft of Jewelry, Furs, Stamps, and Other Specified Items – Occurrence Limit

            if (property360InputModel.IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageSelected)
            {
                if (property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit == 0)
                {
                    property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 44.1 property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit : Input field

                    // Step 44.2 
                    property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 44.3 = ((Step 44.1 - Step 44.2)/100 )* Step B
                    property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium =
                                                                ((property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit
                                                                - property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitBaseLimit)
                                                                / 100)
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium = Math.Round(property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium < minimumPremium)
                    {
                        property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageName, property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit, property360InputModel.IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageSelected, additionalBenefits);
            #endregion

            #region Step 45 - Undamaged Leasehold Improvements

            if (property360InputModel.IsUndamagedLeaseholdImprovementsCoverageSelected)
            {
                if (property360InputModel.UndamagedLeaseholdImprovementsRevisedLimit == 0)
                {
                    property360OutputModel.UndamagedLeaseholdImprovementsPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.UndamagedLeaseholdImprovementsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 45.1 property360Model.UndamagedLeaseholdImprovementsRevisedLimit : Input field

                    // Step 45.2 
                    property360OutputModel.UndamagedLeaseholdImprovementsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.UndamagedLeaseholdImprovementsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 45.3 
                    property360OutputModel.UndamagedLeaseholdImprovementsAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 45.4 
                    property360OutputModel.UndamagedLeaseholdImprovements360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.UndamagedLeaseholdImprovements360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 45.5 = (((Step 45.1 - Step 45.2)/ 100) +(Step 45.4 - Step 45.3)*(Step 45.1 / 100)) * Step A
                    property360OutputModel.UndamagedLeaseholdImprovementsPremium = (((property360InputModel.UndamagedLeaseholdImprovementsRevisedLimit
                                                                - property360OutputModel.UndamagedLeaseholdImprovementsBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.UndamagedLeaseholdImprovements360DeductibleFactor
                                                                - property360OutputModel.UndamagedLeaseholdImprovementsAOPDeductibleFactor)
                                                                * (property360InputModel.UndamagedLeaseholdImprovementsRevisedLimit
                                                                / 100))
                                                                * outputProperty.BuildingFinalRate;

                    property360OutputModel.UndamagedLeaseholdImprovementsPremium = Math.Round(property360OutputModel.UndamagedLeaseholdImprovementsPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.UndamagedLeaseholdImprovementsPremium < minimumPremium)
                    {
                        property360OutputModel.UndamagedLeaseholdImprovementsPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.UndamagedLeaseholdImprovementsPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.UndamagedLeaseholdImprovementsCoverageName, property360InputModel.UndamagedLeaseholdImprovementsRevisedLimit, property360InputModel.IsUndamagedLeaseholdImprovementsCoverageSelected, additionalBenefits);
            #endregion

            #region Step 46 - Valuable Papers and Records Other than Electronic Data

            if (property360InputModel.IsValuablePapersAndRecordsOtherThanElectronicDataCoverageSelected)
            {
                if (property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit == 0)
                {
                    property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium = 0;
                }
                else
                {
                    minimumPremium = 0;
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 46.1 property360Model.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit : Input field

                    // Step 46.2 
                    property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 46.3 
                    property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 46.4 
                    property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicData360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.ValuablePapersAndRecordsOtherThanElectronicData360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 46.5 = (((Step 46.1 - Step 46.2)/ 100) +(Step 46.4 - Step 46.3)*(Step 27.1 / 100)) * Step B
                    property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium = (((property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit
                                                                - property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataBaseLimit)
                                                                / 100)
                                                                + (property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicData360DeductibleFactor
                                                                - property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataAOPDeductibleFactor)
                                                                * (property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit
                                                                / 100))
                                                                * outputProperty.ContentsFinalRate;

                    property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium = Math.Round(property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium < minimumPremium)
                    {
                        property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataCoverageName, property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit, property360InputModel.IsValuablePapersAndRecordsOtherThanElectronicDataCoverageSelected, additionalBenefits);
            #endregion

            // Calculating Total sum of Property 360 Modification premium.
            Calculate360TotalModificationPremium(model);
        }

        /// <summary>
        /// CalculateProperty360OptionalCoverage : Calculate Option Coverage premium
        /// </summary>
        /// <param name="model"></param>
        protected void CalculateProperty360OptionalCoverage(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

            var property360InputModel = inputProperty.Property360InputModel;
            var property360OutputModel = outputProperty.Property360OutputModel;

            if (property360OutputModel.BusinessIncomeAndExtraExpenseRate == 0)
            {
                // Step C- BI & EE Rate
                decimal v1 = Math.Round(this.propertyDataAccess.GetMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "BI and EE Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate), 3, MidpointRounding.AwayFromZero);
                property360OutputModel.BusinessIncomeAndExtraExpenseRate = outputProperty.BuildingFinalRate * v1;
                property360OutputModel.BusinessIncomeAndExtraExpenseRate = Math.Round(property360OutputModel.BusinessIncomeAndExtraExpenseRate, 3, MidpointRounding.AwayFromZero);
            }

            #region Step 50 - Optional coverage
            property360OutputModel.property360OptionalCoverageOutputModel = new Property360OptionalCoverageOutputModel();
            property360OutputModel.property360OptionalCoverageOutputModel.LossOfMunicipalTaxRevenuesOutputModel = new List<Property360OptionalLossOfMunicipalTaxRevenueOutputModel>();

            if (property360InputModel.Property360OptionalCoverageInputModel != null)
            {
                var outputLossOfTaxRevenuesModel = property360OutputModel.property360OptionalCoverageOutputModel.LossOfMunicipalTaxRevenuesOutputModel;
                var inputLossOfTaxRevenuesModel = property360InputModel.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel;

                if (inputLossOfTaxRevenuesModel != null && inputLossOfTaxRevenuesModel.Count > 0)
                {
                    foreach (var lossOfTaxRevenueInputModel in inputLossOfTaxRevenuesModel)
                    {
                        Property360OptionalLossOfMunicipalTaxRevenueOutputModel lossOfTaxRevenueOutputModel = new Property360OptionalLossOfMunicipalTaxRevenueOutputModel();

                        if (lossOfTaxRevenueInputModel.IsLossOfMunicipalTaxRevenueCoverageSelected && lossOfTaxRevenueInputModel.LossOfMunicipalTaxRevenueRevisedLimit > 0)
                        {
                            Property360DataAccess property360DataAccess = new Property360DataAccess(this.configuration, this.logger);

                            // Step 50.2 Rate
                            lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenueRate = property360OutputModel.BusinessIncomeAndExtraExpenseRate * 1.1M;

                            // 13-07-2021
                            // Round Rate up to 3 digit.
                            lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenueRate = Math.Round(lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenueRate, 3, MidpointRounding.AwayFromZero);

                            // Step 50.3 AOPDeductible
                            lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenueAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                            // Step 50.4 360Deductible
                            lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenue360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(lossOfTaxRevenueInputModel.LossOfMunicipalTaxRevenue360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                            // Step 50.5
                            if (lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenueAOPDeductibleFactor == lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenue360DeductibleFactor)
                            {
                                //(Step 50.2 * Step 50.1/100) 
                                lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenuePremium = lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenueRate
                                                                                  * (lossOfTaxRevenueInputModel.LossOfMunicipalTaxRevenueRevisedLimit
                                                                                  / 100);
                            }
                            // Step 50.6
                            else
                            {
                                //(Step 50.2 * Step 50.1/100) * Step 50.3
                                lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenuePremium = (lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenueRate
                                                                                  * (lossOfTaxRevenueInputModel.LossOfMunicipalTaxRevenueRevisedLimit
                                                                                  / 100))
                                                                                  * lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenueAOPDeductibleFactor;
                            }

                            lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenuePremium = Math.Round(lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenuePremium, MidpointRounding.AwayFromZero);
                        }
                        else
                        {
                            lossOfTaxRevenueOutputModel.LossOfMunicipalTaxRevenuePremium = 0;
                        }

                        lossOfTaxRevenueOutputModel.Id = lossOfTaxRevenueInputModel.Id;

                        outputLossOfTaxRevenuesModel.Add(lossOfTaxRevenueOutputModel);
                    }
                }

                outputProperty.Property360OptionalCoverageTotalPremium = outputLossOfTaxRevenuesModel.Sum(x => x.LossOfMunicipalTaxRevenuePremium); ;
            }

            #endregion            
        }

        /// <summary>
        /// CalculateProperty360GolfCoursesPremiums : Calculate Golf course premium.
        /// </summary>
        /// <param name="model"></param>
        protected void CalculateProperty360GolfCoursesPremiums(RaterFacadeModel model, Dictionary<string, decimal> additionalBenefits)
        {
            Property360DataAccess property360DataAccess = new Property360DataAccess(this.configuration, this.logger);

            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

            var property360InputModel = inputProperty.Property360InputModel;
            var property360OutputModel = outputProperty.Property360OutputModel;
            decimal minimumPremium = 0;

            #region Step 47 -Golf Courses - Tee to Green  
            if (property360InputModel.IsGolfCoursesTeeToGreenCoverageSelected)
            {
                if (property360InputModel.GolfCoursesTeeToGreenRevisedLimit == 0)
                {
                    property360OutputModel.GolfCoursesTeeToGreenPremium = 0;
                }
                else
                {
                    decimal X1 = 0;
                    decimal X2 = 0;

                    //Rate
                    property360OutputModel.GolfCoursesTeeToGreenRate = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GolfCoursesTeeToGreenName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    //Minimum premium
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GolfCoursesTeeToGreenName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    //AOPDeductibleFactor
                    property360OutputModel.GolfCoursesTeeToGreenAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    //360DeductibleFactor
                    property360OutputModel.GolfCoursesTeeToGreen360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.GolfCoursesTeeToGreen360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // X1 & X2 from Misc table.
                    DataTable datatable = new DataTable();

                    datatable = property360DataAccess.GetTeeToGreenFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, "Tee to Green Factor");

                    if (datatable != null && datatable.Rows.Count > 0)
                    {
                        if (datatable.Rows[0]["X1value"] != DBNull.Value)
                        {
                            X1 = Convert.ToDecimal(datatable.Rows[0]["X1value"]);
                        }
                        if (datatable.Rows[0]["X2value"] != DBNull.Value)
                        {
                            X2 = Convert.ToDecimal(datatable.Rows[0]["X2value"]);
                        }
                    }

                    //((((Step 47.1 - X1)/ 100)*Step 47.2 + X2)/ Step 47.3) *Step 47.4
                    //Step 47.5 - ((((Revised Limit - X1)/ 100)*Rate + X2)/ AOPDeductibleFactor) * 360DeductibleFactor
                    property360OutputModel.GolfCoursesTeeToGreenPremium = ((((property360InputModel.GolfCoursesTeeToGreenRevisedLimit
                                                                            - X1)
                                                                            / 100)
                                                                            * property360OutputModel.GolfCoursesTeeToGreenRate
                                                                            + X2)
                                                                             / property360OutputModel.GolfCoursesTeeToGreenAOPDeductibleFactor) * property360OutputModel.GolfCoursesTeeToGreen360DeductibleFactor;

                    property360OutputModel.GolfCoursesTeeToGreenPremium = Math.Round(property360OutputModel.GolfCoursesTeeToGreenPremium, MidpointRounding.AwayFromZero);

                    if (property360OutputModel.GolfCoursesTeeToGreenPremium < minimumPremium)
                    {
                        property360OutputModel.GolfCoursesTeeToGreenPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.GolfCoursesTeeToGreenPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.GolfCoursesTeeToGreenName, property360InputModel.GolfCoursesTeeToGreenRevisedLimit, property360InputModel.IsGolfCoursesTeeToGreenCoverageSelected, additionalBenefits);
            #endregion

            #region Step 48 - Golf Courses -Sprinkler and Underground Wiring            


            if (property360InputModel.IsGolfCoursesSprinklerAndUndergroundWiringCoverageSelected)
            {
                // Step 48.1 RevisedLimit UI Field
                if (property360InputModel.GolfCoursesSprinklerAndUndergroundWiringRevisedLimit == 0)
                {
                    property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium = 0;
                }
                else
                {
                    minimumPremium = 0;

                    // Step 48.2 BaseLimit
                    property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GolfCoursesSprinklerAndUndergroundWiringName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 48.3 Rate
                    property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringRate = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GolfCoursesSprinklerAndUndergroundWiringName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    // Minimum premium
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GolfCoursesSprinklerAndUndergroundWiringName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 48.4 AOPDeductible
                    property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 48.5 360Deductible
                    property360OutputModel.GolfCoursesSprinklerAndUndergroundWiring360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.GolfCoursesSprinklerAndUndergroundWiring360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    //Step 48.6 - ((((Step 48.1-Step 48.2)/100) * Step 48.3)/Step 48.4) * Step 48.5
                    property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium = ((((property360InputModel.GolfCoursesSprinklerAndUndergroundWiringRevisedLimit
                                                                                        - property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringBaseLimit)
                                                                                        / 100)
                                                                                        * property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringRate)
                                                                                         / property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringAOPDeductibleFactor)
                                                                                         * property360OutputModel.GolfCoursesSprinklerAndUndergroundWiring360DeductibleFactor;

                    property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium = Math.Round(property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium, MidpointRounding.AwayFromZero);
                    if (property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium < minimumPremium)
                    {
                        property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.GolfCoursesSprinklerAndUndergroundWiringName, property360InputModel.GolfCoursesSprinklerAndUndergroundWiringRevisedLimit, property360InputModel.IsGolfCoursesSprinklerAndUndergroundWiringCoverageSelected, additionalBenefits);
            #endregion Step 48

            #region Step 49 - Golf Courses -Additional Golf Course Property                       


            if (property360InputModel.IsGolfCoursesAdditionalGolfCoursePropertyCoverageSelected)
            {
                // Step 49.1 RevisedLimit UI Field
                if (property360InputModel.GolfCoursesAdditionalGolfCoursePropertyRevisedLimit == 0)
                {
                    property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium = 0;
                }
                else
                {
                    minimumPremium = 0;

                    // Step 49.2 BaseLimit
                    property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyBaseLimit = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GolfCoursesAdditionalGolfCoursePropertyName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    // Step 49.3 Rate
                    property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyRate = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GolfCoursesAdditionalGolfCoursePropertyName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    // Minimum premium
                    minimumPremium = property360DataAccess.GetProperty360CoverageDetail(property360InputModel.GolfCoursesAdditionalGolfCoursePropertyName, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Premium");

                    // Step 49.4 AOPDeductible
                    property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyAOPDeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step 49.5 360Deductible
                    property360OutputModel.GolfCoursesAdditionalGolfCourseProperty360DeductibleFactor = property360DataAccess.GetDollarDeductibleFactor(property360InputModel.GolfCoursesAdditionalGolfCourseProperty360Deductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    //Step 49.6 - ((((Step 49.1-Step 49.2)/100) * Step 49.3)/Step 49.4) * Step 49.5
                    property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium = ((((property360InputModel.GolfCoursesAdditionalGolfCoursePropertyRevisedLimit
                                                                                        - property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyBaseLimit)
                                                                                        / 100)
                                                                                        * property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyRate)
                                                                                         / property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyAOPDeductibleFactor)
                                                                                         * property360OutputModel.GolfCoursesAdditionalGolfCourseProperty360DeductibleFactor;

                    property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium = Math.Round(property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium, MidpointRounding.AwayFromZero);

                    if (property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium < minimumPremium)
                    {
                        property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium = minimumPremium;
                    }
                }
            }
            else
            {
                property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium = 0;
            }

            CalculateTIVAndAdditionalBenefits(property360InputModel.GolfCoursesAdditionalGolfCoursePropertyName, property360InputModel.GolfCoursesAdditionalGolfCoursePropertyRevisedLimit, property360InputModel.IsGolfCoursesAdditionalGolfCoursePropertyCoverageSelected, additionalBenefits);
            #endregion

            outputProperty.Property360GolfCourceTotalPremium = (property360OutputModel.GolfCoursesTeeToGreenPremium
                                                                            + property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium
                                                                            + property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium);
        }

        /// <summary>
        /// Calculate360TotalModificationPremium
        /// </summary>
        /// <param name="model"></param>
        protected void Calculate360TotalModificationPremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

            var property360OutputModel = outputProperty.Property360OutputModel;
            outputProperty.Property360ModificationCoverageTotalPremium = (property360OutputModel.OrdinanceOrLawCoverageBPremium
                                                                                    + property360OutputModel.OrdinanceOrLawCoverageCPremium
                                                                                    + property360OutputModel.AccountsReceivableRecordsPremium
                                                                                    + property360OutputModel.AppurtenantStructuresPremium
                                                                                    + property360OutputModel.AudioVisualAndCommunicationEquipmentPremium
                                                                                    + property360OutputModel.ChangesInTemperatureOrHumidityPremium
                                                                                    + property360OutputModel.CommandeeredPropertyPremium
                                                                                    + property360OutputModel.ComputerEquipmentPremium
                                                                                    + property360OutputModel.DebrisRemovalYourPremisesPremium
                                                                                    + property360OutputModel.DebrisRemovalWindBlownDebrisPremium
                                                                                    + property360OutputModel.ElectronicDataPremium
                                                                                    + property360OutputModel.FineArtsPremium
                                                                                    + property360OutputModel.FireDepartmentServiceChargePremium
                                                                                    + property360OutputModel.FungusWetRotDryRotAndBacteriaPremium
                                                                                    + property360OutputModel.GlassDisplayOrTrophyCasesPremium
                                                                                    + property360OutputModel.InventoryAndAppraisalPremium
                                                                                    + property360OutputModel.KeyCardPremium
                                                                                    + property360OutputModel.LockReplacementPremium
                                                                                    + property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium
                                                                                    + property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium
                                                                                    + property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium
                                                                                    + property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium
                                                                                    + property360OutputModel.NonOwnedDetachedTrailersPremium
                                                                                    + property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium
                                                                                    + property360OutputModel.OutdoorPropertyPremium
                                                                                    + property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium
                                                                                    + property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium
                                                                                    + property360OutputModel.PollutantCleanUpAndRemovalPremium
                                                                                    + property360OutputModel.PropertyInTransitPremium
                                                                                    + property360OutputModel.PropertyOffPremisesPremium
                                                                                    + property360OutputModel.RechargeOfFireProtectionEquipmentPremium
                                                                                    + property360OutputModel.RetainingWallsPremium
                                                                                    + property360OutputModel.RewardPaymentsPremium
                                                                                    + property360OutputModel.SalespersonsSamplesPremium
                                                                                    + property360OutputModel.SCADAUpgradePremium
                                                                                    + property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium
                                                                                    + property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium
                                                                                    + property360OutputModel.SpoilagePremium
                                                                                    + property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium
                                                                                    + property360OutputModel.UndamagedLeaseholdImprovementsPremium
                                                                                    + property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium
                                                                                    );
        }

        #endregion

        #region Property Schedule Rating.
        private protected virtual void CalculateSchedulePremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

            // Step 1
            decimal finalPropertyPremium = outputProperty.OtherModPremium;            

            // Step 2
            decimal totalPropertyLimit = outputProperty.TotalTIV;

            if (totalPropertyLimit == 0)
            {
                throw new Exception("OutputModel.Property.TotalTIV cannot be zero!");
            }

            // Step 3 PropertyRate	=	(Step 1 /Step 2)*100
            decimal propertyRate = Math.Round((finalPropertyPremium / totalPropertyLimit) * 100, 3, MidpointRounding.AwayFromZero);

            if (outputProperty.ScheduleRatingOutputModel == null)
            {
                outputProperty.ScheduleRatingOutputModel = new PropertyScheduleRatingOutputModel();
            }

            if (inputProperty.ScheduleRatingInputModels != null && inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels != null && inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels.Count > 0)
            {
                outputProperty.ScheduleRatingOutputModel.FinalPropertyPremium = finalPropertyPremium;
                outputProperty.ScheduleRatingOutputModel.IndividualScheduleRating = new List<BuildingScheduleOutputModel>();

                foreach (var item in inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels)
                {
                    var buildingSchedule = new BuildingScheduleOutputModel();

                    buildingSchedule.Bldg = item.Bldg;
                    buildingSchedule.Loc = item.Loc;

                    if (item.SquareFootage == 0)
                    {
                        throw new Exception("InputModel.PropertyScheduleRatingInputModel.buildingScheduleInputModels.SquareFootage cannot be zero!");
                    }

                    buildingSchedule.ItvPerSqFt =Math.Round(item.BuildingLimit / item.SquareFootage);

                    // Step 5 - Get system calculated value Building Premium = (Step 4 / 100) *Step 3
                    buildingSchedule.BuildingPremium = Math.Round((item.BuildingLimit / 100) * propertyRate, MidpointRounding.AwayFromZero);

                    // Step 8 - Get system calculated value COntent Premium = (Step 7 / 100) *Step 3
                    buildingSchedule.ContentPremium = Math.Round((item.ContentsLimit / 100) * propertyRate, MidpointRounding.AwayFromZero);

                    // Step 10 - Get system calculated value	Total Premium	=	Step 5 + Step 8
                    buildingSchedule.TotalPremium =Math.Round(buildingSchedule.BuildingPremium + buildingSchedule.ContentPremium,MidpointRounding.AwayFromZero);

                    outputProperty.ScheduleRatingOutputModel.IndividualScheduleRating.Add(buildingSchedule);
                }

                if (outputProperty.ScheduleRatingOutputModel.IndividualScheduleRating != null && outputProperty.ScheduleRatingOutputModel.IndividualScheduleRating.Count > 0)
                {
                    //Step 11 - Get system calculated value Total Schedule Premium i.e Total Building + Total Content = Total of Total premium

                    outputProperty.ScheduleRatingOutputModel.TotalSchedulePremium = outputProperty.ScheduleRatingOutputModel.IndividualScheduleRating.Sum(x => x.TotalPremium);
                    outputProperty.ScheduleRatingOutputModel.TotalSchedulePremium = Math.Round(outputProperty.ScheduleRatingOutputModel.TotalSchedulePremium, MidpointRounding.AwayFromZero);


                    outputProperty.ScheduleRatingOutputModel.TotalBuildings = inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels.Count;

                    outputProperty.ScheduleRatingOutputModel.TotalSquareFootage = Math.Round(inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels.Sum(x => x.SquareFootage), MidpointRounding.AwayFromZero);
                    outputProperty.ScheduleRatingOutputModel.AvgPricePerSquareFoot = Math.Round(outputProperty.ScheduleRatingOutputModel.IndividualScheduleRating.Average(x => x.ItvPerSqFt), MidpointRounding.AwayFromZero);
                    outputProperty.ScheduleRatingOutputModel.TotalBuildingPremium= Math.Round(outputProperty.ScheduleRatingOutputModel.IndividualScheduleRating.Sum(x => x.BuildingPremium), MidpointRounding.AwayFromZero);
                    outputProperty.ScheduleRatingOutputModel.TotalContentPremium= Math.Round(outputProperty.ScheduleRatingOutputModel.IndividualScheduleRating.Sum(x => x.ContentPremium), MidpointRounding.AwayFromZero);

                    //Calculation of Premium Adjustment		
                    //Step 12 - Get system calculated value : Difference	=	Step 1 - Step 11
                    var difference = outputProperty.ScheduleRatingOutputModel.FinalPropertyPremium - outputProperty.ScheduleRatingOutputModel.TotalSchedulePremium;

                    if (difference != 0)
                    {
                        //Step 13 - Get system calculated value : Highest value	=	Highest Total Premium
                        var highestValue = outputProperty.ScheduleRatingOutputModel.IndividualScheduleRating.Max(x => x.TotalPremium);

                        //Step 14 - Get system calculated value : Modified Premium	=	Step 13 + Step 12
                        outputProperty.ScheduleRatingOutputModel.BuildingModifiedPremium =Math.Round((highestValue + difference),MidpointRounding.AwayFromZero);
                    }
                    outputProperty.ScheduleRatingOutputModel.ModifiedTotalSchedulePremium =Math.Round((outputProperty.ScheduleRatingOutputModel.TotalSchedulePremium + difference),MidpointRounding.AwayFromZero);

                    outputProperty.ScheduleRatingOutputModel.Difference = difference;
                }
                else
                {
                    outputProperty.ScheduleRatingOutputModel.TotalSchedulePremium = 0;
                }
            }
            else
            {
                outputProperty.ScheduleRatingOutputModel.TotalSchedulePremium = 0;
            }
            outputProperty.ScheduleRatingOutputModel.PropertyRate = propertyRate;
        }
        #endregion

        public bool IsPackagePolicy(LobIncludedModel lineOfBusiness)
        {
            var isPackagePolicy = false;
            int count = 0;

            foreach (var prop in lineOfBusiness.GetType().GetProperties())
            {
                if (Convert.ToBoolean(prop.GetValue(lineOfBusiness)))
                {
                    count = count + 1;
                }
            }

            if (count > 1)
            {
                isPackagePolicy = true;
            }

            return isPackagePolicy;
        }

        private void CalculateTIVAndAdditionalBenefits(string selectedCoverageName, decimal revisedLimit, bool isSelected, Dictionary<string, decimal> additionalBenefits)
        {
            var selctedAdditionalBenefit = additionalBenefits.Where(x => x.Key == selectedCoverageName).ToDictionary(p => p.Key, p => p.Value);
            if (selctedAdditionalBenefit != null && selctedAdditionalBenefit.Count > 0)
            {
                if (isSelected)
                {
                    additionalBenefits[selectedCoverageName] = revisedLimit;
                    // return revisedLimit;
                }
                else
                {
                    if (selctedAdditionalBenefit.Values != null && selctedAdditionalBenefit.Values.Count > 0)
                    {
                    }
                    else
                    {
                        additionalBenefits[selectedCoverageName] = 0;
                        //return 0;
                    }
                }
            }
        }
    }
}
