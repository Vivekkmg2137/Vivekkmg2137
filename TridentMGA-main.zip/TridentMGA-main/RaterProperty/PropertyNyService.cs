﻿using DataAccess;
using DomainRules;
using Validations;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Models.ApiModels.LineOfBusiness.Property.Output;

namespace RaterProperty
{
    public class PropertyNyService : PropertyCwService, IPropertyService
    {
        private PropertyDataAccess propertyDataAccess;
        protected new ILoggingManager logger { get; set; }
        protected new IConfiguration configuration { get; set; }
        public PropertyNyService(IConfiguration configuration, ILoggingManager logger) : base(configuration, logger)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.propertyDataAccess = new PropertyDataAccess(this.configuration, this.logger);
        }

        public override DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            return validationResult;
        }

        public override FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new PropertyNyPreValidation(this.configuration, this.logger);
                var results = validator.Validate(model);
                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);

                throw;
            }
        }

        public override FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                var validator = new PropertyNyPostValidation(this.configuration, this.logger);
                var results = validator.Validate(model);
                return results;
            }
            catch (Exception ex)
            {
                this.logger.Error(ex.Message, ex);

                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public override void Calculate(RaterFacadeModel model)
        {
            Dictionary<string, decimal> additionalBenefits = new Dictionary<string, decimal>();
            try
            {
                this.logger.Info("PropertyNYService.CalculatePremium :: Started");

                // Step 1: Calculate Building BPP Premium
                this.CalculateBuildingBPPPremium(model);

                // Step 2 : Calculate Equipment Breakdown Premium
                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownCoverage)
                {                   
                    this.CalculateEquipmentBreakdownPremium(model);
                }

                // Step 3 :Calculate WindFlood Earthquake Premium
                this.CalculateWindFloodEarthquakePremium(model);

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel != null)
                {
                    // Step 4 : Calculate Option Coverage premium
                    this.CalculateOptionalCoveragePremium(model);
                }

                // Property NY 360 Coverage premium
                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel != null)
                {
                    this.CalculateProperty360CoveragePremium(model, additionalBenefits);
                }

                // Step 5 : Calculate Final Premium
                this.CalculateFinalPropertyPremium(model);

                this.logger.Info("PropertyNYService.CalculatePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyNYService.CalculatePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Building BPP premium for NY.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected override void CalculateBuildingBPPPremium(RaterFacadeModel model)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;
                var stateSpecificOutputProperty = outputProperty.PropertyStateSpecificOutputModel;

                var policyHeader = model.RaterInputFacadeModel.PolicyHeaderModel;

                policyHeader.State = policyHeader.State.ToUpper();
                policyHeader.PrimaryClass = policyHeader.PrimaryClass.ToUpper();
                policyHeader.TransactionType = policyHeader.TransactionType.ToUpper();

                this.logger.Info("PropertyNyService.CalculateBuildingBPPPremium :: Started");

                // Step-1 Read table using following as input parameters to get the Cause of Loss rate
                stateSpecificOutputProperty.NewYorkCauseofLossFactor = this.propertyDataAccess.GetCauseOfLoss(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, inputProperty.PropertyStateSpecificInputModel.NewYorkCauseofLoss, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step-2 Getting CoinsuranceFactor from CoinsuranceFactors table
                outputProperty.CoinsuranceFactor = this.propertyDataAccess.GetCoinsuranceFactor(inputProperty.Coinsurance, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step-3 Getting ValuationFactor from ValuationFactors table
                outputProperty.ValuationFactor = this.propertyDataAccess.GetValuationFactors(inputProperty.Valuation, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step-4 Getting AOPDeductibleFactor from DollarDeuctibleCredit lookup table
                outputProperty.AOPDeductibleFactor = this.propertyDataAccess.GetDeductibleFactor(inputProperty.AOPDeductible, model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step-5 Getting InflationGuardFactor from Inflation Guard table
                stateSpecificOutputProperty.NewYorkInflationGuardFactor = this.propertyDataAccess.GetInflationGuard(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, inputProperty.PropertyStateSpecificInputModel.NewYorkInflationGuard, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step-6 (Policy Expiration Date  -Transaction Effective Date)/(Policy Expiration Date - Policy Effective  Date)
                outputProperty.ProRatafactor = Convert.ToDecimal(((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate).TotalDays) / ((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).TotalDays));
                outputProperty.ProRatafactor = Math.Round(outputProperty.ProRatafactor, 2, MidpointRounding.AwayFromZero);

                if (model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage)
                {
                    // Step 7 - Terrorism Premium Calculation
                    // Read the terrorism Factor based on the State, LOB & Effective Date selected in a policy.
                    outputProperty.TerrorismFactor = this.propertyDataAccess.GetTerrorismFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }

                // Step 8 - Tier Premium Calculation
                // Read "Misc' table for 'Tier Factor' as "Factor Type" by passing State, LOB, Effective date.
                outputProperty.TierFactor = this.propertyDataAccess.GetMiscFactor(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, "Tier Factor", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // Step 9 -EquipmentBreakdownIRPMFactor
                outputProperty.EquipmentBreakdownIRPMFactor = inputProperty.IRPM / 100;

                // Step 10 -  Input field on UI Use OtherModFactor
                // "Repeat Steps 11 through 13 for each building group added to the policy (Group will be defined as buildings with same Hazard group, Protection Class & Construction Type)"

                outputProperty.ScheduleRatingOutputModel = new PropertyScheduleRatingOutputModel();

                if (inputProperty.ScheduleRatingInputModels != null && inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels != null && inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels.Count > 0)
                {
                    var groupedList = inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels
                                    .GroupBy(u => new { u.HazardGroup, u.Construction, u.ProtectionClass })
                                    .Select(grp => grp.ToList())
                                    .ToList();

                    List<GroupedBuildingScheduleOutputModel> groupedBuildingScheduleOutputModels = new List<GroupedBuildingScheduleOutputModel>();

                    if (groupedList != null && groupedList.Count > 0)
                    {
                        foreach (var group in groupedList)
                        {
                            GroupedBuildingScheduleOutputModel groupedScheduleOutputModel = new GroupedBuildingScheduleOutputModel();

                            foreach (var subgroup in group)
                            {
                                groupedScheduleOutputModel.BuildingLimit = groupedScheduleOutputModel.BuildingLimit + subgroup.BuildingLimit;
                                groupedScheduleOutputModel.ContentsLimit = groupedScheduleOutputModel.ContentsLimit + subgroup.ContentsLimit;
                                groupedScheduleOutputModel.HazardGroup = subgroup.HazardGroup;
                                groupedScheduleOutputModel.Construction = subgroup.Construction;
                                groupedScheduleOutputModel.ProtectionClass = subgroup.ProtectionClass;
                            }

                            if (groupedScheduleOutputModel != null)
                            {
                                // Step 11 -  Total Limit (UI field)
                                groupedScheduleOutputModel.TotalTIV = groupedScheduleOutputModel.BuildingLimit + groupedScheduleOutputModel.ContentsLimit;

                                // Step 12 -Read table using following as input parameters to get the Base Rates.                
                                groupedScheduleOutputModel.BaseRate = this.propertyDataAccess.GetBaseRates(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, groupedScheduleOutputModel.HazardGroup, groupedScheduleOutputModel.ProtectionClass, groupedScheduleOutputModel.Construction, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                                // Step 13 (Step 11/100) * Step 12 * Step 1 * Step 2 * Step 3 * Step 4 * Step 5              
                                groupedScheduleOutputModel.BuildingPremium = (groupedScheduleOutputModel.TotalTIV / 100)
                                                                                * groupedScheduleOutputModel.BaseRate
                                                                                * stateSpecificOutputProperty.NewYorkCauseofLossFactor
                                                                                * outputProperty.CoinsuranceFactor
                                                                                * outputProperty.ValuationFactor
                                                                                * outputProperty.AOPDeductibleFactor
                                                                                * stateSpecificOutputProperty.NewYorkInflationGuardFactor;

                                groupedScheduleOutputModel.BuildingPremium = Math.Round(groupedScheduleOutputModel.BuildingPremium, MidpointRounding.AwayFromZero);

                                groupedBuildingScheduleOutputModels.Add(groupedScheduleOutputModel);
                                                                
                               // outputProperty.ScheduleRatingOutputModel.ModifiedTotalPremium = outputProperty.ScheduleRatingOutputModel.ModifiedTotalPremium + groupedScheduleOutputModel.BuildingPremium;
                            }
                        }
                    }
                    outputProperty.ScheduleRatingOutputModel.GroupedScheduleRatings = groupedBuildingScheduleOutputModels;
                }

                if (outputProperty.ScheduleRatingOutputModel != null && outputProperty.ScheduleRatingOutputModel.GroupedScheduleRatings != null && outputProperty.ScheduleRatingOutputModel.GroupedScheduleRatings.Count > 0)
                {
                    outputProperty.TotalTIV = outputProperty.ScheduleRatingOutputModel.GroupedScheduleRatings.Sum(x => x.TotalTIV);
                    outputProperty.BuildingTIV = outputProperty.ScheduleRatingOutputModel.GroupedScheduleRatings.Sum(x => x.BuildingLimit);
                    outputProperty.ContentTIV = outputProperty.ScheduleRatingOutputModel.GroupedScheduleRatings.Sum(x => x.ContentsLimit);

                    // Step- 14 Sum of Building Premium of all the added building groups
                    outputProperty.PropertyStateSpecificOutputModel.NewYorkTotalBuildingPremium = Math.Round(outputProperty.ScheduleRatingOutputModel.GroupedScheduleRatings.Sum(x => x.BuildingPremium), MidpointRounding.AwayFromZero);

                    if (outputProperty.TotalTIV == 0)
                    {
                        throw new Exception("OutputModel.Property.TotalTIV cannot be zero!");
                    }

                    outputProperty.ScheduleRatingOutputModel.GroupedScheduleRatings.ForEach(x =>
                    {
                        x.SOVPercent = (x.TotalTIV / outputProperty.TotalTIV) * 100;
                        x.SOVPercent = Math.Round(x.SOVPercent, MidpointRounding.AwayFromZero);
                    });
                }
                else
                {
                    outputProperty.TotalTIV = 0;
                }

                this.logger.Info("PropertyNyService.CalculateBuildingBPPPremium :: Completed");
            }
            catch (Exception ex)
            {
                logger.Error("PropertyNyService.CalculateBuildingBPPPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate Equipment Breakdown premium for NY.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected override void CalculateEquipmentBreakdownPremium(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

            try
            {
                this.logger.Info("PropertyNyService.CalculateEquipmentBreakdownPremium :: Started");

                //Do not execute step 15 when Referral is selected as Yes
                if (inputProperty.ReferredEquipmentBreakdownCoverage == false)
                {
                    // Step 15 - EB Premium calculation
                    // Step 15.1 Input field EquipmentBreakdownLimit 
                    // Step 15.2 Input field EquipmentBreakdownRate
                    // Step 15.3 (Step 15.1/100) * Step 15.2

                    // 14-07-2021
                    //The default rate is 0.0200.
                    //If rate is not overriden by the user, then default rate will be used.
                    //If rate is overrriden by the user, then use the Rate entered by the user.
                    if (inputProperty.EquipmentBreakdownRate > 0)
                    {
                        outputProperty.EquipmentBreakdownTotalPremium = Math.Round((inputProperty.PropertyStateSpecificInputModel.NewYorkEquipmentBreakdownLimit
                                                                                                / 100)
                                                                                                * inputProperty.EquipmentBreakdownRate, 4, MidpointRounding.AwayFromZero);
                    }
                    else
                    {
                        outputProperty.EquipmentBreakdownTotalPremium = Math.Round((inputProperty.PropertyStateSpecificInputModel.NewYorkEquipmentBreakdownLimit
                                                                                                / 100)
                                                                                                * (decimal)0.0200, 4, MidpointRounding.AwayFromZero);
                    }
                }
                //Execute this step only when Referral is selected as Yes &  Premium is manually entered
                else
                {
                    // Step 16 - Referred EB Coverage Rate Calculation
                    // Step 16.1 input EquipmentBreakdownTotalPremium
                    // Step 16.2 input EquipmentBreakdownLimit
                    // Step 16.3 Calculate EquipmentBreakdownRate = (Step 16.1 * 100)/Step 16.2
                    outputProperty.EquipmentBreakdownRate = (inputProperty.InputEquipmentBreakdownTotalPremium
                                                                       * 100)
                                                                       / inputProperty.PropertyStateSpecificInputModel.NewYorkEquipmentBreakdownLimit;
                    // 14-07-2021
                    outputProperty.EquipmentBreakdownRate = Math.Round(outputProperty.EquipmentBreakdownRate,
                                                                        4, MidpointRounding.AwayFromZero);
                }

                this.logger.Info("PropertyNyService.CalculateEquipmentBreakdownPremium :: Completed");

            }
            catch (Exception ex)
            {
                logger.Error("PropertyNyService.CalculateEquipmentBreakdownPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate WindFloodEarthquakePremium for NY.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected override void CalculateWindFloodEarthquakePremium(RaterFacadeModel model)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;
                var stateSpecificOutputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel;

                this.logger.Info("PropertyNyService.CalculateWindFloodEarthquakePremium :: Started");

                //Windstorm and Hail Coverage Calculation
                if (inputProperty.WindstormAndHailCoverage == true)
                {
                    //Case 1 : When Premium is manually entered execute step 18
                    //Case 2 : When Rate is manually entered execute step 17

                    if (inputProperty.PropertyStateSpecificInputModel.NewYorkInputWindTotalPremium == 0)
                    {
                        // Step 17 - Wind & Hail Premium Calculations

                        // Step 17.1 NewYorkWindAndHailLimit
                        stateSpecificOutputProperty.NewYorkWindAndHailLimit = outputProperty.TotalTIV;

                        // Step 17.2 NewYorkWindAndHailRate : Input field

                        // (Step 17.1 / 100) *Step 17.2
                        // 14-07-2021
                        //The default rate is 0.0000.
                        //If rate is not overriden by the user, then default rate will be used.
                        //If rate is overrriden by the user, then use the Rate entered by the user.
                        if (inputProperty.PropertyStateSpecificInputModel.NewYorkWindAndHailRate > 0)
                        {
                            outputProperty.WindTotalPremium = Math.Round((outputProperty.TotalTIV / 100)
                                                * inputProperty.PropertyStateSpecificInputModel.NewYorkWindAndHailRate, MidpointRounding.AwayFromZero);

                        }
                        else
                        {
                            outputProperty.WindTotalPremium = Math.Round((outputProperty.TotalTIV / 100)
                                                * 0, MidpointRounding.AwayFromZero);
                        }

                    }
                    //Execute this step only when Premium is manually entered
                    else
                    {
                        // Step 18.1 WindTotalPremium : Input field

                        // Step 18.2 NewYorkWindAndHailLimit
                        stateSpecificOutputProperty.NewYorkWindAndHailLimit = outputProperty.TotalTIV;

                        if (outputProperty.TotalTIV == 0)
                        {
                            throw new Exception("OutputModel.Property.TotalTIV cannot be zero!");
                        }
                        // Step 18.3 (Step 18.1 * 100)/Step 18.2
                        // 14-07-2021
                        stateSpecificOutputProperty.NewYorkWindAndHailRate = Math.Round((inputProperty.PropertyStateSpecificInputModel.NewYorkInputWindTotalPremium
                                                                       * 100)
                                                                       / outputProperty.TotalTIV,
                                                                       4, MidpointRounding.AwayFromZero);
                    }
                }

                //Earthquake Coverage Calculations
                if (inputProperty.EarthquakeCoverage == true)
                {
                    //When Premium is manually entered, do not execute this step
                    if (inputProperty.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium == 0)
                    {
                        // Step 19 - Earthquake Premium calculations
                        // Step 19.1 Input field   NY_EarthquakeLimit
                        // Step 19.2 Input field   NewYorkEarthquakeRate

                        // Step 19.3 (Step 19.1/100) * Step 19.2
                        // 14-07-2021
                        //The default rate is 0.0200.
                        //If rate is not overriden by the user, then default rate will be used.
                        //If rate is overrriden by the user, then use the Rate entered by the user.

                        if (inputProperty.PropertyStateSpecificInputModel.NewYorkEarthquakeRate > 0)
                        {
                            outputProperty.EarthquakeTotalPremium = Math.Round((inputProperty.PropertyStateSpecificInputModel.NewYorkEarthquakeLimit
                                                                                                         / 100)
                                                                                                         * inputProperty.PropertyStateSpecificInputModel.NewYorkEarthquakeRate, MidpointRounding.AwayFromZero);
                        }
                        else
                        {
                            outputProperty.EarthquakeTotalPremium = Math.Round((inputProperty.PropertyStateSpecificInputModel.NewYorkEarthquakeLimit
                                                                                                                                     / 100)
                                                                                                                                     * (decimal)0.0200, MidpointRounding.AwayFromZero);
                        }
                    }
                    else
                    {
                        // Step 20 - Earthquake Coverage Rate Calculation
                        // Step 20.1 Input field    model.EarthquakeTotalPremium
                        // Step 20.2 Input field    model.NY_EarthquakeLimit

                        // Step 20.3 (Step 20.1 * 100)/Step 20.2) 
                        // 14-07-2021
                        stateSpecificOutputProperty.NewYorkEarthquakeRate = Math.Round((inputProperty.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium
                                                                                  * 100)
                                                                                  / inputProperty.PropertyStateSpecificInputModel.NewYorkEarthquakeLimit,
                                                                                  4, MidpointRounding.AwayFromZero);
                    }
                }

                //Flood Coverage Calculations
                if (inputProperty.FloodCoverage == true)
                {
                    //When Premium is manually entered, do not execute this step
                    if (inputProperty.PropertyStateSpecificInputModel.NewYorkInputFloodTotalPremium == 0)
                    {
                        // Step 21 - Flood Premium Calculation 
                        // Step 21.1 Limit
                        // Step 21.2 Rate

                        // Step 21.3 (Step 21.1/100) * Step 21.2
                        // 14-07-2021
                        //The default rate is 0.0200.
                        //If rate is not overriden by the user, then default rate will be used.
                        //If rate is overrriden by the user, then use the Rate entered by the user.
                        if (inputProperty.PropertyStateSpecificInputModel.NewYorkFloodRate > 0)
                        {
                            outputProperty.FloodTotalPremium = Math.Round((inputProperty.PropertyStateSpecificInputModel.NewYorkFloodLimit
                                                                                                    / 100)
                                                                                                    * inputProperty.PropertyStateSpecificInputModel.NewYorkFloodRate, MidpointRounding.AwayFromZero);
                        }
                        else
                        {
                            outputProperty.FloodTotalPremium = Math.Round((inputProperty.PropertyStateSpecificInputModel.NewYorkFloodLimit
                                                                                                                               / 100)
                                                                                                                               * (decimal)0.0200, MidpointRounding.AwayFromZero);
                        }
                    }
                    else
                    {
                        // Step 22 - Flood Coverage Rate Calculation
                        // Step 22.1 Premium
                        // Step 22.2 Limit

                        // Step 22.3 (Step 22.1 * 100)/Step 22.2
                        // 14-07-2021
                        stateSpecificOutputProperty.NewYorkFloodRate = Math.Round((inputProperty.PropertyStateSpecificInputModel.NewYorkInputFloodTotalPremium
                                                                           * 100)
                                                                           / inputProperty.PropertyStateSpecificInputModel.NewYorkFloodLimit,
                                                                           4, MidpointRounding.AwayFromZero);
                    }
                }

                this.logger.Info("PropertyNyService.CalculateWindFloodEarthquakePremium :: Completed");

            }
            catch (Exception ex)
            {
                logger.Error("PropertyNyService.CalculateWindFloodEarthquakePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate CalculateOptionalCoveragePremium for NY.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected override void CalculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

                outputProperty.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageOutputModel();
                outputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageOutputModel = new List<PropertyOptionalOtherCoverageOutputModel>();
                var outputOptionalOthersCoverages = outputProperty.PropertyOptionalCoveragesModel;

                this.logger.Info("PropertyBaseService.CalculateOptionalCoveragePremium :: Started");

                if (inputProperty.PropertyOptionalCoveragesModel.IsMoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceCoverageSelected)
                {
                    outputProperty.OptionalCoverageTotalPremium = outputProperty.OptionalCoverageTotalPremium + inputProperty.PropertyOptionalCoveragesModel.MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium;
                    outputProperty.PropertyOptionalCoveragesModel.MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium = inputProperty.PropertyOptionalCoveragesModel.MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium;
                }

                if (inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel != null && inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel.Count > 0)
                {
                    inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel = inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel.Where(x => x.IsOptionalCoverageSelected).ToList();

                    // Calculating OptionalCoverageTotalPremium
                    foreach (var optionalCoverage in inputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                    {
                        // Step 3 ((Step 1 /1000) * Step 2) OtherPremium : (OtherLimit / 1000) * OtherRate
                        if (optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER" && optionalCoverage.RatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                        {
                            optionalCoverage.Premium = ((optionalCoverage.Limit / 1000) * optionalCoverage.Rate);
                        }

                        // Step 3 ((Step 1 /1000) * Step 2) OtherPremium : (OtherLimit / 100) * OtherRate
                        else if (optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER" && optionalCoverage.RatingBasis.ToUpper() == "PER 100 OF LIMIT")
                        {
                            optionalCoverage.Premium = ((optionalCoverage.Limit / 100) * optionalCoverage.Rate);
                        }

                        optionalCoverage.Premium = Math.Round(optionalCoverage.Premium, MidpointRounding.AwayFromZero);

                        outputProperty.OptionalCoverageTotalPremium = outputProperty.OptionalCoverageTotalPremium + optionalCoverage.Premium;
                        outputProperty.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageOutputModel.Add(new PropertyOptionalOtherCoverageOutputModel()
                        {
                            Id = optionalCoverage.Id,
                            Premium = optionalCoverage.Premium
                        });
                    }
                }

                this.logger.Info("PropertyBaseService.CalculateOptionalCoveragePremium :: Completed");
            }
            catch (Exception ex)
            {
                this.logger.Error("PropertyBaseService.CalculateOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// Calculate the final property premium for NY.
        /// </summary>
        /// <param name="model">RaterPropertyModel.</param>
        private protected override void CalculateFinalPropertyPremium(RaterFacadeModel model)
        {
            try
            {
                var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
                var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;
                var stateSpecificOutputProperty = outputProperty.PropertyStateSpecificOutputModel;

                this.logger.Info("PropertyNyService.CalculateFinalPropertyPremium :: Started");

                // Read Minimum Premium lookup table to get Minimum Premium
                outputProperty.LOBMinimumPremium = this.propertyDataAccess.GetLOBTotalPremium(model.RaterInputFacadeModel.PolicyHeaderModel.State, inputProperty.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                // 14-07-2021
                // Round Property360TotalPremiums up to nearest digit.
                outputProperty.LOBMinimumPremium = Math.Round(outputProperty.LOBMinimumPremium, MidpointRounding.AwayFromZero);

                outputProperty.EquipmentBreakdownTotalPremium = inputProperty.ReferredEquipmentBreakdownCoverage == true ? inputProperty.InputEquipmentBreakdownTotalPremium : outputProperty.EquipmentBreakdownTotalPremium;

                if (inputProperty.WindstormAndHailCoverage == true)
                {
                    outputProperty.WindTotalPremium = outputProperty.WindTotalPremium == 0 ? inputProperty.PropertyStateSpecificInputModel.NewYorkInputWindTotalPremium : outputProperty.WindTotalPremium;
                }
                if (inputProperty.EarthquakeCoverage == true)
                {
                    outputProperty.EarthquakeTotalPremium = outputProperty.EarthquakeTotalPremium == 0 ? inputProperty.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium : outputProperty.EarthquakeTotalPremium;
                }
                if (inputProperty.FloodCoverage == true)
                {
                    outputProperty.FloodTotalPremium = outputProperty.FloodTotalPremium == 0 ? inputProperty.PropertyStateSpecificInputModel.NewYorkInputFloodTotalPremium : outputProperty.FloodTotalPremium;
                }

                // Step A -Base Premium Calculation
                // Step 14 + Step 15.3/Step 16.1 + Step 17.3/Step 18.1 + Step 19.3/Step 20.1 + Step 21.3/Step 22.1) * Step 6                
                outputProperty.BasePremium = (outputProperty.PropertyStateSpecificOutputModel.NewYorkTotalBuildingPremium
                                                           + outputProperty.EquipmentBreakdownTotalPremium
                                                           + outputProperty.WindTotalPremium
                                                           + outputProperty.EarthquakeTotalPremium
                                                           + outputProperty.FloodTotalPremium)
                                                           * outputProperty.ProRatafactor;

                // 14-07-2021
                // Round Property360TotalPremiums up to nearest digit.
                outputProperty.BasePremium = Math.Round(outputProperty.BasePremium, MidpointRounding.AwayFromZero);

                // Step B.1- Non-Modified Premium Calculation 
                // Step B.2 (Step B.1 * Step 6)
                outputProperty.NonModifiedPremium = outputProperty.OptionalCoverageTotalPremium * outputProperty.ProRatafactor;

                // 14-07-2021
                // Round Property360TotalPremiums up to nearest digit.
                outputProperty.NonModifiedPremium = Math.Round(outputProperty.NonModifiedPremium, MidpointRounding.AwayFromZero);

                // Step C.1 -Manual Premium Calculation
                // Step 14 + Step 15.3 / Step 16.1 + Step 17.3 / Step 18.1 + Step 19.3 / Step 20.1 + Step 21.3 / Step 22.1 + Step B.2 + Step 27) *Step 6                
                outputProperty.ManualPremium = (outputProperty.PropertyStateSpecificOutputModel.NewYorkTotalBuildingPremium
                                                            + outputProperty.EquipmentBreakdownTotalPremium
                                                            + outputProperty.WindTotalPremium
                                                            + outputProperty.EarthquakeTotalPremium
                                                            + outputProperty.FloodTotalPremium
                                                            + outputProperty.NonModifiedPremium
                                                            + outputProperty.PropertyStateSpecificOutputModel.NewYorkProperty360TotalPremiums)
                                                            * outputProperty.ProRatafactor;

                outputProperty.ManualPremium = Math.Round(outputProperty.ManualPremium, MidpointRounding.AwayFromZero);

                // Step C.2
                // "This step will be executed only If calculated Manual Premium in step C < LOB Minimum Premium"
                if (outputProperty.ManualPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.ManualPremium = outputProperty.LOBMinimumPremium;
                }

                // Step D - Tier Premium Calculation
                // ((Step C.1 - Step B.2) *Step 8) +Step B.2                
                outputProperty.TierPremium = ((outputProperty.ManualPremium
                                                                      - outputProperty.NonModifiedPremium)
                                                                      * outputProperty.TierFactor)
                                                                      + outputProperty.NonModifiedPremium;

                outputProperty.TierPremium = Math.Round(outputProperty.TierPremium, MidpointRounding.AwayFromZero);

                // Step D.2   
                // "This step will be executed only If calculated Tier Premium in step D < LOB Minimum Premium"
                if (outputProperty.TierPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.TierPremium = outputProperty.LOBMinimumPremium;
                }

                // Step E - IRPM Premium Calculation  ((Step D.1 - Step B.2) * Step 9) + Step B.2               
                outputProperty.IRPMPremium = ((outputProperty.TierPremium
                                                                    - outputProperty.NonModifiedPremium)
                                                                    * outputProperty.EquipmentBreakdownIRPMFactor)
                                                                    + outputProperty.NonModifiedPremium;

                outputProperty.IRPMPremium = Math.Round(outputProperty.IRPMPremium, MidpointRounding.AwayFromZero);

                // Step E.2
                //"This step will be executed only If calculated IRPM Premium in step E < LOB Minimum Premium"
                if (outputProperty.IRPMPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.IRPMPremium = outputProperty.LOBMinimumPremium;
                }

                // Step F - Other Mod Premium Calculation    ((Step E.1 - Step B.2) * Step 10) + Step B.2
                // OtherModPremiumCalculation : ((IRPMPremiumCalculation - NonModifiedPremiumCalculation) * OtherModFactor) + NonModifiedPremiumCalculation
                outputProperty.OtherModPremium = ((outputProperty.IRPMPremium
                                                                         - outputProperty.NonModifiedPremium)
                                                                         * inputProperty.OtherModFactor)
                                                                         + outputProperty.NonModifiedPremium;

                outputProperty.OtherModPremium = Math.Round(outputProperty.OtherModPremium, MidpointRounding.AwayFromZero);

                // Step F.2
                // "This step will be executed only If calculated Other Mod Premium in step F < LOB Minimum Premium"
                if (outputProperty.OtherModPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.OtherModPremium = outputProperty.LOBMinimumPremium;
                }

                if (model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage)
                {
                    // Step G - Terrorism Premium Calculation  (Step F * Step 7 )
                    // TerrorismPremiumCalculation : (OtherModPremiumCalculation * TerrorismFactor)
                    outputProperty.TerrorismPremium = Math.Round(outputProperty.OtherModPremium
                                                                        * outputProperty.TerrorismFactor, MidpointRounding.AwayFromZero);
                }

                // Step H - Modified Premium Calculation	(Step G + Step F)
                // ModifiedPremiumCalculation : (OtherModPremiumCalculation + TerrorismPremiumCalculation)
                outputProperty.ModifiedPremium = Math.Round(outputProperty.TerrorismPremium
                                                                        + outputProperty.OtherModPremium, MidpointRounding.AwayFromZero);

                // Step H.2
                // "This step will be executed only If calculated Modified Premium in step H < LOB Minimum Premium"
                if (outputProperty.ModifiedPremium < outputProperty.LOBMinimumPremium)
                {
                    outputProperty.ModifiedPremium = outputProperty.LOBMinimumPremium;
                }

                // Property schedule rating calculation
                if (model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.NEWBUSINESS || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.RENEWAL || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.ENDORSEMENT)
                {
                    this.CalculateSchedulePremium(model);
                }

                var isPackagePolicy = this.IsPackagePolicy(model.RaterInputFacadeModel.LineOfBusiness);

                // Step I -NY Fire Insurance Fee
                // Step I.1 (Step 14 + Step 27) * Step 6 * Step 8 * Step 9 * Step 10
                if ((!isPackagePolicy && (model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.NEWBUSINESS || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.RENEWAL)) ||
                    (isPackagePolicy && (model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.NEWBUSINESS || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.RENEWAL || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == TransactionTypeConstant.ENDORSEMENT)))
                {
                    stateSpecificOutputProperty.NewYorkUWPremiumFireExposure = (outputProperty.PropertyStateSpecificOutputModel.NewYorkTotalBuildingPremium
                                                            + outputProperty.PropertyStateSpecificOutputModel.NewYorkProperty360TotalPremiums)
                                                            * outputProperty.ProRatafactor
                                                            * outputProperty.TierFactor
                                                            * outputProperty.EquipmentBreakdownIRPMFactor
                                                            * inputProperty.OtherModFactor;

                    stateSpecificOutputProperty.NewYorkUWPremiumFireExposure = Math.Round(stateSpecificOutputProperty.NewYorkUWPremiumFireExposure, 2, MidpointRounding.AwayFromZero);

                    // Step I.2   Read table using following as input parameters to get the Misc.
                    stateSpecificOutputProperty.NewYorkFireInsuranceRate = this.propertyDataAccess.GetNYFireInsuranceFee(model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, inputProperty.LineOfBusiness, "NY Fire Insurance Fee", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                    // Step I.3   (Step I.1 * Step I.2)
                    stateSpecificOutputProperty.NewYorkFireInsuranceFeeCharge = Math.Round(stateSpecificOutputProperty.NewYorkUWPremiumFireExposure * stateSpecificOutputProperty.NewYorkFireInsuranceRate, 2, MidpointRounding.AwayFromZero);
                }

                this.logger.Info("PropertyNyService.CalculateFinalPropertyPremium :: Completed");

            }
            catch (Exception ex)
            {
                logger.Error("PropertyNyService.CalculateFinalPropertyPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region Property NY 360
        /// <summary>
        /// CalculateProperty360CoveragePremium
        /// </summary>
        /// <param name="model"></param>
        private protected override void CalculateProperty360CoveragePremium(RaterFacadeModel model, Dictionary<string, decimal> additionalBenefits)
        {
            var NY360InputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel;
            var NY360OutputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel;

            Property360DataAccess property360DataAccess = new Property360DataAccess(this.configuration, this.logger);

            #region Accounts Receivable Records	


            if (NY360InputProperty.IsAccountsReceivableRecordsCoverageSelected && NY360InputProperty.AccountsReceivableRecordsRevisedLimit > 0)
            {
                //step 1  NY360InputProperty.AccountsReceivableRecordsRevisedLimit

                //step 2 
                NY360OutputProperty.AccountsReceivableRecordsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.AccountsReceivableRecordsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.AccountsReceivableRecordsRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.AccountsReceivableRecordsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");


                // step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.AccountReceivablePremium = Math.Round(((NY360InputProperty.AccountsReceivableRecordsRevisedLimit
                                                                                                - NY360OutputProperty.AccountsReceivableRecordsBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.AccountsReceivableRecordsRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.AccountReceivablePremium = 0;
            }


            #endregion

            #region Building OrdinanceORLaw - Demolition Cost Coverage 

            if (NY360InputProperty.IsBuildingOrdinanceORLawDemolitionCostCoverageSelected && NY360InputProperty.BuildingOrdinanceORLawDemolitionCostRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.BuildingOrdinanceORLawDemolitionCostRevisedLimit 

                //Step 2
                NY360OutputProperty.BuildingOrdinanceORLawDemolitionCostBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.BuildingOrdinanceORLawDemolitionCostCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //Step 3
                NY360OutputProperty.BuildingOrdinanceORLawDemolitionCostRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.BuildingOrdinanceORLawDemolitionCostCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //Step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.BuildingOrdinanceORLawDemolitionCostCoveragePremium = Math.Round(((NY360InputProperty.BuildingOrdinanceORLawDemolitionCostRevisedLimit
                                                                                                - NY360OutputProperty.BuildingOrdinanceORLawDemolitionCostBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.BuildingOrdinanceORLawDemolitionCostRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.BuildingOrdinanceORLawDemolitionCostCoveragePremium = 0;
            }



            #endregion

            #region Building OrdinanceORLaw - Increased Cost of Construction Coverage

            if (NY360InputProperty.IsBuildingOrdinanceORLawIncreasedCostOfContructionCoverageSelected && NY360InputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionRevisedLimit 

                //step 2
                NY360OutputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                // Step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionPremium = Math.Round(((NY360InputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionRevisedLimit
                                                                                                - NY360OutputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionPremium = 0;
            }


            #endregion

            #region Changes in TemperatureORHumidity 

            if (NY360InputProperty.IsChangesInTemperatureORHumidityCoverageSelected && NY360InputProperty.ChangesInTemperatureORHumidityRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.ChangesInTemperatureORHumidityRevisedLimit 

                //step2
                NY360OutputProperty.ChangesInTemperatureORHumidityBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ChangesInTemperatureORHumidityCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.ChangesInTemperatureORHumidityRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ChangesInTemperatureORHumidityCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                // Step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.ChangesInTemperatureORHumidityPremium = Math.Round(((NY360InputProperty.ChangesInTemperatureORHumidityRevisedLimit
                                                                                                - NY360OutputProperty.ChangesInTemperatureORHumidityBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.ChangesInTemperatureORHumidityRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.ChangesInTemperatureORHumidityPremium = 0;
            }


            #endregion

            #region Commandeered Property  

            if (NY360InputProperty.IsCommandeeredPropertyCoverageSelected && NY360InputProperty.CommandeeredPropertyRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.CommandeeredPropertyRevisedLimit

                //step 2 
                NY360OutputProperty.CommandeeredPropertyBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.CommandeeredPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.CommandeeredPropertyRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.CommandeeredPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                // Step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.CommandeeredPropertyPremium = Math.Round(((NY360InputProperty.CommandeeredPropertyRevisedLimit
                                                                                                - NY360OutputProperty.CommandeeredPropertyBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.CommandeeredPropertyRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.CommandeeredPropertyPremium = 0;
            }



            #endregion

            #region Communication Equipment Coverage  

            if (NY360InputProperty.IsCommunicationEquipmentCoverageSelected && NY360InputProperty.CommunicationEquipmentRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.CommunicationEquipmentRevisedLimit 

                // step 2
                NY360OutputProperty.CommunicationEquipmentBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.CommunicationEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.CommunicationEquipmentRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.CommunicationEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //Step 4  (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.CommunicationEquipmentPremium = Math.Round(((NY360InputProperty.CommunicationEquipmentRevisedLimit
                                                                                                - NY360OutputProperty.CommunicationEquipmentBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.CommunicationEquipmentRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.CommunicationEquipmentPremium = 0;
            }



            #endregion

            #region Computer Equipment Coverage  

            if (NY360InputProperty.IsComputerEquipmentCoverageSelected && NY360InputProperty.ComputerEquipmentRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.ComputerEquipmentRevisedLimit 

                //step 2
                NY360OutputProperty.ComputerEquipmentBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ComputerEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.ComputerEquipmentRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ComputerEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                // Step 4  (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.ComputerEquipmentPremium = Math.Round(((NY360InputProperty.ComputerEquipmentRevisedLimit
                                                                                                - NY360OutputProperty.ComputerEquipmentBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.ComputerEquipmentRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.ComputerEquipmentPremium = 0;
            }


            #endregion

            #region Detached Signs Coverage	

            if (NY360InputProperty.IsDetachedSignsCoverageSelected && NY360InputProperty.DetachedSignsRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.DetachedSignsRevisedLimit 

                //step 2
                NY360OutputProperty.DetachedSignsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.DetachedSignsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.DetachedSignsRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.DetachedSignsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.DetachedSignsPremium = Math.Round(((NY360InputProperty.DetachedSignsRevisedLimit
                                                                                                - NY360OutputProperty.DetachedSignsBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.DetachedSignsRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.DetachedSignsPremium = 0;
            }



            #endregion

            #region Electrical Damage Coverage

            if (NY360InputProperty.IsElectricalDamageCoverageSelected && NY360InputProperty.ElectricalDamageRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.ElectricalDamageRevisedLimit 

                //step 2
                NY360OutputProperty.ElectricalDamageBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ElectricalDamageCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.ElectricalDamageRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ElectricalDamageCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.ElectricalDamagePremium = Math.Round(((NY360InputProperty.ElectricalDamageRevisedLimit
                                                                                                - NY360OutputProperty.ElectricalDamageBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.ElectricalDamageRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.ElectricalDamagePremium = 0;
            }



            #endregion

            #region Extra Expense and Business Income Coverage

            if (NY360InputProperty.IsExtraExpenseAndBusinessIncomeCoverageSelected && NY360InputProperty.ExtraExpenseAndBusinessIncomeRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.ExtraExpenseAndBusinessIncomeRevisedLimit

                //step 2
                NY360OutputProperty.ExtraExpenseAndBusinessIncomeBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ExtraExpenseAndBusinessIncomeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.ExtraExpenseAndBusinessIncomeRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ExtraExpenseAndBusinessIncomeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.ExtraExpenseAndBusinessIncomePremium = Math.Round(((NY360InputProperty.ExtraExpenseAndBusinessIncomeRevisedLimit
                                                                                                - NY360OutputProperty.ExtraExpenseAndBusinessIncomeBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.ExtraExpenseAndBusinessIncomeRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.ExtraExpenseAndBusinessIncomePremium = 0;
            }



            #endregion

            #region Fairs, Exhibitions, ExpositionsORTrade Shows Coverage

            if (NY360InputProperty.IsFairsExhibitionsExpositionsORTradeShowsCoverageSelected && NY360InputProperty.FairsExhibitionsExpositionsORTradeShowsRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.FairsExhibitionsExpositionsORTradeShowsRevisedLimit 

                //step 2
                NY360OutputProperty.FairsExhibitionsExpositionsORTradeShowsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.FairsExhibitionsExpositionsORTradeShowsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.FairsExhibitionsExpositionsORTradeShowsRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.FairsExhibitionsExpositionsORTradeShowsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.FairsExhibitionsExpositionsORTradeShowsPremium = Math.Round(((NY360InputProperty.FairsExhibitionsExpositionsORTradeShowsRevisedLimit
                                                                                                - NY360OutputProperty.FairsExhibitionsExpositionsORTradeShowsBaseLimit)
                                                                                                / 100)
                                                                                                * NY360OutputProperty.FairsExhibitionsExpositionsORTradeShowsRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.FairsExhibitionsExpositionsORTradeShowsPremium = 0;
            }



            #endregion

            #region Fine Arts Coverage	 

            if (NY360InputProperty.IsFineartsCoverageSelected && NY360InputProperty.FineartsRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.FineartsRevisedLimit

                //step 2
                NY360OutputProperty.FineartsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.FineartsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.FineartsRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.FineartsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.FineartsPremium = Math.Round(((NY360InputProperty.FineartsRevisedLimit
                                                                                       - NY360OutputProperty.FineartsBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.FineartsRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.FineartsPremium = 0;
            }



            #endregion

            #region Fire Department Service Charge Coverage	

            if (NY360InputProperty.IsFireDepartmentServiceChargeCoverageSelected && NY360InputProperty.FireDepartmentServiceChargeRevisedLimit > 0)
            {
                //step 1 NY360InputProperty.FireDepartmentServiceChargeRevisedLimit 

                //step 2
                NY360OutputProperty.FireDepartmentServiceChargeBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.FireDepartmentServiceChargeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.FireDepartmentServiceChargeRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.FireDepartmentServiceChargeCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.FireDepartmentServiceChargePremium = Math.Round(((NY360InputProperty.FireDepartmentServiceChargeRevisedLimit
                                                                                       - NY360OutputProperty.FireDepartmentServiceChargeBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.FireDepartmentServiceChargeRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.FireDepartmentServiceChargePremium = 0;
            }


            #endregion

            #region  Flagpoles Coverage	  

            if (NY360InputProperty.FlagpolesRevisedLimit > 0 && NY360InputProperty.IsFlagpolesCoverageSelected)
            {
                //step 1 NY360InputProperty.FlagpolesRevisedLimit

                //step 2;
                NY360OutputProperty.FlagpolesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.FlagpolesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.FlagpolesRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.FlagpolesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.FlagpolesPremium = Math.Round(((NY360InputProperty.FlagpolesRevisedLimit
                                                                                       - NY360OutputProperty.FlagpolesBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.FlagpolesRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.FlagpolesPremium = 0;
            }



            #endregion

            #region Glass DisplayORTrophy Cases Coverage

            if (NY360InputProperty.GlassDisplayORTrophyCasesRevisedLimit > 0 && NY360InputProperty.IsGlassDisplayORTrophyCasesCoverageSelected)
            {
                // Coverage applicable for All primary class except School
                if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() != "SC")
                {
                    //step 1 NY360InputProperty.GlassDisplayORTrophyCasesRevisedLimit 

                    //step 2
                    NY360OutputProperty.GlassDisplayORTrophyCasesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.GlassDisplayORTrophyCasesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    //step 3
                    NY360OutputProperty.GlassDisplayORTrophyCasesRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.GlassDisplayORTrophyCasesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    ////step 4(Step 1 - Step 2)/100 * Step 3)
                    NY360OutputProperty.GlassDisplayORTrophyCasesPremium = Math.Round(((NY360InputProperty.GlassDisplayORTrophyCasesRevisedLimit
                                                                                           - NY360OutputProperty.GlassDisplayORTrophyCasesBaseLimit)
                                                                                           / 100)
                                                                                           * NY360OutputProperty.GlassDisplayORTrophyCasesRate, MidpointRounding.AwayFromZero);

                }
                else
                {
                    NY360OutputProperty.GlassDisplayORTrophyCasesPremium = 0;
                }
            }
            else
            {
                NY360OutputProperty.GlassDisplayORTrophyCasesPremium = 0;
            }

            #endregion

            #region Grounds, Maintenance Equipment Coverage

            if (NY360InputProperty.GroundsMaintenanceEquipmentRevisedLimit > 0 && NY360InputProperty.IsGroundsMaintenanceEquipmentCoverageSelected)
            {
                //step 1 NY360InputProperty.GroundsMaintenanceEquipmentRevisedLimit 

                //step 2
                NY360OutputProperty.GroundsMaintenanceEquipmentBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.GroundsMaintenanceEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.GroundsMaintenanceEquipmentRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.GroundsMaintenanceEquipmentCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.GroundsMaintenanceEquipmentPremium = Math.Round(((NY360InputProperty.GroundsMaintenanceEquipmentRevisedLimit
                                                                                       - NY360OutputProperty.GroundsMaintenanceEquipmentBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.GroundsMaintenanceEquipmentRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.GroundsMaintenanceEquipmentPremium = 0;
            }



            #endregion

            #region Lock Replacement Coverage

            if (NY360InputProperty.LockReplacementRevisedLimit > 0 && NY360InputProperty.IsLockReplacementCoverageSelected)
            {
                //step 1 NY360InputProperty.LockReplacementRevisedLimit 

                //step 2
                NY360OutputProperty.LockReplacementBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.LockReplacementCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.LockReplacementRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.LockReplacementCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.LockReplacementPremium = Math.Round(((NY360InputProperty.LockReplacementRevisedLimit
                                                                                       - NY360OutputProperty.LockReplacementBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.LockReplacementRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.LockReplacementPremium = 0;
            }


            #endregion

            #region Money, Securities and Stamps - Inside Premise Coverage

            if (NY360InputProperty.MoneySecuritiesAndStampsInsidePremiseRevisedLimit > 0 && NY360InputProperty.IsMoneySecuritiesAndStampsInsidePremiseCoverageSelected)
            {
                //step 1 NY360InputProperty.MoneySecuritiesAndStampsInsidePremiseRevisedLimit 

                // step 2
                NY360OutputProperty.MoneySecuritiesAndStampsInsidePremiseBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.MoneySecuritiesAndStampsInsidePremiseCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.MoneySecuritiesAndStampsInsidePremiseRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.MoneySecuritiesAndStampsInsidePremiseCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.MoneySecuritiesAndStampsInsidePremisePremium = Math.Round(((NY360InputProperty.MoneySecuritiesAndStampsInsidePremiseRevisedLimit
                                                                                       - NY360OutputProperty.MoneySecuritiesAndStampsInsidePremiseBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.MoneySecuritiesAndStampsInsidePremiseRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.MoneySecuritiesAndStampsInsidePremisePremium = 0;
            }


            #endregion

            #region Money, Securities and Stamps - Outside Premise Coverage	

            if (NY360InputProperty.MoneySecuritiesAndStampsOutsidePremiseRevisedLimit > 0 && NY360InputProperty.IsMoneySecuritiesAndStampsOutsidePremiseCoverageSelected)
            {
                //step 1 NY360InputProperty.MoneySecuritiesAndStampsOutsidePremiseRevisedLimit 

                //step 2
                NY360OutputProperty.MoneySecuritiesAndStampsOutsidePremiseBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.MoneySecuritiesAndStampsOutsidePremiseCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.MoneySecuritiesAndStampsOutsidePremiseRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.MoneySecuritiesAndStampsOutsidePremiseCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.MoneySecuritiesAndStampsOutsidePremisePremium = Math.Round(((NY360InputProperty.MoneySecuritiesAndStampsOutsidePremiseRevisedLimit
                                                                                       - NY360OutputProperty.MoneySecuritiesAndStampsOutsidePremiseBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.MoneySecuritiesAndStampsOutsidePremiseRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.MoneySecuritiesAndStampsOutsidePremisePremium = 0;
            }


            #endregion

            #region Newly AcquiredORConstructed Property - Building Coverage
            if (NY360InputProperty.NewlyAcquiredORConstructedPropertyBuildingRevisedLimit > 0 && NY360InputProperty.IsNewlyAcquiredORConstructedPropertyBuildingCoverageSelected)
            {
                //step 1 NY360InputProperty.NewlyAcquiredORConstructedPropertyBuildingRevisedLimit 

                //step 2
                NY360OutputProperty.NewlyAcquiredORConstructedPropertyBuildingBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.NewlyAcquiredORConstructedPropertyBuildingCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.NewlyAcquiredORConstructedPropertyBuildingRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.NewlyAcquiredORConstructedPropertyBuildingCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.NewlyAcquiredORConstructedPropertyBuildingPremium = Math.Round(((NY360InputProperty.NewlyAcquiredORConstructedPropertyBuildingRevisedLimit
                                                                                                                       - NY360OutputProperty.NewlyAcquiredORConstructedPropertyBuildingBaseLimit)
                                                                                                                       / 100)
                                                                                                                       * NY360OutputProperty.NewlyAcquiredORConstructedPropertyBuildingRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.NewlyAcquiredORConstructedPropertyBuildingPremium = 0;
            }


            #endregion

            #region Newly AcquiredORConstructed Property - Personal Property Coverage

            if (NY360InputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyRevisedLimit > 0 && NY360InputProperty.IsNewlyAcquiredORConstructedPropertyPersonalPropertyCoverageSelected)
            {
                //step 1 NY360InputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyRevisedLimit 

                //step 2
                NY360OutputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyPremium = Math.Round(((NY360InputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyRevisedLimit
                                                                                       - NY360OutputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyPremium = 0;
            }


            #endregion

            #region Off Premises Utility Failure Coverage

            if (NY360InputProperty.OffPremisesUtilityFailureRevisedLimit > 0 && NY360InputProperty.IsOffPremisesUtilityFailureCoverageSelected)
            {
                //step 1 NY360InputProperty.OffPremisesUtilityFailureRevisedLimit 

                //step 2
                NY360OutputProperty.OffPremisesUtilityFailureBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.OffPremisesUtilityFailureCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.OffPremisesUtilityFailureRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.OffPremisesUtilityFailureCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.OffPremisesUtilityFailurePremium = Math.Round(((NY360InputProperty.OffPremisesUtilityFailureRevisedLimit
                                                                                       - NY360OutputProperty.OffPremisesUtilityFailureBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.OffPremisesUtilityFailureRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.OffPremisesUtilityFailurePremium = 0;
            }


            #endregion

            #region Outdoor Property - Any one tree, shrubORplant Coverage

            if (NY360InputProperty.OutdoorPropertyAnyOneTreeShrubORplantRevisedLimit > 0 && NY360InputProperty.IsOutdoorPropertyAnyOneTreeShrubORplantCoverageSelected)
            {
                //step 1 NY360InputProperty.OutdoorPropertyAnyOneTreeShrubORplantRevisedLimit 

                //step 2
                NY360OutputProperty.OutdoorPropertyAnyOneTreeShrubORplantBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.OutdoorPropertyAnyOneTreeShrubORplantCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.OutdoorPropertyAnyOneTreeShrubORplantRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.OutdoorPropertyAnyOneTreeShrubORplantCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.OutdoorPropertyAnyOneTreeShrubORplantPremium = Math.Round(((NY360InputProperty.OutdoorPropertyAnyOneTreeShrubORplantRevisedLimit
                                                                                       - NY360OutputProperty.OutdoorPropertyAnyOneTreeShrubORplantBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.OutdoorPropertyAnyOneTreeShrubORplantRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.OutdoorPropertyAnyOneTreeShrubORplantPremium = 0;
            }


            #endregion

            #region Outdoor Property - Total limit Coverage

            if (NY360InputProperty.OutdoorPropertyTotalLimitRevisedLimit > 0 && NY360InputProperty.IsOutdoorPropertyTotalLimitCoverageSelected)
            {
                //step 1 NY360InputProperty.OutdoorPropertyTotalLimitRevisedLimit

                //step 2 
                NY360OutputProperty.OutdoorPropertyTotalLimitBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.OutdoorPropertyTotalLimitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.OutdoorPropertyTotalLimitRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.OutdoorPropertyTotalLimitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                // step 4  (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.OutdoorPropertyTotalLimitPremium = Math.Round(((NY360InputProperty.OutdoorPropertyTotalLimitRevisedLimit
                                                                                       - NY360OutputProperty.OutdoorPropertyTotalLimitBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.OutdoorPropertyTotalLimitRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.OutdoorPropertyTotalLimitPremium = 0;
            }


            #endregion

            #region Personal Effects and Property of Others - Any one employeeORvolunteer Coverage
            if (NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRevisedLimit > 0 && NY360InputProperty.IsPersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerCoverageSelected)
            {
                // Coverage applicable for All primary class except School
                if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() != "SC")
                {
                    //step 1 NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRevisedLimit

                    //step 2
                    NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    //step 3
                    NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    //step 4 (Step 1 - Step 2)/100 * Step 3)
                    NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerPremium = Math.Round(((NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRevisedLimit
                                                                                           - NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerBaseLimit)
                                                                                           / 100)
                                                                                           * NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRate, MidpointRounding.AwayFromZero);
                }
                else
                {
                    NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerPremium = 0;
                }
            }
            else
            {
                NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerPremium = 0;
            }

            #endregion

            #region Personal Effects and Property of Others - Any one occurrence Coverage
            if (NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRevisedLimit > 0 && NY360InputProperty.IsPersonalEffectsAndPropertyOfOthersAnyOneOccurrenceCoverageSelected)
            {
                // Coverage applicable for All primary class except School									
                if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() != "SC")
                {
                    //step 1 NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRevisedLimit 

                    //step 2 
                    NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    //step 3
                    NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    //step 4 (Step 1 - Step 2)/100 * Step 3)
                    NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrencePremium = Math.Round(((NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRevisedLimit
                                                                                           - NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceBaseLimit)
                                                                                           / 100)
                                                                                           * NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRate, MidpointRounding.AwayFromZero);
                }
                else
                {
                    NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrencePremium = 0;
                }
            }
            else
            {
                NY360OutputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrencePremium = 0;
            }

            #endregion

            #region Pollutant Clean Up and Removal Coverage
            if (NY360InputProperty.PollutantCleanUpAndRemovalRevisedLimit > 0 && NY360InputProperty.IsPollutantCleanUpAndRemovalCoverageSelected)
            {
                //step 1 NY360InputProperty.PollutantCleanUpAndRemovalRevisedLimit 

                //step 2
                NY360OutputProperty.PollutantCleanUpAndRemovalBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PollutantCleanUpAndRemovalCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.PollutantCleanUpAndRemovalRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PollutantCleanUpAndRemovalCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.PollutantCleanUpAndRemovalPremium = Math.Round(((NY360InputProperty.PollutantCleanUpAndRemovalRevisedLimit
                                                                                       - NY360OutputProperty.PollutantCleanUpAndRemovalBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.PollutantCleanUpAndRemovalRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.PollutantCleanUpAndRemovalPremium = 0;
            }
            #endregion

            #region Property in Transit Coverage
            if (NY360InputProperty.PropertyInTransitRevisedLimit > 0 && NY360InputProperty.IsPropertyInTransitCoverageSelected)
            {
                //step 1 NY360InputProperty.PropertyInTransitRevisedLimit 

                //step 2
                NY360OutputProperty.PropertyInTransitBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PropertyInTransitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.PropertyInTransitRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PropertyInTransitCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.PropertyInTransitPremium = Math.Round(((NY360InputProperty.PropertyInTransitRevisedLimit
                                                                                       - NY360OutputProperty.PropertyInTransitBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.PropertyInTransitRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.PropertyInTransitPremium = 0;
            }
            #endregion

            #region Property Off-Premises Coverage
            if (NY360InputProperty.PropertyOffPremisesRevisedLimit > 0 && NY360InputProperty.IsPropertyOffPremisesCoverageSelected)
            {
                //step 1 NY360InputProperty.PropertyOffPremisesRevisedLimit 

                //step 2
                NY360OutputProperty.PropertyOffPremisesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PropertyOffPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.PropertyOffPremisesRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PropertyOffPremisesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4 (Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.PropertyOffPremisesPremium = Math.Round(((NY360InputProperty.PropertyOffPremisesRevisedLimit
                                                                                       - NY360OutputProperty.PropertyOffPremisesBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.PropertyOffPremisesRate, MidpointRounding.AwayFromZero);

            }
            else
            {
                NY360OutputProperty.PropertyOffPremisesPremium = 0;
            }
            #endregion

            #region Spoilage Coverage
            if (NY360InputProperty.SpoilageCoverageRevisedLimit > 0 && NY360InputProperty.IsSpoilageCoverageSelected)
            {
                //step 1 NY360InputProperty.SpoilageCoverageRevisedLimit 

                //step 2
                NY360OutputProperty.SpoilageCoverageBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.SpoilageCoverageCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                //step 3
                NY360OutputProperty.SpoilageCoverageRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.SpoilageCoverageCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                //step 4(Step 1 - Step 2)/100 * Step 3)
                NY360OutputProperty.SpoilageCoveragePremium = Math.Round(((NY360InputProperty.SpoilageCoverageRevisedLimit
                                                                                       - NY360OutputProperty.SpoilageCoverageBaseLimit)
                                                                                       / 100)
                                                                                       * NY360OutputProperty.SpoilageCoverageRate, MidpointRounding.AwayFromZero);
            }
            else
            {
                NY360OutputProperty.SpoilageCoveragePremium = 0;
            }


            #endregion

            #region Valuable Papers and Records Coverage
            if (NY360InputProperty.ValuablePapersAndRecordsRevisedLimit > 0 && NY360InputProperty.IsValuablePapersAndRecordsCoverageSelected)
            {
                // Coverage applicable for All primary class except School
                if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() != "SC")
                {
                    //step 1 NY360InputProperty.ValuablePapersAndRecordsRevisedLimit

                    //step 2
                    NY360OutputProperty.ValuablePapersAndRecordsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ValuablePapersAndRecordsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    //step 3
                    NY360OutputProperty.ValuablePapersAndRecordsRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ValuablePapersAndRecordsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    //step 4(Step 1 - Step 2)/100 * Step 3)
                    NY360OutputProperty.ValuablePapersAndRecordsPremium = Math.Round(((NY360InputProperty.ValuablePapersAndRecordsRevisedLimit
                                                                                           - NY360OutputProperty.ValuablePapersAndRecordsBaseLimit)
                                                                                           / 100)
                                                                                           * NY360OutputProperty.ValuablePapersAndRecordsRate, MidpointRounding.AwayFromZero);
                }
                else
                {
                    NY360OutputProperty.ValuablePapersAndRecordsPremium = 0;
                }
            }
            else
            {
                NY360OutputProperty.ValuablePapersAndRecordsPremium = 0;
            }

            #endregion

            #region Extra Expense and Tuition & Fees Coverage

            if (NY360InputProperty.ExtraExpenseAndTuitionFeesRevisedLimit > 0 && NY360InputProperty.IsExtraExpenseAndTuitionFeesCoverageSelected)
            {
                // This coverage is applicable for School primary class only
                if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() == "SC")
                {

                    //step 1 NY360InputProperty.ExtraExpenseAndTuitionFeesRevisedLimit 

                    //step 2
                    NY360OutputProperty.ExtraExpenseAndTuitionFeesBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ExtraExpenseAndTuitionFeesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    //step 3
                    NY360OutputProperty.ExtraExpenseAndTuitionFeesRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ExtraExpenseAndTuitionFeesCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    //step 4(Step 1 - Step 2)/100 * Step 3)
                    NY360OutputProperty.ExtraExpenseAndTuitionFeesPremium = Math.Round(((NY360InputProperty.ExtraExpenseAndTuitionFeesRevisedLimit
                                                                                           - NY360OutputProperty.ExtraExpenseAndTuitionFeesBaseLimit)
                                                                                           / 100)
                                                                                           * NY360OutputProperty.ExtraExpenseAndTuitionFeesRate, MidpointRounding.AwayFromZero);


                }
                else
                {
                    NY360OutputProperty.ExtraExpenseAndTuitionFeesPremium = 0;
                }
            }
            else
            {
                NY360OutputProperty.ExtraExpenseAndTuitionFeesPremium = 0;
            }
            #endregion

            #region Valuable Papers	   
            if (NY360InputProperty.IsValuablePapersCoverageSelected && NY360InputProperty.ValuablePapersRevisedLimit > 0)
            {
                // This coverage is applicable for School primary class only									
                if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() == "SC")
                {
                    //step 1 NY360InputProperty.ValuablePapersRevisedLimit 

                    //step 2
                    NY360OutputProperty.ValuablePapersBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ValuablePapersCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    //step 3
                    NY360OutputProperty.ValuablePapersRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.ValuablePapersCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    //step 4(Step 1 - Step 2)/100 * Step 3)
                    NY360OutputProperty.ValuablePapersPremium = Math.Round(((NY360InputProperty.ValuablePapersRevisedLimit
                                                                                           - NY360OutputProperty.ValuablePapersBaseLimit)
                                                                                           / 100)
                                                                                           * NY360OutputProperty.ValuablePapersRate, MidpointRounding.AwayFromZero);
                }
                else
                {
                    NY360OutputProperty.ValuablePapersPremium = 0;
                }
            }
            else
            {
                NY360OutputProperty.ValuablePapersPremium = 0;
            }


            #endregion

            #region Musical Instruments and Band Uniforms Coverage
            if (NY360InputProperty.IsMusicalInstrumentsAndBandUniformsCoverageSelected && NY360InputProperty.MusicalInstrumentsAndBandUniformsRevisedLimit > 0)
            {
                // This coverage is applicable for School primary class only									
                if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() == "SC")
                {
                    //step 1 NY360InputProperty.MusicalInstrumentsAndBandUniformsRevisedLimit 

                    //step 2
                    NY360OutputProperty.MusicalInstrumentsAndBandUniformsBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.MusicalInstrumentsAndBandUniformsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    //step 3
                    NY360OutputProperty.MusicalInstrumentsAndBandUniformsRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.MusicalInstrumentsAndBandUniformsCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    //step 4 (Step 1 - Step 2)/100 * Step 3)
                    NY360OutputProperty.MusicalInstrumentsAndBandUniformsPremium = Math.Round(((NY360InputProperty.MusicalInstrumentsAndBandUniformsRevisedLimit
                                                                                           - NY360OutputProperty.MusicalInstrumentsAndBandUniformsBaseLimit)
                                                                                           / 100)
                                                                                           * NY360OutputProperty.MusicalInstrumentsAndBandUniformsRate, MidpointRounding.AwayFromZero);
                }
                else
                {
                    NY360OutputProperty.MusicalInstrumentsAndBandUniformsPremium = 0;
                }
            }
            else
            {
                NY360OutputProperty.MusicalInstrumentsAndBandUniformsPremium = 0;
            }

            #endregion

            #region Personal Property of EmployeesORVolunteers - Any one employeeORvolunteer 

            if (NY360InputProperty.IsPersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerCoverageSelected && NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRevisedLimit > 0)
            {
                // This coverage is applicable for School primary class only									
                if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() == "SC")
                {
                    //step 1 NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRevisedLimit 

                    //step 2 
                    NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    //step 3
                    NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    //step 4 
                    NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerPremium = Math.Round(((NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRevisedLimit
                                                                                           - NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerBaseLimit)
                                                                                           / 100)
                                                                                           * NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRate, MidpointRounding.AwayFromZero);

                }
                else
                {
                    NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerPremium = 0;
                }
            }
            else
            {
                NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerPremium = 0;
            }
            #endregion

            #region Personal Property of EmployeesORVolunteers - Any one occurrence

            if (NY360InputProperty.IsPersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceCoverageSelected && NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRevisedLimit > 0)
            {
                // This coverage is applicable for School primary class only									
                if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() == "SC")
                {
                    //step 1 NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRevisedLimit 

                    //step 2
                    NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceBaseLimit = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Limit");

                    //step 3
                    NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRate = property360DataAccess.GetProperty360CoverageDetail(NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceCoverageName, model.RaterInputFacadeModel.PolicyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LineOfBusiness, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate, model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass, "Rate");

                    //step 4
                    NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrencePremium = Math.Round(((NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRevisedLimit
                                                                                           - NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceBaseLimit)
                                                                                           / 100)
                                                                                           * NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRate, MidpointRounding.AwayFromZero);
                }
                else
                {
                    NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrencePremium = 0;
                }
            }
            else
            {
                NY360OutputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrencePremium = 0;
            }


            #endregion

            // Property360TotalPremiums = Sum of all coverages
            var property360OuputModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel;
            model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkProperty360TotalPremiums =
                                                                  (property360OuputModel.AccountReceivablePremium
                                                                  + property360OuputModel.BuildingOrdinanceORLawDemolitionCostCoveragePremium
                                                                  + property360OuputModel.BuildingOrdinanceORLawIncreasedCostOfContructionPremium
                                                                  + property360OuputModel.ChangesInTemperatureORHumidityPremium
                                                                  + property360OuputModel.CommandeeredPropertyPremium
                                                                  + property360OuputModel.CommunicationEquipmentPremium
                                                                  + property360OuputModel.ComputerEquipmentPremium
                                                                  + property360OuputModel.DetachedSignsPremium
                                                                  + property360OuputModel.ElectricalDamagePremium
                                                                  + property360OuputModel.ExtraExpenseAndBusinessIncomePremium
                                                                  + property360OuputModel.FairsExhibitionsExpositionsORTradeShowsPremium
                                                                  + property360OuputModel.FineartsPremium
                                                                  + property360OuputModel.FireDepartmentServiceChargePremium
                                                                  + property360OuputModel.FlagpolesPremium
                                                                  + property360OuputModel.GlassDisplayORTrophyCasesPremium
                                                                  + property360OuputModel.GroundsMaintenanceEquipmentPremium
                                                                  + property360OuputModel.LockReplacementPremium
                                                                  + property360OuputModel.MoneySecuritiesAndStampsInsidePremisePremium
                                                                  + property360OuputModel.MoneySecuritiesAndStampsOutsidePremisePremium
                                                                  + property360OuputModel.NewlyAcquiredORConstructedPropertyBuildingPremium
                                                                  + property360OuputModel.NewlyAcquiredORConstructedPropertyPersonalPropertyPremium
                                                                  + property360OuputModel.OffPremisesUtilityFailurePremium
                                                                  + property360OuputModel.OutdoorPropertyAnyOneTreeShrubORplantPremium
                                                                  + property360OuputModel.OutdoorPropertyTotalLimitPremium
                                                                  + property360OuputModel.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerPremium
                                                                  + property360OuputModel.PersonalEffectsAndPropertyOfOthersAnyOneOccurrencePremium
                                                                  + property360OuputModel.PollutantCleanUpAndRemovalPremium
                                                                  + property360OuputModel.PropertyInTransitPremium
                                                                  + property360OuputModel.PropertyOffPremisesPremium
                                                                  + property360OuputModel.SpoilageCoveragePremium
                                                                  + property360OuputModel.ValuablePapersAndRecordsPremium
                                                                  + property360OuputModel.ExtraExpenseAndTuitionFeesPremium
                                                                  + property360OuputModel.ValuablePapersPremium
                                                                  + property360OuputModel.MusicalInstrumentsAndBandUniformsPremium
                                                                  + property360OuputModel.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerPremium
                                                                  + property360OuputModel.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrencePremium
                                                                  );


            // 14-07-2021
            // Round Property360TotalPremiums up to nearest digit.
            model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360TotalPremiums = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360TotalPremiums, MidpointRounding.AwayFromZero);
        }

        #endregion
    }
}
