﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaterProperty
{
    public class PropertyServiceWrapper
    {
        /// <summary>
        /// Logger.
        /// </summary>
        protected ILoggingManager logger { get; private set; }
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyCwService"/> class.
        /// </summary>
        /// <param name="logger">ILoggingManager.</param>
        public PropertyServiceWrapper(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;

            this.logger = logger;
        }

        /// <summary>
        /// ExecutePropertyEngine : It's includes pre validation ,premium calculation , post validation.
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        /// <returns>ValidationResult</returns>
        public FluentValidation.Results.ValidationResult ExecutePropertyEngine(RaterFacadeModel raterFacadeModel)
        {
            //Create service object
            IPropertyService service = null;

            if (raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
            {
                service = new PropertyNyService(this.configuration, this.logger);
            }
            else
            {
                service = new PropertyCwService(this.configuration, this.logger);
            }


            // Prevalidate
            var preValidateResults = service.PreValidate(raterFacadeModel);

            if (!preValidateResults.IsValid) return preValidateResults;

            // Since input pre validation are success, calculate premium
            service.Calculate(raterFacadeModel);

            //Post validate
            var postValidateResults = service.PostValidate(raterFacadeModel);

            return postValidateResults;
        }
    }
}
