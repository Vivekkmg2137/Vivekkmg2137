﻿using Models;
using Models.ApiModels;

namespace RaterPublicOfficials
{
    /// <summary>
    /// IPublic Officials CW Service
    /// </summary>
    public interface IPublicOfficialsCWService
    {
        /// <summary>
        /// ExecuteDomainRules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model);

        /// <summary>
        /// PreValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model);

        /// <summary>
        /// PostValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model);

        /// <summary>
        /// Calculate
        /// </summary>
        /// <param name="model"></param>
        void Calculate(RaterFacadeModel model);
    }
}
