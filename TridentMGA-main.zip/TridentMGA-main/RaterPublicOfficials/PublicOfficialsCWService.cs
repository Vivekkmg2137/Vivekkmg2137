﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Input;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Output;
using Models.ApiModels.LineOfBusiness.PublicOfficials;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Validations;
using Models.ApiModels.Policy;

namespace RaterPublicOfficials
{
    /// <summary>
    /// Public Officials CW Service
    /// </summary>
    public class PublicOfficialsCWService : IPublicOfficialsCWService
    {
        /// <summary>
        /// DataAccess object
        /// </summary>
        private PublicOfficialsDataAccess _PublicOfficials { get; set; }

        /// <summary>
        /// Logger object
        /// </summary>
        protected ILoggingManager _Logger { get; private set; }

        /// <summary>
        /// Configuration object
        /// </summary>
        protected IConfiguration _Configuration { get; private set; }

        private int ExcessExposureLiabilityLimitValidValue = 1000000;

        /// <summary>
        /// Public Officials CW Service
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public PublicOfficialsCWService(IConfiguration configuration, ILoggingManager logger)
        {
            this._Configuration = configuration;
            this._Logger = logger;
            this._PublicOfficials = new PublicOfficialsDataAccess(configuration, logger);
        }

        /// <summary>
        /// ExecuteDomainRules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsCWService.ExecuteDomainRules :: Starting");
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            this._Logger.Info("PublicOfficialsCWService.ExecuteDomainRules :: Completed");
            return validationResult;
        }

        /// <summary>
        /// PreValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("PublicOfficialsCWService.PreValidate :: Starting");
                var validator = new PublicOfficialsCWPreValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);
                this._Logger.Info("PublicOfficialsCWService.PreValidate :: Completed");
                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsCWService.PreValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// PostValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("PublicOfficialsCWService.PostValidate :: Starting");
                var validator = new PublicOfficialsCWPostValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);
                this._Logger.Info("PublicOfficialsCWService.PostValidate :: Completed");
                //return results;
                return new FluentValidation.Results.ValidationResult();
            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsCWService.PostValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region PublicOfficialsCW Calculation
        /// <summary>
        /// Calculate
        /// </summary>
        /// <param name="model"></param>
        public virtual void Calculate(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsCWService.Calculate :: Starting");

            try
            {
                #region Liablity Premium 

                CalculateLiablityPremium(model);

                #endregion

                #region Optional Coverages Premium

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel != null)
                {
                    CaculateOptionalCoveragePremium(model);
                }

                #endregion

                #region OthersPremium

                CalculateOthersPremium(model);

                #endregion

                this._Logger.Info("PublicOfficialsCWService.Calculate :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsCWService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        private void CalculateOthersPremium(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsCWService.CalculateOthersPremium :: Starting");

            var outputPOModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputPOModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW;

            try
            {
                // Read Minimum Premium lookup table to get Minimum Premium
                decimal lOBMinimumPremium = this._PublicOfficials.GetLOBTotalPremium(policyHeaderModel.State,
                                                                                    inputPOModel.LineOfBusiness,
                                                                                    policyHeaderModel.PrimaryClass,
                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                    policyHeaderModel.PolicyExpirationDate);

                //Calculate Manual Premium
                //Step-19	
                //Step-19.1	Refer to (Step 12.5)
                //Step-19.2 Refer to Step 18
                //ROUND(Base Premium + Non Modified Premium)
                outputPOModel.ManualPremium = outputPOModel.BasePremium
                                            + outputPOModel.NonModifiedPremium;

                //Apply Minimum Premium rules
                //Step-19.3	
                //If "Manual Premium" < Minimum Premium Then "Manual Premium" = "Minimum Premium"
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(Manual Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 15.3)
                //Manual Premium = LOB Minimum Premium +Suppl.Extended Reporting Period

                if (outputPOModel.ManualPremium < lOBMinimumPremium)
                {
                    outputPOModel.ManualPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.ManualPremium = (outputPOModel.BasePremium
                                                 - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);

                    if (outputPOModel.ManualPremium < lOBMinimumPremium)
                    {
                        outputPOModel.ManualPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                    + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                //Calculate Tier Premium
                //Step-20
                //Tier Premium
                //Get Tier Type
                //Step-20.1
                //Tier Plan Applies -Policy & Pricing JSON
                //Step-20.2
                //Refer to Step 19
                //Step-20.3
                //Refer to Step 18
                //Step-20.4
                //Get Tier Factor Tier Rate
                //Step-20.5
                //Refer to Step 18
                //ROUND(((Manual Premium - Non Modified Premium) * Tier Factor) + Non Modified Premium)

                outputPOModel.TierRate = this._PublicOfficials.GetProfLinesTierRate(policyHeaderModel.State,
                                                                                   inputPOModel.LineOfBusiness,
                                                                                   model.RaterInputFacadeModel.PricingInputModel.TierPlan,
                                                                                   policyHeaderModel.PolicyEffectiveDate,
                                                                                   policyHeaderModel.PolicyExpirationDate);

                outputPOModel.TierPremium = Convert.ToInt32(((outputPOModel.ManualPremium
                                                            - outputPOModel.NonModifiedPremium)
                                                            * outputPOModel.TierRate)
                                                            + outputPOModel.NonModifiedPremium);

                //Apply Minimum Premium rules
                //Step-20.6
                //If "Tier Premium" < Minimum Premium Then "Tier Premium" = " Minimum Premium "
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(Tier Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 15.3)
                //Tier Premium = LOB Minimum Premium +Suppl.Extended Reporting Period

                if (outputPOModel.TierPremium < lOBMinimumPremium)
                {
                    outputPOModel.TierPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.TierPremium = (outputPOModel.TierPremium
                                               - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);

                    if (outputPOModel.TierPremium < lOBMinimumPremium)
                    {
                        outputPOModel.TierPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                  + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                //Calculate IRPM Premium
                //Step-21
                //Step-21.1 Refer to Step 20
                //Step-21.2 Refer to Step 18
                //Step-21.3 Get IRPM Factor
                outputPOModel.IRPMFactor = inputPOModel.IRPMFactor;

                //Step-21.4 Refer to Step 18
                //ROUND(((Tier Premium - Non Modified Premium)	*IRPM Factor)+Non Modified Premium)	
                //If "IRPM Premium" < Minimum Premium Then
                //"IRPM Premium" = "Minimum Premium"
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(IRPM Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 15.3)
                //IRPM Premium = LOB Minimum Premium +Suppl.Extended Reporting Period
                outputPOModel.IRPMPremium = Convert.ToInt32(((outputPOModel.TierPremium
                                                            - outputPOModel.NonModifiedPremium)
                                                            * outputPOModel.IRPMFactor)
                                                            + outputPOModel.NonModifiedPremium);

                if (outputPOModel.IRPMPremium < lOBMinimumPremium)
                {
                    outputPOModel.IRPMPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.IRPMPremium = (outputPOModel.IRPMPremium
                                               - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);

                    if (outputPOModel.IRPMPremium < lOBMinimumPremium)
                    {
                        outputPOModel.IRPMPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                  + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                //Calculate Other Mod Premium
                //Step-22
                //Other Mod Premium
                //Step-22.1
                //Refer to Step 21
                //Step-22.2
                //Refer to Step 18	
                //Step-22.3
                //Get Other Mod Factor
                outputPOModel.OtherModRate = inputPOModel.OtherModRate;

                //Other Mod Rate
                //Step-22.4
                //Refer to Step 18
                //Step-22.5
                //Apply Minimum Premium rules
                //ROUND(((IRPM Premium -Non Modified Premium)*Other Mod Factor)	+Non Modified Premium)
                outputPOModel.OtherModPremium = Convert.ToInt32(((outputPOModel.IRPMPremium
                                                                - outputPOModel.NonModifiedPremium)
                                                                * outputPOModel.OtherModRate)
                                                                + outputPOModel.NonModifiedPremium);

                //Step-22.6
                //If " Other Mod Premium" < Minimum Premium Then "Other Mod Premium" = "Minimum Premium"
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(Other Mod Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 15.3)
                //Other Mod Premium = LOB Minimum Premium +Suppl.Extended Reporting Period
                if (outputPOModel.OtherModPremium < lOBMinimumPremium)
                {
                    outputPOModel.OtherModPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.OtherModPremium = (outputPOModel.OtherModPremium
                                                   - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);

                    if (outputPOModel.OtherModPremium < lOBMinimumPremium)
                    {
                        outputPOModel.OtherModPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                      + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                //Step 23	Calculate Terrorism Premium	Terrorism Premium
                //Step 23.1   Refer to Step 22       
                //Step 23.2   Get Terrorism Factor Terrorism Rate
                //ROUND( Other Mod Premium * Terrorism Factor)
                //Terrorism Factor Is Always 0
                outputPOModel.TerrorismRate = 0;
                if (model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected)
                {
                    outputPOModel.TerrorismPremium = Convert.ToInt32(Math.Round((outputPOModel.OtherModPremium
                                                                               * outputPOModel.TerrorismRate)
                                                                               , 0
                                                                               , MidpointRounding.AwayFromZero));
                }

                //Step 24	Calculate  Final PO Premium	POModifiedFinalPremium		
                //Step 24.1   Refer to Step 22       
                //Step 24.2   Refer to Step 23
                //Other Mod Premium + Terrorism Premium
                outputPOModel.POModifiedFinalPremium = Convert.ToInt32(outputPOModel.OtherModPremium
                                                                     + outputPOModel.TerrorismPremium);

                //If " Final PO Premium" < Minimum Premium Then 
                //"Final PO Premium " = "Minimum Premium"
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(Other Mod Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 15.3)
                //Final PO Premium = LOB Minimum Premium +Suppl.Extended Reporting Period
                if (outputPOModel.POModifiedFinalPremium < lOBMinimumPremium)
                {
                    outputPOModel.POModifiedFinalPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.POModifiedFinalPremium = (outputPOModel.POModifiedFinalPremium
                                                          - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);

                    if (outputPOModel.POModifiedFinalPremium < lOBMinimumPremium)
                    {
                        outputPOModel.POModifiedFinalPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                             + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                // Step 25
                //Calculate POUnmodifiedWithoutExcessPremium
                if (outputPOModel.PublicOfficialsOptionalCoverageModel != null)
                {
                    var totalPOOptionalUnModifiedWithoutExcessPremium = 0M;

                    totalPOOptionalUnModifiedWithoutExcessPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationUnModifiedWithoutExcessPremium
                                                                  + outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseUnModifiedWithoutExcessPremium
                                                                  + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium;

                    int othercoverageWithoutExcessPremium = 0;
                    if (outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null)
                    {
                        othercoverageWithoutExcessPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel.Sum(x => x.OtherCoverageUnModifiedWithoutExcessPremium);
                    }

                    totalPOOptionalUnModifiedWithoutExcessPremium = totalPOOptionalUnModifiedWithoutExcessPremium + othercoverageWithoutExcessPremium;

                    outputPOModel.POUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(totalPOOptionalUnModifiedWithoutExcessPremium, 0, MidpointRounding.ToZero));
                }

                this._Logger.Info("PublicOfficialsCWService.CalculateOthersPremium :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsCWService.CalculateOthersPremium :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateLiablityPremium
        /// </summary>
        /// <param name="model"></param>
        private void CalculateLiablityPremium(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsCWService.CalculateLiablityPremium :: Starting");

            var inputPOModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW;
            var outputPOModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

            policyHeaderModel.State = policyHeaderModel.State.ToUpper();
            policyHeaderModel.PrimaryClass = policyHeaderModel.PrimaryClass.ToUpper();
            policyHeaderModel.TransactionType = policyHeaderModel.TransactionType.ToUpper();

            //Step-8
            //IF STATE CODE <> 'NY' pass 'Excluded' as the default value for 'EP Coverage' to the table EPInclExclFactor
            //This is not a user entered value if STATE CODE <> 'NY'

            inputPOModel.EPInclusionExclusion = "Excluded";

            // Step-10 
            //Get Rating Basis	RatingBasis				
            //Get Rating Basis by  State Code, Primary Class	Rating Basis
            var dataTableRatingBasis = this._PublicOfficials.GetRatingBasisParameter(policyHeaderModel.State,
                                                                                     policyHeaderModel.PrimaryClass,
                                                                                     inputPOModel.LineOfBusiness,
                                                                                     policyHeaderModel.PolicyEffectiveDate,
                                                                                     policyHeaderModel.PolicyExpirationDate);

            if (dataTableRatingBasis != null && dataTableRatingBasis.Rows.Count > 0 && dataTableRatingBasis.Rows[0]["RatingBasis"] != DBNull.Value)
            {
                outputPOModel.RatingBasis = dataTableRatingBasis.Rows[0]["RatingBasis"].ToString();
            }

            //Step-11
            //Math.Round((YearFrac(Policy Effective Date, Retro Active Date, 1),0)
            //Ex: If  Policy Eff Date = 05 / 11 / 2020 Retro Date = 05 / 11 / 2015 THEN YearFrac Returns the Value 5.0091. Perform RoundDown Refer to Example in J16 cell

            outputPOModel.RetroYear = (int)Math.Round(this.YearFrac(inputPOModel.RetroDate,
                                                                    policyHeaderModel.PolicyEffectiveDate)
                                                                    , 0
                                                                    , MidpointRounding.AwayFromZero);

            //Step-12.5
            //ROUND((Exposure / Rating Basis Parameter)* Base Rate *  EP Incl/ Excl * Limit Rate *Limit Aggregate Rate *(Deductible Rate   OR SIR Rate) * Population Rate *Location Rate *Policy Type Rate * Years in CM Program Rate *Retro Active Factor *Experience Factor )

            //Step-12.7
            //Get RetentionRate by these parametes:- State Code, Primary Class

            if (dataTableRatingBasis != null && dataTableRatingBasis.Rows.Count > 0 && dataTableRatingBasis.Rows[0]["RatingBasisParameter"] != DBNull.Value)
            {
                outputPOModel.RatingBasisParameter = Convert.ToInt32(dataTableRatingBasis.Rows[0]["RatingBasisParameter"]);
            }

            //ExposureRate                
            // Step-12.8
            // User Entry If the Rater receives a value -Validate the value against the Base Rate Min, Base Rate Max column of the lookup table(To be handled in PreValidations) LookUp
            // If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation
            // User Entry If the Rater receives a value -Validate the value against the Base Rate Min, Base Rate Max column of the lookup table(To be handled in PreValidations) LookUp
            // If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation
            if (inputPOModel.ExposureRate >= 0)
            {
                outputPOModel.ExposureRate = inputPOModel.ExposureRate;
            }
            else
            {
                var dataTableExposureBasis = this._PublicOfficials.GetProfLinesExposureRate(policyHeaderModel.State,
                                                                                           policyHeaderModel.PrimaryClass,
                                                                                           inputPOModel.LineOfBusiness,
                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                           policyHeaderModel.PolicyExpirationDate);

                if (dataTableExposureBasis != null && dataTableExposureBasis.Rows.Count > 0 && dataTableExposureBasis.Rows[0]["BaseRate"] != DBNull.Value)
                {
                    outputPOModel.ExposureRate = Convert.ToInt32(dataTableExposureBasis.Rows[0]["BaseRate"]);
                }
            }

            //Step-12.9
            //Always pass 'EP Coverage' as 'Excluded' to the 'EP InclExlFactor' table
            //Get RetentionRate by these parametes:-State Code,  EP Coverage(Always pass 'EP Coverage' as 'Excluded' to the table)
            outputPOModel.EPInclusionExclusionRate = this._PublicOfficials.GetProfLinesPOInclExclRate(policyHeaderModel.State,
                                                                                                     inputPOModel.LineOfBusiness,
                                                                                                     inputPOModel.EPInclusionExclusion,
                                                                                                     "Exclusion",
                                                                                                     policyHeaderModel.PolicyEffectiveDate,
                                                                                                     policyHeaderModel.PolicyExpirationDate);

            //LiabilityLimitRate
            //Step-12.10
            //User Entry If the Rater receives a value -Validate the value against the Rate Min, Rate Max column of the lookup table(To be handled in PreValidations) LookUp
            //If the rater donot receive a value -lookup 'Rate Fixed' column to pick the rate and use in the calculation
            //User Entry & Lookup (See RULE column for more details) State Code, Limit

            if (inputPOModel.LiabilityLimitRate >= 0)
            {
                outputPOModel.LiabilityLimitRate = inputPOModel.LiabilityLimitRate;
            }
            else
            {
                outputPOModel.LiabilityLimitRate = this._PublicOfficials.GetProfLinesLiabilityLimitRate(policyHeaderModel.State,
                                                                                                       inputPOModel.LineOfBusiness,
                                                                                                       inputPOModel.LiabilityLimit,
                                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                                       policyHeaderModel.PolicyExpirationDate);
            }

            //AggregateLimitRate
            //Step-12.11
            //Get RetentionRate by these parametes:-State Code, Limit, Aggregate Limit

            outputPOModel.AggregateLimitRate = this._PublicOfficials.GetProfLinesAggregateLimitRate(policyHeaderModel.State,
                                                                                                   inputPOModel.LineOfBusiness,
                                                                                                   inputPOModel.LiabilityLimit,
                                                                                                   inputPOModel.AggregateLimit,
                                                                                                   policyHeaderModel.PolicyEffectiveDate,
                                                                                                   policyHeaderModel.PolicyExpirationDate);

            //RetentionRate
            //Step-12.12
            //Get RetentionRate by these parametes:- STATE CODE, DeductibleSIR (Pass the value as 'Deductible' if 'Deductible/SIR' is selected as 'Deductible'), Deductible STATE CODE, DeductibleSIR (Pass the value as 'SIR' if 'Deductible/SIR' is selected as 'SIR') SIR

            outputPOModel.RetentionRate = this._PublicOfficials.GetProfLinesRetentionRate(policyHeaderModel.State,
                                                                                         inputPOModel.LineOfBusiness,
                                                                                         inputPOModel.DeductibleSIR,
                                                                                         inputPOModel.Retention,
                                                                                         policyHeaderModel.PolicyEffectiveDate,
                                                                                         policyHeaderModel.PolicyExpirationDate);

            //PopulationRate
            //Step-12.14
            //State Code, Primary Class, Population/ADA
            outputPOModel.PopulationRate = this._PublicOfficials.GetProfLinesPopulationRate(policyHeaderModel.State,
                                                                                           policyHeaderModel.PrimaryClass,
                                                                                           inputPOModel.LineOfBusiness,
                                                                                           policyHeaderModel.PopulationADA,
                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                           policyHeaderModel.PolicyExpirationDate);

            //LocationRate
            //Step-12.15
            //State Code, Primary Class, LocationType
            outputPOModel.LocationRate = this._PublicOfficials.GetProfLinesLocationRate(policyHeaderModel.State,
                                                                                       inputPOModel.LineOfBusiness,
                                                                                       policyHeaderModel.LocationType,
                                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                                       policyHeaderModel.PolicyExpirationDate);

            //Policy Type Rate
            //Step-12.16
            //Get RetentionRate by these parametes:-State Code, Primary Class, Population/ADA

            outputPOModel.PolicyTypeRate = this._PublicOfficials.GetProfLinesPolicyTypeRate(policyHeaderModel.State,
                                                                                           inputPOModel.LineOfBusiness,
                                                                                           inputPOModel.PolicyType,
                                                                                           policyHeaderModel.PolicyEffectiveDate,
                                                                                           policyHeaderModel.PolicyExpirationDate);

            //YearsinCMRate
            //Step-12.17
            //Get RetentionRate by these parametes:-State Code, Years in CM Program

            outputPOModel.YearsInCMRate = this._PublicOfficials.GetProfLinesCMPolicyYearRate(policyHeaderModel.State,
                                                                                            inputPOModel.LineOfBusiness,
                                                                                            inputPOModel.YearsInCMProgram,
                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                            policyHeaderModel.PolicyExpirationDate);

            //RetroDateRate
            //Step-12.18
            //Refer to Step 11  for 'Years Prior'
            //If the Years Prior is greater than 6 Pass the value '>6' to the table
            //If 'Policy Tytpe = 'Claims Made' THEN use the table to lookup the factors
            //Else '1.000'
            string retroYear = string.Empty;
            if (inputPOModel.PolicyType == "Claims Made")
            {
                if (outputPOModel.RetroYear > 6)
                {
                    retroYear = ">6";
                }
                else
                {
                    retroYear = outputPOModel.RetroYear.ToString();
                }

                outputPOModel.RetroDateRate = this._PublicOfficials.GetProfLinesRetroDateRate(policyHeaderModel.State,
                                                                                             inputPOModel.LineOfBusiness,
                                                                                             retroYear,
                                                                                             policyHeaderModel.PolicyEffectiveDate,
                                                                                             policyHeaderModel.PolicyExpirationDate);
            }
            else   // if (inputPOModel.PolicyType == "Occurrence")
            {
                outputPOModel.RetroDateRate = 1;
            }

            //Experience Rate
            //Step-12.19
            //Refer to Step 10 for 'Experience Factor Applies' (Boolean) Pass the values '1' OR '0' to Experience Factor table If Nothing is received by the rater -Use '1.000'

            outputPOModel.ExperienceRate = this._PublicOfficials.GetProfLinesLossExperienceRate(policyHeaderModel.State,
                                                                                               inputPOModel.LineOfBusiness,
                                                                                               (inputPOModel.ExperienceFactorIsSelected ? 1 : 0),
                                                                                               policyHeaderModel.PolicyEffectiveDate,
                                                                                               policyHeaderModel.PolicyExpirationDate);

            //Step-12.5
            outputPOModel.BasePremium = (int)Math.Round(((inputPOModel.Exposure
                                                        / outputPOModel.RatingBasisParameter)
                                                        * outputPOModel.ExposureRate
                                                        * outputPOModel.EPInclusionExclusionRate
                                                        * outputPOModel.LiabilityLimitRate
                                                        * outputPOModel.AggregateLimitRate
                                                        * outputPOModel.RetentionRate
                                                        * outputPOModel.PopulationRate
                                                        * outputPOModel.LocationRate
                                                        * outputPOModel.PolicyTypeRate
                                                        * outputPOModel.YearsInCMRate
                                                        * outputPOModel.RetroDateRate
                                                        * outputPOModel.ExperienceRate)
                                                        , 0
                                                        , MidpointRounding.AwayFromZero);

            //model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW = outputPOModel;

            this._Logger.Info("PublicOfficialsCWService.CalculateLiablityPremium :: Completed");
        }

        #region OptionalCoveragePremium

        /// <summary>
        /// Caculate Optional Coverage Premium
        /// </summary>
        /// <param name="model"></param>
        private void CaculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsCWService.CaculateOptionalCoveragePremium :: Starting");

            var outputPOModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputPOModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW;

            try
            {
                if (inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationIsSelected)
                {
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationIsSelected = inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationIsSelected;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationDeductible = inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationDeductible;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationModifiedPremium = inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationModifiedPremium;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationRate = inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationRate;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationReturnMethod = inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationReturnMethod;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationLimit = inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationLimit;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationAggregateLimit = inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationAggregateLimit;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationRatingBasis = inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationRatingBasis;

                    //Inverse Condemnation UnModified Premium
                    //Step-13.3
                    //Pass the Primary Class & State Codeto the Additional Coverages Premium table and if it is not found, Pass Primary Class as "All" and State Code as 'CW'. This means factor/rate applicable for all Primary Class & States
                    // ROUND to nearest whole number
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationUnModifiedWithoutExcessPremium = (int)Math.Round(this._PublicOfficials.GetProfLinesPOOptionalCoveragePremium(policyHeaderModel.State,
                                                                                                                                                                                                      policyHeaderModel.PrimaryClass,
                                                                                                                                                                                                      inputPOModel.LineOfBusiness,
                                                                                                                                                                                                      "Inverse Condemnation - AG PO 0005 01",
                                                                                                                                                                                                      inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationLimit,
                                                                                                                                                                                                      inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationAggregateLimit,
                                                                                                                                                                                                      inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationRatingBasis,
                                                                                                                                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                                                      policyHeaderModel.PolicyExpirationDate),
                                                                                                                                                                                                      0,
                                                                                                                                                                                                      MidpointRounding.AwayFromZero);

                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationUnModifiedPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationUnModifiedWithoutExcessPremium;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationIncludedInExcessExposure = inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationIncludedInExcessExposure;

                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(inputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationIncludedInExcessExposure))
                    {
                        outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationIncludedInExcessExposure = this._PublicOfficials.GetPOCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                                                            inputPOModel.LineOfBusiness,
                                                                                                                                                                            "Inverse Condemnation - AG PO 0005 01",
                                                                                                                                                                            policyHeaderModel.PrimaryClass,
                                                                                                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                            policyHeaderModel.PolicyExpirationDate);
                    }

                    //step 3
                    // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputPOModel.LiabilityLimit == ExcessExposureLiabilityLimitValidValue)
                    {
                        if (!string.IsNullOrEmpty(outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationIncludedInExcessExposure)
                            && outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationIncludedInExcessExposure.ToUpper() == "TRUE")
                        {
                            outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationUnModifiedPremium = 0;
                        }
                    }
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseIsSelected)
                {
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseIsSelected = inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseIsSelected;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseDeductible = inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseDeductible;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseModifiedPremium = inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseModifiedPremium;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseRate = inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseRate;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseReturnMethod = inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseReturnMethod;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseLimit = inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseLimit;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseAggregateLimit = inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseAggregateLimit;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseRatingBasis = inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseRatingBasis;

                    //Non-Monetary Defense UnmodifedPremium
                    //Step-14.3
                    //Pass the Primary Class & State Codeto the Additional Coverages Premium table and if it is not found, Pass Primary Class as "All" and State Code as 'CW'. This means factor/rate applicable for all Primary Class & States If Premium = n / a - Use '0' ROUND to nearest whole number
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseUnModifiedWithoutExcessPremium = (int)Math.Round(this._PublicOfficials.GetProfLinesPOOptionalCoveragePremium(policyHeaderModel.State,
                                                                                                                                                                                                     policyHeaderModel.PrimaryClass,
                                                                                                                                                                                                     inputPOModel.LineOfBusiness,
                                                                                                                                                                                                     "Non-Monetary Defense",
                                                                                                                                                                                                     inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseLimit,
                                                                                                                                                                                                     inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseAggregateLimit,
                                                                                                                                                                                                     inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseRatingBasis,
                                                                                                                                                                                                     policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                                                     policyHeaderModel.PolicyExpirationDate),
                                                                                                                                                                                                     0,
                                                                                                                                                                                                     MidpointRounding.AwayFromZero);

                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseUnModifiedPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseUnModifiedWithoutExcessPremium;
                    outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure = inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure;

                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(inputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure))
                    {
                        outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure = this._PublicOfficials.GetPOCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                                                            inputPOModel.LineOfBusiness,
                                                                                                                                                                            "Non-Monetary Defense",
                                                                                                                                                                            policyHeaderModel.PrimaryClass,
                                                                                                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                                                            policyHeaderModel.PolicyExpirationDate);
                    }

                    if (!string.IsNullOrEmpty(outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure)
                        && outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputPOModel.LiabilityLimit == ExcessExposureLiabilityLimitValidValue)
                        {
                            outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseUnModifiedPremium = 0;
                        }
                    }
                }

                #region Code removed from sheet.

                //if (inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                //{
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodDeductible = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodDeductible;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRate = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRate;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodLimit = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodLimit;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;


                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExpsure = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodInverseCondemnationIncludedInExcessExposure;

                //    if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputPOModel.LiabilityLimit == ExcessExposureLiabilityLimitValidValue)
                //    {
                //        //step 2
                //        // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                //        if (!string.IsNullOrEmpty(inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodInverseCondemnationIncludedInExcessExposure))
                //        {
                //            outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExpsure = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodInverseCondemnationIncludedInExcessExposure;
                //        }
                //        else
                //        {
                //            outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExpsure = this.PublicOfficials.GetPOCoverageInExcessExposure(policyHeaderModel.State,
                //                                                                                                                                                                        inputPOModel.LineOfBusiness,
                //                                                                                                                                                                        "Suppl. Extended Reporting Period",
                //                                                                                                                                                                        policyHeaderModel.PrimaryClass,
                //                                                                                                                                                                        policyHeaderModel.PolicyEffectiveDate,
                //                                                                                                                                                                        policyHeaderModel.PolicyExpirationDate);
                //        }

                //        //step 3
                //        // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                //        if (outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExpsure.ToUpper() == "TRUE")
                //        {
                //            outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium = 0;
                //        }
                //    }
                //}

                #endregion

                #region Optional Coverage VI -Other

                CalculateOtherOptionalCoveragePremium(model);

                #endregion

                // Calculate Optional Coverages Premium
                //Step-17
                //ROUND( Inverse Condemnation Premium + Non Monetary Defense + Suppl.Extended Reporting Period +Other Premium)
                //Step 17.1 (Refer to Step 13.3) + Step 17.2 (Refer to Step 14.3)+Step 17.3 (Refer to Step 15.3) + Step 17.4 (Refer to Step 16)

                int optionUnModifiedPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.InverseCondemnationUnModifiedPremium
                                            + outputPOModel.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseUnModifiedPremium
                                            + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;

                int othersUnmodifiedPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null ? outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel.Sum(x => x.OtherCoverageUnModifiedPremium) : 0;

                outputPOModel.PublicOfficialsOptionalCoverageModel.OtherCoveragesTotalPremium = othersUnmodifiedPremium + optionUnModifiedPremium;

                outputPOModel.NonModifiedPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.OtherCoveragesTotalPremium;
            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsCWService.CaculateOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }

            this._Logger.Info("PublicOfficialsCWService.CaculateOptionalCoveragePremium :: Completed");
        }

        #endregion

        #region Other Optional Coverage
        /// <summary>
        /// CalculateOtherOptionalCoveragePremium
        /// </summary>
        /// <param name="model"></param>
        private void CalculateOtherOptionalCoveragePremium(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsCWService.CalculateOtherOptionalCoveragePremium :: Starting");

            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var outputPOModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW;
            var otherCoverageInputModelList = inputModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel;

            if (otherCoverageInputModelList != null)
            {
                foreach (var otherCoverageInputModel in otherCoverageInputModelList)
                {
                    var otherCoverageOutputModel = new PublicOfficialsCWOtherCoverageOutputModel();
                    otherCoverageOutputModel.OtherCoverageID = otherCoverageInputModel.OtherCoverageID;
                    otherCoverageOutputModel.OtherCoverageReturnMethod = otherCoverageInputModel.OtherCoverageReturnMethod;
                    otherCoverageOutputModel.OtherCoverageAggregateLimit = otherCoverageInputModel.OtherCoverageAggregateLimit;
                    otherCoverageOutputModel.OtherCoverageDeductible = otherCoverageInputModel.OtherCoverageDeductible;
                    otherCoverageOutputModel.OtherCoverageLimit = otherCoverageInputModel.OtherCoverageLimit;
                    otherCoverageOutputModel.OtherCoverageRatingBasis = otherCoverageInputModel.OtherCoverageRatingBasis;
                    otherCoverageOutputModel.OtherCoverageReturnMethod = otherCoverageInputModel.OtherCoverageReturnMethod;
                    otherCoverageOutputModel.OtherCoverageRate = otherCoverageInputModel.OtherCoverageRate;
                    otherCoverageOutputModel.OtherCoverageDescription = otherCoverageInputModel.OtherCoverageDescription;
                    //Other Coverage Umodified Premium
                    //Step-16.5
                    //Unlimited No of "Other" Coverages can be added & based on the "Rating Basis" selected - Keep Adding the premiums to calculate final Optional Coverages Premium
                    //The Output Should be Sum of all the OTHER Premiums Round to the nearest whole number
                    //PREMIUM =
                    //IF Rating Basis = "per 1,000 of limit" THEN Rate * (Limit / 1000)
                    if (otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                    {
                        otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((otherCoverageInputModel.OtherCoverageLimit / 1000)
                                                                                                                         * otherCoverageInputModel.OtherCoverageRate
                                                                                                                         , 0
                                                                                                                         , MidpointRounding.AwayFromZero));
                    }

                    //IF Rating Basis = "per 100 of limit" THEN Rate * (Limit / 100)

                    else if (otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                    {
                        otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((otherCoverageInputModel.OtherCoverageLimit / 100)
                                                                                    * otherCoverageInputModel.OtherCoverageRate
                                                                                    , 0
                                                                                    , MidpointRounding.AwayFromZero));
                    }

                    //IF Rating Basis = "Flat charge" THEN PREMIUM is user entered
                    else if (otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARRGE")
                    {
                        otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = otherCoverageInputModel.OtherCoverageUnModifiedPremium;
                    }

                    //IF Rating Basis = "No Charge" THEN 0
                    else if (otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                    {
                        otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = 0;
                    }

                    otherCoverageOutputModel.OtherCoverageUnModifiedPremium = otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium;
                    otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure = otherCoverageInputModel.OtherCoverageIncludedInExcessExposure;

                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(otherCoverageInputModel.OtherCoverageIncludedInExcessExposure))
                    {
                        otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure = this._PublicOfficials.GetPOCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                            inputModel.LineOfBusiness,
                                                                                                                                            "Other",
                                                                                                                                            policyHeaderModel.PrimaryClass,
                                                                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                            policyHeaderModel.PolicyExpirationDate);

                    }

                    //step 3
                    // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                    if (!string.IsNullOrEmpty(otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure) && otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == ExcessExposureLiabilityLimitValidValue)
                        {
                            otherCoverageOutputModel.OtherCoverageUnModifiedPremium = 0;
                        }
                    }

                    outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel.Add(otherCoverageOutputModel);
                }
            }

            this._Logger.Info("PublicOfficialsCWService.CalculateOtherOptionalCoveragePremium :: Completed");
        }

        #endregion

        #endregion

        #region Get Yearfrac
        /// <summary>
        /// YearFrac
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public decimal YearFrac(DateTime startDate, DateTime endDate)
        {
            this._Logger.Info("PublicOfficialsCWService.YearFrac :: Starting");
            if (endDate < startDate)
            {
                return 0;
            }
            int endDay = endDate.Day;
            int startDay = startDate.Day;
            switch (startDay)
            {
                case 31:
                    {
                        startDay = 30;
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 30:
                    {
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 29:
                    {
                        if (startDate.Month == 2)
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;

                case 28:
                    {
                        if ((startDate.Month == 2) && (!DateTime.IsLeapYear(startDate.Year)))
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;
            }
            var yearFrac = (((endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDay - startDay)) / 360);
            this._Logger.Info("PublicOfficialsCWService.YearFrac :: Completed");
            return yearFrac;
        }
        #endregion
    }
}

