﻿using DataAccess;
using DomainRules;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Input;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Output;
using Models.ApiModels.LineOfBusiness.PublicOfficials;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Validations;
using Models.ApiModels.Policy;

namespace RaterPublicOfficials
{
    /// <summary>
    /// Public Officials NY Service
    /// </summary>
    public class PublicOfficialsNYService : IPublicOfficialsNYService
    {
        /// <summary>
        /// DataAccess object
        /// </summary>
        private PublicOfficialsDataAccess _PublicOfficials { get; set; }

        /// <summary>
        /// Logger object
        /// </summary>
        protected ILoggingManager _Logger { get; private set; }

        /// <summary>
        /// Configuration object
        /// </summary>
        protected IConfiguration _Configuration { get; private set; }

        private int ExcessExposureLiabilityLimitValidValue = 1000000;

        /// <summary>
        /// Public Officials NY Service
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public PublicOfficialsNYService(IConfiguration configuration, ILoggingManager logger)
        {
            this._Configuration = configuration;
            this._Logger = logger;
            this._PublicOfficials = new PublicOfficialsDataAccess(configuration, logger);
        }

        /// <summary>
        /// ExecuteDomainRules
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual DomainValidationCore.Validation.ValidationResult ExecuteDomainRules(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsNYService.ExecuteDomainRules :: Starting");
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var validationResult = new IsPolicyHeaderValid().Validate(policyHeaderModel);

            if (!validationResult.IsValid)
            {
                List<string> errorList = new List<string>();
                foreach (var error in validationResult.Errors)
                {
                    errorList.Add(error.Message);
                }
            }

            this._Logger.Info("PublicOfficialsNYService.ExecuteDomainRules :: Completed");
            return validationResult;
        }

        /// <summary>
        /// PreValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PreValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("PublicOfficialsNYService.PreValidate :: Starting");
                var validator = new PublicOfficialsNYPreValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);
                this._Logger.Info("PublicOfficialsNYService.PreValidate :: Completed");
                return results;
            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsNYService.PreValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// PostValidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns>ValidationResult</returns>
        public virtual FluentValidation.Results.ValidationResult PostValidate(RaterFacadeModel model)
        {
            try
            {
                this._Logger.Info("PublicOfficialsNYService.PostValidate :: Starting");
                var validator = new PublicOfficialsNYPostValidator(this._Configuration, this._Logger);
                var results = validator.Validate(model);
                this._Logger.Info("PublicOfficialsNYService.PostValidate :: Completed");
                return new FluentValidation.Results.ValidationResult();
            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsNYService.PostValidate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        #region PublicOfficialsCW Calculation

        /// <summary>
        /// Calculate
        /// </summary>
        /// <param name="model"></param>
        public virtual void Calculate(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsNYService.Calculate :: Starting");

            try
            {
                #region Liablity Premium 

                CalculateLiablityPremium(model);
                
                #endregion

                #region Optional Coverages Premium

                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel != null)
                {
                    CaculateOptionalCoveragePremium(model);
                }

                #endregion

                #region Other Coverages Premium

                CalculateOtherCoverages(model);

                #endregion

                this._Logger.Info("PublicOfficialsNYService.Calculate :: Completed");
            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsNYService.Calculate :: Exception :: " + ex.Message, ex);
                throw;
            }
        }

        /// <summary>
        /// CalculateLiablityPremium
        /// </summary>
        /// <param name="model"></param>
        private void CalculateLiablityPremium(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsNYService.CalculateLiablityPremium :: Starting");
            var inputPOModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            var outputPOModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

            policyHeaderModel.State = policyHeaderModel.State.ToUpper();
            policyHeaderModel.PrimaryClass = policyHeaderModel.PrimaryClass.ToUpper();
            policyHeaderModel.TransactionType = policyHeaderModel.TransactionType.ToUpper();

            //Step-1
            //Get STATE CODE
            //User Entry

            //Step-2
            //Get Primary Class
            //User Entry

            //Step-2.1
            //Get Secondary Class
            //User Entry

            //Step-3
            //Get Population/ADA
            //User Entry

            //Step-4
            //Get Location Type
            //User Entry

            //Step-5
            //Get Policy Type
            //User Entry

            //Step-6
            //Get Retro Active Date
            //User Entry

            //Step-7
            //Get  Exposure
            //User Entry

            //EPInclusionExclusion
            //Step-8
            //User Entry

            //YearsinCMProgram
            //Step-9
            //User Entry

            //Type
            //Step-10.1
            //User Entry

            //Expense
            //Step-10.2
            //User Entry

            //RatingBasis
            //Step-10.3
            //User Entry
            var dataTableRatingBasis = this._PublicOfficials.GetRatingBasisParameter(policyHeaderModel.State,
                                                                                     policyHeaderModel.PrimaryClass,
                                                                                     inputPOModel.LineOfBusiness,
                                                                                     policyHeaderModel.PolicyEffectiveDate,
                                                                                     policyHeaderModel.PolicyExpirationDate);

            if (dataTableRatingBasis != null && dataTableRatingBasis.Rows.Count > 0 && dataTableRatingBasis.Rows[0]["RatingBasis"] != DBNull.Value)
            {
                outputPOModel.RatingBasis = dataTableRatingBasis.Rows[0]["RatingBasis"].ToString();
            }

            //Step-11
            //Math.Round((YearFrac(Policy Effective Date, Retro Active Date, 1),0)
            //Ex: If  Policy Eff Date = 05 / 11 / 2020 Retro Date = 05 / 11 / 2015 THEN YearFrac Returns the Value 5.0091. Perform RoundDown Refer to Example in J16 cell

            outputPOModel.RetroYear = Convert.ToInt32(Math.Round(this.YearFrac(inputPOModel.RetroDate,
                                                                               policyHeaderModel.PolicyEffectiveDate),
                                                                               0,
                                                                               MidpointRounding.AwayFromZero));

            //LiabilityLimit
            //Step-12
            //User Entry

            //AggregateLimit
            //Step-12.1
            //User Entry

            //Get EP Limit
            //Step-12.2
            //User Entry

            //Get EP Aggregate Limit
            //Step-12.3
            //User Entry

            //Deductible / SIR
            //Step-12.4
            //User Entry

            //Retention
            //Step-12.5
            //User Entry

            //AggregateRetention
            //Step-12.6
            //User Entry

            //Step-12.7
            //ROUND(((Exposure / Rating Basis Parameter) * Base Rate* EP Incl / Excl Rate* Limit Rate* Limit Aggregate Rate)	+
            //((Exposure /Rating Basis Parameter)	* Base Rate* EP Incl / Excl Rate* Limit Rate* Limit Aggregate)	+
            // "Deductibl/SIR * Population Rate*Location Rate*Policy Type Rate*Years in CM Program Rate*Retro Active Factor)

            //Step-12.8
            //Refer to Step 7(Exposure)

            //Get Rating Basis Parameter
            //Step-12.9
            //Get RatingBasisParameter by parameters :- State Code, Primary Class

            if (dataTableRatingBasis != null && dataTableRatingBasis.Rows.Count > 0 && dataTableRatingBasis.Rows[0]["RatingBasisParameter"] != DBNull.Value)
            {
                outputPOModel.RatingBasisParameter = Convert.ToInt32(Math.Round(Convert.ToDecimal(dataTableRatingBasis.Rows[0]["RatingBasisParameter"]),
                                                                                                  0,
                                                                                                  MidpointRounding.AwayFromZero));
            }

            //ExposureRate                
            // Step-12.10
            // User Entry If the Rater receives a value -Validate the value against the Base Rate Min, Base Rate Max column of the lookup table(To be handled in PreValidations) LookUp
            // If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation
            // User Entry If the Rater receives a value -Validate the value against the Base Rate Min, Base Rate Max column of the lookup table(To be handled in PreValidations) LookUp
            // If the rater donot receive a value -lookup 'Base Rate Fixed' column to pick the rate and use in the calculation

            if (inputPOModel.ExposureRate >= 0)
            {
                outputPOModel.ExposureRate = inputPOModel.ExposureRate;
            }
            else
            {
                var dataTableExposureBasis = this._PublicOfficials.GetProfLinesExposureRate(policyHeaderModel.State,
                                                                                            policyHeaderModel.PrimaryClass,
                                                                                            inputPOModel.LineOfBusiness,
                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                            policyHeaderModel.PolicyExpirationDate);
               
                if (dataTableExposureBasis != null && dataTableExposureBasis.Rows.Count > 0 && dataTableExposureBasis.Rows[0]["BaseRate"] != DBNull.Value)
                {
                    outputPOModel.ExposureRate = Convert.ToInt32(dataTableExposureBasis.Rows[0]["BaseRate"]);
                }
            }

            //EPInclusionExclusionRate
            //Step-12.11
            //Always pass 'EP Coverage' as 'Excluded' to the 'EP InclExlFactor' table
            //Get EPInclusionExclusionRate by parameter :-State Code,  EP Coverage(Always pass 'EP Coverage' as 'Excluded' to the table)

            outputPOModel.EPInclusionExclusionRate = this._PublicOfficials.GetProfLinesPOInclExclRate(policyHeaderModel.State,
                                                                                                      inputPOModel.LineOfBusiness,                                                                                                     
                                                                                                      "Excluded",
                                                                                                      "Exclusion",
                                                                                                      policyHeaderModel.PolicyEffectiveDate,
                                                                                                      policyHeaderModel.PolicyExpirationDate);

            //LiabilityLimitRate
            //Step-12.12
            //User Entry If the Rater receives a value -Validate the value against the Rate Min, Rate Max column of the lookup table(To be handled in PreValidations) LookUp
            //If the rater donot receive a value -lookup 'Rate Fixed' column to pick the rate and use in the calculation
            //User Entry & Lookup (See RULE column for more details) State Code, Limit

            if (inputPOModel.LiabilityLimitRate >= 0)
            {
                outputPOModel.LiabilityLimitRate = inputPOModel.LiabilityLimitRate;
            }
            else
            {
                outputPOModel.LiabilityLimitRate = this._PublicOfficials.GetProfLinesLiabilityLimitRate(policyHeaderModel.State,
                                                                                                        inputPOModel.LineOfBusiness,
                                                                                                        inputPOModel.LiabilityLimit,
                                                                                                        policyHeaderModel.PolicyEffectiveDate,
                                                                                                        policyHeaderModel.PolicyExpirationDate);
            }

            //AggregateLimitRate
            //Step-12.13
            //Get AggregateLimitRate by parameter:-State Code, Limit, Aggregate Limit

            outputPOModel.AggregateLimitRate = this._PublicOfficials.GetProfLinesAggregateLimitRate(policyHeaderModel.State,
                                                                                                    inputPOModel.LineOfBusiness,
                                                                                                    inputPOModel.LiabilityLimit,
                                                                                                    inputPOModel.AggregateLimit,
                                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                                    policyHeaderModel.PolicyExpirationDate);


            //Refer to Step 17(Exposure)	
            //Step-12.14

            //Rating Basis Paramete
            //Step-12.15
            //Get Date From Step-12.9

            //ExposureRate
            //Step-12.16
            //Get ExposureRate by parameter:- LOB, State, Primary Class	Base Rate Fixed
            //Already Calculated 
            if (inputPOModel.EPInclusionExclusion.ToUpper() == "INCLUDED")
            {
                //NYEPInclusionExclusionRate
                //Step-12.17
                //Get NYEPInclusionExclusionRate parameter:- State Code, EP Coverage, ITEM(Pass ITEM = 'Inclusion')
                outputPOModel.NYEPInclusionExclusionRate = this._PublicOfficials.GetProfLinesPOInclExclRate(policyHeaderModel.State,
                                                                                                            inputPOModel.LineOfBusiness,
                                                                                                            inputPOModel.EPInclusionExclusion,
                                                                                                            "Inclusion",
                                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                                            policyHeaderModel.PolicyExpirationDate);

                //NYEPLimitRate
                //Step-12.18
                //User Entry
                //If the Rater receives a value -Validate the value against the Rate Min, Rate Max column of the lookup table(To be handled in PreValidations)LookUp
                //If the rater donot receive a value -lookup 'Rate Fixed' column to pick the rate and use in the calculation
                //User Entry &Lookup(See above for more details) State Code, Limit, PASS LOB as 'EP'
                //Todo(Limit not exit)
                DataTable dataTableNYEPLimitRate = this._PublicOfficials.GetProfLinesNYEPLimitRate(policyHeaderModel.State,
                                                                                                   inputPOModel.LineOfBusiness,
                                                                                                   inputPOModel.NYEPLimit,
                                                                                                   policyHeaderModel.PolicyEffectiveDate,
                                                                                                   policyHeaderModel.PolicyExpirationDate);

                if (dataTableNYEPLimitRate != null && dataTableNYEPLimitRate.Rows.Count>0)
                {
                    if (dataTableNYEPLimitRate.Rows[0]["Factor"] != DBNull.Value)
                    {
                        outputPOModel.NYEPLimitRate = Convert.ToDecimal(dataTableNYEPLimitRate.Rows[0]["Factor"]);
                    }
                }


                //NYEPAggregateLimitRate
                //Step-12.19
                //Get PolicyTypeRate parameter:-State Code, Limit, Aggregate Limit, PASS LOB as 'EP'
                //Todo(Limit not exit)

                outputPOModel.NYEPAggregateLimitRate = this._PublicOfficials.GetProfLinesAggregateLimitRate(policyHeaderModel.State,
                                                                                                            inputPOModel.LineOfBusiness,
                                                                                                            inputPOModel.NYEPLimit,
                                                                                                            inputPOModel.AggregateLimit,
                                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                                            policyHeaderModel.PolicyExpirationDate);

            }

            //RetentionRate
            //Step-12.20
            //Step-12.21
            //Get RetentionRate parameter:-STATE CODE, DeductibleSIR (Pass the value as 'Deductible' if 'Deductible/SIR' is selected as 'Deductible'), Deductible STATE CODE, DeductibleSIR (Pass the value as 'SIR' if 'Deductible/SIR' is selected as 'SIR') SIR

            outputPOModel.RetentionRate = this._PublicOfficials.GetProfLinesRetentionRate(policyHeaderModel.State,
                                                                                         inputPOModel.LineOfBusiness,
                                                                                         inputPOModel.DeductibleSIR,
                                                                                         inputPOModel.Retention,
                                                                                         policyHeaderModel.PolicyEffectiveDate,
                                                                                         policyHeaderModel.PolicyExpirationDate);

            //PopulationRate
            //Step-12.22
            //Get PopulationRate parameter:-State Code, Primary Class, Population/ADA
            outputPOModel.PopulationRate = this._PublicOfficials.GetProfLinesPopulationRate(policyHeaderModel.State,
                                                                                            policyHeaderModel.PrimaryClass,
                                                                                            inputPOModel.LineOfBusiness,
                                                                                            policyHeaderModel.PopulationADA,
                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                            policyHeaderModel.PolicyExpirationDate);

            //LocationRate
            //Step-12.23
            //Get LocationRate parameter:-State Code, Primary Class, Location Type
            outputPOModel.LocationRate = this._PublicOfficials.GetProfLinesLocationRate(policyHeaderModel.State,
                                                                                        inputPOModel.LineOfBusiness,
                                                                                        policyHeaderModel.LocationType,
                                                                                        policyHeaderModel.PolicyEffectiveDate,
                                                                                        policyHeaderModel.PolicyExpirationDate);

            //Policy Type Rate
            //Step-12.24
            //Get PolicyTypeRate parameter:-State Code, Primary Class, Population/ADA

            outputPOModel.PolicyTypeRate = this._PublicOfficials.GetProfLinesPolicyTypeRate(policyHeaderModel.State,
                                                                                            inputPOModel.LineOfBusiness,
                                                                                            inputPOModel.PolicyType,
                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                            policyHeaderModel.PolicyExpirationDate);

            //YearsinCMRate
            //Step-12.25
            //Get PopulationRate parameter:-State Code, Years in CM Program

            outputPOModel.YearsInCMRate = this._PublicOfficials.GetProfLinesCMPolicyYearRate(policyHeaderModel.State,
                                                                                             inputPOModel.LineOfBusiness,
                                                                                             inputPOModel.YearsInCMProgram,
                                                                                             policyHeaderModel.PolicyEffectiveDate,
                                                                                             policyHeaderModel.PolicyExpirationDate);

            //RetroDateRate
            //Step-12.26
            //Refer to Step 11  for 'Years Prior'
            //If the Years Prior is greater than 6 Pass the value '>6' to the table
            //If 'Policy Tytpe = 'Claims Made' THEN use the table to lookup the factors
            //Else '1.000'

            string retroYear = string.Empty;
            if (inputPOModel.PolicyType == "Claims Made")
            {
                if (outputPOModel.RetroYear > 6)
                {
                    retroYear = ">6";
                }
                else
                {
                    retroYear = outputPOModel.RetroYear.ToString();
                }
                outputPOModel.RetroDateRate = this._PublicOfficials.GetProfLinesRetroDateRate(policyHeaderModel.State,
                                                                                             inputPOModel.LineOfBusiness,
                                                                                             retroYear,
                                                                                             policyHeaderModel.PolicyEffectiveDate,
                                                                                             policyHeaderModel.PolicyExpirationDate);
            }
            else if (inputPOModel.PolicyType == "Occurrence")
            {
                outputPOModel.RetroDateRate = 1;
            }

            //Step-12.7
            //ROUND(((Exposure / Rating Basis Parameter) * Base Rate* EP Incl / Excl Rate* Limit Rate* Limit Aggregate Rate)	+
            //((Exposure /Rating Basis Parameter)	* Base Rate* EP Incl / Excl Rate* Limit Rate* Limit Aggregate)	+
            // "Deductibl/SIR * Population Rate*Location Rate*Policy Type Rate*Years in CM Program Rate*Retro Active Factor)
            outputPOModel.BasePremium = Convert.ToInt32(Math.Round((((inputPOModel.Exposure
                                                                     / outputPOModel.RatingBasisParameter)
                                                                     * outputPOModel.ExposureRate
                                                                     * outputPOModel.EPInclusionExclusionRate
                                                                     * outputPOModel.LiabilityLimitRate
                                                                     * outputPOModel.AggregateLimitRate)
                                                                     + ((inputPOModel.ExposureRate 
                                                                     / outputPOModel.RatingBasisParameter)
                                                                     * outputPOModel.ExposureRate
                                                                     * outputPOModel.NYEPInclusionExclusionRate
                                                                     * outputPOModel.NYEPLimitRate
                                                                     * outputPOModel.NYEPAggregateLimitRate)
                                                                     + outputPOModel.RetentionRate
                                                                     * outputPOModel.PopulationRate
                                                                     * outputPOModel.LocationRate
                                                                     * outputPOModel.PolicyTypeRate
                                                                     * outputPOModel.YearsInCMRate
                                                                     * outputPOModel.RetroDateRate),
                                                                     0 ,
                                                                     MidpointRounding.AwayFromZero));

            this._Logger.Info("PublicOfficialsNYService.CalculateLiablityPremium :: Completed");

        }

        #region Optional Coverage
        /// <summary>
        /// CaculateOptionalCoveragePremium
        /// </summary>
        /// <param name="model"></param>
        /// <param name="outputPOModel"></param>
        /// <param name="policyHeaderModel"></param>
        private void CaculateOptionalCoveragePremium(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsNYService.CaculateOptionalCoveragePremium :: Starting");

            var inputPOModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            var outputPOModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

            try
            {
                #region Code commented due to BA change in sheet.

                //if (inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                //{
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodDeductible = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodDeductible;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod;
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis;

                //    //Suppl. Extended Reporting Period Limit
                //    //Step-13
                //    //"This is an Optional Coverage Pass Coverage Name to the table as 'Inverse Condemnation - AG PO 0005 01'"	User Entry

                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodLimit = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodLimit;

                //    //Suppl. Extended Reporting Period Rate
                //    //Step-13.2
                //    //Pass the Primary Class & State Codeto the Additional Coverages Premium table and if it is not found, Check for "All". This means factor/rate applicable for all Primary Class & States
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRate = this.PublicOfficials.GetProfLinesPOOptionalCoverageRate(policyHeaderModel.State,
                //                                                                                                                                                  policyHeaderModel.PrimaryClass,
                //                                                                                                                                                  inputPOModel.LineOfBusiness,
                //                                                                                                                                                  "Suppl. Extended Reporting Period",
                //                                                                                                                                                  inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodLimit,
                //                                                                                                                                                  inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit,
                //                                                                                                                                                  inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis,
                //                                                                                                                                                  policyHeaderModel.PolicyEffectiveDate,
                //                                                                                                                                                  policyHeaderModel.PolicyExpirationDate);

                //    //Suppl.Extended Reporting Period UnModified Premium
                //    //Step-13.3
                //    //This can be added to the policy only IF
                //    //Transaction Type = Endorsement
                //    //This is not applicable for Transaction Type = New Business
                //    //Round to the nearest whole number
                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;

                //    /* if (policyHeaderModel.TransactionType.ToUpper() == AppConstants.NEWBUSINESS)
                //     {
                //         outputPOModel.publicOfficialsOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
                //     }
                //     else if (policyHeaderModel.TransactionType.ToUpper() == AppConstants.ENDORSEMENT)
                //     {
                //         var rate = Convert.ToInt32(Math.Round(this.PublicOfficials.GetProfLinesApplicableOptionalCoverage(policyHeaderModel.State,
                //                                                                                                             policyHeaderModel.PrimaryClass,
                //                                                                                                             inputPOModel.LineOfBusiness,
                //                                                                                                             "Non-Monetary Defense",
                //                                                                                                             policyHeaderModel.PolicyEffectiveDate,
                //                                                                                                             policyHeaderModel.PolicyExpirationDate),
                //                                                                                                             0, MidpointRounding.AwayFromZero));

                //         outputPOModel.publicOfficialsOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = ((rate
                //                                                                                                          / 100)
                //                                                                                                       * in
                //     }*/


                //    outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium;
                //    if (model.RaterInputFacadeModel.LineOfBusiness.Excess
                //          && inputPOModel.LiabilityLimit == ExcessExposureLiabilityLimitValidValue)
                //    {
                //        //step 2
                //        // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                //        if (!string.IsNullOrEmpty(inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure))
                //        {
                //            outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExpsure = inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure;
                //        }
                //        else
                //        {
                //            outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExpsure = this.PublicOfficials.GetPOCoverageInExcessExposure(policyHeaderModel.State,
                //                                                                                                                                                                        inputPOModel.LineOfBusiness,
                //                                                                                                                                                                        "Suppl. Extended Reporting Period",
                //                                                                                                                                                                        policyHeaderModel.PrimaryClass,
                //                                                                                                                                                                        policyHeaderModel.PolicyEffectiveDate,
                //                                                                                                                                                                        policyHeaderModel.PolicyExpirationDate);

                //        }

                //        //step 3
                //        // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                //        if (outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExpsure.ToUpper() == "TRUE")
                //        {
                //            outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium = 0;
                //        }
                //    }
                //    //FINAL PO PREMIUM
                //    //Step-13.4
                //    //Todo
                //}

                #endregion

                #region Optional Coverage VI -Other

                CalculateOtherOptionalCoveragePremium(model);

                #endregion

                // Calculate Optional Coverages Premium
                //Step-15
                //ROUND( Inverse Condemnation Premium + Non Monetary Defense + Suppl.Extended Reporting Period +Other Premium)
                //Step 15.1 (Refer to Step 13.3) +  Step 15.2 (Refer to Step 14)

                int premium = outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;

                int otherPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null ? outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel.Sum(x => x.OtherCoverageUnModifiedPremium) : 0;

                outputPOModel.PublicOfficialsOptionalCoverageModel.OtherCoveragesTotalPremium = otherPremium + premium;

                // Refer to Step 17  
                //Setep-16
                //Step-16.1 Non Modified Premium(Refer to Step 15)
                //ROUND(Optional Coverages Premium)
                outputPOModel.NonModifiedPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium
                                                 + outputPOModel.PublicOfficialsOptionalCoverageModel.OtherCoveragesTotalPremium;

            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsNYService.CaculateOptionalCoveragePremium :: Exception :: " + ex.Message, ex);
                throw;
            }

            this._Logger.Info("PublicOfficialsNYService.CaculateOptionalCoveragePremium :: Completed");
        }
        #endregion

        #region Other Optional Coverage
        /// <summary>
        /// CalculateOtherOptionalCoveragePremium
        /// </summary>
        /// <param name="model"></param>
        private void CalculateOtherOptionalCoveragePremium(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsNYService.CalculateOtherOptionalCoveragePremium :: Starting");

            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var otherCoverageInputModelList = inputModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel;
            var outputPOModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY;

            if (otherCoverageInputModelList != null)
            {
                foreach (var otherCoverageInputModel in otherCoverageInputModelList)
                {
                    var otherCoverageOutputModel = new PublicOfficialsNYOtherCoverageOutputModel();

                    otherCoverageOutputModel.OtherCoverageID = otherCoverageInputModel.OtherCoverageID;
                    otherCoverageOutputModel.OtherCoverageReturnMethod = otherCoverageInputModel.OtherCoverageReturnMethod;
                    otherCoverageOutputModel.OtherCoverageAggregateLimit = otherCoverageInputModel.OtherCoverageAggregateLimit;
                    otherCoverageOutputModel.OtherCoverageDeductible = otherCoverageInputModel.OtherCoverageDeductible;
                    otherCoverageOutputModel.OtherCoverageDescription = otherCoverageInputModel.OtherCoverageDescription;
                    otherCoverageOutputModel.OtherCoverageLimit = otherCoverageInputModel.OtherCoverageLimit;

                    //Other Coverage Rate
                    //Step-14.2
                    //User Entry [Received as Input only if Rating Basis = 'per 100 of limit' OR 'per 1,000 of limit'
                    if (otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT" || otherCoverageInputModel.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                    {
                        otherCoverageOutputModel.OtherCoverageRate = otherCoverageInputModel.OtherCoverageRate;
                    }

                    //Other Coverage Rating Basis Step-14.3 User Entry                   
                    otherCoverageOutputModel.OtherCoverageRatingBasis = otherCoverageInputModel.OtherCoverageRatingBasis;

                    //Other Coverage Umodified Premium
                    //Step-14.4
                    //Unlimited No of "Other" Coverages can be added & based on the "Rating Basis" selected - Keep Adding the premiums to calculate final Optional Coverages Premium
                    //The Output Should be Sum of all the OTHER Premiums Round to the nearest whole number
                    //PREMIUM =
                    // IF Rating Basis = "per 1,000 of limit" THEN Rate * (Limit / 1000)
                    if (otherCoverageOutputModel.OtherCoverageRatingBasis.ToUpper() == "PER 1000 OF LIMIT")
                    {
                        otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((otherCoverageInputModel.OtherCoverageLimit
                                                                                                                         / 1000)
                                                                                                                         * otherCoverageInputModel.OtherCoverageRate
                                                                                                                         , 0
                                                                                                                         , MidpointRounding.AwayFromZero));
                    }

                    //IF Rating Basis = "per 100 of limit" THEN Rate * (Limit / 100)
                    else if (otherCoverageOutputModel.OtherCoverageRatingBasis.ToUpper() == "PER 100 OF LIMIT")
                    {
                        otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = Convert.ToInt32(Math.Round((otherCoverageInputModel.OtherCoverageLimit / 100)
                                                                                                                         * otherCoverageInputModel.OtherCoverageRate
                                                                                                                         , 0
                                                                                                                         , MidpointRounding.AwayFromZero));
                    }

                    //IF Rating Basis = "Flat charge" THEN PREMIUM is user entered
                    else if (otherCoverageOutputModel.OtherCoverageRatingBasis.ToUpper() == "FLAT CHARRGE")
                    {
                        otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = otherCoverageInputModel.OtherCoverageUnModifiedPremium;
                    }

                    //IF Rating Basis = "No Charge" THEN 0
                    else if (otherCoverageOutputModel.OtherCoverageRatingBasis.ToUpper() == "NO CHARGE")
                    {
                        otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium = 0;
                    }

                    otherCoverageOutputModel.OtherCoverageUnModifiedPremium = otherCoverageOutputModel.OtherCoverageUnModifiedWithoutExcessPremium;
                    otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure = otherCoverageInputModel.OtherCoverageIncludedInExcessExposure;

                    //step 2
                    // If input value is blank then Refer to lookup table. otherwise "Included in Excess Exposure" = input
                    if (string.IsNullOrEmpty(otherCoverageInputModel.OtherCoverageIncludedInExcessExposure))
                    {
                        otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure = this._PublicOfficials.GetPOCoverageInExcessExposure(policyHeaderModel.State,
                                                                                                                                            inputModel.LineOfBusiness,
                                                                                                                                            "Other",
                                                                                                                                            policyHeaderModel.PrimaryClass,
                                                                                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                                                                                            policyHeaderModel.PolicyExpirationDate);
                    }

                    if (!string.IsNullOrEmpty(otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure) && otherCoverageOutputModel.OtherCoverageIncludedInExcessExposure.ToUpper() == "TRUE")
                    {
                        //step 3
                        // If LineOfBusiness Excess = True and Included in Excess Exposure = True and Liability Limit = 1,000,000
                        if (model.RaterInputFacadeModel.LineOfBusiness.Excess && inputModel.LiabilityLimit == ExcessExposureLiabilityLimitValidValue)
                        {
                            otherCoverageOutputModel.OtherCoverageUnModifiedPremium = 0;
                        }
                    }
                    outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel.Add(otherCoverageOutputModel);
                }
            }

            this._Logger.Info("PublicOfficialsNYService.CalculateOtherOptionalCoveragePremium :: Completed");
        }
        #endregion

        public void CalculateOtherCoverages(RaterFacadeModel model)
        {
            this._Logger.Info("PublicOfficialsNYService.CalculateOtherCoverages :: Starting");
            var inputPOModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            var outputPOModel = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;

            try
            {
                // Read Minimum Premium lookup table to get Minimum Premium
                decimal lOBMinimumPremium = this._PublicOfficials.GetLOBTotalPremium(policyHeaderModel.State,
                                                                                    inputPOModel.LineOfBusiness,
                                                                                    policyHeaderModel.PrimaryClass,
                                                                                    policyHeaderModel.PolicyEffectiveDate,
                                                                                    policyHeaderModel.PolicyExpirationDate);

                //Calculate Manual Premium
                //Step-17	
                //Step-17.1	Refer to (Step 12.7)
                //Step-17.2 Refer to Step 16
                //ROUND(Base Premium + Non Modified Premium)
                outputPOModel.ManualPremium = outputPOModel.BasePremium
                                            + outputPOModel.NonModifiedPremium;

                //Apply Minimum Premium rules
                //Step-17.3	
                //If "Manual Premium" < Minimum Premium Then "Manual Premium" = "Minimum Premium"
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(Manual Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 13.3)
                //Manual Premium = LOB Minimum Premium +Suppl.Extended Reporting Period

                if (outputPOModel.ManualPremium < lOBMinimumPremium)
                {
                    outputPOModel.ManualPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.ManualPremium = (outputPOModel.BasePremium
                                                 - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);
                    if (outputPOModel.ManualPremium < lOBMinimumPremium)
                    {
                        outputPOModel.ManualPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                    + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                //Calculate Tier Premium
                //Step-18
                //Tier Premium
                //Get Tier Type
                //Step-18.1
                //Tier Plan Applies -Policy & Pricing JSON
                //Step-18.2
                //Refer to Step 17
                //Step-18.3
                //Refer to Step 16
                //Step-18.4
                //Get Tier Factor Tier Rate
                //Step-18.5
                //Refer to Step 16
                //ROUND(((Manual Premium - Non Modified Premium) * Tier Factor) + Non Modified Premium)
                outputPOModel.TierRate = this._PublicOfficials.GetProfLinesTierRate(policyHeaderModel.State,
                                                                                   inputPOModel.LineOfBusiness,
                                                                                   model.RaterInputFacadeModel.PricingInputModel.TierPlan,
                                                                                   policyHeaderModel.PolicyEffectiveDate,
                                                                                   policyHeaderModel.PolicyExpirationDate);

                outputPOModel.TierPremium = Convert.ToInt32(Math.Round((((outputPOModel.ManualPremium
                                                                        - outputPOModel.NonModifiedPremium)
                                                                        * outputPOModel.TierRate)
                                                                        + outputPOModel.NonModifiedPremium)
                                                                        , 0
                                                                        , MidpointRounding.AwayFromZero));

                //Apply Minimum Premium rules
                //Step-18.6
                //If "Tier Premium" < Minimum Premium Then "Tier Premium" = " Minimum Premium "
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(Tier Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 13.3)
                //Tier Premium = LOB Minimum Premium +Suppl.Extended Reporting Period

                if (outputPOModel.TierPremium < lOBMinimumPremium)
                {
                    outputPOModel.TierPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.TierPremium = (outputPOModel.TierPremium
                                               - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);

                    if (outputPOModel.TierPremium < lOBMinimumPremium)
                    {
                        outputPOModel.TierPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                  + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                //Calculate IRPM Premium
                //Step-19
                //Step-19.1 Refer to Step 18
                //Step-19.2 Refer to Step 16
                //Step-19.3 Get IRPM Factor
                //Step-19.4 Refer to Step 16
                //ROUND(((Tier Premium - Non Modified Premium)	*IRPM Factor)+Non Modified Premium)	
                //If "IRPM Premium" < Minimum Premium Then
                //"IRPM Premium" = "Minimum Premium"
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(IRPM Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 13.3)
                //IRPM Premium = LOB Minimum Premium +Suppl.Extended Reporting Period

                outputPOModel.IRPMFactor = inputPOModel.IRPMFactor;

                outputPOModel.IRPMPremium = Convert.ToInt32(Math.Round(((outputPOModel.TierPremium
                                                                       - outputPOModel.NonModifiedPremium)
                                                                       * outputPOModel.IRPMFactor)
                                                                       + outputPOModel.NonModifiedPremium));

                if (outputPOModel.IRPMPremium < lOBMinimumPremium)
                {
                    outputPOModel.IRPMPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.IRPMPremium = (outputPOModel.IRPMPremium
                                               - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);

                    if (outputPOModel.IRPMPremium < lOBMinimumPremium)
                    {
                        outputPOModel.IRPMPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                  + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                //Calculate Other Mod Premium
                //Step-20
                //Other Mod Premium
                //Step-20.1
                //Refer to Step 19
                //Step-20.2
                //Refer to Step 16	
                //Step-20.3
                //Get Other Mod Factor
                //Other Mod Rate
                //Step-20.4
                //Refer to Step 16
                //Step-20.5
                //Apply Minimum Premium rules
                //ROUND(((IRPM Premium -Non Modified Premium)*Other Mod Factor)	+Non Modified Premium)

                outputPOModel.OtherModRate = inputPOModel.OtherModRate;

                outputPOModel.OtherModPremium = Convert.ToInt32(((outputPOModel.IRPMPremium
                                                                - outputPOModel.NonModifiedPremium)
                                                                * outputPOModel.OtherModRate)
                                                                + outputPOModel.NonModifiedPremium);

                //Step-20.6
                //If " Other Mod Premium" < Minimum Premium Then "Other Mod Premium" = "Minimum Premium"
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(Other Mod Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 15.3)
                //Other Mod Premium = LOB Minimum Premium +Suppl.Extended Reporting Period
                if (outputPOModel.OtherModPremium < lOBMinimumPremium)
                {
                    outputPOModel.OtherModPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.OtherModPremium = (outputPOModel.OtherModPremium
                                                   - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);

                    if (outputPOModel.OtherModPremium < lOBMinimumPremium)
                    {
                        outputPOModel.OtherModPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                      + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                //Terrorism Premium
                //Step-21	
                //Calculate Terrorism Premium
                //Step-21.1
                //Other Mod Premium
                //Refer to Step 20        
                //Terrorism Factor
                //Step-21.2
                //Get Terrorism Factor Terrorism Rate 
                //ROUND(Other Mod Premium * Terrorism Factor)
                //Terrorism Factor Is Always 0
                outputPOModel.TerrorismRate = 0;
                outputPOModel.TerrorismPremium = Convert.ToInt32(Math.Round((outputPOModel.OtherModPremium
                                                                           * outputPOModel.TerrorismRate)
                                                                           , 0
                                                                           , MidpointRounding.AwayFromZero));

                //POModifiedFinalPremium
                //Step-22	
                //Calculate  Final PO Premium
                //Other Mod Premium
                //Step-22.1
                //Refer to Step 20
                //Terrorism Premium
                //Step-22.2
                //Refer to Step 21        
                //Other Mod Premium + Terrorism Premium
                outputPOModel.PONYModifiedFinalPremium = Convert.ToInt32(outputPOModel.OtherModPremium
                                                                       + outputPOModel.TerrorismPremium);

                //Step-22.3
                //If " Final PO Premium" < Minimum Premium Then "Final PO Premium " = "Minimum Premium"
                //If the 'Suppl Extended Reoprting Period' Optional Coverage is selected on the policy -Minimum Premium rule needs to be applied as shown in the steps below
                //1.ROUND(Other Mod Premium - Suppl.Extended Reporting Period)
                //2.If '1' is less than LOB Minimum Premium
                //3.Add back Suppl Extended Reporting Period premium(Step 13.3)
                //Final PO Premium = LOB Minimum Premium +Suppl.Extended Reporting Period
                if (outputPOModel.PONYModifiedFinalPremium < lOBMinimumPremium)
                {
                    outputPOModel.PONYModifiedFinalPremium = Convert.ToInt32(lOBMinimumPremium);
                }

                if (inputPOModel.PublicOfficialsOptionalCoverageModel != null && inputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                {
                    outputPOModel.PONYModifiedFinalPremium = (outputPOModel.TierPremium
                                                            - outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium);
                   
                    if (outputPOModel.PONYModifiedFinalPremium < lOBMinimumPremium)
                    {
                        outputPOModel.PONYModifiedFinalPremium = Convert.ToInt32(lOBMinimumPremium)
                                                                               + outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium;
                    }
                }

                //Step 23	
                //Calculate PONYUnmodifiedWithoutExcessPremium	
                var totalPoOPtionalUnModifiedWithoutExcessPremium = 0M;
                if (outputPOModel.PublicOfficialsOptionalCoverageModel != null)
                {
                    totalPoOPtionalUnModifiedWithoutExcessPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium;

                    int othercoverageWithoutExcessPremium = 0;
                    if (outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null)
                    {
                        othercoverageWithoutExcessPremium = outputPOModel.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel.Sum(x => x.OtherCoverageUnModifiedWithoutExcessPremium);
                    }

                    totalPoOPtionalUnModifiedWithoutExcessPremium = totalPoOPtionalUnModifiedWithoutExcessPremium + othercoverageWithoutExcessPremium;

                    outputPOModel.PONYUnmodifiedWithoutExcessPremium = Convert.ToInt32(Math.Round(totalPoOPtionalUnModifiedWithoutExcessPremium, 0, MidpointRounding.ToZero));

                    this._Logger.Error("PublicOfficialsNYService.CalculateOtherCoverages :: Completed");
                }
            }
            catch (Exception ex)
            {
                this._Logger.Error("PublicOfficialsNYService.CalculateOtherCoverages :: Exception :: " + ex.Message, ex);
                throw;
            }
        }
        #endregion

        #region Get Yearfrac
        /// <summary>
        /// YearFrac
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>decimal</returns>
        public decimal YearFrac(DateTime startDate, DateTime endDate)
        {
            this._Logger.Info("PublicOfficialsNYService.YearFrac :: Starting");
            if (endDate < startDate)
            {
                //   throw new ArgumentOutOfRangeException("endDate cannot be less than startDate");
                return 0;
            }
            int endDay = endDate.Day;
            int startDay = startDate.Day;
            switch (startDay)
            {
                case 31:
                    {
                        startDay = 30;
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 30:
                    {
                        if (endDay == 31)
                        {
                            endDay = 30;
                        }
                    }
                    break;

                case 29:
                    {
                        if (startDate.Month == 2)
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;

                case 28:
                    {
                        if ((startDate.Month == 2) && (!DateTime.IsLeapYear(startDate.Year)))
                        {
                            startDay = 30;
                            if ((endDate.Month == 2) && (endDate.Day == 28 + (DateTime.IsLeapYear(endDate.Year) ? 1 : 0)))
                            {
                                endDay = 30;
                            }
                        }
                    }
                    break;
            }
            var yearFrac = (((endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDay - startDay)) / 360);
            this._Logger.Info("PublicOfficialsNYService.YearFrac :: Completed");
            return yearFrac;
        }
        #endregion
    }
}

