﻿using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace RaterPublicOfficials
{
    /// <summary>
    /// Public Officials CW Wrapper
    /// </summary>
    public class PublicOfficialsWrapper
    {
        /// <summary>
        /// Logger.
        /// </summary>
        protected ILoggingManager logger { get; private set; }
        protected IConfiguration configuration { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="PublicOfficialsWrapper"/> class.
        /// </summary>
        public PublicOfficialsWrapper(IConfiguration configuration, ILoggingManager logger)
        {
            this.logger = logger;
            this.configuration = configuration;
        }

        /// <summary>
        /// ExecutePublicOfficialsEngine : It's includes pre validation ,premium calculation , post validation.
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        /// <returns>ValidationResult</returns>
        public FluentValidation.Results.ValidationResult ExecutePublicOfficialsEngine(RaterFacadeModel raterFacadeModel)
        {            
            if (raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NY)
            {
                //Create service object
                IPublicOfficialsNYService service = new PublicOfficialsNYService(this.configuration, this.logger);

                //// Prevalidate
                var preValidateResults = service.PreValidate(raterFacadeModel);
                if (!preValidateResults.IsValid) return preValidateResults;

                // Since input pre validation are success, calculate premium
                service.Calculate(raterFacadeModel);

                //Post validate
                var postValidateResults = service.PostValidate(raterFacadeModel);

                return postValidateResults;
            }
            else
            {
                //Create service object
                IPublicOfficialsCWService service = new PublicOfficialsCWService(this.configuration, this.logger); 

                //// Prevalidate
                var preValidateResults = service.PreValidate(raterFacadeModel);

                if (!preValidateResults.IsValid) return preValidateResults;

                // Since input pre validation are success, calculate premium
                service.Calculate(raterFacadeModel);

                //Post validate
                var postValidateResults = service.PostValidate(raterFacadeModel);

                return postValidateResults;
            }
        }
    }
}
