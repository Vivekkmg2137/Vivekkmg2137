﻿/****** Object:  StoredProcedure [dbo].[Trident_GetAutoApplicableClassCode]    Script Date: 9/2/2021 7:32:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 07-27-2021
-- EXEC [dbo].[Trident_GetAutoApplicableClassCode] 'NY','AL', '7911', 'Emergency', '2021-11-01'		--1
-- EXEC [dbo].[Trident_GetAutoApplicableClassCode] 'NY','AL', '7398', 'Emergency', '2021-11-01'		--0
-- EXEC [dbo].[Trident_GetAutoApplicableClassCode] 'CO','AL', '014-990', 'Non Emergency', '2021-09-01'--1
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoApplicableClassCode]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@ClassCode NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF (@RatingGroup IS NULL)
		BEGIN
			IF EXISTS (Select 1  FROM [dbo].[Trident_AutoClassCodes] 
						WHERE (StateCode = @StateCode OR StateCode = 'CW') AND LOBCode = @LOBCode AND ClassCode = @ClassCode
						AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
			BEGIN
				SELECT 1 as IsApplicable
			END
			ELSE
			BEGIN
				SELECT 0 as IsApplicable
			END
		END
		ELSE
		BEGIN
			IF EXISTS (Select 1  FROM [dbo].[Trident_AutoClassCodes] 
						WHERE (StateCode = @StateCode OR StateCode = 'CW') AND LOBCode = @LOBCode AND ClassCode = @ClassCode AND RatingGroup = @RatingGroup
						AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
			BEGIN
				SELECT 1 as IsApplicable
			END
			ELSE
			BEGIN
				SELECT 0 as IsApplicable
			END
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoApplicableDeductible]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoApplicableDeductible] 'CO', 'AL', 'Deductible', 500, '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoApplicableDeductible] 'CO', 'AL', 'Deductible', 700, '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoApplicableDeductible] 'MS', 'AL', 'SIR', 25000, '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoApplicableDeductible] 'MS', 'AL', 'SIR', 35000, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoApplicableDeductible]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@DedSIR NVARCHAR(50),
@Deductible DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF (@LOBCode = 'AL')
		BEGIN

			IF EXISTS (SELECT 1 FROM [dbo].[Trident_AutoALDeductibleFactors]
						WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND DeductibleSIR = @DedSIR AND Deductible = @Deductible
						AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) 
						AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
			BEGIN
				SELECT 1 as IsApplicable
			END
			ELSE
			BEGIN
				SELECT 0 as IsApplicable
			END

		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoApplicableMedPay]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoApplicableMedPay] 'AL', 'AL', 'Medical Payments', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoApplicableMedPay] 'MI', 'AL', 'Medical Payments', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoApplicableMedPay]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_AutoMedicalPayments]
					WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage
					AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT 1 as IsApplicable
		END
		ELSE
		BEGIN
			SELECT 0 as IsApplicable
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoApplicableOptionalCoverage]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoApplicableOptionalCoverage] 'ME', 'AL', 'Additional Insured Designated Person Or Organization - CA201', '08-01-2021'	--1
-- EXEC [dbo].[Trident_GetAutoApplicableOptionalCoverage] 'ME', 'AL', 'Additional Insured Endorsement - Auto - AG1009', '08-01-2021'	--1
-- EXEC [dbo].[Trident_GetAutoApplicableOptionalCoverage] 'CO', 'AL', 'Lessor - Additional Insured And Loss Payee - CA 20 01', '08-01-2021'	--1
-- EXEC [dbo].[Trident_GetAutoApplicableOptionalCoverage] 'KS', 'AL', 'Lessor - Additional Insured And Loss Payee - CA 20 01', '08-01-2021'	--0
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoApplicableOptionalCoverage]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_AutoOptionalCoverages]
					WHERE (StateCode = @StateCode OR StateCode = 'CW') AND LOBCode = @LOBCode AND Coverage = @Coverage
					AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT 1 as IsApplicable
		END
		ELSE
		BEGIN
			SELECT 0 as IsApplicable
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoApplicablePIPCoverage]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoApplicablePIPCoverage] 'DE', 'AL', 'Personal Injury Protection', '08-01-2021'  --1
-- EXEC [dbo].[Trident_GetAutoApplicablePIPCoverage] 'CO', 'AL', 'Personal Injury Protection', '08-01-2021'	 --0
-- EXEC [dbo].[Trident_GetAutoApplicablePIPCoverage] 'MI', 'AL', 'Excess Attendant Care', '08-01-2021'  --1
-- EXEC [dbo].[Trident_GetAutoApplicablePIPCoverage] 'CO', 'AL', 'Excess Attendant Care', '08-01-2021'  --0
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoApplicablePIPCoverage]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_AutoPIPCoverages]
					WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage
					AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT 1 as IsApplicable
		END
		ELSE
		BEGIN
			SELECT 0 as IsApplicable
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoApplicableSurcharge]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoApplicableSurcharge] 'MN', 'APD', 'MN Fire Safety Surcharge', '08-01-2021'	--1
-- EXEC [dbo].[Trident_GetAutoApplicableSurcharge] 'CO', 'APD', 'MN Fire Safety Surcharge', '08-01-2021'	--0
-- EXEC [dbo].[Trident_GetAutoApplicableSurcharge] 'MN', 'APD', 'MN Automobile Theft Prevention Surcharge', '08-01-2021'	--1
-- EXEC [dbo].[Trident_GetAutoApplicableSurcharge] 'CO', 'APD', 'MN Automobile Theft Prevention Surcharge', '08-01-2021'	--0
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoApplicableSurcharge]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Surcharge NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_AutoSurcharges]
					WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Surcharge = @Surcharge
					AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT 1 as IsApplicable
		END
		ELSE
		BEGIN
			SELECT 0 as IsApplicable
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoApplicableUIMCoverage]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoApplicableUIMCoverage] 'CT', 'AL', 'Underinsured', '08-01-2021'	
-- EXEC [dbo].[Trident_GetAutoApplicableUIMCoverage] 'CT', 'AL', 'Underinsured Conversion', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoApplicableUIMCoverage] 'IL', 'AL', 'Underinsured Conversion', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoApplicableUIMCoverage]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_AutoUIMCoverages]
					WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage
					AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT 1 as IsApplicable
		END
		ELSE
		BEGIN
			SELECT 0 as IsApplicable
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoApplicableUMCoverage]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoApplicableUMCoverage] 'MS', 'AL', 'Uninsured', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoApplicableUMCoverage] 'MS', 'AL', 'Uninsured PD', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoApplicableUMCoverage]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_AutoUMCoverages]
					WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage 
					AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT 1 as IsApplicable
		END
		ELSE
		BEGIN
			SELECT 0 as IsApplicable
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoBaseRate]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoBaseRate] 'MO', 'MU', 'AL', 'Buses', 'Rural', '08-01-2021'	--640	NULL	NULL
-- EXEC [dbo].[Trident_GetAutoBaseRate] 'CT', 'CO', 'AL', 'Buses', 'Rural', '08-01-2021'	--594	100	900
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetAutoBaseRate]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@LocationType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(BaseRate as DECIMAL(8,3)) as BaseRate, 
					 CAST(BaseRateMin as DECIMAL(8,3)) as MinValue, CAST(BaseRateMax as DECIMAL(8,3)) as MaxValue
		FROM [dbo].[Trident_AutoBaseRates]
		WHERE StateCode = @StateCode AND PrimaryClassCode = @PrimaryClassCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoHiredAndNonOwnedPremium]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoHiredAndNonOwnedPremium] 'AL', 'All', 'AL', 'Hired and Non Owned', '08-01-2021'
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetAutoHiredAndNonOwnedPremium]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(Premium as DECIMAL(8,3)) as Premium
		FROM [dbo].[Trident_AutoAdditionalCoverages]
		WHERE StateCode = @StateCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') AND LOBCode = @LOBCode AND Coverage = @Coverage AND RatingBasis = 'Flat charge'
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoLimitFactor]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoLimitFactor] 'AL', 'AL', 'CSL', 100000, '08-01-2021'	--0.56	0.30	0.90
-- EXEC [dbo].[Trident_GetAutoLimitFactor] 'CO', 'AL', 'CSL', 300000, '08-01-2021'	--0.81	0.35	1.00
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetAutoLimitFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@LimitType NVARCHAR(50),
@Limit DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(DefaultFactor as DECIMAL(8,3)) as DefaultRate, 
					 CAST(RateMin as DECIMAL(8,3)) as MinValue, CAST(RateMax as DECIMAL(8,3)) as MaxValue
		FROM [dbo].[Trident_AutoLimitFactors]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LimitType = @LimitType AND Limit = @Limit
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoMedRate]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoMedRate] 'AL', 'AL', 'Medical Payments', 'Rural', 'Buses', '500', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoMedRate] 'AL', 'AL', 'Medical Payments', 'Rural', 'Buses', 'No coverage', '08-01-2021'
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetAutoMedRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@LocationType NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@Limit NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		IF (ISNUMERIC(@Limit)=1)
		BEGIN
			SELECT TOP 1 CAST(ISNULL(Rate,0) as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoMedicalPayments]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND Limit = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(ISNULL(Rate,0) as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoMedicalPayments]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND LimitDisplayText = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END

END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoNYFeeVehiclesCount]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
--EXEC [dbo].[Trident_GetAutoNYFeeVehiclesCount] 'NY', 'AL', 'NY Motor Vehicle Law Enforcement Fee', 'NB', '7398', '08-01-2021'	--1
--EXEC [dbo].[Trident_GetAutoNYFeeVehiclesCount] 'NY', 'AL', 'NY Motor Vehicle Law Enforcement Fee', 'NB', '7911', '08-01-2021'	--0
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoNYFeeVehiclesCount]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@TransactionCode NVARCHAR(50),
@ClassCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT SUM(CASE WHEN AutoFee IS NOT NULL THEN 1 ELSE 0 END) as VehiclesCount
		FROM [dbo].[Trident_AutoNYFees]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND TransactionCode = @TransactionCode
		AND ClassCode = @ClassCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoOtherMod]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Mamta
-- Create date: 07-29-2021
--EXEC [dbo].[Trident_GetAutoOtherMod] 'GA','AL', '2021-11-01' ---1.0000
-- EXEC [dbo].[Trident_GetAutoOtherMod] 'MO','APD', '2021-11-01' ---1.0000
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoOtherMod]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		SELECT TOP 1 OtherModDefault  as OtherModDefault
				FROM [dbo].[Trident_AutoOtherMod]
				WHERE StateCode = @StateCode --AND ClassCode = @ClassCode 
				AND LOBCode = @LOBCode 
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoSurchargeRate]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
--EXEC [dbo].[Trident_GetAutoSurchargeRate] 'MI', 'AL', 'MI MCCA Assessment', 'n/a', 'All', 'Unlimited','n/a', '08-01-2021'	--86
--EXEC [dbo].[Trident_GetAutoSurchargeRate] 'MI', 'AL', 'MI MCCA Assessment', 'n/a', 'All', '50000',    'n/a', '08-01-2021'	--NULL
--EXEC [dbo].[Trident_GetAutoSurchargeRate] 'NC', 'AL', 'NC Auto Loss Recoupment Surcharge', 'n/a', 'n/a', 'n/a', 'n/a', '08-01-2021'	--5.920
--EXEC [dbo].[Trident_GetAutoSurchargeRate] 'MN', 'APD','MN Fire Safety Surcharge', 'n/a', 'n/a', 'n/a', 'n/a', '08-01-2021'	--0.500
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetAutoSurchargeRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Surcharge NVARCHAR(500),
@Coverage NVARCHAR(500),
@ClassCode NVARCHAR(50),
@PIPLimit NVARCHAR(50),
@TransactionCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		IF ISNUMERIC(@PIPLimit) = 1
		BEGIN
			SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoSurcharges]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND (ISNULL(ClassCode,'n/a') = @ClassCode OR ClassCode = 'ALL')
			AND Surcharge = @Surcharge AND ISNULL(Coverage,'n/a') = @Coverage
			AND PIPLimit = @PIPLimit AND ISNULL(TransactionCode,'n/a') = @TransactionCode
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoSurcharges]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND (ISNULL(ClassCode,'n/a') = @ClassCode OR ClassCode = 'ALL') 
			AND Surcharge = @Surcharge AND ISNULL(Coverage,'n/a') = @Coverage
			AND PIPLimitDisplayText = @PIPLimit AND ISNULL(TransactionCode,'n/a') = @TransactionCode
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoSurchargeVehiclesCount]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
--EXEC [dbo].[Trident_GetAutoSurchargeVehiclesCount] 'MN', 'APD', 'MN Automobile Theft Prevention Surcharge', 'Comprehensive', '011-790', 'CN', '08-01-2021'	--1
--EXEC [dbo].[Trident_GetAutoSurchargeVehiclesCount] 'MN', 'APD', 'MN Automobile Theft Prevention Surcharge', 'Comprehensive', '011-990', 'CN', '08-01-2021'	--1
--EXEC [dbo].[Trident_GetAutoSurchargeVehiclesCount] 'MN', 'APD', 'MN Automobile Theft Prevention Surcharge', 'Comprehensive', '011-790', 'EN', '08-01-2021'	--1
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoSurchargeVehiclesCount]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Surcharge NVARCHAR(500),
@Coverage NVARCHAR(500),
@ClassCode NVARCHAR(50),
@TransactionCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT SUM(CASE WHEN Rate IS NOT NULL THEN 1 ELSE 0 END) as VehiclesCount
		FROM [dbo].[Trident_AutoSurcharges]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND (ISNULL(ClassCode,'n/a') = @ClassCode OR ClassCode = 'ALL')
		AND Surcharge = @Surcharge AND ISNULL(Coverage,'n/a') = @Coverage
		AND ISNULL(TransactionCode,'n/a') = @TransactionCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoTierFactor]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoTierFactor] 'CT', 'AL', 'Preferred', '08-01-2021'	--0.8500
-- EXEC [dbo].[Trident_GetAutoTierFactor] 'CO', 'AL', NULL, '08-01-2021'	--1.000
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetAutoTierFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@TierType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(Factor as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_AutoTierFactors]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND (TierType IS NULL OR TierType = @TierType)
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoUMRate]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoUMRate] 'MS', 'AL', 'Uninsured', 'Rural', 'Buses', 1, '75000', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoUMRate] 'MS', 'AL', 'Uninsured', 'Rural', 'Buses', 1, 'No coverage', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoUMRate] 'MN', 'AL', 'Uninsured', 'Rural', 'Buses', NULL, '1000000', '08-01-2021'
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetAutoUMRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@LocationType NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@UMUIMStacking BIT,
@Limit NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		IF (ISNUMERIC(@Limit)=1)
		BEGIN
			SELECT TOP 1 CAST(ISNULL(Rate,0) as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoUMCoverages]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND (UMUIMStacking IS NULL OR UMUIMStacking = @UMUIMStacking) AND Limit = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(ISNULL(Rate,0) as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoUMCoverages]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND (UMUIMStacking IS NULL OR UMUIMStacking = @UMUIMStacking) AND LimitDisplayText = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetMinMaxValueForFactor]    Script Date: 9/2/2021 7:32:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC Trident_GetMinMaxValueForFactor 'AL',NULL,'PR','LargeRiskFactor','2021-09-09'  --0.0100	25.0000
-- EXEC Trident_GetMinMaxValueForFactor 'AL',NULL,'PR','IRPM','2021-09-09'  --0.9000	1.0000
-- EXEC Trident_GetMinMaxValueForFactor 'NY',NULL,'PR','IRPM Factor','2021-09-09'  --0.8500	1.1500
-- EXEC Trident_GetMinMaxValueForFactor 'NY',NULL,'PR','Other Mod','2021-09-09'	--0.0100	25.0000
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetMinMaxValueForFactor]  
(  
@StateCode NVARCHAR(50),  
@PrimaryClassCode NVARCHAR(50),  
@LOBCode NVARCHAR(50),  
@FactorType NVARCHAR(50),  
@PolicyEffectiveDate DATETIME  
)  
AS  
BEGIN     
	IF (@FactorType = 'LargeRiskFactor' AND @StateCode <> 'NY' AND @LOBCode='PR')
	BEGIN
		IF @StateCode = 'NH'
		BEGIN
			SELECT CAST(1 as DECIMAL(8,4)) as MinValue, CAST(1 as DECIMAL(8,4)) as MaxValue  
		END
		ELSE
		BEGIN
			SELECT TOP 1 MinValue, MaxValue 
			FROM Trident_LargeRiskMod   
			WHERE StateCode = @StateCode AND LOBCode=@LOBCode  
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)  
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)  
		END
	END

	ELSE IF (@FactorType = 'IRPM' AND @StateCode <> 'NY' AND @LOBCode='PR')
	BEGIN
		SELECT TOP 1 MinModValue as MinValue, MaxModValue as MaxValue
		FROM Trident_EquipBreakdownIRPM   
		WHERE StateCode = @StateCode AND LOBCode=@LOBCode  
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)  
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)  
	END   

	ELSE IF (@FactorType IN ('IRPM Factor', 'Other Mod') AND @StateCode = 'NY' AND @LOBCode='PR')
	BEGIN
		SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,4)) as MinValue, CAST(KeyValue2 as DECIMAL(15,4)) as MaxValue
		FROM [dbo].[Trident_MiscFactors] 
		WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END

	ELSE IF (@FactorType = 'IRPM' AND @LOBCode IN ('AL','APD'))
	BEGIN
		SELECT TOP 1 IRPMMin as MinValue, IRPMMax as MaxValue
		FROM [dbo].[Trident_AutoIRPM] 
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END

	ELSE IF (@FactorType = 'OtherMod' AND @LOBCode IN ('AL','APD'))
	BEGIN
		SELECT TOP 1 OtherModMin as MinValue, OtherModMax as MaxValue
		FROM [dbo].[Trident_AutoOtherMod]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoPIPRate]    Script Date: 9/14/2021 3:10:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'MI', 'AL', 'Personal Injury Protection', 'Rural', 'Buses', NULL, 'Unlimited', '08-01-2021'  --n/a	--18
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'MI', 'AL', 'Personal Injury Protection', 'Rural', 'Buses', NULL, '50000', '08-01-2021'	--n/a	--11
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'MI', 'AL', 'Excess Attendant Care', 'Rural', 'Buses', '250000', '1000', '08-01-2021'  --n/a	--13
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'MI', 'AL', 'Excess Attendant Care', 'Rural', 'Buses', '500000', '1000', '08-01-2021'	--n/a	--16
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'PA', 'AL', 'Basic FPB', 'Rural', 'Buses', NULL, 'Included', '08-01-2021'  --n/a	--20
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'PA', 'AL', 'Basic FPB', 'Metro', 'Buses', NULL, 'Included', '08-01-2021'	--n/a	--25
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetAutoPIPRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@LocationType NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@DependentCoverageLimit NVARCHAR(50),
@Limit NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		IF (ISNUMERIC(@Limit)=1)
		BEGIN
			IF (ISNUMERIC(@DependentCoverageLimit) = 1)
			BEGIN
				SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
				FROM [dbo].[Trident_AutoPIPCoverages]
				WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
				AND Coverage = @Coverage AND (Limit = @Limit OR NULLIF(LTRIM(RTRIM(@Limit)),'') IS NULL) AND (DependentCoverageLimit = @DependentCoverageLimit OR @DependentCoverageLimit IS NULL)
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
			END
			ELSE
			BEGIN
				SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
				FROM [dbo].[Trident_AutoPIPCoverages]
				WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
				AND Coverage = @Coverage AND (Limit = @Limit OR NULLIF(LTRIM(RTRIM(@Limit)),'') IS NULL) AND (DependentCoverageLimitDisplayText = @DependentCoverageLimit OR @DependentCoverageLimit IS NULL)
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
			END
		END
		ELSE
		BEGIN
			IF (ISNUMERIC(@DependentCoverageLimit) = 1)
			BEGIN
				SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
				FROM [dbo].[Trident_AutoPIPCoverages]
				WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
				AND Coverage = @Coverage AND (LimitDisplayText = @Limit OR NULLIF(LTRIM(RTRIM(@Limit)),'') IS NULL) AND (DependentCoverageLimit = @DependentCoverageLimit OR @DependentCoverageLimit IS NULL)
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
			END
			ELSE
			BEGIN
				SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
				FROM [dbo].[Trident_AutoPIPCoverages]
				WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
				AND Coverage = @Coverage AND (LimitDisplayText = @Limit OR NULLIF(LTRIM(RTRIM(@Limit)),'') IS NULL) AND (DependentCoverageLimitDisplayText = @DependentCoverageLimit OR @DependentCoverageLimit IS NULL)
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
			END
		END

END
GO
