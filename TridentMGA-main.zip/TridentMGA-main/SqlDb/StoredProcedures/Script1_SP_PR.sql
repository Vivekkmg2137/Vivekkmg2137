﻿USE [ParagonInsuranceHoldings]
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetBIEEDaysFactor]    Script Date: 7/9/2021 4:44:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetBIEEDaysFactor] 'AL', 'PR', 60, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetBIEEDaysFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@NumDays INT,
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(ExtPeriodOfIndemnityFactor as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_BIExtendedPeriodOfIndemnity]
		WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND NumDays = @NumDays 
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetBIEEDeductibleFactor]    Script Date: 7/9/2021 4:44:15 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetBIEEDeductibleFactor] 'AL', 'PR', 24, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetBIEEDeductibleFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Deductible DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(TimeElemDeductibleFactor as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_BITimeElementDeductible]
		WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND TimeElemDeductible = @Deductible 
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetBuildingAddtlDefCharge]    Script Date: 7/9/2021 4:44:00 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetBuildingAddtlDefCharge] 'AL', 'PR', 12500, 'Increased Def Point Factor', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetBuildingAddtlDefCharge]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@BuildingDefPts DECIMAL(15,4),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		DECLARE @Val1 DECIMAL(15,4), @Val2 DECIMAL(15,4), @Val3 DECIMAL(15,3);

		IF EXISTS (SELECT 1 FROM [dbo].[Trident_MiscFactors] WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT TOP 1 @Val1 = ISNULL(KeyValue1,0), @Val2 = ISNULL(KeyValue2,0) 
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 @Val1 = ISNULL(KeyValue1,0), @Val2 = ISNULL(KeyValue2,0) 
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = 'CW' AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END

		--SET @Val3 = (SELECT (((FLOOR(((@BuildingDefPts - 6750 - 1) / 50)) + 1) * ISNULL(@Val1,0)) + ISNULL(@Val2,0)));
		SET @Val3 = (SELECT ROUND((ROUND(((FLOOR(((@BuildingDefPts - 6750 - 1) / 50)) + 1) * ISNULL(@Val1,0)),3) + ISNULL(@Val2,0)),3));

		SELECT @Val3 as AdditionalChargesBuilding;

END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetBuildingBaseMLR]    Script Date: 7/9/2021 4:43:47 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetBuildingBaseMLR] 'MU', '1', 'CW', 'PR', 'Class Group Rate', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetBuildingBaseMLR]
(
@PrimaryClassCode NVARCHAR(50),
@SecondaryClassCode NVARCHAR(50),
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN

	DECLARE @ClassGroup NVARCHAR(50);

	SELECT @ClassGroup = ClassGroup 
	FROM [dbo].[Trident_SecondaryClass] SC
	WHERE SC.PrimaryClassCode = @PrimaryClassCode AND SC.SecondaryClassCode = @SecondaryClassCode AND SC.LOBCode = @LOBCode 
	AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
	AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
	IF EXISTS (SELECT 1 FROM [dbo].[Trident_MiscFactors] WHERE Key1 = @LOBCode AND Key2 = @StateCode AND Key3 = @ClassGroup AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
	BEGIN
		SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as KeyValue 
		FROM [dbo].[Trident_MiscFactors] 
		WHERE Key1 = @LOBCode AND Key2 = @StateCode AND Key3 = @ClassGroup AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END
	ELSE
	BEGIN
		SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as KeyValue 
		FROM [dbo].[Trident_MiscFactors] 
		WHERE Key1 = @LOBCode AND Key2 = 'CW' AND Key3 = @ClassGroup AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetBuildingMajorLossRateCharge]    Script Date: 7/9/2021 4:43:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetBuildingMajorLossRateCharge] 'AL', 'PR', 700, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetBuildingMajorLossRateCharge]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@BuildingDefPts DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(AdditionalChargesBuilding as DECIMAL(8,3)) as AdditionalChargesBuilding
		FROM [dbo].[Trident_MajorLossRateCharges] 
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode 
		AND @BuildingDefPts BETWEEN MinDeficiencyPoints AND MaxDeficiencyPoints
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetCauseOfLossFactor]    Script Date: 7/9/2021 4:43:09 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetCauseOfLossFactor] 'AL', 'PR', 'Basic', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetCauseOfLossFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@CauseOfLoss NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST([Factor] as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_CauseOfLossFactors]
		WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND CauseOfLoss = @CauseOfLoss
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetCoinsurance]    Script Date: 7/9/2021 4:42:56 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetCoinsurance] 'AL', 'PR', '0.90', '08-01-2021'
-- EXEC [dbo].[Trident_GetCoinsurance] 'AL', 'PR', 'Agreed Amount', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetCoinsurance]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coinsurance NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF (@Coinsurance = 'Agreed Amount')
		BEGIN
			SELECT CAST([Rate] as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_CoinsuranceFactors]
			WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND Coinsurance = @Coinsurance
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT CAST([Rate] as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_CoinsuranceFactors]
			WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND CAST(Coinsurance as DECIMAL(8,4)) = CAST(@Coinsurance as DECIMAL(8,4))
			AND Coinsurance <> 'Agreed Amount'
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetContentsAddtlDefCharge]    Script Date: 7/9/2021 4:49:09 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetContentsAddtlDefCharge] 'AL', 'PR', 12500, 'Increased Def Point Factor', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetContentsAddtlDefCharge]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@ContentsDefPts DECIMAL(15,4),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		DECLARE @Val1 DECIMAL(15,4), @Val2 DECIMAL(15,4), @Val3 DECIMAL(15,3);

		IF EXISTS (SELECT 1 FROM [dbo].[Trident_MiscFactors] WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT TOP 1 @Val1 = ISNULL(KeyValue1,0), @Val2 = ISNULL(KeyValue2,0) 
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 @Val1 = ISNULL(KeyValue1,0), @Val2 = ISNULL(KeyValue2,0) 
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = 'CW' AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END

		--SET @Val3 = (SELECT (((FLOOR(((@ContentsDefPts - 6750 - 1) / 50)) + 1) * ISNULL(@Val1,0)) + ISNULL(@Val2,0)))
		SET @Val3 = (SELECT ROUND((ROUND(((FLOOR(((@ContentsDefPts - 6750 - 1) / 50)) + 1) * ISNULL(@Val1,0)),3) + ISNULL(@Val2,0)),3));

		SELECT @Val3 as AdditionalChargesContents
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetContentsBaseMLR]    Script Date: 7/9/2021 4:42:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetContentsBaseMLR] 'MU', '1', 'CW', 'PR', 'Class Group Rate', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetContentsBaseMLR]
(
@PrimaryClassCode NVARCHAR(50),
@SecondaryClassCode NVARCHAR(50),
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN

	DECLARE @ClassGroup NVARCHAR(50);

	SELECT @ClassGroup = ClassGroup 
	FROM [dbo].[Trident_SecondaryClass] SC
	WHERE SC.PrimaryClassCode = @PrimaryClassCode AND SC.SecondaryClassCode = @SecondaryClassCode AND SC.LOBCode = @LOBCode 
	AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
	AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
	IF EXISTS (SELECT 1 FROM [dbo].[Trident_MiscFactors] WHERE Key1 = @LOBCode AND Key2 = @StateCode AND Key3 = @ClassGroup AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
	BEGIN
		SELECT TOP 1 CAST(KeyValue2 as DECIMAL(15,3)) as KeyValue 
		FROM [dbo].[Trident_MiscFactors] 
		WHERE Key1 = @LOBCode AND Key2 = @StateCode AND Key3 = @ClassGroup AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END
	ELSE
	BEGIN
		SELECT TOP 1 CAST(KeyValue2 as DECIMAL(15,3)) as KeyValue 
		FROM [dbo].[Trident_MiscFactors] 
		WHERE Key1 = @LOBCode AND Key2 = 'CW' AND Key3 = @ClassGroup AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetContentsMajorLossRateCharge]    Script Date: 7/9/2021 4:42:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetContentsMajorLossRateCharge] 'AL', 'PR', 700, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetContentsMajorLossRateCharge]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@ContentsDefPts DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(AdditionalChargesContents as DECIMAL(8,3)) as AdditionalChargesContents
		FROM [dbo].[Trident_MajorLossRateCharges] 
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode 
		AND @ContentsDefPts BETWEEN MinDeficiencyPoints AND MaxDeficiencyPoints
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO