﻿USE [ParagonInsuranceHoldings]
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetCoverageDeductibleFactor]    Script Date: 7/9/2021 4:35:51 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetCoverageDeductibleFactor] 'CW', 'PR', 'Dependent Property Business Income', 'DED', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetCoverageDeductibleFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@CoverageName NVARCHAR(500),
@Type NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		DECLARE @CoverageID INT;
		IF EXISTS (SELECT 1 FROM Trident_360Coverage WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND CoverageName = @CoverageName
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SET @CoverageID = (SELECT TOP 1 CoverageID FROM Trident_360Coverage 
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND CoverageName = @CoverageName
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL));
		END
		ELSE
		BEGIN
			SET @CoverageID = (SELECT TOP 1 CoverageID FROM Trident_360Coverage 
			WHERE StateCode = 'CW' AND LOBCode = @LOBCode AND CoverageName = @CoverageName
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL));
		END

		IF EXISTS (SELECT 1 FROM [dbo].[Trident_360CoverageDeductible] WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND CoverageID = @CoverageID
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT TOP 1 CASE @Type WHEN 'DED' THEN CAST([DeductibleFactor] as DECIMAL(15,3))
						  WHEN 'AOP' THEN CAST([AOPDeductibleFactor] as DECIMAL(15,3))
						  WHEN '360' THEN CAST([360DeductibleFactor] as DECIMAL(15,3))
			END as DedFactor
			FROM [dbo].[Trident_360CoverageDeductible]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND CoverageID = @CoverageID
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CASE @Type WHEN 'DED' THEN CAST([DeductibleFactor] as DECIMAL(15,3))
						  WHEN 'AOP' THEN CAST([AOPDeductibleFactor] as DECIMAL(15,3))
						  WHEN '360' THEN CAST([360DeductibleFactor] as DECIMAL(15,3))
			END as DedFactor
			FROM [dbo].[Trident_360CoverageDeductible]
			WHERE StateCode = 'CW' AND LOBCode = @LOBCode AND CoverageID = @CoverageID
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetCoverageDetail]    Script Date: 7/9/2021 4:35:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetCoverageDetail] 'CW', 'All', 'PR', 'Business Income and Extra Expense', 'Limit', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetCoverageDetail]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@CoverageName NVARCHAR(500),
@Type NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		DECLARE @CoverageID INT;
		IF EXISTS (SELECT 1 FROM Trident_360Coverage WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND CoverageName = @CoverageName
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SET @CoverageID = (SELECT TOP 1 CoverageID FROM Trident_360Coverage 
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND CoverageName = @CoverageName
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL));
		END
		ELSE
		BEGIN
			SET @CoverageID = (SELECT TOP 1 CoverageID FROM Trident_360Coverage 
			WHERE StateCode = 'CW' AND LOBCode = @LOBCode AND CoverageName = @CoverageName
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL));
		END


		IF EXISTS (SELECT 1 FROM [dbo].[Trident_360CoverageDetails] WHERE StateCode = @StateCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') AND LOBCode = @LOBCode 
		AND CoverageID = @CoverageID AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT TOP 1 CASE @Type WHEN 'Limit' THEN CAST([BaseLimit] as DECIMAL(15,3))
						  WHEN 'Premium' THEN CAST([MinimumPremium] as DECIMAL(15,3))
						  WHEN 'Rate' THEN CAST([Rate] as DECIMAL(15,3))
			END as CoverageVal
			FROM [dbo].[Trident_360CoverageDetails]
			WHERE StateCode = @StateCode
			AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') 
			AND LOBCode = @LOBCode 
			AND CoverageID = @CoverageID
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CASE @Type WHEN 'Limit' THEN CAST([BaseLimit] as DECIMAL(15,3))
						  WHEN 'Premium' THEN CAST([MinimumPremium] as DECIMAL(15,3))
						  WHEN 'Rate' THEN CAST([Rate] as DECIMAL(15,3))
			END as CoverageVal
			FROM [dbo].[Trident_360CoverageDetails]
			WHERE StateCode = 'CW'
			AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') 
			AND LOBCode = @LOBCode 
			AND CoverageID = @CoverageID
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetCoverageDetailForAdditionalBenefits]    Script Date: 7/9/2021 4:35:20 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetCoverageDetailForAdditionalBenefits] '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetCoverageDetailForAdditionalBenefits]
(
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT C.CoverageName, CD.BaseLimit
		FROM [Trident_360CoverageDetails] CD
		INNER JOIN [Trident_360Coverage] C
		ON CD.StateCode=C.StateCode AND CD.LOBCode=C.LOBCode AND CD.CoverageID=C.CoverageID
		WHERE CD.IsIncludedInAdditionalBenefits = 1 AND
		CAST(@PolicyEffectiveDate as DATE) >= CAST(CD.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(CD.EndDate as DATE) OR CD.EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetDollarDeductibleFactor]    Script Date: 7/9/2021 4:35:04 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetDollarDeductibleFactor] 'AL', 'PR', 1000, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetDollarDeductibleFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Deductible DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(DeductibleFactor as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_DollarDeductibleCredit]
		WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND Deductible = @Deductible 
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetEBBIDeductibleFactor]    Script Date: 7/9/2021 4:34:48 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetEBBIDeductibleFactor] 'AL', 'MU', 'PR', 48, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetEBBIDeductibleFactor]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@EBBIDeductible DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(EBBIDeductibleFactor as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_EBBIDeductibleFactors]
		WHERE StateCode = @StateCode AND PrimaryClassCode = @PrimaryClassCode AND LOBCode = @LOBCode AND EBBIDeductible = @EBBIDeductible
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetEBDeductibleFactor]    Script Date: 7/9/2021 4:34:30 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetEBDeductibleFactor] 'AL', 'MU', 'PR', 1000, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetEBDeductibleFactor]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@EBDeductible DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(EBDeductibleFactor as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_EBDeductibleFactors]
		WHERE StateCode = @StateCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') AND LOBCode = @LOBCode AND EBDeductible = @EBDeductible
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetEBLimitFactor]    Script Date: 7/9/2021 4:34:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetEBLimitFactor] 'AL', 'MU', 'PR', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetEBLimitFactor]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(EBLimitFactor as DECIMAL(8,4)) as Factor
		FROM [dbo].[Trident_EBLimitFactors]
		WHERE StateCode = @StateCode AND PrimaryClassCode = @PrimaryClassCode AND LOBCode = @LOBCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetEBSpoilageDollarDeductibleFactor]    Script Date: 7/9/2021 4:34:04 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetEBSpoilageDollarDeductibleFactor] 'AL', 'MU', 'PR', 1000, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetEBSpoilageDollarDeductibleFactor]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@SpoilageDeductible DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(Factor as DECIMAL(8,3)) as EBSpoilageFactor
		FROM [dbo].[Trident_EBSpoilageDollarDeductible]
		WHERE StateCode = @StateCode AND PrimaryClassCode = @PrimaryClassCode AND LOBCode = @LOBCode AND EBSpoilageDollarDeductible = @SpoilageDeductible
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetEBSpoilagePercentageDeductibleFactor]    Script Date: 7/9/2021 4:33:50 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetEBSpoilagePercentageDeductibleFactor] 'AL', 'PR', 0.10, '08-01-2021'
-- EXEC [dbo].[Trident_GetEBSpoilagePercentageDeductibleFactor] 'AL', 'PR', 0.00, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetEBSpoilagePercentageDeductibleFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@SpoilageDeductible DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF (@SpoilageDeductible = 0)
		BEGIN
			SELECT CAST(1 as DECIMAL(8,3)) as EBSpoilageFactor
		END
		ELSE
		BEGIN
			SELECT CAST(EBSpoilageFactor as DECIMAL(8,3)) as EBSpoilageFactor
			FROM [dbo].[Trident_EBSpoilagePercentageDeductible]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND EBSpoilageDeductible = @SpoilageDeductible
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetEquipmentBreakdownTotalPremium]    Script Date: 7/9/2021 4:33:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetEquipmentBreakdownTotalPremium] 'AL', 'All', 'PR', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetEquipmentBreakdownTotalPremium]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(EBMinPremium as DECIMAL(8,3)) as EBMinPremium
		FROM [dbo].[Trident_PropertyMinimumPremium]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All')
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO