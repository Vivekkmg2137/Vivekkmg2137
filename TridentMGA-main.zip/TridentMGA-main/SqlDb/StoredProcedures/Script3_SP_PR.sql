﻿USE [ParagonInsuranceHoldings]
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetInflationGuardFactor]    Script Date: 7/9/2021 4:27:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetInflationGuardFactor] 'NY', 'PR', 0.02, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetInflationGuardFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@InflationGuard DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST([Factor] as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_NYInflationGuardFactors]
		WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND InflationGuard = @InflationGuard
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetLCM]    Script Date: 7/9/2021 4:27:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetLCM] 'CW', 'PR', 'Normal Loss Rate LCM', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetLCM]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_MiscFactors] WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as LCMValue 
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as LCMValue 
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = 'CW' AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetLOBTotalPremium]    Script Date: 7/9/2021 4:27:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetLOBTotalPremium] 'AL', 'All', 'PR', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetLOBTotalPremium]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(LOBMinPremium as DECIMAL(8,3)) as LOBMinPremium
		FROM [dbo].[Trident_PropertyMinimumPremium]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All')
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetMarginClause]    Script Date: 7/9/2021 4:26:47 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetMarginClause] 'AL', 'PR', '1.05', '08-01-2021'
-- EXEC [dbo].[Trident_GetMarginClause] 'AL', 'PR', 'No Coverage', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetMarginClause]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@MarginClause NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF (@MarginClause = 'No Coverage')
		BEGIN
			SELECT CAST([Rate] as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_MarginClauseFactors]
			WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND MarginClause = @MarginClause
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT CAST([Rate] as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_MarginClauseFactors]
			WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND CAST(MarginClause as DECIMAL(8,4)) = CAST(@MarginClause as DECIMAL(8,4))
			AND MarginClause <> 'No Coverage'
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetMergeCoverageDeductibleFactor]    Script Date: 7/21/2021 5:46:06 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetMergeCoverageDeductibleFactor] 'AL', 'PR', '08-01-2021'
-- EXEC [dbo].[Trident_GetMergeCoverageDeductibleFactor] 'CW', 'PR', '08-01-2021'
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetMergeCoverageDeductibleFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_360CoverageDeductible] WHERE StateCode = @StateCode AND LOBCode = @LOBCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT C.CoverageName,
					CAST([DeductibleFactor] as DECIMAL(15,3)) as Deductible,
					CAST([AOPDeductibleFactor] as DECIMAL(15,3)) as AOPDeductible,
					CAST([360DeductibleFactor] as DECIMAL(15,3)) as [360Deductible]
			FROM [dbo].[Trident_360CoverageDeductible] CD
			INNER JOIN [dbo].[Trident_360Coverage] C ON CD.CoverageID = C.CoverageID AND CD.StateCode = C.StateCode AND CD.LOBCode = C.LOBCode
			WHERE CD.StateCode = @StateCode AND CD.LOBCode = @LOBCode
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(CD.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(CD.EndDate as DATE) OR CD.EndDate IS NULL)
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(C.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(C.EndDate as DATE) OR C.EndDate IS NULL)
			ORDER BY C.CoverageName
		END
		ELSE
		BEGIN
			SELECT C.CoverageName,
					CAST([DeductibleFactor] as DECIMAL(15,3)) as Deductible,
					CAST([AOPDeductibleFactor] as DECIMAL(15,3)) as AOPDeductible,
					CAST([360DeductibleFactor] as DECIMAL(15,3)) as [360Deductible]
			FROM [dbo].[Trident_360CoverageDeductible] CD
			INNER JOIN [dbo].[Trident_360Coverage] C ON CD.CoverageID = C.CoverageID AND CD.StateCode = C.StateCode AND CD.LOBCode = C.LOBCode
			WHERE CD.StateCode = 'CW' AND CD.LOBCode = @LOBCode
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(CD.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(CD.EndDate as DATE) OR CD.EndDate IS NULL)
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(C.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(C.EndDate as DATE) OR C.EndDate IS NULL)
			ORDER BY C.CoverageName
		END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetMergeCoverageDetail]    Script Date: 7/21/2021 5:45:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetMergeCoverageDetail] 'NY', 'SC', 'PR', '08-01-2021'
-- EXEC [dbo].[Trident_GetMergeCoverageDetail] 'CW', 'All', 'PR', '08-01-2021'
-- =============================================

ALTER PROCEDURE [dbo].[Trident_GetMergeCoverageDetail]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN

		IF EXISTS (SELECT 1 FROM [dbo].[Trident_360CoverageDetails] WHERE StateCode = @StateCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') AND LOBCode = @LOBCode 
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT C.CoverageName,
					CAST([BaseLimit] as DECIMAL(15,3)) as Limit,
					CAST([MinimumPremium] as DECIMAL(15,3)) as Premium,
					CAST([Rate] as DECIMAL(15,3)) as Rate
			FROM [dbo].[Trident_360CoverageDetails] CD
			INNER JOIN [dbo].[Trident_360Coverage] C ON CD.CoverageID = C.CoverageID AND CD.StateCode = C.StateCode AND CD.LOBCode = C.LOBCode
			WHERE CD.StateCode = @StateCode
			--AND (CD.PrimaryClassCode = @PrimaryClassCode OR CD.PrimaryClassCode = 'All') 
			AND CD.PrimaryClassCode = (CASE WHEN EXISTS (SELECT 1 FROM [dbo].[Trident_360CoverageDetails] CD1 WHERE CD1.StateCode = @StateCode AND CD1.PrimaryClassCode = @PrimaryClassCode 
				AND CD1.LOBCode = @LOBCode AND CAST(@PolicyEffectiveDate as DATE) >= CAST(CD1.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(CD1.EndDate as DATE) OR CD1.EndDate IS NULL))
				THEN @PrimaryClassCode ELSE 'All' END)
			AND CD.LOBCode = @LOBCode 
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(CD.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(CD.EndDate as DATE) OR CD.EndDate IS NULL)
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(C.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(C.EndDate as DATE) OR C.EndDate IS NULL)
			ORDER BY C.CoverageName
		END
		ELSE
		BEGIN
			SELECT C.CoverageName,
					CAST([BaseLimit] as DECIMAL(15,3)) as Limit,
					CAST([MinimumPremium] as DECIMAL(15,3)) as Premium,
					CAST([Rate] as DECIMAL(15,3)) as Rate
			FROM [dbo].[Trident_360CoverageDetails] CD
			INNER JOIN [dbo].[Trident_360Coverage] C ON CD.CoverageID = C.CoverageID AND CD.StateCode = C.StateCode AND CD.LOBCode = C.LOBCode
			WHERE CD.StateCode = 'CW'
			--AND (CD.PrimaryClassCode = @PrimaryClassCode OR CD.PrimaryClassCode = 'All') 
			AND CD.PrimaryClassCode = (CASE WHEN EXISTS (SELECT 1 FROM [dbo].[Trident_360CoverageDetails] CD1 WHERE CD1.StateCode = 'CW' AND CD1.PrimaryClassCode = @PrimaryClassCode 
				AND CD1.LOBCode = @LOBCode AND CAST(@PolicyEffectiveDate as DATE) >= CAST(CD1.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(CD1.EndDate as DATE) OR CD1.EndDate IS NULL))
				THEN @PrimaryClassCode ELSE 'All' END)
			AND CD.LOBCode = @LOBCode 
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(CD.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(CD.EndDate as DATE) OR CD.EndDate IS NULL)
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(C.EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(C.EndDate as DATE) OR C.EndDate IS NULL)
			ORDER BY C.CoverageName
		END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetMinMaxValueForFactor]    Script Date: 7/23/2021 3:52:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
-- EXEC Trident_GetMinMaxValueForFactor 'AL',NULL,'PR','LargeRiskFactor','2021-09-09'  --0.0100	25.0000
-- EXEC Trident_GetMinMaxValueForFactor 'NH',NULL,'PR','LargeRiskFactor','2021-09-09'  --1.0000	1.0000
-- EXEC Trident_GetMinMaxValueForFactor 'AL',NULL,'PR','IRPM','2021-09-09'  --0.9000	1.0000

-- EXEC Trident_GetMinMaxValueForFactor 'NY',NULL,'PR','IRPM Factor','2021-09-09'  --0.8500	1.1500
-- EXEC Trident_GetMinMaxValueForFactor 'NY',NULL,'PR','Other Mod','2021-09-09'	--0.0100	25.0000

ALTER PROCEDURE [dbo].[Trident_GetMinMaxValueForFactor]  
(  
@StateCode NVARCHAR(50),  
@PrimaryClassCode NVARCHAR(50),  
@LOBCode NVARCHAR(50),  
@FactorType NVARCHAR(50),  
@PolicyEffectiveDate DATETIME  
)  
AS  
BEGIN     
	IF (@FactorType = 'LargeRiskFactor' AND @StateCode <> 'NY' AND @LOBCode='PR')
	BEGIN
		IF @StateCode = 'NH'
		BEGIN
			SELECT CAST(1 as DECIMAL(8,4)) as MinValue, CAST(1 as DECIMAL(8,4)) as MaxValue  
		END
		ELSE
		BEGIN
			SELECT TOP 1 MinValue, MaxValue 
			FROM Trident_LargeRiskMod   
			WHERE StateCode = @StateCode AND LOBCode=@LOBCode  
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)  
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)  
		END
	END

	ELSE IF (@FactorType = 'IRPM' AND @StateCode <> 'NY' AND @LOBCode='PR')
	BEGIN
		SELECT TOP 1 MinModValue as MinValue, MaxModValue as MaxValue
		FROM Trident_EquipBreakdownIRPM   
		WHERE StateCode = @StateCode AND LOBCode=@LOBCode  
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)  
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)  
	END   

	ELSE IF (@FactorType IN ('IRPM Factor', 'Other Mod') AND @StateCode = 'NY' AND @LOBCode='PR')
	BEGIN
		SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,4)) as MinValue, CAST(KeyValue2 as DECIMAL(15,4)) as MaxValue
		FROM [dbo].[Trident_MiscFactors] 
		WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END

	ELSE IF (@FactorType = 'IRPM' AND @LOBCode='AL')
	BEGIN
		SELECT TOP 1 IRPMMin as MinValue, IRPMMax as MaxValue
		FROM [dbo].[Trident_AutoIRPM] 
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END

	ELSE IF (@FactorType = 'OtherMod' AND @LOBCode='AL')
	BEGIN
		SELECT TOP 1 OtherModMin as MinValue, OtherModMax as MaxValue
		FROM [dbo].[Trident_AutoOtherMod]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	END
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetMinMaxValueForHazard]    Script Date: 7/9/2021 4:26:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- EXEC Trident_GetMinMaxValueForHazard 'CT','PR','Climatical Hazards', 'Hurricane', '57','2021-08-01'	--0,600
-- EXEC Trident_GetMinMaxValueForHazard 'ME','PR','Flood', 'Covered Zone', 'C','2021-08-01'		--0,300
-- EXEC Trident_GetMinMaxValueForHazard 'NH','PR','Earth Movement', 'Territory', 'Territory 1','2021-08-01'	--0,850
-- EXEC Trident_GetMinMaxValueForHazard 'AL','PR','Deficiency Construction', NULL, NULL,'2021-08-01'	--0,1000

CREATE PROCEDURE [dbo].[Trident_GetMinMaxValueForHazard]  
(  
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),  
@Category NVARCHAR(500),  
@SubCategory NVARCHAR(500), 
@Justification NVARCHAR(500),  
@PolicyEffectiveDate DATETIME  
)  
AS  
BEGIN     

		SELECT TOP 1 MinDeficiencyPoints as MinValue, MaxDeficiencyPoints as MaxValue 
		FROM Trident_HazardPoints   
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND CategoryName = @Category 
		AND (SubCategory = @SubCategory OR SubCategory IS NULL) AND (Justification = @Justification OR Justification IS NULL)
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)  
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)  
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetMiscFactor]    Script Date: 7/9/2021 4:25:49 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetMiscFactor] 'CW', 'PR', 'Tier Factor', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetMiscFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_MiscFactors] WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as MiscFactor 
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as MiscFactor 
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = 'CW' AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetMNFireSafetySurcharge]    Script Date: 7/9/2021 4:25:36 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetMNFireSafetySurcharge] 'MN', 'All', 'PR', 'MN Fire Safety Surcharge Rate', '08-01-2021', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetMNFireSafetySurcharge]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME,
@PolicyExpirationDate DATETIME
)
AS
BEGIN
	
		SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as SurchargeRate
		FROM [dbo].[Trident_MiscFactors] 
		WHERE Key1 = @LOBCode AND Key2 = @StateCode AND Key3 = @PrimaryClassCode AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		AND CAST(@PolicyExpirationDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyExpirationDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetModifiedNormalLossRate]    Script Date: 7/9/2021 4:25:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetModifiedNormalLossRate] 'CW', 'PR', 500, 1.2, 'Min Max NLR', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetModifiedNormalLossRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Deductible DECIMAL(15,4),
@NormalLossRate DECIMAL(15,4),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		DECLARE @MinVal DECIMAL(15,4), @MaxVal DECIMAL(15,4), @FinalVal DECIMAL(15,4);

		IF EXISTS (SELECT 1 FROM [dbo].[Trident_MiscFactors] WHERE Key1 = @LOBCode AND Key2 = @StateCode
		AND CAST(REPLACE(LTRIM(RTRIM(Key3)),',','') as DECIMAL(15,4)) = @Deductible AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT TOP 1 @MinVal = CAST(KeyValue1 as DECIMAL(15,3)), @MaxVal = CAST(KeyValue2 as DECIMAL(15,3))
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = @StateCode
			AND CAST(REPLACE(LTRIM(RTRIM(Key3)),',','') as DECIMAL(15,4)) = @Deductible AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 @MinVal = CAST(KeyValue1 as DECIMAL(15,3)), @MaxVal = CAST(KeyValue2 as DECIMAL(15,3))
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = 'CW' 
			AND CAST(REPLACE(LTRIM(RTRIM(Key3)),',','') as DECIMAL(15,4)) = @Deductible AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END

		IF @NormalLossRate BETWEEN ISNULL(@MinVal,0) AND ISNULL(@MaxVal,0)
		BEGIN
			SET @FinalVal = @NormalLossRate
		END
		ELSE IF @NormalLossRate < @MinVal
		BEGIN
			SET @FinalVal = @MinVal
		END
		ELSE IF @NormalLossRate > @MaxVal
		BEGIN
			SET @FinalVal = @MaxVal
		END

		SELECT @FinalVal as ModifiedNLR
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetNYBaseRates]    Script Date: 7/9/2021 4:25:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetNYBaseRates] 'NY', 'CO', 'PR', 1, 1, 'Frame', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetNYBaseRates]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@HazardGroupId	INT,
@ProtectionClassId	INT,
@ConstructionType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST([Rate] as DECIMAL(8,4)) as Rate
		FROM [dbo].[Trident_NYBaseRates]
		WHERE StateCode = @StateCode AND PrimaryClassCode = @PrimaryClassCode AND LOBCode = @LOBCode 
		AND HazardGroupId = @HazardGroupId AND ProtectionClassId = @ProtectionClassId AND ConstructionType = @ConstructionType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetNYFireInsuranceFee]    Script Date: 7/9/2021 4:24:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetNYFireInsuranceFee] 'NY', 'MU', 'PR', 'NY Fire Insurance Fee', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetNYFireInsuranceFee]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,4)) as MiscFactor 
		FROM [dbo].[Trident_MiscFactors] 
		WHERE Key1 = @LOBCode AND Key2 = @StateCode AND Key3 = @PrimaryClassCode AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO