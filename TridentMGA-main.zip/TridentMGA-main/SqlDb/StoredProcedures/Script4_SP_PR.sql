﻿USE [ParagonInsuranceHoldings]
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetPollutantCleanUpLimitFactor]    Script Date: 7/9/2021 4:20:21 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetPollutantCleanUpLimitFactor] 'AL', 'PR', 500000, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetPollutantCleanUpLimitFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Limit DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(PollutantCleanUpRate as DECIMAL(8,3)) as PollutantCleanUpRate
		FROM [dbo].[Trident_EBCoverageLimitFactors] 
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Limit = @Limit
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetRefrigerantContaminationLimitFactor]    Script Date: 7/9/2021 4:20:06 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetRefrigerantContaminationLimitFactor] 'AL', 'PR', 500000, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetRefrigerantContaminationLimitFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Limit DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(EBRefrigerantRate as DECIMAL(8,3)) as EBRefrigerantRate
		FROM [dbo].[Trident_EBCoverageLimitFactors] 
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Limit = @Limit
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetSpoilageRate]    Script Date: 7/9/2021 4:19:51 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetSpoilageRate] 'AL', 'PR', 500, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetSpoilageRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Deductible DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(SpoilageRate as DECIMAL(8,3)) as SpoilageRate
		FROM [dbo].[Trident_360Spoilage]
		WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND SpoilageDeductible = @Deductible 
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetSpoilageType1LimitFactor]    Script Date: 7/9/2021 4:19:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetSpoilageType1LimitFactor] 'AL', 'PR', 500000, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetSpoilageType1LimitFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Limit DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(EBSpoilageType1Rate as DECIMAL(8,3)) as SpoilageType1Rate
		FROM [dbo].[Trident_EBCoverageLimitFactors] 
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Limit = @Limit
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetSpoilageType2LimitFactor]    Script Date: 7/9/2021 4:19:24 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetSpoilageType2LimitFactor] 'AL', 'PR', 500000, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetSpoilageType2LimitFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Limit DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(EBSpoilageType2Rate as DECIMAL(8,3)) as SpoilageType2Rate
		FROM [dbo].[Trident_EBCoverageLimitFactors] 
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Limit = @Limit
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetSpoilageTypeLimitFactor]    Script Date: 7/9/2021 4:19:10 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetSpoilageTypeLimitFactor] 'AL', 'PR', 'Type1', 1000000, '08-01-2021'
-- EXEC [dbo].[Trident_GetSpoilageTypeLimitFactor] 'AL', 'PR', 'Type2', 1000000, '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetSpoilageTypeLimitFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Type NVARCHAR(50),
@Limit DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CASE @Type WHEN 'Type1' THEN CAST(EBSpoilageType1Rate as DECIMAL(8,3))
						  WHEN 'Type2' THEN CAST(EBSpoilageType2Rate as DECIMAL(8,3)) END as SpoilageTypeRate
		FROM [dbo].[Trident_EBCoverageLimitFactors] 
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Limit = @Limit
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetStateList]    Script Date: 7/9/2021 4:18:17 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetStateList] '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetStateList]
(
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT Code as StateCode, Name as StateName 
		FROM Trident_MstState
		WHERE  CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) 
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetTeeToGreenFactor]    Script Date: 7/9/2021 4:18:04 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetTeeToGreenFactor] 'CW', 'PR', 'Tee to Green Factor', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetTeeToGreenFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_MiscFactors] WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as X1value, CAST(KeyValue2 as DECIMAL(15,3)) as X2value
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as X1value, CAST(KeyValue2 as DECIMAL(15,3)) as X2value
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = 'CW' AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetTerrorismFactor]    Script Date: 7/9/2021 4:17:51 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetTerrorismFactor] 'AL', 'PR', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetTerrorismFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(TerrorismFactor as DECIMAL(8,3)) as TerrorismFactor
		FROM [dbo].[Trident_TerrorismFactors]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetValuation]    Script Date: 7/9/2021 4:17:25 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetValuation] 'AL', 'PR', 'ACV', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetValuation]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Valuation NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(Factor as DECIMAL(8,2)) as Factor
		FROM [dbo].[Trident_ValuationFactors]
		WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND ValuationId = @Valuation 
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
	
END
GO