﻿USE [ParagonInsuranceHoldings]
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetOCPRate]    Script Date: 7/9/2021 3:28:33 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetOCPRate] 'NY', 'OCP', 100000, 100000, 'Work Permit', '08-01-2021', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetOCPRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Limit DECIMAL(15,4),
@AggrLimit DECIMAL(15,4),
@Description NVARCHAR(50),
@PolicyEffectiveDate DATETIME,
@PolicyExpirationDate DATETIME
)
AS
BEGIN
	
		SELECT CAST(Premium as DECIMAL(8,3)) as Premium
		FROM [dbo].[Trident_OCPLimits]
		WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND Limit = @Limit AND AggregateLimit = @AggrLimit AND Description = @Description
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		AND ((@PolicyExpirationDate IS NULL) OR (CAST(@PolicyExpirationDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)))
	
END
GO


/****** Object:  StoredProcedure [dbo].[Trident_GetOCPMiscFactor]    Script Date: 7/26/2021 5:57:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetOCPMiscFactor] 'NY', 'OCP', 'Tier Factor', '08-01-2021', '08-01-2021'
-- EXEC [dbo].[Trident_GetOCPMiscFactor] 'NY', 'OCP', 'IRPM Factor', '08-01-2021', '08-01-2021'
-- EXEC [dbo].[Trident_GetOCPMiscFactor] 'NY', 'OCP', 'Other Mod', '08-01-2021', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetOCPMiscFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@FactorType NVARCHAR(50),
@PolicyEffectiveDate DATETIME,
@PolicyExpirationDate DATETIME
)
AS
BEGIN
	
			SELECT TOP 1 CAST(KeyValue1 as DECIMAL(15,3)) as MiscFactor 
			FROM [dbo].[Trident_MiscFactors] 
			WHERE Key1 = @LOBCode AND Key2 = @StateCode AND FactorType = @FactorType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
			AND ((@PolicyExpirationDate IS NULL) OR (CAST(@PolicyExpirationDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)))
	
END
GO