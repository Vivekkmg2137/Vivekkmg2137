﻿USE [ParagonInsuranceHoldings]
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoBaseRate]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoBaseRate] 'MO', 'MU', 'AL', 'Buses', 'Rural', '08-01-2021'	--640	NULL	NULL
-- EXEC [dbo].[Trident_GetAutoBaseRate] 'CT', 'CO', 'AL', 'Buses', 'Rural', '08-01-2021'	--594	100	900
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoBaseRate]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@LocationType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(BaseRate as DECIMAL(8,3)) as BaseRate, 
					 CAST(BaseRateMin as DECIMAL(8,3)) as BaseRateMin, CAST(BaseRateMax as DECIMAL(8,3)) as BaseRateMax
		FROM [dbo].[Trident_AutoBaseRates]
		WHERE StateCode = @StateCode AND PrimaryClassCode = @PrimaryClassCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoDeductibleFactor]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoDeductibleFactor] 'AL', 'AL', 'Deductible', 500, NULL, '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoDeductibleFactor] 'MS', 'AL', 'SIR', 50000, NULL, '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoDeductibleFactor] 'AL', 'APD', NULL, 100, 'Collision', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoDeductibleFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@DedSIRType NVARCHAR(50),
@Deductible DECIMAL(15,4),
@Coverage NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF (@LOBCode = 'AL')
		BEGIN
			SELECT CAST(DeductibleFactor as DECIMAL(8,3)) as Factor
			FROM [dbo].[Trident_AutoALDeductibleFactors]
			WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND Deductible = @Deductible AND DeductibleSIR = @DedSIRType
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE IF (@LOBCode = 'APD')
		BEGIN
			SELECT CAST(DeductibleFactor as DECIMAL(8,3)) as Factor
			FROM [dbo].[Trident_AutoAPDDeductibleFactors]
			WHERE LOBCode = @LOBCode AND StateCode = @StateCode AND Coverage = @Coverage AND Deductible = @Deductible
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoHiredAndNonOwnedPremium]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoHiredAndNonOwnedPremium] 'AL', 'All', 'AL', 'Hired and Non Owned', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoHiredAndNonOwnedPremium]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(Premium as DECIMAL(8,3)) as Premium
		FROM [dbo].[Trident_AutoAdditionalCoverages]
		WHERE StateCode = @StateCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') AND LOBCode = @LOBCode AND Coverage = @Coverage AND RatingBasis = 'Flat charge'
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoLimitFactor]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoLimitFactor] 'AL', 'AL', 'CSL', 100000, '08-01-2021'	--0.56	0.30	0.90
-- EXEC [dbo].[Trident_GetAutoLimitFactor] 'CO', 'AL', 'CSL', 300000, '08-01-2021'	--0.81	0.35	1.00
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoLimitFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@LimitType NVARCHAR(50),
@Limit DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(DefaultFactor as DECIMAL(8,3)) as DefaultRate, 
					 CAST(RateMin as DECIMAL(8,3)) as RateMin, CAST(RateMax as DECIMAL(8,3)) as RateMax
		FROM [dbo].[Trident_AutoLimitFactors]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LimitType = @LimitType AND Limit = @Limit
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoMedRate]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoMedRate] 'AL', 'AL', 'Medical Payments', 'Rural', 'Buses', '500', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoMedRate] 'AL', 'AL', 'Medical Payments', 'Rural', 'Buses', 'No coverage', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoMedRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@LocationType NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@Limit NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		IF (ISNUMERIC(@Limit)=1)
		BEGIN
			SELECT TOP 1 CAST(ISNULL(Rate,0) as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoMedicalPayments]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND Limit = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(ISNULL(Rate,0) as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoMedicalPayments]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND LimitDisplayText = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END

END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoMinimumPremium]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoMinimumPremium] 'AL', 'All', 'AL', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoMinimumPremium]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(500),
@LOBCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(MinPremium as DECIMAL(8,3)) as Premium
		FROM [dbo].[Trident_AutoMinimumPremium]
		WHERE StateCode = @StateCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') AND LOBCode = @LOBCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoNYFee]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
--EXEC [dbo].[Trident_GetAutoNYFee] 'NY', 'AL', 'NY Motor Vehicle Law Enforcement Fee', 'NB', '7398', '08-01-2021'	--10
--EXEC [dbo].[Trident_GetAutoNYFee] 'NY', 'AL', 'NY Motor Vehicle Law Enforcement Fee', 'NB', '7911', '08-01-2021'	--NULL
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoNYFee]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@TransactionCode NVARCHAR(50),
@ClassCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(AutoFee as DECIMAL(8,3)) as AutoFee
		FROM [dbo].[Trident_AutoNYFees]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND TransactionCode = @TransactionCode
		AND ClassCode = @ClassCode
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoOptionalCoveragePremium]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoOptionalCoveragePremium] 'NY', 'All', 'AL', 'Mutual Aid - CA 20 40', 'Flat charge', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoOptionalCoveragePremium] 'AL', 'All', 'AL', 'Lessor - Additional Insured And Loss Payee - CA 20 01', 'Flat charge', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoOptionalCoveragePremium] 'CW', 'All', 'APD', 'Other', 'Flat charge', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoOptionalCoveragePremium]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@RatingBasis NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF EXISTS (SELECT 1 FROM [dbo].[Trident_AutoOptionalCoverages] 
		WHERE StateCode = @StateCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') AND LOBCode = @LOBCode AND Coverage = @Coverage AND RatingBasis = @RatingBasis
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
			SELECT TOP 1 CASE WHEN ISNUMERIC(Premium)=1 THEN CAST(Premium as DECIMAL(8,3)) ELSE NULL END as Premium, ReturnMethod
			FROM [dbo].[Trident_AutoOptionalCoverages]
			WHERE StateCode = @StateCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') AND LOBCode = @LOBCode AND Coverage = @Coverage AND RatingBasis = @RatingBasis
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CASE WHEN ISNUMERIC(Premium)=1 THEN CAST(Premium as DECIMAL(8,3)) ELSE NULL END as Premium, ReturnMethod
			FROM [dbo].[Trident_AutoOptionalCoverages]
			WHERE StateCode = 'CW' AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'All') AND LOBCode = @LOBCode AND Coverage = @Coverage AND RatingBasis = @RatingBasis
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoOtherMod]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Mamta
-- Create date: 07-29-2021
--EXEC [dbo].[Trident_GetAutoOtherMod] 'GA','AL', '2021-11-01' ---1.0000
-- EXEC [dbo].[Trident_GetAutoOtherMod] 'MO','APD', '2021-11-01' ---1.0000
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoOtherMod]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		SELECT TOP 1 OtherModDefault  as OtherModDefault
				FROM [dbo].[Trident_AutoOtherMod]
				WHERE StateCode = @StateCode --AND ClassCode = @ClassCode 
				AND LOBCode = @LOBCode 
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoPIPRate]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'MI', 'AL', 'Personal Injury Protection', 'Rural', 'Buses', NULL, 'Unlimited', '08-01-2021'  --n/a	--18
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'MI', 'AL', 'Personal Injury Protection', 'Rural', 'Buses', NULL, '50000', '08-01-2021'	--n/a	--11
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'MI', 'AL', 'Excess Attendant Care', 'Rural', 'Buses', '250000', '1000', '08-01-2021'  --n/a	--13
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'MI', 'AL', 'Excess Attendant Care', 'Rural', 'Buses', '500000', '1000', '08-01-2021'	--n/a	--16
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'PA', 'AL', 'Basic FPB', 'Rural', 'Buses', NULL, 'Included', '08-01-2021'  --n/a	--20
-- EXEC [dbo].[Trident_GetAutoPIPRate] 'PA', 'AL', 'Basic FPB', 'Metro', 'Buses', NULL, 'Included', '08-01-2021'	--n/a	--25
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoPIPRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@LocationType NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@DependentCoverageLimit NVARCHAR(50),
@Limit NVARCHAR(500),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		DECLARE @DependentCoverage NVARCHAR(50);
		IF (ISNUMERIC(@Limit)=1)
		BEGIN
			SELECT TOP 1 @DependentCoverage = DependentCoverage
			FROM [dbo].[Trident_AutoPIPCoverages]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND Limit = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)

			IF (@DependentCoverage = 'n/a')
			BEGIN
				SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
				FROM [dbo].[Trident_AutoPIPCoverages]
				WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
				AND (Coverage = @Coverage AND Limit = @Limit)
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
			END
		END
		ELSE
		BEGIN
			SELECT TOP 1 @DependentCoverage = DependentCoverage
			FROM [dbo].[Trident_AutoPIPCoverages]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND LimitDisplayText = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)

			IF (@DependentCoverage = 'n/a')
			BEGIN
				SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
				FROM [dbo].[Trident_AutoPIPCoverages]
				WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
				AND (Coverage = @Coverage AND LimitDisplayText = @Limit)
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
			END
		END
		
		IF (@DependentCoverage <> 'n/a')
		BEGIN	
			IF (ISNUMERIC(@DependentCoverageLimit)=1)
			BEGIN
				SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
				FROM [dbo].[Trident_AutoPIPCoverages]
				WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
				AND (Coverage = @DependentCoverage AND Limit = @DependentCoverageLimit)
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
			END
			ELSE
			BEGIN
				SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
				FROM [dbo].[Trident_AutoPIPCoverages]
				WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
				AND (Coverage = @DependentCoverage AND LimitDisplayText = @DependentCoverageLimit)
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
			END
		END

END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoPopulationFactor]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoPopulationFactor] 'AL', 'CO', 'AL', 15000, '08-01-2021'	--1.050
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoPopulationFactor]
(
@StateCode NVARCHAR(50),
@PrimaryClassCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Population DECIMAL(15,4),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(PopulationFactor as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_AutoPopulationFactors]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND (PrimaryClassCode = @PrimaryClassCode OR PrimaryClassCode = 'ALL')
		AND @Population BETWEEN PopulationRangeMin AND PopulationRangeMax
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoRatingGroup]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Mamta
-- Create date: 07-27-2021
-- EXEC [dbo].[Trident_GetAutoRatingGroup] 'NY','AL', 'Private Passenger','7398', '2021-11-01'	---Non Emergency
-- EXEC [dbo].[Trident_GetAutoRatingGroup] 'CW','AL', 'All Other Bus','6584' , '2021-09-01'--Buses
-- EXEC [dbo].[Trident_GetAutoRatingGroup] 'CW','APD', 'Service or Utility Trailers non-fleet','691-990' , '2021-11-01'--Trailers
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoRatingGroup]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@AutomobileType NVARCHAR(50),
@ClassCode NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		IF EXISTS (Select 1  FROM [dbo].[Trident_AutoClassCodes] WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND AutomobileType = @AutomobileType AND ClassCode = @ClassCode
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL))
		BEGIN
				SELECT TOP 1 RatingGroup  as RatingGroup
				FROM [dbo].[Trident_AutoClassCodes]
				WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND AutomobileType = @AutomobileType AND ClassCode = @ClassCode
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 RatingGroup  as RatingGroup
				FROM [dbo].[Trident_AutoClassCodes]
				WHERE StateCode = 'CW' AND LOBCode = @LOBCode AND AutomobileType = @AutomobileType AND ClassCode = @ClassCode
				AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE) AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoSurchargeRate]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
--EXEC [dbo].[Trident_GetAutoSurchargeRate] 'MI', 'AL', 'MI MCCA Assessment', 'n/a', 'All', '50000', 'n/a', 'n/a', '08-01-2021'	--NULL
--EXEC [dbo].[Trident_GetAutoSurchargeRate] 'MI', 'AL', 'MI MCCA Assessment', 'n/a', 'All', 'Unlimited', 'n/a', 'per vehicle with PIP', '08-01-2021'	--86
--EXEC [dbo].[Trident_GetAutoSurchargeRate] 'NC', 'AL', 'NC Auto Loss Recoupment Surcharge', 'n/a', 'n/a', 'n/a', 'n/a', 'Percentage of AL premium', '08-01-2021'	--5.920
--EXEC [dbo].[Trident_GetAutoSurchargeRate] 'MN', 'APD', 'MN Fire Safety Surcharge', 'n/a', 'n/a', 'n/a', 'n/a', 'Percentage of APD Comprehensiverehensive premium', '08-01-2021'	--0.500
--EXEC [dbo].[Trident_GetAutoSurchargeRate] 'MN', 'APD', 'MN Automobile Theft Prevention Surcharge', 'n/a', '7911', 'n/a', 'NB', 'n/a', '08-01-2021'	--NULL
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoSurchargeRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Surcharge NVARCHAR(500),
@Coverage NVARCHAR(500),
@ClassCode NVARCHAR(50),
@PIPLimit NVARCHAR(50),
@TransactionCode NVARCHAR(50),
@RatingBasis NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		IF ISNUMERIC(@PIPLimit) = 1
		BEGIN
			SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoSurcharges]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND (ClassCode = @ClassCode OR ClassCode = 'ALL') AND Surcharge = @Surcharge AND Coverage = @Coverage
			AND PIPLimit = @PIPLimit AND TransactionCode = @TransactionCode AND RatingBasis = @RatingBasis
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoSurcharges]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND (ClassCode = @ClassCode OR ClassCode = 'ALL') AND Surcharge = @Surcharge AND Coverage = @Coverage
			AND PIPLimitDisplayText = @PIPLimit AND TransactionCode = @TransactionCode AND RatingBasis = @RatingBasis
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoTierFactor]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoTierFactor] 'CT', 'AL', 'Preferred', '08-01-2021'	--0.8500
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoTierFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@TierType NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(Factor as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_AutoTierFactors]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND TierType = @TierType
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoUIMRate]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoUIMRate] 'CT', 'AL', 'Underinsured', 'Rural', 'Buses', '50000', '08-01-2021'		--18
-- EXEC [dbo].[Trident_GetAutoUIMRate] 'CT', 'AL', 'Underinsured Conversion', 'Rural', 'All', 'Yes', '08-01-2021'--1
-- EXEC [dbo].[Trident_GetAutoUIMRate] 'IN', 'AL', 'Underinsured', 'Rural', 'Buses', 'No coverage', '08-01-2021'	--1
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoUIMRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@LocationType NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@Limit NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		IF (ISNUMERIC(@Limit)=1)
		BEGIN
			SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoUIMCoverages]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND Limit = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(Rate as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoUIMCoverages]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND LimitDisplayText = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoUMRate]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoUMRate] 'MS', 'AL', 'Uninsured', 'Rural', 'Buses', 1, '75000', '08-01-2021'
-- EXEC [dbo].[Trident_GetAutoUMRate] 'MS', 'AL', 'Uninsured', 'Rural', 'Buses', 1, 'No coverage', '08-01-2021'
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoUMRate]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Coverage NVARCHAR(500),
@LocationType NVARCHAR(50),
@RatingGroup NVARCHAR(50),
@UMUIMStacking BIT,
@Limit NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
	
		IF (ISNUMERIC(@Limit)=1)
		BEGIN
			SELECT TOP 1 CAST(ISNULL(Rate,0) as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoUMCoverages]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND UMUIMStacking = @UMUIMStacking AND Limit = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		ELSE
		BEGIN
			SELECT TOP 1 CAST(ISNULL(Rate,0) as DECIMAL(8,3)) as Rate
			FROM [dbo].[Trident_AutoUMCoverages]
			WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Coverage = @Coverage AND LocationType = @LocationType AND (RatingGroup = @RatingGroup OR RatingGroup = 'ALL')
			AND UMUIMStacking = @UMUIMStacking AND LimitDisplayText = @Limit
			AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
			AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		END
		
END
GO
/****** Object:  StoredProcedure [dbo].[Trident_GetAutoValuationFactor]    Script Date: 8/5/2021 2:44:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Surbhi Verma
-- Create date: 05-31-2021
-- EXEC [dbo].[Trident_GetAutoValuationFactor] 'AL', 'APD', 'Stated Amount', '08-01-2021'	--1.100
-- =============================================

CREATE PROCEDURE [dbo].[Trident_GetAutoValuationFactor]
(
@StateCode NVARCHAR(50),
@LOBCode NVARCHAR(50),
@Valuation NVARCHAR(50),
@PolicyEffectiveDate DATETIME
)
AS
BEGIN
		
		SELECT TOP 1 CAST(Factor as DECIMAL(8,3)) as Factor
		FROM [dbo].[Trident_AutoValuationFactors]
		WHERE StateCode = @StateCode AND LOBCode = @LOBCode AND Valuation = @Valuation
		AND CAST(@PolicyEffectiveDate as DATE) >= CAST(EffectiveDate as DATE)
		AND (CAST(@PolicyEffectiveDate as DATE) <= CAST(EndDate as DATE) OR EndDate IS NULL)
		
END
GO
