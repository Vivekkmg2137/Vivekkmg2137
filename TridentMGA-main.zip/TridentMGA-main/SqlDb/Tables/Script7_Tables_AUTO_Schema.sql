﻿USE [ParagonInsuranceHoldings]
GO
/****** Object:  Table [dbo].[Trident_AutoAdditionalCoverages]    Script Date: 7/2/2021 10:38:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoAdditionalCoverages](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[PrimaryClassCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Coverage] [nvarchar](500) NULL,
	[DefaultIncluded] [nvarchar](50) NULL,
	[Premium] [decimal](15, 4) NULL,
	[RatingBasis] [nvarchar](50) NULL,
	[ReturnPremiumMethod] [nvarchar](50) NULL,
	[CoverageLevel] [nvarchar](50) NULL,
	[IsIRPM] [bit] NULL,
	[IsOtherModApplied] [bit] NULL,
	[IsTierRatingApplied] [bit] NULL,
	[IsIncludedInExcessExposure] [bit] NULL,
	[IsTRIAApplied] [bit] NULL,
	[IsAppendToLOBMinPrem] [bit] NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALAdditionalCoverages] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoALDeductibleFactors]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoALDeductibleFactors](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[DeductibleSIR] [nvarchar](50) NULL,
	[DeductibleDisplayText] [nvarchar](50) NULL,
	[Deductible] [decimal](15, 4) NULL,
	[DeductibleFactor] [decimal](8, 4) NULL,
	[IsDefault] [bit] NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALDeductibleFactors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoAPDDeductibleFactors]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoAPDDeductibleFactors](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Coverage] [nvarchar](50) NULL,
	[DeductibleDisplayText] [nvarchar](50) NULL,
	[Deductible] [decimal](15, 4) NULL,
	[DeductibleFactor] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_APDDeductibleFactors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoBaseRates]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoBaseRates](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[PrimaryClassCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[RatingGroup] [nvarchar](50) NULL,
	[LocationType] [nvarchar](50) NULL,
	[BaseRate] [decimal](15, 4) NULL,
	[BaseRateMinDisplayText] [nvarchar](50) NULL,
	[BaseRateMin] [decimal](15, 4) NULL,
	[BaseRateMaxDisplayText] [nvarchar](50) NULL,
	[BaseRateMax] [decimal](15, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALBaseRates] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoClassCodes]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoClassCodes](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[AutomobileType] [nvarchar](500) NULL,
	[ClassCode] [nvarchar](50) NULL,
	[RatingGroup] [nvarchar](50) NULL,
	[Capacity] [nvarchar](50) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_AutoClassCodes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoCompany]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoCompany](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[PrimaryClassCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Company] [nvarchar](500) NULL,
	[IsDefaultCompany] [bit] NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_Company] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoIRPM]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoIRPM](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[IRPMMin] [decimal](8, 4) NULL,
	[IRPMMax] [decimal](8, 4) NULL,
	[DefaultIRPM] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALIRPM] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoLimitFactors]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoLimitFactors](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[LimitType] [nvarchar](50) NULL,
	[IsDefaultLimitType] [bit] NULL,
	[LimitDisplayText] [nvarchar](50) NULL,
	[Limit] [decimal](15, 4) NULL,
	[IsDefaultLimit] [bit] NULL,
	[DefaultFactor] [decimal](8, 4) NULL,
	[RateMinDisplayText] [nvarchar](50) NULL,
	[RateMin] [decimal](8, 4) NULL,
	[RateMaxDisplayText] [nvarchar](50) NULL,
	[RateMax] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_AutoLimitFactors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoMedicalPayments]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoMedicalPayments](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Coverage] [nvarchar](500) NULL,
	[LocationType] [nvarchar](50) NULL,
	[RatingGroup] [nvarchar](50) NULL,
	[LimitDisplayText] [nvarchar](50) NULL,
	[Limit] [decimal](15, 4) NULL,
	[IsDefault] [bit] NULL,
	[Rate] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALMedicalPayments] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoMinimumPremium]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoMinimumPremium](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[PrimaryClassCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[MinPremium] [decimal](15, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_AutoMinimumPremium] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoNYFees]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoNYFees](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Coverage] [nvarchar](500) NULL,
	[TransactionCode] [nvarchar](50) NULL,
	[ClassCode] [nvarchar](50) NULL,
	[AutoFee] [decimal](15, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_AutoFees] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoOptionalCoverages]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoOptionalCoverages](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[PrimaryClassCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Coverage] [nvarchar](500) NULL,
	[IsDefaultToIncludeCoverage] [bit] NULL,
	[Description] [nvarchar](500) NULL,
	[LimitIndicator] [nvarchar](50) NULL,
	[DeductibleIndicator] [nvarchar](50) NULL,
	[RatingBasis] [nvarchar](50) NULL,
	[RateIndicator] [nvarchar](50) NULL,
	[ReturnMethod] [nvarchar](50) NULL,
	[Premium] [nvarchar](50) NULL,
	[MinimumPremium] [decimal](15, 4) NULL,
	[IsModFactorsApplied] [bit] NULL,
	[IsTierRatingApplied] [bit] NULL,
	[IsIncludedInExcessExposure] [bit] NULL,
	[IsTRIAApplied] [bit] NULL,
	[IsIncludedInLOBMinPremium] [bit] NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALOptionalCoverages] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoOtherMod]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoOtherMod](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[OtherModMin] [decimal](8, 4) NULL,
	[OtherModMax] [decimal](8, 4) NULL,
	[OtherModDefault] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALOtherMod] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoPIPCoverages]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoPIPCoverages](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[RatingGroup] [nvarchar](50) NULL,
	[LocationType] [nvarchar](50) NULL,
	[Coverage] [nvarchar](500) NULL,
	[DependentCoverage] [nvarchar](50) NULL,
	[DependentCoverageLimitDisplayText] [nvarchar](50) NULL,
	[DependentCoverageLimit] [decimal](15, 4) NULL,
	[LimitDisplayText] [nvarchar](500) NULL,
	[Limit] [decimal](15, 4) NULL,
	[IsDefault] [bit] NULL,
	[Rate] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_PIPCoverages] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoPopulationFactors]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoPopulationFactors](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[PrimaryClassCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[PopulationRangeMinDisplayText] [nvarchar](50) NULL,
	[PopulationRangeMin] [decimal](15, 4) NULL,
	[PopulationRangeMaxDisplayText] [nvarchar](50) NULL,
	[PopulationRangeMax] [decimal](15, 4) NULL,
	[PopulationFactor] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_PopulationFactors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoRetention]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoRetention](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Item] [nvarchar](50) NULL,
	[ItemValue] [nvarchar](50) NULL,
	[IsDefault] [bit] NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALRetention] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoSurcharges]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoSurcharges](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Surcharge] [nvarchar](500) NULL,
	[Coverage] [nvarchar](500) NULL,
	[ClassCode] [nvarchar](50) NULL,
	[PIPLimitDisplayText] [nvarchar](50) NULL,
	[PIPLimit] [decimal](15, 4) NULL,
	[Rate] [decimal](8, 4) NULL,
	[RatingBasis] [nvarchar](50) NULL,
	[TransactionCode] [nvarchar](50) NULL,
	[IsModFactorsApplied] [bit] NULL,
	[IsTierRatingApplied] [bit] NULL,
	[IsIncludedInExcessExposure] [bit] NULL,
	[IsTRIAApplied] [bit] NULL,
	[IsIncludedInLOBMinPremium] [bit] NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALSurcharges] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoTierFactors]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoTierFactors](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[TierType] [nvarchar](50) NULL,
	[Factor] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_ALTierFactors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoUIMCoverages]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoUIMCoverages](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[LocationType] [nvarchar](50) NULL,
	[RatingGroup] [nvarchar](50) NULL,
	[Coverage] [nvarchar](500) NULL,
	[LimitDisplayText] [nvarchar](50) NULL,
	[Limit] [decimal](15, 4) NULL,
	[IsDefault] [bit] NULL,
	[Rate] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_UIMCoverages] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoUMCoverages]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoUMCoverages](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Coverage] [nvarchar](500) NULL,
	[LocationType] [nvarchar](50) NULL,
	[RatingGroup] [nvarchar](50) NULL,
	[UMUIMStacking] [bit] NULL,
	[LimitDisplayText] [nvarchar](50) NULL,
	[Limit] [decimal](15, 4) NULL,
	[IsDefault] [bit] NULL,
	[Rate] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_UMCoverages] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoUMDeductible]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoUMDeductible](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[LocationType] [nvarchar](50) NULL,
	[RatingGroup] [nvarchar](50) NULL,
	[Coverage] [nvarchar](500) NULL,
	[LimitDisplayText] [nvarchar](50) NULL,
	[Limit] [decimal](15, 4) NULL,
	[IsDefault] [bit] NULL,
	[Rate] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_UMDeductible] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Trident_AutoValuationFactors]    Script Date: 7/2/2021 10:38:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Trident_AutoValuationFactors](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StateCode] [nvarchar](50) NULL,
	[LOBCode] [nvarchar](50) NULL,
	[Valuation] [nvarchar](50) NULL,
	[Factor] [decimal](8, 4) NULL,
	[EffectiveDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
 CONSTRAINT [PK_Trident_APDValuationFactors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Trident_AutoAdditionalCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALAdditionalCoverages_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoAdditionalCoverages] CHECK CONSTRAINT [FK_Trident_ALAdditionalCoverages_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoAdditionalCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALAdditionalCoverages_Trident_MstPrimaryClass] FOREIGN KEY([PrimaryClassCode])
REFERENCES [dbo].[Trident_MstPrimaryClass] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoAdditionalCoverages] CHECK CONSTRAINT [FK_Trident_ALAdditionalCoverages_Trident_MstPrimaryClass]
GO
ALTER TABLE [dbo].[Trident_AutoAdditionalCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALAdditionalCoverages_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoAdditionalCoverages] CHECK CONSTRAINT [FK_Trident_ALAdditionalCoverages_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoALDeductibleFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALDeductible_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoALDeductibleFactors] CHECK CONSTRAINT [FK_Trident_ALDeductible_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoALDeductibleFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALDeductible_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoALDeductibleFactors] CHECK CONSTRAINT [FK_Trident_ALDeductible_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoAPDDeductibleFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_APDDeductible_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoAPDDeductibleFactors] CHECK CONSTRAINT [FK_Trident_APDDeductible_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoAPDDeductibleFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_APDDeductible_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoAPDDeductibleFactors] CHECK CONSTRAINT [FK_Trident_APDDeductible_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoBaseRates]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALBaseRates_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoBaseRates] CHECK CONSTRAINT [FK_Trident_ALBaseRates_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoBaseRates]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALBaseRates_Trident_MstPrimaryClass] FOREIGN KEY([PrimaryClassCode])
REFERENCES [dbo].[Trident_MstPrimaryClass] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoBaseRates] CHECK CONSTRAINT [FK_Trident_ALBaseRates_Trident_MstPrimaryClass]
GO
ALTER TABLE [dbo].[Trident_AutoBaseRates]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALBaseRates_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoBaseRates] CHECK CONSTRAINT [FK_Trident_ALBaseRates_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoClassCodes]  WITH CHECK ADD  CONSTRAINT [FK_Trident_AutoClassCodes_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoClassCodes] CHECK CONSTRAINT [FK_Trident_AutoClassCodes_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoClassCodes]  WITH CHECK ADD  CONSTRAINT [FK_Trident_AutoClassCodes_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoClassCodes] CHECK CONSTRAINT [FK_Trident_AutoClassCodes_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoCompany]  WITH CHECK ADD  CONSTRAINT [FK_Trident_Company_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoCompany] CHECK CONSTRAINT [FK_Trident_Company_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoCompany]  WITH CHECK ADD  CONSTRAINT [FK_Trident_Company_Trident_MstPrimaryClass] FOREIGN KEY([PrimaryClassCode])
REFERENCES [dbo].[Trident_MstPrimaryClass] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoCompany] CHECK CONSTRAINT [FK_Trident_Company_Trident_MstPrimaryClass]
GO
ALTER TABLE [dbo].[Trident_AutoCompany]  WITH CHECK ADD  CONSTRAINT [FK_Trident_Company_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoCompany] CHECK CONSTRAINT [FK_Trident_Company_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoIRPM]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALIRPM_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoIRPM] CHECK CONSTRAINT [FK_Trident_ALIRPM_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoIRPM]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALIRPM_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoIRPM] CHECK CONSTRAINT [FK_Trident_ALIRPM_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoLimitFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_AutoLimitFactor_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoLimitFactors] CHECK CONSTRAINT [FK_Trident_AutoLimitFactor_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoLimitFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_AutoLimitFactor_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoLimitFactors] CHECK CONSTRAINT [FK_Trident_AutoLimitFactor_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoMedicalPayments]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALMedicalPayments_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoMedicalPayments] CHECK CONSTRAINT [FK_Trident_ALMedicalPayments_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoMedicalPayments]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALMedicalPayments_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoMedicalPayments] CHECK CONSTRAINT [FK_Trident_ALMedicalPayments_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoMinimumPremium]  WITH CHECK ADD  CONSTRAINT [FK_Trident_AutoMinimumPremium_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoMinimumPremium] CHECK CONSTRAINT [FK_Trident_AutoMinimumPremium_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoMinimumPremium]  WITH CHECK ADD  CONSTRAINT [FK_Trident_AutoMinimumPremium_Trident_MstPrimaryClass] FOREIGN KEY([PrimaryClassCode])
REFERENCES [dbo].[Trident_MstPrimaryClass] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoMinimumPremium] CHECK CONSTRAINT [FK_Trident_AutoMinimumPremium_Trident_MstPrimaryClass]
GO
ALTER TABLE [dbo].[Trident_AutoMinimumPremium]  WITH CHECK ADD  CONSTRAINT [FK_Trident_AutoMinimumPremium_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoMinimumPremium] CHECK CONSTRAINT [FK_Trident_AutoMinimumPremium_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoNYFees]  WITH CHECK ADD  CONSTRAINT [FK_Trident_AutoFees_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoNYFees] CHECK CONSTRAINT [FK_Trident_AutoFees_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoNYFees]  WITH CHECK ADD  CONSTRAINT [FK_Trident_AutoFees_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoNYFees] CHECK CONSTRAINT [FK_Trident_AutoFees_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoOptionalCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALOptionalCoverages_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoOptionalCoverages] CHECK CONSTRAINT [FK_Trident_ALOptionalCoverages_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoOptionalCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALOptionalCoverages_Trident_MstPrimaryClass] FOREIGN KEY([PrimaryClassCode])
REFERENCES [dbo].[Trident_MstPrimaryClass] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoOptionalCoverages] CHECK CONSTRAINT [FK_Trident_ALOptionalCoverages_Trident_MstPrimaryClass]
GO
ALTER TABLE [dbo].[Trident_AutoOptionalCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALOptionalCoverages_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoOptionalCoverages] CHECK CONSTRAINT [FK_Trident_ALOptionalCoverages_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoOtherMod]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALOtherMod_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoOtherMod] CHECK CONSTRAINT [FK_Trident_ALOtherMod_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoOtherMod]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALOtherMod_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoOtherMod] CHECK CONSTRAINT [FK_Trident_ALOtherMod_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoPIPCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_PIPCoverage_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoPIPCoverages] CHECK CONSTRAINT [FK_Trident_PIPCoverage_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoPIPCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_PIPCoverage_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoPIPCoverages] CHECK CONSTRAINT [FK_Trident_PIPCoverage_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoPopulationFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_PopulationFactors_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoPopulationFactors] CHECK CONSTRAINT [FK_Trident_PopulationFactors_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoPopulationFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_PopulationFactors_Trident_MstPrimaryClass] FOREIGN KEY([PrimaryClassCode])
REFERENCES [dbo].[Trident_MstPrimaryClass] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoPopulationFactors] CHECK CONSTRAINT [FK_Trident_PopulationFactors_Trident_MstPrimaryClass]
GO
ALTER TABLE [dbo].[Trident_AutoPopulationFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_PopulationFactors_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoPopulationFactors] CHECK CONSTRAINT [FK_Trident_PopulationFactors_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoRetention]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALRetention_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoRetention] CHECK CONSTRAINT [FK_Trident_ALRetention_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoRetention]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALRetention_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoRetention] CHECK CONSTRAINT [FK_Trident_ALRetention_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoSurcharges]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALSurcharges_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoSurcharges] CHECK CONSTRAINT [FK_Trident_ALSurcharges_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoSurcharges]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALSurcharges_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoSurcharges] CHECK CONSTRAINT [FK_Trident_ALSurcharges_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoTierFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALTierFactor_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoTierFactors] CHECK CONSTRAINT [FK_Trident_ALTierFactor_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoTierFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_ALTierFactor_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoTierFactors] CHECK CONSTRAINT [FK_Trident_ALTierFactor_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoUIMCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_UIMCoverages_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoUIMCoverages] CHECK CONSTRAINT [FK_Trident_UIMCoverages_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoUIMCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_UIMCoverages_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoUIMCoverages] CHECK CONSTRAINT [FK_Trident_UIMCoverages_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoUMCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_UMCoverages_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoUMCoverages] CHECK CONSTRAINT [FK_Trident_UMCoverages_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoUMCoverages]  WITH CHECK ADD  CONSTRAINT [FK_Trident_UMCoverages_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoUMCoverages] CHECK CONSTRAINT [FK_Trident_UMCoverages_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoUMDeductible]  WITH CHECK ADD  CONSTRAINT [FK_Trident_UMDeductible_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoUMDeductible] CHECK CONSTRAINT [FK_Trident_UMDeductible_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoUMDeductible]  WITH CHECK ADD  CONSTRAINT [FK_Trident_UMDeductible_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoUMDeductible] CHECK CONSTRAINT [FK_Trident_UMDeductible_Trident_MstState]
GO
ALTER TABLE [dbo].[Trident_AutoValuationFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_APDValuationFactors_Trident_MstLOB] FOREIGN KEY([LOBCode])
REFERENCES [dbo].[Trident_MstLOB] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoValuationFactors] CHECK CONSTRAINT [FK_Trident_APDValuationFactors_Trident_MstLOB]
GO
ALTER TABLE [dbo].[Trident_AutoValuationFactors]  WITH CHECK ADD  CONSTRAINT [FK_Trident_APDValuationFactors_Trident_MstState] FOREIGN KEY([StateCode])
REFERENCES [dbo].[Trident_MstState] ([Code])
GO
ALTER TABLE [dbo].[Trident_AutoValuationFactors] CHECK CONSTRAINT [FK_Trident_APDValuationFactors_Trident_MstState]
GO
