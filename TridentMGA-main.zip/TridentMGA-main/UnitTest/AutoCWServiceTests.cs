﻿namespace UnitTest
{
    using Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.ApiModels;
    using RaterAutoLiability;
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    using System.IO;
    using UnitTest.Init;


    [TestClass]
    public class AutoCWServiceTests
    {
        private IAutoALService CWservice;
        private IAutoAPDService AutoAPDservice;
        private AutoScheduleRatingService AutoScheduleRatingService;
        /// <summary>
        /// Gets logger.
        /// </summary>
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }

        private RaterFacadeModel model;

        private AutoInitialization autoInitialization;

        [TestInitialize]
        public void Initialize()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();


            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();

            this.CWservice = new AutoALCwService(this.configuration, this.logger);
            this.AutoAPDservice = new AutoAPDService(this.configuration, this.logger);
            this.AutoScheduleRatingService = new AutoScheduleRatingService(this.configuration, this.logger);
        }

        public AutoCWServiceTests()
        {
            this.model = new RaterFacadeModel();
            this.autoInitialization = new AutoInitialization();

            autoInitialization.Initialize(this.model);

        }

        #region Test Case Auto Premium for NC state

        [TestMethod]
        public void CalculatePremiumTest1()
        {
            
            autoInitialization.InitializationAutoALCase1(this.model);

            // Since input pre validation are success, calculate premium
            CWservice.Calculate(this.model);

            CalculateAutoLiablityPremiumTest1(this.model);

            CalculateAutoPIPPremiumTest1(this.model);

            CalculateAutoBasicFPBPremiumTest1(this.model);

            CalculateAutoMEDpremiumTest1(this.model);

            CalculateAutoUMPremiumTest1(this.model);

            CalculateAutoUMBIPDPremiumTest1(this.model);

            CalculateAutoUIMPremiumTest1(this.model);

            CalculateAutoHiredandNonOwnedPremiumTest1(this.model);

            CalculateAutoOptionalCoveragesPremiumTest1(this.model);

            CalculateAutoBasePremiumTest1(this.model);

            CalculateAutoManualPremiumTest1(this.model);

            CalculateAutoTierPremiumTest1(this.model);

            CalculateAutoIRPMPremiumTest1(this.model);

            CalculateAutoOtherModPremiumTest1(this.model);

            CalculateAutoTerrorismPremiumTest1(this.model);

            CalculateAutoFinalPremiumForNonMIAndNCTest1(this.model);

            CalculateAutoFinalPremiumMITest1(this.model);

            CalculateAutoFinalPremiumNCTest1(this.model);

            CalculateAutoMIMCCAAssessementChargePremiumTest1(this.model);

            CalculateAutoNCAssessementChargePremiumTest1(this.model);

            CalculateAutoLiabilityModifiedPremiumTest1(this.model);

            CalculateAutoMedPeyModifiedPremiumTest1(this.model);

            CalculateUMAndBIPDModifiedPremiumTest1(this.model);

            CalculateAutoUIMModifiedPremiumTest1(this.model);

            CalculatePIPAndBasicFPBModifiedPremiumTest1(this.model);

            CalculateAutoHiredANDNonOwnedModifiedPremiumTest1(this.model);

            if(model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.HasAutoPhysicalDamage)
            {
                autoInitialization.InitializationAutoAPDCase1(this.model);

                AutoAPDservice.Calculate(this.model);

                CalculateAutoAPDCollCompAndSpecifiedCasueofLossPremiumTest1(this.model);

                CalculateAutoAPDOptionalCoveragePremiumTest1(this.model);

                CalculateAutoAPDMNAutomobileTheftPreventionSurchargeTest1(this.model);

                CalculateAutoAPDMNFireSafetySurchargeTest1(this.model);

                CalculateAutoAPDBasePremiumTest1(this.model);

                CalculateAutoAPDManualPremiumTest1(this.model);

                CalculateAutoAPDTierPremiumTest1(this.model);

                CalculateAutoAPDIRPMPremiumTest1(this.model);

                CalculateAutoAPDOtherModPremiumTest1(this.model);

                CalculateAutoAPDTerrorismPremiumTest1(this.model);

                CalculateAutoAPDFinalPremiumTest1(this.model);
            }

            AutoScheduleRatingService.CalculateScheduleRating(this.model);

            CalculateAutoScheduleRatingTest1(this.model);

        }

        #region Auto AL

        #region Liablity Premium

        public void CalculateAutoLiablityPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.LiabilityUnModifiedPremium, 3636.59M);
        }

        #endregion

        #region PIP Premium

        public void CalculateAutoPIPPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 0);

        }

        #endregion

        #region Basic FPBPremium

        public void CalculateAutoBasicFPBPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 0);
        }

        #endregion

        #region  MED Premium

        public void CalculateAutoMEDpremiumTest1(RaterFacadeModel model)
        {
            
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium, 180.00M);
        }

        #endregion

        #region  UM Premiumm

        public void CalculateAutoUMPremiumTest1(RaterFacadeModel model)
        {
            
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UninsuredUnModifiedPremium, 716.00M);
        }

        #endregion

        #region UM BI/PD Premium

        public void CalculateAutoUMBIPDPremiumTest1(RaterFacadeModel model)
        {
            
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UninsuredUnModifiedPremium, 716.00M);
        }

        #endregion

        #region  UIM Premiumm

        public void CalculateAutoUIMPremiumTest1(RaterFacadeModel model)
        {
          
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium, 0);
        }

        #endregion

        #region Hired and NonOwned Premium
        public void CalculateAutoHiredandNonOwnedPremiumTest1(RaterFacadeModel model)
        {
            
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.HiredAndNonOwnedUnModifiedPremium, 0);

        }

        #endregion

        #region Optional AutoOptionalCoverages Premium

        public void CalculateAutoOptionalCoveragesPremiumTest1(RaterFacadeModel model)
        {
           
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025UnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremium, 0); //User Entered
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009UnModifiedPremium, 0); //User Entered
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201UnModifiedPremium, 0); // user Entered
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.OtherCoverageUnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.NonModifiedPremium, 0);

        }

        #endregion

        #region Auto Base Premium
        public void CalculateAutoBasePremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.BasePremium, 4759);
        }

        #endregion

        #region Auto Manual Premium
        public void CalculateAutoManualPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ManualPremium, 4759);
        }
        #endregion

        #region Calculate Tier Premium

        public void CalculateAutoTierPremiumTest1(RaterFacadeModel model)
        {
           
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.TierPremium, 4759);
        }

        #endregion

        #region Calculate IRPM Premium

        public void CalculateAutoIRPMPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.IRPMPremium, 3331);

        }

        #endregion

        #region Calculate OtherMod Premium

        public void CalculateAutoOtherModPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.OtherModPremium, 3331);

        }

        #endregion

        #region Calculate Terrorism Premium

        public void CalculateAutoTerrorismPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.TerrorismPremium, 0);

        }

        #endregion

        #region Calculate FinalPremium For NonMIAndNC 

        public void CalculateAutoFinalPremiumForNonMIAndNCTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ALModifiedFinalPremium, 3409);

        }

        #endregion

        #region Calculate FinalPremiumMI 

        public void CalculateAutoFinalPremiumMITest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ALModifiedFinalPremium, 3409);

        }

        #endregion

        #region Calculate FinalPremiumNC 

        public void CalculateAutoFinalPremiumNCTest1(RaterFacadeModel model)
        {
            
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ALModifiedFinalPremium, 3409);
        }

        #endregion

        #region Calculate MI MCCA Assessement Charge 

        public void CalculateAutoMIMCCAAssessementChargePremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.MIMCCAAssessmentCharge, 0);
        }

        #endregion

        #region Calculate NC Auto Loss Recoupment Surcharge

        public void CalculateAutoNCAssessementChargePremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.NCAutoLossRecoupmentSurchargeCharge, 78M);
        }

        #endregion

        #region Calculate Liability Modified Premium

        public void CalculateAutoLiabilityModifiedPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.LiabilityModifiedPremium, 2545.61M);
        }

        #endregion

        #region Calculate MedPey Modified Premium

        public void CalculateAutoMedPeyModifiedPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.MedicalPaymentsModifiedPremium, 126.00M);
        }

        #endregion

        #region Calculate UM / UMBIPD Modified Premium

        public void CalculateUMAndBIPDModifiedPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UninsuredModifiedPremium, 501.20M);
        }

        #endregion

        #region Calculate UIM Modified Premium

        public void CalculateAutoUIMModifiedPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UnderinsuredModifiedPremium, 0.00M);
        }

        #endregion

        #region Calculate PIP / BasicFPB Modified Premium

        public void CalculatePIPAndBasicFPBModifiedPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.PersonalInjuryProtectionModifiedPremium, 0.00M);
        }

        #endregion

        #region Calculate HiredANDNonOwned Modified Premium

        public void CalculateAutoHiredANDNonOwnedModifiedPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.HiredAndNonOwnedModifiedPremium, 0);
        }

        #endregion

        #region Calculate Auto Schedule Rating

        public void CalculateAutoScheduleRatingTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.TotalSchedulePremium1, 3330);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.Difference1, 79);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.TotalSchedulePremium2, 3410);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.Difference2, -1);
        }

        #endregion

        #endregion

        #region Auto APD

        #region collision comprehensive And SpecifiedCasueofLoss Premium

        public void CalculateAutoAPDCollCompAndSpecifiedCasueofLossPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalUnModifiedCollisionPremium, 437);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium, 509);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalUnModifiedSpecCauseofLossPremium, 872);
        }

        #endregion

        #region Calculate OptionalCoverage Premium

        public void CalculateAutoAPDOptionalCoveragePremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.GaragekeepersCA9937UnModifiedPremium, 150);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.RentalReimbursementCA9923UnModifiedPremium, 20);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.RentalReimbursementEmergencyServiceVehiclesBA0004UnModifiedPremium, 20);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.FullSafetyGlassCoverageCA0421UnModifiedPremium, 1018);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.OtherCoverageUnModifiedPremium, 50);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.NonModifiedPremium, 1258);
        }

        #endregion

        #region Calculate MNAutomobileTheftPrevention Surcharge

        public void CalculateAutoAPDMNAutomobileTheftPreventionSurchargeTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionCharge, 0);
        }

        #endregion

        #region Calculate MNFireSafety Surcharge

        public void CalculateAutoAPDMNFireSafetySurchargeTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeCharge, 0);
        }

        #endregion

        #region Calculate Base Premium

        public void CalculateAutoAPDBasePremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.BasePremium, 1818);
        }

        #endregion

        #region Calculate Manual Premium

        public void CalculateAutoAPDManualPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.ManualPremium, 3076);
        }

        #endregion

        #region Calculate Tier Premium

        public void CalculateAutoAPDTierPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TierPremium, 3076);
        }

        #endregion

        #region Calculate IRPM Premium

        public void CalculateAutoAPDIRPMPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.IRPMPremium, 3076);
        }

        #endregion

        #region Calculate Other ModPremium

        public void CalculateAutoAPDOtherModPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.OtherModPremium, 3076);
        }

        #endregion

        #region Calculate Terrorism Premium

        public void CalculateAutoAPDTerrorismPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TerrorismPremium, 0);
        }

        #endregion

        #region Calculate Final Premium

        public void CalculateAutoAPDFinalPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.APDModifiedFinalPremium, 3076);
        }

        #endregion

        #endregion

        #endregion


        #region Test Case Auto Premium for PA state

        [TestMethod]
        public void CalculatePremiumTest2()
        {

            autoInitialization.InitializationAutoALCase2(this.model);

            // Since input pre validation are success, calculate premium
            CWservice.Calculate(this.model);

            CalculateAutoLiablityPremiumTest2(this.model);

            CalculateAutoPIPPremiumTest2(this.model);

            CalculateAutoBasicFPBPremiumTest2(this.model);

            CalculateAutoMEDPremiumTest2(this.model);

            CalculateAutoUMPremiumTest2(this.model);

            CalculateAutoUMBIPDPremiumTest2(this.model);

            CalculateAutoUIMPremiumTest2(this.model);

            CalculateAutoHiredandNonOwnedPremiumTest2(this.model);

            CalculateAutoOptionalCoveragesPremiumTest2(this.model);

            CalculateAutoBasePremiumTest2(this.model);

            CalculateAutoManualPremiumTest2(this.model);

            CalculateAutoTierPremiumTest2(this.model);

            CalculateAutoIRPMPremiumTest2(this.model);

            CalculateAutoOtherModPremiumTest2(this.model);

            CalculateAutoTerrorismPremiumTest2(this.model);

            CalculateAutoFinalPremiumForNonMIAndNCTest2(this.model);

            CalculateAutoFinalPremiumMITest2(this.model);

            CalculateAutoFinalPremiumNCTest2(this.model);

            CalculateAutoMIMCCAAssessementChargePremiumTest2(this.model);

            CalculateAutoNCAssessementChargePremiumTest2(this.model);

            CalculateAutoLiabilityModifiedPremiumTest2(this.model);

            CalculateAutoMedPeyModifiedPremiumTest2(this.model);

            CalculateUMAndBIPDModifiedPremiumTest2(this.model);

            CalculateAutoUIMModifiedPremiumTest2(this.model);

            CalculatePIPAndBasicFPBModifiedPremiumTest2(this.model);

            CalculateAutoHiredANDNonOwnedModifiedPremiumTest2(this.model);

            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.HasAutoPhysicalDamage)
            {
                autoInitialization.InitializationAutoAPDCase2(this.model);

                AutoAPDservice.Calculate(this.model);

                CalculateAutoAPDCollCompAndSpecifiedCasueofLossPremiumTest2(this.model);

                CalculateAutoAPDOptionalCoveragePremiumTest2(this.model);

                CalculateAutoAPDMNAutomobileTheftPreventionSurchargeTest2(this.model);

                CalculateAutoAPDMNFireSafetySurchargeTest2(this.model);

                CalculateAutoAPDBasePremiumTest2(this.model);

                CalculateAutoAPDManualPremiumTest2(this.model);

                CalculateAutoAPDTierPremiumTest2(this.model);

                CalculateAutoAPDIRPMPremiumTest2(this.model);

                CalculateAutoAPDOtherModPremiumTest2(this.model);

                CalculateAutoAPDTerrorismPremiumTest2(this.model);

                CalculateAutoAPDFinalPremiumTest2(this.model);
            }

            AutoScheduleRatingService.CalculateScheduleRating(this.model);

            CalculateAutoScheduleRatingTest2(this.model);

        }

        #region Auto AL

        #region Liablity Premium

        public void CalculateAutoLiablityPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.LiabilityUnModifiedPremium, 4300.00M);
        }

        #endregion

        #region PIP Premium

        public void CalculateAutoPIPPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 0);

        }

        #endregion

        #region Basic FPBPremium

        public void CalculateAutoBasicFPBPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 0);
        }

        #endregion

        #region  MED Premium

        public void CalculateAutoMEDPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium, 0);
        }

        #endregion

        #region  UM Premiumm

        public void CalculateAutoUMPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UninsuredUnModifiedPremium, 0);
        }

        #endregion

        #region UM BI/PD Premium

        public void CalculateAutoUMBIPDPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UninsuredUnModifiedPremium, 0);
        }

        #endregion

        #region  UIM Premiumm

        public void CalculateAutoUIMPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium, 118.00M);
        }

        #endregion

        #region Hired and NonOwned Premium
        public void CalculateAutoHiredandNonOwnedPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.HiredAndNonOwnedUnModifiedPremium, 0);

        }

        #endregion

        #region Optional AutoOptionalCoverages Premium

        public void CalculateAutoOptionalCoveragesPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025UnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremium, 40); //User Entered
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009UnModifiedPremium, 0); //User Entered
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201UnModifiedPremium, 0); // user Entered
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.OtherCoverageUnModifiedPremium, 60);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.NonModifiedPremium, 100);

        }

        #endregion

        #region Auto Base Premium
        public void CalculateAutoBasePremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.BasePremium, 4639);
        }

        #endregion

        #region Auto Manual Premium
        public void CalculateAutoManualPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ManualPremium, 4739);
        }
        #endregion

        #region Calculate Tier Premium

        public void CalculateAutoTierPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.TierPremium, 4739);
        }

        #endregion

        #region Calculate IRPM Premium

        public void CalculateAutoIRPMPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.IRPMPremium, 2883);

        }

        #endregion

        #region Calculate OtherMod Premium

        public void CalculateAutoOtherModPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.OtherModPremium, 156);

        }

        #endregion

        #region Calculate Terrorism Premium

        public void CalculateAutoTerrorismPremiumTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.TerrorismPremium, 0);

        }

        #endregion

        #region Calculate FinalPremium For NonMIAndNC 

        public void CalculateAutoFinalPremiumForNonMIAndNCTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ALModifiedFinalPremium, 156);

        }

        #endregion

        #region Calculate FinalPremiumMI 

        public void CalculateAutoFinalPremiumMITest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ALModifiedFinalPremium, 156);

        }

        #endregion

        #region Calculate FinalPremiumNC 

        public void CalculateAutoFinalPremiumNCTest2(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.ALModifiedFinalPremium, 156);
        }

        #endregion

        #region Calculate MI MCCA Assessement Charge 

        public void CalculateAutoMIMCCAAssessementChargePremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.MIMCCAAssessmentCharge, 0);
        }

        #endregion

        #region Calculate NC Auto Loss Recoupment Surcharge

        public void CalculateAutoNCAssessementChargePremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.NCAutoLossRecoupmentSurchargeCharge, 0);
        }

        #endregion

        #region Calculate Liability Modified Premium

        public void CalculateAutoLiabilityModifiedPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.LiabilityModifiedPremium, 51.60M);
        }

        #endregion

        #region Calculate MedPey Modified Premium

        public void CalculateAutoMedPeyModifiedPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.MedicalPaymentsModifiedPremium, 0);
        }

        #endregion

        #region Calculate UM / UMBIPD Modified Premium

        public void CalculateUMAndBIPDModifiedPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UninsuredModifiedPremium, 0);
        }

        #endregion

        #region Calculate UIM Modified Premium

        public void CalculateAutoUIMModifiedPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.UnderinsuredModifiedPremium, 1.42M);
        }

        #endregion

        #region Calculate PIP / BasicFPB Modified Premium

        public void CalculatePIPAndBasicFPBModifiedPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.PersonalInjuryProtectionModifiedPremium, 0.00M);
        }

        #endregion

        #region Calculate HiredANDNonOwned Modified Premium

        public void CalculateAutoHiredANDNonOwnedModifiedPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.HiredAndNonOwnedModifiedPremium, 0);
        }

        #endregion

        #region Calculate Auto Schedule Rating

        public void CalculateAutoScheduleRatingTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.TotalSchedulePremium1, 2780);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.Difference1, -2624);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.TotalSchedulePremium2, 160);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel.Difference2, -4);
        }

        #endregion

        #endregion

        #region Auto APD

        #region collision comprehensive And SpecifiedCasueofLoss Premium

        public void CalculateAutoAPDCollCompAndSpecifiedCasueofLossPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalUnModifiedCollisionPremium, 771);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium, 509);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TotalUnModifiedSpecCauseofLossPremium, 399);
        }

        #endregion

        #region Calculate OptionalCoverage Premium

        public void CalculateAutoAPDOptionalCoveragePremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.GaragekeepersCA9937UnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.RentalReimbursementCA9923UnModifiedPremium, 50);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.RentalReimbursementEmergencyServiceVehiclesBA0004UnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.FullSafetyGlassCoverageCA0421UnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.OtherCoverageUnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.NonModifiedPremium, 50);
        }

        #endregion

        #region Calculate MNAutomobileTheftPrevention Surcharge

        public void CalculateAutoAPDMNAutomobileTheftPreventionSurchargeTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionCharge, 0);
        }

        #endregion

        #region Calculate MNFireSafety Surcharge

        public void CalculateAutoAPDMNFireSafetySurchargeTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeCharge, 0);
        }

        #endregion

        #region Calculate Base Premium

        public void CalculateAutoAPDBasePremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.BasePremium, 1679);
        }

        #endregion

        #region Calculate Manual Premium

        public void CalculateAutoAPDManualPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.ManualPremium, 1729);
        }

        #endregion

        #region Calculate Tier Premium

        public void CalculateAutoAPDTierPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TierPremium, 1729);
        }

        #endregion

        #region Calculate IRPM Premium

        public void CalculateAutoAPDIRPMPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.IRPMPremium, 1225);
        }

        #endregion

        #region Calculate Other ModPremium

        public void CalculateAutoAPDOtherModPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.OtherModPremium, 100);
        }

        #endregion

        #region Calculate Terrorism Premium

        public void CalculateAutoAPDTerrorismPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.TerrorismPremium, 0);
        }

        #endregion

        #region Calculate Final Premium

        public void CalculateAutoAPDFinalPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.APDModifiedFinalPremium, 100);
        }

        #endregion

        #endregion

        #endregion

        [TestCleanup()]
        public void Cleanup() { }
    }
}