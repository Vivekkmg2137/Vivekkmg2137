﻿using Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ApiModels;
using RaterAutoLiability;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.IO;
using UnitTest.Init;

namespace UnitTest
{
    [TestClass()]
    public class AutoNYServiceTest
    {
        private IAutoALService NYservice;
        private IAutoAPDService AutoAPDservice;
        private AutoScheduleRatingService AutoScheduleRatingService;
        /// <summary>
        /// Gets logger.
        /// </summary>
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }

        private RaterFacadeModel model;

        private AutoInitialization autoInitialization;

        [TestInitialize]
        public void Initialize()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();


            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();

            this.NYservice = new AutoALNYService(this.configuration, this.logger);
            this.AutoAPDservice = new AutoAPDService(this.configuration, this.logger);
            this.AutoScheduleRatingService = new AutoScheduleRatingService(this.configuration, this.logger);
        }

        public AutoNYServiceTest()
        {
            this.model = new RaterFacadeModel();
            this.autoInitialization = new AutoInitialization();

            autoInitialization.Initialize(this.model);

        }

        #region Test Case Auto Premium for NY state

        [TestMethod]
        public void CalculatePremiumTest1()
        {

            autoInitialization.InitializationAutoALCase3(this.model);

            // Since input pre validation are success, calculate premium
            NYservice.Calculate(this.model);

            CalculateAutoLiablityPremium(this.model);

            CalculateAutoPIPPremium(this.model);

            CalculateAutoBasicFPBPremium(this.model);

            CalculateAutoMEDpremium(this.model);

            CalculateAutoUMPremium(this.model);

            CalculateAutoUMBIPDPremium(this.model);

            CalculateAutoUIMPremium(this.model);

            CalculateAutoHiredandNonOwnedPremium(this.model);

            CalculateAutoOptionalCoveragesPremium(this.model);

            CalculateAutoBasePremium(this.model);

            CalculateAutoManualPremium(this.model);

            CalculateAutoTierPremium(this.model);

            CalculateAutoIRPMPremium(this.model);

            CalculateAutoOtherModPremium(this.model);

            CalculateAutoTerrorismPremium(this.model);

            CalculateAutoFinalPremiumForNonMIAndNC(this.model);

            CalculateAutoFinalPremiumMI(this.model);

            CalculateAutoFinalPremiumNC(this.model);

            CalculateAutoMIMCCAAssessementChargePremium(this.model);

            CalculateAutoNCAssessementChargePremium(this.model);

            CalculateAutoLiabilityModifiedPremium(this.model);

            CalculateAutoMedPeyModifiedPremium(this.model);

            CalculateUMAndBIPDModifiedPremium(this.model);

            CalculateAutoUIMModifiedPremium(this.model);

            CalculatePIPAndBasicFPBModifiedPremium(this.model);

            CalculateAutoHiredANDNonOwnedModifiedPremium(this.model);

            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.HasAutoPhysicalDamage)
            {
                autoInitialization.InitializationAutoAPDCase3(this.model);

                AutoAPDservice.Calculate(this.model);

                CalculateAutoAPDCollCompAndSpecifiedCasueofLossPremium(this.model);

                CalculateAutoAPDOptionalCoveragePremium(this.model);

                CalculateAutoAPDMNAutomobileTheftPreventionSurcharge(this.model);

                CalculateAutoAPDMNFireSafetySurcharge(this.model);

                CalculateAutoAPDBasePremium(this.model);

                CalculateAutoAPDManualPremium(this.model);

                CalculateAutoAPDTierPremium(this.model);

                CalculateAutoAPDIRPMPremium(this.model);

                CalculateAutoAPDOtherModPremium(this.model);

                CalculateAutoAPDTerrorismPremium(this.model);

                CalculateAutoAPDFinalPremium(this.model);
            }

            AutoScheduleRatingService.CalculateScheduleRating(this.model);

            CalculateAutoScheduleRating(this.model);

        }

        #region Auto AL

        #region Liablity Premium

        public void CalculateAutoLiablityPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.LiabilityUnModifiedPremium, 2655.00M);
        }

        #endregion

        #region PIP Premium

        public void CalculateAutoPIPPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 10.00M);

        }

        #endregion

        #region Basic FPBPremium

        public void CalculateAutoBasicFPBPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.PersonalInjuryProtectionUnModifiedPremium, 10.00M);
        }

        #endregion

        #region  MED Premium

        public void CalculateAutoMEDpremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.MedicalPaymentsUnModifiedPremium, 180.00M);
        }

        #endregion

        #region  UM Premiumm

        public void CalculateAutoUMPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.UninsuredUnModifiedPremium, 0);
        }

        #endregion

        #region UM BI/PD Premium

        public void CalculateAutoUMBIPDPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.UninsuredUnModifiedPremium,0);
        }

        #endregion

        #region  UIM Premiumm

        public void CalculateAutoUIMPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.UnderinsuredUnModifiedPremium, 0);
        }

        #endregion

        #region Hired and NonOwned Premium
        public void CalculateAutoHiredandNonOwnedPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.HiredAndNonOwnedUnModifiedPremium, 100);

        }

        #endregion

        #region Optional AutoOptionalCoverages Premium

        public void CalculateAutoOptionalCoveragesPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.MutualAidCA2025UnModifiedPremium, 50);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.LessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremium, 0); //User Entered
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredEndorsementAutoAG1009UnModifiedPremium, 0); //User Entered
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201UnModifiedPremium, 0); // user Entered
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.OtherCoverageUnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.NonModifiedPremium, 50);

        }

        #endregion

        #region Auto Base Premium
        public void CalculateAutoBasePremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.BasePremium, 3372);
        }

        #endregion

        #region Auto Manual Premium
        public void CalculateAutoManualPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.ManualPremium, 3422);
        }
        #endregion

        #region Calculate Tier Premium

        public void CalculateAutoTierPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.TierPremium, 3422);
        }

        #endregion

        #region Calculate IRPM Premium

        public void CalculateAutoIRPMPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.IRPMPremium, 3591);

        }

        #endregion

        #region Calculate OtherMod Premium

        public void CalculateAutoOtherModPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.OtherModPremium, 3591);

        }

        #endregion

        #region Calculate Terrorism Premium

        public void CalculateAutoTerrorismPremium(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.TerrorismPremium, 0);

        }

        #endregion

        #region Calculate FinalPremium For NonMIAndNC 

        public void CalculateAutoFinalPremiumForNonMIAndNC(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.ALModifiedFinalPremium, 3591);

        }

        #endregion

        #region Calculate FinalPremiumMI 

        public void CalculateAutoFinalPremiumMI(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.ALModifiedFinalPremium, 3591);

        }

        #endregion

        #region Calculate FinalPremiumNC 

        public void CalculateAutoFinalPremiumNC(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.ALModifiedFinalPremium, 3591);
        }

        #endregion

        #region Calculate MI MCCA Assessement Charge 

        public void CalculateAutoMIMCCAAssessementChargePremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.MIMCCAAssessmentCharge, 0);
        }

        #endregion

        #region Calculate NC Auto Loss Recoupment Surcharge

        public void CalculateAutoNCAssessementChargePremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.NCAutoLossRecoupmentSurchargeCharge, 0);
        }

        #endregion

        #region Calculate Liability Modified Premium

        public void CalculateAutoLiabilityModifiedPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.LiabilityModifiedPremium, 2787.75M);
        }

        #endregion

        #region Calculate MedPey Modified Premium

        public void CalculateAutoMedPeyModifiedPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.MedicalPaymentsModifiedPremium, 189.00M);
        }

        #endregion

        #region Calculate UM / UMBIPD Modified Premium

        public void CalculateUMAndBIPDModifiedPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.UninsuredModifiedPremium, 0);
        }

        #endregion

        #region Calculate UIM Modified Premium

        public void CalculateAutoUIMModifiedPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.UnderinsuredModifiedPremium, 0.00M);
        }

        #endregion

        #region Calculate PIP / BasicFPB Modified Premium

        public void CalculatePIPAndBasicFPBModifiedPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.PersonalInjuryProtectionModifiedPremium, 10.50M);
        }

        #endregion

        #region Calculate HiredANDNonOwned Modified Premium

        public void CalculateAutoHiredANDNonOwnedModifiedPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.HiredAndNonOwnedModifiedPremium, 105);
        }

        #endregion

        #region Calculate Auto Schedule Rating

        public void CalculateAutoScheduleRating(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.TotalSchedulePremium1, 3440);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.Difference1, 151);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.TotalSchedulePremium2, 3590);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel.Difference2, 1);
        }

        #endregion

        #endregion

        #region Auto APD

        #region collision comprehensive And SpecifiedCasueofLoss Premium

        public void CalculateAutoAPDCollCompAndSpecifiedCasueofLossPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TotalUnModifiedCollisionPremium, 277);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TotalUnModifiedComprehensivePremium, 419);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TotalUnModifiedSpecCauseofLossPremium, 0);
        }

        #endregion

        #region Calculate OptionalCoverage Premium

        public void CalculateAutoAPDOptionalCoveragePremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.GaragekeepersCA9937UnModifiedPremium, 150);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.RentalReimbursementCA9923UnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.RentalReimbursementEmergencyServiceVehiclesBA0004UnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.FullSafetyGlassCoverageCA0421UnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.OtherCoverageUnModifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.NonModifiedPremium, 150);
        }

        #endregion

        #region Calculate MNAutomobileTheftPrevention Surcharge

        public void CalculateAutoAPDMNAutomobileTheftPreventionSurcharge(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.MNAutomobileTheftPreventionCharge, 0);
        }

        #endregion

        #region Calculate MNFireSafety Surcharge

        public void CalculateAutoAPDMNFireSafetySurcharge(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.MNFireSafetySurchargeCharge, 0);
        }

        #endregion

        #region Calculate Base Premium

        public void CalculateAutoAPDBasePremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.BasePremium, 696);
        }

        #endregion

        #region Calculate Manual Premium

        public void CalculateAutoAPDManualPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.ManualPremium, 846);
        }

        #endregion

        #region Calculate Tier Premium

        public void CalculateAutoAPDTierPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TierPremium, 846);
        }

        #endregion

        #region Calculate IRPM Premium

        public void CalculateAutoAPDIRPMPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.IRPMPremium, 742);
        }

        #endregion

        #region Calculate Other ModPremium

        public void CalculateAutoAPDOtherModPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.OtherModPremium, 156);
        }

        #endregion

        #region Calculate Terrorism Premium

        public void CalculateAutoAPDTerrorismPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.TerrorismPremium, 0);
        }

        #endregion

        #region Calculate Final Premium

        public void CalculateAutoAPDFinalPremium(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.APDModifiedFinalPremium, 156);
        }

        #endregion

        #endregion

        #endregion

        [TestCleanup()]
        public void Cleanup() { }
    }
}

