﻿using Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.IO;
using UnitTest.Init;
using RaterDO;

namespace UnitTest
{
    [TestClass()]
    public class DirectorsAndOfficersServiceTests 
    {
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }

        private IDirectorsAndOfficersService doService;

        private RaterFacadeModel model;

        private DOInitialization doInitialization;

        [TestInitialize()]
        public void Initialize()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();


            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();

            this.doService = new DirectorsAndOfficersService(this.configuration, this.logger);
        }

        public DirectorsAndOfficersServiceTests()
        {
            #region Calculate premium
            this.model = new RaterFacadeModel();
            this.doInitialization = new DOInitialization();

            doInitialization.Initialize(this.model);
            #endregion
        }

        #region Test Case Directors And Officers Premium for SC State 

        [TestMethod]
        public void CalculatePremiumTest1()
        {

            doInitialization.InitializationCase1(this.model);

            // Since input pre validation are success, calculate premium
            doService.Calculate(this.model);

            CalculateInitialRatesTest(this.model);

            CalculateBasePremiumsTest1(this.model);

            CalculateOptionalCoveragesPremiumsTest1(this.model);

            CalculateManualPremiumTest1(this.model);

            CalculateTierPremiumTest1(this.model);

            CalculateIRPMPremiumTest1(this.model);

            CalculateOtherModPremiumTest1(this.model);

            CalculateTerrorismPremiumTest1(this.model);

            CalculateFinalPremiumTest1(this.model);
        }

        #region Calculate Initial Rates
        
        public void CalculateInitialRatesTest(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RatingBasis, "payroll (less clerical)");
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RetroYear, 3);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.ExposureRate, 4.5M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.LiabilityLimitRate, 1.100M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.AggregateLimitRate, 1.065M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.EPInclusionExclusionRate, 0.300M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RetentionRate, 0.960M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.PolicyTypeRate, 0.800M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RetroDateRate, 1.1400M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.YearsInCMRate, 0.950M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.PopulationRate, 1.250M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.LocationRate, 1.000M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.TerrorismRate, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.TierRate, 1.000M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.IRPMFactor, 0.90M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.OtherModRate, 0.75M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RatingBasisParameter, 1000);

        }

        #endregion

        #region Optional Coverages Premium
        
        public void CalculateOptionalCoveragesPremiumsTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel.OtherCoveragesTotalPremium, 170);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.NonModifiedPremium, 170);

        }

        #endregion

        #region Calculate Base Premium
        
        public void CalculateBasePremiumsTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.BasePremium, 329);

        }

        #endregion

        #region Calculate Manual Premium
        
        public void CalculateManualPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.ManualPremium, 499);

        }

        #endregion

        #region Calculate Tier Premium

        
        public void CalculateTierPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.TierPremium, 499);

        }

        #endregion

        #region Calculate IRPM Premium

        
        public void CalculateIRPMPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.IRPMPremium, 466);

        }

        #endregion

        #region Calculate OtherMod Premium
                
        public void CalculateOtherModPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.OtherModPremium, 392);

        }

        #endregion

        #region Calculate Terrorism Premium
                
        public void CalculateTerrorismPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.TerrorismPremium, 0);

        }

        #endregion

        #region Calculate FinalPremium
        
        public void CalculateFinalPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.DOModifiedFinalPremium, 392);

        }

        #endregion

        #endregion

        #region Test Case Directors And Officers Premium for NC State 

        [TestMethod]
        public void CalculatePremiumTest2()
        {

            doInitialization.InitializationCase2(this.model);

            // Since input pre validation are success, calculate premium
            doService.Calculate(this.model);

            CalculateInitialRatesTest2(this.model);

            CalculateBasePremiumsTest2(this.model);

            CalculateOptionalCoveragesPremiumsTest2(this.model);

            CalculateManualPremiumTest2(this.model);

            CalculateTierPremiumTest2(this.model);

            CalculateIRPMPremiumTest2(this.model);

            CalculateOtherModPremiumTest2(this.model);

            CalculateTerrorismPremiumTest2(this.model);

            CalculateFinalPremiumTest2(this.model);
        }

        #region Calculate Initial Rates
        
        public void CalculateInitialRatesTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RatingBasis, "payroll (less clerical)");
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RetroYear, 6);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.ExposureRate, 4.5M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.LiabilityLimitRate, 1.400M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.AggregateLimitRate, 1.015M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.EPInclusionExclusionRate, 0.300M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RetentionRate, 1.000M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.PolicyTypeRate, 0.800M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RetroDateRate, 1.200M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.YearsInCMRate, 0.850M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.PopulationRate, 1.300M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.LocationRate, 1.000M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.TerrorismRate, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.TierRate, 1.000M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.IRPMFactor, 1.50M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.OtherModRate, 1.75M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.RatingBasisParameter, 1000);

        }

        #endregion

        #region Optional Coverages Premium
        
        public void CalculateOptionalCoveragesPremiumsTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel.OtherCoveragesTotalPremium, 170);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.NonModifiedPremium, 170);

        }

        #endregion

        #region Calculate Base Premium
        
        public void CalculateBasePremiumsTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.BasePremium, 203);

        }

        #endregion

        #region Calculate Manual Premium
        
        public void CalculateManualPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.ManualPremium, 373);

        }

        #endregion

        #region Calculate Tier Premium

        
        public void CalculateTierPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.TierPremium, 373);

        }

        #endregion

        #region Calculate IRPM Premium

        
        public void CalculateIRPMPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.IRPMPremium, 475);

        }

        #endregion

        #region Calculate OtherMod Premium

        
        public void CalculateOtherModPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.OtherModPremium, 704);

        }

        #endregion

        #region Calculate Terrorism Premium

        
        public void CalculateTerrorismPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.TerrorismPremium, 0);

        }

        #endregion

        #region Calculate FinalPremium

        
        public void CalculateFinalPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.DOModifiedFinalPremium, 704);

        }

        #endregion

        #endregion

        [TestCleanup()]
        public void Cleanup() { }
    }
}
