﻿using Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.IO;
using UnitTest.Init;
using RateEducatorsLegal;

namespace UnitTest
{
    [TestClass()]
    public class ELCWServiceTest
    {
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }

        private IEducatorsLegalService elService;

        private RaterFacadeModel model;

        private ELCWInitialization elCwInitialization;

        [TestInitialize()]
        public void Initialize()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();


            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();

            this.elService = new EducatorsLegalCwService(this.configuration, this.logger);

        } 
        
        public void ELServiceTestInitilize()
        {
            this.model = new RaterFacadeModel();
            this.elCwInitialization = new ELCWInitialization();
            this.elCwInitialization.Initialize(this.model);
        }
       
        #region Test Case 1
                
        /// <summary>
        /// CalculateLibilityPremiumTest1
        /// </summary>
        private void CalculateLibilityPremiumTest1()
        {
            this.ELServiceTestInitilize();
            this.elCwInitialization.InitializeELPremium(this.model);
            this.elCwInitialization.InitializeOptionalCoveragePremium(this.model);
            #region Prevalidate
            var preValidateResults = elService.PreValidate(this.model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest1
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest1()
        {
            this.CalculateLibilityPremiumTest1();

            #region Calculate premium
            this.elService.Calculate(this.model);
            #endregion 

            #region Post validate
            var postValidateResults = elService.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion        

            this.CalculateInitialRatesTest(this.model);
            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest1();
            #endregion

            this.CalculateOptionalOtherCoverageAssertTest1();
            this.CalculateOptionalBasePremiumAssertTest1();
        }

        #region Calculate Initial Rates

        public void CalculateInitialRatesTest(RaterFacadeModel model)
        {  
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ExposureRate, 3.75M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EPInclusionExclusionRate, Convert.ToDecimal(1.000)); 
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.LiabilityLimitRate, Convert.ToDecimal(0.790M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.AggregateLimitRate, Convert.ToDecimal(1.000));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.RetentionRate, Convert.ToDecimal(0.780M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ExperienceRetention,  1.500M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.PopulationRate, Convert.ToDecimal(1.075M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.LocationRate, Convert.ToDecimal(1.100M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.PolicyTypeRate, Convert.ToDecimal(0.800M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.YearsinCMRate, Convert.ToDecimal(0.900M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.RetroDateRate, Convert.ToDecimal(1.1400M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EPInclusionExclusionRate, Convert.ToDecimal(1.000M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TerrorismRate, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TierRate, Convert.ToDecimal(1.150M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.IRPMFactor, Convert.ToDecimal(1));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.OtherModRate, Convert.ToDecimal(1));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TierPremium, 1004298);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.OtherModPremium, 1004298);
        }
        #endregion

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalCoverageAssertTest1()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEALimit, 25000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEARate, Convert.ToDecimal(100));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEADeductible, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEAModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEAUnmodifiedPremium, 750);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEAUnmodifiedWithoutExcessPremium, 750);

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseLimit,50000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseRate, Convert.ToDecimal(0));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseDeductible, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium, 2000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseUnmodifiedWithoutExcessPremium, 2000);

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodLimit, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodDeductible, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium, 0);

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.OtherCoverageTotalPremium, 1002750); 

        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest1()
        {
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage != null)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageLimit, 100000);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageRate, 10000);
            }
        }

        /// <summary>
        /// CalculateOptionalBasePremiumAssertTest1
        /// </summary>
        private void CalculateOptionalBasePremiumAssertTest1()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.BasePremium, 1346);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.NonModifiedPremium, 1002750);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ManualPremium, 1004096);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TierPremium, 1004298);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.IRPMPremium, 1004298);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.OtherModPremium, 1004298);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TerrorismPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TerrorismRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ELModifiedFinalPremium, 1004298);
        }
        #endregion

        #region Test Case 2 For CT State 
        /// <summary>
        /// CalculateLibilityPremiumTest2
        /// </summary>
        private void CalculateLibilityPremiumTest2()
        {
            this.ELServiceTestInitilize();
            this.elCwInitialization.InitializeELPremium(this.model);
            this.elCwInitialization.InitializeOptionalCoveragePremium(this.model);
            #region Prevalidate
            var preValidateResults = elService.PreValidate(this.model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest2
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest2()
        {
            this.CalculateLibilityPremiumTest1();

            #region Calculate premium
            this.elService.Calculate(this.model);
            #endregion 

            #region Post validate
            var postValidateResults = elService.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion        

            this.CalculateInitialRatesTest2(this.model);
            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest2();
            #endregion

            this.CalculateOptionalOtherCoverageAssertTest2();
            this.CalculateOptionalBasePremiumAssertTest2();
        }

        #region Calculate Initial Rates

        public void CalculateInitialRatesTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ExposureRate, 3.75M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EPInclusionExclusionRate, Convert.ToDecimal(1.000));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.LiabilityLimitRate, Convert.ToDecimal(0.790M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.AggregateLimitRate, Convert.ToDecimal(1.000));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.RetentionRate, Convert.ToDecimal(0.780M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ExperienceRetention, 1.500M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.PopulationRate, Convert.ToDecimal(1.075M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.LocationRate, Convert.ToDecimal(1.100M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.PolicyTypeRate, Convert.ToDecimal(0.800M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.YearsinCMRate, Convert.ToDecimal(0.900M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.RetroDateRate, Convert.ToDecimal(1.1400M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EPInclusionExclusionRate, Convert.ToDecimal(1.000M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TerrorismRate, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TierRate, Convert.ToDecimal(1.150M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.IRPMFactor,1);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.OtherModRate, 1);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TierPremium, 1004298);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.OtherModPremium, 1004298);
        }
        #endregion

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalCoverageAssertTest2()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEALimit, 25000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEARate, Convert.ToDecimal(100));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEADeductible, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEAModifiedPremium, 0); 
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEAUnmodifiedPremium, 750);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.IDEAUnmodifiedWithoutExcessPremium, 750);

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseLimit, 50000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseRate, Convert.ToDecimal(0));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseDeductible, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium, 2000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.NonMonetaryDefenseUnmodifiedWithoutExcessPremium, 2000);

            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodLimit, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodRate, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodDeductible, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium, 0);

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.OtherCoverageTotalPremium, 1002750); 

        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest2()
        {
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage != null)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageLimit, 100000);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageRate, 10000);
            }
        }

        /// <summary>
        /// CalculateOptionalBasePremiumAssertTest1
        /// </summary>
        private void CalculateOptionalBasePremiumAssertTest2()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.BasePremium, 1346);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.NonModifiedPremium, 1002750);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ManualPremium, 1004096);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TierPremium, 1004298);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.IRPMPremium, 1004298);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.OtherModPremium, 1004298);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TerrorismPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.TerrorismRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.ELModifiedFinalPremium, 1004298);
        }
        #endregion

        [TestCleanup()]
        public void Cleanup() { }

    }
}
