﻿namespace UnitTest
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    using System.IO;
    using UnitTest.Init;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Logging;
    using Models.ApiModels;
    using RateEducatorsLegal;

    [TestClass]
    public class ELNYServiceTest
    {
        /// <summary>
        /// Gets logger.
        /// </summary>
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }

        private IEducatorsLegalService service;

        private RaterFacadeModel model;

        private ELNYInitialization elNyInitialization;

        /// <summary>
        /// Initialize : It will Initialize Logger and Property service object.
        /// </summary>
        [TestInitialize]
        public void Initialize()
        {
            //Watch the variable to know the path and name of config file
            //ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).FilePath;
            //In our case , the path is:
            //D:\WorkSpaces\CodeSpaces\KMG\MGA\UnitTest\bin\Debug\netcoreapp3.1\testhost.dll.config
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();

            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();
            this.service = new EducatorsLegalNyService(this.configuration, this.logger);
        }
        
        public void ELServiceTestInitilize()
        {
            this.model = new RaterFacadeModel();
            this.elNyInitialization = new ELNYInitialization();
            this.elNyInitialization.Initialize(this.model);
        }

        #region Test Case 1

        [TestMethod]
        /// <summary>
        /// CalculateLibilityPremiumTest1
        /// </summary>
        private void CalculateLibilityPremiumTest1()
        {
            this.ELServiceTestInitilize();
            this.elNyInitialization.InitializeELPremium(this.model);
            this.elNyInitialization.InitializeOptionalCoveragePremium(this.model);
            #region Prevalidate
            var preValidateResults = service.PreValidate(this.model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest1
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest1()
        {
            this.CalculateLibilityPremiumTest1();

            #region Calculate premium
            this.service.Calculate(this.model);
            #endregion

            #region Post validate
            var postValidateResults = service.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion
            this.CalculatePremiumAssertTest1();
            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest1();
            #endregion
            this.CalculateOptionalOtherCoverageAssertTest1();
            this.CalculateOptionalBasePremiumAssertTest1();
        }

        /// <summary>
        /// CalculatePremiumAssertTest1
        /// </summary>
        private void CalculatePremiumAssertTest1()
        { 
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.ExposureRate, Convert.ToDecimal(3.50M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.LiabilityLimitRate, Convert.ToDecimal(0));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.AggregateLimitRate, Convert.ToDecimal(1.000M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.RetentionRate, Convert.ToDecimal(0.820M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.NYEPLimitRate, Convert.ToDecimal(0));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.NYEPAggregateLimitRate, Convert.ToDecimal(1.000M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.NYEPInclusionExclusionRate, Convert.ToDecimal(0.750M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.PopulationRate, Convert.ToDecimal(1.075M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.LocationRate, Convert.ToDecimal(1.100M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.PolicyTypeRate, Convert.ToDecimal(1.000M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.YearsinCMRate, Convert.ToDecimal(1.000M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.RetroDateRate, Convert.ToDecimal(0.9100M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EPInclusionExclusionRate, Convert.ToDecimal(0.250M));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TerrorismRate, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TierRate, Convert.ToDecimal(1));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.IRPMFactor, Convert.ToDecimal(1));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.OtherModRate, Convert.ToDecimal(1));
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TierPremium, 500);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.OtherModPremium, 500);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalCoverageAssertTest1()
        {
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodLimit, 50000);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodRate, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodDeductible, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.OtherCoverageTotalPremium, 0);
        
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest1()
        {
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage != null)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageLimit, 50000);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageRate, 0);
            }
        }

        /// <summary>
        /// CalculateOptionalBasePremiumAssertTest1
        /// </summary>
        private void CalculateOptionalBasePremiumAssertTest1()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.BasePremium, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.NonModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.ManualPremium, 500);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TierPremium, 500);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.IRPMPremium, 500);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.OtherModPremium, 500);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TerrorismPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TerrorismRate, 0); 
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.ELModifiedFinalPremium, 500);
        }
        #endregion


        #region Test Case 2 for State NY
        /// <summary>
        /// CalculateLibilityPremiumTest1
        /// </summary>
        private void CalculateLibilityPremiumTest2()
        {
            this.ELServiceTestInitilize();
            this.elNyInitialization.InitializeELPremium(this.model);
            this.elNyInitialization.InitializeOptionalCoveragePremium(this.model);
            #region Prevalidate
            var preValidateResults = service.PreValidate(this.model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest1
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest2()
        {
            this.CalculateLibilityPremiumTest2();

            #region Calculate premium
            this.service.Calculate(this.model);
            #endregion

            #region Post validate
            var postValidateResults = service.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion
            this.CalculatePremiumAssertTest2();
            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest2();
            #endregion
            this.CalculateOptionalOtherCoverageAssertTest2();
            this.CalculateOptionalBasePremiumAssertTest2();
        }

        /// <summary>
        /// CalculatePremiumAssertTest1
        /// </summary>
        private void CalculatePremiumAssertTest2()
        {
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.ExposureRate, 3.5M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.LiabilityLimitRate, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.AggregateLimitRate, 1);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.RetentionRate, 0.820M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.NYEPLimitRate, 0M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.NYEPAggregateLimitRate, 1);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.NYEPInclusionExclusionRate, 0.750M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.PopulationRate, 1.075M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.LocationRate, 1.100M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.PolicyTypeRate, 1M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.YearsinCMRate, 1.000M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.RetroDateRate, 0.91M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EPInclusionExclusionRate, 0.250M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TerrorismRate, 0);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TierRate,1);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.IRPMFactor,1M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.OtherModRate,1M);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TierPremium, 500);
            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.OtherModPremium, 500);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalCoverageAssertTest2()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodLimit, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodDeductible, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.OtherCoverageTotalPremium, 0);

        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest2()
        {
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage != null)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageLimit, 50000);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageRate, 0);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageUnmodifiedPremium, 0);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageModifiedPremium, 0);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[0].OtherCoverageUnmodifiedWithoutExcessPremium, 0);

                //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[1].OtherCoverageLimit, 200000);
                //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[1].OtherCoverageRate, 0.10);
                //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[1].OtherCoverageUnmodifiedPremium, 0);
                //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[1].OtherCoverageModifiedPremium, 0);
                //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage.EducatorsLegalOtherCoverage[1].OtherCoverageUnmodifiedWithoutExcessPremium, 0);
            }
        }

        /// <summary>
        /// CalculateOptionalBasePremiumAssertTest1
        /// </summary>
        private void CalculateOptionalBasePremiumAssertTest2()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.BasePremium, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.NonModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.ManualPremium, 500);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TierPremium, 500);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.IRPMPremium, 500);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.OtherModPremium, 500);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TerrorismPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.TerrorismRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.ELModifiedFinalPremium, 500);
        }
        #endregion

        [TestCleanup()]
        public void Cleanup() { }
    }
}
