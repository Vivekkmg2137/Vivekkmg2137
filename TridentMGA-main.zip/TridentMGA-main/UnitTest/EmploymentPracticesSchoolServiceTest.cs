﻿ namespace UnitTest
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.ApiModels;
    using RaterProperty;
    using System.Configuration;
    using Microsoft.Extensions.Configuration;
    using System.IO;
    using UnitTest.Init;
    using RateEmploymentPracticesSchool;

    [TestClass]
    public class EmploymentPracticesSchoolServiceTest
    {
        /// <summary>
        /// Gets logger.
        /// </summary>
        private ILoggingManager _Logger { get; set; }
        private IConfiguration _Configuration { get; set; }

        private IEmploymentPracticesSchoolService _service;

        private RaterFacadeModel _model;

        private EPSInitialization _epsInitialization;

        /// <summary>
        /// Initialize : It will Initialize Logger and Property service object.
        /// </summary>
        [TestInitialize]
        public void Initialize()
        {
            //Watch the variable to know the path and name of config file
            //ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).FilePath;
            //In our case , the path is:
            //D:\WorkSpaces\CodeSpaces\KMG\MGA\UnitTest\bin\Debug\netcoreapp3.1\testhost.dll.config

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this._Configuration = builder.Build();


            var sqlCOnnectionString = _Configuration["ConnectionStrings:SqlDBConnection"];

            this._Logger = new Logging.LoggingManager();
            this._service = new EmploymentPracticesSchoolService(this._Configuration, this._Logger);
        }

        [TestMethod]
        public void EPServiceTestInitilize()
        {
            this._model = new RaterFacadeModel();
            this._epsInitialization = new EPSInitialization();
            this._epsInitialization.Initialize(this._model);
        }

        #region Unit Test for State= CT

        /// <summary>
        /// CalculationEPSPremiumTest1
        /// </summary>
        [TestMethod]
        public void CalculationEPSPremiumTest1()
        {
            this.EPServiceTestInitilize();
            this._epsInitialization.InitializeEPSPremium1(this._model);
            this._service.Calculate(this._model);

            this.CalculationEPSLimitPremiumTest1();
            this.CalculationEPSRetentionPremiumTest1();
            this.CalculationEPSExposerPremiumTest1();
            this.CalculateOptionalCoveragePremiumTest1();
        }       

        /// <summary>
        /// CalculationEPSLimitPremiumTest1
        /// </summary>        
        public void CalculationEPSLimitPremiumTest1()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.LiabilityLimitRate, Convert.ToDecimal(0.79));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.AggregateLimitRate, Convert.ToDecimal(1));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.RetentionRate, Convert.ToDecimal(1.050));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.PopulationRate, Convert.ToDecimal(1.250));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.LocationRate, Convert.ToDecimal(1.000));
        }

        /// <summary>
        /// CalcaulationEPSRetentionPremiumTest1
        /// </summary>        
        public void CalculationEPSRetentionPremiumTest1()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.PolicyTypeRate, Convert.ToDecimal(0.800));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.YearsinCMRate, Convert.ToDecimal(0.900));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.RetroDateRate, Convert.ToDecimal(1.120));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.LossExperienceRate, Convert.ToDecimal(1.500));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.TerrorismRate, Convert.ToDecimal(0));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.TierRate, Convert.ToDecimal(1.000));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.IRPMRate, Convert.ToDecimal(1));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.OtherModRate, Convert.ToDecimal(1));
        }

        /// <summary>
        /// CalculationEPSExposerPremiumTest1
        /// </summary>       
        public void CalculationEPSExposerPremiumTest1()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.ExposureRate, Convert.ToDecimal(4.550));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EPInclusionExclusionRate, Convert.ToDecimal(1.000));
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest1
        /// </summary>        
        public void CalculateOptionalCoveragePremiumTest1()
        {            
            this.CalculateOptionalCoverageAssertTest1();
            this.CalculateOptionalOtherCoverageAssertTest1(); 
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        public void CalculateOptionalCoverageAssertTest1()
        {
            var EPSOptionalCoverage = _model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel;
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.LiabilityLimitRate, Convert.ToDecimal(0.79)); 
            Assert.AreEqual(EPSOptionalCoverage.LossAdjustmentExpenseWrongfulActAggregateLimit, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.LossAdjustmentExpenseWrongfulActUnmodifiedPremium, Convert.ToInt32(60));
            Assert.AreEqual(EPSOptionalCoverage.LossAdjustmentExpenseWrongfulActUnmodifiedWithoutExcessPremium, Convert.ToInt32(60));
            Assert.AreEqual(EPSOptionalCoverage.EEOCLimit, Convert.ToInt32(25000));
            Assert.AreEqual(EPSOptionalCoverage.EEOCAggregateLimit, Convert.ToInt32(50000));
            Assert.AreEqual(EPSOptionalCoverage.EEOCModifiedPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.EEOCUnmodifiedPremium, Convert.ToInt32(750));
            Assert.AreEqual(EPSOptionalCoverage.EEOCUnmodifiedWithoutExcessPremium, Convert.ToInt32(750));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseLimit, Convert.ToInt32(50000));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseAggregateLimit, Convert.ToInt32(100000));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseModifiedPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium, Convert.ToInt32(1500));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseUnmodifiedWithoutExcessPremium, Convert.ToInt32(1500));           
            Assert.AreEqual(EPSOptionalCoverage.SupplExtendedReportingPeriodLimit, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.SupplExtendedReportingPeriodRate, Convert.ToDecimal(0));
            Assert.AreEqual(EPSOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium, Convert.ToInt32(0));
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        public void CalculateOptionalOtherCoverageAssertTest1()
        {
            var otherCovergaeOther = _model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel.EmploymentPracticesSchoolOtherCoverageModel;
            if (otherCovergaeOther != null)
            {
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageUnmodifiedPremium, Convert.ToInt32(20));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageModifiedPremium, Convert.ToInt32(0));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageLimit, Convert.ToInt32(20000));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageAggregateLimit, Convert.ToInt32(100));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageRate, Convert.ToDecimal(0));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageUnmodifiedWithoutExcessPremium, Convert.ToInt32(20));

                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageUnmodifiedPremium, Convert.ToInt32(40));
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageModifiedPremium, Convert.ToInt32(0));
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageLimit, Convert.ToInt32(50000));
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageAggregateLimit, Convert.ToInt32(10));
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageRate, Convert.ToDecimal(0.80));
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageUnmodifiedWithoutExcessPremium, Convert.ToInt32(40));

                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageUnmodifiedPremium, Convert.ToInt32(60));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageModifiedPremium, Convert.ToInt32(0));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageLimit, Convert.ToInt32(20000));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageAggregateLimit, Convert.ToInt32(10));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageRate, Convert.ToDecimal(0.30));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageUnmodifiedWithoutExcessPremium, Convert.ToInt32(60));
            }
        }

        #endregion

        #region Unit Test for State= MA

        /// <summary>
        /// CalculationEPSPremiumTest2
        /// </summary>
        [TestMethod]
        public void CalculationEPSPremiumTest2()
        {
            this.EPServiceTestInitilize();
            this._epsInitialization.InitializeEPSPremium2(this._model);
            this._service.Calculate(this._model);

            this.CalculationEPSLimitPremiumTest2();
            this.CalculationEPSRetentionPremiumTest2();
            this.CalculationEPSExposerPremiumTest2();
            this.CalculateOptionalCoveragePremiumTest2();
        }

        /// <summary>
        /// CalculationEPSLimitPremiumTest1
        /// </summary>        
        public void CalculationEPSLimitPremiumTest2()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.LiabilityLimitRate, Convert.ToDecimal(0.660));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.AggregateLimitRate, Convert.ToDecimal(1.015));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.RetentionRate, Convert.ToDecimal(1.000));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.PopulationRate, Convert.ToDecimal(1.200));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.LocationRate, Convert.ToDecimal(1.100));
        }

        /// <summary>
        /// CalcaulationEPSRetentionPremiumTest1
        /// </summary>        
        public void CalculationEPSRetentionPremiumTest2()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.PolicyTypeRate, Convert.ToDecimal(0.800));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.YearsinCMRate, Convert.ToDecimal(0.950));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.RetroDateRate, Convert.ToDecimal(1.140));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.LossExperienceRate, Convert.ToDecimal(1.500));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.TerrorismRate, Convert.ToDecimal(0));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.TierRate, Convert.ToDecimal(1.000));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.IRPMRate, Convert.ToDecimal(0.90));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.OtherModRate, Convert.ToDecimal(0.75));
        }

        /// <summary>
        /// CalculationEPSExposerPremiumTest1
        /// </summary>       
        public void CalculationEPSExposerPremiumTest2()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.ExposureRate, Convert.ToDecimal(4.060));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EPInclusionExclusionRate, Convert.ToDecimal(1.000));
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest1
        /// </summary>        
        public void CalculateOptionalCoveragePremiumTest2()
        {
            this.CalculateOptionalCoverageAssertTest2();
            this.CalculateOptionalOtherCoverageAssertTest2();
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        public void CalculateOptionalCoverageAssertTest2()
        {
            var EPSOptionalCoverage = _model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel;
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.LiabilityLimitRate, Convert.ToDecimal(0.660));
            Assert.AreEqual(EPSOptionalCoverage.LossAdjustmentExpenseWrongfulActAggregateLimit, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.LossAdjustmentExpenseWrongfulActUnmodifiedPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.LossAdjustmentExpenseWrongfulActUnmodifiedWithoutExcessPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.EEOCLimit, Convert.ToInt32(25000));
            Assert.AreEqual(EPSOptionalCoverage.EEOCAggregateLimit, Convert.ToInt32(50000));
            Assert.AreEqual(EPSOptionalCoverage.EEOCModifiedPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.EEOCUnmodifiedPremium, Convert.ToInt32(750));
            Assert.AreEqual(EPSOptionalCoverage.EEOCUnmodifiedWithoutExcessPremium, Convert.ToInt32(750));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseLimit, Convert.ToInt32(50000));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseAggregateLimit, Convert.ToInt32(50000));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseModifiedPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.NonMonetaryDefenseUnmodifiedWithoutExcessPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.SupplExtendedReportingPeriodLimit, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.SupplExtendedReportingPeriodRate, Convert.ToDecimal(0));
            Assert.AreEqual(EPSOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium, Convert.ToInt32(0));
            Assert.AreEqual(EPSOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedWithoutExcessPremium, Convert.ToInt32(0));
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        public void CalculateOptionalOtherCoverageAssertTest2()
        {
            var otherCovergaeOther = _model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel.EmploymentPracticesSchoolOtherCoverageModel;
            if (otherCovergaeOther != null)
            {
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageUnmodifiedPremium, Convert.ToInt32(50));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageUnmodifiedWithoutExcessPremium, Convert.ToInt32(50));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageModifiedPremium, Convert.ToInt32(0));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageLimit, Convert.ToInt32(50000));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageAggregateLimit, Convert.ToInt32(100));
                Assert.AreEqual(otherCovergaeOther[0].OtherCoverageRate, Convert.ToDecimal(0));

                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageUnmodifiedPremium, Convert.ToInt32(120));
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageUnmodifiedWithoutExcessPremium, Convert.ToInt32(120)); 
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageModifiedPremium, Convert.ToInt32(0));
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageLimit, Convert.ToInt32(150000));
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageAggregateLimit, Convert.ToInt32(100));
                Assert.AreEqual(otherCovergaeOther[1].OtherCoverageRate, Convert.ToDecimal(0.80));

                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageUnmodifiedPremium, Convert.ToInt32(50));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageUnmodifiedWithoutExcessPremium, Convert.ToInt32(50));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageModifiedPremium, Convert.ToInt32(0));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageLimit, Convert.ToInt32(50000));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageAggregateLimit, Convert.ToInt32(100));
                Assert.AreEqual(otherCovergaeOther[2].OtherCoverageRate, Convert.ToDecimal(0.10));
            }
        }

        #endregion
    }
}
