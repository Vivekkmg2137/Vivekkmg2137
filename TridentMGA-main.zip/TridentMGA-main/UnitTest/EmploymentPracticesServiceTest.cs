﻿namespace UnitTest
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.ApiModels;
    using RaterProperty;
    using System.Configuration;
    using Microsoft.Extensions.Configuration;
    using System.IO;
    using UnitTest.Init;
    using RaterEmploymentPractices;

    [TestClass]
    public class EmploymentPracticesServiceTest
    {
        /// <summary>
        /// Gets logger.
        /// </summary>
        private ILoggingManager _Logger { get; set; }

        private IConfiguration _Configuration { get; set; }

        private IEmploymentPractices _service;

        private RaterFacadeModel _model;

        private EPInitialization _epInitialization;

        /// <summary>
        /// Initialize : It will Initialize Logger and Property service object.
        /// </summary>
        [TestInitialize]
        public void Initialize()
        {
            //Watch the variable to know the path and name of config file
            //ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).FilePath;
            //In our case , the path is:
            //D:\WorkSpaces\CodeSpaces\KMG\MGA\UnitTest\bin\Debug\netcoreapp3.1\testhost.dll.config

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this._Configuration = builder.Build();

            var sqlCOnnectionString = _Configuration["ConnectionStrings:SqlDBConnection"];

            this._Logger = new Logging.LoggingManager();
            this._service = new EmploymentPracticesService(this._Configuration, this._Logger);
        }

        [TestMethod]
        public void EPServiceTestInitilize()
        {
            this._model = new RaterFacadeModel();
            this._epInitialization = new EPInitialization();
            this._epInitialization.Initialize(this._model);
        }

        #region Test Case 1
        /// <summary>
        /// CalculateLibilityPremiumTest1
        /// </summary>
        private void CalculateLibilityPremiumTest1()
        {
            this.EPServiceTestInitilize();
            this._epInitialization.InitializeLibilityPremium(this._model);
            this._epInitialization.InitializeOptionalCoveragePremium(this._model);
            #region Prevalidate
            var preValidateResults = _service.PreValidate(this._model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest1
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest1()
        {
            this.CalculateLibilityPremiumTest1();

            #region Calculate premium
            this._service.Calculate(this._model);
            #endregion

            this.CalculateLibilityLimitPremiumTest1();
            this.CalculateLibilityRetentionPremiumTest1();
            this.CalculateLibilityExposerPremiumTest1();
            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest1();
            #endregion
            this.CalculateOptionalOtherCoverageAssertTest1();
            this.CalculateOptionalBasePremiumAssertTest1();
        }

        /// <summary>
        /// CalculateLibilityLimitPremiumTest1
        /// </summary>
        private void CalculateLibilityLimitPremiumTest1()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.LiabilityLimitRate, 100000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.AggregateLimitRate, Convert.ToDecimal(1.025));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.RetentionRate, Convert.ToDecimal(1.05));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.PopulationRate, Convert.ToDecimal(1.125));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.LocationRate, Convert.ToDecimal(1.1));
        }

        /// <summary>
        /// CalculateLibilityRetentionPremiumTest1
        /// </summary>
        private void CalculateLibilityRetentionPremiumTest1()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.PolicyTypeRate, Convert.ToDecimal(0.800));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.YearsinCMRate, Convert.ToDecimal(0.850));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.RetroDateRate, Convert.ToDecimal(1.00));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.LossExperienceRate, 1);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TerrorismRate, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TierRate, 1);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.IRPMRate, 1);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.OtherModRate, 1);
        }

        /// <summary>
        /// CalculateLibilityExposerPremiumTest1
        /// </summary>
        private void CalculateLibilityExposerPremiumTest1()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.ExposureRate, 3);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EPInclusionExclusionRate, Convert.ToDecimal(0.700));
        }
       
        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalCoverageAssertTest1()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium, 10);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCLimit, 5);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit, 15);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCModifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCUnmodifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit, 10);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit, 10);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseModifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodLimit, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesUnModifiedWithoutExcessPremium, 10);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnModifiedWithoutExcessPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCUnModifiedWithoutExcessPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnModifiedWithoutExcessPremium, 0);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest1()
        {
            if (_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel != null)
            {
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageUnmodifiedPremium,0);
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageLimit, 1000);
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageRate, 10);
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageUnModifiedWithoutExcessPremium, 0);
            }
        }
     
        /// <summary>
        /// CalculateOptionalBasePremiumAssertTest1
        /// </summary>
        private void CalculateOptionalBasePremiumAssertTest1()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.BasePremium, 19018952);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.NonModifiedPremium, 10);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.ManualPremium, 19018962);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TierPremium, 19018962);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.IRPMPremium, 19018962);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.OtherModPremium, 19018962);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TerrorismPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EPTotalUnModifiedWithoutExcessPremium, 0);
        }
        #endregion

        #region Test case 2 With Sate Code ='MA'

        /// <summary>
        /// CalculateLibilityPremiumTest2
        /// </summary>
        private void CalculateLibilityPremiumTest2()
        {
            this.EPServiceTestInitilize();
            this._epInitialization.InitializeLibilityPremium2(this._model);
            this._epInitialization.InitializeOptionalCoveragePremium2(this._model);

            #region Prevalidate
            var preValidateResults = _service.PreValidate(this._model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion

        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest2
        /// </summary>
        [TestMethod]
        public void CalculateOptionalCoveragePremiumTest2()
        {
            this.CalculateLibilityPremiumTest2();

            #region Calculate premium
            this._service.Calculate(this._model);
            #endregion

            #region Post validate
            var postValidateResults = _service.PostValidate(_model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion
            this.CalculateLibilityLimitPremiumTest2();
            this.CalculateLibilityRetentionPremiumTest2();
            this.CalculateLibilityExposerPremiumTest2();

            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest2();
            #endregion

            this.CalculateOptionalOtherCoverageAssertTest2();
            this.CalculateOptionalBasePremiumAssertTest2();
        }

        /// <summary>
        /// CalculateLibilityLimitPremiumTest2
        /// </summary>
        private void CalculateLibilityLimitPremiumTest2()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.LiabilityLimitRate, Convert.ToDecimal(0.79));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.AggregateLimitRate, Convert.ToDecimal(1.015));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.RetentionRate, Convert.ToDecimal(0.960));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.PopulationRate, Convert.ToDecimal(1.20));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.LocationRate, Convert.ToDecimal(1.10));
        }

        /// <summary>
        /// CalculateLibilityRetentionPremiumTest2
        /// </summary>
        private void CalculateLibilityRetentionPremiumTest2()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.PolicyTypeRate, Convert.ToDecimal(0.800));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.YearsinCMRate, Convert.ToDecimal(0.950));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.RetroDateRate, Convert.ToDecimal(1.12));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.LossExperienceRate, Convert.ToDecimal(1.50));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TerrorismRate, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TierRate, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.IRPMRate, 1);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.OtherModRate, 1);
        }

        /// <summary>
        /// CalculateLibilityExposerPremiumTest2
        /// </summary>
        private void CalculateLibilityExposerPremiumTest2()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.ExposureRate, Convert.ToDecimal(1.09));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EPInclusionExclusionRate, 1);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest2
        /// </summary>
        private void CalculateOptionalCoverageAssertTest2()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium, 60);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCLimit, 10000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit, 50000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCModifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCUnmodifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit, 50000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit, 200000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseModifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium, 2000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodLimit, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedWithoutExcessPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesUnModifiedWithoutExcessPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnModifiedWithoutExcessPremium, 2000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCUnModifiedWithoutExcessPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnModifiedWithoutExcessPremium, 60);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest2
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest2()
        {
            if (_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel != null)
            {
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageUnmodifiedPremium, 20);
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageLimit, 20000);
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageRate, 10);
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageUnModifiedWithoutExcessPremium, 20);
            }
        }
      
        /// <summary>
        /// CalculateOptionalBasePremiumAssertTest2
        /// </summary>
        private void CalculateOptionalBasePremiumAssertTest2()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.BasePremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.NonModifiedPremium, 2483);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.ManualPremium, 2483);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TierPremium, 2483);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.IRPMPremium, 2483);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.OtherModPremium, 2483);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TerrorismPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EPTotalUnModifiedWithoutExcessPremium, 403);
        }
        #endregion

        #region Test case 3 With Sate Code ='HO'

        /// <summary>
        /// CalculateLibilityPremiumTest3
        /// </summary>
        private void CalculateLibilityPremiumTest3()
        {
            this.EPServiceTestInitilize();
            this._epInitialization.InitializeLibilityPremium3(this._model);
            this._epInitialization.InitializeOptionalCoveragePremium3(this._model);

            #region Prevalidate
            var preValidateResults = _service.PreValidate(this._model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest3
        /// </summary>
        [TestMethod]
        public void CalculateOptionalCoveragePremiumTest3()
        {
            this.CalculateLibilityPremiumTest3();

            #region Calculate premium
            this._service.Calculate(this._model);
            #endregion
            #region Post validate
            var postValidateResults = _service.PostValidate(_model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion
            this.CalculateLibilityLimitPremiumTest3();
            this.CalculateLibilityRetentionPremiumTest3();
            this.CalculateLibilityExposerPremiumTest3();
            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest3();
            #endregion
            this.CalculateOptionalOtherCoverageAssertTest3();
            this.CalculateOptionalBasePremiumAssertTest3();
        }

        /// <summary>
        /// CalculateLibilityLimitPremiumTest3
        /// </summary>
        private void CalculateLibilityLimitPremiumTest3()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.LiabilityLimitRate, Convert.ToDecimal(0.87));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.AggregateLimitRate, Convert.ToDecimal(1.015));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.RetentionRate, Convert.ToDecimal(0.780));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.PopulationRate, Convert.ToDecimal(1.3));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.LocationRate, 1);
        }

        /// <summary>
        /// CalculateLibilityRetentionPremiumTest3
        /// </summary>
        private void CalculateLibilityRetentionPremiumTest3()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.PolicyTypeRate, 1);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.YearsinCMRate, 1);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.RetroDateRate, 1);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.LossExperienceRate, 1);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TerrorismRate, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TierRate, 1);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.IRPMRate, Convert.ToDecimal(1.2));
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.OtherModRate, Convert.ToDecimal(0.75));
        }

        /// <summary>
        /// CalculateLibilityExposerPremiumTest3
        /// </summary>
        private void CalculateLibilityExposerPremiumTest3()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.ExposureRate, 5);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EPInclusionExclusionRate, 1);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest3
        /// </summary>
        private void CalculateOptionalCoverageAssertTest3()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCLimit, 10000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit, 50000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCModifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCUnmodifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit, 50000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit, 200000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseModifiedPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium, 2000);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodLimit, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest3
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest3()
        {
            if (_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel != null)
            {
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageUnmodifiedPremium, 5);
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageLimit, 10000);
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageRate, Convert.ToDecimal(0.5));
                Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel[0].OtherCoverageUnModifiedWithoutExcessPremium, 5);
            }
        }

        /// <summary>
        /// CalculateOptionalBasePremiumAssertTest3
        /// </summary>
        private void CalculateOptionalBasePremiumAssertTest3()
        {
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.BasePremium, 1119);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.NonModifiedPremium, 2095);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.ManualPremium, 3214);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TierPremium, 3214);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.IRPMPremium, 3438);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.OtherModPremium, 3102);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.TerrorismPremium, 0);
            Assert.AreEqual(_model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EPTotalUnModifiedWithoutExcessPremium, 90);
        }
        #endregion
    }
}
