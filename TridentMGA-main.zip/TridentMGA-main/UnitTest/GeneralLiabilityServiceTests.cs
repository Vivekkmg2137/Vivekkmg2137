﻿namespace UnitTest
{
    using Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.ApiModels;
    using RaterGeneralLiability;
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    using System.IO;
    using UnitTest.Init;


    [TestClass]
    public class GeneralLiabilityServiceTests
    {
        private IGeneralLiabilityService generalLiabilityService;
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }

        private RaterFacadeModel model;

        private GeneralLiabilityInitialization generalLiabilityInitialization;

        [TestInitialize]
        public void Initialize()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();


            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();

            this.generalLiabilityService = new GeneralLiabilityService(this.configuration, this.logger);

        }

        public GeneralLiabilityServiceTests()
        {
            this.model = new RaterFacadeModel();
            this.generalLiabilityInitialization = new GeneralLiabilityInitialization();

            generalLiabilityInitialization.Initialize(this.model);



        }

        [TestMethod]
        public void CalculatePremiumTest1()
        {
            generalLiabilityInitialization.InitializationGLCase1(this.model);

            generalLiabilityService.Calculate(this.model);

            CalculateBasePremiumTest1(this.model);

            CalculateDamageToPremisesPremiumTest1(this.model);

            CalculateMedicalPaymentsPremiumTest1(this.model);

            CalculateEmployeeBenefitsPremiumTest1(this.model);

            CalculateDataCompromisePremiumTest1(this.model);

            CalculateCyberPremiumTest1(this.model);

            CalculateUnmannedAircraftTotalPremiumTest1(this.model);

            CalculateOptionalCoveragePremiumTest1(this.model);

            CalculateNonModifiedPremiumTest1(this.model);

            CalculateModifiablePremiumTest1(this.model);

            CalculateManualPremiumTest1(this.model);

            CalculateTierPremiumTest1(this.model);

            CalculateIRPMPremiumTest1(this.model);

            CalculateOtherModPremiumTest1(this.model);

            CalculateTerrorismPremiumTest1(this.model);

            CalculateFinalModifiedPremiumTest1(this.model);

            CalculateTotalUnmodifiedWithoutExcessPremiumTest1(this.model);
        }


        public void CalculateBasePremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.BasePremium, 25);
        }

        public void CalculateDamageToPremisesPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.DamageToPremisesUnmodifiedPremium, 1000);
        }

        public void CalculateMedicalPaymentsPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.MedicalPaymentsUnmodifiedPremium, 1000);
        }

        public void CalculateEmployeeBenefitsPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.EBUnmodifiedPremium, 0);
        }

        public void CalculateDataCompromisePremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.TotalDataCompromiseUnmodifiedPremium, 100);
        }

        public void CalculateCyberPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.TotalCyberUnmodifiedPremium, 0);
        }

        public void CalculateUnmannedAircraftTotalPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.UnmannedAircraftModifiedTotalPremium, 0);
        }

        public void CalculateOptionalCoveragePremiumTest1(RaterFacadeModel model)
        {
            var outputOptionalProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;
            Assert.AreEqual(outputOptionalProperty.CemeteryProfessionalLiabilityGL203UnmodifiedPremium, 10000);
            Assert.AreEqual(outputOptionalProperty.CyberSupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.EmployersLiabilityGL600UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.FailuretoSupplyExclusionGL304UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.FailuretoSupplySublimitGL211UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.FellowEmployeeGL206UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.LimitedPollutionCoverageGL210UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.PAHeartAndLungBenefitsLimitperOfficerGL801UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.PAHeartAndLungBenefitsPolicyLevelAggregateGL800UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.PesticideorHerbicideApplicatorAG7314UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.SchoolViolentEventResponseAGGL1000UnmodifiedPremium, 0);

            Assert.AreEqual(outputOptionalProperty.SewerBackupAggregateLimitGL217UnmodifiedPremium, 10000);
            Assert.AreEqual(outputOptionalProperty.SewerBackupSublimitGL260UnmodifiedPremium, 10000);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredControllingInterestCG2005UnmodifiedPremium, 10000);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium, 10000);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305UnmodifiedPremium, 0);

            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium, 10000);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium, 10000);

            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium, 10000);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium, 10000);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium, 0);
            Assert.AreEqual(outputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium, 10000);
            Assert.AreEqual(outputOptionalProperty.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium, 0);

        }

        public void CalculateNonModifiedPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.NonModifiedPremium, 102100);
        }

        public void CalculateModifiablePremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.ModifiablePremium, 0);
        }

        public void CalculateManualPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.ManualPremium, 102125);
        }

        public void CalculateTierPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.TierPremium, 102125);
        }

        public void CalculateIRPMPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.IRPMPremium, 102125);
        }

        public void CalculateOtherModPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.OtherModPremium, 102125);
        }

        public void CalculateTerrorismPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.TerrorismPremium, 102122);
        }

        public void CalculateFinalModifiedPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GLFinalModifiedPremium, 204247);
        }

        public void CalculateTotalUnmodifiedWithoutExcessPremiumTest1(RaterFacadeModel model)
        {

            Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GLTotalUnmodifiedwithoutExcessPremium, 102100);
        }

        [TestCleanup()]
        public void Cleanup() { }
    }

}

