﻿using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoLiability.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoPhysicalDamage.Output;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Input;
using Models.ApiModels.LineOfBusiness.Auto.AutoSchedule.Output;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class AutoInitialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }

            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.Auto = true;
            
            
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto = new Models.ApiModels.LineOfBusiness.Auto.AutoInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW = new Models.ApiModels.LineOfBusiness.Auto.CWInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel = new AutoLiabilityInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel = new AutoLiabilityOptionalCoverageInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AutoLiabilityOptionalOtherCoverageInputModels = new List<AutoLiabilityOptionalOtherCoverageInputModel>();

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel = new AutoPhysicalDamageInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.AutoPhysicalDamageOptionalCoverageInputModel = new AutoPhysicalDamageOptionalCoverageInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.AutoPhysicalDamageOptionalCoverageInputModel.AutoPhysicalDamageOptionalOtherCoverageInputModels = new List<AutoPhysicalDamageOptionalOtherCoverageInputModel>();

            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto = new Models.ApiModels.LineOfBusiness.Auto.AutoOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW = new Models.ApiModels.LineOfBusiness.Auto.OutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel = new AutoLiabilityOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel = new AutoLiabilityOptionalCoverageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AutoLiabilityOptionalOtherCoverageOutputModels = new List<AutoLiabilityOptionalOtherCoverageOutputModel>();

            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel = new AutoPhysicalDamageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel = new AutoPhysicalDamageOptionalCoverageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.AutoPhysicalDamageOptionalOtherCoverageOutputModels = new List<AutoPhysicalDamageOptionalOtherCoverageOutputModel>();

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel = new List<AutoScheduleVehiclesDetailsInputModel>();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoScheduleRatingOutputModel = new AutoScheduleVehiclesDetailsOutputModel();

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.HasAutoPhysicalDamage = true;


            //Initilized for NY

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY = new Models.ApiModels.LineOfBusiness.Auto.CWInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel = new AutoLiabilityInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel = new AutoLiabilityOptionalCoverageInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel.AutoLiabilityOptionalOtherCoverageInputModels = new List<AutoLiabilityOptionalOtherCoverageInputModel>();

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoPhysicalDamageInputModel = new AutoPhysicalDamageInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoPhysicalDamageInputModel.AutoPhysicalDamageOptionalCoverageInputModel = new AutoPhysicalDamageOptionalCoverageInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoPhysicalDamageInputModel.AutoPhysicalDamageOptionalCoverageInputModel.AutoPhysicalDamageOptionalOtherCoverageInputModels = new List<AutoPhysicalDamageOptionalOtherCoverageInputModel>();

            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY = new Models.ApiModels.LineOfBusiness.Auto.OutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel = new AutoLiabilityOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel = new AutoLiabilityOptionalCoverageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel.AutoLiabilityOptionalCoveragesOutputModel.AutoLiabilityOptionalOtherCoverageOutputModels = new List<AutoLiabilityOptionalOtherCoverageOutputModel>();

            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel = new AutoPhysicalDamageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel = new AutoPhysicalDamageOptionalCoverageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel.AutoPhysicalDamageOptionalCoveragesModel.AutoPhysicalDamageOptionalOtherCoverageOutputModels = new List<AutoPhysicalDamageOptionalOtherCoverageOutputModel>();

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel = new List<AutoScheduleVehiclesDetailsInputModel>();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoScheduleRatingOutputModel = new AutoScheduleVehiclesDetailsOutputModel();

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.HasAutoPhysicalDamage = true;

        }

        #region Initialize Auto AL for NC state
        public void InitializationAutoALCase1(RaterFacadeModel raterFacadeModel)
        {

            InitializeAutoALLiablityPremiumCase1(raterFacadeModel);

            InitializeAutoALPIPPremiumCase1(raterFacadeModel);

            InitializeAutoALPIPPremiumCase1(raterFacadeModel);

            InitializeAutoALMEDPremiumCase1(raterFacadeModel);

            InitializeAutoALUMPremiumCase1(raterFacadeModel);

            InitializeAutoALUMBIPDPremiumCase1(raterFacadeModel);

            InitializeAutoALUIMCase1(raterFacadeModel);

            InitializeAutoALHiredandNonOwnedPremiumCase1(raterFacadeModel);

            InitializeAutoALOptionalCoveragesPremiumCase1(raterFacadeModel);

            InitializeAutoALTierPremiumCase1(raterFacadeModel);

            InitializeAutoALIRPMPremiumCase1(raterFacadeModel);

            InitializeAutoALOtherModPremiumCase1(raterFacadeModel);

            InitializeAutoALMIMCCAAssessementChargeCase1(raterFacadeModel);

            InitializeAutoScheduleRatingCase1(raterFacadeModel);
        }

        #region Liablity Premium

        private void InitializeAutoALLiablityPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            #region PolicyHeaderModel

            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 3500;
            model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage = true;
            model.RaterInputFacadeModel.PolicyHeaderModel.IsEndorsement = false;

            //Case 1 Get BaseRate
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.NC;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Rural";

            #endregion

            inputProperty.NonEmergencyPIPUnitsCount = 6;
            inputProperty.EmergencyPIPUnitsCount = 1;
            inputProperty.BusesPIPUnitsCount = 2;
            inputProperty.TotalPIPUnitswithoutTrailersCount = 9;

            inputProperty.NonEmergencyMedPayUnitsCount = 6;
            inputProperty.EmergencyMedPayUnitsCount = 1;
            inputProperty.BusesMedPayUnitsCount = 2;
            inputProperty.TotalMedPayUnitswithoutTrailersCount = 9;

            inputProperty.NonEmergencyUnitsCount = 6;
            inputProperty.EmergencyUnitsCount = 1;
            inputProperty.BusesCount = 2;
            inputProperty.TrailersCount = 1;
            inputProperty.TotalVehicleswithoutTrailersCount = 9;


            //Case 2 Get LimitFactor
            inputProperty.LimitType = "CSL";
            inputProperty.LiabilityLimit = "1000000";
            inputProperty.LiabilityLimitRate = 1;

            //Case 3 Get DeductibleFactor
            inputProperty.Deductible_SIR = "Deductible";
            inputProperty.Retention = 0;


            inputProperty.NonEmergencyUnitsBaseRate = 296;
            inputProperty.EmergencyUnitsBaseRate = 338.29M;
            inputProperty.BusesBaseRate = 422.86M;

            // UI 
            inputProperty.Expense = "Excluded";
            inputProperty.AggregateRetention = 0;
            inputProperty.MedPayAggregate = 10000;
            inputProperty.PIPDeductible = "";
            inputProperty.AdditionalPIPLimit = "";
            inputProperty.AdditionalMonthlyWorkLossLimit = 0;
            inputProperty.AdditionalPIPOtherExpensesPerDayLimit = 0;
            inputProperty.AdditionalDeathBenefitLimit = "";
            inputProperty.OBELLimit = "";
            inputProperty.PIPMedicalExpenseEliminationLimit = "";
            inputProperty.LiabilitySymbol = "2";
            inputProperty.MedicalPaymentsSymbol = "3";
            inputProperty.PersonalInjuryProtectionSymbol = "1";
            inputProperty.UnderinsuredMotoristSymbol = "4";
            inputProperty.UninsuredMotoristSymbol = "5";
            inputProperty.IRPMApplies = true;
        }

        #endregion

        #region PIP Premium 

        private void InitializeAutoALPIPPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            inputProperty.PersonalInjuryProtectionLimit = "EXCLUDED";

            inputProperty.ExcessAttendantCareLimit = "";

        }

        #endregion

        #region  MED Premium

        private void InitializeAutoALMEDPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            inputProperty.MedicalPaymentsLimit = "5000";

        }

        #endregion

        #region UM Premiumm

        private void InitializeAutoALUMPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            inputProperty.UMUIMStacking = false;
            inputProperty.UninsuredLimit = "1000000";

        }

        #endregion

        #region UM BI/PD Premium

        private void InitializeAutoALUMBIPDPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            //Case 1 Get UMBIPDRate
            inputProperty.UninsuredBIPDLimit = "";
        }

        #endregion

        #region UIM permium

        private void InitializeAutoALUIMCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            //Case 1 Get UIMRate
            inputProperty.UnderinsuredConversion = false;
            inputProperty.UnderinsuredLimit = "";
        }

        #endregion

        #region  Hired and NonOwned Premium

        private void InitializeAutoALHiredandNonOwnedPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;


            //Case 1 Get Hired and NonOwned Premium
            inputProperty.HiredAndNonOwned = "Excluded";
        }

        #endregion

        #region Optional Coverages Premium

        private void InitializeAutoALOptionalCoveragesPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            #region OptionalCoverage Initialization

            inputProperty.AutoLiabilityOptionalCoverageInputModel = new AutoLiabilityOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.AutoLiabilityOptionalCoverageInputModel;

            inputOptionalCoverage.AdditionalInsuredDesignatedPersonOrOrganizationCA201IsSelected = false;
            inputOptionalCoverage.AdditionalInsuredEndorsementAutoAG1009IsSelected = false;
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001IsSelected = false;
            inputOptionalCoverage.MutualAidIsSelected = false;

            inputOptionalCoverage.AutoLiabilityOptionalOtherCoverageInputModels = new List<AutoLiabilityOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.AutoLiabilityOptionalOtherCoverageInputModels.Add(new AutoLiabilityOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 0,
                OtherCoverageDescription = "",
                OtherCoverageLimit = 0,
                OtherCoverageDedcutible = 0,
                OtherCoverageRate = 0,
                OtherCoverageRatingBasis = "",
                OtherCoverageReturnMethod = "",
                OtherCoveragePremium = 0

            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel = inputOptionalCoverage;

            #endregion
        }

        #endregion

        #region Calculate Tier Premium

        private void InitializeAutoALTierPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel;
            //Case 1 Get Tier Factor
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Preferred";
        }

        #endregion

        #region Calculate IRPM Premium
        private void InitializeAutoALIRPMPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel;


            //Case 1 Get Tier Factor
            inputProperty.IRPMRate = 0.7M;
        }

        #endregion

        #region Calculate OtherMod Premium
        private void InitializeAutoALOtherModPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel;


            //Case 1 Get Tier Factor
            inputProperty.OtherModRate = 1;
        }

        #endregion

        #region Calculate MI MCCA Assessement Charge 

        private void InitializeAutoALMIMCCAAssessementChargeCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;


            //Case 1 MI MCCA Assessement Charge
            inputProperty.BasicFPBLimit = "";
        }

        #endregion

        #endregion

        #region Initialize Auto APD for NC state
        public void InitializationAutoAPDCase1(RaterFacadeModel raterFacadeModel)
        {
            InitializeAutoAPDCollCompAndSpecifiedCasueofLossPremiumCase1(raterFacadeModel);

            InitializeAutoAPDOptionalCoveragesPremiumCase1(raterFacadeModel);

            InitializeAutoAPDIRPMPremiumCase1(raterFacadeModel);

            InitializeAutoAPDOtherModPremiumCase1(raterFacadeModel);

           // InitializeAutoScheduleRatingCase1(raterFacadeModel);
        }

        #region Initialize CollCompAndSpecifiedCasueofLoss Premium 
        private void InitializeAutoAPDCollCompAndSpecifiedCasueofLossPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel;

            inputProperty.CompBaseRate = 0.35M;
            inputProperty.CollisionBaseRate = 0.3M;
            inputProperty.SpecCauseofLossBaseRate = 0.6M;

            inputProperty.NonEmergencyUnitsCount = 6;
            inputProperty.EmergencyUnitsCount = 1;
            inputProperty.BusesCount = 3;
            inputProperty.TrailersCount = 0;
            inputProperty.TotalVehiclesCount = 10;
            inputProperty.TotalVehicleswithoutTrailersCount = 10;
            inputProperty.CompVehiclesCount = 10;

            inputProperty.ComprehensiveSymbol = "1";
            inputProperty.CollisionSymbol = "2";
            inputProperty.SpecifiedCauseofLossSymbol = "3";

            inputProperty.IRPMApplies = true;
        }

        #endregion

        #region Initialize Optional Coverages Premium

        private void InitializeAutoAPDOptionalCoveragesPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel;

            #region OptionalCoverage Initialization

            inputProperty.AutoPhysicalDamageOptionalCoverageInputModel = new AutoPhysicalDamageOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.AutoPhysicalDamageOptionalCoverageInputModel;

            inputOptionalCoverage.GaragekeepersCA9937CoverageID = 1;
            inputOptionalCoverage.GaragekeepersCA9937IsSelected = true;
            inputOptionalCoverage.GaragekeepersCA9937Limit = 50000;
            inputOptionalCoverage.GaragekeepersCA9937Deductible = 0;
            inputOptionalCoverage.GaragekeepersCA9937RatingBasis = "PER 1000 OF LIMIT";
            inputOptionalCoverage.GaragekeepersCA9937ReturnMethod = "Pro rata";
            inputOptionalCoverage.GaragekeepersCA9937Rate = 3;
            inputOptionalCoverage.GaragekeepersCA9937Premium = 150;

            inputOptionalCoverage.RentalReimbursementCA9923CoverageID = 2;
            inputOptionalCoverage.RentalReimbursementCA9923IsSelected = true;
            inputOptionalCoverage.RentalReimbursementCA9923Limit = 20000;
            inputOptionalCoverage.RentalReimbursementCA9923Deductible = 0;
            inputOptionalCoverage.RentalReimbursementCA9923RatingBasis = "Flat charge";
            inputOptionalCoverage.RentalReimbursementCA9923ReturnMethod = "Pro rata";
            inputOptionalCoverage.RentalReimbursementCA9923Rate = 0;
            inputOptionalCoverage.RentalReimbursementCA9923Premium = 20;

            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004CoverageID = 3;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004IsSelected = true;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Limit = 10000;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Deductible = 0;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004RatingBasis = "Flat charge";
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004ReturnMethod = "Pro rata";
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Rate = 0;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Premium = 20;

            inputOptionalCoverage.FullSafetyGlassCoverageCA0421CoverageID = 4;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421IsSelected = true;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Limit = 0;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Deductible = 0;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421RatingBasis = "APD Comprehensive premium";
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421ReturnMethod = "Pro rata";
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Rate = 2;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Premium = 10;

            inputOptionalCoverage.AutoPhysicalDamageOptionalOtherCoverageInputModels = new List<AutoPhysicalDamageOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.AutoPhysicalDamageOptionalOtherCoverageInputModels.Add(new AutoPhysicalDamageOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 5,
                OtherCoverageDescription = "OTHER",
                OtherCoverageLimit = 30000,
                OtherCoverageDedcutible = 0,
                OtherCoverageRate = 0,
                OtherCoverageRatingBasis = "Flat charge",
                OtherCoverageReturnMethod = "Pro rata",
                OtherCoveragePremium = 50

            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.AutoPhysicalDamageOptionalCoverageInputModel = inputOptionalCoverage;

            #endregion
        }

        #endregion

        #region Initialize Calculate IRPM Premium
        private void InitializeAutoAPDIRPMPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel;


            //Case 1 Get IRPMRate Factor
            inputProperty.IRPMRate = 1;
        }

        #endregion

        #region Initialize Calculate OtherMod Premium
        private void InitializeAutoAPDOtherModPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel;


            //Case 1 Get Tier Factor
            inputProperty.OtherModRate = 1;
        }

        #endregion

        #region Initialize Calculate Auto ScheduleRating
        private void InitializeAutoScheduleRatingCase1(RaterFacadeModel model)
        {
            var inputAutoScheduleRating = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel;

            #region Auto Vehicles Schedule

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 1,
                VIN = "CD534534534534500",
                Make = "Ford",
                Model = "Private Passenger",
                Year = 2005,
                ClassCode = "7398",
                RatingGroup = "Non Emergency",
                OCN = 20000,
                Valuation = "Actual Cash Value",
                CompDeductible = 250,
                CollDeductible = 250,
                SpecifiedCauseofLossDeductible = 250,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 2,
                VIN = "AB534534534534500",
                Make = "Cadillac",
                Model = "Antique Autos",
                Year = 1999,
                ClassCode = "9620",
                RatingGroup = "Non Emergency",
                OCN = 10000,
                Valuation = "Stated Amount",
                CompDeductible = 500,
                CollDeductible = 500,
                SpecifiedCauseofLossDeductible = 500,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 3,
                VIN = "DE534534534534500",
                Make = "Mercedes",
                Model = "Trailer",
                Year = 2007,
                ClassCode = "211-790",
                RatingGroup = "Non Emergency",
                OCN = 50000,
                Valuation = "Replacement Cost",
                CompDeductible = 1000,
                CollDeductible = 1000,
                SpecifiedCauseofLossDeductible = 1000,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 4,
                VIN = "FG534534534534500",
                Make = "Land Rover",
                Model = "All Other Bus",
                Year = 2008,
                ClassCode = "6584",
                RatingGroup = "Buses",
                OCN = 10000,
                Valuation = "Actual Cash Value",
                CompDeductible = 100,
                CollDeductible = 100,
                SpecifiedCauseofLossDeductible = 100,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 5,
                VIN = "HI534534534534500",
                Make = "GMC",
                Model = "Snowmobiles",
                Year = 2009,
                ClassCode = "6181",
                RatingGroup = "Buses",
                OCN = 10000,
                Valuation = "Stated Amount",
                CompDeductible = 500,
                CollDeductible = 500,
                SpecifiedCauseofLossDeductible = 500,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 6,
                VIN = "JK534534534534500",
                Make = "Dodge",
                Model = "Ambulance",
                Year = 2010,
                ClassCode = "7919",
                RatingGroup = "Emergency",
                OCN = 10000,
                Valuation = "Replacement Cost",
                CompDeductible = 1000,
                CollDeductible = 1000,
                SpecifiedCauseofLossDeductible = 1000,
            });


            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 7,
                VIN = "LM534534534534500",
                Make = "BMW Motors",
                Model = "SC Bus",
                Year = 2011,
                ClassCode = "6183",
                RatingGroup = "Buses",
                OCN = 5000,
                Valuation = "Actual Cash Value",
                CompDeductible = 100,
                CollDeductible = 250,
                SpecifiedCauseofLossDeductible = 250,
            });


            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 8,
                VIN = "MN534534534534500",
                Make = "Audi",
                Model = "Social Service Bus-Employee Operated",
                Year = 2012,
                ClassCode = "6481",
                RatingGroup = "Buses",
                OCN = 10000,
                Valuation = "Stated Amount",
                CompDeductible = 500,
                CollDeductible = 500,
                SpecifiedCauseofLossDeductible = 500,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 9,
                VIN = "OP534534534534500",
                Make = "Buick",
                Model = "Light dump",
                Year = 2013,
                ClassCode = "014-790",
                RatingGroup = "Non Emergency",
                OCN = 10000,
                Valuation = "Replacement Cost",
                CompDeductible = 1000,
                CollDeductible = 1000,
                SpecifiedCauseofLossDeductible = 1000,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 10,
                VIN = "PQ534534534534500",
                Make = "Tesla",
                Model = "All Other Bus",
                Year = 2014,
                ClassCode = "6581",
                RatingGroup = "Buses",
                OCN = 5000,
                Valuation = "Actual Cash Value",
                CompDeductible = 250,
                CollDeductible = 100,
                SpecifiedCauseofLossDeductible = 250,
            });

        }

        #endregion

        #endregion

        #endregion



        #region Initialize Auto AL for PA state
        public void InitializationAutoALCase2(RaterFacadeModel raterFacadeModel)
        {

            InitializeAutoALLiablityPremiumCase2(raterFacadeModel);

            InitializeAutoALPIPPremiumCase2(raterFacadeModel);

            InitializeAutoALPIPPremiumCase2(raterFacadeModel);

            InitializeAutoALMEDPremiumCase2(raterFacadeModel);

            InitializeAutoALUMPremiumCase2(raterFacadeModel);

            InitializeAutoALUMBIPDPremiumCase2(raterFacadeModel);

            InitializeAutoALUIMCase2(raterFacadeModel);

            InitializeAutoALHiredandNonOwnedPremiumCase2(raterFacadeModel);

            InitializeAutoALOptionalCoveragesPremiumCase2(raterFacadeModel);

            InitializeAutoALTierPremiumCase2(raterFacadeModel);

            InitializeAutoALIRPMPremiumCase2(raterFacadeModel);

            InitializeAutoALOtherModPremiumCase2(raterFacadeModel);

            InitializeAutoALMIMCCAAssessementChargeCase2(raterFacadeModel);

            InitializeAutoScheduleRatingCase2(raterFacadeModel);
        }

        #region Liablity Premium

        private void InitializeAutoALLiablityPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            #region PolicyHeaderModel

            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 25000;
            model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage = true;
            model.RaterInputFacadeModel.PolicyHeaderModel.IsEndorsement = false;

            //Case 1 Get BaseRate
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.PA;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "CO";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";

            #endregion


            inputProperty.NonEmergencyPIPUnitsCount = 4;
            inputProperty.EmergencyPIPUnitsCount = 1;
            inputProperty.BusesPIPUnitsCount = 2;
            inputProperty.TotalPIPUnitswithoutTrailersCount = 9;

            inputProperty.NonEmergencyMedPayUnitsCount = 6;
            inputProperty.EmergencyMedPayUnitsCount = 1;
            inputProperty.BusesMedPayUnitsCount = 2;
            inputProperty.TotalMedPayUnitswithoutTrailersCount = 9;

            inputProperty.NonEmergencyUnitsCount = 6;
            inputProperty.EmergencyUnitsCount = 1;
            inputProperty.BusesCount = 2;
            inputProperty.TrailersCount = 1;
            inputProperty.TotalVehicleswithoutTrailersCount = 9;


            //Case 2 Get LimitFactor
            inputProperty.LimitType = "CSL";
            inputProperty.LiabilityLimit = "1000000";
            inputProperty.LiabilityLimitRate = 1;

            //Case 3 Get DeductibleFactor
            inputProperty.Deductible_SIR = "Deductible";
            inputProperty.Retention = 0;


            inputProperty.NonEmergencyUnitsBaseRate = 350;
            inputProperty.EmergencyUnitsBaseRate = 400;
            inputProperty.BusesBaseRate = 500;

            // UI 
            inputProperty.Expense = "Included";
            inputProperty.AggregateRetention = 1;
            inputProperty.MedPayAggregate = 0;
            inputProperty.PIPDeductible = "";
            inputProperty.AdditionalPIPLimit = "";
            inputProperty.AdditionalMonthlyWorkLossLimit = 0;
            inputProperty.AdditionalPIPOtherExpensesPerDayLimit = 0;
            inputProperty.AdditionalDeathBenefitLimit = "";
            inputProperty.OBELLimit = "";
            inputProperty.PIPMedicalExpenseEliminationLimit = "";
            inputProperty.LiabilitySymbol = "1";
            inputProperty.MedicalPaymentsSymbol = "5";
            inputProperty.PersonalInjuryProtectionSymbol = "3";
            inputProperty.UnderinsuredMotoristSymbol = "2";
            inputProperty.UninsuredMotoristSymbol = "8";
            inputProperty.IRPMApplies = true;

        }

        #endregion

        #region PIP Premium 

        private void InitializeAutoALPIPPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            inputProperty.PersonalInjuryProtectionLimit = "EXCLUDED";

            inputProperty.ExcessAttendantCareLimit = "";

        }

        #endregion

        #region  MED Premium

        private void InitializeAutoALMEDPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            inputProperty.MedicalPaymentsLimit = "";

        }

        #endregion

        #region UM Premiumm

        private void InitializeAutoALUMPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            inputProperty.UMUIMStacking = true;
            inputProperty.UninsuredLimit = "50000";

        }

        #endregion

        #region UM BI/PD Premium

        private void InitializeAutoALUMBIPDPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            //Case 1 Get UMBIPDRate
            inputProperty.UninsuredBIPDLimit = "";
        }

        #endregion

        #region UIM permium

        private void InitializeAutoALUIMCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            //Case 1 Get UIMRate
            inputProperty.UnderinsuredConversion = false;
            inputProperty.UnderinsuredLimit = "250000";
        }

        #endregion

        #region  Hired and NonOwned Premium

        private void InitializeAutoALHiredandNonOwnedPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;


            //Case 1 Get Hired and NonOwned Premium
            inputProperty.HiredAndNonOwned = "Excluded";
        }

        #endregion

        #region Optional Coverages Premium

        private void InitializeAutoALOptionalCoveragesPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;

            #region OptionalCoverage Initialization

            inputProperty.AutoLiabilityOptionalCoverageInputModel = new AutoLiabilityOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.AutoLiabilityOptionalCoverageInputModel;

            inputOptionalCoverage.AdditionalInsuredDesignatedPersonOrOrganizationCA201IsSelected = false;
            inputOptionalCoverage.AdditionalInsuredEndorsementAutoAG1009IsSelected = false;
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001IsSelected = true;
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001CoverageID = 1;
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001Limit = 0;
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001Deductible = 0;
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001Rate = 0;
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001RatingBasis = "Flat charge";
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001ReturnMethod = "Fully earned";
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremium = 40;
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001ModifiedPremium = 0;

            inputOptionalCoverage.MutualAidIsSelected = false;

            inputOptionalCoverage.AutoLiabilityOptionalOtherCoverageInputModels = new List<AutoLiabilityOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.AutoLiabilityOptionalOtherCoverageInputModels.Add(new AutoLiabilityOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 2,
                OtherCoverageDescription = "OTHER",
                OtherCoverageLimit = 5000,
                OtherCoverageDedcutible = 0,
                OtherCoverageRate = 0,
                OtherCoverageRatingBasis = "Flat charge",
                OtherCoverageReturnMethod = "Pro rata",
                OtherCoveragePremium = 60

            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel = inputOptionalCoverage;

            #endregion
        }

        #endregion

        #region Calculate Tier Premium

        private void InitializeAutoALTierPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel;
            //Case 1 Get Tier Factor
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Preferred";
        }

        #endregion

        #region Calculate IRPM Premium
        private void InitializeAutoALIRPMPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel;


            //Case 1 Get Tier Factor
            inputProperty.IRPMRate = 0.6M;
        }

        #endregion

        #region Calculate OtherMod Premium
        private void InitializeAutoALOtherModPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoLiabilityOutputModel;


            //Case 1 Get Tier Factor
            inputProperty.OtherModRate = 0.02M;
        }

        #endregion

        #region Calculate MI MCCA Assessement Charge 

        private void InitializeAutoALMIMCCAAssessementChargeCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoLiabilityInputModel;


            //Case 1 MI MCCA Assessement Charge
            inputProperty.BasicFPBLimit = "";
        }

        #endregion

        #endregion

        #region Initialize Auto APD for PA state
        public void InitializationAutoAPDCase2(RaterFacadeModel raterFacadeModel)
        {
            InitializeAutoAPDCollCompAndSpecifiedCasueofLossPremiumCase2(raterFacadeModel);

            InitializeAutoAPDOptionalCoveragesPremiumCase2(raterFacadeModel);

            InitializeAutoAPDIRPMPremiumCase2(raterFacadeModel);

            InitializeAutoAPDOtherModPremiumCase2(raterFacadeModel);

            // InitializeAutoScheduleRatingCase2(raterFacadeModel);
        }

        #region Initialize CollCompAndSpecifiedCasueofLoss Premium 
        private void InitializeAutoAPDCollCompAndSpecifiedCasueofLossPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel;

            inputProperty.CompBaseRate = 0.35M;
            inputProperty.CollisionBaseRate = 0.53M;
            inputProperty.SpecCauseofLossBaseRate = 0.275M;

            inputProperty.NonEmergencyUnitsCount = 6;
            inputProperty.EmergencyUnitsCount = 1;
            inputProperty.BusesCount = 3;
            inputProperty.TrailersCount = 0;
            inputProperty.TotalVehiclesCount = 10;
            inputProperty.TotalVehicleswithoutTrailersCount = 10;
            inputProperty.CompVehiclesCount = 10;

            inputProperty.ComprehensiveSymbol = "1";
            inputProperty.CollisionSymbol = "2";
            inputProperty.SpecifiedCauseofLossSymbol = "3";

            inputProperty.IRPMApplies = true;
        }

        #endregion

        #region Initialize Optional Coverages Premium

        private void InitializeAutoAPDOptionalCoveragesPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel;

            #region OptionalCoverage Initialization

            inputProperty.AutoPhysicalDamageOptionalCoverageInputModel = new AutoPhysicalDamageOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.AutoPhysicalDamageOptionalCoverageInputModel;

            inputOptionalCoverage.GaragekeepersCA9937CoverageID = 1;
            inputOptionalCoverage.GaragekeepersCA9937IsSelected = false;
            inputOptionalCoverage.GaragekeepersCA9937Limit = 50000;
            inputOptionalCoverage.GaragekeepersCA9937Deductible = 0;
            inputOptionalCoverage.GaragekeepersCA9937RatingBasis = "PER 1; 000 OF LIMIT";
            inputOptionalCoverage.GaragekeepersCA9937ReturnMethod = "Pro rata";
            inputOptionalCoverage.GaragekeepersCA9937Rate = 3;
            inputOptionalCoverage.GaragekeepersCA9937Premium = 150;

            inputOptionalCoverage.RentalReimbursementCA9923CoverageID = 1;
            inputOptionalCoverage.RentalReimbursementCA9923IsSelected = true;
            inputOptionalCoverage.RentalReimbursementCA9923Limit = 15000;
            inputOptionalCoverage.RentalReimbursementCA9923Deductible = 0;
            inputOptionalCoverage.RentalReimbursementCA9923RatingBasis = "Flat charge";
            inputOptionalCoverage.RentalReimbursementCA9923ReturnMethod = "Pro rata";
            inputOptionalCoverage.RentalReimbursementCA9923Rate = 0;
            inputOptionalCoverage.RentalReimbursementCA9923Premium = 50;

            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004CoverageID = 3;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004IsSelected = false;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Limit = 10000;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Deductible = 0;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004RatingBasis = "Flat charge";
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004ReturnMethod = "Pro rata";
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Rate = 0;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Premium = 20;

            inputOptionalCoverage.FullSafetyGlassCoverageCA0421CoverageID = 4;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421IsSelected = false;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Limit = 0;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Deductible = 0;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421RatingBasis = "APD Comprehensive premium";
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421ReturnMethod = "Pro rata";
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Rate = 0.02M;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Premium = 10;

            //inputOptionalCoverage.AutoPhysicalDamageOptionalOtherCoverageInputModels = new List<AutoPhysicalDamageOptionalOtherCoverageInputModel>();

            //inputOptionalCoverage.AutoPhysicalDamageOptionalOtherCoverageInputModels.Add(new AutoPhysicalDamageOptionalOtherCoverageInputModel
            //{
            //    OtherCoverageID = 5,
            //    OtherCoverageDescription = "OTHER",
            //    OtherCoverageLimit = 30000,
            //    OtherCoverageDedcutible = 0,
            //    OtherCoverageRate = 0,
            //    OtherCoverageRatingBasis = "Flat charge",
            //    OtherCoverageReturnMethod = "Pro rata",
            //    OtherCoveragePremium = 50

            //});

            model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.AutoPhysicalDamageOptionalCoverageInputModel = inputOptionalCoverage;

            #endregion
        }

        #endregion

        #region Initialize Calculate IRPM Premium
        private void InitializeAutoAPDIRPMPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel;


            //Case 1 Get IRPMRate Factor
            inputProperty.IRPMRate = 0.7M;
        }

        #endregion

        #region Initialize Calculate OtherMod Premium
        private void InitializeAutoAPDOtherModPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.CW.AutoPhysicalDamageOutputModel;


            //Case 1 Get Tier Factor
            inputProperty.OtherModRate = 0.02M;
        }

        #endregion

        #region Initialize Calculate Auto ScheduleRating
        private void InitializeAutoScheduleRatingCase2(RaterFacadeModel model)
        {
            var inputAutoScheduleRating = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel;

            #region Auto Vehicles Schedule

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 1,
                VIN = "CD534534534534500",
                Make = "Ford",
                Model = "Private Passenger",
                Year = 2005,
                ClassCode = "7398",
                RatingGroup = "Non Emergency",
                OCN = 20000,
                Valuation = "Actual Cash Value",
                CompDeductible = 250,
                CollDeductible = 250,
                SpecifiedCauseofLossDeductible = 250,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 2,
                VIN = "AB534534534534500",
                Make = "Cadillac",
                Model = "Antique Autos",
                Year = 1999,
                ClassCode = "9620",
                RatingGroup = "Non Emergency",
                OCN = 10000,
                Valuation = "Stated Amount",
                CompDeductible = 500,
                CollDeductible = 500,
                SpecifiedCauseofLossDeductible = 500,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 3,
                VIN = "DE534534534534500",
                Make = "Mercedes",
                Model = "Trailer",
                Year = 2007,
                ClassCode = "211-790",
                RatingGroup = "Non Emergency",
                OCN = 50000,
                Valuation = "Replacement Cost",
                CompDeductible = 1000,
                CollDeductible = 1000,
                SpecifiedCauseofLossDeductible = 1000,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 4,
                VIN = "FG534534534534500",
                Make = "Land Rover",
                Model = "All Other Bus",
                Year = 2008,
                ClassCode = "6584",
                RatingGroup = "Buses",
                OCN = 10000,
                Valuation = "Actual Cash Value",
                CompDeductible = 100,
                CollDeductible = 100,
                SpecifiedCauseofLossDeductible = 100,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 5,
                VIN = "HI534534534534500",
                Make = "GMC",
                Model = "Snowmobiles",
                Year = 2009,
                ClassCode = "6181",
                RatingGroup = "Buses",
                OCN = 10000,
                Valuation = "Stated Amount",
                CompDeductible = 500,
                CollDeductible = 500,
                SpecifiedCauseofLossDeductible = 500,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 6,
                VIN = "JK534534534534500",
                Make = "Dodge",
                Model = "Ambulance",
                Year = 2010,
                ClassCode = "7919",
                RatingGroup = "Emergency",
                OCN = 10000,
                Valuation = "Replacement Cost",
                CompDeductible = 1000,
                CollDeductible = 1000,
                SpecifiedCauseofLossDeductible = 1000,
            });


            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 7,
                VIN = "LM534534534534500",
                Make = "BMW Motors",
                Model = "SC Bus",
                Year = 2011,
                ClassCode = "6183",
                RatingGroup = "Buses",
                OCN = 5000,
                Valuation = "Actual Cash Value",
                CompDeductible = 100,
                CollDeductible = 250,
                SpecifiedCauseofLossDeductible = 250,
            });


            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 8,
                VIN = "MN534534534534500",
                Make = "Audi",
                Model = "Social Service Bus-Employee Operated",
                Year = 2012,
                ClassCode = "6481",
                RatingGroup = "Buses",
                OCN = 10000,
                Valuation = "Stated Amount",
                CompDeductible = 500,
                CollDeductible = 500,
                SpecifiedCauseofLossDeductible = 500,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 9,
                VIN = "OP534534534534500",
                Make = "Buick",
                Model = "Light dump",
                Year = 2013,
                ClassCode = "014-790",
                RatingGroup = "Non Emergency",
                OCN = 10000,
                Valuation = "Replacement Cost",
                CompDeductible = 1000,
                CollDeductible = 1000,
                SpecifiedCauseofLossDeductible = 1000,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 10,
                VIN = "PQ534534534534500",
                Make = "Tesla",
                Model = "All Other Bus",
                Year = 2014,
                ClassCode = "6581",
                RatingGroup = "Buses",
                OCN = 5000,
                Valuation = "Actual Cash Value",
                CompDeductible = 250,
                CollDeductible = 100,
                SpecifiedCauseofLossDeductible = 250,
            });

        }

        #endregion

        #endregion

        #endregion



        #region Initialize Auto AL for NY state
        public void InitializationAutoALCase3(RaterFacadeModel raterFacadeModel)
        {

            InitializeAutoALLiablityPremiumCase3(raterFacadeModel);

            InitializeAutoALPIPPremiumCase3(raterFacadeModel);

            InitializeAutoALPIPPremiumCase3(raterFacadeModel);

            InitializeAutoALMEDPremiumCase3(raterFacadeModel);

            InitializeAutoALUMPremiumCase3(raterFacadeModel);

            InitializeAutoALUMBIPDPremiumCase3(raterFacadeModel);

            InitializeAutoALUIMCase3(raterFacadeModel);

            InitializeAutoALHiredandNonOwnedPremiumCase3(raterFacadeModel);

            InitializeAutoALOptionalCoveragesPremiumCase3(raterFacadeModel);

            InitializeAutoALTierPremiumCase3(raterFacadeModel);

            InitializeAutoALIRPMPremiumCase3(raterFacadeModel);

            InitializeAutoALOtherModPremiumCase3(raterFacadeModel);

            InitializeAutoALMIMCCAAssessementChargeCase3(raterFacadeModel);

            InitializeAutoScheduleRatingCase3(raterFacadeModel);
        }

        #region Liablity Premium

        private void InitializeAutoALLiablityPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;

            #region PolicyHeaderModel

            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 15475;
            model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage = true;
            model.RaterInputFacadeModel.PolicyHeaderModel.IsEndorsement = false;

            //Case 1 Get BaseRate
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.NY;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Rural";

            #endregion

            inputProperty.NonEmergencyPIPUnitsCount = 6;
            inputProperty.EmergencyPIPUnitsCount = 1;
            inputProperty.BusesPIPUnitsCount = 2;
            inputProperty.TotalPIPUnitswithoutTrailersCount = 9;

            inputProperty.NonEmergencyMedPayUnitsCount = 6;
            inputProperty.EmergencyMedPayUnitsCount = 1;
            inputProperty.BusesMedPayUnitsCount = 2;
            inputProperty.TotalMedPayUnitswithoutTrailersCount = 9;

            inputProperty.NonEmergencyUnitsCount = 6;
            inputProperty.EmergencyUnitsCount = 1;
            inputProperty.BusesCount = 2;
            inputProperty.TrailersCount = 1;
            inputProperty.TotalVehicleswithoutTrailersCount = 9;


            //Case 2 Get LimitFactor
            inputProperty.LimitType = "CSL";
            inputProperty.LiabilityLimit = "1000000";
            inputProperty.LiabilityLimitRate = 1;

            //Case 3 Get DeductibleFactor
            inputProperty.Deductible_SIR = "SIR";
            inputProperty.Retention = 25000;


            inputProperty.NonEmergencyUnitsBaseRate =300;
            inputProperty.EmergencyUnitsBaseRate =340;
            inputProperty.BusesBaseRate =400;

            // UI 
            inputProperty.Expense = "Excluded";
            inputProperty.AggregateRetention = 40000;
            inputProperty.MedPayAggregate = 10000;
            inputProperty.PIPDeductible = "200";
            inputProperty.AdditionalPIPLimit = "100000";
            inputProperty.AdditionalMonthlyWorkLossLimit = 2000;
            inputProperty.AdditionalPIPOtherExpensesPerDayLimit = 25;
            inputProperty.AdditionalDeathBenefitLimit = "EXCLUDED";
            inputProperty.OBELLimit = "25000";
            inputProperty.PIPMedicalExpenseEliminationLimit = "Named Insured Only";
            inputProperty.LiabilitySymbol = "2";
            inputProperty.MedicalPaymentsSymbol ="3";
            inputProperty.PersonalInjuryProtectionSymbol = "1";
            inputProperty.UnderinsuredMotoristSymbol ="5";
            inputProperty.UninsuredMotoristSymbol ="4";
            inputProperty.IRPMApplies = true;
        }

        #endregion

        #region PIP Premium 

        private void InitializeAutoALPIPPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;

            inputProperty.PersonalInjuryProtectionLimit = "INCLUDED";

            inputProperty.ExcessAttendantCareLimit = "";

        }

        #endregion

        #region  MED Premium

        private void InitializeAutoALMEDPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;

            inputProperty.MedicalPaymentsLimit = "5000";

        }

        #endregion

        #region UM Premiumm

        private void InitializeAutoALUMPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;

            inputProperty.UMUIMStacking = false;
            inputProperty.UninsuredLimit = "1000000";

        }

        #endregion

        #region UM BI/PD Premium

        private void InitializeAutoALUMBIPDPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;

            //Case 1 Get UMBIPDRate
            inputProperty.UninsuredBIPDLimit = "";
        }

        #endregion

        #region UIM permium

        private void InitializeAutoALUIMCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;

            //Case 1 Get UIMRate
            inputProperty.UnderinsuredConversion = false;
            inputProperty.UnderinsuredLimit = "";
        }

        #endregion

        #region  Hired and NonOwned Premium

        private void InitializeAutoALHiredandNonOwnedPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;


            //Case 1 Get Hired and NonOwned Premium
            inputProperty.HiredAndNonOwned = "Included";
        }

        #endregion

        #region Optional Coverages Premium

        private void InitializeAutoALOptionalCoveragesPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;

            #region OptionalCoverage Initialization

            inputProperty.AutoLiabilityOptionalCoverageInputModel = new AutoLiabilityOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.AutoLiabilityOptionalCoverageInputModel;

            inputOptionalCoverage.AdditionalInsuredDesignatedPersonOrOrganizationCA201IsSelected = false;
            inputOptionalCoverage.AdditionalInsuredEndorsementAutoAG1009IsSelected = false;
            inputOptionalCoverage.LessorAdditionalInsuredAndLossPayeeCA2001IsSelected = false;

            inputOptionalCoverage.MutualAidCoverageID = 1;
            inputOptionalCoverage.MutualAidIsSelected = true;
            inputOptionalCoverage.MutualAidCA2025Limit = 60000;
            inputOptionalCoverage.MutualAidCA2025Deductible = 50;
            inputOptionalCoverage.MutualAidCA2025RatingBasis = "Flat charge";
            inputOptionalCoverage.MutualAidCA2025ReturnMethod = "Fully earned";
            inputOptionalCoverage.MutualAidCA2025Rate = 0;
            inputOptionalCoverage.MutualAidCA2025UnModifiedPremium = 50;
            inputOptionalCoverage.MutualAidCA2025ModifiedPremium = 50;
            inputOptionalCoverage.OtherCoverageModifiedPremium = 0;
            inputOptionalCoverage.OtherCoverageUnModifiedPremium = 0;

            inputOptionalCoverage.AutoLiabilityOptionalOtherCoverageInputModels = new List<AutoLiabilityOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.AutoLiabilityOptionalOtherCoverageInputModels.Add(new AutoLiabilityOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 0,
                OtherCoverageDescription = "",
                OtherCoverageLimit = 0,
                OtherCoverageDedcutible = 0,
                OtherCoverageRate = 0,
                OtherCoverageRatingBasis = "",
                OtherCoverageReturnMethod = "",
                OtherCoveragePremium = 0

            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AutoLiabilityOptionalCoverageInputModel = inputOptionalCoverage;

            #endregion
        }

        #endregion

        #region Calculate Tier Premium

        private void InitializeAutoALTierPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel;
            //Case 1 Get Tier Factor
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Preferred";
        }

        #endregion

        #region Calculate IRPM Premium
        private void InitializeAutoALIRPMPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel;


            //Case 1 Get Tier Factor
            inputProperty.IRPMRate = 1.05M;
        }

        #endregion

        #region Calculate OtherMod Premium
        private void InitializeAutoALOtherModPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoLiabilityOutputModel;


            //Case 1 Get Tier Factor
            inputProperty.OtherModRate = 1;
        }

        #endregion

        #region Calculate MI MCCA Assessement Charge 

        private void InitializeAutoALMIMCCAAssessementChargeCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;


            //Case 1 MI MCCA Assessement Charge
            inputProperty.BasicFPBLimit = "";
        }

        #endregion

        #endregion

        #region Initialize Auto APD for NY state
        public void InitializationAutoAPDCase3(RaterFacadeModel raterFacadeModel)
        {
            InitializeAutoAPDCollCompAndSpecifiedCasueofLossPremiumCase3(raterFacadeModel);

            InitializeAutoAPDOptionalCoveragesPremiumCase3(raterFacadeModel);

            InitializeAutoAPDIRPMPremiumCase3(raterFacadeModel);

            InitializeAutoAPDOtherModPremiumCase3(raterFacadeModel);

            // InitializeAutoScheduleRatingCase3(raterFacadeModel);
        }

        #region Initialize CollCompAndSpecifiedCasueofLoss Premium 
        private void InitializeAutoAPDCollCompAndSpecifiedCasueofLossPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoPhysicalDamageInputModel;

            inputProperty.CompBaseRate = 0.34M;
            inputProperty.CollisionBaseRate = 0.225M;
            inputProperty.SpecCauseofLossBaseRate = 0;

            inputProperty.NonEmergencyUnitsCount = 6;
            inputProperty.EmergencyUnitsCount = 1;
            inputProperty.BusesCount = 2;
            inputProperty.TrailersCount = 1;
            inputProperty.TotalVehiclesCount = 10;
            inputProperty.TotalVehicleswithoutTrailersCount = 9;
            inputProperty.CompVehiclesCount = 10;

            inputProperty.ComprehensiveSymbol = "5";
            inputProperty.CollisionSymbol = "2";
            inputProperty.SpecifiedCauseofLossSymbol = "1";

            inputProperty.IRPMApplies = true;
        }

        #endregion

        #region Initialize Optional Coverages Premium

        private void InitializeAutoAPDOptionalCoveragesPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoPhysicalDamageInputModel;

            #region OptionalCoverage Initialization

            inputProperty.AutoPhysicalDamageOptionalCoverageInputModel = new AutoPhysicalDamageOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.AutoPhysicalDamageOptionalCoverageInputModel;

            inputOptionalCoverage.GaragekeepersCA9937CoverageID = 1;
            inputOptionalCoverage.GaragekeepersCA9937IsSelected = true;
            inputOptionalCoverage.GaragekeepersCA9937Limit = 50000;
            inputOptionalCoverage.GaragekeepersCA9937Deductible = 0;
            inputOptionalCoverage.GaragekeepersCA9937RatingBasis = "PER 1; 000 OF LIMIT";
            inputOptionalCoverage.GaragekeepersCA9937ReturnMethod = "Pro rata";
            inputOptionalCoverage.GaragekeepersCA9937Rate = 3;
            inputOptionalCoverage.GaragekeepersCA9937Premium = 0;

            inputOptionalCoverage.RentalReimbursementCA9923CoverageID = 2;
            inputOptionalCoverage.RentalReimbursementCA9923IsSelected = false;
            inputOptionalCoverage.RentalReimbursementCA9923Limit = 20000;
            inputOptionalCoverage.RentalReimbursementCA9923Deductible = 0;
            inputOptionalCoverage.RentalReimbursementCA9923RatingBasis = "Flat charge";
            inputOptionalCoverage.RentalReimbursementCA9923ReturnMethod = "Pro rata";
            inputOptionalCoverage.RentalReimbursementCA9923Rate = 0;
            inputOptionalCoverage.RentalReimbursementCA9923Premium = 50;

            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004CoverageID = 3;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004IsSelected = false;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Limit = 10000;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Deductible = 0;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004RatingBasis = "Flat charge";
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004ReturnMethod = "Pro rata";
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Rate = 0;
            inputOptionalCoverage.RentalReimbursementEmergencyServiceVehiclesBA0004Premium = 20;

            inputOptionalCoverage.FullSafetyGlassCoverageCA0421CoverageID = 4;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421IsSelected = false;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Limit = 0;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Deductible = 0;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421RatingBasis = "APD Comprehensive premium";
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421ReturnMethod = "Pro rata";
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Rate = 0.02M;
            inputOptionalCoverage.FullSafetyGlassCoverageCA0421Premium = 10;

            //inputOptionalCoverage.AutoPhysicalDamageOptionalOtherCoverageInputModels = new List<AutoPhysicalDamageOptionalOtherCoverageInputModel>();

            //inputOptionalCoverage.AutoPhysicalDamageOptionalOtherCoverageInputModels.Add(new AutoPhysicalDamageOptionalOtherCoverageInputModel
            //{
            //    OtherCoverageID = 5,
            //    OtherCoverageDescription = "OTHER",
            //    OtherCoverageLimit = 30000,
            //    OtherCoverageDedcutible = 0,
            //    OtherCoverageRate = 0,
            //    OtherCoverageRatingBasis = "Flat charge",
            //    OtherCoverageReturnMethod = "Pro rata",
            //    OtherCoveragePremium = 50

            //});

            model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoPhysicalDamageInputModel.AutoPhysicalDamageOptionalCoverageInputModel = inputOptionalCoverage;

            #endregion
        }

        #endregion

        #region Initialize Calculate IRPM Premium
        private void InitializeAutoAPDIRPMPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoPhysicalDamageInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel;


            //Case 1 Get IRPMRate Factor
            inputProperty.IRPMRate = 0.85M;
        }

        #endregion

        #region Initialize Calculate OtherMod Premium
        private void InitializeAutoAPDOtherModPremiumCase3(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoPhysicalDamageInputModel;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Auto.NY.AutoPhysicalDamageOutputModel;


            //Case 1 Get Tier Factor
            inputProperty.OtherModRate = 0.01M;
        }

        #endregion

        #region Initialize Calculate Auto ScheduleRating
        private void InitializeAutoScheduleRatingCase3(RaterFacadeModel model)
        {
            var inputAutoScheduleRating = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel;

            #region Auto Vehicles Schedule

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 1,
                VIN = "CD534534534534500",
                Make = "Ford",
                Model = "Private Passenger",
                Year = 2005,
                ClassCode = "7398",
                RatingGroup = "Non Emergency",
                OCN = 20000,
                Valuation = "Actual Cash Value",
                CompDeductible = 250,
                CollDeductible = 250,
                SpecifiedCauseofLossDeductible = 0,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 2,
                VIN = "AB534534534534500",
                Make = "Cadillac",
                Model = "Antique Autos",
                Year = 1999,
                ClassCode = "9620",
                RatingGroup = "Non Emergency",
                OCN = 10000,
                Valuation = "Stated Amount",
                CompDeductible = 500,
                CollDeductible = 500,
                SpecifiedCauseofLossDeductible = 0,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 3,
                VIN = "DE534534534534500",
                Make = "Mercedes",
                Model = "Trailer",
                Year = 2007,
                ClassCode = "211-790",
                RatingGroup = "Non Emergency",
                OCN = 50000,
                Valuation = "Replacement Cost",
                CompDeductible = 1000,
                CollDeductible = 1000,
                SpecifiedCauseofLossDeductible = 0,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 4,
                VIN = "FG534534534534500",
                Make = "Land Rover",
                Model = "All Other Bus",
                Year = 2008,
                ClassCode = "6584",
                RatingGroup = "Buses",
                OCN = 10000,
                Valuation = "Actual Cash Value",
                CompDeductible = 100,
                CollDeductible = 100,
                SpecifiedCauseofLossDeductible = 0,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 5,
                VIN = "HI534534534534500",
                Make = "GMC",
                Model = "Snowmobiles",
                Year = 2009,
                ClassCode = "6181",
                RatingGroup = "Buses",
                OCN = 10000,
                Valuation = "Stated Amount",
                CompDeductible = 500,
                CollDeductible = 500,
                SpecifiedCauseofLossDeductible = 0,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 6,
                VIN = "JK534534534534500",
                Make = "Dodge",
                Model = "Ambulance",
                Year = 2010,
                ClassCode = "7919",
                RatingGroup = "Emergency",
                OCN = 10000,
                Valuation = "Replacement Cost",
                CompDeductible = 1000,
                CollDeductible = 1000,
                SpecifiedCauseofLossDeductible = 0,
            });


            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 7,
                VIN = "LM534534534534500",
                Make = "BMW Motors",
                Model = "SC Bus",
                Year = 2011,
                ClassCode = "6183",
                RatingGroup = "Buses",
                OCN = 5000,
                Valuation = "Actual Cash Value",
                CompDeductible = 100,
                CollDeductible = 250,
                SpecifiedCauseofLossDeductible = 0,
            });


            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 8,
                VIN = "MN534534534534500",
                Make = "Audi",
                Model = "Social Service Bus-Employee Operated",
                Year = 2012,
                ClassCode = "6481",
                RatingGroup = "Buses",
                OCN = 10000,
                Valuation = "Stated Amount",
                CompDeductible = 500,
                CollDeductible = 500,
                SpecifiedCauseofLossDeductible = 0,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 9,
                VIN = "OP534534534534500",
                Make = "Buick",
                Model = "Light dump",
                Year = 2013,
                ClassCode = "014-790",
                RatingGroup = "Non Emergency",
                OCN = 10000,
                Valuation = "Replacement Cost",
                CompDeductible = 1000,
                CollDeductible = 1000,
                SpecifiedCauseofLossDeductible = 0,
            });

            inputAutoScheduleRating.Add(new AutoScheduleVehiclesDetailsInputModel
            {
                Vehicle = 10,
                VIN = "PQ534534534534500",
                Make = "Tesla",
                Model = "All Other Bus",
                Year = 2014,
                ClassCode = "6581",
                RatingGroup = "Buses",
                OCN = 5000,
                Valuation = "Actual Cash Value",
                CompDeductible = 250,
                CollDeductible = 100,
                SpecifiedCauseofLossDeductible = 0,
            });

        }

        #endregion

        #endregion

        #endregion
    }
}

