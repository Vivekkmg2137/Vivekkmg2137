﻿using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Input;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class DOInitialization
    {

        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.DirectorsAndOfficers = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers = new Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Input.DirectorsAndOfficersInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel = new Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Input.DirectorsAndOfficersOptionalCoverageInputModel();
            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers = new Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Output.DirectorsAndOfficersOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel = new Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Output.DirectorsAndOfficersOptionalCoverageOutputModel();
        }

        #region Test Case Directors And Officers Premium for SC State 

        public void InitializationCase1(RaterFacadeModel model)
        {
            // Initialize Law for CT state
            InitializeInitialRates(model);

            InitializeOptionalCoveragesPremiumCase1(model);

            InitializeBasePremiumCase1(model);

            //InitializeManualPremiumCase1(model);

            InitializeTierPremiumCase1(model);

            InitializeIRPMPremiumCase1(model);

            InitializeOtherModPremiumCase1(model);

            //InitializeTerrorismPremiumCase1(model);

            //InitializeAutoTierPremiumCase1(model);

            //InitializeAutoIRPMPremiumCase1(model);

            //InitializeAutoOtherModPremiumCase1(model);

            //InitializeFinalPremiumCase1(model);
        }

        private void InitializeInitialRates(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;

            #region PolicyHeaderModel

            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.SC;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "PNP"; 
            model.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass = "Water & Sewer";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Rural";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 50000;
            model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage = true;
            model.RaterInputFacadeModel.PolicyHeaderModel.IsEndorsement = false;

            #endregion

            inputProperty.Exposure = 200000;
            inputProperty.ExposureRate = 4.500M;
            inputProperty.LiabilityLimit = 500000;
            inputProperty.AggregateLimit = 3500000;
            inputProperty.LiabilityLimitRate = 1.100M;
            inputProperty.EPInclusionExclusion = "Excluded";
            inputProperty.Deductible_SIR = "Deductible";
            inputProperty.Retention = 2500;
            inputProperty.AggregateRetention = 1000;
            inputProperty.Type = "Each Wrongful Act";
            inputProperty.Expense = "Included";
            inputProperty.PolicyType = "Claims Made";
            inputProperty.RetroDate = Convert.ToDateTime("2018-10-10T09:37:09.510Z");
            inputProperty.YearsinCMProgram = 3;
            inputProperty.IRPMFactor = 0.90M;
            inputProperty.OtherModRate = 0.75M;
            inputProperty.IRPMApplies = true;

        }

        private void InitializeOptionalCoveragesPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;

            inputProperty.DirectorsAndOfficersOptionalCoverageModel = new Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Input.DirectorsAndOfficersOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.DirectorsAndOfficersOptionalCoverageModel;

            //Optional Coverage I - Suppl.Extended Reporting Period
            inputOptionalCoverage.SupplExtendedReportingPeriodIsSelected = false;
            inputOptionalCoverage.SupplExtendedReportingPeriodLimit = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "string";
            inputOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "string";
            inputOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;

            //inputOptionalCoverage.OtherCoverageUnmodifiedPremium = 0;
            //inputOptionalCoverage.OtherCoverageModifiedPremium = 0;

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel = new List<DirectorsAndOfficersOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel.Add(new DirectorsAndOfficersOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 1,
                OtherCoverageDescription = "Other1 DO",
                OtherCoverageLimit = 10000,
                OtherCoverageAggregateLimit = 20000,
                OtherCoverageDedcutible = 10,
                OtherCoverageRate = 0,
                OtherCoverageRatingBasis = "Flat Charge",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageModifiedPremium = 0,
                OtherCoverageUnmodifiedPremium = 30

            });

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel.Add(new DirectorsAndOfficersOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 2,
                OtherCoverageDescription = "Other3 DO",
                OtherCoverageLimit = 100000,
                OtherCoverageAggregateLimit = 200000,
                OtherCoverageDedcutible = 10,
                OtherCoverageRate = 0.20M,
                OtherCoverageRatingBasis = "Per 1000 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageModifiedPremium = 0,
                OtherCoverageUnmodifiedPremium = 0

            });

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel.Add(new DirectorsAndOfficersOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 3,
                OtherCoverageDescription = "Other4 1000",
                OtherCoverageLimit = 200000,
                OtherCoverageAggregateLimit = 100000,
                OtherCoverageDedcutible = 30,
                OtherCoverageRate = 0.10M,
                OtherCoverageRatingBasis = "Per 1000 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageModifiedPremium = 0,
                OtherCoverageUnmodifiedPremium = 0

            });

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel.Add(new DirectorsAndOfficersOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 4,
                OtherCoverageDescription = "Other5 100",
                OtherCoverageLimit = 50000,
                OtherCoverageAggregateLimit = 100000,
                OtherCoverageDedcutible = 30,
                OtherCoverageRate = 0.20M,
                OtherCoverageRatingBasis = "Per 100 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageModifiedPremium = 0,
                OtherCoverageUnmodifiedPremium = 0

            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel = inputOptionalCoverage;

        }

        private void InitializeBasePremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;

            inputProperty.Exposure = 200000;
        }

        private void InitializeTierPremiumCase1(RaterFacadeModel model)
        {
            //Case 1 Get Tier Factor
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = null;
        }

        private void InitializeIRPMPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
           
            //Case 1 Get IRPM Factor
            inputProperty.IRPMFactor = 0.90M;
        }

        private void InitializeOtherModPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
            
            //Case 1 Get IRPM Factor
            inputProperty.OtherModRate = 0.75M;
        }

        #endregion

        #region Test Case Directors And Officers Premium for NC State 

        public void InitializationCase2(RaterFacadeModel model)
        {
            // Initialize Law for CT state
            InitializeInitialRates2(model);

            InitializeOptionalCoveragesPremiumCase2(model);

            InitializeBasePremiumCase2(model);

            //InitializeManualPremiumCase2(model);

            InitializeTierPremiumCase2(model);

            InitializeIRPMPremiumCase2(model);

            InitializeOtherModPremiumCase2(model);

            //InitializeTerrorismPremiumCase2(model);

            //InitializeAutoTierPremiumCase2(model);

            //InitializeAutoIRPMPremiumCase2(model);

            //InitializeAutoOtherModPremiumCase2(model);

            //InitializeFinalPremiumCase2(model);
        }

        private void InitializeInitialRates2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;

            #region PolicyHeaderModel

            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.NC;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "PNP";
            model.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass = "Other";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Rural";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 250000;
            model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage = true;
            model.RaterInputFacadeModel.PolicyHeaderModel.IsEndorsement = false;

            #endregion

            inputProperty.Exposure = 100000;
            inputProperty.ExposureRate = 4.5M;
            inputProperty.LiabilityLimit = 1000000;
            inputProperty.AggregateLimit = 2000000;
            inputProperty.LiabilityLimitRate = 1.400M;
            inputProperty.EPInclusionExclusion = "Excluded";
            inputProperty.Deductible_SIR = "Deductible";
            inputProperty.Retention = 1000;
            inputProperty.AggregateRetention = 2000;
            inputProperty.Type = "Each Wrongful Act";
            inputProperty.Expense = "Included";
            inputProperty.PolicyType = "Claims Made";
            inputProperty.RetroDate = Convert.ToDateTime("2015-10-10T09:37:09.510Z");
            inputProperty.YearsinCMProgram = 1;
            inputProperty.IRPMFactor = 1.50M;
            inputProperty.OtherModRate = 1.75M;
            inputProperty.IRPMApplies = true;

        }

        private void InitializeOptionalCoveragesPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;

            inputProperty.DirectorsAndOfficersOptionalCoverageModel = new Models.ApiModels.LineOfBusiness.DirectorsAndOfficers.Input.DirectorsAndOfficersOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.DirectorsAndOfficersOptionalCoverageModel;

            //Optional Coverage I - Suppl.Extended Reporting Period
            inputOptionalCoverage.SupplExtendedReportingPeriodIsSelected = false;
            inputOptionalCoverage.SupplExtendedReportingPeriodLimit = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "string";
            inputOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "string";
            inputOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;

            //inputOptionalCoverage.OtherCoverageUnmodifiedPremium = 0;
            //inputOptionalCoverage.OtherCoverageModifiedPremium = 0;

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel = new List<DirectorsAndOfficersOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel.Add(new DirectorsAndOfficersOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 1,
                OtherCoverageDescription = "Other1 DO",
                OtherCoverageLimit = 10000,
                OtherCoverageAggregateLimit = 20000,
                OtherCoverageDedcutible = 10,
                OtherCoverageRate = 0,
                OtherCoverageRatingBasis = "Flat Charge",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageModifiedPremium = 0,
                OtherCoverageUnmodifiedPremium = 30

            });

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel.Add(new DirectorsAndOfficersOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 2,
                OtherCoverageDescription = "Other3 DO",
                OtherCoverageLimit = 100000,
                OtherCoverageAggregateLimit = 200000,
                OtherCoverageDedcutible = 10,
                OtherCoverageRate = 0.20M,
                OtherCoverageRatingBasis = "Per 1000 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageModifiedPremium = 0,
                OtherCoverageUnmodifiedPremium = 0

            });

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel.Add(new DirectorsAndOfficersOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 3,
                OtherCoverageDescription = "Other4 1000",
                OtherCoverageLimit = 200000,
                OtherCoverageAggregateLimit = 200000,
                OtherCoverageDedcutible = 30,
                OtherCoverageRate = 0.10M,
                OtherCoverageRatingBasis = "Per 1000 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageModifiedPremium = 0,
                OtherCoverageUnmodifiedPremium = 0

            });

            inputOptionalCoverage.DirectorsAndOfficersOptionalOtherCoverageModel.Add(new DirectorsAndOfficersOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 4,
                OtherCoverageDescription = "Other5 100",
                OtherCoverageLimit = 50000,
                OtherCoverageAggregateLimit = 100000,
                OtherCoverageDedcutible = 30,
                OtherCoverageRate = 0.20M,
                OtherCoverageRatingBasis = "Per 100 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageModifiedPremium = 0,
                OtherCoverageUnmodifiedPremium = 0

            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel = inputOptionalCoverage;

        }

        private void InitializeBasePremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;

            inputProperty.Exposure = 100000;
        }

        private void InitializeTierPremiumCase2(RaterFacadeModel model)
        {
            //Case 1 Get Tier Factor
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = null;
        }

        private void InitializeIRPMPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;

            //Case 1 Get IRPM Factor
            inputProperty.IRPMFactor = 1.50M;
        }

        private void InitializeOtherModPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;

            //Case 1 Get IRPM Factor
            inputProperty.OtherModRate = 1.75M;
        }

        #endregion

    }
}

