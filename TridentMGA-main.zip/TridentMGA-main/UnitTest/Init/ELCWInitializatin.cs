﻿using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Output;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class ELCWInitialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.EducatorsLegal = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal = new EducatorsLegalInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW = new EducatorsLegalCwInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage = new EducatorsLegalCwOptionalCoverageInputModel();

            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal = new EducatorsLegalOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW = new EducatorsLegalCwOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage = new EducatorsLegalCwOptionalCoverageOutputModel();

        }

        public void InitializeELPremium(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.EmploymentPracticesSchool = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal = new EducatorsLegalInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW = new EducatorsLegalCwInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage = new EducatorsLegalCwOptionalCoverageInputModel();


            #region PolicyHeaderModel
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State = "CT";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "SC";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("08-08-2021");       //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("30-12-2021");       //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("01-10-2022");    //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 4500;

            #endregion

            #region PricingInputModel
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel.TierPlan = "SubStandard";
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;

            #endregion

            var InputELModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW;
            InputELModel.Exposure = 400;
            InputELModel.ExposureRate = 3.75M;
            InputELModel.LiabilityLimit = 100000;
            InputELModel.AggregateLimit = 100000;
            InputELModel.LiabilityLimitRate = 0.79M;
            InputELModel.EPInclusionExclusion = "Excluded";
            InputELModel.DeductibleSIR = "Deductible";
            InputELModel.Retention = "25000";
            InputELModel.AggregateRetention = 1;
            InputELModel.ExperienceFactorIsSelected = true;
            InputELModel.Type = "Per Claimant";
            InputELModel.Expense = "Included";           
            InputELModel.PolicyType = "Claims Made";
            InputELModel.RetroDate = Convert.ToDateTime("10-10-2017");
            InputELModel.YearsinCMProgram = 2;
            InputELModel.IRPMFactor = 1;
            InputELModel.OtherModRate = 1;
            InputELModel.IRPMApplies = true;
        }

        public void InitializeOptionalCoveragePremium(RaterFacadeModel model)
        {  
            var InputELModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal;
            var inputELOptionalCoverage = InputELModel.CW.EducatorsLegalOptionalCoverage;
            inputELOptionalCoverage.NonMonetaryDefenseIsSelected = true;
            inputELOptionalCoverage.NonMonetaryDefenseLimit = 50000;
            inputELOptionalCoverage.NonMonetaryDefenseAggregateLimit = 200000;
            inputELOptionalCoverage.NonMonetaryDefenseDeductible = 0;
            inputELOptionalCoverage.NonMonetaryDefenseRatingBasis = "FLAT CHARGE";
            inputELOptionalCoverage.NonMonetaryDefenseReturnMethod = "Pro rata";
            inputELOptionalCoverage.NonMonetaryDefenseRate = 0;
            inputELOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium = 0;
            inputELOptionalCoverage.NonMonetaryDefenseModifiedPremium = 0;
            inputELOptionalCoverage.IDEAIsSelected = true;
            inputELOptionalCoverage.IDEALimit = 25000;
            inputELOptionalCoverage.IDEAAggregateLimit = 50000;
            inputELOptionalCoverage.IDEADeductible = 0;
            inputELOptionalCoverage.IDEARatingBasis = "FLAT CHARGE";
            inputELOptionalCoverage.IDEAReturnMethod = "Pro rata";
            inputELOptionalCoverage.IDEARate = 100;
            inputELOptionalCoverage.IDEAUnmodifiedPremium = 0;
            inputELOptionalCoverage.IDEAModifiedPremium = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodIsSelected = true;
            inputELOptionalCoverage.SupplExtendedReportingPeriodLimit = 12;
            inputELOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "FLAT CHARGE";
            inputELOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "Pro rata";
            inputELOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;
           

            // Other Coverage 
            inputELOptionalCoverage.EducatorsLegalOtherCoverage = new List<EducatorsLegalOtherCoverageInputModel>();
            EducatorsLegalOtherCoverageInputModel OtherCoverage = new EducatorsLegalOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 0;
            OtherCoverage.OtherCoverageDescription = "";
            OtherCoverage.OtherCoverageLimit = 100000;
            OtherCoverage.OtherCoverageAggregateLimit = 0;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "PER 1000 OF LIMIT";
            OtherCoverage.OtherCoverageReturnMethod = "";
            OtherCoverage.OtherCoverageRate = 10000; 
            OtherCoverage.OtherCoveragePremium = 50000;
            OtherCoverage.OtherCoverageUnmodifiedPremium = 20000;
            OtherCoverage.OtherCoverageModifiedPremium = 50000;
            inputELOptionalCoverage.EducatorsLegalOtherCoverage.Add(OtherCoverage);
        }

        #region FOR  StateCode=CT 
        public void InitializeELPremium1(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.EmploymentPracticesSchool = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal = new EducatorsLegalInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW = new EducatorsLegalCwInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW.EducatorsLegalOptionalCoverage = new EducatorsLegalCwOptionalCoverageInputModel();


            #region PolicyHeaderModel
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "2";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State = "CT";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "SC";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021");       //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("09-09-2021");    //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 55000;

            #endregion

            #region PricingInputModel
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel.TierPlan = "Preferred";
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;

            #endregion

            var InputELModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.CW;
            InputELModel.Exposure = 5000;
            InputELModel.ExposureRate = 1.020M;
            InputELModel.LiabilityLimit = 100000;
            InputELModel.AggregateLimit = 100000;
            InputELModel.LiabilityLimitRate = 0.79M;
            InputELModel.EPInclusionExclusion = "Excluded";
            InputELModel.DeductibleSIR = "Deductible";
            InputELModel.Retention = "500";
            InputELModel.AggregateRetention = 1000;
            InputELModel.ExperienceFactorIsSelected = true;
            InputELModel.Type = "Each Wrongful Act";
            InputELModel.Expense = "Excluded";
            InputELModel.PolicyType = "Claims Made";
            InputELModel.RetroDate = Convert.ToDateTime("10-10-2016");
            InputELModel.YearsinCMProgram = 4;
            InputELModel.IRPMFactor = 1.000M;
            InputELModel.OtherModRate = 1.75M;
            InputELModel.IRPMApplies = true;
        }

        public void InitializeOptionalCoveragePremium1(RaterFacadeModel model)
        {
            var InputELModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal;
            var inputELOptionalCoverage = InputELModel.CW.EducatorsLegalOptionalCoverage;
            inputELOptionalCoverage.NonMonetaryDefenseIsSelected = true;
            inputELOptionalCoverage.NonMonetaryDefenseLimit = 50000;
            inputELOptionalCoverage.NonMonetaryDefenseAggregateLimit = 100000;
            inputELOptionalCoverage.NonMonetaryDefenseDeductible = 0;
            inputELOptionalCoverage.NonMonetaryDefenseRatingBasis = "FLAT CHARGE";
            inputELOptionalCoverage.NonMonetaryDefenseReturnMethod = "Pro rata";
            inputELOptionalCoverage.NonMonetaryDefenseRate = 0;
            inputELOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium = 1500;
            inputELOptionalCoverage.NonMonetaryDefenseModifiedPremium = 0;
            inputELOptionalCoverage.IDEAIsSelected = true;
            inputELOptionalCoverage.IDEALimit = 10000;
            inputELOptionalCoverage.IDEAAggregateLimit = 50000;
            inputELOptionalCoverage.IDEADeductible = 0;
            inputELOptionalCoverage.IDEARatingBasis = "FLAT CHARGE";
            inputELOptionalCoverage.IDEAReturnMethod = "Pro rata";
            inputELOptionalCoverage.IDEARate = 0;
            inputELOptionalCoverage.IDEAUnmodifiedPremium = 500;
            inputELOptionalCoverage.IDEAModifiedPremium = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodIsSelected = true;
            inputELOptionalCoverage.SupplExtendedReportingPeriodLimit = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "FLAT CHARGE";
            inputELOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "Pro rata";
            inputELOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0; 

            // Other Coverage 
            inputELOptionalCoverage.EducatorsLegalOtherCoverage = new List<EducatorsLegalOtherCoverageInputModel>();
            EducatorsLegalOtherCoverageInputModel OtherCoverage = new EducatorsLegalOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 1;
            OtherCoverage.OtherCoverageDescription = "Other3 1000";
            OtherCoverage.OtherCoverageLimit = 30000;
            OtherCoverage.OtherCoverageAggregateLimit = 100000;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "PER 1000 OF LIMIT";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = 0.20M;
            OtherCoverage.OtherCoveragePremium = 0;
            OtherCoverage.OtherCoverageUnmodifiedPremium = 0;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputELOptionalCoverage.EducatorsLegalOtherCoverage.Add(OtherCoverage);
        }

        #endregion
    }
}

