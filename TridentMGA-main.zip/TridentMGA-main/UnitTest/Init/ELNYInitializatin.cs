﻿using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Input;
using Models.ApiModels.LineOfBusiness.EducatorsLegal.Output;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class ELNYInitialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.EducatorsLegal = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal = new EducatorsLegalInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY = new EducatorsLegalNyInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage = new EducatorsLegalNyOptionalCoverageInputModel();

            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal = new EducatorsLegalOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY = new EducatorsLegalNyOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage = new EducatorsLegalNyOptionalCoverageOutputModel();

        }

        public void InitializeELPremium(RaterFacadeModel model)
        {
            if (model == null)
            {
                model = new RaterFacadeModel();
            }
            model.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            model.RaterInputFacadeModel.LineOfBusiness.EmploymentPracticesSchool = true;
            model.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            model.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            model.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal = new EducatorsLegalInputModel();
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY = new EducatorsLegalNyInputModel();
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage = new EducatorsLegalNyOptionalCoverageInputModel();


            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.State = "NY";
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "SC";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("08-08-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("12-12-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("01-10-2022");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 4500;

            #endregion

            #region PricingInputModel
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "";
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;

            #endregion

            var InputELModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY;
            InputELModel.Exposure = 400;
            InputELModel.ExposureRate = 3.50M;
            InputELModel.LiabilityLimit = 100000;
            InputELModel.AggregateLimit = 100000;
            InputELModel.LiabilityLimitRate = 0;
            InputELModel.EPInclusionExclusion = "Included";
            InputELModel.DeductibleSIR = "Deductible";
            InputELModel.NYEPAggLimit = 0;
            InputELModel.NYEPLimit = 0;
            InputELModel.NYEPLimitRate = 0;
            InputELModel.NYEPInclusionExclusion = true;
            InputELModel.Retention = "25000";
            InputELModel.AggregateRetention = 1; 
            InputELModel.Type = "Per Claimant";
            InputELModel.Expense = "Included";           
            InputELModel.PolicyType = "Claims Made";
            InputELModel.RetroDate = Convert.ToDateTime("12-12-2017");
            InputELModel.YearsinCMProgram = 2;
            InputELModel.IRPMFactor = 1;
            InputELModel.OtherModRate = 1;
            InputELModel.IRPMApplies = true;
        }

        public void InitializeOptionalCoveragePremium(RaterFacadeModel model)
        { 
            var InputELModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal;
            var inputELOptionalCoverage = InputELModel.NY.EducatorsLegalOptionalCoverage;           
            inputELOptionalCoverage.SupplExtendedReportingPeriodIsSelected = false;
            inputELOptionalCoverage.SupplExtendedReportingPeriodLimit = 50000;
            inputELOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 200000;
            inputELOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "FLAT CHARGE";
            inputELOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "Pro rata";
            inputELOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;
            

            // Other Coverage 
            inputELOptionalCoverage.EducatorsLegalOtherCoverage = new List<EducatorsLegalNyOtherCoverageInputModel>();
            EducatorsLegalNyOtherCoverageInputModel OtherCoverage = new EducatorsLegalNyOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 0;
            OtherCoverage.OtherCoverageDescription = "";
            OtherCoverage.OtherCoverageLimit = 50000;
            OtherCoverage.OtherCoverageAggregateLimit = 100;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "PER 1000 OF LIMIT";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = 0;  
            OtherCoverage.OtherCoverageUnmodifiedPremium = 0;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputELOptionalCoverage.EducatorsLegalOtherCoverage.Add(OtherCoverage);
        }

        #region FOR  StateCode=NY
        public void InitializeELPremium1(RaterFacadeModel model)
        {
            if (model == null)
            {
                model = new RaterFacadeModel();
            }
            model.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            model.RaterInputFacadeModel.LineOfBusiness.EmploymentPracticesSchool = true;
            model.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            model.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            model.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal = new EducatorsLegalInputModel();
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY = new EducatorsLegalNyInputModel();
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY.EducatorsLegalOptionalCoverage = new EducatorsLegalNyOptionalCoverageInputModel();


            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "2";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.State = "NY";
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "SC";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("11-11-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("12-12-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("01-10-2022");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 99999999;

            #endregion

            #region PricingInputModel
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Standard";
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;

            #endregion

            var InputELModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal.NY;
            InputELModel.Exposure = 15000;
            InputELModel.ExposureRate = 4.000M;
            InputELModel.LiabilityLimit = 2000000;
            InputELModel.AggregateLimit = 6000000;
            InputELModel.LiabilityLimitRate = 1.100M;
            InputELModel.EPInclusionExclusion = "Excluded";
            InputELModel.DeductibleSIR = "Deductible";
            InputELModel.NYEPAggLimit = 3000000;
            InputELModel.NYEPLimit = 1000000;
            InputELModel.NYEPLimitRate = 1.000M;
            InputELModel.NYEPInclusionExclusion = true;
            InputELModel.Retention = "$1,000 Loss + 50 % LAE";
            InputELModel.AggregateRetention = 2000;
            InputELModel.Type = "Each Wrongful Act";
            InputELModel.Expense = "Excluded";
            InputELModel.PolicyType = "Claims Made";
            InputELModel.RetroDate = Convert.ToDateTime("10-10-2019");
            InputELModel.YearsinCMProgram = 1;
            InputELModel.IRPMFactor = 1.150M;
            InputELModel.OtherModRate = 1.15M;
            InputELModel.IRPMApplies = true;
        }

        public void InitializeOptionalCoveragePremium1(RaterFacadeModel model)
        {
            var InputELModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EducatorsLegal;
            var inputELOptionalCoverage = InputELModel.NY.EducatorsLegalOptionalCoverage;
            inputELOptionalCoverage.SupplExtendedReportingPeriodIsSelected = false;
            inputELOptionalCoverage.SupplExtendedReportingPeriodLimit = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "FLAT CHARGE";
            inputELOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "Pro rata";
            inputELOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputELOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;
             

            // Other Coverage 
            inputELOptionalCoverage.EducatorsLegalOtherCoverage = new List<EducatorsLegalNyOtherCoverageInputModel>();
            // index 1
            EducatorsLegalNyOtherCoverageInputModel OtherCoverage = new EducatorsLegalNyOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 1;
            OtherCoverage.OtherCoverageDescription = "Other1 EL";
            OtherCoverage.OtherCoverageLimit = 200000;
            OtherCoverage.OtherCoverageAggregateLimit = 200000;
            OtherCoverage.OtherCoverageDeductible = 10;
            OtherCoverage.OtherCoverageRatingBasis = "Flat Charge";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = 0; 
            OtherCoverage.OtherCoverageUnmodifiedPremium = 30;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputELOptionalCoverage.EducatorsLegalOtherCoverage.Add(OtherCoverage);
            // index 2
            OtherCoverage = new EducatorsLegalNyOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 2;
            OtherCoverage.OtherCoverageDescription = "Other2 EL";
            OtherCoverage.OtherCoverageLimit = 200000;
            OtherCoverage.OtherCoverageAggregateLimit = 100000;
            OtherCoverage.OtherCoverageDeductible = 10;
            OtherCoverage.OtherCoverageRatingBasis = "per 1000 of limit";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = 0.10M; 
            OtherCoverage.OtherCoverageUnmodifiedPremium = 200;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputELOptionalCoverage.EducatorsLegalOtherCoverage.Add(OtherCoverage);
        }
        #endregion
    }
}

