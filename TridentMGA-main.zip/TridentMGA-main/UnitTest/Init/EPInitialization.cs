﻿using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Output;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class EPInitialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.EmploymentPractices = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices = new EmploymentPracticesInputModel();

            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices = new EmploymentPracticesOutputModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = new EmploymentPracticesOptionalCoverageInputModel();
        }

        public void InitializePolicyHeaderModel(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.AL;
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 5001;
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy   
            #endregion
            #region Pricing
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "";
            #endregion
        }

        public void InitializeLibilityPremium(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            this.InitializePolicyHeaderModel(model);
            #endregion
            model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices = new EmploymentPracticesOutputModel();
            model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = new EmploymentPracticesOptionalCoverageOutputModel();
            var inputEmploymentPracticesModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;
            inputEmploymentPracticesModel.Exposure = 100000;
            inputEmploymentPracticesModel.ExposureRate = 3;
            inputEmploymentPracticesModel.LiabilityLimit = 100000;
            inputEmploymentPracticesModel.AggregateLimit = 300000;
            inputEmploymentPracticesModel.LiabilityLimitRate = 100000;
            inputEmploymentPracticesModel.DeductibleSIR = "Deductible";
            inputEmploymentPracticesModel.Retention = 500;

            inputEmploymentPracticesModel.AggregateRetention = 1;
            inputEmploymentPracticesModel.Type = "";
            inputEmploymentPracticesModel.Expense = "";

            inputEmploymentPracticesModel.LossExperienceIsSelected = true;
            inputEmploymentPracticesModel.PolicyType = "Claims Made";
            inputEmploymentPracticesModel.RetroActiveDate = Convert.ToDateTime("10-10-2023");
            inputEmploymentPracticesModel.YearsinCMProgram = 1;
            inputEmploymentPracticesModel.IRPMFactor = 1;
            inputEmploymentPracticesModel.OtherModFactor = 1;
            inputEmploymentPracticesModel.IRPMApplies = true;
        }

        public void InitializeOptionalCoveragePremium(RaterFacadeModel model)
        {
            var inputEmploymentPracticesOptionalCoverageModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesLimit = 10;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesAggregateLimit = 0;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesDeductible = 0;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesRatingBasis = "string";
            inputEmploymentPracticesOptionalCoverageModel.BackWagesReturnMethod = "string";
            inputEmploymentPracticesOptionalCoverageModel.BackWagesRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium = 10;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit = 10;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit = 10;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseDeductible = 0;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRatingBasis = "string";
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseReturnMethod = "string";
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.EEOCLimit = 5;
            inputEmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit = 15;
            inputEmploymentPracticesOptionalCoverageModel.EEOCDeductible = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCRatingBasis = "";
            inputEmploymentPracticesOptionalCoverageModel.EEOCRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIsSelected = false;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActLimit = 10;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActAggregateLimit = 10;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDeductible = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRatingBasis = "string";
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActReturnMethod = "string";
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = 10;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodLimit = 10;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit = 10;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodDeductible = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis = "string";
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod = "string";
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium = 0;

            inputEmploymentPracticesOptionalCoverageModel.BackWagesIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.EEOCDefenseIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDefenseIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure = "false";
            var inputEmploymentPracticesOtherCoverageModelList = new List<EmploymentPracticesOtherCoverageInputModel>();
            inputEmploymentPracticesOtherCoverageModelList.Add(new EmploymentPracticesOtherCoverageInputModel
            {
                OtherCoverageID = 0,
                OtherCoverageLimit = 1000,
                OtherCoverageAggregateLimit = 0,
                OtherCoverageDeductible = 0,
                OtherCoverageRate = 10,
                OtherCoverageRatingBasis = "per 1,000 of limit",
                OtherCoverageReturnMethod = "",
                OtherCoverageUnmodifiedPremium = 100,
                OtherCoverageModifiedPremium = 0,
                OtherCoverageIncludedInExcessExposure="false"
            });
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = inputEmploymentPracticesOptionalCoverageModel;
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel = inputEmploymentPracticesOtherCoverageModelList;
        }

        #region test case 2
        public void InitializePolicyHeaderModel2(RaterFacadeModel model)
        {
            model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices = new EmploymentPracticesOutputModel();
            model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = new EmploymentPracticesOptionalCoverageOutputModel();

            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.MA;
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 25000;
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy   

            #endregion
            #region Pricing
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "";
            #endregion
        }
        public void InitializeLibilityPremium2(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            this.InitializePolicyHeaderModel2(model);
            #endregion

            var inputEmploymentPracticesModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;
            inputEmploymentPracticesModel.Exposure = 550;
            inputEmploymentPracticesModel.ExposureRate = Convert.ToDecimal(1.090);
            inputEmploymentPracticesModel.LiabilityLimit = 300000;
            inputEmploymentPracticesModel.AggregateLimit = 600000;
            inputEmploymentPracticesModel.LiabilityLimitRate = Convert.ToDecimal(0.790);
            inputEmploymentPracticesModel.DeductibleSIR = "Deductible";
            inputEmploymentPracticesModel.Retention = 2500;

            inputEmploymentPracticesModel.AggregateRetention = 960;
            inputEmploymentPracticesModel.Type = "Each Wrongful Act";
            inputEmploymentPracticesModel.Expense = "Included";

            inputEmploymentPracticesModel.LossExperienceIsSelected = true;
            inputEmploymentPracticesModel.PolicyType = "Claims Made";
            inputEmploymentPracticesModel.RetroActiveDate = Convert.ToDateTime("01-02-2019");
            inputEmploymentPracticesModel.YearsinCMProgram = 3;
            inputEmploymentPracticesModel.IRPMFactor = Convert.ToDecimal(1.00);
            inputEmploymentPracticesModel.OtherModFactor = Convert.ToDecimal(1.00);
            inputEmploymentPracticesModel.IRPMApplies = true;
        }

        public void InitializeOptionalCoveragePremium2(RaterFacadeModel model)
        {
            var inputEmploymentPracticesOptionalCoverageModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesIsSelected = false;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesLimit = 50000;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesAggregateLimit = 200000;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesDeductible = 2500;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesRatingBasis = "FlatCharge";
            inputEmploymentPracticesOptionalCoverageModel.BackWagesReturnMethod = "Prorata";
            inputEmploymentPracticesOptionalCoverageModel.BackWagesRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit = 50000;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit = 200000;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseDeductible = 2500;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRatingBasis = "FlatCharge";
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseReturnMethod = "Prorata";
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium = 2000;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.EEOCLimit = 10000;
            inputEmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit = 50000;
            inputEmploymentPracticesOptionalCoverageModel.EEOCDeductible = 2500;
            inputEmploymentPracticesOptionalCoverageModel.EEOCRatingBasis = "FlatCharge";
            inputEmploymentPracticesOptionalCoverageModel.EEOCReturnMethod = "Prorata";
            inputEmploymentPracticesOptionalCoverageModel.EEOCRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActLimit = 100000;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActAggregateLimit = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDeductible = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRatingBasis = "FlatCharge";
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActReturnMethod = "Prorata";
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = 60;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected = false;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodLimit = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodDeductible = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis = "string";
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod = "string";
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.EEOCDefenseIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDefenseIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure = "false";
            var inputEmploymentPracticesOtherCoverageModelList = new List<EmploymentPracticesOtherCoverageInputModel>();
            inputEmploymentPracticesOtherCoverageModelList.Add(new EmploymentPracticesOtherCoverageInputModel
            {
                OtherCoverageID =1,
                OtherCoverageLimit = 20000,
                OtherCoverageAggregateLimit = 100,
                OtherCoverageDeductible = 0,
                OtherCoverageRate = 10,
                OtherCoverageRatingBasis = "Flat charge",
                OtherCoverageReturnMethod = "Pro rata",
                OtherCoverageUnmodifiedPremium = 20,
                OtherCoverageModifiedPremium = 0,
                OtherCoverageIncludedInExcessExposure="false"
            });
            inputEmploymentPracticesOtherCoverageModelList.Add(new EmploymentPracticesOtherCoverageInputModel
            {
                OtherCoverageID = 2,
                OtherCoverageLimit = 10000,
                OtherCoverageAggregateLimit = 10,
                OtherCoverageDeductible = 0,
                OtherCoverageRate =Convert.ToDecimal(0.30),
                OtherCoverageRatingBasis = "PER 1000 OF LIMIT",
                OtherCoverageReturnMethod = "Prorata",
                OtherCoverageUnmodifiedPremium = 20,
                OtherCoverageModifiedPremium = 0
            });
            inputEmploymentPracticesOtherCoverageModelList.Add(new EmploymentPracticesOtherCoverageInputModel
            {
                OtherCoverageID = 3,
                OtherCoverageLimit = 80000,
                OtherCoverageAggregateLimit = 80000,
                OtherCoverageDeductible = 0,
                OtherCoverageRate = Convert.ToDecimal(0.50),
                OtherCoverageRatingBasis = "per 100 of limit",
                OtherCoverageReturnMethod = "Prorata",
                OtherCoverageUnmodifiedPremium = 40,
                OtherCoverageModifiedPremium = 0
            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = inputEmploymentPracticesOptionalCoverageModel;
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel = inputEmploymentPracticesOtherCoverageModelList;
        }
        #endregion

        #region test case 3
        public void InitializePolicyHeaderModel3(RaterFacadeModel model)
        {
            model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices = new EmploymentPracticesOutputModel();
            model.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = new EmploymentPracticesOptionalCoverageOutputModel();

            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "SC";
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.OH;
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 65000;
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Rural";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy   
            #endregion
            #region Pricing
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "";
            #endregion
        }
        public void InitializeLibilityPremium3(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            this.InitializePolicyHeaderModel3(model);
            #endregion

            var inputEmploymentPracticesModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;
            inputEmploymentPracticesModel.Exposure = 250;
            inputEmploymentPracticesModel.ExposureRate = Convert.ToDecimal(5);
            inputEmploymentPracticesModel.LiabilityLimit = 500000;
            inputEmploymentPracticesModel.AggregateLimit = 1000000;
            inputEmploymentPracticesModel.LiabilityLimitRate = Convert.ToDecimal(0.870);
            inputEmploymentPracticesModel.DeductibleSIR = "SIR";
            inputEmploymentPracticesModel.Retention = 25000;

            inputEmploymentPracticesModel.AggregateRetention = 780;
            inputEmploymentPracticesModel.Type = "Each Wrongful Act";
            inputEmploymentPracticesModel.Expense = "Included";

            inputEmploymentPracticesModel.LossExperienceIsSelected = true;
            inputEmploymentPracticesModel.PolicyType = "Occurrence";
            inputEmploymentPracticesModel.RetroActiveDate = Convert.ToDateTime("01-02-2019");
            inputEmploymentPracticesModel.YearsinCMProgram = 3;
            inputEmploymentPracticesModel.IRPMFactor = Convert.ToDecimal(1.20);
            inputEmploymentPracticesModel.OtherModFactor = Convert.ToDecimal(0.75);
            inputEmploymentPracticesModel.IRPMApplies = true;
        }

        public void InitializeOptionalCoveragePremium3(RaterFacadeModel model)
        {
            var inputEmploymentPracticesOptionalCoverageModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesLimit = 50000;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesAggregateLimit = 0;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesDeductible = 10000;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesRatingBasis = "FlatCharge";
            inputEmploymentPracticesOptionalCoverageModel.BackWagesReturnMethod = "Prorata";
            inputEmploymentPracticesOptionalCoverageModel.BackWagesRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.BackWagesModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit = 50000;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit = 200000;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseDeductible = 2500;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRatingBasis = "FlatCharge";
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseReturnMethod = "Prorata";
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium = 2000;
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCIsSelected = true;
            inputEmploymentPracticesOptionalCoverageModel.EEOCLimit = 10000;
            inputEmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit = 50000;
            inputEmploymentPracticesOptionalCoverageModel.EEOCDeductible = 2500;
            inputEmploymentPracticesOptionalCoverageModel.EEOCRatingBasis = "FlatCharge";
            inputEmploymentPracticesOptionalCoverageModel.EEOCReturnMethod = "Prorata";
            inputEmploymentPracticesOptionalCoverageModel.EEOCRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.EEOCModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIsSelected = false;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActLimit = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActAggregateLimit = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDeductible = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRatingBasis = "";
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActReturnMethod = "";
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActModifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected = false;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodLimit = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodDeductible = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis = "string";
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod = "string";
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium = 0;

            inputEmploymentPracticesOptionalCoverageModel.BackWagesIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.EEOCDefenseIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActDefenseIncludedInExcessExposure = "false";
            inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIncludedInExcessExposure = "false";
            var inputEmploymentPracticesOtherCoverageModelList = new List<EmploymentPracticesOtherCoverageInputModel>();
            inputEmploymentPracticesOtherCoverageModelList.Add(new EmploymentPracticesOtherCoverageInputModel
            {
                OtherCoverageID = 1,
                OtherCoverageLimit = 10000,
                OtherCoverageAggregateLimit = 50000,
                OtherCoverageDeductible = 0,
                OtherCoverageRate = Convert.ToDecimal(0.50),
                OtherCoverageRatingBasis = "per 1000 of limit",
                OtherCoverageReturnMethod = "Prorata",
                OtherCoverageUnmodifiedPremium = 25,
                OtherCoverageModifiedPremium = 0,
                OtherCoverageIncludedInExcessExposure="false"
            });
            inputEmploymentPracticesOtherCoverageModelList.Add(new EmploymentPracticesOtherCoverageInputModel
            {
                OtherCoverageID = 2,
                OtherCoverageLimit = 80000,
                OtherCoverageAggregateLimit = 80000,
                OtherCoverageDeductible = 0,
                OtherCoverageRate = Convert.ToDecimal(0.50),
                OtherCoverageRatingBasis = "PER 1000 OF LIMIT",
                OtherCoverageReturnMethod = "Prorata",
                OtherCoverageUnmodifiedPremium = 40,
                OtherCoverageModifiedPremium = 0
            });
            inputEmploymentPracticesOtherCoverageModelList.Add(new EmploymentPracticesOtherCoverageInputModel
            {
                OtherCoverageID = 3,
                OtherCoverageLimit = 50000,
                OtherCoverageAggregateLimit = 10000,
                OtherCoverageDeductible = 0,
                OtherCoverageRate = Convert.ToDecimal(0.10),
                OtherCoverageRatingBasis = "per 100 of limit",
                OtherCoverageReturnMethod = "Prorata",
                OtherCoverageUnmodifiedPremium = 50,
                OtherCoverageModifiedPremium = 0
            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = inputEmploymentPracticesOptionalCoverageModel;
            model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel = inputEmploymentPracticesOtherCoverageModelList;
        }
        #endregion
    }
}
