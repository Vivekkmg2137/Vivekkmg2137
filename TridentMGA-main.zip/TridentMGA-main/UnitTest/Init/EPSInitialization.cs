﻿using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EmploymentPracticesSchool.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPracticesSchool.Output;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class EPSInitialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.EmploymentPracticesSchool = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool = new EmploymentPracticesSchoolInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel = new EmploymentPracticesSchoolOptionalCoverageInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel.EmploymentPracticesSchoolOtherCoverageModel = new List<EmploymentPracticesSchoolOtherCoverageInputModel>();
            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool = new EmploymentPracticesSchoolOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel = new EmploymentPracticesSchoolOptionalCoverageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.EmploymentPracticesSchool.EmploymentPracticesSchoolOptionalCoverageModel.EmploymentPracticesSchoolOtherCoverageModel = new List<EmploymentPracticesSchoolOtherCoverageOutputModel>();
        }

        public void InitializeEPSPremium(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.CT;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MSC";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("02-09-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("02-09-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("01-10-2022");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Rural";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 50000;

            #endregion

            #region PricingInputModel
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Standard";
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;

            #endregion

            var InputEPSModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
            InputEPSModel.Exposure = 1000;
            InputEPSModel.ExposureRate = 5;
            InputEPSModel.LiabilityLimit = 100000;
            InputEPSModel.AggregateLimit = 300000;
            InputEPSModel.LiabilityLimitRate = 300000;
            InputEPSModel.DeductibleSIR = "Deductible";
            InputEPSModel.Retention = 1000;
            InputEPSModel.AggregateRetention = 1;
            InputEPSModel.Type = "";
            InputEPSModel.Expense = "";
            InputEPSModel.LossExperienceIsSelected = true;
            InputEPSModel.PolicyType = "Claims Made";
            InputEPSModel.RetroActiveDate = Convert.ToDateTime("10-10-2022");
            InputEPSModel.YearsinCMProgram = 2;
            InputEPSModel.IRPMRate = 1;
            InputEPSModel.OtherModRate = 1;
            InputEPSModel.IRPMApplies = true;
        }

        public void InitializeOptionalCoveragePremium(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.CT;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MSC";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("01-08-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("30-12-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2022");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            #endregion

            #region PricingInputModel
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Standard";
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;
            #endregion

            var InputEPSModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
            var inputEPSOptionalCoverage = InputEPSModel.EmploymentPracticesSchoolOptionalCoverageModel;
            //     var inputOtherOptionalCoverage = inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverage;
            inputEPSOptionalCoverage.NonMonetaryDefenseIsSelected = true;
            inputEPSOptionalCoverage.NonMonetaryDefenseLimit = 50000;
            inputEPSOptionalCoverage.NonMonetaryDefenseAggregateLimit = 100000;
            inputEPSOptionalCoverage.NonMonetaryDefenseDeductible = 0;
            inputEPSOptionalCoverage.NonMonetaryDefenseRatingBasis = "";
            inputEPSOptionalCoverage.NonMonetaryDefenseReturnMethod = "";
            inputEPSOptionalCoverage.NonMonetaryDefenseRate = 0;
            inputEPSOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium = 0;
            inputEPSOptionalCoverage.NonMonetaryDefenseModifiedPremium = 0;
            inputEPSOptionalCoverage.EEOCIsSelected = true;
            inputEPSOptionalCoverage.EEOCLimit = 25000;
            inputEPSOptionalCoverage.EEOCAggregateLimit = 50000;
            inputEPSOptionalCoverage.EEOCDeductible = 0;
            inputEPSOptionalCoverage.EEOCRatingBasis = "";
            inputEPSOptionalCoverage.EEOCRate = 100;
            inputEPSOptionalCoverage.EEOCUnmodifiedPremium = 0;
            inputEPSOptionalCoverage.EEOCModifiedPremium = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActIsSelected = true;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActLimit = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActAggregateLimit = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActDeductible = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActRatingBasis = "";
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActRate = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActReturnMethod = "";
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActModifiedPremium = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodIsSelected = true;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodLimit = 12;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "";
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "";
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;


            // Other Coverage 
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel = new List<EmploymentPracticesSchoolOtherCoverageInputModel>();
            EmploymentPracticesSchoolOtherCoverageInputModel OtherCoverage = new EmploymentPracticesSchoolOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 0;
            OtherCoverage.OtherCoverageLimit = 100000;
            OtherCoverage.OtherCoverageAggregateLimit = 0;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "PER 1000 OF LIMIT";
            OtherCoverage.OtherCoverageReturnMethod = "";
            OtherCoverage.OtherCoverageRate = 10000;
            OtherCoverage.OtherCoverageUnmodifiedPremium = 20000;
            OtherCoverage.OtherCoverageModifiedPremium = 50000;
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel.Add(OtherCoverage);
        }

        #region FOR  StateCode=CT 
        public void InitializeEPSPremium1(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.CT;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MSC";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("02-09-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("02-09-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("01-10-2022");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Rural";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 50000;

            #endregion

            #region PricingInputModel
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Standard";
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;

            #endregion

            var InputEPSModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;


            InputEPSModel.Exposure = 550;
            InputEPSModel.ExposureRate = Convert.ToDecimal(4.550);
            InputEPSModel.AggregateLimit = 300000;
            InputEPSModel.LiabilityLimit = 300000;
            InputEPSModel.LiabilityLimitRate = Convert.ToDecimal(0.790);
            InputEPSModel.DeductibleSIR = "deductible";
            InputEPSModel.Retention = 500;
            InputEPSModel.AggregateRetention = 1; //  Convert.ToDecimal(1.050);  //In Req.  this field is interger ? 
            InputEPSModel.Type = "Each Wrongful Act";
            InputEPSModel.Expense = "Included";
            InputEPSModel.LossExperienceIsSelected = true;
            InputEPSModel.PolicyType = "Claims Made";
            InputEPSModel.RetroActiveDate = Convert.ToDateTime("2018-12-12T09:12:31.622Z");  
            InputEPSModel.YearsinCMProgram = 2;
            InputEPSModel.IRPMRate = Convert.ToDecimal(1.00);
            InputEPSModel.OtherModRate = Convert.ToDecimal(1.00);
            InputEPSModel.IRPMApplies = true;

            InitializeOptionalCoveragePremium1(model);
        }

        public void InitializeOptionalCoveragePremium1(RaterFacadeModel model)
        {            
            var InputEPSModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
            var inputEPSOptionalCoverage = InputEPSModel.EmploymentPracticesSchoolOptionalCoverageModel;
            inputEPSOptionalCoverage.NonMonetaryDefenseIsSelected = true;
            inputEPSOptionalCoverage.NonMonetaryDefenseLimit = 50000;
            inputEPSOptionalCoverage.NonMonetaryDefenseAggregateLimit = 100000;
            inputEPSOptionalCoverage.NonMonetaryDefenseDeductible = 2500;
            inputEPSOptionalCoverage.NonMonetaryDefenseRatingBasis = "Flat Charge";
            inputEPSOptionalCoverage.NonMonetaryDefenseReturnMethod = "Pro rata";
            inputEPSOptionalCoverage.NonMonetaryDefenseRate = 0;
            inputEPSOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium = 1500;
            inputEPSOptionalCoverage.NonMonetaryDefenseModifiedPremium = 0;
            inputEPSOptionalCoverage.EEOCIsSelected = true;
            inputEPSOptionalCoverage.EEOCLimit = 25000;
            inputEPSOptionalCoverage.EEOCAggregateLimit = 50000;
            inputEPSOptionalCoverage.EEOCDeductible = 2500;
            inputEPSOptionalCoverage.EEOCRatingBasis = "Flat Charge";
            inputEPSOptionalCoverage.EEOCReturnMethod = "Pro rata";
            inputEPSOptionalCoverage.EEOCRate = 0;
            inputEPSOptionalCoverage.EEOCUnmodifiedPremium = 750;
            inputEPSOptionalCoverage.EEOCModifiedPremium = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActIsSelected = true;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActLimit = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActAggregateLimit = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActDeductible = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActRatingBasis = "Flat Charge";
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActRate = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActReturnMethod = "Pro rata";
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = 60;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActModifiedPremium = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodIsSelected = true;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodLimit = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "";
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "";
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;


            // Other Coverage 
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel = new List<EmploymentPracticesSchoolOtherCoverageInputModel>();
            EmploymentPracticesSchoolOtherCoverageInputModel OtherCoverage = new EmploymentPracticesSchoolOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 1;
            OtherCoverage.OtherCoverageLimit = 20000;
            OtherCoverage.OtherCoverageAggregateLimit = 100;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "Flat charge";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = 0;
            OtherCoverage.OtherCoverageUnmodifiedPremium = 20;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel.Add(OtherCoverage);
            // index 2
            OtherCoverage = new EmploymentPracticesSchoolOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 2;
            OtherCoverage.OtherCoverageLimit = 50000;
            OtherCoverage.OtherCoverageAggregateLimit = 10;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "PER 1000 OF LIMIT";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = Convert.ToDecimal(0.80);
            OtherCoverage.OtherCoverageUnmodifiedPremium = 40;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel.Add(OtherCoverage);
            // index 3
            OtherCoverage = new EmploymentPracticesSchoolOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 3;
            OtherCoverage.OtherCoverageLimit = 20000;
            OtherCoverage.OtherCoverageAggregateLimit = 10;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "PER 100 OF LIMIT";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = Convert.ToDecimal(0.30);
            OtherCoverage.OtherCoverageUnmodifiedPremium = 60;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel.Add(OtherCoverage);
        }

        #endregion


        #region FOR  StateCode=MA 

        public void InitializeEPSPremium2(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.MA;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MSC";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("09-02-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("09-02-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("09-02-2022");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 25000;

            #endregion

            #region PricingInputModel
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Standard";
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;

            #endregion

            var InputEPSModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;


            InputEPSModel.Exposure = 400;
            InputEPSModel.ExposureRate = Convert.ToDecimal(4.060);
            InputEPSModel.AggregateLimit = 200000;
            InputEPSModel.LiabilityLimit = 100000;
            InputEPSModel.LiabilityLimitRate = Convert.ToDecimal(0.660);
            InputEPSModel.DeductibleSIR = "deductible";
            InputEPSModel.Retention = 1000;
            InputEPSModel.AggregateRetention = 1; //  Convert.ToDecimal(1.050);  //In Req.  this field is interger ? 
            InputEPSModel.Type = "Per Claimant";
            InputEPSModel.Expense = "Included";
            InputEPSModel.LossExperienceIsSelected = true;
            InputEPSModel.PolicyType = "Claims Made";
            InputEPSModel.RetroActiveDate = Convert.ToDateTime("2017-12-12T09:12:31.622Z");
            InputEPSModel.YearsinCMProgram = 3;
            InputEPSModel.IRPMRate = Convert.ToDecimal(0.90);
            InputEPSModel.OtherModRate = Convert.ToDecimal(0.75);
            InputEPSModel.IRPMApplies = true;

            InitializeOptionalCoveragePremium2(model);
        }

        public void InitializeOptionalCoveragePremium2(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.MA;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MSC";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("02-09-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("02-09-2021");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2022");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 25000;
            #endregion

            #region PricingInputModel
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Standard";
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;
            #endregion

            var InputEPSModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
            var inputEPSOptionalCoverage = InputEPSModel.EmploymentPracticesSchoolOptionalCoverageModel;
            //     var inputOtherOptionalCoverage = inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverage;
            inputEPSOptionalCoverage.NonMonetaryDefenseIsSelected = true;
            inputEPSOptionalCoverage.NonMonetaryDefenseLimit = 50000;
            inputEPSOptionalCoverage.NonMonetaryDefenseAggregateLimit = 50000;
            inputEPSOptionalCoverage.NonMonetaryDefenseDeductible = 2500;
            inputEPSOptionalCoverage.NonMonetaryDefenseRatingBasis = "Flat Charge";
            inputEPSOptionalCoverage.NonMonetaryDefenseReturnMethod = "Pro rata";
            inputEPSOptionalCoverage.NonMonetaryDefenseRate = 0;
            inputEPSOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium = 0;
            inputEPSOptionalCoverage.NonMonetaryDefenseModifiedPremium = 0;
            inputEPSOptionalCoverage.EEOCIsSelected = true;
            inputEPSOptionalCoverage.EEOCLimit = 25000;
            inputEPSOptionalCoverage.EEOCAggregateLimit = 50000;
            inputEPSOptionalCoverage.EEOCDeductible = 2500;
            inputEPSOptionalCoverage.EEOCRatingBasis = "Flat Charge";
            inputEPSOptionalCoverage.EEOCReturnMethod = "Pro rata";
            inputEPSOptionalCoverage.EEOCRate = 0;
            inputEPSOptionalCoverage.EEOCUnmodifiedPremium = 750;
            inputEPSOptionalCoverage.EEOCModifiedPremium = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActIsSelected = true;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActLimit = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActAggregateLimit = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActDeductible = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActRatingBasis = "";
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActRate = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActReturnMethod = "";
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActUnmodifiedPremium = 0;
            inputEPSOptionalCoverage.LossAdjustmentExpenseWrongfulActModifiedPremium = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodIsSelected = true;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodLimit = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "";
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "";
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputEPSOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;


            // Other Coverage 
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel = new List<EmploymentPracticesSchoolOtherCoverageInputModel>();
            EmploymentPracticesSchoolOtherCoverageInputModel OtherCoverage = new EmploymentPracticesSchoolOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 1;
            OtherCoverage.OtherCoverageLimit = 50000;
            OtherCoverage.OtherCoverageAggregateLimit = 100;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "Flat charge";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = 0;
            OtherCoverage.OtherCoverageUnmodifiedPremium = 50;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel.Add(OtherCoverage);
            // index 2
            OtherCoverage = new EmploymentPracticesSchoolOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 2;
            OtherCoverage.OtherCoverageLimit = 150000;
            OtherCoverage.OtherCoverageAggregateLimit = 100;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "PER 1000 OF LIMIT";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = Convert.ToDecimal(0.80);
            OtherCoverage.OtherCoverageUnmodifiedPremium = 120;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel.Add(OtherCoverage);
            // index 3
            OtherCoverage = new EmploymentPracticesSchoolOtherCoverageInputModel();
            OtherCoverage.OtherCoverageID = 3;
            OtherCoverage.OtherCoverageLimit = 50000;
            OtherCoverage.OtherCoverageAggregateLimit = 100;
            OtherCoverage.OtherCoverageDeductible = 0;
            OtherCoverage.OtherCoverageRatingBasis = "PER 100 OF LIMIT";
            OtherCoverage.OtherCoverageReturnMethod = "Pro rata";
            OtherCoverage.OtherCoverageRate = Convert.ToDecimal(0.10);
            OtherCoverage.OtherCoverageUnmodifiedPremium = 50;
            OtherCoverage.OtherCoverageModifiedPremium = 0;
            inputEPSOptionalCoverage.EmploymentPracticesSchoolOtherCoverageModel.Add(OtherCoverage);
        }
      #endregion 
    }
}

