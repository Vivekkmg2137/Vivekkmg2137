﻿using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.GeneralLiability.Input;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class GeneralLiabilityInitialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }

            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.GeneralLiability = true;

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability = new Models.ApiModels.LineOfBusiness.GeneralLiability.Input.GeneralLiabilityInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel = new Models.ApiModels.LineOfBusiness.GeneralLiability.Input.GeneralLiabilityOptionalCoverageInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.GeneralLiabilityOptionalOtherCoverageModel = new List<Models.ApiModels.LineOfBusiness.GeneralLiability.Input.GeneralLiabilityOptionalOtherCoverageInputModel>();

            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability = new Models.ApiModels.LineOfBusiness.GeneralLiability.output.GeneralLiabilityOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel = new Models.ApiModels.LineOfBusiness.GeneralLiability.output.GeneralLiabilityOptionalCoverageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.GeneralLiabilityOptionalOtherCoverageModel = new List<Models.ApiModels.LineOfBusiness.GeneralLiability.output.GeneralLiabilityOptionalOtherCoverageOutputModel>();
        }

        public void InitializationGLCase1(RaterFacadeModel raterFacadeModel)
        {
            InitializationGLBasePremiumCase1(raterFacadeModel);

            InitializationGLDamageToPremisesPremiumCase1(raterFacadeModel);

            InitializationGLMedicalPaymentsPremiumCase1(raterFacadeModel);

            InitializationGLEmployeeBenefitsPremiumCase1(raterFacadeModel);

            InitializationGLDataCompromisePremiumCase1(raterFacadeModel);

            InitializationGLCyberPremiumCase1(raterFacadeModel);

            InitializationGLUnmannedAircraftTotalPremiumCase1(raterFacadeModel);

            InitializationGLOptionalCoveragePremiumCase1(raterFacadeModel);

            InitializationGLNonModifiedPremiumCase1(raterFacadeModel);

            InitializationGLModifiablePremiumCase1(raterFacadeModel);

            InitializationGLManualPremiumCase1(raterFacadeModel);

            InitializationGLTierPremiumCase1(raterFacadeModel);

            InitializationGLIRPMPremiumCase1(raterFacadeModel);

            InitializationGLOtherModPremiumCase1(raterFacadeModel);

            InitializationGLTerrorismPremiumCase1(raterFacadeModel);

            InitializationGLFinalModifiedPremiumCase1(raterFacadeModel);

            InitializationGLTotalUnmodifiedWithoutExcessPremiumCase1(raterFacadeModel);
        }

        public void InitializationGLBasePremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;

            #region PolicyHeaderModel

            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 3500;
            model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage = true;
            model.RaterInputFacadeModel.PolicyHeaderModel.IsEndorsement = false;

            //Case 1 Get BaseRate
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.NC;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Rural";
            model.RaterInputFacadeModel.PolicyHeaderModel.Excess = true;

            #endregion
        
            inputProperty.Exposure = 2000;
            inputProperty.ADA = 10;
            inputProperty.ADARate = -1;
            inputProperty.LiabilityLimit = "1000000";
            inputProperty.AggregateLimit = 1000000;
            inputProperty.LiabilityLimitRate = -1;
            inputProperty.DeductibleSIR = "Deductible";
            inputProperty.Retention = 500;
            inputProperty.PolicyType = "Occurrence";
            inputProperty.YearsinClaimsMadeProgram = 1;
            inputProperty.LossExperienceIsSelected = true;
            inputProperty.RetroActiveDate = Convert.ToDateTime("2018-10-10T09:37:09.510Z");
            inputProperty.IRPMFactor = 1;
            inputProperty.OtherModFactor = 1;
        }

        public void InitializationGLDamageToPremisesPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            inputProperty.DamageToPremisesUnmodifiedPremium = 1000;

        }

        public void InitializationGLMedicalPaymentsPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            inputProperty.MedicalPaymentLimit = "INCLUDED";
            inputProperty.MedicalPaymentUnmodifiedPremium = 1000;

        }

        public void InitializationGLEmployeeBenefitsPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            inputProperty.EBLimit = "1";

        }

        public void InitializationGLDataCompromisePremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            inputProperty.DataCompromiseLimit = 1000;
            inputProperty.ResponseExpensePremium = 100;
            inputProperty.DataCompromiseReferralIsSelected = true;
            inputProperty.NYCyberYearsinClaimsMade = 2;
        }

        public void InitializationGLCyberPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            inputProperty.ComputerAttackLimit = 100000;
            inputProperty.CyberReferralIsSelected = false;
            inputProperty.NetworkSecurityAndElectronicMediaLiabilityLimit = 100000;
            inputProperty.NYCyberYearsinClaimsMade = 2;
        }

        public void InitializationGLUnmannedAircraftTotalPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            inputProperty.UnmannedAircraftOption = "INCLUDED";
            inputProperty.UnmannedAircraftAggregateLimit = 50000;
            inputProperty.UnmannedAircraftcoverage15lbsorLessTotalUnits = 100;
        }

        public void InitializationGLOptionalCoveragePremiumCase1(RaterFacadeModel model)
        {
            var inputOptionalProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel;

            inputOptionalProperty.CemeteryProfessionalLiabilityGL203IsSelected = true;
            inputOptionalProperty.CemeteryProfessionalLiabilityGL203UnmodifiedPremium = 10000;

            inputOptionalProperty.DataCompromiseSupplExtendedReportingPeriodIsSelected = true;

            inputOptionalProperty.FailuretoSupplyExclusionGL304IsSelected = true;

            inputOptionalProperty.FailuretoSupplySublimitGL211IsSelected = true;

            inputOptionalProperty.FellowEmployeeGL206IsSelected = true;

            inputOptionalProperty.LimitedPollutionCoverageGL210IsSelected = true;

            inputOptionalProperty.SewerBackupAggregateLimitGL217IsSelected = true;
            inputOptionalProperty.SewerBackupAggregateLimitGL217UnmodifiedPremium = 10000;

            inputOptionalProperty.SewerBackupSublimitGL260IsSelected = true;
            inputOptionalProperty.SewerBackupSublimitGL260UnmodifiedPremium = 10000;

            inputOptionalProperty.AdditionalInsuredControllingInterestCG2005IsSelected = true;
            inputOptionalProperty.AdditionalInsuredControllingInterestCG2005UnmodifiedPremium = 10000;

            inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected = true;
            inputOptionalProperty.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium = 10000;

            inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IsSelected = true;
            inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium = 10000;

            inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028IsSelected = true;
            inputOptionalProperty.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium = 10000;

            inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011IsSelected = true;
            inputOptionalProperty.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium = 10000;

            inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected = true;
            inputOptionalProperty.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium = 10000;

            inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IsSelected = true;
            inputOptionalProperty.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium = 10000;

            inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008IsSelected = true;
            inputOptionalProperty.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium = 10000;

            inputOptionalProperty.GeneralLiabilityOptionalOtherCoverageModel = new List<GeneralLiabilityOptionalOtherCoverageInputModel>();

            inputOptionalProperty.GeneralLiabilityOptionalOtherCoverageModel.Add(new GeneralLiabilityOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 1,
                OtherCoverageDeductible = 0,
                OtherCoverageAggregateLimit = 0,
                OtherCoverageDescription = "",
                OtherCoverageIncludedinExcessExposure = "",
                OtherCoverageLimit = 0,
                OtherCoverageRate = 0.0M,
                OtherCoverageRatingBasis = "",
                OtherCoverageReturnMethod = "",
                OtherCoverageUnmodifiedPremium = 0
            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel = inputOptionalProperty;
        }

        public void InitializationGLNonModifiedPremiumCase1(RaterFacadeModel model)
        {

        }

        public void InitializationGLModifiablePremiumCase1(RaterFacadeModel model)
        {

        }

        public void InitializationGLManualPremiumCase1(RaterFacadeModel model)
        {

        }

        public void InitializationGLTierPremiumCase1(RaterFacadeModel model)
        {

        }

        public void InitializationGLIRPMPremiumCase1(RaterFacadeModel model)
        {

        }

        public void InitializationGLOtherModPremiumCase1(RaterFacadeModel model)
        {

        }

        public void InitializationGLTerrorismPremiumCase1(RaterFacadeModel model)
        {

        }

        public void InitializationGLFinalModifiedPremiumCase1(RaterFacadeModel model)
        {

        }

        public void InitializationGLTotalUnmodifiedWithoutExcessPremiumCase1(RaterFacadeModel model)
        {

        }
        
    }
}
