﻿using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.LawEnforcement.Input;
using Models.ApiModels.LineOfBusiness.LawEnforcement.Output;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class LawInitialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.LawEnforcement = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement = new LawEnforcementInputModel();
            var inputModel=raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            inputModel.LawEnforcementOptionalCoverageModel = new LawEnforcementOptionalCoverageInputModel();
            inputModel.LawEnforcementOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel = new List<LawEnforcementOptionalOtherCoverageInputModel>();

            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement = new LawEnforcementOutputModel();
            var outputModel=raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;
            outputModel.LawEnforcementOptionalCoverageModel = new LawEnforcementOptionalCoverageOutputModel();
            outputModel.LawEnforcementOptionalCoverageModel.LawEnforcementOptionalOtherCoverageModel = new List<LawEnforcementOptionalOtherCoverageOutputModel>();
        }

        #region Initialize Law Enforcement for CT State

        public void InitializationCase1(RaterFacadeModel model)
        {
            // Initialize Law for CT state
            InitializeInitialRatesCase1(model);

            InitializeUnmannedAircraftPremiumCase1(model);

            InitializeOptionalCoveragesPremiumCase1(model);

            InitializeBasePremiumCase1(model);

            InitializeTierPremiumCase1(model);

            InitializeIRPMPremiumCase1(model);

            InitializeOtherModPremiumCase1(model);
        }

        private void InitializeInitialRatesCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;

            #region PolicyHeaderModel

            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.CT;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "CO";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Rural";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("01-09-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 10000;
            model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage = true;
            model.RaterInputFacadeModel.PolicyHeaderModel.IsEndorsement = false;

            #endregion

            inputProperty.Officer = 100;
            inputProperty.ExposureRate = 894.000M;
            inputProperty.LiabilityLimit = 500000;
            inputProperty.AggregateLimit = 1000000;
            inputProperty.LiabilityLimitRate = 0.870M;
            inputProperty.Deductible_SIR = "Deductible";
            inputProperty.Retention = "2500";
            inputProperty.AggregateRetention = 0;
            inputProperty.Type = "Each Wrongful Act";
            inputProperty.Expense = "Included";
            inputProperty.ExperienceFactor = true;
            inputProperty.PolicyType = "Claims Made";
            inputProperty.RetroActiveDate = Convert.ToDateTime("08-01-2019");
            inputProperty.YearsinCMProgram = 1;
            inputProperty.IRPMRate = 1.15M;
            inputProperty.OtherModRate = 1.00M;
            inputProperty.IRPMApplies = true;

        }

        private void InitializeUnmannedAircraftPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;

            inputProperty.UnmannedAircraftOption = "Unmanned Aircraft Policy Limit - LE104";
            inputProperty.UnmannedAircraftAggregateLimit = 25000;
            inputProperty.UnmannedAircraftCoverageIncludedInExcessExposure = "";
            inputProperty.UnmannedAircraftCoverage15lbsorLessRate = 750;
            inputProperty.UnmannedAircraftCoverage15lbsorLessTotalUnits = 2;
            inputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate = 1100;
            inputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsTotalUnits = 1;
            inputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate = 2500;
            inputProperty.UnmannedAircraftCoverage_gteq55lbsTotalUnits = 1;

        }

        private void InitializeOptionalCoveragesPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;

            inputProperty.LawEnforcementOptionalCoverageModel = new Models.ApiModels.LineOfBusiness.LawEnforcement.Input.LawEnforcementOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.LawEnforcementOptionalCoverageModel;

            //Optional Coverage I Additional Insured - Law Enforcement Agencies -AG LE 0006
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesIsSelected = true;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesIncludedInExcessExposure = "";
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesLimit = 0;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesAggregateLimit = 0;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesDeductible = 0;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesRatingBasis = "Flat charge";
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesReturnMethod = "Pro-rata";
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesRate = 0;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium = 20;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesModifiedPremium = 0;

            //Optional Coverage II - Suppl.Extended Reporting Period
            inputOptionalCoverage.SupplExtendedReportingPeriodIsSelected = false;
            inputOptionalCoverage.SupplExtendedReportingPeriodLimit = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "string";
            inputOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "string";
            inputOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;

            //Optional Coverage III - NY - Suppl.Extended Reporting Period
            inputOptionalCoverage.NYSupplExtendedReportingPeriodIsSelected = false;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodLimit = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodAggregateLimit = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodDeductible = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodRatingBasis = "string";
            inputOptionalCoverage.NYSupplExtendedReportingPeriodReturnMethod = "string";
            inputOptionalCoverage.NYSupplExtendedReportingPeriodRate = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodModifiedPremium = 0;

            //Optional Coverage IV -  Non Monetary Defense
            inputOptionalCoverage.NonMonetaryDefenseIsSelected = false;
            inputOptionalCoverage.NonMonetaryDefenseLimit = 0;
            inputOptionalCoverage.NonMonetaryDefenseAggregateLimit = 0;
            inputOptionalCoverage.NonMonetaryDefenseDeductible = 0;
            inputOptionalCoverage.NonMonetaryDefenseRatingBasis = "string";
            inputOptionalCoverage.NonMonetaryDefenseReturnMethod = "string";
            inputOptionalCoverage.NonMonetaryDefenseRate = 0;
            inputOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium = 0;
            inputOptionalCoverage.NonMonetaryDefenseModifiedPremium = 0;

            //Optional Coverage V - Line of Duty Death Benefits
            inputOptionalCoverage.LineOfDutyDeathBenefitsIsSelected = true;
            inputOptionalCoverage.LineOfDutyDeathBenefitsLimit = 50000;
            inputOptionalCoverage.LineOfDutyDeathBenefitsAggregateLimit = 100000;
            inputOptionalCoverage.LineOfDutyDeathBenefitsDeductible = 0;
            inputOptionalCoverage.LineOfDutyDeathBenefitsRatingBasis = "FLAT CHARGE";
            inputOptionalCoverage.LineOfDutyDeathBenefitsReturnMethod = "Pro-rata";
            inputOptionalCoverage.LineOfDutyDeathBenefitsRate = 0;
            inputOptionalCoverage.LineOfDutyDeathBenefitsUnmodifiedPremium = 500;
            inputOptionalCoverage.LineOfDutyDeathBenefitsModifiedPremium = 0;

            inputOptionalCoverage.LawEnforcementOptionalOtherCoverageModel = new List<LawEnforcementOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.LawEnforcementOptionalOtherCoverageModel.Add(new LawEnforcementOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 1,
                OtherCoverageDescription = "Other1 FC",
                OtherCoverageLimit = 10000,
                OtherCoverageAggregateLimit = 20000,
                OtherCoverageDedcutible = 10,
                OtherCoverageRate = 0,
                OtherCoverageRatingBasis = "Flat Charge",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageUnmodifiedPremium = 20
            });

            inputOptionalCoverage.LawEnforcementOptionalOtherCoverageModel.Add(new LawEnforcementOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 2,
                OtherCoverageDescription = "Other3 FC",
                OtherCoverageLimit = 100000,
                OtherCoverageAggregateLimit = 100000,
                OtherCoverageDedcutible = 10,
                OtherCoverageRate = 0.60M,
                OtherCoverageRatingBasis = "Per 1000 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageUnmodifiedPremium = 60
            });

            inputOptionalCoverage.LawEnforcementOptionalOtherCoverageModel.Add(new LawEnforcementOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 3,
                OtherCoverageDescription = "Other3 FC",
                OtherCoverageLimit = 100000,
                OtherCoverageAggregateLimit = 100000,
                OtherCoverageDedcutible = 20,
                OtherCoverageRate = 0.10M,
                OtherCoverageRatingBasis = "Per 100 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageUnmodifiedPremium = 100
            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel = inputOptionalCoverage;

        }

        private void InitializeBasePremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;

            inputProperty.Officer = 100;
        }

        private void InitializeTierPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;

            //Case 1 Get Tier Factor
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "Substandard";
        }

        private void InitializeIRPMPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;

            //Case 1 Get IRPM Factor
            inputProperty.IRPMRate = 1.15M;
        }

        private void InitializeOtherModPremiumCase1(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;

            //Case 1 Get IRPM Factor
            inputProperty.OtherModRate = 1.00M;
        }

        #endregion

        #region Initialize Law Enforcement for NY State

        public void InitializationCase2(RaterFacadeModel model)
        {
            // Initialize Law for CT state
            InitializeInitialRatesCase2(model);

            InitializeUnmannedAircraftPremiumCase2(model);

            InitializeOptionalCoveragesPremiumCase2(model);

            InitializeBasePremiumCase2(model);

            InitializeTierPremiumCase2(model);

            InitializeIRPMPremiumCase2(model);

            InitializeOtherModPremiumCase2(model);

        }

        private void InitializeInitialRatesCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;

            #region PolicyHeaderModel

            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.NY;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "SC";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "METRO";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("01-09-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 50000;
            model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage = true;
            model.RaterInputFacadeModel.PolicyHeaderModel.IsEndorsement = false;

            #endregion

            inputProperty.Officer = 300;
            inputProperty.ExposureRate = 920.000M;
            inputProperty.LiabilityLimit = 100000;
            inputProperty.AggregateLimit = 300000;
            inputProperty.LiabilityLimitRate = 0.660M;
            inputProperty.Deductible_SIR = "Deductible";
            inputProperty.Retention = "$1,000 Loss + 50% LAE";
            inputProperty.AggregateRetention = 0;
            inputProperty.Type = "Each Wrongful Act";
            inputProperty.Expense = "Included";
            inputProperty.ExperienceFactor = true;
            inputProperty.PolicyType = "Claims Made";
            inputProperty.RetroActiveDate = Convert.ToDateTime("08-01-2016");
            inputProperty.YearsinCMProgram = 2;
            inputProperty.IRPMRate = 1.00M;
            inputProperty.OtherModRate = 0.90M;
            inputProperty.IRPMApplies = true;

        }

        private void InitializeUnmannedAircraftPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;

            inputProperty.UnmannedAircraftOption = "Unmanned Aircraft Sublimit - LE105";
            inputProperty.UnmannedAircraftAggregateLimit = 500000;
            inputProperty.UnmannedAircraftCoverageIncludedInExcessExposure = "";
            inputProperty.UnmannedAircraftCoverage15lbsorLessRate = 500;
            inputProperty.UnmannedAircraftCoverage15lbsorLessTotalUnits = 3;
            inputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsRate = 625;
            inputProperty.UnmannedAircraftCoverage15PT1_to_lt55lbsTotalUnits = 2;
            inputProperty.UnmannedAircraftCoverage_gteq55lbslbsRate = 1000;
            inputProperty.UnmannedAircraftCoverage_gteq55lbsTotalUnits = 1;

        }

        private void InitializeOptionalCoveragesPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;

            inputProperty.LawEnforcementOptionalCoverageModel = new Models.ApiModels.LineOfBusiness.LawEnforcement.Input.LawEnforcementOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.LawEnforcementOptionalCoverageModel;

            //Optional Coverage I Additional Insured - Law Enforcement Agencies -AG LE 0006
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesIsSelected = false;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesIncludedInExcessExposure = "";
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesLimit = 0;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesAggregateLimit = 0;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesDeductible = 0;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesRatingBasis = "string";
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesReturnMethod = "string";
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesRate = 0;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium = 0;
            inputOptionalCoverage.AdditionalInsuredLawEnforcementAgenciesModifiedPremium = 0;

            //Optional Coverage II - Suppl.Extended Reporting Period
            inputOptionalCoverage.SupplExtendedReportingPeriodIsSelected = false;
            inputOptionalCoverage.SupplExtendedReportingPeriodLimit = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodDeductible = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodRatingBasis = "string";
            inputOptionalCoverage.SupplExtendedReportingPeriodReturnMethod = "string";
            inputOptionalCoverage.SupplExtendedReportingPeriodRate = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputOptionalCoverage.SupplExtendedReportingPeriodModifiedPremium = 0;

            //Optional Coverage III - NY - Suppl.Extended Reporting Period
            inputOptionalCoverage.NYSupplExtendedReportingPeriodIsSelected = false;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodLimit = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodAggregateLimit = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodDeductible = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodRatingBasis = "string";
            inputOptionalCoverage.NYSupplExtendedReportingPeriodReturnMethod = "string";
            inputOptionalCoverage.NYSupplExtendedReportingPeriodRate = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodUnmodifiedPremium = 0;
            inputOptionalCoverage.NYSupplExtendedReportingPeriodModifiedPremium = 0;


            //Optional Coverage IV -  Non Monetary Defense
            inputOptionalCoverage.NonMonetaryDefenseIsSelected = false;
            inputOptionalCoverage.NonMonetaryDefenseLimit = 0;
            inputOptionalCoverage.NonMonetaryDefenseAggregateLimit = 0;
            inputOptionalCoverage.NonMonetaryDefenseDeductible = 0;
            inputOptionalCoverage.NonMonetaryDefenseRatingBasis = "string";
            inputOptionalCoverage.NonMonetaryDefenseReturnMethod = "string";
            inputOptionalCoverage.NonMonetaryDefenseRate = 0;
            inputOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium = 0;
            inputOptionalCoverage.NonMonetaryDefenseModifiedPremium = 0;

            //Optional Coverage V - Line of Duty Death Benefits
            inputOptionalCoverage.LineOfDutyDeathBenefitsIsSelected = true;
            inputOptionalCoverage.LineOfDutyDeathBenefitsLimit = 50000;
            inputOptionalCoverage.LineOfDutyDeathBenefitsAggregateLimit = 100000;
            inputOptionalCoverage.LineOfDutyDeathBenefitsDeductible = 0;
            inputOptionalCoverage.LineOfDutyDeathBenefitsRatingBasis = "FLAT CHARGE";
            inputOptionalCoverage.LineOfDutyDeathBenefitsReturnMethod = "Pro-rata";
            inputOptionalCoverage.LineOfDutyDeathBenefitsRate = 0;
            inputOptionalCoverage.LineOfDutyDeathBenefitsUnmodifiedPremium = 500;
            inputOptionalCoverage.LineOfDutyDeathBenefitsModifiedPremium = 0;

            inputOptionalCoverage.LawEnforcementOptionalOtherCoverageModel = new List<LawEnforcementOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.LawEnforcementOptionalOtherCoverageModel.Add(new LawEnforcementOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 1,
                OtherCoverageDescription = "Other1 FC",
                OtherCoverageLimit = 100000,
                OtherCoverageAggregateLimit = 200000,
                OtherCoverageDedcutible = 10,
                OtherCoverageRate = 0,
                OtherCoverageRatingBasis = "Flat Charge",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageUnmodifiedPremium = 30

            });

            inputOptionalCoverage.LawEnforcementOptionalOtherCoverageModel.Add(new LawEnforcementOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 2,
                OtherCoverageDescription = "Other3 FC",
                OtherCoverageLimit = 500000,
                OtherCoverageAggregateLimit = 1000000,
                OtherCoverageDedcutible = 10,
                OtherCoverageRate = 0.30M,
                OtherCoverageRatingBasis = "Per 1000 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageUnmodifiedPremium = 150

            });

            inputOptionalCoverage.LawEnforcementOptionalOtherCoverageModel.Add(new LawEnforcementOptionalOtherCoverageInputModel
            {
                OtherCoverageID = 3,
                OtherCoverageDescription = "Other3 FC",
                OtherCoverageLimit = 100000,
                OtherCoverageAggregateLimit = 100000,
                OtherCoverageDedcutible = 20,
                OtherCoverageRate = 0.10M,
                OtherCoverageRatingBasis = "Per 100 of limit",
                OtherCoverageReturnMethod = "Pro-rata",
                OtherCoverageUnmodifiedPremium = 100

            });

            model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel = inputOptionalCoverage;

        }

        private void InitializeBasePremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;

            inputProperty.Officer = 300;
        }

        private void InitializeTierPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;

            //Case 1 Get Tier Factor
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = null;
        }

        private void InitializeIRPMPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;

            //Case 1 Get IRPM Factor
            inputProperty.IRPMRate = 1.00M;
        }

        private void InitializeOtherModPremiumCase2(RaterFacadeModel model)
        {
            var inputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            var outputProperty = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement;

            //Case 1 Get IRPM Factor
            inputProperty.OtherModRate = 0.90M;
        }

        #endregion
    }
}
