﻿using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Ocp.Input;
using Models.ApiModels.LineOfBusiness.Ocp.Output;
using Models.ApiModels.Policy;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;
using Models;

namespace UnitTest.Init
{
    /// <summary>
    /// OcpInitialization 
    /// </summary>
    public class OcpInitialization
    {
        /// <summary>
        /// Initialize: Initialize raterFacadeModel.
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            if (raterFacadeModel.RaterInputFacadeModel == null)
            {
                raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel();
            }
            if (raterFacadeModel.RaterOutputFacadeModel == null)
            {
                raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            }

            var raterInputFacade = raterFacadeModel.RaterInputFacadeModel;
            var raterOutputFacade = raterFacadeModel.RaterOutputFacadeModel;


            raterInputFacade.LineOfBusiness.Ocp1 = true;
            raterInputFacade.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterOutputFacade.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterInputFacade.PolicyHeaderModel = new PolicyHeaderModel();
            raterInputFacade.LineOfBusinessInputModel.Ocp1 = new OcpInputModel();
            raterOutputFacade.LineOfBusinessOutputModel.Ocp1 = new OcpOutputModel();

            raterInputFacade.LineOfBusiness.Ocp2 = false;
            raterInputFacade.LineOfBusinessInputModel.Ocp2 = new OcpInputModel();
            raterOutputFacade.LineOfBusinessOutputModel.Ocp2 = new OcpOutputModel();

            raterInputFacade.LineOfBusiness.Ocp3 = false;
            raterInputFacade.LineOfBusinessInputModel.Ocp3 = new OcpInputModel();
            raterOutputFacade.LineOfBusinessOutputModel.Ocp3 = new OcpOutputModel();


            raterInputFacade.LineOfBusiness.Ocp4 = false;
            raterInputFacade.LineOfBusinessInputModel.Ocp4 = new OcpInputModel();
            raterOutputFacade.LineOfBusinessOutputModel.Ocp4 = new OcpOutputModel();

            raterInputFacade.LineOfBusiness.Ocp5 = false;
            raterInputFacade.LineOfBusinessInputModel.Ocp5 = new OcpInputModel();
            raterOutputFacade.LineOfBusinessOutputModel.Ocp5 = new OcpOutputModel();

        }

        /// <summary>
        /// InitializeOCPCase1 : Model Initialization
        /// </summary>
        /// <param name="model"></param>
        public void InitializeOCPCase1(RaterFacadeModel model)
        {
            #region PolicyHeader

            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.NY;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            model.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass = "1";       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("01-08-2021");
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("01-08-2022");

            #endregion

            #region OCP model
            model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1.Description = "Work Permit";
            model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1.AggregateLimit = 100000;           
            model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1.Limit = 100000;
            model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1.Name = "test";
            model.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1.IRPMFlag = true;

            model.RaterInputFacadeModel.LineOfBusiness.Ocp2 = false;
            #endregion
        }

       
    }
}
