﻿using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Property.Input;
using Models.ApiModels.LineOfBusiness.Property.Output;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class Property360Initialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            var inputProperty = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var outputProperty = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;
            inputProperty.Property360InputModel = new Property360InputModel();
            outputProperty.Property360OutputModel = new Property360OutputModel();

            inputProperty.Property360InputModel.Property360OptionalCoverageInputModel = new Property360OptionalCoverageInputModel();
            inputProperty.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel = new List<Property360OptionalVacancyPermitInputModel>();
            inputProperty.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel = new List<Property360OptionalVehiclePhysicalDamageInputModel>();
            inputProperty.Property360InputModel.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel = new List<Property360OptionalLossOfMunicipalTaxRevenueInputModel>();

            outputProperty.Property360OutputModel.property360OptionalCoverageOutputModel = new Property360OptionalCoverageOutputModel();
            outputProperty.Property360OutputModel.property360OptionalCoverageOutputModel.LossOfMunicipalTaxRevenuesOutputModel = new List<Property360OptionalLossOfMunicipalTaxRevenueOutputModel>();
        }

        public void GetFacadeForCase1(PropertyInputModel propertyInputModel)
        {
            var input360Property = propertyInputModel.Property360InputModel;

            #region Property 360 BI EE Initialization

            input360Property.IsBusinessIncomeAndExtraExpenseCoverageSelected = true;
            input360Property.IsDependentPropertyCoverageSelected = true;
            input360Property.IsInterruptionOfComputerOperationsCoverageSelected = true;
            input360Property.IsLeaseCancellationMovingExpensesCoverageSelected = true;
            input360Property.IsNewlyAcquiredOrConstructedPropertyCoverageSelected = true;
            input360Property.IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageSelected = true;


            input360Property.BusinessIncomeAndExtraExpenseDays = 120;
            input360Property.BusinessIncomeAndExtraExpenseDeductible = 48;
            input360Property.BusinessIncomeAndExtraExpenseRevisedLimit = 600000;
            input360Property.DependentPropertyRevisedLimit = 150000;
            input360Property.InterruptionOfComputerOperationsRevisedLimit = 50000;
            input360Property.LeaseCancellationMovingExpensesRevisedLimit = 10000;
            input360Property.NewlyAcquiredOrConstructedPropertyRevisedLimit = 600000;
            input360Property.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseBIDeductible = 120;
            input360Property.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit = 55000;

            #endregion

            #region Property 360 Coverage Modification Initialization

            input360Property.IsOrdinanceOrLawCoverageBSelected = true;
            input360Property.IsOrdinanceOrLawCoverageCSelected = true;
            input360Property.IsAccountsReceivableRecordsCoverageSelected = true;
            input360Property.IsAppurtenantStructuresCoverageSelected = true;
            input360Property.IsAudioVisualAndCommunicationEquipmentCoverageSelected = true;
            input360Property.IsChangesInTemperatureOrHumidityCoverageSelected = true;
            input360Property.IsCommandeeredPropertyCoverageSelected = true;
            input360Property.IsComputerEquipmentCoverageSelected = true;
            input360Property.IsDebrisRemovalYourPremisesCoverageSelected = true;
            input360Property.IsDebrisRemovalWindBlownDebrisCoverageSelected = true;
            input360Property.IsElectronicDataCoverageSelected = true;
            input360Property.IsFineArtsCoverageSelected = true;
            input360Property.IsFireDepartmentServiceChargeCoverageSelected = true;
            input360Property.IsFungusWetRotDryRotAndBacteriaCoverageSelected = true;
            input360Property.IsGlassDisplayOrTrophyCasesCoverageSelected = true;
            input360Property.IsInventoryAndAppraisalCoverageSelected = true;
            input360Property.IsKeyCardCoverageSelected = true;
            input360Property.IsLockReplacementCoverageSelected = true;
            input360Property.IsMoneyAndSecuritiesOnYourPremisesCoverageSelected = true;
            input360Property.IsMoneyAndSecuritiesAwayFromYourPremisesCoverageSelected = true;

            input360Property.IsNewlyAcquiredOrConstructedPropertyBuildingsCoverageSelected = true;
            input360Property.IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageSelected = true;
            input360Property.IsNonOwnedDetachedTrailersCoverageSelected = true;
            input360Property.IsOffPremisesUtilityFailureDamageToCoveredPropertyCoverageSelected = true;
            input360Property.IsOutdoorPropertyCoverageSelected = true;
            input360Property.IsPersonalEffectsAndPropertyOfOthersCoverageSelected = true;
            input360Property.IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageSelected = true;
            input360Property.IsModificationPollutantCleanUpAndRemovalCoverageSelected = true;
            input360Property.IsPropertyInTransitCoverageSelected = true;
            input360Property.IsPropertyOffPremisesCoverageSelected = true;
            input360Property.IsRechargeOfFireProtectionEquipmentCoverageSelected = true;
            input360Property.IsRetainingWallsCoverageSelected = true;
            input360Property.IsRewardPaymentsCoverageSelected = true;
            input360Property.IsSalespersonsSamplesCoverageSelected = true;
            input360Property.IsSCADAUpgradeCoverageSelected = true;
            input360Property.IsSodTreesShrubsAndPlantsAnyOneCoverageSelected = true;
            input360Property.IsSodTreesShrubsAndPlantsOccurrenceCoverageSelected = true;
            input360Property.IsSpoilageCoverageSelected = true;
            input360Property.IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageSelected = true;
            input360Property.IsUndamagedLeaseholdImprovementsCoverageSelected = true;
            input360Property.IsValuablePapersAndRecordsOtherThanElectronicDataCoverageSelected = true;

            input360Property.OrdinanceOrLawCoverageBRevisedLimit = 1250000;
            input360Property.OrdinanceOrLawCoverageCRevisedLimit = 1100000;
            input360Property.AccountsReceivableRecordsRevisedLimit = 120000;
            input360Property.AccountsReceivableRecords360Deductible = 2500;
            input360Property.AppurtenantStructuresRevisedLimit = 200000;
            input360Property.AppurtenantStructures360Deductible = 1000;
            input360Property.AudioVisualAndCommunicationEquipmentRevisedLimit = 130000;
            input360Property.ChangesInTemperatureOrHumidityRevisedLimit = 52000;
            input360Property.ChangesInTemperatureOrHumidity360Deductible = 1000;
            input360Property.CommandeeredPropertyRevisedLimit = 252000;
            input360Property.ComputerEquipmentRevisedLimit = 275000;
            input360Property.ComputerEquipment360Deductible = 500;
            input360Property.DebrisRemovalYourPremisesRevisedLimit = 275000;
            input360Property.DebrisRemovalWindBlownDebrisRevisedLimit = 13000;
            input360Property.ElectronicDataRevisedLimit = 125000;
            input360Property.ElectronicData360Deductible = 2500;
            input360Property.FineArtsRevisedLimit = 120000M;
            input360Property.FineArts360Deductible = 5000;
            input360Property.FireDepartmentServiceChargeRevisedLimit = 40000;
            input360Property.FungusWetRotDryRotAndBacteriaRevisedLimit = 16500;
            input360Property.GlassDisplayOrTrophyCasesRevisedLimit = 6000;
            input360Property.InventoryAndAppraisalRevisedLimit = 23000;
            input360Property.InventoryAndAppraisal360Deductible = 1000;
            input360Property.KeyCardRevisedLimit = 27000;
            input360Property.KeyCard360Deductible = 500;
            input360Property.LockReplacementRevisedLimit = 12000;
            input360Property.MoneyAndSecuritiesOnYourPremisesRevisedLimit = 25000;
            input360Property.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit = 15000;
            input360Property.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit = 1100000;
            input360Property.NewlyAcquiredOrConstructedPropertyBuildings360Deductible = 7500;
            input360Property.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit = 1300000;
            input360Property.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalProperty360Deductible = 15000;
            input360Property.NonOwnedDetachedTrailersRevisedLimit = 21000;
            input360Property.NonOwnedDetachedTrailers360Deductible = 1000;
            input360Property.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit = 150000;
            input360Property.OffPremisesUtilityFailureDamageToCoveredProperty360Deductible = 5000;
            input360Property.OutdoorPropertyRevisedLimit = 110000;
            input360Property.OutdoorProperty360Deductible = 500;
            input360Property.PersonalEffectsAndPropertyOfOthersRevisedLimit = 60000;
            input360Property.PersonalEffectsAndPropertyOfOthers360Deductible = 500;
            input360Property.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit = 2500;
            input360Property.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteer360Deductible = 500;
            input360Property.ModificationPollutantCleanUpAndRemovalRevisedLimit = 550000;
            input360Property.ModificationPollutantCleanUpAndRemoval360Deductible = 2500;
            input360Property.PropertyInTransitRevisedLimit = 75000;
            input360Property.PropertyOffPremisesRevisedLimit = 60000;
            input360Property.PropertyOffPremises360Deductible = 7500;
            input360Property.RechargeOfFireProtectionEquipmentRevisedLimit = 14000;
            input360Property.RetainingWallsRevisedLimit = 11000;
            input360Property.RetainingWalls360Deductible = 500;
            input360Property.RewardPaymentsRevisedLimit = 17000;
            input360Property.SalespersonsSamplesRevisedLimit = 14000;
            input360Property.SalespersonsSamples360Deductible = 500;
            input360Property.SCADAUpgradeRevisedLimit = 110000;
            input360Property.SCADAUpgrade360Deductible = 1000;
            input360Property.SodTreesShrubsAndPlantsAnyOneRevisedLimit = 1500;
            input360Property.SodTreesShrubsAndPlantsOccurrenceRevisedLimit = 15000;
            input360Property.SodTreesShrubsAndPlantsOccurrence360Deductible = 1000;
            input360Property.SpoilageRevisedLimit = 30000;
            input360Property.SpoilageDeductible = 7500;
            input360Property.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit = 15000;

            input360Property.UndamagedLeaseholdImprovementsRevisedLimit = 55000;
            input360Property.UndamagedLeaseholdImprovements360Deductible = 1000;
            input360Property.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit = 110000;
            input360Property.ValuablePapersAndRecordsOtherThanElectronicData360Deductible = 1000;
            #endregion

            #region Property 360 Golf Courses Initialization

            input360Property.IsGolfCoursesTeeToGreenCoverageSelected = true;
            input360Property.IsGolfCoursesSprinklerAndUndergroundWiringCoverageSelected = true;
            input360Property.IsGolfCoursesAdditionalGolfCoursePropertyCoverageSelected = true;

            input360Property.GolfCoursesTeeToGreen360Deductible = 10000;
            input360Property.GolfCoursesTeeToGreenRevisedLimit = 120000;

            input360Property.GolfCoursesSprinklerAndUndergroundWiring360Deductible = 2500;
            input360Property.GolfCoursesSprinklerAndUndergroundWiringRevisedLimit = 100000;

            input360Property.GolfCoursesAdditionalGolfCourseProperty360Deductible = 7500;
            input360Property.GolfCoursesAdditionalGolfCoursePropertyRevisedLimit = 150000;

            #endregion

            #region Property 360 OptionalCoverage Initialization
            input360Property.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel = new List<Property360OptionalLossOfMunicipalTaxRevenueInputModel>();
            input360Property.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel.Add(new Property360OptionalLossOfMunicipalTaxRevenueInputModel
            {
                Id = 1,
                IsLossOfMunicipalTaxRevenueCoverageSelected = true,
                LossOfMunicipalTaxRevenue360Deductible = 1000,
                LossOfMunicipalTaxRevenueRevisedLimit = 300000
            });
            #endregion
        }

        public void GetFacadeForCase2(PropertyInputModel propertyInputModel)
        {
            var input360Property = propertyInputModel.Property360InputModel;

            input360Property.IsBusinessIncomeAndExtraExpenseCoverageSelected = true;
            input360Property.IsDependentPropertyCoverageSelected = true;
            input360Property.IsInterruptionOfComputerOperationsCoverageSelected = true;
            input360Property.IsLeaseCancellationMovingExpensesCoverageSelected = true;
            input360Property.IsNewlyAcquiredOrConstructedPropertyCoverageSelected = true;
            input360Property.IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageSelected = true;
            input360Property.IsOrdinanceOrLawCoverageBSelected = true;
            input360Property.IsOrdinanceOrLawCoverageCSelected = true;
            input360Property.IsAccountsReceivableRecordsCoverageSelected = true;
            input360Property.IsAppurtenantStructuresCoverageSelected = true;
            input360Property.IsAudioVisualAndCommunicationEquipmentCoverageSelected = true;
            input360Property.IsChangesInTemperatureOrHumidityCoverageSelected = true;
            input360Property.IsCommandeeredPropertyCoverageSelected = true;
            input360Property.IsComputerEquipmentCoverageSelected = true;
            input360Property.IsDebrisRemovalYourPremisesCoverageSelected = true;
            input360Property.IsDebrisRemovalWindBlownDebrisCoverageSelected = true;
            input360Property.IsElectronicDataCoverageSelected = true;
            input360Property.IsFineArtsCoverageSelected = true;
            input360Property.IsFireDepartmentServiceChargeCoverageSelected = true;
            input360Property.IsFungusWetRotDryRotAndBacteriaCoverageSelected = true;
            input360Property.IsGlassDisplayOrTrophyCasesCoverageSelected = true;
            input360Property.IsInventoryAndAppraisalCoverageSelected = true;
            input360Property.IsKeyCardCoverageSelected = true;
            input360Property.IsLockReplacementCoverageSelected = true;
            input360Property.IsMoneyAndSecuritiesOnYourPremisesCoverageSelected = true;
            input360Property.IsMoneyAndSecuritiesAwayFromYourPremisesCoverageSelected = true;
            input360Property.IsNewlyAcquiredOrConstructedPropertyBuildingsCoverageSelected = true;
            input360Property.IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageSelected = true;
            input360Property.IsNonOwnedDetachedTrailersCoverageSelected = true;
            input360Property.IsOffPremisesUtilityFailureDamageToCoveredPropertyCoverageSelected = true;
            input360Property.IsOutdoorPropertyCoverageSelected = true;
            input360Property.IsPersonalEffectsAndPropertyOfOthersCoverageSelected = true;
            input360Property.IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageSelected = true;
            input360Property.IsModificationPollutantCleanUpAndRemovalCoverageSelected = true;
            input360Property.IsPropertyInTransitCoverageSelected = true;
            input360Property.IsPropertyOffPremisesCoverageSelected = true;
            input360Property.IsRechargeOfFireProtectionEquipmentCoverageSelected = true;
            input360Property.IsRetainingWallsCoverageSelected = true;
            input360Property.IsRewardPaymentsCoverageSelected = true;
            input360Property.IsSalespersonsSamplesCoverageSelected = true;
            input360Property.IsSCADAUpgradeCoverageSelected = true;
            input360Property.IsSodTreesShrubsAndPlantsAnyOneCoverageSelected = true;
            input360Property.IsSodTreesShrubsAndPlantsOccurrenceCoverageSelected = true;
            input360Property.IsSpoilageCoverageSelected = true;
            input360Property.IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageSelected = true;
            input360Property.IsUndamagedLeaseholdImprovementsCoverageSelected = true;
            input360Property.IsValuablePapersAndRecordsOtherThanElectronicDataCoverageSelected = true;
            input360Property.IsGolfCoursesTeeToGreenCoverageSelected = true;
            input360Property.IsGolfCoursesSprinklerAndUndergroundWiringCoverageSelected = true;
            input360Property.IsGolfCoursesAdditionalGolfCoursePropertyCoverageSelected = true;

            #region Property 360 BI EE Initialization

            //input360Property.BusinessIncomeAndExtraExpenseRate = 0.550M;
            input360Property.BusinessIncomeAndExtraExpenseDays = 120;
            input360Property.BusinessIncomeAndExtraExpenseDeductible = 48;
            input360Property.BusinessIncomeAndExtraExpenseRevisedLimit = 600000;
            input360Property.DependentPropertyRevisedLimit = 150000;
            input360Property.InterruptionOfComputerOperationsRevisedLimit = 50000;
            input360Property.LeaseCancellationMovingExpensesRevisedLimit = 10000;
            input360Property.NewlyAcquiredOrConstructedPropertyRevisedLimit = 600000;
            input360Property.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseBIDeductible = 120;
            input360Property.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit = 55000;

            #endregion

            #region Property 360 Coverage Modification Initialization

            input360Property.OrdinanceOrLawCoverageBRevisedLimit = 1250000;
            input360Property.OrdinanceOrLawCoverageCRevisedLimit = 1100000;
            input360Property.AccountsReceivableRecordsRevisedLimit = 120000;
            input360Property.AccountsReceivableRecords360Deductible = 2500;
            input360Property.AppurtenantStructuresRevisedLimit = 200000;
            input360Property.AppurtenantStructures360Deductible = 1000;
            input360Property.AudioVisualAndCommunicationEquipmentRevisedLimit = 130000;
            input360Property.ChangesInTemperatureOrHumidityRevisedLimit = 52000;
            input360Property.ChangesInTemperatureOrHumidity360Deductible = 1000;
            input360Property.CommandeeredPropertyRevisedLimit = 252000;
            input360Property.ComputerEquipmentRevisedLimit = 275000;
            input360Property.ComputerEquipment360Deductible = 500;
            input360Property.DebrisRemovalYourPremisesRevisedLimit = 275000;
            input360Property.DebrisRemovalWindBlownDebrisRevisedLimit = 13000;
            input360Property.ElectronicDataRevisedLimit = 125000;
            input360Property.ElectronicData360Deductible = 2500;
            input360Property.FineArtsRevisedLimit = 120000M;
            input360Property.FineArts360Deductible = 5000;
            input360Property.FireDepartmentServiceChargeRevisedLimit = 40000;
            input360Property.FungusWetRotDryRotAndBacteriaRevisedLimit = 16500;
            input360Property.GlassDisplayOrTrophyCasesRevisedLimit = 6000;
            input360Property.InventoryAndAppraisalRevisedLimit = 23000;
            input360Property.InventoryAndAppraisal360Deductible = 1000;
            input360Property.KeyCardRevisedLimit = 27000;
            input360Property.KeyCard360Deductible = 500;
            input360Property.LockReplacementRevisedLimit = 12000;
            input360Property.MoneyAndSecuritiesOnYourPremisesRevisedLimit = 25000;
            input360Property.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit = 15000;
            input360Property.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit = 1100000;
            input360Property.NewlyAcquiredOrConstructedPropertyBuildings360Deductible = 7500;
            input360Property.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit = 1300000;
            input360Property.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalProperty360Deductible = 15000;
            input360Property.NonOwnedDetachedTrailersRevisedLimit = 21000;
            input360Property.NonOwnedDetachedTrailers360Deductible = 1000;
            input360Property.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit = 150000;
            input360Property.OffPremisesUtilityFailureDamageToCoveredProperty360Deductible = 5000;
            input360Property.OutdoorPropertyRevisedLimit = 110000;
            input360Property.OutdoorProperty360Deductible = 500;
            input360Property.PersonalEffectsAndPropertyOfOthersRevisedLimit = 60000;
            input360Property.PersonalEffectsAndPropertyOfOthers360Deductible = 500;
            input360Property.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit = 2500;
            input360Property.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteer360Deductible = 500;
            input360Property.ModificationPollutantCleanUpAndRemovalRevisedLimit = 550000;
            input360Property.ModificationPollutantCleanUpAndRemoval360Deductible = 2500;
            input360Property.PropertyInTransitRevisedLimit = 75000;
            input360Property.PropertyOffPremisesRevisedLimit = 60000;
            input360Property.PropertyOffPremises360Deductible = 7500;
            input360Property.RechargeOfFireProtectionEquipmentRevisedLimit = 14000;
            input360Property.RetainingWallsRevisedLimit = 11000;
            input360Property.RetainingWalls360Deductible = 500;
            input360Property.RewardPaymentsRevisedLimit = 17000;
            input360Property.SalespersonsSamplesRevisedLimit = 14000;
            input360Property.SalespersonsSamples360Deductible = 500;
            input360Property.SCADAUpgradeRevisedLimit = 110000;
            input360Property.SCADAUpgrade360Deductible = 1000;
            input360Property.SodTreesShrubsAndPlantsAnyOneRevisedLimit = 1500;
            input360Property.SodTreesShrubsAndPlantsOccurrenceRevisedLimit = 15000;
            input360Property.SodTreesShrubsAndPlantsOccurrence360Deductible = 1000;
            input360Property.SpoilageRevisedLimit = 30000;
            input360Property.SpoilageDeductible = 7500;
            input360Property.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit = 15000;

            input360Property.UndamagedLeaseholdImprovementsRevisedLimit = 55000;
            input360Property.UndamagedLeaseholdImprovements360Deductible = 1000;
            input360Property.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit = 110000;
            input360Property.ValuablePapersAndRecordsOtherThanElectronicData360Deductible = 1000;
            #endregion

            #region Property 360 Golf Courses Initialization

            input360Property.GolfCoursesTeeToGreen360Deductible = 10000;
            input360Property.GolfCoursesTeeToGreenRevisedLimit = 120000;

            input360Property.GolfCoursesSprinklerAndUndergroundWiring360Deductible = 2500;
            input360Property.GolfCoursesSprinklerAndUndergroundWiringRevisedLimit = 100000;

            input360Property.GolfCoursesAdditionalGolfCourseProperty360Deductible = 7500;
            input360Property.GolfCoursesAdditionalGolfCoursePropertyRevisedLimit = 150000;

            #endregion

            #region Property 360 OptionalCoverage Initialization

            input360Property.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel = new List<Property360OptionalLossOfMunicipalTaxRevenueInputModel>();
            input360Property.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel.Add(new Property360OptionalLossOfMunicipalTaxRevenueInputModel
            {
                Id = 1,
                IsLossOfMunicipalTaxRevenueCoverageSelected = true,
                LossOfMunicipalTaxRevenue360Deductible = 1000,
                LossOfMunicipalTaxRevenueRevisedLimit = 300000
            });

            #endregion
        }

        public void GetFacadeForCaseTesting(PropertyInputModel propertyInputModel)
        {
            var input360Property = propertyInputModel.Property360InputModel;

            input360Property.IsBusinessIncomeAndExtraExpenseCoverageSelected = true;
            input360Property.IsDependentPropertyCoverageSelected = false;
            input360Property.IsInterruptionOfComputerOperationsCoverageSelected = false;
            input360Property.IsLeaseCancellationMovingExpensesCoverageSelected = false;
            input360Property.IsNewlyAcquiredOrConstructedPropertyCoverageSelected = false;
            input360Property.IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageSelected = false;
            input360Property.IsOrdinanceOrLawCoverageBSelected = false;
            input360Property.IsOrdinanceOrLawCoverageCSelected = false;
            input360Property.IsAccountsReceivableRecordsCoverageSelected = false;
            input360Property.IsAppurtenantStructuresCoverageSelected = false;
            input360Property.IsAudioVisualAndCommunicationEquipmentCoverageSelected = false;
            input360Property.IsChangesInTemperatureOrHumidityCoverageSelected = false;
            input360Property.IsCommandeeredPropertyCoverageSelected = false;
            input360Property.IsComputerEquipmentCoverageSelected = false;
            input360Property.IsDebrisRemovalYourPremisesCoverageSelected = false;
            input360Property.IsDebrisRemovalWindBlownDebrisCoverageSelected = false;
            input360Property.IsElectronicDataCoverageSelected = false;
            input360Property.IsFineArtsCoverageSelected = false;
            input360Property.IsFireDepartmentServiceChargeCoverageSelected = true;
            input360Property.IsFungusWetRotDryRotAndBacteriaCoverageSelected = false;
            input360Property.IsGlassDisplayOrTrophyCasesCoverageSelected = false;
            input360Property.IsInventoryAndAppraisalCoverageSelected = false;
            input360Property.IsKeyCardCoverageSelected = false;
            input360Property.IsLockReplacementCoverageSelected = false;
            input360Property.IsMoneyAndSecuritiesOnYourPremisesCoverageSelected = false;
            input360Property.IsMoneyAndSecuritiesAwayFromYourPremisesCoverageSelected = false;
            input360Property.IsNewlyAcquiredOrConstructedPropertyBuildingsCoverageSelected = false;
            input360Property.IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageSelected = false;
            input360Property.IsNonOwnedDetachedTrailersCoverageSelected = false;
            input360Property.IsOffPremisesUtilityFailureDamageToCoveredPropertyCoverageSelected = false;
            input360Property.IsOutdoorPropertyCoverageSelected = false;
            input360Property.IsPersonalEffectsAndPropertyOfOthersCoverageSelected = false;
            input360Property.IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageSelected = false;
            input360Property.IsModificationPollutantCleanUpAndRemovalCoverageSelected = false;
            input360Property.IsPropertyInTransitCoverageSelected = false;
            input360Property.IsPropertyOffPremisesCoverageSelected = false;
            input360Property.IsRechargeOfFireProtectionEquipmentCoverageSelected = false;
            input360Property.IsRetainingWallsCoverageSelected = false;
            input360Property.IsRewardPaymentsCoverageSelected = false;
            input360Property.IsSalespersonsSamplesCoverageSelected = false;
            input360Property.IsSCADAUpgradeCoverageSelected = false;
            input360Property.IsSodTreesShrubsAndPlantsAnyOneCoverageSelected = false;
            input360Property.IsSodTreesShrubsAndPlantsOccurrenceCoverageSelected = false;
            input360Property.IsSpoilageCoverageSelected = false;
            input360Property.IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageSelected = false;
            input360Property.IsUndamagedLeaseholdImprovementsCoverageSelected = false;
            input360Property.IsValuablePapersAndRecordsOtherThanElectronicDataCoverageSelected = false;
            input360Property.IsGolfCoursesTeeToGreenCoverageSelected = true;
            input360Property.IsGolfCoursesSprinklerAndUndergroundWiringCoverageSelected = false;
            input360Property.IsGolfCoursesAdditionalGolfCoursePropertyCoverageSelected = false;

            #region Property 360 BI EE Initialization

            //input360Property.BusinessIncomeAndExtraExpenseRate = 0.550M;
            input360Property.BusinessIncomeAndExtraExpenseDays = 120;
            input360Property.BusinessIncomeAndExtraExpenseDeductible = 48;
            input360Property.BusinessIncomeAndExtraExpenseRevisedLimit = 600000;
            input360Property.DependentPropertyRevisedLimit = 0;
            input360Property.InterruptionOfComputerOperationsRevisedLimit = 0;
            input360Property.LeaseCancellationMovingExpensesRevisedLimit = 0;
            input360Property.NewlyAcquiredOrConstructedPropertyRevisedLimit = 0;
            input360Property.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseBIDeductible = 120;
            input360Property.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit = 0;

            #endregion

            #region Property 360 Coverage Modification Initialization

            input360Property.OrdinanceOrLawCoverageBRevisedLimit = 0;
            input360Property.OrdinanceOrLawCoverageCRevisedLimit = 0;
            input360Property.AccountsReceivableRecordsRevisedLimit = 0;
            input360Property.AccountsReceivableRecords360Deductible = 2500;
            input360Property.AppurtenantStructuresRevisedLimit = 0;
            input360Property.AppurtenantStructures360Deductible = 1000;
            input360Property.AudioVisualAndCommunicationEquipmentRevisedLimit = 0;
            input360Property.ChangesInTemperatureOrHumidityRevisedLimit = 0;
            input360Property.ChangesInTemperatureOrHumidity360Deductible = 1000;
            input360Property.CommandeeredPropertyRevisedLimit = 252000;
            input360Property.ComputerEquipmentRevisedLimit = 275000;
            input360Property.ComputerEquipment360Deductible = 500;
            input360Property.DebrisRemovalYourPremisesRevisedLimit = 275000;
            input360Property.DebrisRemovalWindBlownDebrisRevisedLimit = 13000;
            input360Property.ElectronicDataRevisedLimit = 125000;
            input360Property.ElectronicData360Deductible = 2500;
            input360Property.FineArtsRevisedLimit = 120000M;
            input360Property.FineArts360Deductible = 5000;
            input360Property.FireDepartmentServiceChargeRevisedLimit = 50000;
            input360Property.FungusWetRotDryRotAndBacteriaRevisedLimit = 16500;
            input360Property.GlassDisplayOrTrophyCasesRevisedLimit = 6000;
            input360Property.InventoryAndAppraisalRevisedLimit = 23000;
            input360Property.InventoryAndAppraisal360Deductible = 1000;
            input360Property.KeyCardRevisedLimit = 27000;
            input360Property.KeyCard360Deductible = 500;
            input360Property.LockReplacementRevisedLimit = 12000;
            input360Property.MoneyAndSecuritiesOnYourPremisesRevisedLimit = 25000;
            input360Property.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit = 15000;
            input360Property.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit = 1100000;
            input360Property.NewlyAcquiredOrConstructedPropertyBuildings360Deductible = 7500;
            input360Property.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit = 1300000;
            input360Property.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalProperty360Deductible = 15000;
            input360Property.NonOwnedDetachedTrailersRevisedLimit = 21000;
            input360Property.NonOwnedDetachedTrailers360Deductible = 1000;
            input360Property.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit = 150000;
            input360Property.OffPremisesUtilityFailureDamageToCoveredProperty360Deductible = 5000;
            input360Property.OutdoorPropertyRevisedLimit = 110000;
            input360Property.OutdoorProperty360Deductible = 500;
            input360Property.PersonalEffectsAndPropertyOfOthersRevisedLimit = 60000;
            input360Property.PersonalEffectsAndPropertyOfOthers360Deductible = 500;
            input360Property.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit = 2500;
            input360Property.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteer360Deductible = 500;
            input360Property.ModificationPollutantCleanUpAndRemovalRevisedLimit = 550000;
            input360Property.ModificationPollutantCleanUpAndRemoval360Deductible = 2500;
            input360Property.PropertyInTransitRevisedLimit = 75000;
            input360Property.PropertyOffPremisesRevisedLimit = 60000;
            input360Property.PropertyOffPremises360Deductible = 7500;
            input360Property.RechargeOfFireProtectionEquipmentRevisedLimit = 14000;
            input360Property.RetainingWallsRevisedLimit = 11000;
            input360Property.RetainingWalls360Deductible = 500;
            input360Property.RewardPaymentsRevisedLimit = 17000;
            input360Property.SalespersonsSamplesRevisedLimit = 14000;
            input360Property.SalespersonsSamples360Deductible = 500;
            input360Property.SCADAUpgradeRevisedLimit = 110000;
            input360Property.SCADAUpgrade360Deductible = 1000;
            input360Property.SodTreesShrubsAndPlantsAnyOneRevisedLimit = 1500;
            input360Property.SodTreesShrubsAndPlantsOccurrenceRevisedLimit = 15000;
            input360Property.SodTreesShrubsAndPlantsOccurrence360Deductible = 1000;
            input360Property.SpoilageRevisedLimit = 30000;
            input360Property.SpoilageDeductible = 7500;
            input360Property.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit = 15000;

            input360Property.UndamagedLeaseholdImprovementsRevisedLimit = 55000;
            input360Property.UndamagedLeaseholdImprovements360Deductible = 1000;
            input360Property.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit = 110000;
            input360Property.ValuablePapersAndRecordsOtherThanElectronicData360Deductible = 1000;
            #endregion

            #region Property 360 Golf Courses Initialization

            input360Property.GolfCoursesTeeToGreen360Deductible = 1000;
            input360Property.GolfCoursesTeeToGreenRevisedLimit = 100000;

            input360Property.GolfCoursesSprinklerAndUndergroundWiring360Deductible = 2500;
            input360Property.GolfCoursesSprinklerAndUndergroundWiringRevisedLimit = 100000;

            input360Property.GolfCoursesAdditionalGolfCourseProperty360Deductible = 7500;
            input360Property.GolfCoursesAdditionalGolfCoursePropertyRevisedLimit = 150000;

            #endregion

            #region Property 360 OptionalCoverage Initialization

            input360Property.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel = new List<Property360OptionalLossOfMunicipalTaxRevenueInputModel>();
            input360Property.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel.Add(new Property360OptionalLossOfMunicipalTaxRevenueInputModel
            {
                Id = 1,
                IsLossOfMunicipalTaxRevenueCoverageSelected = true,
                LossOfMunicipalTaxRevenue360Deductible = 1000,
                LossOfMunicipalTaxRevenueRevisedLimit = 200000
            });

            #endregion
        }
    }
}
