﻿using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Property.Input;
using Models.ApiModels.LineOfBusiness.Property.Output;
using Models.ApiModels.Policy;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class PropertyCWInitialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel.RaterInputFacadeModel == null)
            {
                raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel();
            }
            if (raterFacadeModel.RaterOutputFacadeModel == null)
            {
                raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            }

            var raterInputFacade = raterFacadeModel.RaterInputFacadeModel;
            var raterOutputFacade = raterFacadeModel.RaterOutputFacadeModel;

            raterInputFacade.LineOfBusiness.Property = true;
            raterInputFacade.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterInputFacade.LineOfBusinessInputModel.Property = new PropertyInputModel();
            raterInputFacade.LineOfBusinessInputModel.Property.Property360InputModel = new Property360InputModel();
            raterInputFacade.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();
            raterInputFacade.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();
            raterInputFacade.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel = new Property360OptionalCoverageInputModel();
            raterInputFacade.PolicyHeaderModel = new PolicyHeaderModel();

            raterOutputFacade.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterOutputFacade.PremiumSummaryModel = new PremiumSummaryModel();
            raterOutputFacade.ResponseModel = new ResponseInfoModel();
            raterOutputFacade.LineOfBusinessOutputModel.Property = new PropertyOutputModel();
            raterOutputFacade.LineOfBusinessOutputModel.Property.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageOutputModel();
            raterOutputFacade.LineOfBusinessOutputModel.Property.Property360OutputModel = new Property360OutputModel();
            raterOutputFacade.LineOfBusinessOutputModel.Property.Property360OutputModel.property360OptionalCoverageOutputModel = new Property360OptionalCoverageOutputModel();
            raterInputFacade.LineOfBusinessInputModel.Property.ScheduleRatingInputModels = new PropertyScheduleRatingInputModel();
        }

        public void InitializeTestCase1(RaterFacadeModel raterFacadeModel)
        {
            var inputProperty = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var inputPolicyHeader = raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel;
            var input360InputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel;
            #region PolicyHeader

            inputPolicyHeader.Id = 1;
            inputPolicyHeader.ClientId = "Paragon";
            inputPolicyHeader.QuoteId = 3;
            inputPolicyHeader.State = StateCodeConstant.AL;
            inputPolicyHeader.PrimaryClass = "MU";
            inputPolicyHeader.SecondaryClass = "1";
            inputPolicyHeader.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            inputPolicyHeader.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            inputPolicyHeader.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy   
            inputPolicyHeader.TransactionType = "NEWBUSINESS";
            inputPolicyHeader.TerrorismCoverage = true;
            #endregion

            #region BuildingBPP Initialization

            inputProperty.BuildingTIV = 1000000;
            inputProperty.ContentTIV = 500000;
            inputProperty.AOPDeductible = 5000;
            inputProperty.SumNetNormalLossClaims = 20000;

            inputProperty.Coinsurance = "1.00";
            inputProperty.MarginClause = "1.20";
            inputProperty.Valuation = "RC";
            inputProperty.Blanket = "Test";

            inputProperty.TIVExpPeriod1stYear = 2500000;
            inputProperty.TIVExpPeriod2ndYear = 1500000;
            inputProperty.TIVExpPeriod3rdYear = 1000000;

            #endregion

            #region EquipmentBreakdown Initialization

            inputProperty.BusinessIncomeAndExtraExpenseLimit = 50000;
            inputProperty.IRPM = 100;
            inputProperty.EquipmentBreakdownDeductible = 5000;
            inputProperty.BusinessIncomeAndExtraExpenseDeductible = 240;
            inputProperty.PollutantCleanUpLimit = 250000;
            inputProperty.RefrigerantContaminationLimit = 250000;
            inputProperty.SelectedSpoilageType = "Type1";
            inputProperty.EBSpoilageLimit = 1000000;
            inputProperty.SpoilageDeductible = 0.1M; // "10%";
            inputProperty.SpoilageMinimumDeductible = 1000;
            inputProperty.EquipmentBreakdownCoverage = true;
            inputProperty.ReferredEquipmentBreakdownCoverage = false;

            if (inputProperty.ReferredEquipmentBreakdownCoverage == true)
            {
                inputProperty.EquipmentBreakdownRate = 0;
                inputProperty.InputEquipmentBreakdownTotalPremium = 98;
            }

            #endregion

            #region WindFloodEarthquake Initialization
            inputProperty.WindstormAndHailCoverage = true;
            inputProperty.FloodCoverage = true;
            inputProperty.EarthquakeCoverage = true;
            inputProperty.WindstormAndHailSubjectToMinimumDeductible = "";

            #endregion

            #region OptionalCoverage Initialization

            inputProperty.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = false;

            inputOptionalCoverage.IsAlabamaWindAndHailCertificateCreditCoverageSelected = true;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditDescription = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditLimit = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditDeductible = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditRatingBasis = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditRate = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditReturnMethod = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditPremium = -100000;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 1,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 500000,
                Deductible = 0,
                RatingBasis = "PER 1000 OF LIMIT",
                Rate = 0.25M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            }); ;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 2,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 500000,
                Deductible = 0,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.2M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 3,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 200000,
                Deductible = 500,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.089M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region FinalPremium Initialization

            inputProperty.LargeRiskFactor = 0.05M;

            #endregion

            #region Hazard (Property- fill-in Deficiency)

            // Building
            inputProperty.DisasterExposureBuildingPoints = 1000;
            inputProperty.ClimaticalHazardsHurricaneBuildingPoints = 1000;
            inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints = 1000;
            inputProperty.ClimaticalHazardsWinterStormBuildingPoints = 1000;
            inputProperty.ClimaticalHazardsAllOtherBuildingPoints = 1000;
            inputProperty.OccupancyHazardsBuildingPoints = 1000;
            inputProperty.LackofPrivateProtectionBuildingPoints = 1000;
            inputProperty.AmendedLimitorAddCoverageBuildingPoints = 1000;
            inputProperty.InadequatePublicProtectionBuildingPoints = 1000;
            inputProperty.ExtraExternalExposureBuildingPoints = 1000;
            inputProperty.DeficiencyConstructionBuildingPoints = 1000;
            inputProperty.UnusualCombustionBuildingPoints = 1000;
            inputProperty.FloodExposureBuildingPoints = 1000;
            inputProperty.EarthquakeExposureBuildingPoints = 1000;
            inputProperty.ExcludedorReducedCoverageBuildingPoints = 100;
            inputProperty.FloodDeductible = 100;
            inputProperty.EarthquakeDeductible = 100;
            inputProperty.WindstormAndHailDeductible = 10;


            //Content
            inputProperty.DisasterExposureContentPoints = 1000;
            inputProperty.ClimaticalHazardsHurricaneContentPoints = 1000;
            inputProperty.ClimaticalHazardsSevereConvectiveContentPoints = 1000;
            inputProperty.ClimaticalHazardsWinterStormContentPoints = 1000;
            inputProperty.ClimaticalHazardsAllOtherContentPoints = 1000;
            inputProperty.OccupancyHazardsContentPoints = 1000;
            inputProperty.LackofPrivateProtectionContentPoints = 1000;
            inputProperty.AmendedLimitorAddCoverageContentPoints = 1000;
            inputProperty.InadequatePublicProtectionContentPoints = 1000;
            inputProperty.ExtraExternalExposureContentPoints = 1000;
            inputProperty.DeficiencyConstructionContentPoints = 1000;
            inputProperty.UnusualCombustionContentPoints = 1000;
            inputProperty.FloodExposureContentPoints = 1000;
            inputProperty.EarthquakeExposureContentPoints = 1000;
            inputProperty.ExcludedorReducedCoverageContentPoints = 100;
            inputProperty.ExclusionorReductionofCoverageBuildingPoints = -100;
            inputProperty.ExclusionorReductionofCoverageContentPoints = -100;
            #endregion

            //inputProperty.ExcludedorReducedCoverageJustification = "Moderate Restrictions or Coverage Exclusions";
            inputProperty.EarthquakeExposureJustification = " ";
            inputProperty.DisasterExposureJustification = "Highly Concentrated Values";
            inputProperty.ClimaticalHazardsHurricaneJustification = "10";
            inputProperty.ClimaticalHazardsSevereConvectiveJustification = "High Potential for Damage";
            inputProperty.ClimaticalHazardsWinterStormJustification = "High Potential for Damage";
            inputProperty.ClimaticalHazardsAllOtherJustification = "High Potential for Damage";
            inputProperty.OccupancyHazardsJustification = "Above Average Central Station Alarm Monitoring or Low Attraction Value";
            inputProperty.AmendedLimitorAddCoverageJustification = " ";
            inputProperty.FloodExposureJustification = " ";
            inputProperty.LackofPrivateProtectionJustification = " ";
            inputProperty.InadequatePublicProtectionJustification = " ";
            inputProperty.ExcludedorReducedCoverageJustification = " ";
            inputProperty.DeficiencyConstructionJustification = " ";
            inputProperty.UnusualCombustionJustification = " ";
            inputProperty.EarthquakeExposureJustification = " ";
            inputProperty.ExtraExternalExposureJustification = " ";

            #region Hazard (Property- dropdown Deficiency)

            // Building
            inputProperty.DisasterExposureDispersionBuildingPoints = 100;
            inputProperty.DisasterExposurePMLBuildingPoints = 100;
            inputProperty.ClimaticalHazardsHurricaneBuildingPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints = 100;
            inputProperty.ClimaticalHazardsWinterStormBuildingPoints = 100;
            inputProperty.ClimaticalHazardsAllOtherBuildingPoints = 100;
            inputProperty.SpecialOccupancyHazardsBuildingPoints = 100;
            inputProperty.SpecialOccupancyProcessingBuildingPoints = 100;
            inputProperty.SpecialOccupancyBusinessIncomePMLBuildingPoints = 100;
            inputProperty.SpecialOccupancyNumberofOccupantsBuildingPoints = 100;
            inputProperty.PrivateProtectionFireSuppressionBuildingPoints = 100;
            inputProperty.PrivateProtectionFireProtectionBuildingPoints = 100;
            inputProperty.PrivateProtectionCentralMonitoringBuildingPoints = 100;
            inputProperty.SpecificInsuranceBuildingPoints = 100;
            inputProperty.PublicProtectionLowHazardBuildingPoints = 100;
            inputProperty.PublicProtectionMediumHazardBuildingPoints = 100;
            inputProperty.PublicProtectionHighHazardBuildingPoints = 100;
            inputProperty.ExternalExposureBuildingPoints = 100;
            inputProperty.ExternalExposureSeparationBuildingPoints = 100;
            inputProperty.ConstructionBuildingPoints = 100;
            inputProperty.ConstructionEngineeringBuildingPoints = 100;
            inputProperty.ConstructionAttractionValueBuildingPoints = 100;
            inputProperty.CommoditiesBuildingPoints = 100;
            inputProperty.FloodCoveredZoneBuildingPoints1 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints2 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints3 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints4 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints5 = 100;
            inputProperty.EarthMovementTerritoryBuildingPoints1 = 100;
            inputProperty.EarthMovementTerritoryBuildingPoints2 = 100;
            inputProperty.EarthMovementLimitBuildingPoints = 100;
            inputProperty.ExcludedorReducedCoverageBuildingPoints = 0;

            //Content
            inputProperty.DisasterExposureDispersionContentPoints = 100;
            inputProperty.DisasterExposurePMLContentPoints = 100;
            inputProperty.ClimaticalHazardsHurricaneContentPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveContentPoints = 100;
            inputProperty.ClimaticalHazardsWinterStormContentPoints = 100;
            inputProperty.ClimaticalHazardsAllOtherContentPoints = 100;
            inputProperty.SpecialOccupancyHazardsContentPoints = 100;
            inputProperty.SpecialOccupancyProcessingContentPoints = 100;
            inputProperty.SpecialOccupancyBusinessIncomePMLContentPoints = 100;
            inputProperty.SpecialOccupancyNumberofOccupantsContentPoints = 100;
            inputProperty.PrivateProtectionFireSuppressionContentPoints = 100;
            inputProperty.PrivateProtectionFireProtectionContentPoints = 100;
            inputProperty.PrivateProtectionCentralMonitoringContentPoints = 100;
            inputProperty.SpecificInsuranceContentPoints = 100;
            inputProperty.PublicProtectionLowHazardContentPoints = 100;
            inputProperty.PublicProtectionMediumHazardContentPoints = 100;
            inputProperty.PublicProtectionHighHazardContentPoints = 100;
            inputProperty.ExternalExposureContentPoints = 100;
            inputProperty.ExternalExposureSeparationContentPoints = 100;
            inputProperty.ConstructionContentPoints = 100;
            inputProperty.ConstructionEngineeringContentPoints = 100;
            inputProperty.ConstructionAttractionValueContentPoints = 100;
            inputProperty.CommoditiesContentPoints = 100;
            inputProperty.FloodCoveredZoneContentPoints1 = 100;
            inputProperty.FloodCoveredZoneContentPoints2 = 100;
            inputProperty.FloodCoveredZoneContentPoints3 = 100;
            inputProperty.FloodCoveredZoneContentPoints4 = 100;
            inputProperty.FloodCoveredZoneContentPoints5 = 100;
            inputProperty.EarthMovementTerritoryContentPoints1 = 100;
            inputProperty.EarthMovementTerritoryContentPoints2 = 100;
            inputProperty.EarthMovementLimitContentPoints = 100;
            inputProperty.ExcludedorReducedCoverageContentPoints = 0;
            inputProperty.EarthquakeLimit = 100;
            inputProperty.FloodLimit = 100;
            #endregion

            #region Schedule Rating
            inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels = new List<BuildingScheduleInputModel>()
            {
                new BuildingScheduleInputModel{
                BuildingLimit=500000, ContentsLimit=100000, Construction="Frame", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=200000, ContentsLimit=150000, Construction="Frame", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=150000, ContentsLimit=100000, Construction="Joisted Masonry", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=150000, ContentsLimit=150000, Construction="Frame", HazardGroup=2, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=50000, ContentsLimit=10000, Construction="Joisted Masonry", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=120000, ContentsLimit=130000, Construction="Frame", HazardGroup=2, ProtectionClass=1,SquareFootage=1
                }
            };
            #endregion

        }
        public void InitializeTestCase2(RaterFacadeModel raterFacadeModel)
        {

            var inputProperty = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var inputPolicyHeader = raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel;
            var inputProperty360OptionalCoverage = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel;

            #region PolicyHeader

            inputPolicyHeader.Id = 1;
            inputPolicyHeader.ClientId = "Paragon";
            inputPolicyHeader.QuoteId = 3;
            inputPolicyHeader.State = StateCodeConstant.AL;
            inputPolicyHeader.PrimaryClass = "MU";
            inputPolicyHeader.SecondaryClass = "1";
            inputPolicyHeader.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            inputPolicyHeader.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            inputPolicyHeader.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy   
            inputPolicyHeader.TransactionType = "NEWBUSINESS";
            inputPolicyHeader.TerrorismCoverage = true;
            #endregion

            #region BuildingBPP Initialization

            inputProperty.BuildingTIV = 1000000;
            inputProperty.ContentTIV = 500000;
            inputProperty.AOPDeductible = 5000;
            inputProperty.SumNetNormalLossClaims = 20000;

            inputProperty.Coinsurance = "1.00";
            inputProperty.MarginClause = "1.20";
            inputProperty.Valuation = "RC";
            inputProperty.Blanket = "Test";

            inputProperty.TIVExpPeriod1stYear = 2500000;
            inputProperty.TIVExpPeriod2ndYear = 1500000;
            inputProperty.TIVExpPeriod3rdYear = 1000000;

            #endregion

            #region EquipmentBreakdown Initialization

            inputProperty.BusinessIncomeAndExtraExpenseLimit = 50000;
            inputProperty.IRPM = 100;
            inputProperty.EquipmentBreakdownDeductible = 5000;
            inputProperty.BusinessIncomeAndExtraExpenseDeductible = 240;
            inputProperty.PollutantCleanUpLimit = 250000;
            inputProperty.RefrigerantContaminationLimit = 250000;
            inputProperty.SelectedSpoilageType = "Type1";
            inputProperty.EBSpoilageLimit = 1000000;
            inputProperty.SpoilageDeductible = 0.1M; // "10%";
            inputProperty.SpoilageMinimumDeductible = 1000;
            inputProperty.EquipmentBreakdownCoverage = true;
            inputProperty.ReferredEquipmentBreakdownCoverage = false;

            if (inputProperty.ReferredEquipmentBreakdownCoverage == true)
            {
                inputProperty.EquipmentBreakdownRate = 0;
                inputProperty.InputEquipmentBreakdownTotalPremium = 98;
            }

            #endregion

            #region WindFloodEarthquake Initialization
            inputProperty.WindstormAndHailCoverage = true;
            inputProperty.FloodCoverage = true;
            inputProperty.EarthquakeCoverage = true;


            #endregion

            #region OptionalCoverage Initialization

            inputProperty.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = false;

            inputOptionalCoverage.IsAlabamaWindAndHailCertificateCreditCoverageSelected = true;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditDescription = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditLimit = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditDeductible = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditRatingBasis = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditRate = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditReturnMethod = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditPremium = -100000;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 1,
                IsOptionalCoverageSelected = true,
                Description = "test",
                Limit = 500000,
                Deductible = 0,
                RatingBasis = "test",
                Rate = 0.25M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });
            inputProperty360OptionalCoverage.VacancyPermitsInputModel = new List<Property360OptionalVacancyPermitInputModel>();


            inputProperty360OptionalCoverage.VacancyPermitsInputModel.Add(new Property360OptionalVacancyPermitInputModel
            { 
                IsVacancyPermitCoverageSelected=true,
                VacancyPermitLocation = 0,
                VacancyPermitBuilding=0,
                VacancyPermitLocationDescription="",
                VacancyPermitLimit = 0,
                VacancyPermitDeductible=0,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 3,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 200000,
                Deductible = 500,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.089M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region FinalPremium Initialization

            inputProperty.LargeRiskFactor = 0.05M;

            #endregion

            #region Hazard (Property- fill-in Deficiency)

            // Building
            inputProperty.DisasterExposureBuildingPoints = 1000;
            inputProperty.ClimaticalHazardsHurricaneBuildingPoints = 1000;
            inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints = 1000;
            inputProperty.ClimaticalHazardsWinterStormBuildingPoints = 1000;
            inputProperty.ClimaticalHazardsAllOtherBuildingPoints = 1000;
            inputProperty.OccupancyHazardsBuildingPoints = 1000;
            inputProperty.LackofPrivateProtectionBuildingPoints = 1000;
            inputProperty.AmendedLimitorAddCoverageBuildingPoints = 1000;
            inputProperty.InadequatePublicProtectionBuildingPoints = 1000;
            inputProperty.ExtraExternalExposureBuildingPoints = 1000;
            inputProperty.DeficiencyConstructionBuildingPoints = 1000;
            inputProperty.UnusualCombustionBuildingPoints = 1000;
            inputProperty.FloodExposureBuildingPoints = 1000;
            inputProperty.EarthquakeExposureBuildingPoints = 1000;
            inputProperty.ExcludedorReducedCoverageBuildingPoints = 100;//1000;
            inputProperty.FloodDeductible = 100;
            inputProperty.EarthquakeDeductible = 100;
            inputProperty.WindstormAndHailDeductible = 100;


            //Content
            inputProperty.DisasterExposureContentPoints = 1000;
            inputProperty.ClimaticalHazardsHurricaneContentPoints = 1000;
            inputProperty.ClimaticalHazardsSevereConvectiveContentPoints = 1000;
            inputProperty.ClimaticalHazardsWinterStormContentPoints = 1000;
            inputProperty.ClimaticalHazardsAllOtherContentPoints = 1000;
            inputProperty.OccupancyHazardsContentPoints = 1000;
            inputProperty.LackofPrivateProtectionContentPoints = 1000;
            inputProperty.AmendedLimitorAddCoverageContentPoints = 1000;
            inputProperty.InadequatePublicProtectionContentPoints = 1000;
            inputProperty.ExtraExternalExposureContentPoints = 1000;
            inputProperty.DeficiencyConstructionContentPoints = 1000;
            inputProperty.UnusualCombustionContentPoints = 1000;
            inputProperty.FloodExposureContentPoints = 1000;
            inputProperty.EarthquakeExposureContentPoints = 1000;
            inputProperty.ExcludedorReducedCoverageContentPoints = 0;//1000;

            #endregion

            #region Hazard (Property- dropdown Deficiency)

            // Building
            inputProperty.DisasterExposureDispersionBuildingPoints = 100;
            inputProperty.DisasterExposurePMLBuildingPoints = 100;
            inputProperty.ClimaticalHazardsHurricaneBuildingPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints = 100;
            inputProperty.ClimaticalHazardsWinterStormBuildingPoints = 100;
            inputProperty.ClimaticalHazardsAllOtherBuildingPoints = 100;
            inputProperty.SpecialOccupancyHazardsBuildingPoints = 100;
            inputProperty.SpecialOccupancyProcessingBuildingPoints = 100;
            inputProperty.SpecialOccupancyBusinessIncomePMLBuildingPoints = 100;
            inputProperty.SpecialOccupancyNumberofOccupantsBuildingPoints = 100;
            inputProperty.PrivateProtectionFireSuppressionBuildingPoints = 100;
            inputProperty.PrivateProtectionFireProtectionBuildingPoints = 100;
            inputProperty.PrivateProtectionCentralMonitoringBuildingPoints = 100;
            inputProperty.SpecificInsuranceBuildingPoints = 100;
            inputProperty.PublicProtectionLowHazardBuildingPoints = 100;
            inputProperty.PublicProtectionMediumHazardBuildingPoints = 100;
            inputProperty.PublicProtectionHighHazardBuildingPoints = 100;
            inputProperty.ExternalExposureBuildingPoints = 100;
            inputProperty.ExternalExposureSeparationBuildingPoints = 100;
            inputProperty.ConstructionBuildingPoints = 100;
            inputProperty.ConstructionEngineeringBuildingPoints = 100;
            inputProperty.ConstructionAttractionValueBuildingPoints = 100;
            inputProperty.CommoditiesBuildingPoints = 100;
            inputProperty.FloodCoveredZoneBuildingPoints1 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints2 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints3 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints4 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints5 = 100;
            inputProperty.EarthMovementTerritoryBuildingPoints1 = 100;
            inputProperty.EarthMovementTerritoryBuildingPoints2 = 100;
            inputProperty.EarthMovementLimitBuildingPoints = 100;
            inputProperty.ExcludedorReducedCoverageBuildingPoints = 0;

            //Content
            inputProperty.DisasterExposureDispersionContentPoints = 100;
            inputProperty.DisasterExposurePMLContentPoints = 100;
            inputProperty.ClimaticalHazardsHurricaneContentPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveContentPoints = 100;
            inputProperty.ClimaticalHazardsWinterStormContentPoints = 100;
            inputProperty.ClimaticalHazardsAllOtherContentPoints = 100;
            inputProperty.SpecialOccupancyHazardsContentPoints = 100;
            inputProperty.SpecialOccupancyProcessingContentPoints = 100;
            inputProperty.SpecialOccupancyBusinessIncomePMLContentPoints = 100;
            inputProperty.SpecialOccupancyNumberofOccupantsContentPoints = 100;
            inputProperty.PrivateProtectionFireSuppressionContentPoints = 100;
            inputProperty.PrivateProtectionFireProtectionContentPoints = 100;
            inputProperty.PrivateProtectionCentralMonitoringContentPoints = 100;
            inputProperty.SpecificInsuranceContentPoints = 100;
            inputProperty.PublicProtectionLowHazardContentPoints = 100;
            inputProperty.PublicProtectionMediumHazardContentPoints = 100;
            inputProperty.PublicProtectionHighHazardContentPoints = 100;
            inputProperty.ExternalExposureContentPoints = 100;
            inputProperty.ExternalExposureSeparationContentPoints = 100;
            inputProperty.ConstructionContentPoints = 100;
            inputProperty.ConstructionEngineeringContentPoints = 100;
            inputProperty.ConstructionAttractionValueContentPoints = 100;
            inputProperty.CommoditiesContentPoints = 100;
            inputProperty.FloodCoveredZoneContentPoints1 = 100;
            inputProperty.FloodCoveredZoneContentPoints2 = 100;
            inputProperty.FloodCoveredZoneContentPoints3 = 100;
            inputProperty.FloodCoveredZoneContentPoints4 = 100;
            inputProperty.FloodCoveredZoneContentPoints5 = 100;
            inputProperty.EarthMovementTerritoryContentPoints1 = 100;
            inputProperty.EarthMovementTerritoryContentPoints2 = 100;
            inputProperty.EarthMovementLimitContentPoints = 100;
            inputProperty.ExcludedorReducedCoverageContentPoints = 0;//100;

            #endregion

            #region Schedule Rating
            inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels = new List<BuildingScheduleInputModel>()
            {
                new BuildingScheduleInputModel{
                BuildingLimit=500000, ContentsLimit=100000, Construction="Frame", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=200000, ContentsLimit=150000, Construction="Frame", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=150000, ContentsLimit=100000, Construction="Joisted Masonry", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=150000, ContentsLimit=150000, Construction="Frame", HazardGroup=2, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=50000, ContentsLimit=10000, Construction="Joisted Masonry", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=120000, ContentsLimit=130000, Construction="Frame", HazardGroup=2, ProtectionClass=1,SquareFootage=1
                }
            };
            #endregion

            inputProperty.EarthquakeLimit = 100;
            inputProperty.FloodLimit = 100;
            inputProperty.ExcludedorReducedCoverageJustification = "Moderate Restrictions or Coverage Exclusions";
            inputProperty.EarthquakeExposureJustification = " ";
            inputProperty.DisasterExposureJustification = "Highly Concentrated Values";
            inputProperty.ClimaticalHazardsHurricaneJustification = "10";
            inputProperty.ClimaticalHazardsSevereConvectiveJustification = "High Potential for Damage";
            inputProperty.ClimaticalHazardsWinterStormJustification = "High Potential for Damage";
            inputProperty.ClimaticalHazardsAllOtherJustification = "High Potential for Damage";
            inputProperty.OccupancyHazardsJustification = "Above Average Central Station Alarm Monitoring or Low Attraction Value";
            inputProperty.AmendedLimitorAddCoverageJustification = " ";
            inputProperty.FloodExposureJustification = " ";
            inputProperty.LackofPrivateProtectionJustification = " ";
            inputProperty.InadequatePublicProtectionJustification = " ";
            inputProperty.ExcludedorReducedCoverageJustification = " ";
            inputProperty.DeficiencyConstructionJustification = " ";
            inputProperty.UnusualCombustionJustification = " ";
            inputProperty.EarthquakeExposureJustification = " ";
            inputProperty.ExtraExternalExposureJustification = " ";

        }

        public void InitializeTestCase3(RaterFacadeModel raterFacadeModel)
        {
            var inputProperty = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var inputPolicyHeader = raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel;

            #region PolicyHeader

            inputPolicyHeader.Id = 1;
            inputPolicyHeader.ClientId = "Paragon";
            inputPolicyHeader.QuoteId = 3;
            inputPolicyHeader.State = StateCodeConstant.AL;
            inputPolicyHeader.PrimaryClass = "MU";
            inputPolicyHeader.SecondaryClass = "1";
            inputPolicyHeader.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            inputPolicyHeader.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            inputPolicyHeader.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            inputPolicyHeader.TransactionType = "NEWBUSINESS";
            inputPolicyHeader.TerrorismCoverage = true;
            #endregion

            #region BuildingBPP Initialization

            inputProperty.BuildingTIV = 2000000;
            inputProperty.ContentTIV = 1000000;
            inputProperty.AOPDeductible = 10000;
            inputProperty.SumNetNormalLossClaims = 20000;

            inputProperty.Coinsurance = "1.00";
            inputProperty.MarginClause = "1.20";
            inputProperty.Valuation = "RC";
            inputProperty.Blanket = "Test";

            inputProperty.TIVExpPeriod1stYear = 2500000;
            inputProperty.TIVExpPeriod2ndYear = 1500000;
            inputProperty.TIVExpPeriod3rdYear = 1000000;

            #endregion

            #region EquipmentBreakdown Initialization

            inputProperty.BusinessIncomeAndExtraExpenseLimit = 50000;
            inputProperty.IRPM = 100;
            inputProperty.EquipmentBreakdownDeductible = 5000;
            inputProperty.BusinessIncomeAndExtraExpenseDeductible = 240;
            inputProperty.PollutantCleanUpLimit = 250000;
            inputProperty.RefrigerantContaminationLimit = 250000;
            inputProperty.SelectedSpoilageType = "Type1";
            inputProperty.EBSpoilageLimit = 1000000;
            inputProperty.SpoilageDeductible = 0.1M; // "10%";
            inputProperty.SpoilageMinimumDeductible = 1000;
            inputProperty.ReferredEquipmentBreakdownCoverage = false;
            inputProperty.EquipmentBreakdownCoverage = true;

            if (inputProperty.ReferredEquipmentBreakdownCoverage == true)
            {
                inputProperty.EquipmentBreakdownRate = 0;
                inputProperty.InputEquipmentBreakdownTotalPremium = 98;
            }

            #endregion

            #region WindFloodEarthquake Initialization

            inputProperty.WindstormAndHailCoverage = true;
            inputProperty.FloodCoverage = true;
            inputProperty.EarthquakeCoverage = true;

            #endregion

            #region OptionalCoverage Initialization

            inputProperty.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = false;

            inputOptionalCoverage.IsAlabamaWindAndHailCertificateCreditCoverageSelected = true;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditDescription = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditLimit = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditDeductible = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditRatingBasis = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditRate = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditReturnMethod = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditPremium = -100000;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 1,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 500000,
                Deductible = 0,
                RatingBasis = "PER 1000 OF LIMIT",
                Rate = 0.25M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            }); ;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 2,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 500000,
                Deductible = 0,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.2M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 3,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 200000,
                Deductible = 500,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.089M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region FinalPremium Initialization

            inputProperty.LargeRiskFactor = 0.05M;

            #endregion

            #region Hazard (Property- fill-in Deficiency)

            // Building
            inputProperty.DisasterExposureBuildingPoints = 100;
            inputProperty.ClimaticalHazardsHurricaneBuildingPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints = 100;
            inputProperty.ClimaticalHazardsWinterStormBuildingPoints = 100;
            inputProperty.ClimaticalHazardsAllOtherBuildingPoints = 100;
            inputProperty.OccupancyHazardsBuildingPoints = 100;
            inputProperty.LackofPrivateProtectionBuildingPoints = 100;
            inputProperty.AmendedLimitorAddCoverageBuildingPoints = 100;
            inputProperty.InadequatePublicProtectionBuildingPoints = 100;
            inputProperty.ExtraExternalExposureBuildingPoints = 100;
            inputProperty.DeficiencyConstructionBuildingPoints = 100;
            inputProperty.UnusualCombustionBuildingPoints = 100;
            inputProperty.FloodExposureBuildingPoints = 100;
            inputProperty.EarthquakeExposureBuildingPoints = 100;
            inputProperty.ExcludedorReducedCoverageBuildingPoints = 0;//100;
            inputProperty.FloodDeductible = 100;
            inputProperty.EarthquakeDeductible = 100;
            inputProperty.WindstormAndHailDeductible = 100;

            //Content
            inputProperty.DisasterExposureContentPoints = 100;
            inputProperty.ClimaticalHazardsHurricaneContentPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveContentPoints = 100;
            inputProperty.ClimaticalHazardsWinterStormContentPoints = 100;
            inputProperty.ClimaticalHazardsAllOtherContentPoints = 100;
            inputProperty.OccupancyHazardsContentPoints = 100;
            inputProperty.LackofPrivateProtectionContentPoints = 100;
            inputProperty.AmendedLimitorAddCoverageContentPoints = 100;
            inputProperty.InadequatePublicProtectionContentPoints = 100;
            inputProperty.ExtraExternalExposureContentPoints = 100;
            inputProperty.DeficiencyConstructionContentPoints = 100;
            inputProperty.UnusualCombustionContentPoints = 100;
            inputProperty.FloodExposureContentPoints = 100;
            inputProperty.EarthquakeExposureContentPoints = 100;
            inputProperty.ExcludedorReducedCoverageContentPoints = 0;// 100;

            #endregion

            #region Hazard (Property- dropdown Deficiency)

            // Building
            inputProperty.DisasterExposureDispersionBuildingPoints = 100;
            inputProperty.DisasterExposurePMLBuildingPoints = 100;
            inputProperty.ClimaticalHazardsHurricaneBuildingPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints = 100;
            inputProperty.ClimaticalHazardsWinterStormBuildingPoints = 100;
            inputProperty.ClimaticalHazardsAllOtherBuildingPoints = 100;
            inputProperty.SpecialOccupancyHazardsBuildingPoints = 100;
            inputProperty.SpecialOccupancyProcessingBuildingPoints = 100;
            inputProperty.SpecialOccupancyBusinessIncomePMLBuildingPoints = 100;
            inputProperty.SpecialOccupancyNumberofOccupantsBuildingPoints = 100;
            inputProperty.PrivateProtectionFireSuppressionBuildingPoints = 100;
            inputProperty.PrivateProtectionFireProtectionBuildingPoints = 100;
            inputProperty.PrivateProtectionCentralMonitoringBuildingPoints = 100;
            inputProperty.SpecificInsuranceBuildingPoints = 100;
            inputProperty.PublicProtectionLowHazardBuildingPoints = 100;
            inputProperty.PublicProtectionMediumHazardBuildingPoints = 100;
            inputProperty.PublicProtectionHighHazardBuildingPoints = 100;
            inputProperty.ExternalExposureBuildingPoints = 100;
            inputProperty.ExternalExposureSeparationBuildingPoints = 100;
            inputProperty.ConstructionBuildingPoints = 100;
            inputProperty.ConstructionEngineeringBuildingPoints = 100;
            inputProperty.ConstructionAttractionValueBuildingPoints = 100;
            inputProperty.CommoditiesBuildingPoints = 100;
            inputProperty.FloodCoveredZoneBuildingPoints1 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints2 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints3 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints4 = 100;
            inputProperty.FloodCoveredZoneBuildingPoints5 = 100;
            inputProperty.EarthMovementTerritoryBuildingPoints1 = 100;
            inputProperty.EarthMovementTerritoryBuildingPoints2 = 100;
            inputProperty.EarthMovementLimitBuildingPoints = 100;
            inputProperty.ExcludedorReducedCoverageBuildingPoints = 0;// 100;

            //Content
            inputProperty.DisasterExposureDispersionContentPoints = 100;
            inputProperty.DisasterExposurePMLContentPoints = 100;
            inputProperty.ClimaticalHazardsHurricaneContentPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveContentPoints = 100;
            inputProperty.ClimaticalHazardsWinterStormContentPoints = 100;
            inputProperty.ClimaticalHazardsAllOtherContentPoints = 100;
            inputProperty.SpecialOccupancyHazardsContentPoints = 100;
            inputProperty.SpecialOccupancyProcessingContentPoints = 100;
            inputProperty.SpecialOccupancyBusinessIncomePMLContentPoints = 100;
            inputProperty.SpecialOccupancyNumberofOccupantsContentPoints = 100;
            inputProperty.PrivateProtectionFireSuppressionContentPoints = 100;
            inputProperty.PrivateProtectionFireProtectionContentPoints = 100;
            inputProperty.PrivateProtectionCentralMonitoringContentPoints = 100;
            inputProperty.SpecificInsuranceContentPoints = 100;
            inputProperty.PublicProtectionLowHazardContentPoints = 100;
            inputProperty.PublicProtectionMediumHazardContentPoints = 100;
            inputProperty.PublicProtectionHighHazardContentPoints = 100;
            inputProperty.ExternalExposureContentPoints = 100;
            inputProperty.ExternalExposureSeparationContentPoints = 100;
            inputProperty.ConstructionContentPoints = 100;
            inputProperty.ConstructionEngineeringContentPoints = 100;
            inputProperty.ConstructionAttractionValueContentPoints = 100;
            inputProperty.CommoditiesContentPoints = 100;
            inputProperty.FloodCoveredZoneContentPoints1 = 100;
            inputProperty.FloodCoveredZoneContentPoints2 = 100;
            inputProperty.FloodCoveredZoneContentPoints3 = 100;
            inputProperty.FloodCoveredZoneContentPoints4 = 100;
            inputProperty.FloodCoveredZoneContentPoints5 = 100;
            inputProperty.EarthMovementTerritoryContentPoints1 = 100;
            inputProperty.EarthMovementTerritoryContentPoints2 = 100;
            inputProperty.EarthMovementLimitContentPoints = 100;
            inputProperty.ExcludedorReducedCoverageContentPoints = 0;// 100;

            #endregion

            inputProperty.EarthquakeLimit = 100;
            inputProperty.FloodLimit = 100;
            inputProperty.ExcludedorReducedCoverageJustification = "Moderate Restrictions or Coverage Exclusions";
            inputProperty.EarthquakeExposureJustification = " ";
            inputProperty.DisasterExposureJustification = "Highly Concentrated Values";
            inputProperty.ClimaticalHazardsHurricaneJustification = "10";
            inputProperty.ClimaticalHazardsSevereConvectiveJustification = "High Potential for Damage";
            inputProperty.ClimaticalHazardsWinterStormJustification = "High Potential for Damage";
            inputProperty.ClimaticalHazardsAllOtherJustification = "High Potential for Damage";
            inputProperty.OccupancyHazardsJustification = "Above Average Central Station Alarm Monitoring or Low Attraction Value";
            inputProperty.AmendedLimitorAddCoverageJustification = " ";
            inputProperty.FloodExposureJustification = " ";
            inputProperty.LackofPrivateProtectionJustification = " ";
            inputProperty.InadequatePublicProtectionJustification = " ";
            inputProperty.ExcludedorReducedCoverageJustification = " ";
            inputProperty.DeficiencyConstructionJustification = " ";
            inputProperty.UnusualCombustionJustification = " ";
            inputProperty.EarthquakeExposureJustification = " ";
            inputProperty.ExtraExternalExposureJustification = " ";

        }

        public void InitializeTestCase4(RaterFacadeModel raterFacadeModel)
        {
            var inputProperty = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var inputPolicyHeader = raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel;

            #region PolicyHeader

            inputPolicyHeader.Id = 1;
            inputPolicyHeader.ClientId = "Paragon";
            inputPolicyHeader.QuoteId = 3;
            inputPolicyHeader.State = StateCodeConstant.AL;
            inputPolicyHeader.PrimaryClass = "FD";
            inputPolicyHeader.SecondaryClass = "36";
            inputPolicyHeader.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            inputPolicyHeader.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            inputPolicyHeader.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            inputPolicyHeader.TransactionType = "NEWBUSINESS";
            inputPolicyHeader.TerrorismCoverage = true;
            #endregion

            #region BuildingBPP Initialization

            inputProperty.BuildingTIV = 500000;
            inputProperty.ContentTIV = 600000;
            inputProperty.AOPDeductible = 500;
            inputProperty.SumNetNormalLossClaims = 100000;

            inputProperty.Coinsurance = "0.80";
            inputProperty.MarginClause = "1.05";
            inputProperty.Valuation = "ACV";
            inputProperty.Blanket = "Test";

            inputProperty.TIVExpPeriod1stYear = 30000;
            inputProperty.TIVExpPeriod2ndYear = 10000;
            inputProperty.TIVExpPeriod3rdYear = 20000;

            #endregion

            #region EquipmentBreakdown Initialization

            inputProperty.BusinessIncomeAndExtraExpenseLimit = 400000;
            inputProperty.IRPM = 91;
            inputProperty.EquipmentBreakdownDeductible = 1000;
            inputProperty.BusinessIncomeAndExtraExpenseDeductible = 12;
            inputProperty.PollutantCleanUpLimit = 500000;
            inputProperty.RefrigerantContaminationLimit = 250000;
            inputProperty.SelectedSpoilageType = "Type2";
            inputProperty.EBSpoilageLimit = 500000;
            inputProperty.SpoilageDeductible = 0.1M; // "10%";
            inputProperty.SpoilageMinimumDeductible = 7500;
            inputProperty.ReferredEquipmentBreakdownCoverage = false;
            inputProperty.EquipmentBreakdownCoverage = true;

            if (inputProperty.ReferredEquipmentBreakdownCoverage == true)
            {
                inputProperty.EquipmentBreakdownRate = 0;
                inputProperty.InputEquipmentBreakdownTotalPremium = 98;
            }

            #endregion

            #region WindFloodEarthquake Initialization

            inputProperty.WindstormAndHailCoverage = true;
            inputProperty.FloodCoverage = true;
            inputProperty.EarthquakeCoverage = true;

            #endregion

            #region OptionalCoverage Initialization

            inputProperty.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = false;

            inputOptionalCoverage.IsAlabamaWindAndHailCertificateCreditCoverageSelected = false;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditDescription = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditLimit = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditDeductible = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditRatingBasis = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditRate = 0;
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditReturnMethod = "";
            inputOptionalCoverage.AlabamaWindAndHailCertificateCreditPremium = 0;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            //inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            //{
            //    Id = 1,
            //    IsOptionalCoverageSelected = true,
            //    Description = "OTHER",
            //    Limit = 0,
            //    Deductible = 0,
            //    RatingBasis = "PER 1000 OF LIMIT",
            //    Rate = 0.1M,
            //    ReturnMethod = "Pro Rata",
            //    Premium = 0,
            //});

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 2,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 400000,
                Deductible = 0,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.15M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            //inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            //{
            //    Id = 3,
            //    IsOptionalCoverageSelected = true,
            //    Description = "OTHER",
            //    Limit = 200000,
            //    Deductible = 500,
            //    RatingBasis = "PER 100 OF LIMIT",
            //    Rate = 0.089M,
            //    ReturnMethod = "Pro Rata",
            //    Premium = 0,
            //});

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region FinalPremium Initialization

            inputProperty.LargeRiskFactor = 1;

            #endregion

            #region Hazard (Property- fill-in Deficiency)

            // Building
            inputProperty.DisasterExposureBuildingPoints = 1000;
            inputProperty.ClimaticalHazardsHurricaneBuildingPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints = 500;
            inputProperty.ClimaticalHazardsWinterStormBuildingPoints = 700;
            inputProperty.ClimaticalHazardsAllOtherBuildingPoints = 200;
            inputProperty.OccupancyHazardsBuildingPoints = 300;
            inputProperty.LackofPrivateProtectionBuildingPoints = 1000;
            inputProperty.AmendedLimitorAddCoverageBuildingPoints = 1000;
            inputProperty.InadequatePublicProtectionBuildingPoints = 100;
            inputProperty.ExtraExternalExposureBuildingPoints = 700;
            inputProperty.DeficiencyConstructionBuildingPoints = 100;
            inputProperty.UnusualCombustionBuildingPoints = 100;
            inputProperty.FloodExposureBuildingPoints = 1000;
            inputProperty.EarthquakeExposureBuildingPoints = 300;
            inputProperty.ExcludedorReducedCoverageBuildingPoints = 0;// -1000;

            inputProperty.FloodDeductible = 100;
            inputProperty.EarthquakeDeductible = 100;
            inputProperty.WindstormAndHailDeductible = 100;

            //Content
            inputProperty.DisasterExposureContentPoints = 1000;
            inputProperty.ClimaticalHazardsHurricaneContentPoints = 100;
            inputProperty.ClimaticalHazardsSevereConvectiveContentPoints = 500;
            inputProperty.ClimaticalHazardsWinterStormContentPoints = 700;
            inputProperty.ClimaticalHazardsAllOtherContentPoints = 200;
            inputProperty.OccupancyHazardsContentPoints = 300;
            inputProperty.LackofPrivateProtectionContentPoints = 1000;
            inputProperty.AmendedLimitorAddCoverageContentPoints = 1000;
            inputProperty.InadequatePublicProtectionContentPoints = 100;
            inputProperty.ExtraExternalExposureContentPoints = 700;
            inputProperty.DeficiencyConstructionContentPoints = 100;
            inputProperty.UnusualCombustionContentPoints = 100;
            inputProperty.FloodExposureContentPoints = 1000;
            inputProperty.EarthquakeExposureContentPoints = 300;
            inputProperty.ExcludedorReducedCoverageContentPoints = 0;// -1000;

            #endregion

            #region Hazard (Property- dropdown Deficiency)

            // Building
            //inputProperty.DisasterExposureDispersionBuildingPoints = 100;
            //inputProperty.DisasterExposurePMLBuildingPoints = 100;
            //inputProperty.ClimaticalHazardsHurricaneBuildingPoints = 100;
            //inputProperty.ClimaticalHazardsSevereConvectiveBuildingPoints = 100;
            //inputProperty.ClimaticalHazardsWinterStormBuildingPoints = 100;
            //inputProperty.ClimaticalHazardsAllOtherBuildingPoints = 100;
            //inputProperty.SpecialOccupancyHazardsBuildingPoints = 100;
            //inputProperty.SpecialOccupancyProcessingBuildingPoints = 100;
            //inputProperty.SpecialOccupancyBusinessIncomePMLBuildingPoints = 100;
            //inputProperty.SpecialOccupancyNumberofOccupantsBuildingPoints = 100;
            //inputProperty.PrivateProtectionFireSuppressionBuildingPoints = 100;
            //inputProperty.PrivateProtectionFireProtectionBuildingPoints = 100;
            //inputProperty.PrivateProtectionCentralMonitoringBuildingPoints = 100;
            //inputProperty.SpecificInsuranceBuildingPoints = 100;
            //inputProperty.PublicProtectionLowHazardBuildingPoints = 100;
            //inputProperty.PublicProtectionMediumHazardBuildingPoints = 100;
            //inputProperty.PublicProtectionHighHazardBuildingPoints = 100;
            //inputProperty.ExternalExposureBuildingPoints = 100;
            //inputProperty.ExternalExposureSeparationBuildingPoints = 100;
            //inputProperty.ConstructionBuildingPoints = 100;
            //inputProperty.ConstructionEngineeringBuildingPoints = 100;
            //inputProperty.ConstructionAttractionValueBuildingPoints = 100;
            //inputProperty.CommoditiesBuildingPoints = 100;
            //inputProperty.FloodCoveredZoneBuildingPoints1 = 100;
            //inputProperty.FloodCoveredZoneBuildingPoints2 = 100;
            //inputProperty.FloodCoveredZoneBuildingPoints3 = 100;
            //inputProperty.FloodCoveredZoneBuildingPoints4 = 100;
            //inputProperty.FloodCoveredZoneBuildingPoints5 = 100;
            //inputProperty.EarthMovementTerritoryBuildingPoints1 = 100;
            //inputProperty.EarthMovementTerritoryBuildingPoints2 = 100;
            //inputProperty.EarthMovementLimitBuildingPoints = 100;
            //inputProperty.ExcludedorReducedCoverageBuildingPoints = 100;

            ////Content
            //inputProperty.DisasterExposureDispersionContentPoints = 100;
            //inputProperty.DisasterExposurePMLContentPoints = 100;
            //inputProperty.ClimaticalHazardsHurricaneContentPoints = 100;
            //inputProperty.ClimaticalHazardsSevereConvectiveContentPoints = 100;
            //inputProperty.ClimaticalHazardsWinterStormContentPoints = 100;
            //inputProperty.ClimaticalHazardsAllOtherContentPoints = 100;
            //inputProperty.SpecialOccupancyHazardsContentPoints = 100;
            //inputProperty.SpecialOccupancyProcessingContentPoints = 100;
            //inputProperty.SpecialOccupancyBusinessIncomePMLContentPoints = 100;
            //inputProperty.SpecialOccupancyNumberofOccupantsContentPoints = 100;
            //inputProperty.PrivateProtectionFireSuppressionContentPoints = 100;
            //inputProperty.PrivateProtectionFireProtectionContentPoints = 100;
            //inputProperty.PrivateProtectionCentralMonitoringContentPoints = 100;
            //inputProperty.SpecificInsuranceContentPoints = 100;
            //inputProperty.PublicProtectionLowHazardContentPoints = 100;
            //inputProperty.PublicProtectionMediumHazardContentPoints = 100;
            //inputProperty.PublicProtectionHighHazardContentPoints = 100;
            //inputProperty.ExternalExposureContentPoints = 100;
            //inputProperty.ExternalExposureSeparationContentPoints = 100;
            //inputProperty.ConstructionContentPoints = 100;
            //inputProperty.ConstructionEngineeringContentPoints = 100;
            //inputProperty.ConstructionAttractionValueContentPoints = 100;
            //inputProperty.CommoditiesContentPoints = 100;
            //inputProperty.FloodCoveredZoneContentPoints1 = 100;
            //inputProperty.FloodCoveredZoneContentPoints2 = 100;
            //inputProperty.FloodCoveredZoneContentPoints3 = 100;
            //inputProperty.FloodCoveredZoneContentPoints4 = 100;
            //inputProperty.FloodCoveredZoneContentPoints5 = 100;
            //inputProperty.EarthMovementTerritoryContentPoints1 = 100;
            //inputProperty.EarthMovementTerritoryContentPoints2 = 100;
            //inputProperty.EarthMovementLimitContentPoints = 100;
            //inputProperty.ExcludedorReducedCoverageContentPoints = 100;

            #endregion

            inputProperty.EarthquakeLimit = 100;
            inputProperty.FloodLimit = 100;
            inputProperty.ExcludedorReducedCoverageJustification = "Moderate Restrictions or Coverage Exclusions";
            inputProperty.EarthquakeExposureJustification = " ";
            inputProperty.DisasterExposureJustification = "Highly Concentrated Values";
            inputProperty.ClimaticalHazardsHurricaneJustification = "10";
            inputProperty.ClimaticalHazardsSevereConvectiveJustification = "High Potential for Damage";
            inputProperty.ClimaticalHazardsWinterStormJustification = "High Potential for Damage";
            inputProperty.ClimaticalHazardsAllOtherJustification = "High Potential for Damage";
            inputProperty.OccupancyHazardsJustification = "Above Average Central Station Alarm Monitoring or Low Attraction Value";
            inputProperty.AmendedLimitorAddCoverageJustification = " ";
            inputProperty.FloodExposureJustification = " ";
            inputProperty.LackofPrivateProtectionJustification = " ";
            inputProperty.InadequatePublicProtectionJustification = " ";
            inputProperty.ExcludedorReducedCoverageJustification = " ";
            inputProperty.DeficiencyConstructionJustification = " ";
            inputProperty.UnusualCombustionJustification = " ";
            inputProperty.EarthquakeExposureJustification = " ";
            inputProperty.ExtraExternalExposureJustification = " ";

        }
    }
}
