﻿using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Property.Input;
using Models.ApiModels.LineOfBusiness.Property.Output;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class PropertyNewYork360Initialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            var propertyInputModel = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var propertyOutputModel = raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property;

            if (propertyInputModel.PropertyStateSpecificInputModel == null)
            {
                propertyInputModel.PropertyStateSpecificInputModel = new PropertyStateSpecificInputModel();                
            }
            if (propertyInputModel.PropertyStateSpecificInputModel.PropertyNewYork360InputModel == null)
            {
                propertyInputModel.PropertyStateSpecificInputModel.PropertyNewYork360InputModel = new PropertyNewYork360InputModel();
            }

            if (propertyOutputModel.PropertyStateSpecificOutputModel==null)
            {
                propertyOutputModel.PropertyStateSpecificOutputModel = new PropertyStateSpecificOutputModel();
                propertyOutputModel.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel = new PropertyNewYork360OutputModel();
            }           

        }

        public void InitializeNewYork360PropertyCase1(RaterFacadeModel model)
        {           
            var NY360InputProperty = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel;

            NY360InputProperty.IsAccountsReceivableRecordsCoverageSelected = true;
            NY360InputProperty.IsBuildingOrdinanceORLawDemolitionCostCoverageSelected = true;
            NY360InputProperty.IsBuildingOrdinanceORLawIncreasedCostOfContructionCoverageSelected = true;
            NY360InputProperty.IsChangesInTemperatureORHumidityCoverageSelected = true;
            NY360InputProperty.IsCommandeeredPropertyCoverageSelected = true;
            NY360InputProperty.IsCommunicationEquipmentCoverageSelected = true;
            NY360InputProperty.IsComputerEquipmentCoverageSelected = true;
            NY360InputProperty.IsDetachedSignsCoverageSelected = true;
            NY360InputProperty.IsElectricalDamageCoverageSelected = true;
            NY360InputProperty.IsExtraExpenseAndBusinessIncomeCoverageSelected = true;
            NY360InputProperty.IsFairsExhibitionsExpositionsORTradeShowsCoverageSelected = true;
            NY360InputProperty.IsFineartsCoverageSelected = true;
            NY360InputProperty.IsFireDepartmentServiceChargeCoverageSelected = true;
            NY360InputProperty.IsFlagpolesCoverageSelected = true;
            NY360InputProperty.IsGlassDisplayORTrophyCasesCoverageSelected = true;

            NY360InputProperty.IsGroundsMaintenanceEquipmentCoverageSelected = true;
            NY360InputProperty.IsLockReplacementCoverageSelected = true;
            NY360InputProperty.IsMoneySecuritiesAndStampsInsidePremiseCoverageSelected = true;
            NY360InputProperty.IsMoneySecuritiesAndStampsOutsidePremiseCoverageSelected = true;
            NY360InputProperty.IsNewlyAcquiredORConstructedPropertyBuildingCoverageSelected = true;
            NY360InputProperty.IsNewlyAcquiredORConstructedPropertyPersonalPropertyCoverageSelected = true;
            NY360InputProperty.IsOffPremisesUtilityFailureCoverageSelected = true;
            NY360InputProperty.IsOutdoorPropertyAnyOneTreeShrubORplantCoverageSelected = true;
            NY360InputProperty.IsOutdoorPropertyTotalLimitCoverageSelected = true;
            NY360InputProperty.IsPersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerCoverageSelected = true;
            NY360InputProperty.IsPersonalEffectsAndPropertyOfOthersAnyOneOccurrenceCoverageSelected = true;
            NY360InputProperty.IsPollutantCleanUpAndRemovalCoverageSelected = true;
            NY360InputProperty.IsPropertyInTransitCoverageSelected = true;
            NY360InputProperty.IsSpoilageCoverageSelected = true;
            NY360InputProperty.IsValuablePapersAndRecordsCoverageSelected = true;
            NY360InputProperty.IsExtraExpenseAndTuitionFeesCoverageSelected = true;
            NY360InputProperty.IsValuablePapersCoverageSelected = true;
            NY360InputProperty.IsMusicalInstrumentsAndBandUniformsCoverageSelected = true;
            NY360InputProperty.IsPersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerCoverageSelected = true;
            NY360InputProperty.IsPersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceCoverageSelected = true;

            NY360InputProperty.AccountsReceivableRecordsRevisedLimit = 60000;
            NY360InputProperty.BuildingOrdinanceORLawDemolitionCostRevisedLimit = 500000;
            NY360InputProperty.BuildingOrdinanceORLawIncreasedCostOfContructionRevisedLimit = 300000;
            NY360InputProperty.ChangesInTemperatureORHumidityRevisedLimit = 100000;
            NY360InputProperty.CommandeeredPropertyRevisedLimit = 500000;
            NY360InputProperty.CommunicationEquipmentRevisedLimit = 100000;
            NY360InputProperty.ComputerEquipmentRevisedLimit = 100000;
            NY360InputProperty.DetachedSignsRevisedLimit = 5000;
            NY360InputProperty.ElectricalDamageRevisedLimit = 70000;
            NY360InputProperty.ExtraExpenseAndBusinessIncomeRevisedLimit = 150000;
            NY360InputProperty.FairsExhibitionsExpositionsORTradeShowsRevisedLimit = 150000;
            NY360InputProperty.FineartsRevisedLimit = 60000;
            NY360InputProperty.FireDepartmentServiceChargeRevisedLimit = 15000;
            NY360InputProperty.FlagpolesRevisedLimit = 11000;
            NY360InputProperty.GlassDisplayORTrophyCasesRevisedLimit = 7000;
            NY360InputProperty.GroundsMaintenanceEquipmentRevisedLimit = 5000;
            NY360InputProperty.LockReplacementRevisedLimit = 500;
            NY360InputProperty.MoneySecuritiesAndStampsInsidePremiseRevisedLimit = 5000;
            NY360InputProperty.MoneySecuritiesAndStampsOutsidePremiseRevisedLimit = 5000;
            NY360InputProperty.NewlyAcquiredORConstructedPropertyBuildingRevisedLimit = 1000000;
            NY360InputProperty.NewlyAcquiredORConstructedPropertyPersonalPropertyRevisedLimit = 500000;
            NY360InputProperty.OffPremisesUtilityFailureRevisedLimit = 75000;
            NY360InputProperty.OutdoorPropertyAnyOneTreeShrubORplantRevisedLimit = 3000;
            NY360InputProperty.OutdoorPropertyTotalLimitRevisedLimit = 50000;
            NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRevisedLimit = 3000;
            NY360InputProperty.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRevisedLimit = 150000;
            NY360InputProperty.PollutantCleanUpAndRemovalRevisedLimit = 50000;
            NY360InputProperty.PropertyInTransitRevisedLimit = 50000;
            NY360InputProperty.PropertyOffPremisesRevisedLimit = 50000;
            NY360InputProperty.SpoilageCoverageRevisedLimit = 50000;
            NY360InputProperty.ValuablePapersAndRecordsRevisedLimit = 150000;
            NY360InputProperty.ExtraExpenseAndTuitionFeesRevisedLimit = 150000;
            NY360InputProperty.ValuablePapersRevisedLimit = 250000;
            NY360InputProperty.MusicalInstrumentsAndBandUniformsRevisedLimit = 110000;
            NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRevisedLimit = 2500;
            NY360InputProperty.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRevisedLimit = 150000;
        }
    }
}
