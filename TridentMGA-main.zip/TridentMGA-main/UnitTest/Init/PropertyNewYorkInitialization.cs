﻿using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Property.Input;
using Models.ApiModels.LineOfBusiness.Property.Output;
using Models.ApiModels.Policy;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;
using Models;

namespace UnitTest.Init
{
    public class PropertyNewYorkInitialization
    {
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {            
            if (raterFacadeModel.RaterInputFacadeModel == null)
            {
                raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel();
            }
            if (raterFacadeModel.RaterOutputFacadeModel == null)
            {
                raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            }

            var raterInputFacade = raterFacadeModel.RaterInputFacadeModel;
            var raterOutputFacade = raterFacadeModel.RaterOutputFacadeModel;

            raterInputFacade.LineOfBusiness.Property = true;
            raterInputFacade.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterOutputFacade.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterInputFacade.PolicyHeaderModel = new PolicyHeaderModel();
            raterOutputFacade.PremiumSummaryModel = new PremiumSummaryModel();
            raterOutputFacade.ResponseModel = new ResponseInfoModel();
            raterInputFacade.LineOfBusinessInputModel.Property = new PropertyInputModel();
            raterInputFacade.LineOfBusinessInputModel.Property.ScheduleRatingInputModels = new PropertyScheduleRatingInputModel();
            raterInputFacade.LineOfBusinessInputModel.Property.ScheduleRatingInputModels.buildingScheduleInputModels = new List<BuildingScheduleInputModel>();
            raterOutputFacade.LineOfBusinessOutputModel.Property = new PropertyOutputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel = new PropertyStateSpecificInputModel();
        }

        public void InitializeCase1(RaterFacadeModel raterFacadeModel)
        {
            var inputProperty = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var inputPolicyHeader = raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel;

            #region PolicyHeaderModel
            inputPolicyHeader.Id = 1;
            inputPolicyHeader.ClientId = "Paragon";
            inputPolicyHeader.QuoteId = 3;
            inputPolicyHeader.State = StateCodeConstant.NY;
            inputPolicyHeader.PrimaryClass = "CO";
            inputPolicyHeader.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            inputPolicyHeader.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            inputPolicyHeader.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            inputPolicyHeader.TransactionType = "NEWBUSINESS";
            inputPolicyHeader.TerrorismCoverage = true;
            #endregion

            inputProperty.Valuation = "RC";            
            inputProperty.Coinsurance = ".80";
            inputProperty.AOPDeductible = 2500;            
            inputProperty.IRPM = 100;            
            inputProperty.OtherModFactor = 1.21M;
            inputProperty.PropertyStateSpecificInputModel.NewYorkInflationGuard = .120M;
            inputProperty.PropertyStateSpecificInputModel.NewYorkCauseofLoss = "Broad";
            inputProperty.PropertyStateSpecificInputModel.NewYorkEquipmentBreakdownLimit = 400000M;
            inputProperty.EquipmentBreakdownCoverage = true;
            inputProperty.ReferredEquipmentBreakdownCoverage = true;
            inputProperty.Blanket = "test";

            if (inputProperty.ReferredEquipmentBreakdownCoverage == false)
            {
                inputProperty.EquipmentBreakdownRate = 0.020M;
                inputProperty.InputEquipmentBreakdownTotalPremium = 0;
            }
            else
            {
                inputProperty.InputEquipmentBreakdownTotalPremium = 150;
                inputProperty.EquipmentBreakdownRate = 0;
            }


            inputProperty.WindstormAndHailCoverage = true;
            if (inputProperty.WindstormAndHailCoverage == true)
            {
                // We can pass Premium or Rate one at a time.
                //model.InputModel.Property.NY_WindAndHailPremium = 500M;
                inputProperty.PropertyStateSpecificInputModel.NewYorkWindAndHailRate = 0.010M;
                inputProperty.WindstormAndHailDeductible = 100;

            }

            inputProperty.EarthquakeCoverage = true;
            if (inputProperty.EarthquakeCoverage == true)
            {
                // We can pass Premium or Rate one at a time.
                inputProperty.PropertyStateSpecificInputModel.NewYorkEarthquakeLimit = 50000M;
                inputProperty.PropertyStateSpecificInputModel.NewYorkEarthquakeRate = 0.020M;
                //model.InputModel.Property.NY_EarthquakePremium = 2000M;
                inputProperty.EarthquakeDeductible = 100;
            }

            inputProperty.FloodCoverage = true;
            if (inputProperty.FloodCoverage == true)
            {
                // We can pass Premium or Rate one at a time.
                inputProperty.PropertyStateSpecificInputModel.NewYorkFloodLimit = 300000M;
                inputProperty.PropertyStateSpecificInputModel.NewYorkFloodRate = 0.020M;
                //model.InputModel.Property.NY_FloodPremium = 2000M;
                inputProperty.FloodDeductible = 100;

            }

            #region OptionalCoverage Initialization

            inputProperty.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = false;

            inputOptionalCoverage.IsAlabamaWindAndHailCertificateCreditCoverageSelected = false;


            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 1,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 500000,
                Deductible = 0,
                RatingBasis = "PER 1000 OF LIMIT",
                Rate = 0.25M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            }); ;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 2,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 500000,
                Deductible = 0,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.2M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 3,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 200000,
                Deductible = 500,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.089M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.IsMoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceCoverageSelected = true;
            inputOptionalCoverage.MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium = 10000;

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region Schedule Rating
            inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels = new List<BuildingScheduleInputModel>()
            {
                new BuildingScheduleInputModel{
                BuildingLimit=500000, ContentsLimit=100000, Construction="Frame", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=200000, ContentsLimit=150000, Construction="Frame", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=150000, ContentsLimit=100000, Construction="Joisted Masonry", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=150000, ContentsLimit=150000, Construction="Frame", HazardGroup=2, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=50000, ContentsLimit=10000, Construction="Joisted Masonry", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=120000, ContentsLimit=130000, Construction="Frame", HazardGroup=2, ProtectionClass=1,SquareFootage=1
                }
            };
            #endregion
        }

        public void InitializeCase2(RaterFacadeModel raterFacadeModel)
        {
            var inputProperty = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            var inputPolicyHeader = raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel;

            #region PolicyHeaderModel
            inputPolicyHeader.Id = 1;
            inputPolicyHeader.ClientId = "Paragon";
            inputPolicyHeader.QuoteId = 3;
            inputPolicyHeader.State = StateCodeConstant.NY;
            inputPolicyHeader.PrimaryClass = "CO";
            inputPolicyHeader.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            inputPolicyHeader.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            inputPolicyHeader.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy
            inputPolicyHeader.TransactionType = "NEWBUSINESS";
            inputPolicyHeader.TerrorismCoverage = true;
            #endregion

            inputProperty.Valuation = "RC";
            inputProperty.PropertyStateSpecificInputModel.NewYorkCauseofLoss = "Broad";
            inputProperty.Coinsurance = ".80";
            inputProperty.AOPDeductible = 2500;
            inputProperty.PropertyStateSpecificInputModel.NewYorkInflationGuard = .120M;
            inputProperty.IRPM = 100;
            inputProperty.OtherModFactor = 1.21M;
            inputProperty.EquipmentBreakdownCoverage = true;
            inputProperty.PropertyStateSpecificInputModel.NewYorkEquipmentBreakdownLimit = 400000M;
            inputProperty.ReferredEquipmentBreakdownCoverage = false;
            inputProperty.Blanket = "test";
            if (inputProperty.ReferredEquipmentBreakdownCoverage == false)
            {
                inputProperty.EquipmentBreakdownRate = 0.020M;
                inputProperty.InputEquipmentBreakdownTotalPremium = 0;
            }
            else
            {
                inputProperty.InputEquipmentBreakdownTotalPremium = 150;
                inputProperty.EquipmentBreakdownRate = 0;
            }

            inputProperty.WindstormAndHailCoverage = true;
            if (inputProperty.WindstormAndHailCoverage == true)
            {
                // We can pass Premium or Rate one at a time.
                //model.InputModel.Property.NY_WindAndHailPremium = 500M;
                inputProperty.PropertyStateSpecificInputModel.NewYorkWindAndHailRate = 0.010M;
                inputProperty.WindstormAndHailDeductible = 100;
            }

            inputProperty.EarthquakeCoverage = true;
            if (inputProperty.EarthquakeCoverage == true)
            {
                // We can pass Premium or Rate one at a time.
                inputProperty.PropertyStateSpecificInputModel.NewYorkEarthquakeLimit = 50000M;
                inputProperty.PropertyStateSpecificInputModel.NewYorkEarthquakeRate = 0.020M;
                //model.InputModel.Property.NY_EarthquakePremium = 2000M;
                inputProperty.EarthquakeDeductible = 100;
            }

            inputProperty.FloodCoverage = true;
            if (inputProperty.FloodCoverage == true)
            {
                // We can pass Premium or Rate one at a time.
                inputProperty.PropertyStateSpecificInputModel.NewYorkFloodLimit = 300000M;
                inputProperty.PropertyStateSpecificInputModel.NewYorkFloodRate = 0.020M;
                //model.InputModel.Property.NY_FloodPremium = 2000M;
                inputProperty.FloodDeductible = 100;
            }

            #region OptionalCoverage Initialization

            inputProperty.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = inputProperty.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = false;

            inputOptionalCoverage.IsAlabamaWindAndHailCertificateCreditCoverageSelected = false;


            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 1,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 500000,
                Deductible = 0,
                RatingBasis = "PER 1000 OF LIMIT",
                Rate = 0.25M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            }); ;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 2,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 500000,
                Deductible = 0,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.2M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Id = 3,
                IsOptionalCoverageSelected = true,
                Description = "OTHER",
                Limit = 200000,
                Deductible = 500,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.089M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.IsMoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceCoverageSelected = true;
            inputOptionalCoverage.MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium = 10000;

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region Schedule Rating
            inputProperty.ScheduleRatingInputModels.buildingScheduleInputModels = new List<BuildingScheduleInputModel>()
            {
                new BuildingScheduleInputModel{
                BuildingLimit=500000, ContentsLimit=100000, Construction="Frame", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=200000, ContentsLimit=150000, Construction="Frame", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=150000, ContentsLimit=100000, Construction="Joisted Masonry", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=150000, ContentsLimit=150000, Construction="Frame", HazardGroup=2, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=50000, ContentsLimit=10000, Construction="Joisted Masonry", HazardGroup=1, ProtectionClass=1,SquareFootage=1
                },
                new BuildingScheduleInputModel{
                BuildingLimit=120000, ContentsLimit=130000, Construction="Frame", HazardGroup=2, ProtectionClass=1,SquareFootage=1
                }
            };
            #endregion

        }
    }
}
           