﻿using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Output;
using Models.ApiModels.LineOfBusiness.PublicOfficials;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Input;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Output;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    /// <summary>
    /// Public Officials CW Initialization
    /// </summary>
    public class PublicOfficialsCWInitialization
    {
        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.PublicOfficials = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials = new PublicOfficialsInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW = new PublicOfficialsCWInputModel();

            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel = new PublicOfficialsCWOptionalCoverageInputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials = new PublicOfficialsOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW = new PublicOfficialsCWOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel = new PublicOfficialsCWOptionalCoverageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel = new List<PublicOfficialsCWOtherCoverageOutputModel>();
        }

        #region unti test case1

        /// <summary>
        /// Initialize Policy Header Model
        /// </summary>
        /// <param name="model"></param>
        public void InitializePolicyHeaderModel(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = "AL";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 5001;
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy   
            #endregion

            #region Pricing
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "";
            #endregion
        }

        /// <summary>
        /// Initialize Libility Premium
        /// </summary>
        /// <param name="model"></param>
        public void InitializeLibilityPremium(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            this.InitializePolicyHeaderModel(model);
            #endregion

            var inputPublicOfficialsCWModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW;
            inputPublicOfficialsCWModel.Exposure = 100000;
            inputPublicOfficialsCWModel.ExposureRate = 3;
            inputPublicOfficialsCWModel.LiabilityLimit = 100000;
            inputPublicOfficialsCWModel.AggregateLimit = 300000;
            inputPublicOfficialsCWModel.LiabilityLimitRate = 1;
            inputPublicOfficialsCWModel.DeductibleSIR = "Deductible";
            inputPublicOfficialsCWModel.Retention = "500";

            inputPublicOfficialsCWModel.AggregateRetention = 1;
            inputPublicOfficialsCWModel.ExperienceFactorIsSelected = true;
            inputPublicOfficialsCWModel.Type = "";
            inputPublicOfficialsCWModel.Expense = "";

            inputPublicOfficialsCWModel.PolicyType = "Claims Made";
            inputPublicOfficialsCWModel.RetroDate = Convert.ToDateTime("10-10-2023");
            inputPublicOfficialsCWModel.IRPMApplies = true;
            inputPublicOfficialsCWModel.YearsInCMProgram = 1;
            inputPublicOfficialsCWModel.IRPMFactor = 1;
            inputPublicOfficialsCWModel.OtherModRate = 1;
        }

        /// <summary>
        /// Initialize Optional Coverage Premium
        /// </summary>
        /// <param name="model"></param>
        public void InitializeOptionalCoveragePremium(RaterFacadeModel model)
        {
            var inputPublicOfficialsCWOptionalCoverageInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseIsSelected = true;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseLimit = 10;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseAggregateLimit = 10;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseDeductible = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseRatingBasis = "string";
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseReturnMethod = "string";
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseRate = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseUnModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationIsSelected = true;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationLimit = 10;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationAggregateLimit = 10;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationDeductible = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationRatingBasis = "string";
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationReturnMethod = "string";
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationRate = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationUnModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodIsSelected = true;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodLimit = 10;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodAggregateLimit = 10;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodDeductible = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodRatingBasis = "string";
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodReturnMethod = "string";
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodRate = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodUnModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.OtherCoveragesTotalPremium = 100;
            //inputPublicOfficialsCWOptionalCoverageInputModel.OtherCoverageModifiedPremium = 100;
            var inputPublicOfficialsCWOtherCoverageModelList = new List<PublicOfficialsCWOtherCoverageInputModel>();
            inputPublicOfficialsCWOtherCoverageModelList.Add(new PublicOfficialsCWOtherCoverageInputModel
            {
                OtherCoverageID = 1,
                OtherCoverageLimit = 1000,
                OtherCoverageAggregateLimit = 0,
                OtherCoverageDeductible = 0,
                OtherCoverageRate = 10,
                OtherCoverageRatingBasis = "per 1,000 of limit",
                OtherCoverageReturnMethod = "",
                OtherCoverageUnModifiedPremium = 100
            });
            model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel = inputPublicOfficialsCWOptionalCoverageInputModel;
            model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel = inputPublicOfficialsCWOtherCoverageModelList;
        }
        #endregion


        #region unti test case2

        /// <summary>
        /// Initialize Policy Header Model
        /// </summary>
        /// <param name="model"></param>
        public void InitializePolicyHeaderModel2(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "CO";
            model.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass = "County";
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = "CT";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 25000;
            model.RaterInputFacadeModel.PolicyHeaderModel.Company = "Argonaut Insurance Company";
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("2021-09-14T09:58:04.419Z");    //MM-dd-yyyy   
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NewBusiness";
            model.RaterInputFacadeModel.PolicyHeaderModel.TerrorismCoverage = false;
            // model.RaterInputFacadeModel.PolicyHeaderModel.TransactionCode = "NB";
            #endregion
            #region Pricing
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "";
            #endregion
        }

        /// <summary>
        /// Initialize Libility Premium
        /// </summary>
        /// <param name="model"></param>
        public void InitializeLibilityPremium2(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            this.InitializePolicyHeaderModel2(model);
            #endregion

            var inputPublicOfficialsCWModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW;
            inputPublicOfficialsCWModel.Exposure = 150000;
            inputPublicOfficialsCWModel.ExposureRate = 0.940M;
            inputPublicOfficialsCWModel.LiabilityLimit = 300000;
            inputPublicOfficialsCWModel.AggregateLimit = 900000;
            inputPublicOfficialsCWModel.LiabilityLimitRate = 0.790M;
            inputPublicOfficialsCWModel.DeductibleSIR = "Deductible";
            inputPublicOfficialsCWModel.Retention = "2500";

            inputPublicOfficialsCWModel.AggregateRetention = 3000;
            inputPublicOfficialsCWModel.ExperienceFactorIsSelected = true;
            inputPublicOfficialsCWModel.Type = "Each Wrongful Act";
            inputPublicOfficialsCWModel.Expense = "Excluded";

            inputPublicOfficialsCWModel.PolicyType = "Claims Made";
            inputPublicOfficialsCWModel.RetroDate = Convert.ToDateTime("10-10-2018");
            inputPublicOfficialsCWModel.IRPMApplies = true;
            inputPublicOfficialsCWModel.YearsInCMProgram = 2;
            inputPublicOfficialsCWModel.IRPMFactor = 1;
            inputPublicOfficialsCWModel.OtherModRate = 0.90M;
        }

        /// <summary>
        /// Initialize Optional Coverage Premium
        /// </summary>
        /// <param name="model"></param>
        public void InitializeOptionalCoveragePremium2(RaterFacadeModel model)
        {
            var inputPublicOfficialsCWOptionalCoverageInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseIsSelected = true;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseLimit = 50000;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseAggregateLimit = 50000;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseDeductible = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseRatingBasis = "Flat Charge";
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseReturnMethod = "Pro rata";
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseRate = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseUnModifiedPremium = 1000;
            inputPublicOfficialsCWOptionalCoverageInputModel.NonMonetaryDefenseModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationIsSelected = true;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationLimit = 100000;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationAggregateLimit = 300000;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationDeductible = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationRatingBasis = "No charge";
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationReturnMethod = "Pro rata";
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationRate = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationUnModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.InverseCondemnationModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodIsSelected = false;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodLimit = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodAggregateLimit = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodDeductible = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodRatingBasis = "string";
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodReturnMethod = "string";
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodRate = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodUnModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.SupplExtendedReportingPeriodModifiedPremium = 0;
            inputPublicOfficialsCWOptionalCoverageInputModel.OtherCoveragesTotalPremium = 0;
            var inputPublicOfficialsCWOtherCoverageModelList = new List<PublicOfficialsCWOtherCoverageInputModel>();
            inputPublicOfficialsCWOtherCoverageModelList.Add(new PublicOfficialsCWOtherCoverageInputModel
            {
                OtherCoverageID = 1,
                OtherCoverageLimit = 50000,
                OtherCoverageAggregateLimit = 100000,
                OtherCoverageDeductible = 10,
                OtherCoverageRate = 0.20M,
                OtherCoverageRatingBasis = "per 1000 of limit",
                OtherCoverageReturnMethod = "Pro rata",
                OtherCoverageUnModifiedPremium = 100,
                OtherCoverageModifiedPremium = 0
            });
            model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel = inputPublicOfficialsCWOptionalCoverageInputModel;
            model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel = inputPublicOfficialsCWOtherCoverageModelList;
        }
        #endregion
    }
}
