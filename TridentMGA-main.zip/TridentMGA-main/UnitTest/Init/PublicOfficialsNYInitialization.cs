﻿using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Input;
using Models.ApiModels.LineOfBusiness.EmploymentPractices.Output;
using Models.ApiModels.LineOfBusiness.PublicOfficials;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Input;
using Models.ApiModels.LineOfBusiness.PublicOfficials.Output;
using Models.ApiModels.Policy;
using Models.ApiModels.Pricing.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    /// <summary>
    /// Public Officials NY Initialization
    /// </summary>
    public class PublicOfficialsNYInitialization
    {
        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="raterFacadeModel"></param>
        public void Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }
            raterFacadeModel.RaterInputFacadeModel = new RaterInputFacadeModel() { LineOfBusiness = new LobIncludedModel() };
            raterFacadeModel.RaterInputFacadeModel.LineOfBusiness.PublicOfficials = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials = new PublicOfficialsInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY = new PublicOfficialsNYInputModel();

            raterFacadeModel.RaterOutputFacadeModel = new RaterOutputFacadeModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterInputFacadeModel.PricingInputModel = new PricingInputModel();
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel = new PublicOfficialsNYOptionalCoverageInputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials = new PublicOfficialsOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY = new PublicOfficialsNYOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel = new PublicOfficialsNYOptionalCoverageOutputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel = new List<PublicOfficialsNYOtherCoverageOutputModel>();
        }

        #region unti test case1
        /// <summary>
        /// Initialize Policy Header Model
        /// </summary>
        /// <param name="model"></param>
        public void InitializePolicyHeaderModel(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = "AL";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 5001;
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy   
            #endregion
            #region Pricing
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "";
            #endregion
        }

        /// <summary>
        /// Initialize Libility Premium
        /// </summary>
        /// <param name="model"></param>
        public void InitializeLibilityPremium(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            this.InitializePolicyHeaderModel(model);
            #endregion

            var inputPublicOfficialsNYModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            inputPublicOfficialsNYModel.Exposure = 100000;
            inputPublicOfficialsNYModel.ExposureRate = 3;
            inputPublicOfficialsNYModel.LiabilityLimit = 100000;
            inputPublicOfficialsNYModel.AggregateLimit = 300000;
            inputPublicOfficialsNYModel.LiabilityLimitRate = 1;
            inputPublicOfficialsNYModel.EPInclusionExclusion = "";
            inputPublicOfficialsNYModel.NYEPInclusionExclusion = true;
            inputPublicOfficialsNYModel.NYEPLimit = 100;
            inputPublicOfficialsNYModel.NYEPLimitRate = 100;
            inputPublicOfficialsNYModel.NYEPAggLimit = 100;
            inputPublicOfficialsNYModel.DeductibleSIR = "Deductible";
            inputPublicOfficialsNYModel.Retention = "500";
            inputPublicOfficialsNYModel.EPInclusionExclusion = "Excluded";

            inputPublicOfficialsNYModel.AggregateRetention = 1;
            inputPublicOfficialsNYModel.Type = "";
            inputPublicOfficialsNYModel.Expense = "";

            inputPublicOfficialsNYModel.PolicyType = "Claims Made";
            inputPublicOfficialsNYModel.RetroDate = Convert.ToDateTime("10-10-2023");
            inputPublicOfficialsNYModel.YearsInCMProgram = 1;
            inputPublicOfficialsNYModel.IRPMApplies = true;
            inputPublicOfficialsNYModel.IRPMFactor = 1;
            inputPublicOfficialsNYModel.OtherModRate = 1;
        }

        /// <summary>
        /// Initialize Optional Coverage Premium
        /// </summary>
        /// <param name="model"></param>
        public void InitializeOptionalCoveragePremium(RaterFacadeModel model)
        {
            //var inputEmploymentPracticesOptionalCoverageModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel;
            //inputEmploymentPracticesOptionalCoverageModel.BackWagesIsSelected = true;
            //inputEmploymentPracticesOptionalCoverageModel.BackWagesLimit = 10;
            //inputEmploymentPracticesOptionalCoverageModel.BackWagesAggregateLimit = 0;
            //inputEmploymentPracticesOptionalCoverageModel.BackWagesDeductible = 0;
            //inputEmploymentPracticesOptionalCoverageModel.BackWagesRatingBasis = "string";
            //inputEmploymentPracticesOptionalCoverageModel.BackWagesReturnMethod = "string";
            //inputEmploymentPracticesOptionalCoverageModel.BackWagesRate = 0;
            //inputEmploymentPracticesOptionalCoverageModel.BackWagesUnmodifiedPremium = 10;
            //inputEmploymentPracticesOptionalCoverageModel.BackWagesModifiedPremium = 0;
            //inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIsSelected = true;
            //inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseLimit = 10;
            //inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseAggregateLimit = 10;
            //inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseDeductible = 0;
            //inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRatingBasis = "string";
            //inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseReturnMethod = "string";
            //inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRate = 0;
            //inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseUnmodifedPremium = 0;
            //inputEmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseModifedPremium = 0;
            //inputEmploymentPracticesOptionalCoverageModel.EEOCIsSelected = true;
            //inputEmploymentPracticesOptionalCoverageModel.EEOCLimit = 5;
            //inputEmploymentPracticesOptionalCoverageModel.EEOCAggregateLimit = 15;
            //inputEmploymentPracticesOptionalCoverageModel.EEOCDeductible = 0;
            //inputEmploymentPracticesOptionalCoverageModel.EEOCRatingBasis = "";
            //inputEmploymentPracticesOptionalCoverageModel.EEOCRate = 0;
            //inputEmploymentPracticesOptionalCoverageModel.EEOCUnmodifedPremium = 0;
            //inputEmploymentPracticesOptionalCoverageModel.EEOCModifedPremium = 0;
            //inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateIsSelected = true;
            //inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateLimit = 10;
            //inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateLimitAggregateLimit = 10;
            //inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateLimitDeductible = 0;
            //inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateRatingBasis = "string";
            //inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateRate = 0;
            //inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateReturnMethod = "string";
            //inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateLimitUnmodifedPremium = 10;
            //inputEmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateLimitModifedPremium = 0;
            //inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected = true;
            //inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodLimit = 10;
            //inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit = 10;
            //inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodDeductible = 0;
            //inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis = "string";
            //inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod = "string";
            //inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRate = 0;
            //inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifedPremium = 0;
            //inputEmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodModifedPremium = 0;
            //var inputEmploymentPracticesOtherCoverageModelList = new List<EmploymentPracticesOtherCoverageInputModel>();
            //inputEmploymentPracticesOtherCoverageModelList.Add(new EmploymentPracticesOtherCoverageInputModel
            //{
            //    OtherCoverageId = 0,
            //    OtherCoverageLimit = 1000,
            //    OtherCoverageAggregateLimit = 0,
            //    OtherCoverageDeductible = 0,
            //    OtherCoverageRate = 10,
            //    OtherCoverageRatingBasis = "per 1,000 of limit",
            //    OtherCoverageReturnMethod = "",
            //    OtherCoverageUnmodifedPremium = 100,
            //    OtherCoverageModifedPremium = 0
            //});
            //model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = inputEmploymentPracticesOptionalCoverageModel;
            //model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel = inputEmploymentPracticesOtherCoverageModelList;
        }
        #endregion

        #region unti test case2
        /// <summary>
        /// Initialize Policy Header Model
        /// </summary>
        /// <param name="model"></param>
        public void InitializePolicyHeaderModel2(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            model.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            model.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            model.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType = "NEWBUSINESS";
            model.RaterInputFacadeModel.PolicyHeaderModel.State = "AL";
            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA = 5001;
            model.RaterInputFacadeModel.PolicyHeaderModel.LocationType = "Metro";
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy   
            #endregion
            #region Pricing
            model.RaterInputFacadeModel.PricingInputModel.TerrorismAcceptedRejected = true;
            model.RaterInputFacadeModel.PricingInputModel.TierPlan = "";
            #endregion
        }

        /// <summary>
        /// Initialize Libility Premium
        /// </summary>
        /// <param name="model"></param>
        public void InitializeLibilityPremium2(RaterFacadeModel model)
        {
            #region PolicyHeaderModel
            this.InitializePolicyHeaderModel2(model);
            #endregion

            var inputPublicOfficialsNYModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            inputPublicOfficialsNYModel.Exposure = 100000;
            inputPublicOfficialsNYModel.ExposureRate = 3;
            inputPublicOfficialsNYModel.LiabilityLimit = 100000;
            inputPublicOfficialsNYModel.AggregateLimit = 300000;
            inputPublicOfficialsNYModel.LiabilityLimitRate = 1;
            inputPublicOfficialsNYModel.EPInclusionExclusion = "";
            inputPublicOfficialsNYModel.NYEPInclusionExclusion = true;
            inputPublicOfficialsNYModel.NYEPLimit = 100;
            inputPublicOfficialsNYModel.NYEPLimitRate = 100;
            inputPublicOfficialsNYModel.NYEPAggLimit = 100;
            inputPublicOfficialsNYModel.DeductibleSIR = "Deductible";
            inputPublicOfficialsNYModel.Retention = "500";
            inputPublicOfficialsNYModel.EPInclusionExclusion = "Excluded";

            inputPublicOfficialsNYModel.AggregateRetention = 1;
            inputPublicOfficialsNYModel.Type = "";
            inputPublicOfficialsNYModel.Expense = "";

            inputPublicOfficialsNYModel.PolicyType = "Claims Made";
            inputPublicOfficialsNYModel.RetroDate = Convert.ToDateTime("10-10-2023");
            inputPublicOfficialsNYModel.YearsInCMProgram = 1;
            inputPublicOfficialsNYModel.IRPMApplies = true;
            inputPublicOfficialsNYModel.IRPMFactor = 1;
            inputPublicOfficialsNYModel.OtherModRate = 1;
        }

        /// <summary>
        /// Initialize Optional Coverage Premium
        /// </summary>
        /// <param name="model"></param>
        public void InitializeOptionalCoveragePremium2(RaterFacadeModel model)
        {
            var inputPOOptionalCoverageModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel;
            inputPOOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected = true;
            inputPOOptionalCoverageModel.SupplExtendedReportingPeriodLimit = 10;
            inputPOOptionalCoverageModel.SupplExtendedReportingPeriodAggregateLimit = 10;
            inputPOOptionalCoverageModel.SupplExtendedReportingPeriodDeductible = 0;
            inputPOOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis = "string";
            inputPOOptionalCoverageModel.SupplExtendedReportingPeriodReturnMethod = "string";
            inputPOOptionalCoverageModel.SupplExtendedReportingPeriodRate = 0;
            inputPOOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium = 0;
            inputPOOptionalCoverageModel.SupplExtendedReportingPeriodModifiedPremium = 0;
            var inputEmploymentPracticesOtherCoverageModelList = new List<EmploymentPracticesOtherCoverageInputModel>();
            //inputEmploymentPracticesOtherCoverageModelList.Add(new EmploymentPracticesOtherCoverageInputModel
            //{
            //    OtherCoverageId = 0,
            //    OtherCoverageLimit = 1000,
            //    OtherCoverageAggregateLimit = 0,
            //    OtherCoverageDeductible = 0,
            //    OtherCoverageRate = 10,
            //    OtherCoverageRatingBasis = "per 1,000 of limit",
            //    OtherCoverageReturnMethod = "",
            //    OtherCoverageUnmodifedPremium = 100,
            //    OtherCoverageModifedPremium = 0
            //});
            //model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel = inputEmploymentPracticesOptionalCoverageModel;
            //model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EmploymentPracticesOtherCoverageModel = inputEmploymentPracticesOtherCoverageModelList;
        }
        #endregion
    }
}
