﻿using Models;
using Models.ApiModels;
using Models.ApiModels.LineOfBusiness.Property.Input;
using Models.ApiModels.Policy;
using System;
using System.Collections.Generic;
using System.Text;

namespace UnitTest.Init
{
    public class RaterFacadePropertyGeneralModelInitialization
    {
        public RaterFacadeModel Initialize(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel = new LineOfBusinessInputModel();
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel = new LineOfBusinessOutputModel();
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel = new PolicyHeaderModel();
            raterFacadeModel.RaterOutputFacadeModel.PremiumSummaryModel = new PremiumSummaryModel();
            raterFacadeModel.RaterOutputFacadeModel.ResponseModel = new ResponseInfoModel();

            return raterFacadeModel;
        }

        public RaterFacadeModel GetFacadeForCase1(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }

            #region BuildingBPP Initialization


            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.AL;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass = "1";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy   

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV = 1000000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV = 500000;
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingDefTotalPoints = 6000;   // Changed
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsDefTotalPoints = 6300;   // Changed
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible = 5000;      // Changed
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SumNetNormalLossClaims = 20000;

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Coinsurance = "1.00";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.MarginClause = "1.20";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Valuation = "RC";

            #endregion

            #region EquipmentBreakdown Initialization

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit = 50000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM = 100;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownDeductible = 5000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseDeductible = 240;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PollutantCleanUpLimit = 250000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.RefrigerantContaminationLimit = 250000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType = "Type1";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EBSpoilageLimit = 1000000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageDeductible = 0.1M; // "10%";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageMinimumDeductible = 1000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage = false;
            //raterFacadeModel.InputModel.Property.EquipmentBreakdownLimit = 1;

            if (raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
            {
                raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownRate = 0;
                raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InputEquipmentBreakdownTotalPremium = 5000;
            }

            #endregion

            #region WindFloodEarthquake Initialization

            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindBuildingPoints = 1500;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodBuildingPoints = 200;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeBuildingPoints = 300;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindContentsPoints = 1700;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodContentsPoint = 300;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeContentsPoints = 100;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage = true;

            #endregion

            #region OptionalCoverage Initialization

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = true;
            inputOptionalCoverage.AdditionalCoveredPropertyDescription = "Additional Covered";
            inputOptionalCoverage.AdditionalCoveredPropertyLimit = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyDeductible = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyRatingBasis = "Flat charge";
            inputOptionalCoverage.AdditionalCoveredPropertyRate = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyReturnMethod = "Pro Rata";
            inputOptionalCoverage.AdditionalCoveredPropertyPremium = 50;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 1,
                Deductible = 0,
                RatingBasis = "Flat charge",
                Rate = 0,
                ReturnMethod = "Pro Rata",
                Premium = 500,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 1, 
                Deductible = 1000, 
                RatingBasis = "PER 1000 OF LIMIT",
                Rate = 0.06M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                 Description = "OTHER",
                 Limit = 20000,
                 Deductible = 500,
                 RatingBasis = "PER 100 OF LIMIT",
                 Rate = 0.05M,
                 ReturnMethod = "Pro Rata",
                Premium = 0,
            });
                        
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region FinalPremium Initialization

            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BusinessIncomeAndExtraExpense360CoveragePremium = 1276;
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360TotalPremiums = 14827;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LargeRiskFactor = 0.05M;

            #endregion

            return raterFacadeModel;
        }

        public RaterFacadeModel GetFacadeForCase2(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }

            #region BuildingBPP Initialization

            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.AL;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass = "1";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV = 1000000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV = 500000;
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingDefTotalPoints = 6400; // Changed
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsDefTotalPoints = 6700; // Changed
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible = 7500; // Changed
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SumNetNormalLossClaims = 20000;

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Coinsurance = "1.00";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.MarginClause = "1.20";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Valuation = "RC";

            #endregion

            #region EquipmentBreakdown Initialization

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit = 50000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM = 100;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownDeductible = 5000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseDeductible = 240;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PollutantCleanUpLimit = 250000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.RefrigerantContaminationLimit = 250000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType = "Type1";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EBSpoilageLimit = 1000000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageDeductible = 0.1M; // "10%";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageMinimumDeductible = 1000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage = false;
            //raterFacadeModel.InputModel.Property.EquipmentBreakdownLimit = 1;

            if (raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
            {
                raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownRate = 0;
                raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InputEquipmentBreakdownTotalPremium = 5000;
            }

            #endregion

            #region WindFloodEarthquake Initialization

            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindBuildingPoints = 1500;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodBuildingPoints = 200;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeBuildingPoints = 300;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindContentsPoints = 1700;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodContentsPoint = 300;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeContentsPoints = 100;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage = true;

            #endregion
                        
            #region OptionalCoverage Initialization

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = true;
            inputOptionalCoverage.AdditionalCoveredPropertyDescription = "Additional Covered";
            inputOptionalCoverage.AdditionalCoveredPropertyLimit = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyDeductible = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyRatingBasis = "Flat charge";
            inputOptionalCoverage.AdditionalCoveredPropertyRate = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyReturnMethod = "Pro Rata";
            inputOptionalCoverage.AdditionalCoveredPropertyPremium = 50;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 1,
                Deductible = 0,
                RatingBasis = "Flat charge",
                Rate = 0,
                ReturnMethod = "Pro Rata",
                Premium = 500,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 1,
                Deductible = 1000,
                RatingBasis = "PER 1000 OF LIMIT",
                Rate = 0.06M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 20000,
                Deductible = 500,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.05M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region FinalPremium Initialization

            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360TotalPremiums = 19232;
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BusinessIncomeAndExtraExpense360CoveragePremium = 1786;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LargeRiskFactor = 0.05M;

            #endregion

            return raterFacadeModel;
        }

        public RaterFacadeModel InitializeCase3(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }

            #region BuildingBPP Initialization

            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.AL;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass = "1";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV = 2000000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV = 1000000;
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingDefTotalPoints = 6400;  // Same as Case2
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsDefTotalPoints = 6700;  // Same as Case2
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible = 10000;   // Changed
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SumNetNormalLossClaims = 20000;

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Coinsurance = "1.00";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.MarginClause = "1.20";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Valuation = "RC";

            #endregion

            #region EquipmentBreakdown Initialization

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit = 50000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM = 100;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownDeductible = 5000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseDeductible = 240;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PollutantCleanUpLimit = 250000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.RefrigerantContaminationLimit = 250000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType = "Type1";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EBSpoilageLimit = 1000000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageDeductible = 0.1M; // "10%";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageMinimumDeductible = 1000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage = false;
            //raterFacadeModel.InputModel.Property.EquipmentBreakdownLimit = 1;

            if (raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
            {
                raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownRate = 0;
                raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InputEquipmentBreakdownTotalPremium = 5000;
            }

            #endregion

            #region WindFloodEarthquake Initialization

            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindBuildingPoints = 1500;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodBuildingPoints = 200;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeBuildingPoints = 300;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindContentsPoints = 1700;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodContentsPoint = 300;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeContentsPoints = 100;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage = true;

            #endregion

            #region OptionalCoverage Initialization

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = true;
            inputOptionalCoverage.AdditionalCoveredPropertyDescription = "Additional Covered";
            inputOptionalCoverage.AdditionalCoveredPropertyLimit = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyDeductible = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyRatingBasis = "Flat charge";
            inputOptionalCoverage.AdditionalCoveredPropertyRate = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyReturnMethod = "Pro Rata";
            inputOptionalCoverage.AdditionalCoveredPropertyPremium = 50;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 1,
                Deductible = 0,
                RatingBasis = "Flat charge",
                Rate = 0,
                ReturnMethod = "Pro Rata",
                Premium = 500,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 1,
                Deductible = 1000,
                RatingBasis = "PER 1000 OF LIMIT",
                Rate = 0.06M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 20000,
                Deductible = 500,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.05M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region FinalPremium Initialization

            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360TotalPremiums = 19535;
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BusinessIncomeAndExtraExpense360CoveragePremium = 1765;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LargeRiskFactor = 0.05M;

            #endregion

            return raterFacadeModel;
        }

        public RaterFacadeModel InitializeCase4(RaterFacadeModel raterFacadeModel)
        {
            if (raterFacadeModel == null)
            {
                raterFacadeModel = new RaterFacadeModel();
            }

            #region BuildingBPP Initialization


            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.Id = 1;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.ClientId = "Paragon";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.QuoteId = 3;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.State = StateCodeConstant.AL;
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass = "MU";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass = "1";
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate = Convert.ToDateTime("10-10-2021"); //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate = Convert.ToDateTime("10-10-2022");       //MM-dd-yyyy
            raterFacadeModel.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate = Convert.ToDateTime("10-10-2021");    //MM-dd-yyyy

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV = 1000000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV = 500000;
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingDefTotalPoints = 6000;
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsDefTotalPoints = 6300;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible = 5000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SumNetNormalLossClaims = 20000;

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Coinsurance = "1.00";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.MarginClause = "1.20";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Valuation = "RC";

            #endregion

            #region EquipmentBreakdown Initialization

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit = 50000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM = 100;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownDeductible = 5000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseDeductible = 240;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PollutantCleanUpLimit = 250000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.RefrigerantContaminationLimit = 250000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType = "Type1";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EBSpoilageLimit = 1000000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageDeductible = 0.1M; // "10%";
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageMinimumDeductible = 1000;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage = false;
            //raterFacadeModel.InputModel.Property.EquipmentBreakdownLimit = 1;

            if (raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
            {
                raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownRate = 0;
                raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InputEquipmentBreakdownTotalPremium = 5000;
            }

            #endregion

            #region WindFloodEarthquake Initialization

            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindBuildingPoints = 1500;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodBuildingPoints = 200;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeBuildingPoints = 300;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindContentsPoints = 1700;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodContentsPoint = 300;
            //raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeContentsPoints = 100;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage = true;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage = true;

            #endregion

            #region OptionalCoverage Initialization

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = new PropertyOptionalCoverageInputModel();

            var inputOptionalCoverage = raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel;

            inputOptionalCoverage.IsAdditionalCoveredPropertyOptionalCoverageSelected = true;
            inputOptionalCoverage.AdditionalCoveredPropertyDescription = "Additional Covered";
            inputOptionalCoverage.AdditionalCoveredPropertyLimit = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyDeductible = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyRatingBasis = "Flat charge";
            inputOptionalCoverage.AdditionalCoveredPropertyRate = 0;
            inputOptionalCoverage.AdditionalCoveredPropertyReturnMethod = "Pro Rata";
            inputOptionalCoverage.AdditionalCoveredPropertyPremium = 50;

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel = new List<PropertyOptionalOtherCoverageInputModel>();

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 1,
                Deductible = 0,
                RatingBasis = "Flat charge",
                Rate = 0,
                ReturnMethod = "Pro Rata",
                Premium = 500,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 1,
                Deductible = 1000,
                RatingBasis = "PER 1000 OF LIMIT",
                Rate = 0.06M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            inputOptionalCoverage.PropertyOptionalOthersCoverageInputModel.Add(new PropertyOptionalOtherCoverageInputModel
            {
                Description = "OTHER",
                Limit = 20000,
                Deductible = 500,
                RatingBasis = "PER 100 OF LIMIT",
                Rate = 0.05M,
                ReturnMethod = "Pro Rata",
                Premium = 0,
            });

            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel = inputOptionalCoverage;

            #endregion

            #region FinalPremium Initialization

            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BusinessIncomeAndExtraExpense360CoveragePremium = 1276;
            raterFacadeModel.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360TotalPremiums = 14827;
            raterFacadeModel.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LargeRiskFactor = 0.05M;

            #endregion

            return raterFacadeModel;
        }
    }
}
