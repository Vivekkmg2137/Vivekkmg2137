﻿using Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.IO;
using UnitTest.Init;
using RaterLawEnforcement;

namespace UnitTest
{
    [TestClass()]
    public class LawServiceTests
    {
        private ILoggingManager _Logger { get; set; }
        private IConfiguration _Configuration { get; set; }

        private ILawEnforcementService _lawService;

        private RaterFacadeModel _model;

        private LawInitialization _lawInitialization;

        [TestInitialize()]
        public void Initialize()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this._Configuration = builder.Build();

            var sqlCOnnectionString = _Configuration["ConnectionStrings:SqlDBConnection"];

            this._Logger = new Logging.LoggingManager();

            this._lawService = new LawEnforcementService(this._Configuration, this._Logger);
        }

        public LawServiceTests()
        {
            #region Calculate premium
            this._model = new RaterFacadeModel();
            this._lawInitialization = new LawInitialization();

            _lawInitialization.Initialize(this._model);
            #endregion
        }

        #region Test Case Law Enforcement Premium for CT State 

        [TestMethod]
        public void CalculatePremiumTest1()
        {
            _lawInitialization.InitializationCase1(this._model);

            // Since input pre validation are success, calculate premium
            _lawService.Calculate(this._model);

            CalculateInitialRatesTest1(this._model);

            CalculateUnmannedAircraftPremiumTest1(this._model);

            CalculateOptionalCoveragesPremiumsTest1(this._model);

            CalculateBasePremiumsTest1(this._model);

            CalculateManualPremiumTest1(this._model);

            CalculateTierPremiumTest1(this._model);

            CalculateIRPMPremiumTest1(this._model);

            CalculateOtherModPremiumTest1(this._model);

            CalculateTerrorismPremiumTest1(this._model);

            CalculateFinalPremiumTest1(this._model);
        }

        #region Calculate Initial Rates

        public void CalculateInitialRatesTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.ExposureRate, 894.000M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LiabilityLimitRate, 0.870M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.AggregateLimitRate, 1.015M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.RetentionRate, 0.960M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.PopulationRate, 1.000M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LocationRate, 1.000M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.PolicyTypeRate, 0.800M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.YearsInCMRate, 0.850M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.RetroDateRate, 1.1200M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LossExperienceRate, 1.500M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.TerrorismRate, 0);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.TierRate, 1.150M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.IRPMRate, 1.15M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.OtherModRate, 1.00M);

        }

        #endregion

        #region Calculate Unmanned Aircraft Premium
        
        public void CalculateUnmannedAircraftPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.UnmannedAircraftModifiedTotalPremium, 4384M);
        }

        #endregion

        #region Optional Coverages Premium

        public void CalculateOptionalCoveragesPremiumsTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium, 20);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0); 
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.NYSupplExtendedReportingPeriodUnmodifiedPremium, 0); 
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium, 0); 
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.LineOfDutyDeathBenefitsUnmodifiedPremium, 500);
           // Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.OtherCoverageUnmodifiedPremium, 180);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.NonModifiedPremium, 700);
        }

        #endregion

        #region Calculate Base Premium

        public void CalculateBasePremiumsTest1(RaterFacadeModel model)
        {
           Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.BasePremium, 86579);
        }

        #endregion

        #region Calculate Manual Premium

        public void CalculateManualPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.ManualPremium, 90594);
        }

        #endregion

        #region Calculate Tier Premium

        public void CalculateTierPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.TierPremium, 104078);
        }

        #endregion

        #region Calculate IRPM Premium

        public void CalculateIRPMPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.IRPMPremium, 119585);
        }

        #endregion

        #region Calculate OtherMod Premium

        public void CalculateOtherModPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.OtherModPremium, 119585);
        }

        #endregion

        #region Calculate Terrorism Premium

        public void CalculateTerrorismPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.TerrorismPremium, 0);
        }

        #endregion

        #region Calculate FinalPremium

        public void CalculateFinalPremiumTest1(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawFinalModifiedPremium, 119585);
        }

        #endregion

        #endregion

        #region Test Case Law Enforcement Premium for NY State 

        [TestMethod]
        public void CalculatePremiumTest2()
        {

            _lawInitialization.InitializationCase2(this._model);

            // Since input pre validation are success, calculate premium
            _lawService.Calculate(this._model);

            CalculateInitialRatesTest2(this._model);

            CalculateUnmannedAircraftPremiumTest2(this._model);

            CalculateOptionalCoveragesPremiumsTest2(this._model);

            CalculateBasePremiumsTest2(this._model);

            CalculateManualPremiumTest2(this._model);

            CalculateTierPremiumTest2(this._model);

            CalculateIRPMPremiumTest2(this._model);

            CalculateOtherModPremiumTest2(this._model);

            CalculateTerrorismPremiumTest2(this._model);

            CalculateFinalPremiumTest2(this._model);
        }

        #region Calculate Initial Rates

        public void CalculateInitialRatesTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.ExposureRate, 920.000M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LiabilityLimitRate, 0.660M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.AggregateLimitRate, 1.025M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.RetentionRate, 1.000M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.PopulationRate, 1.250M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LocationRate, 1.100M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.PolicyTypeRate, 1.000M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.YearsInCMRate, 1.000M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.RetroDateRate, 0.9600M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LossExperienceRate, 1.000M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.TerrorismRate, 0);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.TierRate, 1.000M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.IRPMRate, 1.00M);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.OtherModRate, 0.90M);
        }

        #endregion

        #region Calculate Unmanned Aircraft Premium

        public void CalculateUnmannedAircraftPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.UnmannedAircraftModifiedTotalPremium, 2869);  //3251M
        }

        #endregion

        #region Optional Coverages Premium

        public void CalculateOptionalCoveragesPremiumsTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium, 0);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.SupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.NYSupplExtendedReportingPeriodUnmodifiedPremium, 0);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.NonMonetaryDefenseUnmodifiedPremium, 0);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.LineOfDutyDeathBenefitsUnmodifiedPremium, 0);
            //Assert.AreEqual(this.model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.ot.OtherCoverageUnmodifiedPremium, 280);
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.NonModifiedPremium, 280);
        }

        #endregion

        #region Calculate Base Premium

        public void CalculateBasePremiumsTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.BasePremium, 246462);
        }

        #endregion

        #region Calculate Manual Premium

        public void CalculateManualPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.ManualPremium, 249930);  //250354
        }

        #endregion

        #region Calculate Tier Premium

        public void CalculateTierPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.TierPremium, 249930); //250354
        }

        #endregion

        #region Calculate IRPM Premium

        public void CalculateIRPMPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.IRPMPremium, 249930); //250354
        }

        #endregion

        #region Calculate OtherMod Premium

        public void CalculateOtherModPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.OtherModPremium, 224965);  //225347
        }

        #endregion

        #region Calculate Terrorism Premium

        public void CalculateTerrorismPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.TerrorismPremium, 0);
        }

        #endregion

        #region Calculate FinalPremium

        public void CalculateFinalPremiumTest2(RaterFacadeModel model)
        {
            Assert.AreEqual(this._model.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.LawFinalModifiedPremium, 224965);  //225347
        }

        #endregion

        #endregion

        [TestCleanup()]
        public void Cleanup() { }
    }
}
