﻿using Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models.ApiModels;
using RaterOCP;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.IO;
using UnitTest.Init;

namespace UnitTest
{
    [TestClass()]
    public class OCPServiceTest
    {
        private IOcpService service;
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }

        [TestInitialize()]
        public void Initialize()
        {
            this.logger = new Logging.LoggingManager();
            var builder = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
               .AddEnvironmentVariables();

            this.configuration = builder.Build();
            this.service = new OCPCwService(this.configuration, this.logger);
        }

        [TestMethod()]
        public void CalculateOCPPremiumTest()
        {
            RaterFacadeModel model = new RaterFacadeModel();
            OcpInitialization ocpInitialization = new OcpInitialization();

            ocpInitialization.Initialize(model);
            ocpInitialization.InitializeOCPCase1(model);

            #region Prevalidate
            var preValidateResults = service.PreValidate(model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion

            #region Calculate premium
            // Since input pre validation are success, calculate premium
            service.Calculate(model);
            #endregion

            #region Post validate
            var postValidateResults = service.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1.BasePremium, 200);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1.ManualPremium, 200);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1.OCPFinalPremium, 200);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1.TierPremium, 200);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1.IRPMPremium, 200);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1.OtherModPremium, 200);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1.TerrorismPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1.NonModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Ocp1.OCPFinalPremium, 200);
        }        

        [TestCleanup()]
        public void Cleanup() { }
    }
}
