﻿using Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;
using System;
using System.Collections.Generic;
using System.Text;
using RaterProperty;
using Models.ApiModels;
using Microsoft.Extensions.Configuration;
using System.IO;
using UnitTest.Init;

namespace UnitTest
{
    [TestClass()]
    public class PropertyNYServiceTest
    {
        private IPropertyService service;
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }

        [TestInitialize()]
        public void Initialize()
        {

            var builder = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
               .AddEnvironmentVariables();

            this.configuration = builder.Build();


            var sqlConnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();
            this.service = new PropertyNyService(this.configuration, this.logger);
        }
        
        [TestMethod]
        public void CalculatePremiumTest_Case1()
        {
            RaterFacadeModel model = new RaterFacadeModel();
            PropertyNewYorkInitialization initialization = new PropertyNewYorkInitialization();
            initialization.Initialize(model);
            initialization.InitializeCase1(model);

            PropertyNewYork360Initialization initialization360 = new PropertyNewYork360Initialization();
            initialization360.Initialize(model);
            initialization360.InitializeNewYork360PropertyCase1(model);

            #region Prevalidate
            var preValidateResults = service.PreValidate(model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion

            #region Calculate premium
            // Since input pre validation are success, calculate premium
            service.Calculate(model);
            #endregion

            #region Post validate
            var postValidateResults = service.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion

            #region Step 1 Total Building Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkTotalBuildingPremium, 2474);
            #endregion

            #region Property NY 360 Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.AccountReceivablePremium, -12M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.BuildingOrdinanceORLawDemolitionCostCoveragePremium, 120M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.BuildingOrdinanceORLawIncreasedCostOfContructionPremium, 60M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.ChangesInTemperatureORHumidityPremium, 5M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.CommandeeredPropertyPremium, 40M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.CommunicationEquipmentPremium, 50M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.ComputerEquipmentPremium, 75M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.DetachedSignsPremium, 0M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.ElectricalDamagePremium, 2M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkProperty360TotalPremiums, 475M);

            #endregion

            #region Step 2 Equipment Breakdown Premium
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownRate, 0.0375M);
            }
            else
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium, 80);
            }
            #endregion

            #region Step 3 Wind Flood Earthquake Premium
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium, 181);
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium, 60);
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium, 10);
            }
            #endregion

            #region Step 4 Optional Coverage Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OptionalCoverageTotalPremium, 11303);
            #endregion

            #region Step 5 Final Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BasePremium, 2875);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, 11303);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium, 14653);//1428
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium, 14653);//1428
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium, 14653);//1592
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium, 15357);//1856
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TerrorismPremium, 461);//56
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium, 15818);//1912
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkFireInsuranceFeeCharge, 44.60M);//14.19M
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkUWPremiumFireExposure, 3568.29M);//1135.46M
            #endregion
        }

        [TestMethod]
        public void CalculatePremiumTest_Case2()
        {
            RaterFacadeModel model = new RaterFacadeModel();
            PropertyNewYorkInitialization initialization = new PropertyNewYorkInitialization();
            initialization.Initialize(model);
            initialization.InitializeCase2(model);

            PropertyNewYork360Initialization initialization360 = new PropertyNewYork360Initialization();
            initialization360.Initialize(model);
            initialization360.InitializeNewYork360PropertyCase1(model);

            #region Prevalidate
            var preValidateResults = service.PreValidate(model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion

            #region Calculate premium
            // Since input pre validation are success, calculate premium
            service.Calculate(model);
            #endregion

            #region Post validate
            var postValidateResults = service.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion

            #region Step 1 Building BPP Premium
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ScheduleRatingInputModels != null)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkTotalBuildingPremium, 2474); // Result case-I=16
            }
            else
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkTotalBuildingPremium, 0);
            }
            #endregion

            #region Property NY 360
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.AccountReceivablePremium, -12M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.BuildingOrdinanceORLawDemolitionCostCoveragePremium, 120M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.BuildingOrdinanceORLawIncreasedCostOfContructionPremium, 60M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.ChangesInTemperatureORHumidityPremium, 5M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.CommandeeredPropertyPremium, 40M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkProperty360TotalPremiums, 475M);
            #endregion

            #region Step 2 Equipment Breakdown Premium

            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownRate, 0.038M);
            }
            else
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium, 80);
            }

            #endregion

            #region Step 3 Wind Flood Earthquake Premium
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium, 181);
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium, 60);
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium, 10);
            }
            #endregion

            #region Step 4 Optional Coverage Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OptionalCoverageTotalPremium, 11303);
            #endregion

            #region Step 5 Final Premium

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BasePremium, 2805);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, 11303);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium, 14583);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium, 14583);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium, 14583);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium, 15272);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TerrorismPremium, 458);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium, 15730);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkFireInsuranceFeeCharge, 44.60M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkUWPremiumFireExposure, 3568.29M);
            #endregion
        }

        [TestCleanup()]
        public void Cleanup() { }
    }
}
