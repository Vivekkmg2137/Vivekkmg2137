﻿namespace UnitTest
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.ApiModels;
    using RaterProperty;
    using System.Configuration;
    using Microsoft.Extensions.Configuration;
    using System.IO;
    using UnitTest.Init;

    /// <summary>
    /// PropertyServiceTests : Unit test class for testing property calculation.
    /// </summary>
    [TestClass]
    public class PropertyServiceTests
    {
        private IPropertyService service;

        /// <summary>
        /// Gets logger.
        /// </summary>
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }
        /// <summary>
        /// Initialize : It will Initialize Logger and Property service object.
        /// </summary>
        [TestInitialize]
        public void Initialize()
        {
            //Watch the variable to know the path and name of config file
            //ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).FilePath;
            //In our case , the path is:
            //D:\WorkSpaces\CodeSpaces\KMG\MGA\UnitTest\bin\Debug\netcoreapp3.1\testhost.dll.config

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();


            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();
            this.service = new PropertyCwService(this.configuration, this.logger);

        }

        /// <summary>
        /// CalculatePremiumTest_Case1
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest_Case1()
        {
            RaterFacadeModel model = new RaterFacadeModel();

            PropertyCWInitialization initializer = new PropertyCWInitialization();
            initializer.Initialize(model);
            initializer.InitializeTestCase1(model);

            Property360Initialization property360Initializer = new Property360Initialization();
            property360Initializer.Initialize(model);
            property360Initializer.GetFacadeForCase1(model.RaterInputFacadeModel.LineOfBusinessInputModel.Property);

            #region Prevalidate
            var preValidateResults = service.PreValidate(model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion

            #region Calculate premium
            // Since input pre validation are success, calculate premium
            service.Calculate(model);
            #endregion

            #region Post validate
            var postValidateResults = service.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion

            #region Step 1 Building BPP Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium, 37880);//38435
            #endregion

            #region Property 360 Coverage premium  

            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel != null)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BusinessIncomeAndExtraExpense360CoveragePremium, 4498);//4562

                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360ModificationCoverageTotalPremium, 32762); //33240 // 10620

                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360GolfCourceTotalPremium, 2638);

                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OptionalCoverageTotalPremium, 5567);//5648

                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360TotalPremiums, 40967);  //41526//14837
            }

            #endregion

            #region Step 2 Equipment Breakdown Premium
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownRate, 0.0063M);
            }
            else
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium, 98);
            }
            #endregion

            #region Step 3 Wind Flood Earthquake premium

            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium, 1673);
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium, 5576);
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium, 5576);
            }

            #endregion

            #region Step 4 Optional premium            
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OptionalCoverageTotalPremium, -98697);//560
            #endregion

            #region Step 5 Final premium

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BasePremium, 37978);//38533
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, -98697);//560
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium, 100);  //2060
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium, 100);//2060
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium, 100);//2060
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium, 100);//2060
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TerrorismPremium, 3);//62
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium, 103);//2122

            #endregion
        }

        /// <summary>
        /// CalculatePremiumTest_Case2
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest_Case2()
        {
            RaterFacadeModel model = new RaterFacadeModel();

            PropertyCWInitialization initializer = new PropertyCWInitialization();
            initializer.Initialize(model);
            initializer.InitializeTestCase2(model);

            Property360Initialization property360Initializer = new Property360Initialization();
            property360Initializer.Initialize(model);
            property360Initializer.GetFacadeForCase1(model.RaterInputFacadeModel.LineOfBusinessInputModel.Property);

            #region Prevalidate
            var preValidateResults = service.PreValidate(model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion

            #region Calculate premium
            // Since input pre validation are success, calculate premium
            service.Calculate(model);
            #endregion

            #region Post validate
            var postValidateResults = service.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion

            #region Step 1 Building BPP Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium, 37880);//38435
            #endregion

            #region Property 360 Coverage Premium  
           
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BusinessIncomeAndExtraExpense360CoveragePremium, 4498);// 4562

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360ModificationCoverageTotalPremium, 32762); //33240 // 10621

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360GolfCourceTotalPremium, 2638);

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OptionalCoverageTotalPremium, 5567);// 5648

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360TotalPremiums, 40967);//41526

            #endregion

            #region Step 2 Equipment Breakdown Premium
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownRate, 0.0087M);
            }
            else
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium, 98);
            }

            #endregion

            #region Step 3 Wind Flood Earthquake Premium

            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium, 1673);
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium, 5576);
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium, 5576);
            }

            #endregion

            #region Step 4 Optional Coverage Premium            
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OptionalCoverageTotalPremium, -99822);
            #endregion

            #region Step 5 Final Premium

            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BasePremium, 37978);// 38533
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, -99822);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium, 100);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium, 100);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium, 100);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium, 100);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TerrorismPremium, 3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium, 103);

            #endregion
        }

        /// <summary>
        /// CalculatePremiumTest_Case3
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest_Case3()
        {
            RaterFacadeModel model = new RaterFacadeModel();
            PropertyCWInitialization initializer = new PropertyCWInitialization();
            initializer.Initialize(model);
            initializer.InitializeTestCase3(model);

            #region Prevalidate
            var preValidateResults = service.PreValidate(model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion

            #region Calculate premium
            // Since input pre validation are success, calculate premium
            service.Calculate(model);
            #endregion

            #region Post validate
            var postValidateResults = service.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion

            #region Step 1 Building BPP Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium, 1210);//1420
            #endregion
            
            #region Step 2 Equipment Breakdown Premium
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownRate, 2222);
            }
            else
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium, 194);
            }
            #endregion

            #region Step 3 Wind Flood Earthquake Premium

            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium, 234);//360
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium, 78);//120
            }
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == true)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium, 78);//120
            }

            #endregion
            #region Step 4 Calculate Optional Coverage Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OptionalCoverageTotalPremium, -98697);
            #endregion
            

            #region Step 5 Calculate Final Premium
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BasePremium, 1404);//1614
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, -98697);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium, 100); 
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium, 100);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium, 100);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium, 100);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TerrorismPremium, 3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium, 103);

            #endregion
        }

        [TestCleanup]
        public void Cleanup()
        {
        }
    }
}