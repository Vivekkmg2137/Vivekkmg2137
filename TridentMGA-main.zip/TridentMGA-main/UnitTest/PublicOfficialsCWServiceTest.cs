﻿namespace UnitTest
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.ApiModels;
    using RaterProperty;
    using System.Configuration;
    using Microsoft.Extensions.Configuration;
    using System.IO;
    using UnitTest.Init;
    using RaterEmploymentPractices;
    using RaterPublicOfficials;

    [TestClass]
    public class PublicOfficialsCWServiceTest
    {
        /// <summary>
        /// Logger Object
        /// </summary>
        private ILoggingManager logger { get; set; }

        /// <summary>
        /// Configuration Object
        /// </summary>
        private IConfiguration configuration { get; set; }

        /// <summary>
        /// PublicOfficialsCWService Object
        /// </summary>
        private IPublicOfficialsCWService service;

        /// <summary>
        /// RaterFacadeModel Object
        /// </summary>
        private RaterFacadeModel model;

        /// <summary>
        /// PublicOfficialsCWInitialization Object
        /// </summary>
        private PublicOfficialsCWInitialization poInitialization;

        /// <summary>
        /// Initialize : It will Initialize Logger and Property service object.
        /// </summary>
        [TestInitialize]
        public void Initialize()
        {
            //Watch the variable to know the path and name of config file
            //ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).FilePath;
            //In our case , the path is:
            //D:\WorkSpaces\CodeSpaces\KMG\MGA\UnitTest\bin\Debug\netcoreapp3.1\testhost.dll.config

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();

            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();
            this.service = new PublicOfficialsCWService(this.configuration, this.logger);
        }

        /// <summary>
        /// POCWServiceTestInitilize
        /// </summary>
        private void POCWServiceTestInitilize()
        {
            this.model = new RaterFacadeModel();
            this.poInitialization = new PublicOfficialsCWInitialization();
            this.poInitialization.Initialize(this.model);
        }

        #region Test Case 1
        /// <summary>
        /// CalculateLibilityPremiumTest1
        /// </summary>
        private void CalculateLibilityPremiumTest1()
        {
            this.POCWServiceTestInitilize();
            this.poInitialization.InitializeLibilityPremium(this.model);
            this.poInitialization.InitializeOptionalCoveragePremium(this.model);

            #region Prevalidate
            var preValidateResults = service.PreValidate(this.model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest1
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest1()
        {
            this.CalculateLibilityPremiumTest1();

            #region Calculate premium
            this.service.Calculate(this.model);
            #endregion

            this.CalculateLibilityLimitPremiumTest1();

            #region Calculate Optional and Other premium

            this.CalculateOptionalCoverageAssertTest1();

            #endregion

            this.CalculateOptionalOtherCoverageAssertTest1();
        }

        /// <summary>
        /// CalculateLibilityLimitPremiumTest1
        /// </summary>
        private void CalculateLibilityLimitPremiumTest1()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.RatingBasisParameter, 1000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.RetroYear, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.ExposureRate, 3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.LiabilityLimitRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.AggregateLimitRate, Convert.ToDecimal(1.025));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.EPInclusionExclusionRate, Convert.ToDecimal(0.3));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.RetentionRate, Convert.ToDecimal(1.05));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PolicyTypeRate, Convert.ToDecimal(0.800));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.RetroDateRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.YearsInCMRate, Convert.ToDecimal(0.850));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.BasePremium, 82);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.NonModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.ManualPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.IRPMFactor, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.IRPMPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TerrorismRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TerrorismPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.OtherModRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.OtherModPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TierRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TierPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.POModifiedFinalPremium, 250);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalCoverageAssertTest1()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseLimit, 10);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseAggregateLimit, 10);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseUnModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodLimit, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium, 0);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest1()
        {
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageDeductible, 0);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageLimit, 1000);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageRate, 10);
            }
        }
        #endregion

        #region Test Case 2
        /// <summary>
        /// CalculateLibilityPremiumTest2
        /// </summary>
        private void CalculateLibilityPremiumTest2()
        {
            this.POCWServiceTestInitilize();
            this.poInitialization.InitializeLibilityPremium2(this.model);
            this.poInitialization.InitializeOptionalCoveragePremium2(this.model);
            #region Prevalidate
            var preValidateResults = service.PreValidate(this.model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest2
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest2()
        {
            this.CalculateLibilityPremiumTest2();

            #region Calculate premium
            this.service.Calculate(this.model);
            #endregion

            this.CalculateLibilityLimitPremiumTest2();
            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest2();
            #endregion
            this.CalculateOptionalOtherCoverageAssertTest2();
        }

        /// <summary>
        /// CalculateLibilityLimitPremiumTest2
        /// </summary>
        private void CalculateLibilityLimitPremiumTest2()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.RatingBasisParameter, 1000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.RetroYear, 3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.ExposureRate,0.94M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.LiabilityLimitRate, 0.79M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.AggregateLimitRate, Convert.ToDecimal(1.025));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.EPInclusionExclusionRate,1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.RetentionRate, 0.96M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PolicyTypeRate, Convert.ToDecimal(0.800));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.RetroDateRate, 1.14M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.YearsInCMRate, Convert.ToDecimal(0.90));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.BasePremium, 163);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.NonModifiedPremium, 1010);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.ManualPremium,1173);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.IRPMFactor, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.IRPMPremium, 1010);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TerrorismRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TerrorismPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.OtherModRate, 0.90M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.OtherModPremium, 1010);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TierRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TierPremium, 1010);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.POModifiedFinalPremium, 1010);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest2
        /// </summary>
        private void CalculateOptionalCoverageAssertTest2()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseLimit, 50000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseAggregateLimit, 50000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.NonMonetaryDefenseUnModifiedPremium, 1000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodLimit, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium, 0);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest2
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest2()
        {
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageDeductible, 10);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageLimit, 50000);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageRate, 0.20M);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageUnModifiedPremium, 10);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageModifiedPremium, 0);
            }
        }
        #endregion
    }
}
