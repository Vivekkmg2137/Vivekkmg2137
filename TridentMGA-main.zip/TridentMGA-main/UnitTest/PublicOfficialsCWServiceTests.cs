﻿namespace UnitTest
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.ApiModels;
    using RaterProperty;
    using System.Configuration;
    using Microsoft.Extensions.Configuration;
    using System.IO;
    using UnitTest.Init;
    using RaterPublicOfficials;

    /// <summary>
    /// Public Officials CW Service Tests
    /// </summary>
    [TestClass]
    public class PublicOfficialsCWServiceTests
    {
        /// <summary>
        /// Gets logger.
        /// </summary>
        private ILoggingManager logger { get; set; }
        private IConfiguration configuration { get; set; }

        private IPublicOfficialsCWService service;

        private RaterFacadeModel model;

        private PublicOfficialsCWInitialization poCWInitialization;

        /// <summary>
        /// Initialize : It will Initialize Logger and Property service object.
        /// </summary>
        [TestInitialize]
        public void Initialize()
        {
            //Watch the variable to know the path and name of config file
            //ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).FilePath;
            //In our case , the path is:
            //D:\WorkSpaces\CodeSpaces\KMG\MGA\UnitTest\bin\Debug\netcoreapp3.1\testhost.dll.config
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();

            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();
            this.service = new PublicOfficialsCWService(this.configuration, this.logger);
        }

        /// <summary>
        /// PO Service Test Initilize
        /// </summary>
        [TestMethod]
        public void POServiceTestInitilize()
        {
            this.model = new RaterFacadeModel();
            this.poCWInitialization = new PublicOfficialsCWInitialization();
            this.poCWInitialization.Initialize(this.model);
        }

        #region Test Case 1
        /// <summary>
        /// CalculateLibilityPremiumTest1
        /// </summary>
        private void CalculateLibilityPremiumTest1()
        {
            this.poCWInitialization.InitializeLibilityPremium(this.model);
            this.poCWInitialization.InitializeOptionalCoveragePremium(this.model);
            #region Prevalidate
            var preValidateResults = service.PreValidate(this.model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest1
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest1()
        {
            this.CalculateLibilityPremiumTest1();

            #region Calculate premium
            this.service.Calculate(this.model);
            #endregion

            #region Post validate
            var postValidateResults = service.PostValidate(model);
            Assert.AreEqual(postValidateResults.IsValid, true);
            #endregion
            this.CalculatePremiumAssertTest1();
            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest1();
            #endregion
            this.CalculateOptionalOtherCoverageAssertTest1();
            this.CalculateOptionalBasePremiumAssertTest1();
        }

        /// <summary>
        /// CalculatePremiumAssertTest1
        /// </summary>
        private void CalculatePremiumAssertTest1()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.ExposureRate, 3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.EPInclusionExclusionRate, Convert.ToDecimal(0.700));
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalCoverageAssertTest1()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.NonMonetaryDefenseLimit, 10);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.NonMonetaryDefenseAggregateLimit, 10);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.NonMonetaryDefenseModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.NonMonetaryDefenseUnmodifiedPremium, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.SupplExtendedReportingPeriodLimit, 10);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.SupplExtendedReportingPeriodRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.SupplExtendedReportingPeriodUnmodifiedPremium, 3);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest1()
        {
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.publicOfficialsOtherCoverage != null)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.publicOfficialsOtherCoverage[0].OtherCoverageLimit, 1000);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.publicOfficialsOptionalCoverage.publicOfficialsOtherCoverage[0].OtherCoverageRate, 10);
            }
        }

        /// <summary>
        /// CalculateOptionalBasePremiumAssertTest1
        /// </summary>
        private void CalculateOptionalBasePremiumAssertTest1()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.BasePremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.NonModifiedPremium, 24);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.ManualPremium, 3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TierPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.IRPMPremium, -3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.OtherModPremium, 3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.CW.TerrorismPremium, 0);
        }
        #endregion
    }
}
