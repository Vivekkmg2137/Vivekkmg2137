﻿namespace UnitTest
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Logging;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Models;
    using Models.ApiModels;
    using RaterProperty;
    using System.Configuration;
    using Microsoft.Extensions.Configuration;
    using System.IO;
    using UnitTest.Init;
    using RaterPublicOfficials;

    /// <summary>
    /// PublicOfficialsNYServiceTest
    /// </summary>
    [TestClass]
    public class PublicOfficialsNYServiceTest
    {
        /// <summary>
        /// Logger Object
        /// </summary>
        private ILoggingManager logger { get; set; }

        /// <summary>
        /// Configuration Object
        /// </summary>
        private IConfiguration configuration { get; set; }

        /// <summary>
        /// PublicOfficialsNYService Object
        /// </summary>
        private IPublicOfficialsNYService service;

        /// <summary>
        /// RaterFacadeModel Object
        /// </summary>
        private RaterFacadeModel model;

        /// <summary>
        /// PublicOfficialsNYInitialization Object
        /// </summary>
        private PublicOfficialsNYInitialization poInitialization;

        /// <summary>
        /// Initialize : It will Initialize Logger and Property service object.
        /// </summary>
        [TestInitialize]
        public void Initialize()
        {
            //Watch the variable to know the path and name of config file
            //ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None).FilePath;
            //In our case , the path is:
            //D:\WorkSpaces\CodeSpaces\KMG\MGA\UnitTest\bin\Debug\netcoreapp3.1\testhost.dll.config

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddEnvironmentVariables();

            this.configuration = builder.Build();

            var sqlCOnnectionString = configuration["ConnectionStrings:SqlDBConnection"];

            this.logger = new Logging.LoggingManager();
            this.service = new PublicOfficialsNYService(this.configuration, this.logger);
        }

        /// <summary>
        /// PONYServiceTestInitilize
        /// </summary>
        private void PONYServiceTestInitilize()
        {
            this.model = new RaterFacadeModel();
            this.poInitialization = new PublicOfficialsNYInitialization();
            this.poInitialization.Initialize(this.model);
        }

        #region Test Case 1
        /// <summary>
        /// CalculateLibilityPremiumTest1
        /// </summary>
        private void CalculateLibilityPremiumTest1()
        {
            this.PONYServiceTestInitilize();
            this.poInitialization.InitializeLibilityPremium(this.model);
            this.poInitialization.InitializeOptionalCoveragePremium(this.model);
            #region Prevalidate
            var preValidateResults = service.PreValidate(this.model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest1
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest1()
        {
            this.CalculateLibilityPremiumTest1();

            #region Calculate premium
            this.service.Calculate(this.model);
            #endregion

            this.CalculateLibilityLimitPremiumTest1();

            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest1();
            #endregion

            this.CalculateOptionalOtherCoverageAssertTest1();
        }

        /// <summary>
        /// CalculateLibilityLimitPremiumTest1
        /// </summary>
        private void CalculateLibilityLimitPremiumTest1()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RatingBasis, "Adjusted Gross Operating Expenditures");
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RatingBasisParameter, 1000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RetroYear, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.ExposureRate, 3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.LiabilityLimitRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.AggregateLimitRate, Convert.ToDecimal(1.025));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.EPInclusionExclusionRate, 0.3M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.NYEPLimitRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.NYEPAggregateLimitRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.NYEPInclusionExclusionRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RetentionRate, Convert.ToDecimal(1.05));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PolicyTypeRate, Convert.ToDecimal(.80));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RetroDateRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.YearsInCMRate, Convert.ToDecimal(.85));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.BasePremium, 93);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.NonModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.ManualPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.IRPMFactor, Convert.ToDecimal(1));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.IRPMPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.TerrorismRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.TerrorismPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.OtherModRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.OtherModPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.TierRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.TierPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PONYModifiedFinalPremium, 250);
        }
       
        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalCoverageAssertTest1()
        {
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodLimit, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRate, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.OtherCoveragesTotalPremium, 0);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest1
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest1()
        {
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null 
                && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel.Count >0)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageDescription, 100);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageLimit, 1000);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageRate, 10);
            }
        }
        #endregion

        #region Test Case 2
        /// <summary>
        /// CalculateLibilityPremiumTest2
        /// </summary>
        private void CalculateLibilityPremiumTest2()
        {
            this.PONYServiceTestInitilize();
            this.poInitialization.InitializeLibilityPremium2(this.model);
            this.poInitialization.InitializeOptionalCoveragePremium2(this.model);
            #region Prevalidate
            var preValidateResults = service.PreValidate(this.model);
            Assert.AreEqual(preValidateResults.IsValid, true);
            #endregion
        }

        /// <summary>
        /// CalculateOptionalCoveragePremiumTest2
        /// </summary>
        [TestMethod]
        public void CalculatePremiumTest2()
        {
            this.CalculateLibilityPremiumTest2();

            #region Calculate premium
            this.service.Calculate(this.model);
            #endregion

            this.CalculateLibilityLimitPremiumTest2();

            #region Calculate Optional and Other premium
            this.CalculateOptionalCoverageAssertTest2();
            #endregion

            this.CalculateOptionalOtherCoverageAssertTest2();
        }

        /// <summary>
        /// CalculateLibilityLimitPremiumTest2
        /// </summary>
        private void CalculateLibilityLimitPremiumTest2()
        {
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RatingBasis, "Adjusted Gross Operating Expenditures");
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RatingBasisParameter, 1000);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RetroYear, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.ExposureRate, 3);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.LiabilityLimitRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.AggregateLimitRate, Convert.ToDecimal(1.025));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.EPInclusionExclusionRate, 0.30M);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.NYEPLimitRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.NYEPAggregateLimitRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.NYEPInclusionExclusionRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RetentionRate, Convert.ToDecimal(1.05));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PolicyTypeRate, Convert.ToDecimal(.80));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.RetroDateRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.YearsInCMRate, Convert.ToDecimal(.85));
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.BasePremium, 93);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.NonModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.ManualPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.IRPMFactor, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.IRPMPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.TerrorismRate, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.TerrorismPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.OtherModRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.OtherModPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.TierRate, 1);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.TierPremium, 250);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PONYModifiedFinalPremium, 250);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest2
        /// </summary>
        private void CalculateOptionalCoverageAssertTest2()
        {
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodLimit, 10);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodRate, 0);
            //Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodUnModifiedPremium, 0);
            Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.OtherCoveragesTotalPremium, 0);
        }

        /// <summary>
        /// CalculateOptionalCoverageAssertTest2
        /// </summary>
        private void CalculateOptionalOtherCoverageAssertTest2()
        {
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel != null
                && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel.Count > 0)
            {
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageDescription, 200);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageLimit, 2000);
                Assert.AreEqual(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.PublicOfficialsOtherCoverageModel[0].OtherCoverageRate, 20);
            }
        }
        #endregion
    }
}
