﻿
namespace Validations
{
    using AutoMapper;
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Models.ApiModels;
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    public class AutoALNYPostValidator : AbstractValidator<RaterFacadeModel>
    {
        private AutoDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        readonly IConfiguration configuration;

        private readonly IMapper _mapper;

        public AutoALNYPostValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.DataAccess = new AutoDataAccess(this.configuration, this.Logger);
        }
    }
}
