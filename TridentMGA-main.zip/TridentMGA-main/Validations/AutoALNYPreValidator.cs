﻿namespace Validations
{
    using AutoMapper;
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Microsoft.Extensions.Configuration;
    using Models;
    using Models.ApiModels;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Text;
    public class AutoALNyPreValidator : AbstractValidator<RaterFacadeModel>
    {
        private AutoDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        readonly IConfiguration configuration;

        private readonly IMapper _mapper;

        public AutoALNyPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.DataAccess = new AutoDataAccess(this.configuration, this.Logger);

            //Model Validation 
            #region Model Validation 

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                .Must((modelObject, selectedLineOfBusiness) => IsModelValid(modelObject))
                .WithMessage(Resources.ErrorMessages.InputJSONNotValidForLOBs);

            //3)If Not received as input by Rater
            //Cannot Rate the quote as 'Limit Type' is Mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LimitType)
                .NotEmpty()
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityLimitTypeMissing);

            //4)If Not received as input by Rater
            //Cannot Rate the quote as 'Liability Limit' is Mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LiabilityLimit)
                .NotEmpty()
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityLiablityLimitMissing);

            //6)If Incorrectly received by the rater i.e. not in the range of lookup
            //Cannot Rate the quote as 'Rate' entered is not in the allowed range 
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LiabilityLimitRate >= 0, () =>
            {
                string stringLiabilityLimitRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LiabilityLimitRate)
                    .Must((modelObject, value) =>
                    CheckForMinMaxValueLiabilityLimitRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LiabilityLimitRate, modelObject, out stringLiabilityLimitRate))
                    .WithMessage(x => !string.IsNullOrEmpty(stringLiabilityLimitRate) ? stringLiabilityLimitRate : Resources.ErrorMessages.InputAutoLiabilityLimitRateNotInRange);
            });
            //8)If Not received as input by Rater
            //Cannot Rate the quote as 'Deductible/SIR' is mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Deductible_SIR)
                .NotEmpty()
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityDeductible_SIRMissing);

            //9)If 'Deductible/SIR' is selected as 'Deductible' & value entered is not applicable or not as per the lookup values per state
            //Cannot Rate the Quote as the 'Retention' is not applicable
            When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Deductible_SIR)
            && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Deductible_SIR.ToUpper() == "DEDUCTIBLE", () =>
            {
                string stringRetention = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Retention)
                    .Must((modelObject, value) =>
                    CheckForMinMaxValueAutoApplicableDeductible(modelObject, out stringRetention))
                    .WithMessage(x => !string.IsNullOrEmpty(stringRetention) ? stringRetention : Resources.ErrorMessages.InputAutoLiabilityRetentionNotInRange);

            });

            //10) If 'Deductible/SIR' is selected as 'SIR' & value entered is not applicable or not as per the lookup values per state	
            //Cannot Rate the Quote as the 'Retention' is not applicable
            When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Deductible_SIR)
            && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Deductible_SIR.ToUpper() == "SIR", () =>
            {
                string stringRetention = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Retention)
                    .Must((modelObject, value) =>
                    CheckForMinMaxValueAutoApplicableDeductible(modelObject, out stringRetention))
                    .WithMessage(x => !string.IsNullOrEmpty(stringRetention) ? stringRetention : Resources.ErrorMessages.InputAutoLiabilityRetentionNotInRange);

            });


            //11)If 'Deductible/SIR' is received by rater but 'Retention' is not received by rater
            // Cannot Rate the quote as 'Retention' is Mandatory when 'Deductible/SIR' is opted
            When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Deductible_SIR)
             && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Deductible_SIR.ToUpper() == "DEDUCTIBLE" ||
             reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Deductible_SIR.ToUpper() == "SIR"), () =>
             {
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Retention)
                    .NotNull()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityRetentionDeductibleSIRMissing);
             });

            //12)If Expense is not received by the rater	
            //Cannot Rate the quote as 'Exepnse' is Mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Expense)
                .NotEmpty()
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityExpenseMissing);

            //13)If 'Aggregate Retention' received by rater is less than 'Retention'
            //Cannot Rate the quote as 'Aggregate Retention' is less than the 'Retention'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AggregateRetention)
                .GreaterThanOrEqualTo(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.Retention)
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAggregateRetentionMissing);

            //14)If the Medical Payment limit is selected for the not appicable states
            //Cannot Rate the quote as 'Medical Payments' coverage is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalPaymentsLimit)
                .Must((modelObject, value) =>
                CheckAutoApplicableMedPayState(modelObject, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalPaymentsLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityMedicalPaymentsLimitNotApplicableForState);

            //15)If the Medical Payments limit is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Medical Payments' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
             {
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalPaymentsLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalPaymentsLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityMedicalPaymentsLimitNotApplicable);
             });

            //16)If the user entered value is less than the 'Medical Payments'
            //Cannot Rate the quote as 'Med Pay Aggregate' cannot be less than the 'Medical Payments'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedPayAggregate)
                .Must((modelObject, value) =>
                CheckMedPayAggregate(modelObject))
                .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityMedPayAggregateAndMedicalPayments);

            //17)If the Med Pay Aggregatet is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Med Pay Aggregate' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
              {
                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedPayAggregate)
                      .Equal(0)
                      .WithMessage(Resources.ErrorMessages.InputAutoLiabilityMedPayAggregatetHiredAndNonOwned);
              });

            //18)If 'Uninsured Limit' is received by rater for not applicable states
            //Cannot Rate the quote as 'Uninsured' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredLimit)
                .Must((modelObject, value) =>
                CheckAutoApplicableUMCoverageState(modelObject, "Uninsured", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredLimitNotApplicableForState);

            //19)If the UnInsured Limit is selected when 'Hired and NonOwned' = 'HNO ONLY'	
            //Cannot Rate the quote as 'UnInsured' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUnInsuredLimitHiredAndNonOwned);
            });

            //20)"If State Code = 'IN' or 'MS' AND user enters 'Uninsured Limit' & 'Uninsured BI/PD Limit'"	
            //Cannot Rate the quote as user can either select Uninsured or Uninsured BI/PD; cannot select both
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredLimit)
               .Must((modelObject, value) => UninsuredAndUninsuredBIValidation(modelObject))
               .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredUninsuredBIPDCannotSelectBoth);

            //21)If State Code = 'IN' & Uninsured Limit <> 'No coverage'
            //Cannot Rate the quote as  'Uninsured' is not equal to  'Liability'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.IN, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredLimit.ToUpper())
                    .NotEqual("NO COVERAGE")
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredNotEqualLiability);
            });

            //22)If State Code = 'NH'    
            //Cannot Rate the quote as 'Uninsured' must be equal to 'Liability'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NH, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredLimit)
                    .Equal("Liability")
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredMustBeEqualLiability);
            });

            //23)If State Code = 'MS' & 'UM / UIM Stacking' = 'No'
            //Cannot Rate the quote as 'Uninsured' cannot be opted when 'UM/UIM Stacking' = 'No'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.MS && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UMUIMStacking == false, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredLimit)
                    .Empty()
                    .Null()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredNotOptedUMStackingNo);
            });

            //25)If 'Uninsured Limit' is received by rater for not applicable states
            //Cannot Rate the quote as 'Uninsured' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredBIPDLimit)
                .Must((modelObject, value) =>
                CheckAutoApplicableUMCoverageState(modelObject, "Uninsured BI/PD", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredBIPDLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredLimitNotApplicableForState);

            //26)If the 'UnInsured BI/PD' Limit is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'UnInsured BI/PD' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
              {
                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredBIPDLimit)
                     .Must((modelObject, value) =>
                     checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredBIPDLimit))
                     .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredBIAndPDHiredAndNonOwnedCoverageHNOOnlyInvalid);
              });

            //27)If State Code = 'IN' & Uninsured <> 'No coverage'
            //Cannot Rate the quote as  'Uninsured' is not equal to  'Liability'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.IN, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredBIPDLimit)
                    .NotEqual("No coverage")
                    .WithMessage(Resources.ErrorMessages.UninsuredPropertyIsNotEqualToLiabilityLimit);
            });

            //28)If State Code = 'MS' & 'UM / UIM Stacking' = 'No'
            //Cannot Rate the quote as 'Uninsured' cannot be opted when 'UM/UIM Stacking' = 'No'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.MS && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UMUIMStacking == false, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredBIPDLimit)
                .Empty()
                .Null()
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredNotOptedUMStackingNo);
            });

            //29)If State Code = 'NH'
            //Cannot Rate the quote as 'Uninsured' must be equal to 'Liability'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NH, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredLimit)
                    .Equal(reg => Convert.ToString(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LiabilityLimit))
                    .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityUninsuredEqualToLiability);
            });


            //30)If 'Uninsured PD' is received by rater for not applicable states	
            //Cannot Rate the quote as 'Uninsured PD' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredPD)
                .Must((modelObject, value) =>
                CheckAutoApplicableUMCoverageState(modelObject, "Uninsured PD", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredPD))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredPDNotApplicableForState);

            //31)If the 'UnInsured PD' Limit is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'UnInsured PD' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredPD)
                .Empty()
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredPDHiredAndNonOwnedCoverageHNOOnlyInvalid);
            });

            //32)If 'Underinsured' is received by rater for not applicable states
            //Cannot Rate the quote as 'Underinsured' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredLimit)
                .Must((modelObject, value) =>
                CheckAutoApplicableUIMCoverageState(modelObject, "Underinsured", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUnderinsuredLimitNotApplicableForState);

            //33)If the 'UnderInsured' Limit is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'UnderInsured' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
             {
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredLimit)
                     .Must((modelObject, value) =>
                     checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredLimit)).
                     WithMessage(Resources.ErrorMessages.InputAutoLiabilityUnderInsuredHiredNonOwned);
             });

            //34)If 'Underinsured Conversion' is received by rater for not applicable states
            //Cannot Rate the quote as 'Underinsured Conversion' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredConversion)
                .Must((modelObject, value) =>
                CheckAutoApplicableUIMCoverageStateBool(modelObject, "Underinsured Conversion", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredConversion))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUnderinsuredConversionNotApplicableForState);

            //35) If the 'UnderInsured Conversion' Limit is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'UnderInsured Conversion' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredConversion)
               .Equal(true)
               .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUnderInsuredConversionHiredAndNonOwnedCoverageHNOOnlyInvalid);
            });

            string[] stateUMUIMStacking = { "MS", "PA" };
            List<string> stateUMUIMStackingList = new List<string>(stateUMUIMStacking);
            //36)If UM/ UIM stacking is opted for States other than 'MS' & 'PA'
            //Cannot Rate the quote as UM / UIM Stacking is not applicbale for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UMUIMStacking)
                .Must((modelObject, uninsured) => UninsuredUMUIMStacking(modelObject, stateUMUIMStackingList))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredUIUMStackingNotApplicable);

            //38)If the 'UM/UIM Stacking' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'UM/UIM Stacking' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UMUIMStacking)
                .Equal(true)
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityUMUIMStackingHiredAndNonOwnedCoverageHNOOnlyInvalid);
            });

            //39)If 'Personal Injury Protection' is received by rater for not appicable states	
            //Cannot Rate the quote as 'Personal Injury Protection' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PersonalInjuryProtectionLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Personal Injury Protection", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PersonalInjuryProtectionLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoPersonalInjuryProtectionLimitNotApplicableForState);

            // //40)If State = 'PA'
            // //Cannot Rate the quote as 'Personal Injury Protection' is not appliable for the selected state
            // When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State == AppConstants.PA, () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PersonalInjuryProtectionLimit)
            //     .Empty().WithMessage(Resources.ErrorMessages.InputAutoPersonalInjuryProtectionLimitNotApplicableForSelectedState);
            //});

            //41)If the 'Personal Injury Protection' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Personal Injury Protection' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PersonalInjuryProtectionLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PersonalInjuryProtectionLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPersonalInjuryProtectionLimitHNONotApplicable);
            });

            //42)If 'PIP Deductible' is received by rater for not appicable states
            //Cannot Rate the quote as 'PIP Deductible' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPDeductible)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "PIP Deductible",
                modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPDeductible))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPIPDeductibleInvalid);

            //43)If the 'PIP Deductible' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Personal Injury Protection Deductible' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPDeductible)
                     .Must((modelObject, value) =>
                     checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPDeductible))
                     .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPIPDeductibleNotApplicable);
            });

            //44)If 'Additional PIP' is received by rater for not appicable states
            //Cannot Rate the quote as 'Additional PIP' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalPIPLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Additional PIP", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalPIPLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalPIPLimitInvalidForState);

            //45)If the 'Additional PIP' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Additional PIP' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalPIPLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalPIPLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalPIPLimitHiredAndNonOwnedNotApplicable);
            });

            //46)If 'Additional Monthly Work Loss' is received by rater for not appicable states
            //Cannot Rate the quote as 'Additional Monthly Work Loss' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalMonthlyWorkLossLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Additional Monthly Work Loss", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalMonthlyWorkLossLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalMonthlyWorkLossLimitInvalidForState);

            //47)If the 'Additional Monthly Work Loss' is selected when 'Hired and NonOwned' = 'HNO ONLY'	
            //Cannot Rate the quote as 'Additional Monthly Work Loss' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalMonthlyWorkLossLimit)
                     .Equal(0)
                     .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalMonthlyWorkLossLimitHiredAndNonOwnedNotApplicable);
            });

            //48)If 'Additional PIP Other Expenses (Per Day)' is received by rater for not appicable states
            //Cannot Rate the quote as 'Additional PIP Other Expenses (Per Day)' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalPIPOtherExpensesPerDayLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Additional PIP Other Expenses (Per Day)", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalPIPOtherExpensesPerDayLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalPIPOtherExpensesPerDayLimitInvalidForState);

            //49)If the 'Additional PIP Other Expenses (Per Day)' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Additional PIP Other Expenses (Per Day)' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalPIPOtherExpensesPerDayLimit)
                    .Equal(0)
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalPIPOtherExpensesPerDayLimitHiredAndNonOwnedNotApplicable);
            });

            //50)If 'Additional Death Benefit' is received by rater for not appicable states
            //Cannot Rate the quote as 'Additional Death Benefit' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalDeathBenefitLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Additional Death Benefit", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalDeathBenefitLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalDeathBenefitLimitInvalidForState);

            //51)If the 'Additional Death Benefit' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Additional Death Benefit' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalDeathBenefitLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalDeathBenefitLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalDeathBenefitLimitHiredAndNonOwnedNotApplicable);
            });

            //52)If 'OBEL' is received by rater for not appicable states
            //Cannot Rate the quote as 'OBEL' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.OBELLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "OBEL", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.OBELLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityOBELLimitInvalidForState);

            //53)If the 'OBEL' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'OBEL' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.OBELLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.OBELLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityOBELLimitAndNonOwnedNotApplicable);
            });

            //54) If 'PIP Medical Expense Elimination' is received by rater for not appicable states
            // Cannot Rate the quote as 'PIP Medical Expense Elimination' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPMedicalExpenseEliminationLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "PIP Medical Expense Elimination", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPMedicalExpenseEliminationLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPIPMedicalExpenseEliminationLimitInvalidForState);

            //55)If the 'PIP Medical Expense Elimination' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'PIP Medical Expense Elimination' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPMedicalExpenseEliminationLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPMedicalExpenseEliminationLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPIPMedicalExpenseEliminationLimitAndNonOwnedNotApplicable);
            });


            //56)If State Code = 'MI'
            //Cannot Rate the quote as 'Excess Attendant Care' cannot be selected if 'Personal Injury Protection' equals 'Unlimited'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.MI &&
            !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.ExcessAttendantCareLimit)
            && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PersonalInjuryProtectionLimit == "Unlimited", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.ExcessAttendantCareLimit)
                    .Empty()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityExcessAttendantCareLimitAndPersonalInjuryProtectionApplicable);
            });

            //57) If 'Excess Attendant Care' is received by rater for not appicable states
            // Cannot Rate the quote as 'Excess Attendant Care' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.ExcessAttendantCareLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Excess Attendant Care", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.ExcessAttendantCareLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityExcessAttendantCareLimitInvalidForState);

            //58)If the 'Excess Attendant Care' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Excess Attendant Care' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.ExcessAttendantCareLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.ExcessAttendantCareLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityExcessAttendantCareLimitAndNonOwnedNotApplicable);
            });

            //59)If 'Property Protection Insurance' is received by rater for not appicable states
            //Cannot Rate the quote as 'Property Protection Insurance' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionInsuranceLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Property Protection Insurance", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionInsuranceLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPropertyProtectionInsuranceLimitInvalidForState);

            //60)If the 'Property Protection Insurance' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Property Protection Insurance' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionInsuranceLimit)
                      .Must((modelObject, value) =>
                       checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionInsuranceLimit))
                      .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPropertyProtectionInsuranceLimitAndNonOwnedNotApplicable);
            });

            //61) If 'Property Protection Insurance' equals 'Excluded'
            // Cannot Rate the quote as 'Property Protection Deductible' is not applicable for the value opted for 'Personal Injury Protection'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionDeductible == "Excluded", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionDeductible)
                    .Empty()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPropertyProtectionPersonalInjuryProtectionDeductibleInvalid);
            });


            //62)If 'Property Protection Deductible' is received by rater for not appicable states	
            //Cannot Rate the quote as 'Property Protection Deductible' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionDeductible)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Property Protection Insurance", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionDeductible))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPropertyProtectionDeductibleInvalidForState);

            //63)If the 'Property Protection Deductible' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Property Protection Deductible' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionDeductible)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyProtectionDeductible))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPropertyProtectionDeductibleAndNonOwnedNotApplicable);
            });

            //64)If 'Property Damage Liability Buyback' is received by rater for not appicable states
            //Cannot Rate the quote as 'Property Damage Liability Buyback' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyDamageLiabilityBuybackLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Property Damage Liability Buyback", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyDamageLiabilityBuybackLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPropertyDamageLiabilityBuybackLimitInvalidForState);

            //65)If the 'Property Damage Liability Buyback' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Property Damage Liability Buyback' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY"
            , () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyDamageLiabilityBuybackLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PropertyDamageLiabilityBuybackLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPropertyDamageLiabilityBuybackLimitAndNonOwnedNotApplicable);
            });

            //66) If 'PIP Work Loss Exclusion' is received by rater for not appicable states
            //Cannot Rate the quote as 'PIP Work Loss Exclusion' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPWorkLossExclusionLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "PIP Work Loss Exclusion",
                modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPWorkLossExclusionLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPIPWorkLossExclusionLimitInvalidForState);

            //67) If the 'PIP Work Loss Exclusion' is selected when 'Hired and NonOwned' = 'HNO ONLY'	
            //Cannot Rate the quote as 'PIP Work Loss Exclusion' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPWorkLossExclusionLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PIPWorkLossExclusionLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPIPWorkLossExclusionLimitAndNonOwnedNotApplicable);
            });

            //68)If State<> PA
            //Cannot Rate the quote as 'Personal Injury Protection' is not appliable for the selected state
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State != StateCodeConstant.PA, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BasicFPBLimit)
                    .Empty()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPersonalInjuryProtectionLimitNotApplicableForState);
            });

            //69)If the 'Basic FPB' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Basic FPB' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BasicFPBLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BasicFPBLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityBasicFPBLimitAndNonOwnedNotApplicable);
            });

            //70)If 'Additional Benefits' is received by rater for not appicable states 
            //Cannot Rate the quote as 'Additional Benefits' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Additional Benefits", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalBenefitsLimitInvalidForState);

            //71)If the 'Additional Benefits' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Additional Benefits' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalBenefitsLimitAndNonOwnedNotApplicable);
            });

            //72)If State Code = 'PA'
            //Cannot Rate the quote as 'Combination FPB' should be blank as 'Additional Benefits' equals 'No Coverage' or 'Added FPB'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.PA
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit == "No Coverage"
            || reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit == "Added FPB"), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.CombinationFPBLimit)
                    .Empty()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityCombinationFPBLimitAdditionalBenefitsLimitNotApplicable);
            });

            //73)If 'Combination FPB' is received by rater for not appicable states
            //	Cannot Rate the quote as 'Combination FPB' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.CombinationFPBLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Combination FPB", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.CombinationFPBLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityCombinationFPBLimitInvalidForState);

            //74)If the 'Combination FPB' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Combination FPB' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.CombinationFPBLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.CombinationFPBLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityCombinationFPBLimitAndNonOwnedNotApplicable);
            });

            //75)If State Code = 'PA'
            //Cannot Rate the quote as 'Medical Expense Benefits' should be blank as 'Additional Benefits' equals 'No Coverage' or 'Combination FPB'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.PA
           && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit == "No Coverage"
           || reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit == "Combination FPB"), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalExpenseBenefitsLimit)
                    .Empty()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityMedicalExpenseBenefitsLimitAdditionalBenefitsLimitNotApplicable);
            });

            //76)If 'Medical Expense Benefits' is received by rater for not appicable states
            //Cannot Rate the quote as 'Medical Expense Benefits' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalExpenseBenefitsLimit)
                .Must((modelObject, value) =>
                CheckAutoApplicablePIPCoverage(modelObject, "Medical Expense Benefits", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalExpenseBenefitsLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityMedicalExpenseBenefitsLimitInvalidForState);

            //77)If the 'Medical Expense Benefits' is selected when 'Hired and NonOwned' = 'HNO ONLY'	
            //Cannot Rate the quote as 'Medical Expense Benefits' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
             {
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalExpenseBenefitsLimit)
                      .Must((modelObject, value) =>
                       checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalExpenseBenefitsLimit))
                      .WithMessage(Resources.ErrorMessages.InputAutoLiabilityMedicalExpenseBenefitsLimitAndNonOwnedNotApplicable);
             });

            //78)If State Code = 'PA'
            //Cannot Rate the quote as 'Work Loss Benefits' should be blank as 'Additional Benefits' equals 'No Coverage' or 'Combination FPB'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.PA
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit == "No Coverage"
            || reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit == "Combination FPB"), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.WorkLossBenefitsLimit)
                    .Empty()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityWorkLossBenefitsLimitAdditionalBenefitsLimitNotApplicable);
            });

            //79)If 'Work Loss Benefits' is received by rater for not appicable states
            //Cannot Rate the quote as 'Work Loss Benefits' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.WorkLossBenefitsLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Work Loss Benefits", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.WorkLossBenefitsLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityWorkLossBenefitsLimitInvalidForState);

            //80)If the 'Work Loss Benefits' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Work Loss Benefits' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.WorkLossBenefitsLimit)
                    .Must((modelObject, value) =>
                     checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.WorkLossBenefitsLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityWorkLossBenefitsLimitAndNonOwnedNotApplicable);
            });

            //81) If State Code = 'PA'
            //Cannot Rate the quote as 'Funeral Expense Benefits' should be blank as 'Additional Benefits' equals 'No Coverage' or 'Combination FPB'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.PA
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit == "No Coverage"
            || reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit == "Combination FPB"), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.FuneralExpenseBenefitsLimit)
                    .Empty()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityFuneralExpenseBenefitsLimitAdditionalBenefitsLimitNotApplicable);
            });

            //82)If the 'Funeral Expense Benefits' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Funeral Expense Benefits' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.FuneralExpenseBenefitsLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.FuneralExpenseBenefitsLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityFuneralExpenseBenefitsLimitAndNonOwnedNotApplicable);
            });

            //83)If State Code = 'PA'
            //Cannot Rate the quote as 'Accidental Death Benefits' should be blank as 'Additional Benefits' equals 'No Coverage'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.PA
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AdditionalBenefitsLimit == "No Coverage"), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AccidentalDeathBenefitsLimit)
                    .Empty()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAccidentalDeathBenefitsLimitAdditionalBenefitsLimitNotApplicable);
            });

            //84)If the 'Accidental Death Benefits' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Accidental Death Benefits' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AccidentalDeathBenefitsLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AccidentalDeathBenefitsLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAccidentalDeathBenefitsLimitAndNonOwnedNotApplicable);
            });

            //85)If State Code = 'PA'
            //Cannot Rate the quote as 'Extraordinary Medical Benefits' cannot be selected if 'Medical Benefits' Not equals '100,000'
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.PA
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalExpenseBenefitsLimit != "100000"), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.ExtraordinaryMedicalBenefitsLimit)
                    .Empty()
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityExtraordinaryMedicalBenefitsLimitInvalidValueForPAState);
            });

            //86)If the 'Extraordinary Medical Benefits' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Extraordinary Medical Benefits' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.ExtraordinaryMedicalBenefitsLimit)
                   .Must((modelObject, value) =>
                   checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.ExtraordinaryMedicalBenefitsLimit))
                   .WithMessage(Resources.ErrorMessages.InputAutoLiabilityExtraordinaryMedicalBenefitsLimitAndNonOwnedNotApplicable);
            });

            //87)If 'Pedestrian FPB' is received by rater for not appicable states
            //Cannot Rate the quote as 'Pedestrian FPB' is not applicable for the selected 'State'
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PedestrianFPBLimit)
                .Must((modelObject, value) => CheckAutoApplicablePIPCoverage(modelObject, "Pedestrian FPB", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PedestrianFPBLimit))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPedestrianFPBLimitInvalidForState);

            //88)If the 'Pedestrian FPB' is selected when 'Hired and NonOwned' = 'HNO ONLY'
            //Cannot Rate the quote as 'Pedestrian FPB' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PedestrianFPBLimit)
                    .Must((modelObject, value) =>
                    checkValueStringIsNullOrEmpty(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PedestrianFPBLimit))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPedestrianFPBLimitAndNonOwnedNotApplicable);
            });

            #region Not to do
            ////93)If Liability Symbol is not received by the rater
            ////Cannot Rate the quote as Liability Symbol is Mandatory
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LiabilitySymbol)
            //   .NotEmpty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityLiabilitySymbolRequired);

            ////94)If the Liabiiity is selected when 'Hired and NonOwned' = 'HNO ONLY'
            ////Cannot Rate the quote as 'Liability Symbol' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            //When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY"
            //, () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LiabilitySymbol)
            //    .Empty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityLiabilitySymbolAndNonOwnedNotApplicable);
            //});

            ////95)If 'Personal Injury Protection' or 'Basic FPB limit' is received by the rater and 'Symbol' is not entered
            ////Cannot Rate the quote as 'Personal Injury Protection Symbol' is Mandatory
            //When(reg => (!string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PersonalInjuryProtectionLimit)
            //|| !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BasicFPBLimit))
            //, () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LiabilitySymbol)
            //    .NotEmpty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityLiabilitySymbolAndPersonalInjuryProtectionSymbol);
            //});

            ////96)If the Personal Injury Protection is selected when 'Hired and NonOwned' = 'HNO ONLY'
            ////Cannot Rate the quote as 'Personal Injury Protection Symbol' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            //When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY"
            //            , () =>
            //            {
            //                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.PersonalInjuryProtectionSymbol)
            //                .Empty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityPersonalInjuryProtectionSymbolAndNonOwnedNotApplicable);
            //            });

            ////97)If 'Medical Payments' is received by the rater and 'Symbol' is not entered
            ////Cannot Rate the quote as 'Medical Payments Symbol' is Mandatory
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalPaymentsSymbol)
            //.NotEmpty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityMedicalPaymentsSymbolRequired);

            ////98)If the Medical Payments is selected when 'Hired and NonOwned' = 'HNO ONLY'
            ////Cannot Rate the quote as 'Medical Payments Symbol' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            //When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY"
            //, () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.MedicalPaymentsSymbol)
            //    .Empty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityMedicalPaymentsSymbolAndNonOwnedNotApplicable);
            //});

            ////99)If 'Uninsured Motorist' is received by the rater and 'Symbol' is not entered
            ////Cannot Rate the quote as 'Uninsured Motorist Symbol' is Mandatory
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredMotoristSymbol)
            //.NotEmpty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredMotoristSymbolRequired);

            ////100)If the UnInsured Motorist is selected when 'Hired and NonOwned' = 'HNO ONLY'
            ////Cannot Rate the quote as 'UnInsured Motorist Symbol' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            //When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY"
            //, () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredMotoristSymbol)
            //    .Empty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityUninsuredMotoristSymbolAndNonOwnedNotApplicable);
            //});

            ////101)If 'Underinsured Motorist' is received by the rater and 'Symbol' is not entered
            ////Cannot Rate the quote as 'Underinsured Motorist' is Mandatory
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredMotoristSymbol)
            //.NotEmpty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityUnderinsuredMotoristSymbolRequired);

            ////102)If the UnderInsured Motorist is selected when 'Hired and NonOwned' = 'HNO ONLY'
            ////Cannot Rate the quote as 'UnderInsured Motorist Symbol' is not applicable if 'Hired & NonOwned' = 'HNO ONLY'
            //When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY"
            //, () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredMotoristSymbol)
            //    .Empty().WithMessage(Resources.ErrorMessages.InputAutoLiabilityUnderinsuredMotoristSymbolAndNonOwnedNotApplicable);
            //});

            ////103)"	If 'Rating Basis' = 'Flat Charge' & Premium is not received by the rater"
            //// Cannot Rate the quote as 'Additional Insured Designated Person Or Organization - CA201' Premium is missing"
            //When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AutoLiabilityOptionalCoveragesModel != null
            //, () =>
            //{
            //    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.AutoLiabilityOptionalCoveragesModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201RatingBasis == "Flat Charge"
            //    , () =>
            //    {
            //        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.
            //        AutoLiabilityOptionalCoveragesModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201UnModifiedPremium)
            //        .NotEqual(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredDesignatedPersonOrOrganizationCA201UnModifiedPremiumMissing);
            //    });

            //    //104) If 'Additional Insured Designated Person Or Organization - CA201' is received by rater for not appicable states
            //    //Cannot Rate the quote as 'Additional Insured Designated Person Or Organization - CA201' is not applicable for the selected 'State'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Limit)
            //    .Must((modelObject, value) => CheckAutoApplicableOptionalCoverage(modelObject, "Additional Insured Designated Person Or Organization - CA201"))
            //    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredDesignatedPersonOrOrganizationCA201LimitNotApplicableForStates);

            //    //105) If 'Additional Insured Designated Person Or Organization - CA201' Limit is received by the rater
            //    //Cannot rate the quote as 'Limit' is not applicable for the Coverage 'Additional Insured Designated Person Or Organization - CA201'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Limit)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredDesignatedPersonOrOrganizationCA201LimitNotApplicable);

            //    //106)If 'Additional Insured Designated Person Or Organization - CA201' deductible is received by the rater
            //    //Cannot rate the quote as 'Deductible' is not applicable for the Coverage 'Additional Insured Designated Person Or Organization - CA201'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Deductible)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredDesignatedPersonOrOrganizationCA201DeductibleNotApplicable);

            //    //107)If 'Additional Insured Designated Person Or Organization - CA201' Rate is received by the rater
            //    //Cannot rate the quote as 'Rate' is not applicable for the Coverage 'Additional Insured Designated Person Or Organization - CA201'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredDesignatedPersonOrOrganizationCA201Rate)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredDesignatedPersonOrOrganizationCA201RateNotApplicable);

            //    //TODO
            //    //108)If 'Additional Insured Designated Person Or Organization - CA201' Description is received by the rater
            //    //Cannot rate the quote as 'Description' is not applicable for the Coverage 'Additional Insured Designated Person Or Organization - CA201'

            //    //109) If 'Rating Basis' = 'Flat Charge' & Premium is not received by the rater    "
            //    //Cannot Rate the quote as 'Additional Insured Endorsement - Auto - AG1009' Premium is missing"
            //    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredEndorsementAutoAG1009RatingBasis == "Flat Charge"
            //    , () =>
            //    {
            //        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //        .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredEndorsementAutoAG1009UnModifiedPremium)
            //        .NotEqual(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredEndorsementAutoAG1009UnModifiedPremiumMissing);
            //    });

            //    //110)If 'Additional Insured Endorsement - Auto - AG1009' is received by rater for not appicable states
            //    //Cannot Rate the quote as 'Additional Insured Endorsement - Auto - AG1009' is not applicable for the selected 'State'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredEndorsementAutoAG1009Limit)
            //    .Must((modelObject, value) => CheckAutoApplicableOptionalCoverage(modelObject, "Additional Insured Endorsement - Auto - AG1009"))
            //    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredEndorsementAutoAG1009LimitNotApplicableForStates);

            //    //111) 'Additional Insured Endorsement - Auto - AG1009' Limit is received by the rater
            //    // Cannot rate the quote as 'Limit' is not applicable for the Coverage 'Additional Insured Endorsement - Auto - AG1009'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredEndorsementAutoAG1009Limit)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredEndorsementAutoAG1009LimitNotApplicable);

            //    //112)If 'Additional Insured Endorsement - Auto - AG1009' deductible is received by the rater
            //    //Cannot rate the quote as 'Deductible' is not applicable for the Coverage 'AAdditional Insured Endorsement - Auto - AG1009'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredEndorsementAutoAG1009Deductible)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredEndorsementAutoAG1009DeductibleNotApplicable);

            //    //113)If 'Additional Insured Endorsement - Auto - AG1009' Rate is received by the rater
            //    //Cannot rate the quote as 'Rate' is not applicable for the Coverage 'Additional Insured Endorsement - Auto - AG1009'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredEndorsementAutoAG1009Rate)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityAdditionalInsuredEndorsementAutoAG1009RateNotApplicable);

            //    //114)If 'Additional Insured Endorsement - Auto - AG1009' Description is received by the rater
            //    //Cannot rate the quote as 'Description' is not applicable for the Coverage 'Additional Insured Endorsement - Auto - AG1009'

            //    //115)If 'Rating Basis' = 'Flat Charge' & Premium is not received by the rater	"
            //    //Cannot Rate the quote as Lessor - 'Additional Insured And Loss Payee - CA 20 01' Premium is missing"
            //    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.AdditionalInsuredEndorsementAutoAG1009RatingBasis == "Flat Charge"
            //    , () =>
            //    {
            //        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //        .AutoLiabilityOptionalCoveragesModel.LessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremium)
            //        .NotEqual(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityLessorAdditionalInsuredAndLossPayeeCA2001UnModifiedPremiumMissing);
            //    });

            //    //116)If 'Lessor - Additional Insured And Loss Payee - CA 20 01' is received by rater for not appicable states
            //    //Cannot Rate the quote as 'Lessor - Additional Insured And Loss Payee - CA 20 01' is not applicable for the selected 'State'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.LessorAdditionalInsuredAndLossPayeeCA2001Limit)
            //    .Must((modelObject, value) => CheckAutoApplicableOptionalCoverage(modelObject, "Lessor - Additional Insured And Loss Payee - CA 20 01"))
            //    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityLessorAdditionalInsuredAndLossPayeeCA2001LimitNotApplicableForStates);

            //    //117)If 'Lessor - Additional Insured And Loss Payee - CA 20 01' Limit is received by the rater
            //    //Cannot rate the quote as 'Limit' is not applicable for the Coverage 'Lessor - Additional Insured And Loss Payee - CA 20 01'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.LessorAdditionalInsuredAndLossPayeeCA2001Limit)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityLessorAdditionalInsuredAndLossPayeeCA2001LimitNotApplicable);


            //    //118)If 'Lessor - Additional Insured And Loss Payee - CA 20 01' deductible is received by the rater
            //    //Cannot rate the quote as 'Deductible' is not applicable for the Coverage 'Lessor - Additional Insured And Loss Payee - CA 20 01'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.LessorAdditionalInsuredAndLossPayeeCA2001Deductible)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityLessorAdditionalInsuredAndLossPayeeCA2001DeductibleNotApplicable);

            //    //119)If 'Lessor - Additional Insured And Loss Payee - CA 20 01' Rate is received by the rater
            //    //Cannot rate the quote as 'Rate' is not applicable for the Coverage 'Lessor - Additional Insured And Loss Payee - CA 20 01'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.LessorAdditionalInsuredAndLossPayeeCA2001Rate)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityLessorAdditionalInsuredAndLossPayeeCA2001RateNotApplicable);

            //    //TODO
            //    //120) If 'Lessor - Additional Insured And Loss Payee - CA 20 01 Description is received by the rater	
            //    //Cannot rate the quote as 'Description' is not applicable for the Coverage 'Lessor - Additional Insured And Loss Payee -CA 20 01'

            //    //121) If 'Rating Basis' = 'Flat Charge' & Limit is not received by the rater  "
            //    //Cannot Rate the quote as 'Mutual Aid - CA 20 25' Limit is missing"
            //    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.MutualAidCA2025RatingBasis == "Flat Charge"
            //    , () =>
            //    {
            //        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //        .AutoLiabilityOptionalCoveragesModel.MutualAidCA2025UnModifiedPremium)
            //        .NotEqual(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityMutualAidCA2025UnModifiedPremiumMissing);
            //    });

            //    //122)If 'Mutual Aid - CA 20 25' is received by rater for not appicable states   
            //    //Cannot Rate the quote as 'Mutual Aid - CA 20 25' is not applicable for the selected 'State'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //     .AutoLiabilityOptionalCoveragesModel.MutualAidCA2025Limit)
            //     .Must((modelObject, value) => CheckAutoApplicableOptionalCoverage(modelObject, "Lessor - Additional Insured And Loss Payee - CA 20 01"))
            //     .WithMessage(Resources.ErrorMessages.InputAutoLiabilityMutualAidCA2025LimitNotApplicableForStates);

            //    //123)If 'Mutual Aid - CA 20 25' Limit is not received by the rater
            //    //Cannot rate the quote as 'Limit' is necessary for the Coverage 'Mutual Aid - CA 20 25'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.MutualAidCA2025Limit)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityMutualAidCA2025LimitNotApplicable);

            //    //124)If 'Mutual Aid - CA 20 25' deductible is not received by the rater
            //    //Cannot rate the quote as 'Deductible' is necessary for the coverage Mutual Aid - CA 20 25'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //   .AutoLiabilityOptionalCoveragesModel.MutualAidCA2025Deductible)
            //   .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityMutualAidCA2025DeductibleNotApplicable);

            //    //125)If 'Mutual Aid - CA 20 25' Rate is received by the rater
            //    //Cannot rate the quote as 'Rate' is not applicable for the Coverage 'Mutual Aid - CA 20 25'
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //    .AutoLiabilityOptionalCoveragesModel.MutualAidCA2025Rate)
            //    .Equal(0).WithMessage(Resources.ErrorMessages.InputAutoLiabilityMutualAidCA2025RateNotApplicable);

            //    //TODO
            //    //126)If 'Lessor - Additional Insured And Loss Payee - CA 20 01' Description is received by the rater
            //    //Cannot rate the quote as 'Description' is not applicable for the Coverage 'Mutual Aid - CA 20 25'



            //    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //     .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels != null
            //      && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //     .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels.Count > 0
            //     , () =>
            //     {
            //         //127)If 'Rating Basis' = 'per 1,000 of limit' & 'Limit' is not received by the rater "
            //         //Cannot Rate the quote as Other Coverage Limit is missing."
            //         string errorMessageRatingBasis1000Limit = string.Empty;
            //         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //         .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels)
            //         .Must((modelObject, value) =>
            //          CheckForOptionalCoverageOtherLimit(modelObject, ref errorMessageRatingBasis1000Limit, "per 1000 of limit"))
            //         .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityAutoLiabilityOptionalOtherCoverageInputModelsLimitRequired + errorMessageRatingBasis1000Limit);

            //         //128)If 'Rating Basis' = 'per 1,000 of limit' & 'Rate' is not received by the rater
            //         //Cannot Rate the quote as Other Coverage Rate is missing.
            //         string errorMessageRatingBasis1000Rate = string.Empty;
            //         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //         .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels)
            //         .Must((modelObject, value) =>
            //          CheckForOptionalCoverageOtherRate(modelObject, ref errorMessageRatingBasis1000Rate, "per 1000 of limit"))
            //         .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityAutoLiabilityOptionalOtherCoverageInputModelsRateRequired + errorMessageRatingBasis1000Rate);

            //         //129)If 'Rating Basis' = 'per 1,00 of limit' & 'Limit' is not received by the rater "
            //         //Cannot Rate the quote as Other Coverage Limit is missing."
            //         string errorMessageRatingBasis100Limit = string.Empty;
            //         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //         .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels)
            //         .Must((modelObject, value) =>
            //          CheckForOptionalCoverageOtherLimit(modelObject, ref errorMessageRatingBasis100Limit, "per 100 of limit"))
            //         .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityAutoLiabilityOptionalOtherCoverageInputModelsLimitRequired + errorMessageRatingBasis100Limit);

            //         //130)If 'Rating Basis' = 'per 1,00 of limit' & 'Rate' is not received by the rater	
            //         //Cannot Rate the quote as Other Coverage Rate is missing.
            //         string errorMessageRatingBasis100Rate = string.Empty;
            //         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //         .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels)
            //         .Must((modelObject, value) =>
            //          CheckForOptionalCoverageOtherRate(modelObject, ref errorMessageRatingBasis100Rate, "per 1000 of limit"))
            //         .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityAutoLiabilityOptionalOtherCoverageInputModelsRateRequired + errorMessageRatingBasis100Rate);

            //         //131)If 'Rating Basis' = 'No charge' & 'Limit' is not received by the rater
            //         //Cannot Rate the quote as Other Coverage Limit is missing.
            //         string errorMessageRatingBasisNochargeLimit = string.Empty;
            //         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //         .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels)
            //         .Must((modelObject, value) =>
            //          CheckForOptionalCoverageOtherLimit(modelObject, ref errorMessageRatingBasisNochargeLimit, "No charge"))
            //         .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityAutoLiabilityOptionalOtherCoverageInputModelsLimitRequired + errorMessageRatingBasisNochargeLimit);

            //         //132) If 'Rating Basis' = 'No charge' & 'Rate' is received by the rater
            //         // Cannot Rate the quote as Other Coverage Rate is not applicable when 'Rating Basis' = 'No Charge'
            //         string errorMessageRatingBasisNochargeRate = string.Empty;
            //         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //         .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels)
            //         .Must((modelObject, value) =>
            //          CheckForOptionalCoverageOtherRate(modelObject, ref errorMessageRatingBasisNochargeRate, "No charge"))
            //         .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityAutoLiabilityOptionalOtherCoverageInputModelsRateNochargeRequired + errorMessageRatingBasisNochargeRate);


            //         //133) If 'Rating Basis' = 'Flat charge' & 'Limit' is not received by the rater
            //         // Cannot Rate the quote as Other Coverage Limit is missing.
            //         string errorMessageRatingBasisFlatChargeLimit = string.Empty;
            //         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //         .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels)
            //         .Must((modelObject, value) =>
            //          CheckForOptionalCoverageOtherLimit(modelObject, ref errorMessageRatingBasisFlatChargeLimit, "Flat charge"))
            //         .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityAutoLiabilityOptionalOtherCoverageInputModelsLimitRequired + errorMessageRatingBasisFlatChargeLimit);

            //         //134)If 'Rating Basis' = 'Flat charge' & 'Rate' is received by the rater
            //         //Cannot Rate the quote as Other Coverage Rate is Not Applicable when 'Rating Basis' = 'Flat Charge'
            //         string errorMessageRatingBasisFlatChargeRate = string.Empty;
            //         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //         .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels)
            //         .Must((modelObject, value) =>
            //          CheckForOptionalCoverageOtherRate(modelObject, ref errorMessageRatingBasisFlatChargeRate, "Flat Charge"))
            //         .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityAutoLiabilityOptionalOtherCoverageInputModelsRateFlatChargeRequired + errorMessageRatingBasisFlatChargeRate);

            //         // 135)If 'Rating Basis' = 'Flat charge' & 'Premium' is not received by the rater
            //         // Cannot Rate the quote as Other Coverage Permium is missing
            //         string errorMessageRatingBasisFlatChargePremium = string.Empty;
            //         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
            //         .AutoLiabilityOptionalCoveragesModel.AutoLiabilityOptionalOtherCoverageInputModels)
            //         .Must((modelObject, value) =>
            //          CheckForOptionalCoverageOtherPremium(modelObject, ref errorMessageRatingBasisFlatChargePremium, "Flat Charge"))
            //         .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityAutoLiabilityOptionalOtherCoverageInputModelsPremiumRequired + errorMessageRatingBasisFlatChargePremium);

            //         // TODO
            //         //136)If 'Rating Basis' is missing when 'Other' coverage is selected
            //         //Cannot Rate the quote as 'Rating Basis' is missing

            //         // TODO
            //         //137)If 'Description ' is not received by the Rater when Other Coverage is selected
            //         //Cannot Rate the quote as Description is mandatory



            //     });
            //});
            //// TODO
            ////138)If 'Rate' is received by the rater for other than STATE = MI
            ////Cannot Rate the quote as 'MI MCCA Assessment' is not applicable for the selected 'State'

            //// TODO
            ////140)If 'Rate' is received by the rater for Other than State = NY
            ////Cannot Rate the quote as 'NY Motor Vehicle Law Enforcement Fee' is not applicable for the selected 'State'

            //// TODO
            ////141)If 'Class Code' is not received by the rater and State Code = 'NY'
            ////Cannot Rate the quote as 'Class Code' is required for calculating 'NY Motor Vehicle Law Enforcement Fee'

            #endregion

            //142) If 'Base Rate' Incorrectly received by the rater i.e.not in the range of lookup
            // Cannot Rate the quote as 'Base Rate' entered is not in the allowed range
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.NonEmergencyUnitsBaseRate >= 0, () =>
            {
                string errorNonEmergencyUnitsBaseRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.NonEmergencyUnitsBaseRate)
                    .Must((modelObject, value) => CheckAutoBaseRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.NonEmergencyUnitsBaseRate, modelObject, "Non Emergency", out errorNonEmergencyUnitsBaseRate))
                    .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityBaseRateNotInRange);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.EmergencyUnitsBaseRate >= 0, () =>
            {
                string errorEmergencyUnitsBaseRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.EmergencyUnitsBaseRate)
                    .Must((modelObject, value) => CheckAutoBaseRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.EmergencyUnitsBaseRate, modelObject, "Emergency", out errorEmergencyUnitsBaseRate))
                    .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityBaseRateNotInRange);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BusesBaseRate >= 0, () =>
            {
                string errorBusesBaseRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BusesBaseRate)
                    .Must((modelObject, value) => CheckAutoBaseRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BusesBaseRate, modelObject, "Buses", out errorBusesBaseRate))
                    .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityBaseRateNotInRange);
            });

            //143) If 'Population / ADA' Is not received by the rater
            //Cannot Rate the quote as 'Population / ADA' is Mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .NotNull()
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPopulationADARequired);

            //144) If 'Population / ADA' entered is greater than 99999999
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
            .LessThanOrEqualTo(99999999)
            .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPopulationADAOutOfRange);

            //146)When 'IRPM Factor' entered is not within the lookup columns range
            //Cannot Rate the quote as 'IRPM' value is invalid
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.IRPMRate).ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckRangeForValue(Math.Round((modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.IRPMRate), 2), "IRPM", modelObject))
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityIRPMRateNotInRange);

            //148)When 'Other Mod Factor' entered is not within the lookup columns range
            //Cannot Rate the quote as 'Other Mod Factor' value is invalid
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.OtherModRate).ScalePrecision(4, 15)
             .Must((modelObject, value) =>
             CheckRangeForValue(Math.Round((modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.OtherModRate), 2), "OtherMod", modelObject)).
             WithMessage(Resources.ErrorMessages.InputAutoLiabilityOtherModRateNotInRange);

            //149) If 'Class Code' and 'Rating Group' doesnot match
            // Cannot Rate the quote as 'Class Code' & 'Rating Group' doesnot match
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel != null &&
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel.Count > 0, () =>
            {
                string errorClassCodeRatingGroup = Resources.ErrorMessages.InputAutoLiabilityScheduleRatingInputModelClassCodeRatingGroupMissing;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel)
                    .Must((modelObject, value) =>
                    CheckClassCodeWithRatingGroupValidation(modelObject, ref errorClassCodeRatingGroup))
                    .WithMessage(x => errorClassCodeRatingGroup);
            });

            //150) 'Location Type' is not received by the rater
            //Cannot Rate the quote as 'Location Type' is Mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.LocationType)
               .NotEmpty()
               .WithMessage(Resources.ErrorMessages.InputAutoLiabilityLocationTypeRequired);

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel != null &&
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel.Count > 0, () =>
            {
                //151)If 'Rating Group' is not received by the Rater when Vehicle Array is received by the Rater
                //Cannot Rate the quote as 'Rating Group' is Mandatory
                string errorMessageRatingGroup = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel)
                    .Must((modelObject, value) =>
                    CheckRatingGroups(modelObject, ref errorMessageRatingGroup))
                    .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityRatingGroupRequired + errorMessageRatingGroup);

                //153)If Class Code recveived is not in the lookup table
                //Cannot Rate the quote as 'Class Code' is not Valid
                string errorClassCode = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel)
                    .Must((modelObject, value) =>
                    CheckRatingGroups(modelObject, ref errorClassCode))
                    .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityClassCodeRequired + errorClassCode);


            });

            When(reg =>
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.NonEmergencyUnitsCount > 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.EmergencyUnitsCount > 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BusesCount > 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.TrailersCount > 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.NonEmergencyPIPUnitsCount > 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.EmergencyPIPUnitsCount > 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BusesPIPUnitsCount > 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.NonEmergencyMedPayUnitsCount > 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.EmergencyMedPayUnitsCount > 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.BusesMedPayUnitsCount > 0, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned)
                    .Must((modelObject, value) => CheckForValue(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned))
                    .WithMessage(Resources.ErrorMessages.InputAutoLiabilityHNOOnlyCanNotRate);

            });
            #endregion
        }

        public bool IsModelValid(RaterFacadeModel model)
        {
            if (model != null && model.RaterInputFacadeModel.LineOfBusiness != null)
            {
                if (model.RaterInputFacadeModel.LineOfBusiness.Auto == true && model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel == null)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckForHiredAndNonOwnedRate(RaterFacadeModel model)
        {
            // to do
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.HiredAndNonOwned.ToUpper() == "HNO ONLY")
            {

            }
            return true;
        }

        public bool UninsuredAndUninsuredBIValidation(RaterFacadeModel model)
        {
            List<string> stateToCheck = new List<string>() { "IN", "MS" };
            if (!string.IsNullOrEmpty(model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UnderinsuredLimit)
           && !string.IsNullOrEmpty(model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UninsuredBIPDLimit)
           && stateToCheck.Contains(model.RaterInputFacadeModel.PolicyHeaderModel.State))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool UninsuredUMUIMStacking(RaterFacadeModel model, List<string> stateToCheck)
        {
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.UMUIMStacking
           && !stateToCheck.Contains(model.RaterInputFacadeModel.PolicyHeaderModel.State))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool CheckForMinMaxValueLiabilityLimitRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var autoLiabilityInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;

            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetAutoLimitFactor(policyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, autoLiabilityInputModel.LimitType,
                autoLiabilityInputModel.LiabilityLimit, policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                message = autoLiabilityInputModel.LimitType + " - " + autoLiabilityInputModel.LiabilityLimit + " range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value && dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    if (dataTable.Rows[0]["DefaultRate"] != DBNull.Value)
                    {
                        if (valueTocheck == Convert.ToDecimal(dataTable.Rows[0]["DefaultRate"]))
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = autoLiabilityInputModel.LimitType + " - " + autoLiabilityInputModel.LiabilityLimit + " Min range does not exist.";
                    flag = false;
                }
                else if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = autoLiabilityInputModel.LimitType + " - " + autoLiabilityInputModel.LiabilityLimit + " Max range does not exist.";
                    flag = false;
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                    if (valueTocheck >= minValue && valueTocheck <= maxValue)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }

            return flag;
        }

        public bool CheckForMinMaxValueAutoApplicableDeductible(RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var autoLiabilityInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetAutoApplicableDeductible(policyHeaderModel.State, model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, autoLiabilityInputModel.Deductible_SIR,
                autoLiabilityInputModel.Retention, policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                message = "Value does not exist";
            }
            else
            {
                if (dataTable.Rows.Count > 0)
                {
                    flag = Convert.ToBoolean(dataTable.Rows[0]["IsApplicable"]);
                }
                else
                {
                    flag = false;
                }
            }

            return flag;
        }

        public bool CheckAutoApplicableMedPayState(RaterFacadeModel model, string tocheckValue)
        {
            bool returnFlag = false;
            if (!string.IsNullOrEmpty(tocheckValue))
            {
                returnFlag = this.DataAccess.GetAutoApplicableMedPay(model.RaterInputFacadeModel.PolicyHeaderModel.State,
                    model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, "Medical Payments", model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
            }
            else
            {
                return returnFlag = true;
            }

            return returnFlag;
        }

        public bool CheckAutoApplicableUMCoverageState(RaterFacadeModel model, string checkCoverage, string limitval)
        {
            bool returnFlag = false;
            if (!string.IsNullOrEmpty(limitval))
            {
                if (limitval.ToUpper() != "EXCLUDED")
                {
                    returnFlag = this.DataAccess.GetAutoApplicableUMCoverage(model.RaterInputFacadeModel.PolicyHeaderModel.State,
            model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, checkCoverage, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                }
                else
                {
                    returnFlag = true;
                }

            }
            else
            {
                returnFlag = true;
            }
            return returnFlag;
        }

        public bool CheckAutoApplicableUIMCoverageState(RaterFacadeModel model, string checkCoverage, string limitval)
        {
            bool returnFlag = false;
            if (!string.IsNullOrEmpty(limitval))
            {
                if (limitval.ToUpper() != "EXCLUDED")
                {
                    returnFlag = this.DataAccess.GetAutoApplicableUIMCoverage(model.RaterInputFacadeModel.PolicyHeaderModel.State,
            model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, checkCoverage, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

                }
                else
                {
                    returnFlag = true;
                }

            }
            else
            {
                returnFlag = true;
            }
            return returnFlag;
        }

        public bool CheckAutoApplicableUIMCoverageStateBool(RaterFacadeModel model, string checkCoverage, bool limitval)
        {
            bool returnFlag = false;
            if (limitval)
            {
                returnFlag = this.DataAccess.GetAutoApplicableUMCoverage(model.RaterInputFacadeModel.PolicyHeaderModel.State,
             model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, checkCoverage, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);

            }
            else
            {
                returnFlag = true;
            }
            return returnFlag;
        }

        public bool CheckAutoApplicablePIPCoverage(RaterFacadeModel model, string checkCoverage, string valuecheck)
        {
            bool returnFlag = false;
            if (!string.IsNullOrEmpty(valuecheck))
            {
                if (valuecheck.ToUpper() != "EXCLUDED")
                {
                    returnFlag = this.DataAccess.GetAutoApplicablePIPCoverage(model.RaterInputFacadeModel.PolicyHeaderModel.State,
                    model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, checkCoverage, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                }
                else
                {
                    returnFlag = true;
                }
            }
            else
            {
                returnFlag = true;
            }
            return returnFlag;
        }

        public bool CheckAutoApplicablePIPCoverage(RaterFacadeModel model, string checkCoverage, bool valuecheck)
        {
            bool returnFlag = false;
            if (valuecheck)
            {
                returnFlag = this.DataAccess.GetAutoApplicablePIPCoverage(model.RaterInputFacadeModel.PolicyHeaderModel.State,
                model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, checkCoverage, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
            }
            else
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public bool CheckAutoApplicablePIPCoverage(RaterFacadeModel model, string checkCoverage, int valuecheck)
        {
            bool returnFlag = false;
            if (valuecheck != 0)
            {
                returnFlag = this.DataAccess.GetAutoApplicablePIPCoverage(model.RaterInputFacadeModel.PolicyHeaderModel.State,
                model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, checkCoverage, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
            }
            else
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public bool CheckAutoApplicableOptionalCoverage(RaterFacadeModel model, string checkCoverage)
        {
            bool returnFlag = false;
            returnFlag = this.DataAccess.GetAutoApplicableOptionalCoverage(model.RaterInputFacadeModel.PolicyHeaderModel.State,
             model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, checkCoverage, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
            return returnFlag;
        }

        public bool CheckAutoApplicableSurcharge(RaterFacadeModel model, string checkCoverage)
        {
            bool returnFlag = false;
            returnFlag = this.DataAccess.GetAutoApplicableSurcharge(model.RaterInputFacadeModel.PolicyHeaderModel.State,
             model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness, checkCoverage, model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate); ;
            return returnFlag;
        }

        public bool CheckForOptionalCoverageOtherLimit(RaterFacadeModel model, ref String mess, string checkLimit)
        {

            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
                 .AutoLiabilityOptionalCoverageInputModel.AutoLiabilityOptionalOtherCoverageInputModels;
            bool valueToReturn = false;
            //int index = 1;
            //String indexMsg = string.Empty;
            if (checkModelList.Count > 0)
            {
                foreach (var item in checkModelList)
                {
                    if (item.OtherCoverageRatingBasis == checkLimit && item.OtherCoverageLimit != null)
                    {
                        valueToReturn = true;
                    }
                    //else
                    //{
                    //    indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    //}
                }
            }
            //mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }

        public bool CheckForOptionalCoverageOtherRate(RaterFacadeModel model, ref String mess, string checkLimit)
        {

            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
                 .AutoLiabilityOptionalCoverageInputModel.AutoLiabilityOptionalOtherCoverageInputModels;
            bool valueToReturn = false;
            //int index = 1;
            //String indexMsg = string.Empty;
            if (checkModelList.Count > 0)
            {
                foreach (var item in checkModelList)
                {
                    if (item.OtherCoverageRatingBasis == checkLimit)
                    {
                        valueToReturn = true;
                    }
                    //else
                    //{
                    //    indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    //}
                }
            }
            //mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }


        public bool CheckForOptionalCoverageOtherPremium(RaterFacadeModel model, ref String mess, string checkLimit)
        {

            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel
                 .AutoLiabilityOptionalCoverageInputModel.AutoLiabilityOptionalOtherCoverageInputModels;
            bool valueToReturn = false;
            //int index = 1;
            //String indexMsg = string.Empty;
            if (checkModelList.Count > 0)
            {
                foreach (var item in checkModelList)
                {
                    if (item.OtherCoverageRatingBasis == checkLimit && item.OtherCoveragePremium != null)
                    {
                        valueToReturn = true;
                    }
                    //else
                    //{
                    //    indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    //}
                }
            }
           // mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }

        public bool CheckRangeForValue(decimal valueTocheck, string factorType, RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var InputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;
            DataTable dataTable = null;
            bool flag = false;

            dataTable = this.DataAccess.GetMinMaxValueForFactor(policyHeaderModel.State, policyHeaderModel.PrimaryClass, InputModel.LineOfBusiness, factorType, policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                throw new Exception(factorType + " range does not exist.");
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    throw new Exception(factorType + " Min range does not exist.");
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    throw new Exception(factorType + " Max range does not exist.");
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }

            return flag;
        }


        public bool CheckClassCode(RaterFacadeModel model, ref String mess)
        {
            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel;
            bool valueToReturn = false;
            //int index = 1;
            //String indexMsg = string.Empty;
            if (checkModelList.Count > 0)
            {
                foreach (var item in checkModelList)
                {
                    if (!string.IsNullOrEmpty(item.ClassCode))
                    {
                        valueToReturn = true;
                    }
                    //else
                    //{
                    //    indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    //}
                }
            }
            //mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }
        public bool CheckMedPayAggregate(RaterFacadeModel model)
        {
            bool returnFlag = true;
            var InputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;
            if (InputModel.MedicalPaymentsLimit != "No Coverage" && !string.IsNullOrEmpty(InputModel.MedicalPaymentsLimit) && Convert.ToInt16(InputModel.MedPayAggregate)
             < Convert.ToInt16(InputModel.MedicalPaymentsLimit))
            {
                returnFlag = false;
            }
            return returnFlag;
        }

        public bool CheckForValue(string texttocheck)
        {

            if (texttocheck.ToUpper() == "HNO ONLY")
            {
                return false;
            }
            else
            {
                return true;
            }

        }
        public bool CheckRatingGroups(RaterFacadeModel model, ref String mess)
        {
            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel;
            bool valueToReturn = false;
            //int index = 1;
            //String indexMsg = string.Empty;
            if (checkModelList.Count > 0)
            {
                foreach (var item in checkModelList)
                {
                    if (!string.IsNullOrEmpty(item.RatingGroup))
                    {
                        valueToReturn = true;
                    }
                    //else
                    //{
                    //    indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    //}
                }
            }
            //mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }

        public bool CheckClassCodeWithRatingGroupValidation(RaterFacadeModel model, ref string errroMessage)
        {
            bool valueToReturn = true;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            bool returnFlag = true;
            //int index = 1;
            //String indexmess = string.Empty;
            var collectionList = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoScheduleVehiclesDetailsInputModel;
            foreach (var item in collectionList)
            {
                returnFlag = this.DataAccess.GetAutoApplicableClassCode(model.RaterInputFacadeModel.PolicyHeaderModel.State,
                model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel.LineOfBusiness,
                item.ClassCode,
                item.RatingGroup,
                model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                if (!returnFlag)
                {
                    valueToReturn = false;
                   // indexmess = !string.IsNullOrEmpty(indexmess) ? (indexmess + "," + index) : index.ToString();
                }
              //  index++;
            }
          // errroMessage = !string.IsNullOrEmpty(indexmess) ? (errroMessage + " at indexes [" + indexmess + "]") : errroMessage;
            return valueToReturn;
        }

        public bool CheckAutoBaseRate(decimal valueTocheck, RaterFacadeModel model, string ratingGroup,
            out string errroMessage)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var InputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.NY.AutoLiabilityInputModel;
            DataTable dataTable = null;
            bool flag = false;
            errroMessage = string.Empty;
            dataTable = this.DataAccess.GetAutoBaseRate(policyHeaderModel.State, policyHeaderModel.PrimaryClass, InputModel.LineOfBusiness, ratingGroup, policyHeaderModel.LocationType, policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                errroMessage = ratingGroup + " range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value && dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    if (dataTable.Rows[0]["BaseRate"] != DBNull.Value)
                    {
                        if (valueTocheck == Convert.ToDecimal(dataTable.Rows[0]["BaseRate"]))
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    errroMessage = ratingGroup + " Min range does not exist.";
                    flag = false;
                }
                else if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    errroMessage = ratingGroup + " Max range does not exist.";
                    flag = false;
                }

                else if (string.IsNullOrEmpty(errroMessage))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                    if (valueTocheck >= minValue && valueTocheck <= maxValue)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            return flag;
        }



        public bool checkValueStringIsNullOrEmpty(string value)
        {
            bool returnFlag = true;
            if (!string.IsNullOrEmpty(value))
            {
                returnFlag = false;
            }
            return returnFlag;
        }
    }
}
