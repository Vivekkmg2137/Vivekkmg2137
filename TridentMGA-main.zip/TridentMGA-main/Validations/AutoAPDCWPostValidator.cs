﻿
namespace Validations
{
    using AutoMapper;
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Microsoft.Extensions.Configuration;
    using Models.ApiModels;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class AutoAPDCWPostValidator: AbstractValidator<RaterFacadeModel>
    {
        private AutoPhysicalDamageDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        readonly Microsoft.Extensions.Configuration.IConfiguration configuration;

        private readonly IMapper _mapper;

        public AutoAPDCWPostValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.Logger = logger;
            this.DataAccess = new AutoPhysicalDamageDataAccess(this.configuration, this.Logger);
        }

    }
}
