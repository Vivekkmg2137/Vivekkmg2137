﻿
namespace Validations
{
    using AutoMapper;
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Microsoft.Extensions.Configuration;
    using Models.ApiModels;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Text;
    public class AutoAPDCWPreValidator : AbstractValidator<RaterFacadeModel>
    {
        readonly IConfiguration configuration;
        private AutoPhysicalDamageDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        public AutoAPDCWPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.DataAccess = new AutoPhysicalDamageDataAccess(this.configuration, this.Logger);

            #region Model Validation
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                .Must((modelObject, selectedLineOfBusiness) => IsModelValid(modelObject))
                .WithMessage(x => string.Format("Input JSON is not valid for LOBs"));
            #endregion

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel != null
           && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel.Count > 0, () =>
           {
               //2)If OCN is not received by the rater 
               //Cannot Rate the Quote as 'OCN' is mandatory
               string errorMessageOCN = Resources.ErrorMessages.InputAutoLiabilityScheduleRatingInputModelOCNMissing;
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel)
                   .Must((modelObject, value) => CheckForAutoLiabilityScheduleRatingInputModelOCN(modelObject, ref errorMessageOCN)).
                   WithMessage(x => errorMessageOCN);

               //3)If Valuation is not received by the rater
               //Cannot Rate the Quote as 'Valuation' is mandatory
               string errorMessageValuation = Resources.ErrorMessages.InputAutoLiabilityScheduleRatingInputModelValuationMissing;
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel)
                    .Must((modelObject, value) => CheckForAutoLiabilityScheduleRatingInputModelValuation(modelObject, ref errorMessageValuation)).
                    WithMessage(x => errorMessageValuation);

               //If 'Rating Group' is not received by the Rater when Vehicle Array is received by the Rater  
               //Cannot Rate the quote as 'Rating Group' is Mandatory
               string errorMessageRatingGroup = Resources.ErrorMessages.InputAutoLiabilityScheduleRatingInputModelRatingGroupMissing;
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel)
                    .Must((modelObject, value) =>
                    CheckForAutoLiabilityScheduleRatingInputModelRatingGroup(modelObject, ref errorMessageRatingGroup)).
                    WithMessage(x => errorMessageRatingGroup);

               //If Class Code recveived is not in the lookup table
               //Cannot Rate the quote as 'Class Code' is not Valid
               string errorMessageclasscode = Resources.ErrorMessages.InputAutoLiabilityScheduleRatingInputModelClassCodeMissing;
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel)
                    .Must((modelObject, value) =>
                    CheckForAutoLiabilityScheduleRatingInputModelClassCode(modelObject, ref errorMessageclasscode)).
                    WithMessage(x => errorMessageclasscode);

               //If Class Code received is not matching with the Rating Group received
               //Cannot Rate the quote as 'Class Code' & 'Rating Group' dosnot match
               string errorMessageclasscodeRatingGroup = Resources.ErrorMessages.InputAutoLiabilityScheduleRatingInputModelClassCodeRatingGroupMissing;
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel)
                    .Must((modelObject, value) =>
                    CheckForAutoLiabilityScheduleRatingInputModelClassCodeRatingGroup(modelObject, ref errorMessageclasscodeRatingGroup)).
                    WithMessage(x => errorMessageclasscodeRatingGroup);
           });

            //If 'Base Rate' Incorrectly received by the rater i.e. not in the range of lookup	
            //Cannot Rate the quote as 'Base Rate' entered is not in the allowed range
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.CompBaseRate >= 0, () =>
            {
                string errorCompBaseRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.CompBaseRate)
                    .Must((modelObject, value) => CheckForMinMaxValueBaseRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.CompBaseRate, modelObject, "Comprehensive", out errorCompBaseRate))
                    .WithMessage(x => !string.IsNullOrEmpty(errorCompBaseRate) ? errorCompBaseRate : Resources.ErrorMessages.InputAutoPhysicalDamageComprehensiveRateNotInRange);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.CollisionBaseRate >= 0, () =>
            {
                string errorCollissionBaseRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.CollisionBaseRate)
                    .Must((modelObject, value) => CheckForMinMaxValueBaseRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.CollisionBaseRate, modelObject, "Collision", out errorCollissionBaseRate))
                    .WithMessage(x => !string.IsNullOrEmpty(errorCollissionBaseRate) ? errorCollissionBaseRate : Resources.ErrorMessages.InputAutoPhysicalDamageCollisionRateNotInRange);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.SpecCauseofLossBaseRate >= 0, () =>
            {
                string errorSpecCauseofLossBaseRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.SpecCauseofLossBaseRate)
                    .Must((modelObject, value) => CheckForMinMaxValueBaseRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.SpecCauseofLossBaseRate, modelObject, "Specified Causes of Loss", out errorSpecCauseofLossBaseRate))
                    .WithMessage(x => !string.IsNullOrEmpty(errorSpecCauseofLossBaseRate) ? errorSpecCauseofLossBaseRate : Resources.ErrorMessages.InputAutoPhysicalDamageSpecCauseofLossBaseRateNotInRange);
            });

            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .NotNull()
                .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPopulationADARequired);

            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
            .LessThanOrEqualTo(99999999)
            .WithMessage(Resources.ErrorMessages.InputAutoLiabilityPopulationADAOutOfRange);

            string errorIRPMRateMessage = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.IRPMRate).ScalePrecision(4, 15)
                  .Must((modelObject, value) =>
                  CheckRangeForValue(Math.Round((modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.IRPMRate), 2), "IRPM", modelObject, out errorIRPMRateMessage)).
                  WithMessage(Resources.ErrorMessages.InputAutoLiabilityIRPMRateNotInRange);

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.OtherModRate).ScalePrecision(4, 15)
                 .Must((modelObject, value) =>
                 CheckRangeForValue(Math.Round((modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.OtherModRate), 2), "OtherMod", modelObject, out errorIRPMRateMessage)).
                 WithMessage(Resources.ErrorMessages.InputAutoLiabilityOtherModRateNotInRange);
        }

        public bool IsModelValid(RaterFacadeModel model)
        {

            if (model != null && model.RaterInputFacadeModel.LineOfBusiness != null)
            {
                if (model.RaterInputFacadeModel.LineOfBusiness.Auto && model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW != null && model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.HasAutoPhysicalDamage && model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel == null)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }
        }


        public bool CheckRangeForValue(decimal valueTocheck, string factorType, RaterFacadeModel model, out string errorMessage)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var InputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel;
            DataTable dataTable = null;
            bool flag = false;
            errorMessage = string.Empty;
            dataTable = this.DataAccess.GetMinMaxValueForFactor(policyHeaderModel.State, policyHeaderModel.PrimaryClass, InputModel.LineOfBusiness, factorType, policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                errorMessage = factorType + " range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    errorMessage = factorType + " Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    errorMessage = factorType + " Max range does not exist.";
                }

                if (string.IsNullOrEmpty(errorMessage))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }



        public bool CheckForAutoLiabilityScheduleRatingInputModelValuation(RaterFacadeModel model, ref String mess)
        {

            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel;
            bool valueToReturn = true;
            //int index = 1;
            //String indexmess = string.Empty;
            if (checkModel != null)
            {
                foreach (var item in checkModel)
                {
                    if (string.IsNullOrEmpty(item.Valuation))
                    {
                        valueToReturn = false;
                       // indexmess = !string.IsNullOrEmpty(indexmess) ? (indexmess + "," + index) : index.ToString();
                    }
                   // index++;
                }
            }

           // mess = !string.IsNullOrEmpty(indexmess) ? (mess + " at indexes [" + indexmess + "]") : mess;
            return valueToReturn;

        }

        public bool CheckForAutoLiabilityScheduleRatingInputModelRatingGroup(RaterFacadeModel model, ref String mess)
        {

            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel;
            bool valueToReturn = true;
            //int index = 1;
            //String indexmess = string.Empty;
            if (checkModel != null)
            {
                foreach (var item in checkModel)
                {
                    if (string.IsNullOrEmpty(item.RatingGroup))
                    {
                        valueToReturn = false;
                        //indexmess = !string.IsNullOrEmpty(indexmess) ? (indexmess + "," + index) : index.ToString();
                    }
                    //index++;
                }
            }

            //mess = !string.IsNullOrEmpty(indexmess) ? (mess + " at indexes [" + indexmess + "]") : mess;
            return valueToReturn;

        }

        public bool CheckForAutoLiabilityScheduleRatingInputModelClassCode(RaterFacadeModel model, ref String mess)
        {

            bool valueToReturn = true;
            //int index = 1;
            //String indexmess = string.Empty;
            bool returnFlag = true;
            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel;
            foreach (var item in checkModel)
            {
                returnFlag = this.DataAccess.GetAutoApplicableClassCode(model.RaterInputFacadeModel.PolicyHeaderModel.State,
                   model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.LineOfBusiness,
                   item.ClassCode,
                   null,
                   model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                if (!returnFlag)
                {
                    valueToReturn = false;
                   // indexmess = !string.IsNullOrEmpty(indexmess) ? (indexmess + "," + index) : index.ToString();
                }
             //   index++;
            }
           // mess = !string.IsNullOrEmpty(indexmess) ? (mess + " at indexes [" + indexmess + "]") : mess;
            return valueToReturn;
        }

        public bool CheckForAutoLiabilityScheduleRatingInputModelClassCodeRatingGroup(RaterFacadeModel model, ref String mess)
        {

            bool valueToReturn = true;
            //int index = 1;
            //String indexmess = string.Empty;
            bool returnFlag = true;
            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel;
            foreach (var item in checkModel)
            {
                returnFlag = this.DataAccess.GetAutoApplicableClassCode(model.RaterInputFacadeModel.PolicyHeaderModel.State,
                   model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.LineOfBusiness,
                   item.ClassCode,
                   item.RatingGroup,
                   model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate);
                if (!returnFlag)
                {
                    valueToReturn = false;
                    //indexmess = !string.IsNullOrEmpty(indexmess) ? (indexmess + "," + index) : index.ToString();
                }
               // index++;
            }
            //mess = !string.IsNullOrEmpty(indexmess) ? (mess + " at indexes [" + indexmess + "]") : mess;
            return valueToReturn;
        }

        public bool CheckForAutoLiabilityScheduleRatingInputModelOCN(RaterFacadeModel model, ref String mess)
        {

            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoScheduleVehiclesDetailsInputModel;
            bool valueToReturn = true;
           // int index = 1;
           // String indexmess = string.Empty;
            if (checkModel != null)
            {
                foreach (var item in checkModel)
                {
                    if (item.OCN == 0)
                    {
                        valueToReturn = false;
                       // indexmess = !string.IsNullOrEmpty(indexmess) ? (indexmess + "," + index) : index.ToString();
                    }
                  //  index++;
                }
            }

            //mess = !string.IsNullOrEmpty(indexmess) ? (mess + " at indexes [" + indexmess + "]") : mess;
            return valueToReturn;
        }

        public bool CheckForMinMaxValueBaseRate(decimal valueTocheck, RaterFacadeModel model, string ratingGroup, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetBaseRate(policyHeaderModel.State, policyHeaderModel.PrimaryClass, model.RaterInputFacadeModel.LineOfBusinessInputModel.Auto.CW.AutoPhysicalDamageInputModel.LineOfBusiness, ratingGroup, policyHeaderModel.LocationType,
                policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                message = ratingGroup + " range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = ratingGroup + " Min range does not exist.";
                    flag = false;
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = ratingGroup + " Max range does not exist.";
                    flag = false;
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }
    }
}
