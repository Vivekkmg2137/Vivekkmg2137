﻿using System;
using System.Globalization;

namespace Validations
{
    public class CommonFluents
    {
        /// <summary>
        /// Validate the input date
        /// </summary>
        /// <param name="inputDate"> Input Date</param>
        /// <returns>bool</returns>
        public static bool ValidateDate(string inputDate)
        {
            // If inputDate not null
            if (!string.IsNullOrEmpty(inputDate))
            {
                DateTime parsedDate;
                bool checkIfDateValid =  DateTime.TryParse(inputDate, out parsedDate);
                if (checkIfDateValid)
                {
                    return true;
                }
                else {
                    return false;
                }
                //SqlDateTime sqlDateTime = System.Data.SqlTypes.SqlDateTime.MinValue.Value;
                //string[] datePattern = { "M/d/yyyy", "MM/dd/yyyy", "MM/dd/yyyy hh:mm:ss tt", "M/d/yyyy hh:mm:ss tt", "MM-dd-yyyy", "M-d-yyyy", "M/dd/yyyy", "MM/d/yyyy", "M-dd-yyyy", "MM-d-yyyy", "M/dd/yyyy h:mm:ss tt", "MM/d/yyyy h:mm:ss tt", "M/d/yyyy h:mm:ss tt", "MM-dd-yyyy hh:mm:ss", "MM/dd/yyyy hh:mm:ss" };

                //if (DateTime.TryParseExact(inputDate, datePattern[0], null, System.Globalization.DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[1], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[2], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[3], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[4], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[5], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[6], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[7], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[8], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[9], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[10], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[11], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[12], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[13], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else if (DateTime.TryParseExact(inputDate, datePattern[14], null, DateTimeStyles.None, out parsedDate) && Convert.ToDateTime(inputDate) > System.Data.SqlTypes.SqlDateTime.MinValue.Value)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}
            }
            return true;
        }

    }
}
