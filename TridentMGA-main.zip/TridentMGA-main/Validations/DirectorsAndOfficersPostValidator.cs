﻿using AutoMapper;
using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Validations
{
    public class DirectorsAndOfficersPostValidator : AbstractValidator<RaterFacadeModel>
    {
        private DirectorsAndOfficersDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        readonly Microsoft.Extensions.Configuration.IConfiguration configuration;

        private readonly IMapper _mapper;
        public DirectorsAndOfficersPostValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.Logger = logger;
            this.DataAccess = new DirectorsAndOfficersDataAccess(this.configuration, this.Logger);
        }
    }
}
