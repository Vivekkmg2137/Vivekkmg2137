﻿using AutoMapper;
using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
namespace Validations
{
    /// <summary>
    /// DirectorsAndOfficersPreValidator
    /// </summary>
    public class DirectorsAndOfficersPreValidator : AbstractValidator<RaterFacadeModel>
    {
        /// <summary>
        /// DataAccess Object
        /// </summary>
        private DirectorsAndOfficersDataAccess _DataAccess { get; set; }

        /// <summary>
        /// Logger Object
        /// </summary>
        protected ILoggingManager _Logger { get; private set; }

        /// <summary>
        /// configuration Object
        /// </summary>
        readonly Microsoft.Extensions.Configuration.IConfiguration configuration;

        /// <summary>
        /// Mapper Object
        /// </summary>
        private readonly IMapper _mapper;

        /// <summary>
        /// DirectorsAndOfficersPreValidator
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public DirectorsAndOfficersPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this._Logger = logger;
            this._DataAccess = new DirectorsAndOfficersDataAccess(this.configuration, this._Logger);

                 
            //step 12 If Liability Limit input field is missing.
            //Cannot Rate the quote as Liability Limit is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.LiabilityLimit).NotNull().
            WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersLiabilityLimitMissing);

            //step 12.1 If Liability Limit input field is missing.
            //Cannot Rate the quote as Aggregate Limit is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.AggregateLimit).NotNull().
            WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersAggregateLimitMissing);

            //If Aggregate Limit entered is less than Liability Limit   
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.AggregateLimit)
                .GreaterThanOrEqualTo(regs => regs.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.LiabilityLimit)
                .WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersLiabilityLimitGreater);

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.LiabilityLimitRate >= 0, () =>
            {
                //If 'Limit Rate' is Incorrectly received by the rater i.e.not in the range of lookup    
                //Cannot Rate the quote as 'Rate' entered is not in the allowed range
                string errorLiabilityLimitRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.LiabilityLimitRate)
                    .Must((modelObject, value) => CheckRangeForLiabilityLimitRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.LiabilityLimitRate,
                                                                                  modelObject,
                                                                                  out errorLiabilityLimitRate))
                    .WithMessage(!string.IsNullOrEmpty(errorLiabilityLimitRate) ?
                                   errorLiabilityLimitRate :
                                   Resources.ErrorMessages.InputDOLiabilityLimitRateInvalid);
            });


            // Step 5 If PolicyType input field is missing. 
            //Cannot Rate the quote as 'Policy Type' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.PolicyType).NotEmpty().
            WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersPolicyTypeMissing);

            // Step 6 If Retro Date input fiDirectorsAndOfficersOptionalOtherCoverageModeleld is missing. 
            //Cannot Rate the quote as 'Retro Date' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.RetroDate).NotNull().
            WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersRetroActiveDateMissing);

            //Step 7 If RetroActive DateGreater entered is less than Liability Limit   
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.RetroDate)
                .LessThanOrEqualTo(regs => regs.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate)
                .WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersRetroActiveDateGreater);

            // Step 8 If Yearsin CM Program input field is missing. 
            //Cannot Rate the quote as 'Yearsin CM Program' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.YearsinCMProgram).NotNull().
            WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersYearInCMProgramMissing);

            // Step 12.2 If Deductible/SIR input field is missing. 
            //Cannot Rate the quote as 'Deductible/SIR' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Deductible_SIR).NotEmpty().
            WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersDeductibleSIRMissing);

            // Step 12.3 If Retention input field is missing. 
            //Cannot Rate the quote as 'Retention' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Retention).NotNull().
            WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersRetentionRateMissing);

            //Step 12.2/ 12.3 If 'Deductible/SIR' is selected as 'Deductible' & 'Retention' entered is not applicable or not as per the lookup values per state 
            //Cannot Rate the Quote as the 'Retention' is not applicable
            When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Deductible_SIR)
                && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Deductible_SIR.ToUpper() == "DEDUCTIBLE" || reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Deductible_SIR.ToUpper() == "SIR"), () =>
            {
                string stringRetention = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Retention)
                    .Must((modelObject, value) => CheckForMinMaxValueApplicableDeductible(modelObject, out stringRetention))
                    .WithMessage(x => !string.IsNullOrEmpty(stringRetention) ? stringRetention : Resources.ErrorMessages.InputDORetentionNotInRange);
            });

            // Step 12.3 If Retention input field is missing.   
            //Cannot Rate the quote as 'Retention' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Retention).NotNull().
            WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersRetentionRateMissing);

            // Step 12.4 If Aggregate Retention input field is missing. 
            //Cannot Rate the quote as 'Aggregate Retention' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.AggregateRetention)
            .NotNull().WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersAggregateRetentionMissing);

            // Step 9 If Type input field is missing. 
            //Cannot Rate the quote as 'Type' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Type)
            .NotEmpty().WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersTypeMissing);

            // Step 10 If Expense input field is missing. 
            //Cannot Rate the quote as 'Expense' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Expense)
            .NotEmpty().WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersExpenseMissing);

            // Step 7 If Exposure input field is missing. 
            //Cannot Rate the quote as 'Exposure' is Missing
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.Exposure)
            .NotNull().WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersExposureRateMissing);

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel != null
                && reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected == true, () =>
            {
                //If this coverage is checked on the UI for not applicable states
                //when JSON tag 'Suppl. Extended Reporting PeriodIsSelected' = True
                //Cannot Rate the quote as 'Suppl. Extended Reporting Period' is not applicable for the selected State
                string stringSupplExtendedReportingPeriodIsSelectedMessage = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                    .Must((modelObject, value) =>
                            CheckApplicableOptionalCoverage(modelObject,
                                                             "Suppl. Extended Reporting Period",
                                                              false,
                                                              out stringSupplExtendedReportingPeriodIsSelectedMessage))
                    .WithMessage(x => !string.IsNullOrEmpty(stringSupplExtendedReportingPeriodIsSelectedMessage) ?
                                        stringSupplExtendedReportingPeriodIsSelectedMessage :
                                        Resources.ErrorMessages.InputDOSupplExtendedReportingNotApplicableForState);

                //If this coverage is checked on the UI for not applicable states & Primary Class Combination
                //when JSON tag 'Suppl. Extended Reporting PeriodIsSelected' = True
                //Cannot Rate the quote as 'Suppl. Extended Reporting Period' is not applicable for the selected State & Primary Class Combination
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.DirectorsAndOfficersOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                    .Must((modelObject, value) =>
                            CheckApplicableOptionalCoverage(modelObject,
                                                       "Suppl. Extended Reporting Period",
                                                       true,
                                                       out stringSupplExtendedReportingPeriodIsSelectedMessage))
                    .WithMessage(x => !string.IsNullOrEmpty(stringSupplExtendedReportingPeriodIsSelectedMessage) ?
                                       stringSupplExtendedReportingPeriodIsSelectedMessage :
                                       Resources.ErrorMessages.InputDOSupplExtendedReportingPeriodWithPrimaryClassNotApplicableForState);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
             .DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel != null
              && reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
             .DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel.Count > 0
             , () =>
             {
                 // If 'Rating Basis' = 'Flat charge' & 'Premium' is not received by the rater
                 // Cannot Rate the quote as Other Coverage Permium is missing
                 //string errorMessageRatingBasisFlatChargePremium = string.Empty;
                 //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
                 //.DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel)
                 //.Must((modelObject, value) =>
                 // CheckForOptionalCoverageOtherPremium(modelObject, ref errorMessageRatingBasisFlatChargePremium, "Flat Charge"))
                 //.WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersOtherCoveragePremiumRequired + errorMessageRatingBasisFlatChargePremium);
                                  
                 // If 'Rating Basis' = 'per 1,000 of limit' & 'Limit' is not received by the rater "
                 //Cannot Rate the quote as Other Coverage Limit is missing."
                 //string errorMessageRatingBasis1000Limit = string.Empty;
                 //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
                 //.DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel)
                 //.Must((modelObject, value) =>
                 // CheckForOptionalCoverageOtherLimit(modelObject, ref errorMessageRatingBasis1000Limit, "per 1000 of limit"))
                 //.WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersOtherCoverageLimitRequired + errorMessageRatingBasis1000Limit);

                 // If 'Rating Basis' = 'per 1,000 of limit' & 'Rate' is not received by the rater
                 //Cannot Rate the quote as Other Coverage Rate is missing.
                 //string errorMessageRatingBasis1000Rate = string.Empty;
                 //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
                 //.DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel)
                 //.Must((modelObject, value) =>
                 // CheckForOptionalCoverageOtherRate(modelObject, ref errorMessageRatingBasis1000Rate, "per 1000 of limit"))
                 //.WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersOtherCoverageRateRequired + errorMessageRatingBasis1000Rate);

                 // If 'Rating Basis' = 'per 1,00 of limit' & 'Limit' is not received by the rater "
                 //Cannot Rate the quote as Other Coverage Limit is missing."
                 //string errorMessageRatingBasis100Limit = string.Empty;
                 //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
                 //.DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel)
                 //.Must((modelObject, value) =>
                 // CheckForOptionalCoverageOtherLimit(modelObject, ref errorMessageRatingBasis100Limit, "per 100 of limit"))
                 //.WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersOtherCoverageLimitRequired + errorMessageRatingBasis100Limit);

                 //130)If 'Rating Basis' = 'per 1,00 of limit' & 'Rate' is not received by the rater	
                 //Cannot Rate the quote as Other Coverage Rate is missing.
                 //string errorMessageRatingBasis100Rate = string.Empty;
                 //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
                 //.DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel)
                 //.Must((modelObject, value) =>
                 // CheckForOptionalCoverageOtherRate(modelObject, ref errorMessageRatingBasis100Rate, "per 100 of rate"))
                 //.WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersOtherCoverageRateRequired + errorMessageRatingBasis100Rate);
 
                 // If 'Rating Basis' = 'No charge' & 'Rate' is received by the rater
                 // Cannot Rate the quote as Other Coverage Rate is not applicable when 'Rating Basis' = 'No Charge'
                 //string errorMessageRatingBasisNochargeRate = string.Empty;
                 //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
                 //.DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel)
                 //.Must((modelObject, value) =>
                 // CheckForNoChargeOtherCoverage(modelObject, ref errorMessageRatingBasisNochargeRate, "No charge"))
                 //.WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersOtherCoverageRateNochargeRequired + errorMessageRatingBasisNochargeRate);



                 //  If 'Rating Basis' is missing when 'Other' coverage is selected
                 // Cannot Rate the quote as 'Rating Basis' is missing
                 string errorMessageRatingBasisMissing = string.Empty;
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
                 .DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel)
                 .Must((modelObject, value) =>
                  CheckForOtherCoverageRatingBasis(modelObject, ref errorMessageRatingBasisMissing, "Rating Basis"))
                 .WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersOtherCoverageRateNochargeRequired + errorMessageRatingBasisMissing);

                 //  If 'Description ' is not received by the Rater when Other Coverage is selected
                 //Cannot Rate the quote as Description is mandatory
                 string errorMessageDescriptionMissing = string.Empty;
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers
                 .DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel)
                 .Must((modelObject, value) =>
                  CheckForOtherCoverageRatingBasis(modelObject, ref errorMessageDescriptionMissing, "Description"))
                 .WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersOtherCoverageRateNochargeRequired + errorMessageDescriptionMissing);

             });


            //If Not received as input by Rater      
            //Cannot Rate the quote as 'Primary Class' is Mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelDirectorsAndOfficersPrimaryClassRequired);

            //If Not received as input by Rater       
            //Cannot Rate the quote as 'Population / ADA' is Mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .NotNull()
                .WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersPopulationADARequired);

            //If 'Population / ADA' entered is greater than 99999999      
            //Cannot Rate the quote as 'Population / ADA' is invalid
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .LessThanOrEqualTo(99999999)
                .WithMessage(x => Resources.ErrorMessages.InputDirectorsAndOfficersPopulationADAOutOfRange);

            //If Not received as input by Rater       
            // Cannot Rate the quote as 'Secondary Class' is Mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelDirectorsAndOfficersSecondaryClassRequired);

            //If Not received as input by Rater      
            //Cannot Rate the quote as 'Location Type' is Mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.LocationType)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelDirectorsAndOfficersLocationTypeRequired);

            //If 'IRPM Factor' entered is not within the lookup columns range 
            //Cannot Rate the quote as 'IRPM' value is invalid
            string errorMessageIRPMFactor = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.IRPMFactor)
                .Must((modelObject, value) =>
                        CheckRangeForValueIRPMRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.IRPMFactor,
                                                    modelObject,
                                                    out errorMessageIRPMFactor))
                .WithMessage(!string.IsNullOrEmpty(errorMessageIRPMFactor) ?
                                errorMessageIRPMFactor :
                                Resources.ErrorMessages.InputDOIRPMFactorInvalid);

            //If 'Other Mod Factor' entered is not within the lookup columns range 
            //Cannot Rate the quote as 'Other Mod Factor' value is invalid
            string errorMessageOtherModFactor = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.OtherModRate)
                .Must((modelObject, value) =>
                        CheckRangeForValueOtherModRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.OtherModRate,
                                                        modelObject,
                                                        out errorMessageOtherModFactor))
                .WithMessage(!string.IsNullOrEmpty(errorMessageOtherModFactor) ?
                                errorMessageOtherModFactor :
                                Resources.ErrorMessages.InputDOOtherModRateInvalid);
        }

        /// <summary>
        /// CheckRangeForLiabilityLimitRate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckRangeForLiabilityLimitRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
            bool flag = false;
            message = string.Empty;
            DataTable dataTable = null;
            dataTable = this._DataAccess.GetLiabilityLimitRateMinimum(policyHeaderModel.State,
                                                                       inputModel.LineOfBusiness,
                                                                       inputModel.LiabilityLimit,
                                                                       policyHeaderModel.PolicyEffectiveDate,
                                                                       policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "LiabilityLimit range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "LiabilityLimit Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "LiabilityLimit Rate Max range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckRangeForValueOtherModRate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckRangeForValueOtherModRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
            bool flag = false;
            message = string.Empty;
            DataTable dataTable = null;
            dataTable = this._DataAccess.GetOtherModRate(policyHeaderModel.State,
                                                        inputModel.LineOfBusiness,
                                                        policyHeaderModel.PolicyEffectiveDate,
                                                        policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "OtherMod range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "OtherMod Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "OtherMod Rate Max range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckRangeForValueIRPMRate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckRangeForValueIRPMRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
            bool flag = false;
            message = string.Empty;
            DataTable dataTable = null;

            dataTable = this._DataAccess.GetIRPMRate(policyHeaderModel.State,
                                                    inputModel.LineOfBusiness,
                                                    policyHeaderModel.PolicyEffectiveDate,
                                                    policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "IRPM Rate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "IRPM Rate Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "IRPM Rate Max range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckForMinMaxValueApplicableDeductible
        /// </summary>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueApplicableDeductible(RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var checkLiabilityInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this._DataAccess.GetAutoApplicableDeductible(policyHeaderModel.State,
                                                                     checkLiabilityInputModel.LineOfBusiness,
                                                                     checkLiabilityInputModel.Deductible_SIR,
                                                                     Convert.ToString(checkLiabilityInputModel.Retention),
                                                                     policyHeaderModel.PolicyEffectiveDate,
                                                                     policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "Value does not exist";
            }
            else
            {
                if (dataTable.Rows.Count > 0)
                {
                    flag = Convert.ToBoolean(dataTable.Rows[0]["IsApplicable"]);
                }
                else
                {
                    flag = false;
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckApplicableOptionalCoverage
        /// </summary>
        /// <param name="model"></param>
        /// <param name="coverage"></param>
        /// <param name="checkprimaryclass"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckApplicableOptionalCoverage(RaterFacadeModel model, string coverage, bool checkprimaryclass, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var checkInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            string paraState = !string.IsNullOrEmpty(policyHeaderModel.State) ? policyHeaderModel.State : StateCodeConstant.CW;
            string paraPrimaryClass = !string.IsNullOrEmpty(policyHeaderModel.PrimaryClass) ? policyHeaderModel.PrimaryClass : "ALL";
            dataTable = this._DataAccess.GetProfLinesApplicableOptionalCoverage(paraState,
                                                                                (checkprimaryclass ? paraPrimaryClass : null),
                                                                                checkInputModel.LineOfBusiness,
                                                                                coverage,
                                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                                policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "OptionalCoverage " + coverage + " does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["IsApplicable"] != DBNull.Value)
                {
                    flag = Convert.ToBoolean(dataTable.Rows[0]["IsApplicable"]);
                }

            }

            return flag;
        }
        public bool CheckForOptionalCoverageOtherPremium(RaterFacadeModel model, ref String mess, string checkLimit)
        {
            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.
                                 DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel;
            bool valueToReturn = false;
            int index = 1;
            String indexMsg = string.Empty;
            if (checkModelList.Count > 0)
            {
                foreach (var item in checkModelList)
                {
                    if (item.OtherCoverageRatingBasis == checkLimit && item.OtherCoverageUnmodifiedPremium != null)
                    {
                        valueToReturn = true;
                    }
                    else
                    {
                        indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    }
                    index++;
                }
            }
            mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }

        public bool CheckForOptionalCoverageOtherLimit(RaterFacadeModel model, ref String mess, string checkLimit)
        {

            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.
                                 DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel;
            bool valueToReturn = false;
            int index = 1;
            String indexMsg = string.Empty;
            if (checkModelList.Count > 0)
            {
                foreach (var item in checkModelList)
                {
                    if (item.OtherCoverageRatingBasis == checkLimit && item.OtherCoverageLimit != null)
                    {
                        valueToReturn = true;
                    }
                    else
                    {
                        indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    }
                    index++;
                }
            }
            mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }

        public bool CheckForOptionalCoverageOtherRate(RaterFacadeModel model, ref String mess, string checkLimit)
        {

            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.
                                 DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel;
            bool valueToReturn = false;
            int index = 1;
            String indexMsg = string.Empty;
            if (checkModelList.Count > 0)
            {
                foreach (var item in checkModelList)
                {

                    if (item.OtherCoverageRatingBasis.ToUpper() == checkLimit.ToUpper() && item.OtherCoverageRate != null)
                    {
                        valueToReturn = true;
                    }                     
                    else
                    {
                        indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    }
                    index++;
                }
            }
            mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }

        public bool CheckForOtherCoverageRatingBasis(RaterFacadeModel model, ref String mess, string checkLimit)
        {

            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.
                                 DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel;
            bool valueToReturn = false;
            int index = 1;
            String indexMsg = string.Empty;
            if (checkModelList.Count > 0) 
            {
                foreach (var item in checkModelList)
                {
                    if (item.OtherCoverageRate >= 0 && !string.IsNullOrEmpty(item.OtherCoverageRatingBasis))
                    {
                        valueToReturn = true;
                    }
                    else
                    {
                        indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    }
                    index++;
                }
            }
            mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }

        public bool CheckForNoChargeOtherCoverage(RaterFacadeModel model, ref String mess, string checkLimit)
        {

            var checkModelList = model.RaterInputFacadeModel.LineOfBusinessInputModel.DirectorsAndOfficers.
                                 DirectorsAndOfficersOptionalCoverageModel.DirectorsAndOfficersOptionalOtherCoverageModel;
            bool valueToReturn = false;
            int index = 1;
            String indexMsg = string.Empty;
            if (checkModelList.Count > 0)
            {
                foreach (var item in checkModelList)
                {
                    if (item.OtherCoverageRate != null)
                    {
                        indexMsg = !string.IsNullOrEmpty(indexMsg) ? (indexMsg + "," + index) : index.ToString();
                    }
                    else
                    {
                        valueToReturn = true;
                    }
                    index++;
                }
            }
            mess = !string.IsNullOrEmpty(indexMsg) ? (mess + "At indexes [" + indexMsg + "]") : mess;
            return valueToReturn;
        }

    }

}
