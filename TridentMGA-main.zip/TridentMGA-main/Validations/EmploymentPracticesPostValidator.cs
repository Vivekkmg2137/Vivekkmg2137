﻿using AutoMapper;
using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;
namespace Validations
{
    public class EmploymentPracticesPostValidator : AbstractValidator<RaterFacadeModel>
    {
        private EmploymentPracticesDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        readonly Microsoft.Extensions.Configuration.IConfiguration configuration;

        private readonly IMapper _mapper;
        public EmploymentPracticesPostValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.Logger = logger;
            this.DataAccess = new EmploymentPracticesDataAccess(this.configuration, this.Logger);
        }

    }
}
