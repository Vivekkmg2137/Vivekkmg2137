﻿using AutoMapper;
using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Linq;

namespace Validations
{
    /// <summary>
    /// EmploymentPracticesPreValidator
    /// </summary>
    public class EmploymentPracticesPreValidator : AbstractValidator<RaterFacadeModel>
    {
        /// <summary>
        /// DataAccess object
        /// </summary>
        private EmploymentPracticesDataAccess _DataAccess { get; set; }

        /// <summary>
        /// Logger object
        /// </summary>
        protected ILoggingManager _Logger { get; private set; }

        /// <summary>
        /// IConfiguration object
        /// </summary>
        readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;

        /// <summary>
        /// EmploymentPracticesPreValidator
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public EmploymentPracticesPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this._configuration = configuration;
            this._Logger = logger;
            this._DataAccess = new EmploymentPracticesDataAccess(this._configuration, this._Logger);

            #region Skip code from Sheet
            /*
            //2)If "Type" dropdown field value is missing 
            // Cannot Rate the quote as Type is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.Type).NotEmpty().
             WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesTypeMissing);

            //3)If "Expense" dropdown field value is missing 
            // Cannot Rate the quote as Expense is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.Expense).NotEmpty().
           WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesExpenseMissing);


            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel != null, () =>
            {
                //4)If "Back Wages Limit" dropdown field value is missing when Back wage coverage is selected 
                //Cannot Rate the quote as Back Wages Limit is invalid.
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesLimit)
                .Must((modelObject, value) =>
                CheckEmploymentPracticesOptionalCoverageInt(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesIsSelected
                , modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesLimit))
                .WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesBackWagesLimitMissing);

                //5)If "Loss Adjustment Expense Wrongful Act Limit" dropdown field value is missing when coverage is selected
                //Cannot Rate the quote as Loss Adjustment Expense Wrongful Act Limit is invalid.
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateLimit)
                .Must((modelObject, value) =>
                CheckEmploymentPracticesOptionalCoverageInt(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateIsSelected
                , modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateLimit))
                .WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesLossAdjustmentExpenseWrongfulActRateLimitMissing);

                //6)When Other Optional Coverage is selected with missing Rating Basis
                //Cannot Rate the quote as Rating Basis is invalid.
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesRatingBasis)
               .Must((modelObject, value) =>
               CheckEmploymentPracticesOptionalCoverageString(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesIsSelected
               , modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesRatingBasis))
               .WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesBackWagesRatingBasisMissing);

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCRatingBasis)
               .Must((modelObject, value) =>
                CheckEmploymentPracticesOptionalCoverageString(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCIsSelected
               , modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.EEOCRatingBasis))
               .WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesEEOCRatingBasisMissing);

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateRatingBasis)
              .Must((modelObject, value) =>
               CheckEmploymentPracticesOptionalCoverageString(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateIsSelected
              , modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActRateRatingBasis))
              .WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesLossAdjustmentExpenseWrongfulActRateRatingBasisMissing);

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRatingBasis)
             .Must((modelObject, value) =>
              CheckEmploymentPracticesOptionalCoverageString(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseIsSelected
             , modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.NonMonetaryDefenseRatingBasis))
             .WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesNonMonetaryDefenseRatingBasisMissing);

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis)
              .Must((modelObject, value) =>
               CheckEmploymentPracticesOptionalCoverageString(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected
              , modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.SupplExtendedReportingPeriodRatingBasis))
              .WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesSupplExtendedReportingPeriodRatingBasisMissing);
            });

            //------------------------------------Rating Algo tab-------------------------------------------------------------//

            //If Exposure Amount input field is missing.
            //Cannot Rate the quote as Exposure Amount is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.Exposure).NotNull().
            WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesExposureMissing);

            //If Liability Limit input field is missing.
            //Cannot Rate the quote as Liability Limit is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.LiabilityLimit).NotNull().
            WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesLiabilityLimitMissing);

            //TODO
            // When entered Liability rate is not within the defined range
            // Cannot Rate the quote as Liability Limit rate is invalid.

            //If Aggregate Limit input field is missing.
            //Cannot Rate the quote as Aggregate Limit is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.AggregateLimit).NotNull().
            WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesAggregateLimitMissing);
            */
            #endregion

            //------------------------------------Rating Algo tab-------------------------------------------------------------//

            string errorMessageExposureRate = string.Empty;

            //Step 2 : When entered Exposure rate is not within the defined range
            //Cannot Rate the quote as Exposure rate is invalid.
            When(reg => (reg.RaterInputFacadeModel.PolicyHeaderModel.State != StateCodeConstant.MO 
                          && reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.ExposureRate >= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.ExposureRate)
                .Must((modelObject, value) => 
                            CheckRangeForValueExposureRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.ExposureRate, 
                                                           modelObject, 
                                                           out errorMessageExposureRate))
                .WithMessage(!string.IsNullOrEmpty(errorMessageExposureRate) ? errorMessageExposureRate : 
                                                    Resources.ErrorMessages.InputEmploymentPracticesExposureRateMissing);
            });

            //Step 6 : Validation 1: If "Deductible/SIR" input field value is missing. (applicable for MS & OH state only)
            //Cannot Rate the quote as Deductible / SIR is invalid.
            When(reg => (reg.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.MS || reg.RaterInputFacadeModel.PolicyHeaderModel.State == StateCodeConstant.OH), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.DeductibleSIR)
                    .NotEmpty().WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesDeductibleSIRMissing)
                    .NotNull().WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesDeductibleSIRMissing);
            });

            string errorMessageIRPMFactor = string.Empty;

            //Step 16 : Validation 2: When entered IRPM Factor is not within the defined range
            //Message: Cannot Rate the quote as IRPM value is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.IRPMFactor)
                .Must((modelObject, value) => CheckRangeForValueIRPMRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.IRPMFactor, modelObject, out errorMessageIRPMFactor))
                .WithMessage(!string.IsNullOrEmpty(errorMessageIRPMFactor) ? errorMessageIRPMFactor : Resources.ErrorMessages.InputEmploymentPracticesIRPMFactorInvalid);

            string errorMessageOtherModFactor = string.Empty;

            //Step 17 : Validation 2: When entered Other Mod Factor is not within the defined range
            //Message: Cannot Rate the quote as Other Mod value is invalid.           
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.OtherModFactor)
                .Must((modelObject, value) => CheckRangeForValueOtherModRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.OtherModFactor, modelObject, out errorMessageOtherModFactor))
                .WithMessage(!string.IsNullOrEmpty(errorMessageOtherModFactor) ? errorMessageOtherModFactor : Resources.ErrorMessages.InputEmploymentPracticesOtherModFactorInvalid);

            #region optional coverage

            //Optional Coverage I - Back Wages : Validation 2: When State(policy level input json node) = CT OR DE OR MA OR ME OR NH OR VT  AND Back Wages Is Selected = 1.
            //Message : Cannot rate the quote as Back Wages coverage is not available for the selected State.
            string[] stateCheckList1 = new string[6] { "CT", "DE", "MA", "ME", "NH", "VT" };

            When(reg => stateCheckList1.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State) && reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel != null, () =>
              {
                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.BackWagesIsSelected)
                      .NotEqual(true)
                      .WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesBackWagesCoverageNotAvailableForState);
              });

            //Optional Coverage II -Loss Adjustment Expense Wrongful Act : Validation 2: When State(policy level input json node) = AL, CO, GA, KS, MI, MN, MS, MO, IL, IN, NC, OH, PA, SC, TX, UT, WY AND Loss Adjustment Expense Wrongful Act Is selected = 1
            //Message : Cannot rate the quote as Loss Adjustment Expense Wrongful Act coverage is not available in the selected State.
            string[] stateCheckList2 = { "AL", "CO", "GA", "KS", "MI", "MN", "MS", "MO", "IL", "IN", "NC", "OH", "PA", "SC", "TX", "UT", "WY" };

            When(reg => stateCheckList2.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State) && reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel != null, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices.EmploymentPracticesOptionalCoverageModel.LossAdjustmentExpenseWrongfulActIsSelected)
                    .NotEqual(true)
                    .WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesLossAdjustmentExpenseWrongfulActNotAvailableForState);
            });

            #endregion
        }

        /// <summary>
        /// CheckRangeForValueExposureRate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckRangeForValueExposureRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;

            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;

            dataTable = this._DataAccess.GetExposureRateMinMaxFactor(policyHeaderModel.State,
                                                                        policyHeaderModel.PrimaryClass,
                                                                        inputModel.LineOfBusiness,
                                                                        policyHeaderModel.PolicyEffectiveDate,
                                                                        policyHeaderModel.PolicyExpirationDate);

            if (dataTable == null)
            {
                message = "Exposure Rate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "Exposure Rate Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "Exposure Rate Max range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckRangeForValueOtherModRate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckRangeForValueOtherModRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;

            bool flag = false;
            message = string.Empty;
            DataTable dataTable = null;

            dataTable = this._DataAccess.GetEPOtherModRate(policyHeaderModel.State,
                                                            inputModel.LineOfBusiness,
                                                            policyHeaderModel.PolicyEffectiveDate,
                                                            policyHeaderModel.PolicyExpirationDate);

            if (dataTable == null)
            {
                message = "OtherMod range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "OtherMod Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "OtherMod Rate Max range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckRangeForValueIRPMRate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckRangeForValueIRPMRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPractices;

            bool flag = false;
            message = string.Empty;
            DataTable dataTable = null;

            dataTable = this._DataAccess.GetEPIRPMRate(policyHeaderModel.State,
                                                        inputModel.LineOfBusiness,
                                                        policyHeaderModel.PolicyEffectiveDate,
                                                        policyHeaderModel.PolicyExpirationDate);

            if (dataTable == null)
            {
                message = "IRPM Rate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "IRPM Rate Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "IRPM Rate Max range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }
    }
}
