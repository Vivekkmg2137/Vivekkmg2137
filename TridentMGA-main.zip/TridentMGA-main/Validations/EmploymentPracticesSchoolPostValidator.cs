﻿using AutoMapper;
using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;


namespace Validations
{
    public class EmploymentPracticesSchoolPostValidator : AbstractValidator<RaterFacadeModel>
    {
        private EmploymentPracticesSchoolDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        readonly Microsoft.Extensions.Configuration.IConfiguration configuration;

        private readonly IMapper _mapper;
        public EmploymentPracticesSchoolPostValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.Logger = logger;
            this.DataAccess = new EmploymentPracticesSchoolDataAccess(this.configuration, this.Logger);
        }
    }
}