﻿using AutoMapper;
using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Validations
{
    public class EmploymentPracticesSchoolPreValidator : AbstractValidator<RaterFacadeModel>
    {
        private EmploymentPracticesSchoolDataAccess _DataAccess { get; set; }
        protected ILoggingManager _Logger { get; private set; }

        readonly Microsoft.Extensions.Configuration.IConfiguration configuration;

        public EmploymentPracticesSchoolPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this._Logger = logger;
            this._DataAccess = new EmploymentPracticesSchoolDataAccess(this.configuration, this._Logger);

            //Step 2 When entered Exposure rate is not within the defined range
            // Cannot Rate the quote as Exposure rate is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.ExposureRate >= 0, () =>
            {
                string errorMessageExposureRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.ExposureRate)
                    .Must((modelObject, value) => CheckRangeForValueExposureRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.ExposureRate, modelObject, out errorMessageExposureRate))
                    .WithMessage(x => !string.IsNullOrEmpty(errorMessageExposureRate) ? errorMessageExposureRate : Resources.ErrorMessages.InputEmploymentPracticesSchoolExposureRateMissing);
            });
            //Step 7 Validation 1: If "Population / ADA" input field value is missing. 
            //Validation 2: If Population entered is greater than 99999999
            //Message: Cannot Rate the quote as Population / ADA is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .LessThanOrEqualTo(99999999).WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesSchoolPopulationADAInvalid);

            //Step 8 Validation 1: If "Location Type" input field value is missing. 
            //Message: Cannot Rate the quote as Location Type is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.LocationType)
                .NotEmpty().WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesSchoolLocationTypeRequired);

            //Step 9 Validation 1: If ""Policy Type"" input field value is missing. 
            //Message: Cannot Rate the quote as Policy Type is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.PolicyType)
                .NotEmpty().WithMessage(x => Resources.ErrorMessages.InputEmploymentPracticesSchoolPolicyTypeRequired);

            //Step 16 Validation 1: If "IRPM Rate" input field value is missing. 
            //Validation 2: When entered IRPM is not within the defined range
            //Message: Cannot Rate the quote as IRPM value is invalid.
            string errorMessageIRPMRate = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.IRPMRate)
                .Must((modelObject, value) => CheckRangeForValueIRPMRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.IRPMRate, modelObject, out errorMessageIRPMRate))
                .WithMessage(x => !string.IsNullOrEmpty(errorMessageIRPMRate) ? errorMessageIRPMRate : Resources.ErrorMessages.InputEmploymentPracticesSchoolIRPMRateInvalid);

            //Step 17 Validation 1: If ""Other Mod Rate"" input field value is missing 
            //Validation 2: When entered Other Mod is not within the defined range
            //Message: Cannot Rate the quote as Other Mod value is invalid.
            string errorMessageOtherModRate = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.OtherModRate)
                .Must((modelObject, value) => CheckRangeForValueOtherModRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool.OtherModRate, modelObject, out errorMessageOtherModRate))
                .WithMessage(x => !string.IsNullOrEmpty(errorMessageOtherModRate) ? errorMessageOtherModRate : Resources.ErrorMessages.InputEmploymentPracticesSchoolOtherModRateInvalid);
        }

        public bool CheckRangeForValueExposureRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;

            dataTable = this._DataAccess.GetExposureRateMinMaxFactor(policyHeaderModel.State, policyHeaderModel.PrimaryClass, inputModel.LineOfBusiness, policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "Exposure Rate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "Exposure Rate Min range does not exist.";
                }
                else if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "Exposure Rate Max range does not exist.";
                }
                else if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        public bool CheckRangeForValueOtherModRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
            bool flag = false;
            message = string.Empty;
            DataTable dataTable = null;

            dataTable = this._DataAccess.GetEPSOtherModRate(policyHeaderModel.State, inputModel.LineOfBusiness, policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "OtherMod range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "OtherMod Min range does not exist.";
                }
                else if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "OtherMod Rate Max range does not exist.";
                }
                else if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        public bool CheckRangeForValueIRPMRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.EmploymentPracticesSchool;
            bool flag = false;
            message = string.Empty;

            DataTable dataTable = null;
            dataTable = this._DataAccess.GetEPSIRPMRate(policyHeaderModel.State, inputModel.LineOfBusiness, policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);

            if (dataTable == null)
            {
                message = "IRPM Rate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "IRPM Rate Min range does not exist.";
                }
                else if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "IRPM Rate Max range does not exist.";
                }
                else if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }
    }
}
