﻿namespace Validations
{
    using AutoMapper;
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Models.ApiModels;
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    using System.Linq;
    using System.Data;
    using Models;

    public class GeneralLiabilityPreValidator : AbstractValidator<RaterFacadeModel>
    {
        private GeneralLiabilityDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        readonly IConfiguration configuration;

        private readonly IMapper _mapper;
        public GeneralLiabilityPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.DataAccess = new GeneralLiabilityDataAccess(this.configuration, this.Logger);

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                .Must((modelObject, selectedLineOfBusiness) => IsModelValid(modelObject))
                .WithMessage(Resources.ErrorMessages.InputJSONNotValidForLOBs);

            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() == "MSC", () =>
             {
                 //This step will be executed only when Primary Class = MSC  
                 string messageExposureRate = string.Empty;
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ExposureRate)
                 .Must((modelObject, value) => CheckForMinMaxValueExposureRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ExposureRate,
                                                                               modelObject, out messageExposureRate))
                 .WithMessage(x => !string.IsNullOrEmpty(messageExposureRate) ? messageExposureRate :
                                    Resources.ErrorMessages.InputGeneralLiabilityExposureRateNotInRange);

             });

            string[] statesCoverage = { "KS", "MO", "NY" };
            List<string> stateCheckListCovefrage = new List<string>(statesCoverage);

            When(reg => stateCheckListCovefrage.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper()), () =>
            {
                //If 'Limit Rate' is Incorrectly received by the rater i.e.not in the range of lookup 
                // Cannot Rate the quote as 'Rate' entered is not in the allowed range
                string messageLiabilityLimitRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.LiabilityLimitRate)
                    .Must((modelObject, value) => CheckForMinMaxValueLiabilityLimitRate(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.LiabilityLimitRate, 0), modelObject, out messageLiabilityLimitRate))
                    .WithMessage(x => !string.IsNullOrEmpty(messageLiabilityLimitRate) ? messageLiabilityLimitRate :
                                       Resources.ErrorMessages.InputGeneralLiabilityLimitRateNotInRange);
            });

            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA >= 0, () =>
            {
                //If 'PopulationADA' is Incorrectly received by the rater i.e.not in the range of lookup 
                // Cannot Rate the quote as 'Rate' entered is not in the allowed range
                string messagePopulationADARate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                    .Must((modelObject, value) => CheckForMinMaxValuePopulationFactor(Math.Round(Convert.ToDecimal(modelObject.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA), 2), modelObject, out messagePopulationADARate))
                    .WithMessage(x => !string.IsNullOrEmpty(messagePopulationADARate) ? messagePopulationADARate :
                                        Resources.ErrorMessages.InputGeneralLiabilityPopulationADANotInRange);

                // Step 23.6 CheckForMinMaxValueCyberPopulation
                //If 'PopulationADA' is Incorrectly received by the rater i.e.not in the range of lookup 
                // Cannot Rate the quote as 'PopulationADA' entered is not in the allowed range
                string messageCyberPopulation = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                    .Must((modelObject, value) => CheckForMinMaxValueCyberPopulation(Math.Round(Convert.ToDecimal(modelObject.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA), 0), modelObject, out messageCyberPopulation))
                    .WithMessage(x => !string.IsNullOrEmpty(messageCyberPopulation) ? messageCyberPopulation :
                                        Resources.ErrorMessages.InputGeneralLiabilityCyberPopulationADA);

            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.IRPMFactor >= 0, () =>
            {
                //If 'IRPM Factor' is Incorrectly received by the rater i.e.not in the range of lookup 
                // Cannot Rate the quote as 'Rate' entered is not in the allowed range
                string messageIRPMFactor = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.IRPMFactor)
                    .Must((modelObject, value) => CheckForMinMaxValueIRPMFactor(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.IRPMFactor, 0), modelObject, out messageIRPMFactor))
                    .WithMessage(x => !string.IsNullOrEmpty(messageIRPMFactor) ? messageIRPMFactor :
                                        Resources.ErrorMessages.InputGeneralIRPMFactorNotInRange);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.OtherModFactor >= 0, () =>
            {
                //If 'OtherMod Factor' is Incorrectly received by the rater i.e.not in the range of lookup 
                // Cannot Rate the quote as 'Rate' entered is not in the allowed range
                string messageOtherModFactor = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.OtherModFactor)
                    .Must((modelObject, value) => CheckForMinMaxValueOtherModeFactor(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.OtherModFactor, 0), modelObject, out messageOtherModFactor))
                    .WithMessage(x => !string.IsNullOrEmpty(messageOtherModFactor) ? messageOtherModFactor :
                                        Resources.ErrorMessages.InputGeneralLiabilityOtherModeNotInRange);
            });

            string[] AircraftCoveragestates = { "AL", "CO", "GA", "KS", "DE", "ME", "MA", "MI", "MN", "IL", "IN", "OH", "NC", "NH", "NY", "PA", "SC", "TX", "UT", "VT", "WY" };
            List<string> stateCheckListAircraftCoverage = new List<string>(AircraftCoveragestates);

            // step 24.2 Unmanned Aircraft Coverage 15 lbs or Less rate
            //  Validation 1: If Unmanned aircraft Option = Coverage A - GL230"" AND 'Unmanned Aircraft Coverage 15 lbs or Less Rate'
            //input value is not within the defined range.
            //Message: Cannot Rate the quote as Unmanned Aircraft Weight -15 lbs or Less Rate is invalid
            When(reg => stateCheckListAircraftCoverage.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper()), () =>
            {
                //If 'Limit Rate' is Incorrectly received by the rater i.e.not in the range of lookup 
                // Cannot Rate the quote as 'Rate' entered is not in the allowed range
                string messageAircraftcoverage15lbs = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverage15lbsorLessRate)
                    .Must((modelObject, value) => CheckForMinMaxValueUnmannedAircrafts(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverage15lbsorLessRate, 0), modelObject, out messageAircraftcoverage15lbs))
                    .WithMessage(x => !string.IsNullOrEmpty(messageAircraftcoverage15lbs) ? messageAircraftcoverage15lbs :
                                       Resources.ErrorMessages.InputGeneralAircraftcoverage15lbsNotInRange);
            });

            // Step 24.5  Unmanned Aircraft Coverage 15.1 to < 55 lbs Rate
            // "Validation 1: If Unmanned aircraft Option = ""Coverage A -GL230"" AND 'Unmanned Aircraft 15.1 to < 55 lbs rate' input field value is not withn the defined range.
            // Message: Cannot Rate the quote as Unmanned Aircraft Weight -15.1 to < 55 lbs rate is invalid"
            When(reg => stateCheckListAircraftCoverage.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper()), () =>
            {
                //If 'Limit Rate' is Incorrectly received by the rater i.e.not in the range of lookup 
                // Cannot Rate the quote as 'Rate' entered is not in the allowed range
                string messageAircraftcoverage15Pt1toLessThen55lbsRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate)
                    .Must((modelObject, value) => CheckForMinMaxValueUnmannedAircrafts15ToLessThan55lbs(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate, 0), modelObject, out messageAircraftcoverage15Pt1toLessThen55lbsRate))
                    .WithMessage(x => !string.IsNullOrEmpty(messageAircraftcoverage15Pt1toLessThen55lbsRate) ? messageAircraftcoverage15Pt1toLessThen55lbsRate :
                                        Resources.ErrorMessages.InputGeneralUnmannedAircraftcoverage15Pt1toLessThen55lbsRate);
            });

            // Step 24.8 Unmanned Aircraft Coverage ≥ 55 lbs Rate 
            // Validation 1: If Unmanned aircraft Option = ""Coverage A -GL230"" AND 'Unmanned Aircraft Coverage ≥ 55 lbs Rate' input field value is not withn the defined range.
            //Message: Cannot Rate the quote as Weight - - ≥ 55 lbs Rate is invalid"
            When(reg => stateCheckListAircraftCoverage.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper()), () =>
            {
                //If 'Limit Rate' is Incorrectly received by the rater i.e.not in the range of lookup 
                // Cannot Rate the quote as 'Rate' entered is not in the allowed range
                string messageAircraftcoverageGreaterThenEqualto55 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate)
                    .Must((modelObject, value) => CheckForMinMaxValueUnmannedAircrafts55lbs(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate, 0), modelObject, out messageAircraftcoverageGreaterThenEqualto55))
                    .WithMessage(x => !string.IsNullOrEmpty(messageAircraftcoverageGreaterThenEqualto55) ? messageAircraftcoverageGreaterThenEqualto55 : Resources.ErrorMessages.InputGeneralUnmannedAircraftcoverageGreaterThenEqualto55lbsRate);
            });


            //// Step 23.11 CheckForMinMaxValueCyberLimits
            //When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA >= 0, () =>
            //{
            //    //If 'PopulationADA' is Incorrectly received by the rater i.e.not in the range of lookup 
            //    // Cannot Rate the quote as 'PopulationADA' entered is not in the allowed range
            //    string messageCyberPopulation = string.Empty;
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
            //        .Must((modelObject, value) => CheckForMinMaxValueCyberPopulation(Math.Round(Convert.ToDecimal(modelObject.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA), 0), modelObject, out messageCyberPopulation))
            //        .WithMessage(x => !string.IsNullOrEmpty(messageCyberPopulation) ? messageCyberPopulation : Resources.ErrorMessages.InputGeneralLiabilityCyberPopulationADA);
            //});

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel != null
            && reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.GeneralLiabilityOptionalOtherCoverageModel != null
            && reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.GeneralLiabilityOptionalOtherCoverageModel.Count > 0, () =>
            {
                //When Other Optional Coverage is selected with missing Description  
                //Cannot Rate the quote as Other Optional Coverage Description is missing.
                string otherCoverageDescription = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.GeneralLiabilityOptionalOtherCoverageModel)
                    .Must((modelObject, value) => CheckForGeneralLiabilityOptionalCoverageInputModelDescription(modelObject, out otherCoverageDescription))
                    .WithMessage(x => !string.IsNullOrEmpty(otherCoverageDescription) ? otherCoverageDescription : Resources.ErrorMessages.InputGeneralLiabilityOptionalOtherCoverageDescriptionMissing);

                //When Sewer Backup Aggregate Limit - GL - 217 IS Selected = True AND Sewer Backup Aggregate Limit - GL - 217 Aggregate Limit is zero.
                //Cannot rate the quote as Sewer Backup Aggregate Limit - GL - 217 coverage Aggregate Limit is invalid.
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.GeneralLiabilityOptionalOtherCoverageModel)
                    .Must((modelObject, value) => CheckForGeneralLiabilityOptionalCoverageLimit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupAggregateLimitGL217IsSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupAggregateLimitGL217Limit))
                    .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilitySewerBackupAggregateLimitGL217LimitInvalid);
            });

            When(reg => Convert.ToInt32(reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.EBLimit) != 0, () =>
            {
                //When EB Limit IS NOT zero AND EB Aggregate Limit is blank in input json 
                //Cannot rate the quote as EB Aggregate Limit is invalid.
                //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.EBAggregateLimit)
                //    .NotEmpty()
                //    .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityEBAggregateLimitInvalid);

                //When EB Limit IS NOT zero AND EB Retention is blank in input json  
                //Cannot rate the quote as EB Retention is invalid.
                //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.EBRetention)
                //    .NotEqual(0)
                //    .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityEBRetentionInvalid);

                //When EB Limit IS NOT zero AND EB Policy Type is blank in input json 
                //Cannot rate the quote as EB Policy Type is invalid.
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.EBPolicyType)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityEBPolicyTypeInvalid);

                //"Validation 1 - When EB Limit IS NOT zero AND EB Policy Type =  Claims Made AND EB Retroactive Date is blank in input json
                //Validation 2 - When EB Limit IS NOT zero AND EB Policy Type = Claims Made AND EB Retroactive Date is after the Policy Effective Date"	" 
                //"Cannot rate the quote as EB Retroactive Date is invalid.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.EBPolicyType.ToUpper() == "CLAIMS MADE", () =>
                {
                    //TODO-DOUBT
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.EBRetroactiveDate)
                        .NotNull()
                        .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityEBRetroactiveDateInvalid);

                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.EBRetroactiveDate)
                        .LessThan(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate)
                        .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityEBRetroactiveDateInvalid);
                });

            });

            //When Products/ Completed Aggregate Limit is missing in input Json   
            //Cannot rate the quote as Products / Completed Aggregate Limit is invalid.
            //TODO-DOUBT
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ProductsCompletedAggregateLimit)
            //    .NotEmpty()
            //    .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityProductsCompletedAggregateLimitInvalid);

            //When Personal and Advertising Injury Limit is missing in input Json 
            //Cannot rate the quote as Personal and Advertising Injury Limit is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.PersonalandAdvertisingInjuryLimit)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityPersonalandAdvertisingInjuryLimitInvalid);

            //If "Type" dropdown field value is missing 
            //Cannot Rate the quote as Type is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.Type)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityTypeInvalid);

            //If "Expense" dropdown field value is missing 
            //Cannot Rate the quote as Expense is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.Expense)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityExpenseInvalid);

            //GL Rating
            //Validation 1: If Exposure input field is missing.
            //Message: Cannot Rate the quote as Exposure is invalid. 
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.Exposure)
            //    .NotEmpty()
            //    .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityExposureInvalid);

            //TODO
            //"Validation 1: When entered Exposure rate is not within the defined range
            //Message - Cannot Rate the quote as Exposure rate is invalid."

            //TODO-DOUBT
            //"Validation 1: If ADA input field is missing.
            //Message: Cannot Rate the quote as ADA is invalid."

            //When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() == PrimaryClassConstant.MSC, () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ADA)
            //        .NotEmpty()
            //        .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityADAInvalid);
            //});

            //TODORetroActiveDate
            //"Validation 1: When entered ADA rate is not within the defined range
            //Message - Cannot Rate the quote as ADA rate is invalid."

            //Validation 1: If Liability Limit input field is missing.
            //Message : Cannot Rate the quote as Liability Limit is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.LiabilityLimit)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityLiabilityLimitInvalid);

            //TODO
            //Validation 2: When entered Liability rate is not within the defined range
            //Message: Cannot Rate the quote as Liability Limit rate is invalid.

            //TODO-DOUBT
            //"Validation 1: If Aggregate Limit input field is missing.
            //Message: Cannot Rate the quote as Aggregate Limit is invalid."
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.AggregateLimit)
            //    .NotEmpty()
            //    .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityAggregateLimitInvalid);

            //Validation 1: If "Deductible/SIR" input field value is missing. (applicable for MS, NY & OH state only)
            //Message: Cannot Rate the quote as Deductible / SIR is invalid.
            string[] stateCheck1 = new string[3] { "MS", "NY", "OH" };
            When(reg => stateCheck1.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.DeductibleSIR)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityDeductibleSIRInvalid);
            });

            //"Validation 1: If ""Population / ADA"" input field value is missing. 
            //Validation 2: If Population entered is greater than 99999999
            //Message: Cannot Rate the quote as Population / ADA is invalid."
            //TODO-DOUBT
            //this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
            //    .NotNull()
            //    .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityPopulationADAInvalid);

            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .LessThanOrEqualTo(99999999)
                .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityPopulationADAInvalid);

            //"Validation 1: If ""Location Type"" input field value is missing. 
            //Message: Cannot Rate the quote as Location Type is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.LocationType)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityLocationTypeInvalid);

            //"Validation 1: If ""Policy Type"" input field value is missing. 
            //Message: Cannot Rate the quote as Policy Type is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.PolicyType)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputGeneralLiabilityPolicyTypeInvalid);

            //"Validation 1: If ""Years In Claims Made Program"" input field value is missing  AND Policy Type = ""Claims Made""
            //Message: Cannot Rate the quote as Years In Claims Made Program is invalid."
            When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.PolicyType) &&
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.PolicyType.ToUpper() == "CLAIMS MADE", () =>
            {
                //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.YearsinClaimsMadeProgram)
                //    .NotEmpty()
                //    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityYearsinClaimsMadeProgramMissing);

                //TODO
                //"Validation 1: If ""Retroactive Date"" input field value is missing AND Policy Type = ""Claims Made"". 
                //Message: Cannot Rate the quote as Retroactive Date is invalid."
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.RetroActiveDate)
                    .NotNull()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityRetroActiveDateInvalid);
            });

            //Validation 2: If entered ""Retroactive Date""  value is greater than ""Policy Effective Date"".
            //Message: Cannot Rate the quote as Retroactive Date is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.RetroActiveDate)
                .LessThan(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate)
                .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityRetroActiveDateInvalid);

            //Validation 1 - When Damage To Premises Limit IS NOT zero and Damage To Premises Unmodified Premium is less than 0
            //Message - Cannot Rate the quote as Damage To Premises Premium is invalid
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.DamageToPremisesUnmodifiedPremium)
            .GreaterThan(0)
            .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityDamageToPremisesUnmodifiedPremiumLessthenZero);


            //Validation 2 - When Damage To Premises limit is missing(zero) in input json.
            //Message - Cannot rate the quote as Damage To Premises Limit is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.DamageToPremisesLimit)
             .NotEmpty()
             .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityDamageToPremisesLimitMissing);

            //"Validation 1 -  When Damage To Premises Included In Excess Exposure value is missing in input json.
            //Message - Cannot rate the quote as Damage To Premises Included In Excess Exposure value is missing."
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.DamageToPremisesIncludedInExcessExposure)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityDamageToPremisesIncludedInExcessExposureMissing);


            //31)"Validation 1 - When Medical Payments Limit is missing in input json.
            //Message - Cannot rate the quote as Medical Payment Limit is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.MedicalPaymentLimit)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityMedicalPaymentLimitMissing);

            //Validation 2 - When Medical Payments Limit IS NOT Excluded AND Medical Payments Unmodified Premium is missing(zero) OR less than zero in input json.
            //Message - Cannot Rate the quote as Medical Payments Premium is invalid"
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.MedicalPaymentLimit.ToUpper() != "EXCLUDED", () =>
             {
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.MedicalPaymentUnmodifiedPremium)
                 .GreaterThan(0)
                 .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityMedicalPaymentUnmodifiedPremiumLessthen);
             });

            //TODO - written wrong in sheet
            //"Validation 1 -  When Damage To Premises Included In Excess Exposure value is missing in input json.
            //Message - Cannot rate the quote as Damage To Premises Included In Excess Exposure value is missing."
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.MedicalPaymentIncludedInExcessExposure)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityMedicalPaymentIncludedInExcessExposureMissing);

            //35"Validation 1 -  When EB limit is missing in input json.
            //Message - Cannot rate the quote as EB Limit is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.EBLimit)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityEBLimitMissing);

            //37)"Validation 1 -  When EB Included In Excess Exposure value is missing in input json.
            //Message - Cannot rate the quote as EB Included In Excess Exposure value is missing."
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.EBIncludedInExcessExposure)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityEBIncludedInExcessExposureMissing);

            //NYVALI
            //49."Validation 1 : When State IS NY AND Data Compromise Limit IS NOT zero AND NY Data Compromise Years in Claim Made IS Zero in input json.
            //Message: Cannot Rate the quote as Data Compromise Years in Claims Made is missing. "
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == "NY", () =>
           {
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.NYDataCompromiseYearsinClaimsMade)
                   .NotEqual(0)
                   .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityNYDataCompromiseYearsinClaimsMadeMissing);
           });

            //59)When Data Compromise Referral IS Selected = True AND Data Compromise Limit IS zero
            //Message: Cann't Rate the quote as Data Compromise Limit is invalid
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.DataCompromiseReferralIsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.DataCompromiseLimit)
                    .NotEqual(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityDataCompromiseLimitInvalid);

                //60)Validation 1 : When Data Compromise Referral IS Selected = True AND Data Compromise Limit IS NOT zero AND Response Expense Premium IS Zero OR less than zero in input json.
                //Message: Cannot Rate the quote as Data Compromise Response Expense Premium is invaild.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.DataCompromiseLimit != 0, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ResponseExpensePremium)
                        .GreaterThan(0)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityResponseExpensePremiumInvalid);

                    //61)"Validation 1 : When Data Compromise Referral IS Selected = True AND Data Compromise Limit IS NOT zero AND Data Compromise Data Compromise Liabiltiy Premium IS Zero OR less than zero in input json.
                    //Message: Cannot Rate the quote as Data Compromise Liability Premium is invalid."
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.DataCompromiseLiabilityPremium)
                        .GreaterThan(0)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityDataCompromiseLiabilityPremiumnvalid);
                });
            });

            //72)Validation 1:  When (Computer Attack Limit IS NOT Zero OR Network Security & Electronic Media Liability IS NOT zero) AND Population is missing in input json.
            //Message: Cannot rate the quote as Population value is invalid."
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ComputerAttackLimit != 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.NetworkSecurityAndElectronicMediaLiabilityLimit != 0, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                    .NotEqual(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityDataPopulationADAInvalid);
            });

            //74)"Validation 1 : When State IS NY AND (Cyber Attack Limit IS NOT zero OR  Network Security Liability and
            //Electronic Media Liability Limit IS NOT zero) AND NY Cyber Years in Claim Made IS Zero in input json.
            //Message: Cannot Rate the quote as Cyber Years in Claims Made is missing. "
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == "NY" && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ComputerAttackLimit != 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.NetworkSecurityAndElectronicMediaLiabilityLimit != 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.NYCyberYearsinClaimsMade)
                    .NotEqual(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityYearinCMMissing);
            });

            //80)"When Cyber Referral IS Selected = True AND (Computer Attack Limit IS zero AND Network Security & Electronic Media Liability Limit IS zero).
            //Message: Cann't Rate the quote as Computer Attack Limit or Network Security & Electronic Media Liability Limit is invalid"
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.CyberReferralIsSelected && reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ComputerAttackLimit != 0, () =>
             {
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.NetworkSecurityAndElectronicMediaLiabilityLimit)
                     .NotEqual(0)
                     .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityComputerAttackLimitorNetworkSecurityLimitInvalid);
             });

            //81)Validation 1 : When State IS NY AND (Cyber Attack Limit IS NOT zero OR  Network Security Liability and Electronic Media Liability Limit IS NOT zero) AND NY Cyber Years in Claim Made IS Zero in input json.
            //Message: Cannot Rate the quote as Cyber Years in Claims Made is missing. "
            When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == "NY" && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ComputerAttackLimit != 0 ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.NetworkSecurityAndElectronicMediaLiabilityLimit != 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.NYCyberYearsinClaimsMade)
                    .NotEqual(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityNYCyberYearsinClaimsMadeInvalid);
            });

            //When Cyber Referral IS Selected = True AND (Computer Attack Limit IS zero AND
            //Network Security& Electronic Media Liability Limit IS zero).
            //Message: Cann't Rate the quote as Computer Attack Limit or Network Security & Electronic Media Liability Limit is invalid"
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.CyberReferralIsSelected &&
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.ComputerAttackLimit == 0, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.NetworkSecurityAndElectronicMediaLiabilityLimit)
                    .NotEqual(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGLNetworkSecurityElectronicMediaLiabilityLimitMissing);
            });

            //88)"Validation 1: If  Unmanned Aircraft Option = ""Coverage A - GL230"" AND 'Aggregate Limit'
            //input field value is missing. 
            //Message: Cannot Rate the quote as Unmanned Aircraft Aggregate Limit is invalid"
            //When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftOption) &&
            //reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftOption.ToUpper() == "COVERAGE A - GL230", () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.AggregateLimit)
            //        .NotEqual(0)
            //        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityUnmannedAircraftOptionAggregateLimitInvalid);
            //});



            When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftOption) &&
                        reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftOption.ToUpper() == "COVERAGE A - GL230", () =>
                        {
                            //90)Validation 1: If  Unmanned aircraft Option = Coverage A - GL230"" AND 'Unmanned Aircraft Coverage 15 lbs or Less Rate'
                            //input value is not within the defined range.
                            //Message: Cannot Rate the quote as Unmanned Aircraft Weight -15 lbs or Less Rate is invalid.
                            string messageAircraftcoverage15lbs = string.Empty;
                            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverage15lbsorLessRate)
                                .Must((modelObject, value) => CheckForMinMaxValueUnmannedAircrafts(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverage15lbsorLessRate, 0), modelObject, out messageAircraftcoverage15lbs))
                                .WithMessage(x => !string.IsNullOrEmpty(messageAircraftcoverage15lbs) ? messageAircraftcoverage15lbs : Resources.ErrorMessages.InputGeneralAircraftcoverage15lbsNotInRange);

                            //94)"Validation 1: If Unmanned aircraft Option = ""Coverage A -GL230""
                            //AND 'Unmanned Aircraft 15.1 to < 55 lbs rate' input field value is not withn the defined range.
                            //Message: Cannot Rate the quote as Unmanned Aircraft Weight -15.1 to < 55 lbs rate is invalid"
                            string messageAircraftcoverage15Pt1toLessThen55lbsRate = string.Empty;
                            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate)
                                .Must((modelObject, value) => CheckForMinMaxValueUnmannedAircrafts15ToLessThan55lbs(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverage15Pt1toLessThen55lbsRate, 0), modelObject, out messageAircraftcoverage15Pt1toLessThen55lbsRate))
                                .WithMessage(x => !string.IsNullOrEmpty(messageAircraftcoverage15Pt1toLessThen55lbsRate) ? messageAircraftcoverage15Pt1toLessThen55lbsRate : Resources.ErrorMessages.InputGeneralUnmannedAircraftcoverage15Pt1toLessThen55lbsRate);

                            //98)Validation 1: If Unmanned aircraft Option = ""Coverage A - GL230""
                            //AND 'Unmanned Aircraft Coverage ≥ 55 lbs Rate' input field value is not withn the defined range.
                            //Message: Cannot Rate the quote as Weight - - ≥ 55 lbs Rate is invalid"
                            string messageAircraftcoverageGreaterThenEqualto55 = string.Empty;
                            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate)
                                .Must((modelObject, value) => CheckForMinMaxValueUnmannedAircrafts55lbs(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverageGreaterThenEqualto55lbsRate, 0), modelObject, out messageAircraftcoverageGreaterThenEqualto55))
                                .WithMessage(x => !string.IsNullOrEmpty(messageAircraftcoverageGreaterThenEqualto55) ? messageAircraftcoverageGreaterThenEqualto55 :
                                                                        Resources.ErrorMessages.InputGeneralUnmannedAircraftcoverageGreaterThenEqualto55lbsRate);

                            //104)Validation 1: If  Unmanned aircraft Option = ""Coverage A - GL230"" AND 'Unmanned Aircraft Coverage Included in Excess Exposure' input field value is missing. 
                            //Message: Cannot Rate the quote as 'Included in Excess Exposure' option for Unmanned Aircraft coverage is missing"
                            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.UnmannedAircraftcoverageIncludedinExcessExposure)
                                .NotEmpty()
                                .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityUnmannedAircraftOptionUnmannedAircraftcoverageIncludedinExcessExposureMissing);
                        });

            //109)Validation 1 - When Cemetery Professional Liability - GL-203 IS Selected = True AND  Cemetery Professional Liability - GL-203 Unmodified premium is zero OR less than zero 
            //Message: Cannot rate the quote as Cemetery Professional Liability -GL - 203 premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.CemeteryProfessionalLiabilityGL203IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.CemeteryProfessionalLiabilityGL203UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityCemeteryProfessionalLiabilityGL203PremiumInValid);

                //110)Validation 1 -  When Cemetery Professional Liability - GL-203 IS Selected = True AND Cemetery Professional Liability - GL-203 Included In Excess Exposure value is missing in input json.
                //Message - Cannot rate the quote as Cemetery Professional Liability -GL - 203 Included In Excess Exposure value is missing."

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.CemeteryProfessionalLiabilityGL203IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityCemeteryProfessionalLiabilityGL203IncludedinExcessExposureMissing);
            });

            //TODO 
            //113)"Validation 1: If Cyber - Suppl. Extended Reporting Period IS Selected = True AND Cyber - Suppl. Extended Reporting Period Limit input value is zero. 
            //Message: Cannot Rate the quote as Cyber - Suppl.Extended Reporting Period Limit is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.CyberSupplExtendedReportingPeriodIsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.CyberSupplExtendedReportingPeriodLimit)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityCyberSupplExtendedReportingPeriodLimitInValid);

                //110)Validation 1 -  When Cemetery Professional Liability - GL-203 IS Selected = True AND Cemetery Professional Liability - GL-203 Included In Excess Exposure value is missing in input json.
                //Message - Cannot rate the quote as Cemetery Professional Liability -GL - 203 Included In Excess Exposure value is missing."

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.CyberSupplExtendedReportingPeriodIncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitCyberSupplExtendedReportingPeriodIncludedinExcessExposureMissing);
            });

            //119)Validation 1: If Data Compromise - Suppl. Extended Reporting Period IS Selected = True AND Data Compromise - Suppl. Extended Reporting Period Limit input value is zero. 
            //Message: Cannot Rate the quote as Data Compromise - Suppl.Extended Reporting Period Limit is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.DataCompromiseSupplExtendedReportingPeriodIsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.DataCompromiseSupplExtendedReportingPeriodLimit)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitDataCompromiseSupplExtendedReportingPeriodLimitMissing);
            });

            //"Validation 1 - When Employers Liability - GL-600 IS Selected = True AND  State IS NOT OH OR WY
            //Message: Cannot rate the quote as Employers Liability - GL - 600 coverage is not available in selected state."
            string[] stateCheck3 = new string[2] { "OH", "WY" };
            When(reg => !stateCheck3.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.EmployersLiabilityGL600IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.EmployersLiabilityGL600IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitEmployersLiabilityGL600IsSelectedIsInvalidForState);
                });
            });


            //Validation 1:  If Employers Liability - GL-600 Coverage is  selected and Employers Liability - GL-600 Unmodified Premium is zero OR less than zero 
            //Message: Cannot Rate the quote as Employers Liability - GL-600 Coverage Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.EmployersLiabilityGL600IsSelected && reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.EmployersLiabilityGL600UnmodifiedPremium <= 0, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.EmployersLiabilityGL600UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitEmployersLiabilityGL600UnmodifiedPremium);
            });

            string[] stateCheck4 = new string[18] { "AL", "CO", "GA", "IL", "IN", "KS", "MI", "MN", "MO", "MS", "NC", "NY", "OH", "PA", "SC", "TX", "UT", "WY" };
            When(reg => !stateCheck4.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                //"Validation 1 -When  Failure to Supply Exclusion - GL-304 IS Selected = True AND
                // State IS NOT AL, CO, GA, IL, IN, KS, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, WY
                //Message:  Cannot rate the quote as Failure to Supply Exclusion - GL-304 coverage is not available in selected state.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplyExclusionGL304IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplyExclusionGL304IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliFailuretoSupplyExclusionGL304IsSelectedIsInvalidForState);
                });

                //"Validation 1 - When Failure to Supply Sublimit - GL-211 IS Selected = True AND
                //State IS NOT AL, CO, GA, IL, IN, KS, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, WY
                //Message:  Cannot rate the quote as Failure to Supply Sublimit - GL-211 coverage is not available in selected state.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplySublimitGL211IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplySublimitGL211IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliFailuretoSupplySublimitGL211IsSelectedIsInvalidForState);
                });

                //108)
                //"Valdiation 1 - IF Cemetery Professional Liability - GL-203 IS Selected = True AND
                //State IS NOT AL, CO, GA, IL, IN, KS, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, WY
                //Message - Cannot rate the quote as Cemetery Professional Liability -GL - 203 coverage is not available in selected State."
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.CemeteryProfessionalLiabilityGL203IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.CemeteryProfessionalLiabilityGL203IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityCemeteryProfessionalLiabilityGL203NotApplicableForState);
                });

                //"Validation 1 - When Additional Insured - Designated Person or Organization - CG 20 26 IS Selected = True AND  State IS NOT AL, CO, GA, IL, IN, KS, MA, ME, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, WY.
                //Message: Cannot rate the quote as Additional Insured - Designated Person or Organization - CG 20 26 coverage is not available in selected state..
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliAdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelectedInvalidForState);
                });

                //"Validation 1 -  If Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18 IS Selected = True AND  State IS NOT AL, CO, CT, DE, GA, IL, IN, KS, MA, ME, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, VT, WY.
                //Message:  Cannot rate the quote as Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18 coverage is not available in selected state.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliAdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelectedInvalidForState);
                });

                //"Validation 1 -   If Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 IS Selected = True AND  State IS NOT AL, CO, CT, GA, IL, IN, KS, MA, ME, MO, MS, NH, OH, PA, TX, VT.
                //Message:  Cannot rate the quote as Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 coverage is not available in selected state.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliAdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelectedInvalidForState);
                });


                //"Validation 1 -When Fellow Employee - GL-206 IS Selected = True AND  State IS NOT AL, CO, GA, IL, IN, KS, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, WY
                //Message:   Cannot rate the quote as  Fellow Employee - GL-206 coverage is not available in selected state.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FellowEmployeeGL206IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FellowEmployeeGL206IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliFellowEmployeeGL206IsSelectedIsInvalidForState);
                });

                //"Validation 1 -When Limited Pollution Coverage - GL-210 IS Selected = True AND  State IS NOT AL, CO, GA, IL, IN, KS, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, WY
                //Message:  Cannot rate the quote as Limited Pollution Coverage - GL-210 coverage is not available in selected state.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedPollutionCoverageGL210IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedPollutionCoverageGL210IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliLimitedPollutionCoverageGL210IsSelectedIsInvalidForState);
                });

                //"Validation 1 -  When Sewer Backup Aggregate Limit - GL-217 IS Selected = True AND  State IS NOT AL, CO, GA, IL, IN, KS, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, WY.
                //Message: Cannot rate the quote as Sewer Backup Aggregate Limit - GL-217 coverage is not available in selected state.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupAggregateLimitGL217IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupAggregateLimitGL217IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliSewerBackupAggregateLimitGL217IsSelectedIsInvalidForState);
                });

                //"Validation 1 - When Additional Insured - Controlling Interest - CG 20 05 IS Selected = True AND  State IS NOT AL, CO, GA, IL, IN, KS, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, WY.
                //Message: Cannot rate the quote as Additional Insured - Controlling Interest - CG 20 05 coverage is not available in selected state.
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredControllingInterestCG2005IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredControllingInterestCG2005IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliAdditionalInsuredControllingInterestCG2005IsSelectedIsInvalidForState);
                });

                //"Validation 1 -  When Sewer Backup Sublimit - GL-260 IS Selected = True AND  State IS NOT  AL, CO, GA, IL, IN, KS, MI, MN, MO, MS, NC, NY, OH, PA, SC, TX, UT, WY.
                //Message: Cannot rate the quote as Sewer Backup  Sublimit - GL-260 coverage is not available in selected state
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupSublimitGL260IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupSublimitGL260IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliSewerBackupSublimitGL260IsSelectedIsInvalidForState);
                });
            });

            //"Validation 1:  If   Failure to Supply Exclusion - GL-304 Is Selected = True AND Failure to Supply Exclusion - GL-304 Limit is zero in input json
            //Message:  Cannot Rate the quote as Failure to Supply Exclusion - GL-304 Limit is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplyExclusionGL304IsSelected && !String.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplyExclusionGL304Limit), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplyExclusionGL304Limit)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityFailuretoSupplyExclusionGL304LimitInValid);
            });



            //"Validation 1:  If Failure to Supply Sublimit - GL-211 Is Selected = True AND Failure to Supply Sublimit - GL-211 Limit is zero in input json.
            //Message: Cannot Rate the quote as Failure to Supply Sublimit - GL-211 Limit is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplySublimitGL211IsSelected && reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplySublimitGL211Limit == 0, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FailuretoSupplySublimitGL211Limit)
                    .NotEqual(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityFailuretoSupplySublimitGL211LimitInValid);
            });


            //"Validation 1: When Fellow Employee - GL-206 IS Selected = True AND Fellow Employee - GL-206 Included In Excess Exposure value is missing in input json
            //Message: Cannot rate the quote as Fellow Employee - GL-206 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FellowEmployeeGL206IsSelected && !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FellowEmployeeGL206IncludedinExcessExposure), () =>
            {
                //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FellowEmployeeGL206Limit)
                //    .NotEmpty()
                //    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityFellowEmployeeGL206LimitInValid);

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.FellowEmployeeGL206IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityFellowEmployeeGL206IncludedinExcessExposureInValid);

            });

            //"Validation 1: When Limited Pollution Coverage - GL-210 IS Selected = True AND Limited Pollution Coverage - GL-210 Included In Excess Exposure value is missing in input json.
            //Message: Cannot rate the quote as Limited Pollution Coverage - GL-210 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedPollutionCoverageGL210IsSelected && !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedPollutionCoverageGL210IncludedinExcessExposure), () =>
            {
                //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedPollutionCoverageGL210Limit)
                //    .NotEmpty()
                //    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityLimitedPollutionCoverageGL210LimitInValid);

                //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedPollutionCoverageGL210IncludedinExcessExposure)
                //        .Equal(string.Empty)
                //        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityLimitedPollutionCoverageGL210IncludedinExcessExposureInValid);

            });

            //"Validation 1 -  When PA Heart & Lung Benefits - Limit per Officer - GL 801 IS Selected = True AND  State IS NOT PA
            //Message:  Cannot rate the quote as PA Heart & Lung Benefits - Limit per Officer - GL 801 coverage is not available in selected state.
            string[] stateCheck8 = new string[1] { "PA" };
            When(reg => !stateCheck8.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PAHeartAndLungBenefitsLimitperOfficerGL801IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PAHeartAndLungBenefitsLimitperOfficerGL801IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitPAHeartAndLungBenefitsLimitperOfficerGL801IsSelectedInvalidForState);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IsSelected, () =>
                {
                    //"Validation 1 - When PA Heart & Lung Benefits - Policy Level Aggregate - GL 800 IS Selected = True AND  State IS NOT PA
                    //Message:  Cannot rate the quote as PA Heart & Lung Benefits - Policy Level Aggregate - GL 800 coverage is not available in selected state.
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PAHeartAndLungBenefitsPolicyLevelAggregateGL800IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitPAHeartAndLungBenefitsPolicyLevelAggregateGL800IsSelectedInvalidForState);
                });
            });

            //"Validation 1 - When Pesticide or Herbicide Applicator - AG 7314 IS Selected = True AND  State IS NOT CT, DE, MA, ME, NH, VT
            //Message: Cannot rate the quote as Pesticide or Herbicide Applicator - AG 7314 coverage is not available in selected state..
            string[] stateCheck10 = new string[6] { "CT", "DE", "MA", "ME", "NH", "VT" };
            When(reg => !stateCheck10.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PesticideorHerbicideApplicatorAG7314IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PesticideorHerbicideApplicatorAG7314IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitPesticideorHerbicideApplicatorAG7314IsSelectedForState);
                });
            });

            //Validation 1 :When Pesticide or Herbicide Applicator - AG 7314 IS Selected = True AND  Pesticide or Herbicide Applicator - AG 7314 Unmodified premium is zero OR less than zero 
            //Message:Cannot rate the quote as Pesticide or Herbicide Applicator - AG 7314 premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PesticideorHerbicideApplicatorAG7314IsSelected && reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PesticideorHerbicideApplicatorAG7314UnmodifiedPremium <= 0, () =>
             {
                 this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PesticideorHerbicideApplicatorAG7314UnmodifiedPremium)
                     .NotEqual(0)
                     .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityPesticideorHerbicideApplicatorAG7314UnmodifiedPremiumInValid);
             });

            //"Validation 1 : When Pesticide or Herbicide Applicator - AG 7314 IS Selected = True AND Pesticide or Herbicide Applicator - AG 7314 Included In Excess Exposure value is missing in input json.
            //Message:  Cannot rate the quote as Pesticide or Herbicide Applicator - AG 7314 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PesticideorHerbicideApplicatorAG7314IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.PesticideorHerbicideApplicatorAG7314IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityPesticideorHerbicideApplicatorAG7314IncludedinExcessExposureInValid);

            });

            //"Validation 1 - When School Violent Event Response - AG GL 1000 IS Selected = True AND  State IS NOT CT, GA, IL, IN, KS, MA, ME, MN, MO, MS, NH, OH, PA, TX, VT
            //Message:  Cannot rate the quote as School Violent Event Response - AG GL 1000 coverage is not available in selected state.
            string[] stateCheck11 = new string[15] { "CT", "GA", "IL", "IN", "KS", "MA", "ME", "MN", "MO", "MS", "NH", "OH", "PA", "TX", "VT" };
            When(reg => !stateCheck11.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SchoolViolentEventResponseAGGL1000IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SchoolViolentEventResponseAGGL1000IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliSchoolViolentEventResponseAGGL1000IsSelectedIsInvalidForState);
                });
            });

            //"Validation 1:  When School Violent Event Response - AG GL 1000 IS Selected = True AND Primary Class IS NOT SC, MSC.
            //Message: Cannot rate the quote as School Violent Event Response - AG GL 1000 coverage is not available for the selected Primary Class.
            string[] primaryclass = new string[2] { "SC", "MSC" };
            When(reg => !primaryclass.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SchoolViolentEventResponseAGGL1000IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SchoolViolentEventResponseAGGL1000IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitySchoolViolentEventResponseAGGL1000LimitInValid);
                });

                //"Validation 1:  If Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 IS Selected = True AND  Primary Class IS NOT SC, MSC.
                //Message:  Cannot rate the quote as Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 coverage is not available with selected primary class .
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected)
                        .Equal(true)
                        .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310LimitInValid);
                });
            });

            //"Validation 1 : If School Violent Event Response - AG GL 1000 Is Selected = True AND
            //School Violent Event Response - AG GL 1000 Limit is zero in input json.
            //Message:  Cannot Rate the quote as School Violent Event Response - AG GL 1000 Limit is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SchoolViolentEventResponseAGGL1000IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SchoolViolentEventResponseAGGL1000AggregateLimit)
                  .NotEmpty()
                  .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitySchoolViolentEventResponseAGGL1000LimitMissing);

                //  When School Violent Event Response - AG GL 1000 IS Selected = True AND School Violent Event Response - AG GL 1000 Included In Excess Exposure value is missing in input json.
                //Message:Cannot rate the quote asSchool Violent Event Response - AG GL 1000 Included In Excess Exposure value is missing.
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SchoolViolentEventResponseAGGL1000IncludedinExcessExposure)
                  .NotEmpty()
                  .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitySchoolViolentEventResponseAGGL1000IncludedinExcessExposureInValid);

            });

            //Validation 1 :When Sewer Backup Aggregate Limit - GL-217 IS Selected = True AND
            //Sewer Backup Aggregate Limit - GL-217 Unmodified Premium is zero or less than zero in input json.
            //Message:Cannot rate the quote as Sewer Backup Aggregate Limit - GL-217 coverage Premium is invalid..
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupAggregateLimitGL217IsSelected
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupAggregateLimitGL217UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupAggregateLimitGL217UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitySewerBackupAggregateLimitGL217UnmodifiedPremiumInValid);
            });


            //Validation 1 :When Sewer Backup Sublimit - GL-260 IS Selected = True AND  Sewer Backup Sublimit - GL-260 Unmodified Premium is zero or less than zero in input json.
            //Message:Cannot rate the quote as Sewer Backup Sublimit - GL-260 coverage Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupSublimitGL260IsSelected
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupSublimitGL260UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.SewerBackupSublimitGL260UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitySewerBackupSublimitGL260UnmodifiedPremiumInValid);
            });

            //Validation 1 : When Additional Insured - Controlling Interest - CG 20 05 IS Selected = True AND Additional Insured - Controlling Interest - CG 20 05 unmodified Premium is zero or less than zero.
            //Message: Cannot rate the quote as Additional Insured - Controlling Interest - CG 20 05 Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredControllingInterestCG2005IsSelected
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredControllingInterestCG2005UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredControllingInterestCG2005UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredControllingInterestCG2005UnmodifiedPremiumInValid);
            });

            //"Validation 1 :  When Additional Insured - Controlling Interest - CG 20 05 IS Selected = True AND
            //Additional Insured - Controlling Interest - CG 20 05 Included In Excess Exposure value is missing in input json.
            //Message: Cannot rate the quote as Additional Insured - Controlling Interest - CG 20 05 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredControllingInterestCG2005IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredControllingInterestCG2005IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredControllingInterestCG2005IncludedinExcessExposureInValid);

            });

            //Validation 1 :When Additional Insured - Designated Person or Organization - CG 20 26 IS Selected = True AND
            //Additional Insured - Designated Person or Organization - CG 20 26 unmodified Premium is zero or less than zero.
            //Message: Cannot rate the quote as Additional Insured - Designated Person or Organization - CG 20 26 Premium is invalid..
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredDesignatedPersonorOrganizationCG2026UnmodifiedPremiumInValid);
            });

            //"Validation 1 : When Additional Insured - Designated Person or Organization - CG 20 26 IS Selected = True AND
            //Additional Insured - Designated Person or Organization - CG 20 26 Included In Excess Exposure value is missing in input json..
            //Message: Cannot rate the quote as Additional Insured - Designated Person or Organization - CG 20 26 Included In Excess Exposure value is missing
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonorOrganizationCG2026IsSelected, () =>
           {
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposure)
                   .NotEmpty()
                   .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposureInValid);

           });

            //"Validation 1 - IF Additional Insured - Designated Person Or Organization For a Specified Event - AG 7305 IS Selected = True AND  State IS NOT CT, DE, MA, ME, NH, VT.
            //Message:Cannot rate the quote as Additional Insured - Designated Person Or Organization For a Specified Event - AG 7305 coverage is not available in selected state.
            string[] stateCheck16 = new string[6] { "CT", "DE", "MA", "ME", "NH", "VT" };
            When(reg => !stateCheck16.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliAdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IsSelectedInvalidForState);
                });
            });

            //"Validation 1 :  When Additional Insured - Designated Person Or Organization For a Specified Event - AG 7305 IS Selected = True AND
            //Additional Insured - Designated Person Or Organization For a Specified Event - AG 7305 Included In Excess Exposure value is missing in input json.
            //Message:Cannot rate the quote as Additional Insured - Designated Person Or Organization For a Specified Event - AG 7305 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IsSelected, () =>
           {
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForaSpecifiedEventAG7305IncludedinExcessExposure)
                   .NotEmpty()
                   .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredDesignatedPersonorOrganizationCG2026IncludedinExcessExposureInValid);
           });

            //"Validation 1 -  If Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306 IS Selected = True AND
            //State IS NOT CT, DE, MA, ME, NH, VT.
            //Message:Cannot rate the quote as Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306 coverage is not available in selected state.
            string[] stateCheck17 = new string[6] { "CT", "DE", "MA", "ME", "NH", "VT" };
            When(reg => !stateCheck17.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelectedInvalidForState);
                });
            });

            //Validation 1 :When Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306 IS Selected = True AND
            //Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306 unmodified Premium is zero or less than zero.
            //Message:  Cannot rate the quote as Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306 Premium is invalid...
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelected, () =>
           {
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremium)
                   .GreaterThan(0)
                   .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306UnmodifiedPremiumInValid);
           });

            //"Validation 1 : When Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306 IS Selected = True AND Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306 Included In Excess Exposure value is missing in input json.
            //Message:Cannot rate the quote as Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7306IncludedinExcessExposureInValid);

            });

            //"Validation 1 -- If Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34 IS Selected = True AND
            //State IS NOT CT, DE, MA, ME, NH, VT.
            //Message: Cannot rate the quote as Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34 coverage is not available in selected state.
            string[] stateCheck18 = new string[6] { "CT", "DE", "MA", "ME", "NH", "VT" };
            When(reg => !stateCheck18.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliAdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IsSelectedInvalidForState);


                    //Validation 1 :When Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34 IS Selected = True AND Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34 unmodified Premium is zero or less than zero in input json.
                    //Message:  Cannot rate the quote as Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34 Premium is invalid.
                    When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium <= 0), () =>
                    {
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremium)
                            .GreaterThan(0)
                            .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034UnmodifiedPremiumInValid);
                    });
                });
            });

            //"Validation 1 : When Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34 IS Selected = True AND Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34 Included In Excess Exposure value is missing in input json.
            //Message:Cannot rate the quote as Additional Insured - Lessor Of Leased Equipment - Automatic Status When Required In Lease Agreement With You - CG 20 34 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredLessorOfLeasedEquipmentAutomaticStatusWhenRequiredInLeaseAgreementWithYouCG2034IncludedinExcessExposureInValid);

            });

            //Validation 1 : WhenAdditional Insured - Lessor of Leased Equipment - CG 20 28 IS Selected = True AND Additional Insured - Lessor of Leased Equipment - CG 20 28 unmodified Premium is zero or less than zero in input json
            //Message: Cannot rate the quote as Additional Insured - Lessor of Leased Equipment - CG 20 28 Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorofLeasedEquipmentCG2028IsSelected && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremium)
                    .NotEqual(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredLessorofLeasedEquipmentCG2028UnmodifiedPremiumInValid);
            });

            //"Validation 1 : When Additional Insured - Lessor of Leased Equipment - CG 20 28 IS Selected = True AND Additional Insured - Lessor of Leased Equipment - CG 20 28 Included In Excess Exposure value is missing in input json.
            //Message:Cannot rate the quote as Additional Insured - Lessor of Leased Equipment - CG 20 28 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorofLeasedEquipmentCG2028IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredLessorofLeasedEquipmentCG2028IncludedinExcessExposureInValid);

            });

            //"Validation 1 --  If Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307 IS Selected = True AND  State IS NOT CT, DE, MA, ME, NH, VT.
            //Message:  Cannot rate the quote as Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307 coverage is not available in selected state.
            string[] stateCheck19 = new string[6] { "CT", "DE", "MA", "ME", "NH", "VT" };
            When(reg => !stateCheck19.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabiliAdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelectedForState);
                });
            });

            //Validation 1 : When Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307 IS Selected = True AND Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307 unmodified Premium is zero or less than zero. 
            //Message: Cannot rate the quote as Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307 Premium is invalid
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelected
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307UnmodifiedPremiumInValid);
            });

            //"Validation 1 :  When Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307 IS Selected = True AND Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307 Included In Excess Exposure value is missing in input json.
            //Message: Cannot rate the quote as Additional Insured - Managers or Lessors of Premises - Automatic Status When Required in Agreement With You - AG 7307 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredManagersorLessorsofPremisesAutomaticStatusWhenRequiredinAgreementWithYouAG7307IncludedinExcessExposureInValid);
            });

            //Validation 1 :  When Additional Insured - Managers or Lessors of Premises - CG 20 11 IS Selected = True AND Additional Insured - Managers or Lessors of Premises - CG 20 11 unmodified Premium is zero or less than zero.
            //Message:  Cannot rate the quote as Additional Insured - Designated Person Or Organization For Designated Premises - AG 7306 Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesCG2011IsSelected
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredManagersorLessorsofPremisesCG2011UnmodifiedPremiumInValid);
            });

            //"Validation 1 : When Additional Insured - Managers or Lessors of Premises - CG 20 11 IS Selected = True AND AAdditional Insured - Managers or Lessors of Premises - CG 20 11 Included In Excess Exposure value is missing in input json.
            //Message:  Cannot rate the quote as Additional Insured - Managers or Lessors of Premises - CG 20 11 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesCG2011IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredManagersorLessorsofPremisesCG2011IncludedinExcessExposureInValid);

            });


            //Validation 1 :When Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18 IS Selected = True AND Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18 unmodified Premium is zero or less than zero.
            //Message: Cannot rate the quote as Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18 Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected
            && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredMortgageeAssigneeorReceiverCG2018UnmodifiedPremiumInValid);
            });

            //"Validation 1 : When Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18 IS Selected = True AND
            //Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18 Included In Excess Exposure value is missing in input json.
            //Message:  Cannot rate the quote as Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IsSelected, () =>
           {
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposure)
                   .NotEmpty()
                   .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredMortgageeAssigneeorReceiverCG2018IncludedinExcessExposureInValid);
           });

            //Validation 1 : When Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24 IS Selected = True AND Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24 unmodified Premium is zero or less than zero.
            //Message: Cannot rate the quote as Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24 Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IsSelected
                    && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024UnmodifiedPremiumInValid);
            });

            //"Validation 1 : When Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24 IS Selected = True AND Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24 Included In Excess Exposure value is missing in input json.
            //Message:  Cannot rate the quote as Additional Insured - Owners or Other Interests From Whom Land has Been Leased - CG 20 24 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredOwnersorOtherInterestsFromWhomLandhasBeenLeasedCG2024IncludedinExcessExposureInValid);

            });

            //Validation 1 :When Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 IS Selected = True AND Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 unmodified Premium is zero or less than zero in input json.
            //Message: Cannot rate the quote as Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310UnmodifiedPremiumInValid);
            });

            //"Validation 1 :  When Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 IS Selected = True AND Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 Included In Excess Exposure value is missing in input json.
            //Message:  Cannot rate the quote as Additional Insured - Students Involved In The School's Intership, Practicum And Teaching Program - AG 7310 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposureInValid);
            });

            //Validation 1 :When Additional Insured - Users of Golfmobiles - CG 20 08 IS Selected = True AND Additional Insured - Users of Golfmobiles - CG 20 08 unmodified Premium is zero or less than zero in input json.
            //Message:  Cannot rate the quote as Additional Insured - Users of Golfmobiles - CG 20 08 Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredUsersofGolfmobilesCG2008IsSelected && 
                        (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredUsersofGolfmobilesCG2008UnmodifiedPremiumInValid);
            });

            //"Validation 1 : When Additional Insured - Users of Golfmobiles - CG 20 08 IS Selected = True AND Additional Insured - Users of Golfmobiles - CG 20 08 Included In Excess Exposure value is missing in input json.
            //Message:  Cannot rate the quote as Additional Insured - Users of Golfmobiles - CG 20 08 Included In Excess Exposure value is missing.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredUsersofGolfmobilesCG2008IsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.AdditionalInsuredUsersofGolfmobilesCG2008IncludedinExcessExposure)
                    .NotEmpty()
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityAdditionalInsuredStudentsInvolvedInTheSchoolsInternshipPracticumAndTeachingProgramAG7310IncludedinExcessExposureInValid);
            });

            //"Validation 1 -If Limited Additional Insured - Designated Person Or Organization For Designated Premises - AG 7309 IS Selected = True
            //AND  State IS NOT CT, DE, MA, ME, NH, VT
            //Message: Cannot rate the quote as Additional Insured - Mortgagee, Assignee, or Receiver - CG 20 18 coverage is not available in selected state.
            string[] stateCheck22 = new string[6] { "CT", "DE", "MA", "ME", "NH", "VT" };
            When(reg => !stateCheck22.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IsSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IsSelected)
                    .Equal(true)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilitLimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IsSelectedForState);
                });
            });

            //Validation 1 :When  Limited Additional Insured - Designated Person Or Organization For Designated Premises - AG 73098 IS Selected = True AND Limited Additional Insured - Designated Person Or Organization For Designated Premises - AG 7309 unmodified Premium is zero or less than zero
            //Message:Cannot rate the quote as  Limited Additional Insured - Designated Person Or Organization For Designated Premises - AG 7309 Premium is invalid..
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309IsSelected && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium <= 0), () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.LimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremium)
                    .GreaterThan(0)
                    .WithMessage(x => Resources.ErrorMessages.InputModelGeneralLiabilityLimitedAdditionalInsuredDesignatedPersonOrOrganizationForDesignatedPremisesAG7309UnmodifiedPremiumInValid);
            });

        }

        public bool IsModelValid(RaterFacadeModel model)
        {
            if (model != null && model.RaterInputFacadeModel.LineOfBusiness != null)
            {
                if (model.RaterInputFacadeModel.LineOfBusiness.Property == true && model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability == null)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckForGeneralLiabilityOptionalCoverageInputModelDescription(RaterFacadeModel model, out string errorMessages)
        {

            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability.GeneralLiabilityOptionalCoverageModel.GeneralLiabilityOptionalOtherCoverageModel;
            bool valueToReturn = true;
            int index = 1;
            String stringIndex = string.Empty;
            errorMessages = string.Empty;
            if (checkModel != null)
            {
                foreach (var optionalCoverage in checkModel)
                {
                    if (string.IsNullOrEmpty(optionalCoverage.OtherCoverageDescription))
                    {
                        valueToReturn = false;
                        stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + "," + index) : index.ToString();
                    }
                    index++;
                }
            }

            errorMessages = !string.IsNullOrEmpty(stringIndex) ? (errorMessages + "At indexes [" + stringIndex + "]") : errorMessages;
            return valueToReturn;
        }

        public bool CheckForGeneralLiabilityOptionalCoverageLimit(bool checkFlag, decimal checkValue)
        {
            bool valueToReturn = false;
            if (checkFlag)
            {
                valueToReturn = true;
            }
            return valueToReturn;
        }

        /// <summary>
        /// Check For Min Max ValueExposureRate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueExposureRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetBaseRate(policyHeaderModel.State,
                                                    policyHeaderModel.PrimaryClass,
                                                    inputModel.LineOfBusiness,
                                                    policyHeaderModel.PolicyEffectiveDate,
                                                    policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "ExposureRate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "ExposureRate Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "ExposureRate Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }

        /// <summary>
        /// Check For Min Max Value Liability Limit Rate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueLiabilityLimitRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetLiabilityLimitRate(policyHeaderModel.State,
                                                              policyHeaderModel.PrimaryClass,
                                                              inputModel.LineOfBusiness,
                                                              policyHeaderModel.PolicyEffectiveDate,
                                                              policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "Liability Limit range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "Liability Limit Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "Liability Limit Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }

        /// <summary>
        /// Check For Min Max Value Population Factor
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValuePopulationFactor(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetPopulationFactor(policyHeaderModel.State,
                                                            policyHeaderModel.PrimaryClass,
                                                            inputModel.LineOfBusiness,
                                                            model.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA,
                                                            policyHeaderModel.PolicyEffectiveDate,
                                                            policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "Population Factor range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "Population Limit Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "Population Factor Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }


        /// <summary>
        /// Check For MinMax Value IRPMFactor
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueIRPMFactor(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetIRPMFactor(policyHeaderModel.State,
                                                      inputModel.LineOfBusiness,
                                                      policyHeaderModel.PolicyEffectiveDate,
                                                      policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "IRPMFactor range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "IRPMFactor Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "IRPMFactor Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }


        /// <summary>
        /// Check For MinMax Value OtherMode Factor
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueOtherModeFactor(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetOtherModeFactor(policyHeaderModel.State,
                                                          inputModel.LineOfBusiness,
                                                          policyHeaderModel.PolicyEffectiveDate,
                                                          policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "Other Mode Factor range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "Other Mode Factor Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "Other Mode Factor Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }

        /// <summary>
        /// Check For Min Max Value Cyber Limits 
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param> 
        /// <returns>bool</returns>  
        public bool CheckForMinMaxValueCyberLimits(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetCyberLimitsPremium(policyHeaderModel.State,
                                                              policyHeaderModel.PrimaryClass,
                                                              inputModel.LineOfBusiness,
                                                              "Computer Attack",
                                                              inputModel.ComputerAttackLimit,
                                                              policyHeaderModel.PolicyEffectiveDate,
                                                              policyHeaderModel.PolicyExpirationDate);

            if (dataTable == null)
            {
                message = "CyberLimit range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "CyberLimit Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "CyberLimit Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }

        /// <summary>
        /// Check For Min Max Value Population Factor
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueCyberPopulation(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetCyberPopulation(policyHeaderModel.State,
                                                            policyHeaderModel.PrimaryClass,
                                                            inputModel.LineOfBusiness,
                                                            "Cyber",
                                                            policyHeaderModel.PopulationADA,
                                                            policyHeaderModel.PolicyEffectiveDate,
                                                            policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "Cyber Population Factor range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "Cyber Population Factor Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "Cyber Population Factor Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }

        /// <summary>
        /// Check For Min Max Value Unmanned Aircrafts  
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueUnmannedAircrafts(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetUnmannedAircrafts(policyHeaderModel.State,
                                                            inputModel.LineOfBusiness,
                                                           "Unmanned Aircraft",
                                                            inputModel.UnmannedAircraftOption,
                                                            policyHeaderModel.PolicyEffectiveDate,
                                                            policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "UnmannedAircraftMinMax range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "UnmannedAircraftMinMax Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "UnmannedAircraftMinMax Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }

        /// <summary>
        /// Check For Min Max Value Unmanned Aircrafts  
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueUnmannedAircrafts15ToLessThan55lbs(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetUnmannedAircrafts15ToLessThan55lbs(policyHeaderModel.State,
                                                                              inputModel.LineOfBusiness,
                                                                              "Unmanned Aircraft",
                                                                              inputModel.UnmannedAircraftOption,
                                                                              policyHeaderModel.PolicyEffectiveDate,
                                                                              policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "UnmannedAircrafts15ToLessThan55lbs range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "UnmannedAircrafts15ToLessThan55lbs Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "UnmannedAircrafts15ToLessThan55lbs Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }

        /// <summary>
        /// Check For Min Max Value Unmanned Aircrafts  
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueUnmannedAircrafts55lbs(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetUnmannedAircrafts55lbs(policyHeaderModel.State,
                                                                  inputModel.LineOfBusiness,
                                                                  "Unmanned Aircraft",
                                                                  inputModel.UnmannedAircraftOption,
                                                                  policyHeaderModel.PolicyEffectiveDate,
                                                                  policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "UnmannedAircrafts55lbs range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "UnmannedAircrafts55lbs Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "UnmannedAircrafts55lbs Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }

        /// <summary>
        /// Check For Min Max Value Unmanned Aircrafts  
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueCyberLimitDeductible(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.GeneralLiability;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetCyberLimitDeductible(policyHeaderModel.State,
                                                                  inputModel.LineOfBusiness,
                                                                  "Computer Attack", inputModel.UnmannedAircraftOption,
                                                                  policyHeaderModel.PolicyEffectiveDate,
                                                                  policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "CyberLimitDeductible range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "CyberLimitDeductible Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "CyberLimitDeductible Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }

    }
}
