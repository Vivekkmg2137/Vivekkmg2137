﻿using AutoMapper;
using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Validations
{
    public class LawPostValidator : AbstractValidator<RaterFacadeModel>
    {
        private LawDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        readonly Microsoft.Extensions.Configuration.IConfiguration configuration;

        private readonly IMapper _mapper;

        public LawPostValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.Logger = logger;
            this.DataAccess = new LawDataAccess(this.configuration, this.Logger);

            //todo No such filed found
            //"Validation 1: If Unmanned aircraft Option = ""Unmanned Aircraft Sublimit - LE105"" OR ""Unmanned Aircraft Policy Limit - LE104""
            //AND Unmanned Aircraft Total Units <= zero
            //Message: Cannot Rate the quote as Unmanned Aircraft Total Units is missing.
            When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftOption)
                 && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftOption.ToUpper() == "UNMANNED AIRCRAFT SUBLIMIT - LE105"
                 || reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftOption.ToUpper() == "UNMANNED AIRCRAFT POLICY LIMIT - LE104"), () =>
                 {
                     this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.LawEnforcement.UnmannedAircraftTotalUnits)
                         .GreaterThan(0)
                         .WithMessage(x => Resources.ErrorMessages.InputModelUnmannedAircraftcoverage55lbsTotalUnitsInvalid);
                 });
        }
    }
}
