﻿using AutoMapper;
using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Validations
{
    public class LawPreValidator : AbstractValidator<RaterFacadeModel>
    {
        private LawDataAccess _dataAccess { get; set; }
        protected ILoggingManager _logger { get; private set; }

        readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;

        private readonly IMapper _mapper;

        public LawPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this._configuration = configuration;
            this._logger = logger;
            this._dataAccess = new LawDataAccess(this._configuration, this._logger);

            string[] statesExrate = { "MO", "NY" };
            List<string> stateCheckListExrate = new List<string>(statesExrate);

            When(reg => !stateCheckListExrate.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper()), () =>
            {
                //" Validation 1: When entered Exposure rate is not within the defined range
                //Message - Cannot Rate the quote as Exposure rate is invalid."
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.ExposureRate >= 0, () =>
                {
                    string errorMessageExposureRate = string.Empty;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.ExposureRate)
                        .Must((modelObject, value) => CheckRangeForExposureRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.ExposureRate, modelObject, out errorMessageExposureRate))
                        .WithMessage(x => !string.IsNullOrEmpty(errorMessageExposureRate) ? errorMessageExposureRate : Resources.ErrorMessages.InputModelLawExposureRateNotInRange);
                });
            });

            string[] statesLLR = { "AL", "CO", "CT", "DE", "GA", "IL", "IN", "MA", "ME", "MI", "MN", "MS", "NC", "NH", "OH", "PA", "SC", "TX", "UT", "VT", "WY" };
            List<string> stateCheckListLLR = new List<string>(statesLLR);

            When(reg => stateCheckListLLR.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper()), () =>
            {
                //"Validation 1: If Liability Limit input field is missing.
                //Message: Cannot Rate the quote as Liability Limit is invalid.
                //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Law.LiabilityLimit)
                //.NotNull().WithMessage(x => Resources.ErrorMessages.InputModelLawLiabilityLimitMissing);

                //Validation 2: When entered Liability Limit Rate is not within the defined range
                //Message: Cannot Rate the quote as Liability Limit rate is invalid."
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LiabilityLimitRate >= 0, () =>
                {
                    string errorMessageLiabilityLimitRate = string.Empty;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LiabilityLimitRate)
                        .Must((modelObject, value) => CheckRangeForProfLinesLiabilityLimitRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LiabilityLimitRate, modelObject, out errorMessageLiabilityLimitRate))
                        .WithMessage(x => !string.IsNullOrEmpty(errorMessageLiabilityLimitRate) ? errorMessageLiabilityLimitRate : Resources.ErrorMessages.InputModelLawLiabilityLimitRateNotInRange);
                });
            });

            #region Skipped by BA in version 1.4

            ////"Validation 1: If ""Deductible/SIR"" input field value is missing. (applicable for MI, MS, NY & OH state only)
            ////Message: Cannot Rate the quote as Deductible / SIR is invalid.
            //string[] states1 = { "MS", "NY", "OH" };
            //List<string> stateCheckList1 = new List<string>(states1);
            //When(reg => stateCheckList1.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper()), () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.Deductible_SIR)
            //        .NotEmpty()
            //        .WithMessage(x => Resources.ErrorMessages.InputModelLawDeductible_SIRMissing);
            //});

            ////Validation 2 : If "Retention" input field value is missing.
            ////Message: Cannot Rate the quote as Retention is invalid."
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.Retention)
            //    .NotEmpty()
            //    .WithMessage(x => Resources.ErrorMessages.InputModelLawRetentionMissing);

            #endregion

            //"Validation 1: If ""Population / ADA"" input field value is missing.             
            //Message: Cannot Rate the quote as Population / ADA is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .NotNull()
                .WithMessage(x => Resources.ErrorMessages.InputAutoLiabilityPopulationADARequired);

            //Validation 2: If Population entered is greater than 99999999
            //Message: Cannot Rate the quote as Population / ADA is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .LessThanOrEqualTo(99999999)
                .WithMessage(x => Resources.ErrorMessages.InputLawPopulationADAOutOfRange);

            //"Validation 1: If ""Location Type"" input field value is missing. 
            //Message: Cannot Rate the quote as Location Type is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.LocationType)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelLawLocationTypeRequired);

            //"Validation 1: If ""Policy Type"" input field value is missing. 
            //Message: Cannot Rate the quote as Policy Type is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.PolicyType)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelLawPolicyTypeMissing);

            #region Give some reason for commenting this code

            //"Validation 1: If ""Years In CM Program"" input field value is missing. 
            //Message: Cannot Rate the quote as Years In Claims Made Program is invalid."
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Law.YearsinCMProgram)
            //      .NotEmpty().WithMessage(x => Resources.ErrorMessages.InputModelLawYearsinCMProgramMissing);

            //"Validation 1: If ""Retroactive Date"" input field value is missing and Policy Type = Claims Made. 
            //Validation 2: If entered ""Retroactive Date""  value is later than ""Effective Date"".
            //Message: Cannot Rate the quote as Retroactive Date is invalid."
            //When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Law.PolicyType == "Claims Made", () =>
            //{
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Law.RetroActiveDate)
            //    .NotNull().WithMessage(x => Resources.ErrorMessages.InputModelLawRetroactiveDateInvalid);
            //});

            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Law.ExposureRate)
            //.Must((modelObject, value) => CheckRetroactiveDate(modelObject))
            //.WithMessage(x => Resources.ErrorMessages.InputModelLawRetroactiveDateInvalid);

            #endregion

            //"Validation 1: If ""IRPM Rate"" input field value is missing. 
            //Validation 2: When entered IRPM is not within the defined range
            //Message: Cannot Rate the quote as IRPM value is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.IRPMRate)
                .NotNull()
                .WithMessage(x => Resources.ErrorMessages.InputModelLawIRPMRateInvalid);

            // Validation 1: If "IRPM Rate" input field value is missing.
            //Validation 2: When entered IRPM is not within the defined range
            string messageIRPMRate = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.IRPMRate)
                .Must((modelObject, value) => CheckRangeForIRPMRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.IRPMRate, modelObject, out messageIRPMRate))
                .WithMessage(x => !string.IsNullOrEmpty(messageIRPMRate) ? messageIRPMRate : Resources.ErrorMessages.InputModelLawIRPMRateInvalid);

            //"Validation 1: If ""Other Mod Rate"" input field value is missing. 
            //Validation 2: When entered Other Mod is not within the defined range
            //Message: Cannot Rate the quote as Other Mod value is invalid."
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.OtherModRate)
                .NotNull()
                .WithMessage(x => Resources.ErrorMessages.InputModelLawOtherModRateInvalid);

            string messageOtherModRate = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.OtherModRate)
                .Must((modelObject, value) => CheckRangeForOtherModRate(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.OtherModRate, modelObject, out messageOtherModRate))
                .WithMessage(x => !string.IsNullOrEmpty(messageOtherModRate) ? messageOtherModRate : Resources.ErrorMessages.InputModelLawOtherModRateInvalid);

            //"Validation 1: If  Unmanned aircraft Option = ""Unmanned Aircraft Sublimit - LE105"" OR ""Unmanned Aircraft Policy Limit - LE104"" AND 'Aggregate Limit' input field value is missing. 
            //Message: Cannot Rate the quote as Unmanned Aircraft Aggregate Limit is invalid"
            When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftOption) 
                && (reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftOption.ToUpper() == "UNMANNED AIRCRAFT SUBLIMIT - LE105"
                || reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftOption.ToUpper() == "UNMANNED AIRCRAFT POLICY LIMIT - LE104"), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftAggregateLimit)
                        .NotNull()
                        .WithMessage(x => Resources.ErrorMessages.InputModelLawUnmannedAircraftAggregateLimitInvalid);

                    string[] statesCoverage = { "AL", "CO", "GA", "KS", "DE", "ME", "MA", "MI", "MN", "IL", "IN", "OH", "NC", "NH", "NY", "PA", "SC", "TX", "UT", "VT", "WY" };
                    List<string> stateCheckListCovefrage = new List<string>(statesCoverage);

                    When(reg => stateCheckListCovefrage.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper()), () =>
                    {
                        When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverage15lbsorLessRate >= 0, () =>
                        {
                         //"Validation 1: If  Unmanned aircraft Option = ""Unmanned Aircraft Sublimit - LE105"" OR ""Unmanned Aircraft Policy Limit - LE104""
                         //AND 'Unmanned Aircraft Coverage 15 lbs or Less Rate' input value is not within the defined range.
                         //Message: Cannot Rate the quote as Unmanned Aircraft Weight -15 lbs or Less Rate is invalid.
                         string messageUnmannedAircraftcoverage15lbsorLessRate = string.Empty;
                            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverage15lbsorLessRate)
                             .Must((modelObject, value) => CheckRangeForUnmannedAircraftMinMaxFactor(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverage15lbsorLessRate,
                              modelObject, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftOption, 15, out messageUnmannedAircraftcoverage15lbsorLessRate))
                             .WithMessage(x => !string.IsNullOrEmpty(messageUnmannedAircraftcoverage15lbsorLessRate) ? messageUnmannedAircraftcoverage15lbsorLessRate : Resources.ErrorMessages.InputModelLawUnmannedAircraftcoverage15lbsorLessRateMissing);
                        });

                        When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverage15PT1_to_lt55lbsRate >= 0, () =>
                        {
                          //"Validation 1: If  Unmanned aircraft Option = "Unmanned Aircraft Sublimit - LE105" OR "Unmanned Aircraft Policy Limit - LE104" AND 'Unmanned Aircraft 15.1 to < 55 lbs rate' input field value is not withn the defined range.
                          //Message: Cannot Rate the quote as Unmanned Aircraft Weight - 15.1 to < 55 lbs rate is invalid
                          string messageUnmannedAircraftcoverage15lbsto55lbs = string.Empty;
                          this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverage15PT1_to_lt55lbsRate)
                              .Must((modelObject, value) => CheckRangeForUnmannedAircraftMinMaxFactor(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverage15PT1_to_lt55lbsRate, modelObject, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftOption, 1555, out messageUnmannedAircraftcoverage15lbsto55lbs))
                              .WithMessage(x => !string.IsNullOrEmpty(messageUnmannedAircraftcoverage15lbsto55lbs) ? messageUnmannedAircraftcoverage15lbsto55lbs : Resources.ErrorMessages.InputModelLawUnmannedAircraftcoverage15lbsTo55lbsRateMissing);
                         });

                        When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverage_gteq55lbslbsRate >= 0, () =>
                        {
                         //"Validation 1: If Unmanned aircraft Option = ""Unmanned Aircraft Sublimit - LE105"" OR ""Unmanned Aircraft Policy Limit - LE104""
                         //AND 'Unmanned Aircraft Coverage ≥ 55 lbs Rate' input field value is not withn the defined range.
                         //Message: Cannot Rate the quote as Weight - - ≥ 55 lbs Rate is invalid"
                         string messageUnmannedAircraftcoverage55lbslbsRate = string.Empty;
                         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverage_gteq55lbslbsRate)
                             .Must((modelObject, value) => CheckRangeForUnmannedAircraftMinMaxFactor(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverage_gteq55lbslbsRate, modelObject, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftOption, 55, out messageUnmannedAircraftcoverage55lbslbsRate))
                             .WithMessage(x => !string.IsNullOrEmpty(messageUnmannedAircraftcoverage55lbslbsRate) ? messageUnmannedAircraftcoverage55lbslbsRate : Resources.ErrorMessages.InputModelLawUnmannedAircraftcoverage55lbslbsRateMissing);
                        });
                    });
               
                    //"Validation 1: If  Unmanned aircraft Option = ""Unmanned Aircraft Sublimit - LE105"" OR ""Unmanned Aircraft Policy Limit - LE104"" AND 'Unmanned Aircraft Coverage Included in Excess Exposure' input field value is missing. 
                    //Message: Cannot Rate the quote as 'Included in Excess Exposure' option for Unmanned Aircraft coverage is missing"
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.UnmannedAircraftCoverageIncludedInExcessExposure)
                        .NotEmpty()
                        .WithMessage(x => Resources.ErrorMessages.InputModelLawIncludedinExcessExposureMissing);
                });

            //Validation 1: If Additional Insured - Law Enforcement Agencies Is Selected =1 and  Additional Insured - Law Enforcement Agencies Unmodified Premium is Missing
            //Message: Cannot Rate the quote as Additional Insured - Law Enforcement Agencies -AG LE 0006 Coverage Premium is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel != null && reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.AdditionalInsuredLawEnforcementAgenciesIsSelected == true, () =>
            {
                //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Law.LawOptionalCoverageInputModel.AdditionalInsuredLawEnforcementAgenciesUnmodifiedPremium)
                //.NotNull().WithMessage(x => Resources.ErrorMessages.InputModelLawAdditionalInsuredLawEnforcementAgenciesUnmodifiedPremiumMissing);

                //Validation 2: If Additional Insured - Law Enforcement Agencies Is Selected = 1 and State = NY
                //Message: Cannot Rate the quote as Additional Insured - Law Enforcement Agencies -AG LE 0006 Coverage is not available in NY State.
                this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper())
                    .NotEqual("NY")
                    .WithMessage(x => Resources.ErrorMessages.InputModelLawAdditionalInsuredLawEnforcementAgenciesNotApplicableForNY);
            });

            //"Validation 1: If Suppl. Extended Reporting Period Is Selected = 1 and state = NY
            // Message: Cannot Rate the quote as Suppl.Extended Reporting Period coverage is not available in selected state.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel != null && reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected == true, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper())
                    .NotEqual("NY")
                    .WithMessage(x => Resources.ErrorMessages.InputModelLawSupplExtendedReportingPeriodIsSelectedNotApplicableForNY);
            });

            //Validation 1: If Suppl. Extended Reporting Period Limit input field value is missing. 
            //Message: Cannot Rate the quote as Suppl.Extended Reporting Period Limit is invalid.
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.SupplExtendedReportingPeriodLimit)
                    .NotNull()
                    .WithMessage(x => Resources.ErrorMessages.InputModelLawSupplExtendedReportingPeriodLimitIsInvalid);

            //Validation 1: If Ny Suppl.Extended Reporting Period Is Selected = 1 AND State IS NOT NY
            //Message:  Cannot Rate the quote as Suppl.Extended Reporting Period-NY coverage is not available in selected state.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel != null && reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.NYSupplExtendedReportingPeriodIsSelected == true, () =>
                  {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper())
                        .Equal("NY")
                        .WithMessage(x => Resources.ErrorMessages.InputModelLawNYSupplExtendedReportingPeriodIsSelectedNotApplicableForOtherThanNY);
                  });

            //"Validation 1: If  Non Monetary Defense Coverage Is Selected =1 and State = NY OR DE
            //Message: Cannot Rate the quote as Non Monetary Defense Coverage is not available in selected State.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel != null &&
                 reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NY || reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.DE, () =>
                 {
                     this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.NonMonetaryDefenseIsSelected)
                         .Equal(false)
                         .WithMessage(x => Resources.ErrorMessages.InputModelLawNonMonetaryDefenseIsSelectedNotApplicableForSelectedState);
                 });

            //Validation 2: If Non Monetary Defense Coverage Is Selected = 1 AND Primary Class = Municipality(MU) OR County(CO) OR Private / Non - Profit(PNP)
            //Message: Cannot Rate the quote as Non Monetary Defense Coverage is not available for selected Primary Class."
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel != null &&
                reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass == "MU" || reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass == "CO"
                || reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass == "PNP", () =>
                    {
                       this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.NonMonetaryDefenseIsSelected)
                           .Equal(false)
                           .WithMessage(x => Resources.ErrorMessages.InputModelLawNonMonetaryDefenseIsSelectedNotApplicableForPrimaryClass);
                    });

            //"Validation 1: If  Line of Duty Death Benefits Coverage Is selected = 1 and State = NY
            //Message: Cannot Rate the quote as Non Monetary Defense Coverage is not available in selected State."
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel != null &&
            reg.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.NY, () =>
                    {
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement.LawEnforcementOptionalCoverageModel.LineOfDutyDeathBenefitsIsSelected)
                            .Equal(false)
                            .WithMessage(x => Resources.ErrorMessages.InputModelLawNonMonetaryDefenseIsSelectedNotApplicableForState);
                    });
        }

        /// <summary>
        /// CheckRangeForProfLinesLiabilityLimitRate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool CheckRangeForExposureRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var lawInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            DataTable dataTable = null;
            message = string.Empty;
            bool flag = false;

            dataTable = this._dataAccess.GetProfLinesExposureRateMinMax(policyHeaderModel.State, policyHeaderModel.PrimaryClass, lawInputModel.LineOfBusiness, policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "ExposureRate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "ExposureRate Min range does not exist.";
                }

                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "ExposureRate Max range does not exist.";
                }

                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckRangeForProfLinesLiabilityLimitRate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool CheckRangeForProfLinesLiabilityLimitRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var lawInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            DataTable dataTable = null;
            message = string.Empty;
            bool flag = false;

            dataTable = this._dataAccess.GetProfLinesLiabilityLimitRateMinMax(policyHeaderModel.State, lawInputModel.LineOfBusiness, lawInputModel.LiabilityLimit, policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "LiabilityLimitRate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "LiabilityLimitRate Min range does not exist.";
                }

                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "LiabilityLimitRate Max range does not exist.";
                }

                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }


        public bool CheckRangeForIRPMRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var lawInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            DataTable dataTable = null;
            message = string.Empty;
            bool flag = false;

            dataTable = this._dataAccess.GetProfLinesIRPMRateMinMax(policyHeaderModel.State, lawInputModel.LineOfBusiness, policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "IRPMRate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "IRPMRate Min range does not exist.";
                }

                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "IRPMRate Max range does not exist.";
                }

                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        public bool CheckRangeForOtherModRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var lawInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            DataTable dataTable = null;
            message = string.Empty;
            bool flag = false;

            dataTable = this._dataAccess.GetProfLinesOtherModRateMinMax(policyHeaderModel.State, lawInputModel.LineOfBusiness, policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "OtherModRate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "OtherModRate Min range does not exist.";
                }

                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "OtherModRate Max range does not exist.";
                }

                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckRetroactiveDate
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public bool CheckRetroactiveDate(RaterFacadeModel model)
        {
            bool returnFlag = true;
            var inputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            if (inputModel.RetroActiveDate > policyHeaderModel.PolicyEffectiveDate)
            {
                returnFlag = false;
            }

            return returnFlag;
        }

        public bool CheckRangeForUnmannedAircraftMinMaxFactor(decimal valueTocheck, RaterFacadeModel model, string coverageType, int type, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var lawInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.LawEnforcement;
            DataTable dataTable = null;
            message = string.Empty;
            bool flag = false;

            dataTable = this._dataAccess.GetProfLinesUnmannedAircraftMinMaxFactor(policyHeaderModel.State, lawInputModel.LineOfBusiness, coverageType, type, policyHeaderModel.PolicyEffectiveDate, policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "UnmannedAircraftMinMax range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "UnmannedAircraftMinMax Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "UnmannedAircraftMinMax Max range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }
    }
}
