﻿
namespace Validations
{
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Microsoft.Extensions.Configuration;
    using Models.ApiModels;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class OCPPostValidator : AbstractValidator<RaterFacadeModel>
    {
        private OCPDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }
        readonly IConfiguration configuration;
        public OCPPostValidator(IConfiguration configuration,ILoggingManager logger)
        {
            this.Logger = logger;
            this.DataAccess = new OCPDataAccess(this.configuration,this.Logger);
        }        
    }
}
