﻿
namespace Validations
{
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Microsoft.Extensions.Configuration;
    using Models.ApiModels;
    using Models.ApiModels.LineOfBusiness.Ocp.Input;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class OCPPreValidator : AbstractValidator<RaterFacadeModel>
    {
        private OCPDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }
        private IConfiguration configuration { get; set; }
        public OCPPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.DataAccess = new OCPDataAccess(this.configuration, this.Logger);

            #region Model Validation
            When(reg => reg.RaterInputFacadeModel.LineOfBusiness != null, () =>
            {
                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                      .Must((modelObject, selectedLineOfBusiness) => IsModelValid(modelObject.RaterInputFacadeModel.LineOfBusiness.Ocp1,modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1))
                      .WithMessage(x => string.Format("Input JSON is not valid for LOBs"));

                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                      .Must((modelObject, selectedLineOfBusiness) => 
                      IsModelValid(modelObject.RaterInputFacadeModel.LineOfBusiness.Ocp2,modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp2))
                      .WithMessage(x => string.Format("Input JSON is not valid for LOBs"));

                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                      .Must((modelObject, selectedLineOfBusiness) => 
                      IsModelValid(modelObject.RaterInputFacadeModel.LineOfBusiness.Ocp3,modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp3))
                      .WithMessage(x => string.Format("Input JSON is not valid for LOBs"));

                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                      .Must((modelObject, selectedLineOfBusiness) => 
                      IsModelValid(modelObject.RaterInputFacadeModel.LineOfBusiness.Ocp4,modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp4))
                      .WithMessage(x => string.Format("Input JSON is not valid for LOBs"));

                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                      .Must((modelObject, selectedLineOfBusiness) => 
                      IsModelValid(modelObject.RaterInputFacadeModel.LineOfBusiness.Ocp5,modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp5))
                      .WithMessage(x => string.Format("Input JSON is not valid for LOBs"));

                  When(reg => reg.RaterInputFacadeModel.LineOfBusiness.Ocp1 == true, () =>
                  {
                           this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1.Limit)
                               .NotEmpty()
                               .WithMessage(Resources.ErrorMessages.InputModelOCPLimitMissing);

                           this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1.Description)
                               .NotEmpty()
                               .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing)
                               .NotNull()
                               .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing);

                           this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1.Name)
                               .NotEmpty()
                               .WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing)
                               .NotNull()
                               .WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing);

                           this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp1.AggregateLimit)
                               .NotEmpty()
                               .WithMessage(Resources.ErrorMessages.InputModelOCPAggregateLimitMissing);
                  });

                  When(reg => reg.RaterInputFacadeModel.LineOfBusiness.Ocp2 == true, () =>
                  {
                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp2.Limit)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPLimitMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp2.Description)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing)
                          .NotNull()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp2.Name)
                      .NotEmpty().WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing)
                      .NotNull().WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp2.AggregateLimit)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPAggregateLimitMissing);
                  });

                  When(reg => reg.RaterInputFacadeModel.LineOfBusiness.Ocp3 == true, () =>
                  {
                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp3.Limit)
                           .NotEmpty()
                           .WithMessage(Resources.ErrorMessages.InputModelOCPLimitMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp3.Description)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing)
                          .NotNull()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp3.Name)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing)
                          .NotNull()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp3.AggregateLimit)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPAggregateLimitMissing);
                  });

                  When(reg => reg.RaterInputFacadeModel.LineOfBusiness.Ocp4 == true, () =>
                  {
                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp4.Limit)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPLimitMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp4.Description)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing)
                          .NotNull()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp4.Name)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing)
                          .NotNull()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp4.AggregateLimit)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPAggregateLimitMissing);
                  });

                  When(reg => reg.RaterInputFacadeModel.LineOfBusiness.Ocp5 == true, () =>
                  {
                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp5.Limit)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPLimitMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp5.Description)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing)
                          .NotNull()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPDescriptionMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp5.Name)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing)
                          .NotNull()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPNameMissing);

                      this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Ocp5.AggregateLimit)
                          .NotEmpty()
                          .WithMessage(Resources.ErrorMessages.InputModelOCPAggregateLimitMissing);
                  });
              });

            #endregion
        }

        public bool IsModelValid(bool allowOcP, OcpInputModel ocpInputModel)
        {
            if (allowOcP == true && ocpInputModel == null)
            {
                return false;
            }
            return true;
        }
    }
}
