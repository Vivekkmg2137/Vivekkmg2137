﻿// <copyright file="ProviderAddressContactDeleteViewModelValidator.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Validations
{
    using FluentValidation;
    using Models;

    public class PersonDeleteValidator : AbstractValidator<Person>
    {
        public PersonDeleteValidator()
        {
            // NotEmpty, NotEqual, Matches, Must
            this.RuleFor(reg => reg.Reason)
               .NotEmpty().WithMessage("Reason is required!")
               .Matches("^[^\"<>;]+$").WithMessage("Reason: Invalid characters (< > ; \") are not allowed!")
               .MaximumLength(500);
        }
    }
}
