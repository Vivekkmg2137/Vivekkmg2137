﻿// <copyright file="ProviderViewModelValidator.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Validations
{
    using System;
    using System.Collections.Generic;
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Microsoft.Extensions.Configuration;
    using Models;

    public class PersonValidator : AbstractValidator<Person>
    {
        private PropertyDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }
        readonly IConfiguration configuration;

        public PersonValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.DataAccess = new PropertyDataAccess(this.configuration,this.Logger);

            // Pre check if we need this validation to fire up
            //If CheckProfession is false, this validation will not fire up
            this.When(this.CheckProfession, () =>
            {
                this.RuleFor(reg => reg.Profession)
                    .NotEmpty()
                    .WithMessage("Profession must be 10 digits numeric only!");
            });

            this.RuleFor(reg => reg.Age)
                .InclusiveBetween(10, 99)
                .WithMessage("Invalid age")
                .GreaterThan(18)
                .WithMessage("Age cannot be less  than 18");

            this.RuleFor(reg => reg.Code)
                .Matches(@"^\d{9}$")
                .When(x => !string.IsNullOrEmpty(x.Code))
                .WithMessage("Code must be 9 digits numeric only!")
                .Must((DataAccess, Code) => this.IsUniqueCode(Code, DataAccess))
                .WithMessage("Value should be Unique. Given value already exists in database!");

            this.RuleFor(reg => reg.Name)
                .NotEmpty()
                .WithMessage("First Name is required!")
                .MaximumLength(50)
                .Matches(@"^[a-zA-Z]*$")
                .WithMessage("First Name can be alphabet only!");

            this.RuleFor(reg => reg.Phone)
                .Matches(@"^\D?(\d{3})\D?\D?(\d{3})\D?(\d{4})$")
                .When(x => !string.IsNullOrEmpty(x.Phone))
                .WithMessage("Phone must be 10 digits numeric only!")
                .MaximumLength(10)
                .WithMessage("Phone must be 10 digits numeric only!");


            this.RuleFor(reg => reg.Email)
              .Matches(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,5}$").When(x => !string.IsNullOrEmpty(x.Email)).WithMessage("Invalid Email!")
              .MaximumLength(50);

            this.RuleFor(reg => reg.BirthDate)
                .Must((modelObject, birthDate) => CommonFluents.ValidateDate(modelObject.BirthDate.ToString())).WithMessage("Birth Date is not valid date!");

            this.When(reg => CommonFluents.ValidateDate(Convert.ToString(reg.BirthDate)), () =>
              {
                  this.When(reg => !String.IsNullOrEmpty(reg.BirthDate.ToString()) && reg.BirthDate.ToString() != "12/31/9999", () =>
                  {
                      this.RuleFor(reg => Convert.ToDateTime(reg.BirthDate))
                      .LessThanOrEqualTo(DateTime.UtcNow)
                      .WithMessage("Birth Date should be less than or equal to current date!");
                  });
              });

            // Gender Is Exist or Not in Dictionary
            this.When(x => !string.IsNullOrEmpty(x.Gender), () =>
            {
                this.RuleFor(reg => reg.Gender)
                    .Must((modelObject, gender) =>
                    IsGender(modelObject))
                    .WithMessage("Gender Does Not Exist!");
            });

            // Married Is Exist or Not in Dictionary
            this.RuleFor(reg => reg.Married)
                .Must((modelObject, married) =>
                IsMarried(modelObject))
                .WithMessage("Married Does Not Exist!");
        }

        /// <summary>
        ///  Check if user is on create page. On edit page, user can not update NPI
        /// </summary>
        /// <param name="model">Person</param>
        /// <returns>Bool</returns>
        public bool CheckProfession(Person model)
        {
            if (model.Id == int.MinValue && !string.IsNullOrEmpty(model.Profession))
            {
                if (model.IsProfessionFake == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// To check duplicate 
        /// </summary>
        /// <param name="code">Code</param>
        /// <param name="model">ProviderViewModel</param>
        /// <returns>Bool Value</returns>
        public bool IsUniqueCode(string code, Person model)
        {
            var result = true;
            if (!string.IsNullOrEmpty(code))
            {
                //result = this.DataAccess.CheckInDatabase(model.Code).Result;
                result = true;
            }

            return result;
        }

        /// <summary>
        /// Validate the Open Hour
        /// </summary>
        /// <param name="model"> Object of ProviderViewModel</param>
        /// <returns>bool</returns>
        private bool IsDOBValidDate(Person model)
        {
            // If DOB not null
            if (model.BirthDate != null)
            {
                // Validate the date
                return CommonFluents.ValidateDate(Convert.ToString(model.BirthDate));
            }

            // Return the result
            return true;
        }

        /// <summary>
        /// Check Gender value Exist or not 
        /// </summary>
        /// <param name="model">ProviderViewModel</param>
        /// <returns>Bool value</returns>
        public bool IsGender(Person model)
        {
            Dictionary<string, string> genderList = StaticDropDownDictionaries.GenderDictionary();

            if (genderList.ContainsKey(model.Gender))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        /// <summary>
        /// Check Married value Exist or not 
        /// </summary>
        /// <param name="model">ProviderViewModel</param>
        /// <returns>Bool value</returns>
        public bool IsMarried(Person model)
        {
            Dictionary<string, string> marriedList = Models.StaticDropDownDictionaries.MarriedDictionary();
            if (!string.IsNullOrEmpty(model.Married))
            {
                if (marriedList.ContainsKey(model.Married))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }
    }
}