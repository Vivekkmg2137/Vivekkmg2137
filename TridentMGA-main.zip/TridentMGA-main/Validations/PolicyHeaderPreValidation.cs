﻿using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Validations
{
    public class PolicyHeaderPreValidation : AbstractValidator<RaterFacadeModel>
    {
        private PropertyDataAccess PropertyDataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }

        readonly IConfiguration configuration;

        public PolicyHeaderPreValidation(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.configuration = configuration;
            this.PropertyDataAccess = new PropertyDataAccess(this.configuration, this.Logger);

            //this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.Id)
            //    .NotNull().WithMessage(Resources.ErrorMessages.InputPolicyHeaderIdRequired)
            //    .NotEqual(0).WithMessage(Resources.ErrorMessages.InputPolicyHeaderIdRequired);

            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.ClientId)
                .NotEmpty().WithMessage(Resources.ErrorMessages.InputPolicyHeaderClientIdRequired);

            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.TransactionType)
                .NotEmpty().WithMessage(Resources.ErrorMessages.InputPolicyHeaderTransactionTypeRequired);

            //this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.QuoteId)
            //    .NotNull().WithMessage(Resources.ErrorMessages.InputPolicyHeaderQuoteIdRequired)
            //    .NotEqual(0).WithMessage(Resources.ErrorMessages.InputPolicyHeaderQuoteIdRequired);

            // To-do Code related  to SP 
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.State)
                 .NotEmpty().WithMessage(Resources.ErrorMessages.InputPolicyHeaderStateRequired)
                 .Must((modelObject, state) => CheckForStateValue(modelObject))
                 .WithMessage(Resources.ErrorMessages.InputPolicyHeaderStateInvalid);

            //this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.NameInsured)
            //    .MaximumLength(250)
            //    .Matches(@"^[a-zA-Z]*$").WithMessage(Resources.ErrorMessages.InputPolicyHeaderFirstNameAlphabetOnly);

            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass)
                .NotEmpty().WithMessage(Resources.ErrorMessages.InputPolicyHeaderPrimaryClassRequired)
                .Matches(@"^[a-zA-Z]*$").WithMessage(Resources.ErrorMessages.InputPolicyHeaderPrimaryClassAlphabetOnly);

            //this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.SecondaryClass)
            //    .NotEmpty().WithMessage(Resources.ErrorMessages.InputPolicyHeaderSecondaryClassRequired);

            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate)
                .NotEmpty().WithMessage(Resources.ErrorMessages.InputPolicyHeaderPolicyEffectiveDateRequired)
                .Must((modelObject, policyEffectiveDate) => CommonFluents.ValidateDate(Convert.ToString(modelObject.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate)))
                .WithMessage(Resources.ErrorMessages.InputPolicyHeaderPolicyEffectiveDateInvalid);

            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate)
                .NotEmpty().WithMessage(Resources.ErrorMessages.InputPolicyHeaderPolicyExpirationDateRequired)
                .Must((modelObject, policyExpirationDate) => CommonFluents.ValidateDate(Convert.ToString(modelObject.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate)))
                .WithMessage(Resources.ErrorMessages.InputPolicyHeaderPolicyExpirationDateInvalid)
                .Must((modelObject, policyExpirationDate) => CheckDates(modelObject))
                .WithMessage(Resources.ErrorMessages.InputPolicyHeaderPolicyExpirationDateShouldBeGreaterThanPolicyEffectiveDate);

            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate)
                .NotEmpty().WithMessage(Resources.ErrorMessages.InputPolicyHeaderTransactionEffectiveDateRequired)
                .Must((modelObject, startDate) => CommonFluents.ValidateDate(Convert.ToString(modelObject.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate)))
                .WithMessage(Resources.ErrorMessages.InputPolicyHeaderTransactionEffectiveDateInvalid)
                .Must((modelObject, policyExpirationDate) => CheckTransactionDates(modelObject))
                .WithMessage(Resources.ErrorMessages.InputPolicyHeaderTransactionDateShouldBeInBetweenEffectiveDateAndExpirationDate);
        }


        /// <summary>
        /// CheckDates
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public bool CheckDates(RaterFacadeModel model)
        {
            if (model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate > model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// CheckForStateValue
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public bool CheckForStateValue(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var propertyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            DataTable dataTable = null;
            bool flag = false;
            dataTable = this.PropertyDataAccess.GetStateList(policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                throw new Exception(" state does not exist.");
            }
            else
            {
                var row = dataTable.AsEnumerable().Where(r => r.Field<string>("StateCode") == model.RaterInputFacadeModel.PolicyHeaderModel.State).ToList();
                if (row.Count > 0)
                {
                    flag = true;
                }
            }
            return flag;
        }

        /// <summary>
        /// CheckTransactionDates
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public bool CheckTransactionDates(RaterFacadeModel model)
        {
            if (model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate <= model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate && model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate <= model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
