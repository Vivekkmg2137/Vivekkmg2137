﻿using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models.ApiModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Validations
{
    public class PropertyNyPostValidation : AbstractValidator<RaterFacadeModel>
    {
        private PropertyDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }
        readonly IConfiguration configuration;

        public PropertyNyPostValidation(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.DataAccess = new PropertyDataAccess(this.configuration,this.Logger);

            #region NY Sheet

            //change 16-07-2020
            this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TotalTIV)
                .NotNull()
                .NotEqual(0)
                .WithMessage(Resources.ErrorMessages.OutputPropertyTotalTIVMissing);


            //When(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor <= 1, () =>
            //{
            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor)
            //   .ScalePrecision(4, 15)
            //    .NotNull().WithMessage(x => string.Format(Resources.ErrorMessages.OutputPropertyProRatafactorValueNotMatched));
            //});


            //decimal calculatedEquipmentBreakdownIRPMFactor = 0, calculatedBuildingBPPPremium = 0, calculatedNY_TotalBuildingPremium = 0,
            //    calculatedEquipmentBreakdownTotalPremium = 0, calculatedEarthquakeCoverag = 0, calculatedWindTotalPremium = 0, calculatedFloodTotalPremium = 0
            //    , calculatedBasePremium = 0, calculatedNonModifiedPremium = 0, calculatedManualPremium = 0, calculatedTierPremium = 0, calculatedIRPMPremium = 0
            //    , calculatedOtherModPremium = 0, calculatedModifiedPremium = 0;
            //calculatedEquipmentBreakdownRate = 0, 
            //calculatedNY_WindAndHailLimit = 0,
            //calculatedWindTotalPremium = 0,
            // calculatedEarthquakeTotalPremium = 0, calculatedNY_EarthquakeRate = 0;

            //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownIRPMFactor)
            //  .Must((modelObject, equipmentBreakdownIRPMFactor) => IsEquipmentBreakdownIRPMFactorValid(modelObject, out calculatedEquipmentBreakdownIRPMFactor))
            // .WithMessage(x => string.Format("Value of EquipmentBreakdownIRPMFactor should be equal to be {0} !", calculatedEquipmentBreakdownIRPMFactor));

            //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TotalTIV)
            //   .Must((modelObject, totalTIV) => IsTotalTIVValid(modelObject, out calculatedTotalTIV))
            //   .WithMessage(x => string.Format("Value of TotalTIV should be equal to {0} ", calculatedTotalTIV));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium)
            //      .Must((modelObject, buildingBPPPremium) => IsBuildingBPPPremiumValid(modelObject, out calculatedBuildingBPPPremium))
            //      .WithMessage(x => string.Format("Value of BuildingBPPPremium should be equal to {0} ", calculatedBuildingBPPPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium)
            //    .Must((modelObject, nY_TotalBuildingPremium) => IsNY_TotalBuildingPremiumValid(modelObject, out calculatedNY_TotalBuildingPremium))
            //    .WithMessage(x => string.Format("Value of NY_TotalBuildingPremium should be equal to {0} ", calculatedNY_TotalBuildingPremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium)
            //    .Must((modelObject, windTotalPremium) => IsWindTotalPremiumValid(modelObject, out calculatedWindTotalPremium))
            //    .WithMessage(x => string.Format("Value of WindTotalPremium should be equal to {0} ", calculatedWindTotalPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium)
            //    .Must((modelObject, earthquakeTotalPremium) => IsEarthquakeTotalPremiumValid(modelObject, out calculatedEarthquakeCoverag))
            //    .WithMessage(x => string.Format("Value of EarthquakeTotalPremium should be equal to {0} ", calculatedEarthquakeCoverag));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium)
            //    .Must((modelObject, floodTotalPremium) => IsFloodTotalPremiumValid(modelObject, out calculatedFloodTotalPremium))
            //    .WithMessage(x => string.Format("Value of FloodTotalPremium should be equal to {0} ", calculatedFloodTotalPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BasePremium)
            //   .Must((modelObject, basePremium) => IsBasePremiumValid(modelObject, out calculatedBasePremium))
            //   .WithMessage(x => string.Format("Value of BasePremium should be equal to {0} ", calculatedBasePremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium)
            //    .Must((modelObject, nonModifiedPremium) => IsNonModifiedPremiumValid(modelObject, out calculatedNonModifiedPremium))
            //    .WithMessage(x => string.Format("Value of NonModifiedPremium should be equal to {0} ", calculatedNonModifiedPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium)
            //    .Must((modelObject, manualPremium) => CheckManualPremiumWithLOBMinimumPremium(modelObject, out calculatedManualPremium))
            //    .WithMessage(x => string.Format("Value of ManualPremium should be equal to {0} ", calculatedManualPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium)
            //   .Must((modelObject, tierPremium) => CheckTierPremiumWithLOBMinimumPremium(modelObject, out calculatedTierPremium))
            //   .WithMessage(x => string.Format("Value of TierPremium should be equal to {0} ", calculatedTierPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium)
            //   .Must((modelObject, iRPMPremium) => CheckIRPMPremiumWithLOBMinimumPremium(modelObject, out calculatedIRPMPremium))
            //   .WithMessage(x => string.Format("Value of IRPMPremium should be equal to {0} ", calculatedIRPMPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium)
            //  .Must((modelObject, otherModPremium) => CheckOtherModPremiumWithLOBMinimumPremium(modelObject, out calculatedOtherModPremium))
            //  .WithMessage(x => string.Format("Value of OtherModPremium should be equal to {0} ", calculatedOtherModPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium)
            //.Must((modelObject, modifiedPremium) => CheckModifiedPremiumWithLOBMinimumPremium(modelObject, out calculatedModifiedPremium))
            //.WithMessage(x => string.Format("Value of ModifiedPremium should be equal to {0} ", calculatedModifiedPremium));

            //    string messageForPrimaryClassDepedant = string.Empty;
            //    this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass)
            //.Must((modelObject, primaryClass) => CheckPrimaryClassDepedantPremimums(modelObject, out messageForPrimaryClassDepedant))
            //.WithMessage(x => string.Format("{0} ", messageForPrimaryClassDepedant));


            #endregion
        }

        #region NY Sheet
        /// <summary>
        /// Check is equipmentBreakdownIRPMFactor Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="EquipmentBreakdownIRPMFactor">decimal</param>
        /// <returns>bool Value</returns>
        public bool IsEquipmentBreakdownIRPMFactorValid(RaterFacadeModel model, out decimal equipmentBreakdownIRPMFactor)
        {
            equipmentBreakdownIRPMFactor = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM / 100;
            if (equipmentBreakdownIRPMFactor == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownIRPMFactor)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        ///// <summary>
        ///// Check TotalTIV is Valid
        ///// </summary>
        ///// <param name="model">RaterFacadeModel</param>
        ///// <param name="totalTIV">decimal</param>
        ///// <returns>bool Value</returns>
        //public bool IsTotalTIVValid(RaterFacadeModel model, out decimal totalTIV)
        //{
        //    totalTIV = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV + model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV;
        //    if (totalTIV == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TotalTIV)
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

        /// <summary>
        /// Check BuildingBPPPremium is Valid
        ///  Step 13 (Step 11/100) * Step 12 * Step 1 * Step 2 * Step 3 * Step 4 * Step 5     
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="buildingBPPPremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool IsBuildingBPPPremiumValid(RaterFacadeModel model, out decimal buildingBPPPremium)
        {
            // buildingBPPPremium
            buildingBPPPremium = Math.Round((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TotalTIV / 100)
                                                                    * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkBaseRate
                                                                    * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkCauseofLossFactor
                                                                    * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.CoinsuranceFactor
                                                                    * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ValuationFactor
                                                                    * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.AOPDeductibleFactor
                                                                    * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkInflationGuardFactor, MidpointRounding.AwayFromZero);

            if (buildingBPPPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Check NY_TotalBuildingPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="nY_TotalBuildingPremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool IsNY_TotalBuildingPremiumValid(RaterFacadeModel model, out decimal nY_TotalBuildingPremium)
        {
            nY_TotalBuildingPremium = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium;

            if (nY_TotalBuildingPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Check equipmentBreakdownTotalPremium is valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="equipmentBreakdownTotalPremium">decimal</param>
        /// <returns>bool Value</returns>


        //public bool IsReferredEquipmentBreakdownCoverageFalseValid(RaterFacadeModel model, out decimal equipmentBreakdownRate)
        //{

        //    equipmentBreakdownRate = 0;
        //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
        //    {
        //        model.OutputModel.Property.EquipmentBreakdownRate = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownTotalPremium
        //                                                              * 100)
        //                                                              / model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownLimit, 3,MidpointRounding.AwayFromZero);

        //        if (model.OutputModel.Property.EquipmentBreakdownRate == equipmentBreakdownRate)
        //        {

        //            return true;
        //        }
        //        else
        //        {
        //            return false;
        //        }

        //    }
        //    else
        //    {
        //        return true;
        //    }
        //}

        //public bool IsWindstormAndHailCoverageRelatedValuesValid(RaterFacadeModel model, out decimal nY_WindAndHailLimit, out decimal windTotalPremium, out decimal nY_WindAndHailRate)
        //{
        //    nY_WindAndHailLimit = 0;
        //    windTotalPremium = 0;
        //    nY_WindAndHailRate = 0;
        //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true)
        //    {
        //        if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindTotalPremium == 0)
        //        {
        //            // Step 17 - Wind & Hail Premium Calculations
        //            nY_WindAndHailLimit = model.OutputModel.Property.TotalTIV;

        //            if (nY_WindAndHailLimit == model.OutputModel.Property.PropertyStateSpecificInputModel.NewYorkWindAndHailLimit)
        //            {
        //                // Step 17.1 NY_WindAndHailLimit
        //                // Step 17.2 NY_WindAndHailRate : Input field
        //                // (Step 17.1 / 100) *Step 17.2
        //                windTotalPremium = Math.Round((model.OutputModel.Property.TotalTIV
        //                                                                    / 100)
        //                                                                    * model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkWindAndHailRate,MidpointRounding.AwayFromZero);
        //                if (model.OutputModel.Property.WindTotalPremium == windTotalPremium)
        //                {
        //                    return true;
        //                }
        //                else
        //                {
        //                    return false;
        //                }

        //            }
        //            else
        //            {
        //                return false;
        //            }
        //        }
        //        else
        //        {
        //            // Step 18.1 WindTotalPremium : Input field
        //            // Step 18.2 NY_WindAndHailLimit
        //            nY_WindAndHailLimit = model.OutputModel.Property.TotalTIV;

        //            if (nY_WindAndHailLimit == model.OutputModel.Property.PropertyStateSpecificInputModel.NewYorkWindAndHailLimit)
        //            {
        //                // Step 18.3 (Step 18.1 * 100)/Step 18.2
        //                nY_WindAndHailRate = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindTotalPremium
        //                                                               * 100)
        //                                                               / model.OutputModel.Property.TotalTIV,
        //                                                               3,MidpointRounding.AwayFromZero);
        //                if (nY_WindAndHailRate == model.OutputModel.Property.PropertyStateSpecificInputModel.NewYorkWindAndHailRate)
        //                {
        //                    return true;
        //                }
        //                else
        //                {
        //                    return false;
        //                }
        //            }
        //            else
        //            {
        //                return false;
        //            }
        //        }
        //    }
        //    else
        //    {
        //        return true;
        //    }
        //}

        /// <summary>
        /// Check earthquakeTotalPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="earthquakeTotalPremium">decimal</param>
        /// <param name="nY_EarthquakeRate">decimal</param>
        /// <returns>bool Value</returns>
        public bool IsEarthquakeCoverageValuesValid(RaterFacadeModel model, out decimal earthquakeTotalPremium, out decimal nY_EarthquakeRate)
        {
            earthquakeTotalPremium = 0;
            nY_EarthquakeRate = 0;
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == true)
            {
                //When Premium is manually entered, do not execute this step
                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium == 0)
                {
                    // Step 19 - Earthquake Premium calculations
                    // Step 19.1 Input field   NY_EarthquakeLimit
                    // Step 19.2 Input field   NY_EarthquakeRate
                    // Step 19.3 (Step 19.1/100) * Step 19.2
                    earthquakeTotalPremium = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkEarthquakeLimit
                                                                                 / 100)
                                                                                 * model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkEarthquakeRate, MidpointRounding.AwayFromZero);
                    if (earthquakeTotalPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    // Step 20 - Earthquake Coverage Rate Calculation
                    // Step 20.1 Input field    model.EarthquakeTotalPremium
                    // Step 20.2 Input field    model.NY_EarthquakeLimit
                    // Step 20.3 (Step 20.1 * 100)/Step 20.2) 
                    nY_EarthquakeRate = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium
                                                                              * 100)
                                                                              / model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkEarthquakeLimit,
                                                                              3, MidpointRounding.AwayFromZero);
                    if (nY_EarthquakeRate == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.NewYorkEarthquakeRate)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            else
            {
                return true;
            }


        }

       

        /// <summary>
        /// Check windTotalPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="windTotalPremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool IsWindTotalPremiumValid(RaterFacadeModel model, out decimal windTotalPremium)
        {
            windTotalPremium = 0;
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium == 0)
            {
                windTotalPremium = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputWindTotalPremium;
                if (windTotalPremium == model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputWindTotalPremium)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Check earthquakeTotalPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="earthquakeTotalPremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool IsEarthquakeTotalPremiumValid(RaterFacadeModel model, out decimal earthquakeTotalPremium)
        {
            earthquakeTotalPremium = 0;
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium == 0)
            {
                earthquakeTotalPremium = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium;
                if (earthquakeTotalPremium == model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Check floodCoverage is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="floodCoverage">decimal</param>
        /// <returns>bool Value</returns>
        public bool IsFloodTotalPremiumValid(RaterFacadeModel model, out decimal floodCoverage)
        {
            floodCoverage = 0;
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium == 0)
            {
                floodCoverage = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputFloodTotalPremium;
                if (floodCoverage == model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputFloodTotalPremium)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Check basePremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="basePremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool IsBasePremiumValid(RaterFacadeModel model, out decimal basePremium)
        {
            basePremium = (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium
                                                              + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium
                                                              + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium
                                                              + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium
                                                              + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium)
                                                              * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor;
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BasePremium == basePremium)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Check nonModifiedPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="nonModifiedPremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool IsNonModifiedPremiumValid(RaterFacadeModel model, out decimal nonModifiedPremium)
        {

            nonModifiedPremium = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OptionalCoverageTotalPremium * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor;

            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium == nonModifiedPremium)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        /// <summary>
        /// Check ManualPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="manualPremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool CheckManualPremiumWithLOBMinimumPremium(RaterFacadeModel model, out decimal manualPremium)
        {

            manualPremium = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium;
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
            {
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium == manualPremium)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }
        /// <summary>
        /// Check TierPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="tierPremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool CheckTierPremiumWithLOBMinimumPremium(RaterFacadeModel model, out decimal tierPremium)
        {

            tierPremium = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium;
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
            {
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium == tierPremium)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Check IRPMPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="iRPMPremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool CheckIRPMPremiumWithLOBMinimumPremium(RaterFacadeModel model, out decimal iRPMPremium)
        {
            iRPMPremium = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium;
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
            {
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium == iRPMPremium)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Check OtherModPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="otherModPremium">decimal</param>
        /// <returns>bool Value</returns>
        public bool CheckOtherModPremiumWithLOBMinimumPremium(RaterFacadeModel model, out decimal otherModPremium)
        {
            otherModPremium = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium;
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
            {
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium == otherModPremium)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Check ModifiedPremium is Valid
        /// </summary>
        /// <param name="model">RaterFacadeModel</param>
        /// <param name="modifiedPremium">decimal</param>
        /// <returns>bool Value</returns>

        public bool CheckModifiedPremiumWithLOBMinimumPremium(RaterFacadeModel model, out decimal modifiedPremium)
        {
            modifiedPremium = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium;
            if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
            {
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium == modifiedPremium)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        public bool CheckPrimaryClassDepedantPremimums(RaterFacadeModel model, out string messageTosend)
        {
            messageTosend = string.Empty;
            StringBuilder messageString = new StringBuilder();
            bool statusFlag = true;
            if (model.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() == "SC" && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel != null)
            {
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.GlassDisplayORTrophyCasesPremium != 0)
                {
                    messageString.Append("GlassDisplayORTrophyCasesPremium should be zero! ");
                    statusFlag = false;
                }
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerPremium != 0)
                {
                    messageString.Append("PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerPremium should be zero! ");
                    statusFlag = false;
                }
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.PersonalEffectsAndPropertyOfOthersAnyOneOccurrencePremium != 0)
                {
                    messageString.Append("PersonalEffectsAndPropertyOfOthersAnyOneOccurrencePremium should be zero! ");
                    statusFlag = false;
                }
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.ValuablePapersPremium != 0)
                {
                    messageString.Append("ValuablePapersPremium should be zero! ");
                    statusFlag = false;
                }
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.MusicalInstrumentsAndBandUniformsPremium != 0)
                {
                    messageString.Append("MusicalInstrumentsAndBandUniformsPremium should be zero! ");
                    statusFlag = false;
                }
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerPremium != 0)
                {
                    messageString.Append("PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerPremium should be zero! ");
                    statusFlag = false;
                }
                if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PropertyStateSpecificOutputModel.PropertyNewYork360OutputModel.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrencePremium != 0)
                {
                    messageString.Append("PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrencePremium should be zero! ");
                    statusFlag = false;
                }
            }
            messageTosend = Convert.ToString(messageString);
            return statusFlag;

        }



        #endregion

    }
}
