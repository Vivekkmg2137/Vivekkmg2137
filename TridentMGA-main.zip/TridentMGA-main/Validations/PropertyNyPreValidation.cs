﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using DataAccess;
using FluentValidation;
using Logging;
using Microsoft.Extensions.Configuration;
using Models;
using Models.ApiModels;


namespace Validations
{
    public class PropertyNyPreValidation : AbstractValidator<RaterFacadeModel>
    {
        private PropertyDataAccess propertyDataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }
        readonly IConfiguration configuration;

        public PropertyNyPreValidation(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.configuration = configuration;
            this.propertyDataAccess = new PropertyDataAccess(this.configuration, this.Logger);

            #region Model Validation & Policy header

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                .Must((modelObject, selectedLineOfBusiness) =>
                IsModelValid(modelObject))
                .WithMessage(Resources.ErrorMessages.InputJSONNotValidForLOBs);
            
            this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor)
                .Must((modelObject, policyExpirationDate) =>
                IsProRatafactorWithDatesValid(modelObject))
                .WithMessage(Resources.ErrorMessages.InputPolicyHeaderPolicyDateInvalidForProRatafactor);

            #endregion

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ScheduleRatingInputModels)
                .NotNull()
                .WithMessage(Resources.ErrorMessages.InputPropertyNY_ScheduleRatingInputModelsMissing);

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ScheduleRatingInputModels != null, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ScheduleRatingInputModels.buildingScheduleInputModels)
                    .NotNull()
                    .WithMessage(Resources.ErrorMessages.InputPropertyNY_buildingScheduleInputModelsMissing);
            });

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkCauseofLoss)
                .NotEmpty()
                .WithMessage(Resources.ErrorMessages.InputPropertyNY_CauseofLossMissing);

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Coinsurance)
                .NotEmpty()
                .WithMessage(Resources.ErrorMessages.InputPropertyCoinsuranceMissing);

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Valuation)
                .NotEmpty()
                .WithMessage(Resources.ErrorMessages.InputPropertyValuationMissing);

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible)
                .ScalePrecision(4, 15)
                .NotNull()
                .WithMessage(Resources.ErrorMessages.InputPropertyAOPDeductibleMissing);

            //change 16-07-2020
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Blanket)
                .NotEmpty()
                .WithMessage(Resources.ErrorMessages.InputPropertyBlanketMissing);

            string equipmentBreakdownIRPMErrorMessage = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM)
                .ScalePrecision(4, 15)
                .Must((modelObject, equipmentBreakdownIRPM) =>
                CheckRangeForValue(Math.Round((modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM / 100), 2), "IRPM Factor", modelObject, out equipmentBreakdownIRPMErrorMessage))
                .WithMessage(Resources.ErrorMessages.InputPropertyEquipmentBreakdownIRPMNotInRange);

            //change 16-07-2020
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM)
                .ScalePrecision(4, 15)
                .NotEqual(0)
                .WithMessage(Resources.ErrorMessages.InputPropertyEquipmentBreakdownIRPMNotInRange);

            string otherModFactorErrorMessage = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OtherModFactor)
                .ScalePrecision(4, 15)
                .Must((modelObject, otherModFactor) =>
                CheckRangeForValue(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OtherModFactor, "Other Mod", modelObject, out otherModFactorErrorMessage))
                .WithMessage(Resources.ErrorMessages.InputPropertyOtherModFactorNotInRange);

            //change 16-07-2020
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OtherModFactor).ScalePrecision(4, 15)
                .NotEqual(0)
                .WithMessage(Resources.ErrorMessages.InputPropertyOtherModFactorNotInRange);

            //change 16-07-2020
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodDeductible)
                    .NotNull()
                    .WithMessage(Resources.ErrorMessages.InputPropertyFloodDeductibleMissing)
                    .NotEqual(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyFloodDeductibleMissing);
            });

            //change 16-07-2020
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeDeductible)
                    .NotNull()
                    .WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeDeductibleMissing).NotEqual(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeDeductibleMissing);
            });

            //change 16/07/2021
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == false, () =>
              {
                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownRate)
                      .ScalePrecision(4, 15)
                      .NotEqual(0)
                      .WithMessage(Resources.ErrorMessages.InputPropertyEquipmentBreakdownRateMissing);
              });

            //Calculate Equipment Breakdown premium for NY.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InputEquipmentBreakdownTotalPremium)
                    .ScalePrecision(4, 15)
                    .GreaterThan(0)
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyEquipmentBreakdownTotalPremiumMissing);

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkEquipmentBreakdownLimit)
                    .ScalePrecision(4, 15)
                    .GreaterThan(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyNY_EquipmentBreakdownLimitMissing);
            });

            //Calculate WindFloodEarthquakePremium for NY.
            //Windstorm and Hail Coverage Calculation
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage
            && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputWindTotalPremium == 0, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkWindAndHailRate)
                    .ScalePrecision(4, 15)
                    .GreaterThan(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyNY_WindAndHailRateMissing);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage
           && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputWindTotalPremium != 0, () =>
           {
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputWindTotalPremium)
                    .ScalePrecision(4, 15)
                    .GreaterThan(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyWindTotalPremiumMissing);
           });

            //Earthquake Coverage Calculations
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage
            && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium == 0, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkEarthquakeLimit)
                    .ScalePrecision(4, 15)
                    .GreaterThan(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyNY_EarthquakeLimitMissing);

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkEarthquakeRate)
                    .ScalePrecision(4, 15)
                    .GreaterThan(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyNY_EarthquakeRateMissing);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage
           && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium != 0, () =>
           {
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputEarthquakeTotalPremium)
                   .ScalePrecision(4, 15)
                   .GreaterThan(0)
                   .WithMessage(Resources.ErrorMessages.InputPropertyNY_InputEarthquakeTotalPremium);

               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkEarthquakeLimit)
                   .ScalePrecision(4, 15)
                   .GreaterThan(0)
                   .WithMessage(Resources.ErrorMessages.InputPropertyNY_EarthquakeLimitMissing);
           });


            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage
            && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputFloodTotalPremium == 0, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkFloodLimit)
                    .ScalePrecision(4, 15)
                    .GreaterThan(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyNY_FloodLimitMissing);

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkFloodRate)
                    .ScalePrecision(4, 15)
                    .GreaterThan(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyNY_FloodRateMissing);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage
           && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputFloodTotalPremium != 0, () =>
           {
               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkInputFloodTotalPremium)
                    .ScalePrecision(4, 15)
                    .GreaterThan(0)
                    .WithMessage(Resources.ErrorMessages.InputPropertyNY_InputFloodTotalPremiumMissing);

               this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.NewYorkFloodLimit)
                   .ScalePrecision(4, 15)
                   .GreaterThan(0)
                   .WithMessage(Resources.ErrorMessages.InputPropertyNY_FloodLimitMissing);
           });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel != null
            && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel != null, () =>
            {

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.IsMoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceCoverageSelected, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                        .Must((modelObject, propertyOptionalCoverages) =>
                        CheckForOptionalCoverageMoneySecuritiesStamps(modelObject))
                        .WithMessage(Resources.ErrorMessages.InputPropertyMoneySecuritiesStampsTemporaryMissing);
                });

                String errorMessageInputPropertyMoneySecuritiesStampsTemporaryMissing = Resources.ErrorMessages.InputPropertyMoneySecuritiesStampsTemporaryMissing;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                    .Must((modelObject, propertyOptionalCoverages) =>
                    CheckForOptionalCoverageFlatCharge(modelObject, ref errorMessageInputPropertyMoneySecuritiesStampsTemporaryMissing))
                    .WithMessage(errorMessageInputPropertyMoneySecuritiesStampsTemporaryMissing);

                String errorMessageInputPropertyOtherCoverageLimitMissing = Resources.ErrorMessages.InputPropertyOtherCoverageLimitMissing;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                    .Must((modelObject, propertyOptionalCoverages) =>
                    CheckForOptionalCoverageOtherForLimit(modelObject, "PER 1000 OF LIMIT", ref errorMessageInputPropertyOtherCoverageLimitMissing))
                    .WithMessage(errorMessageInputPropertyOtherCoverageLimitMissing);

                String errorMessageInputPropertyOtherCoverageRateMissing = Resources.ErrorMessages.InputPropertyOtherCoverageRateMissing;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                    .Must((modelObject, propertyOptionalCoverages) =>
                    CheckForOptionalCoverageOtherForRate(modelObject, "PER 1000 OF LIMIT", ref errorMessageInputPropertyOtherCoverageRateMissing))
                    .WithMessage(errorMessageInputPropertyOtherCoverageRateMissing);

                String errorMessageInputPropertyOtherCoverageLimitMissing2 = Resources.ErrorMessages.InputPropertyOtherCoverageLimitMissing;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                    .Must((modelObject, propertyOptionalCoverages) => CheckForOptionalCoverageOtherForLimit(modelObject, "PER 100 OF LIMIT", ref errorMessageInputPropertyOtherCoverageLimitMissing2))
                    .WithMessage(errorMessageInputPropertyOtherCoverageLimitMissing2);

                String errorMessageInputPropertyOtherCoverageRateMissing2 = Resources.ErrorMessages.InputPropertyOtherCoverageRateMissing;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                    .Must((modelObject, propertyOptionalCoverages) =>
                    CheckForOptionalCoverageOtherForRate(modelObject, "PER 100 OF LIMIT", ref errorMessageInputPropertyOtherCoverageRateMissing2))
                    .WithMessage(errorMessageInputPropertyOtherCoverageRateMissing2);
            });
            //360 from here
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel != null, () =>
            {
                //Accounts Receivable
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.AccountsReceivableRecordsRevisedLimit)
                    .Must((modelObject, accountsReceivableRecordsRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsAccountsReceivableRecordsCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.AccountsReceivableRecordsRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelAccountsReceivableRecordsRevisedLimitMissing);

                //Building Ordinance or Law - Demolition Cost Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.BuildingOrdinanceORLawDemolitionCostRevisedLimit)
                    .Must((modelObject, buildingOrdinanceORLawDemolitionCostRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsBuildingOrdinanceORLawDemolitionCostCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.BuildingOrdinanceORLawDemolitionCostRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelBuildingOrdinanceORLawDemolitionCostRevisedLimitMissing);


                //Building Ordinance or Law - Increased Cost of Construction Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.BuildingOrdinanceORLawIncreasedCostOfContructionRevisedLimit)
                    .Must((modelObject, buildingOrdinanceORLawIncreasedCostOfContructionRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsBuildingOrdinanceORLawIncreasedCostOfContructionCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.BuildingOrdinanceORLawIncreasedCostOfContructionRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelBuildingOrdinanceORLawIncreasedCostOfContructionRevisedLimitMissing);

                //Changes in Temperature or Humidity Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ChangesInTemperatureORHumidityRevisedLimit)
                .Must((modelObject, changesInTemperatureORHumidityRevisedLimit) =>
                CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsChangesInTemperatureORHumidityCoverageSelected,
                modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ChangesInTemperatureORHumidityRevisedLimit))
                .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelChangesInTemperatureORHumidityRevisedLimitMissing);

                //Commandeered Property Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.CommandeeredPropertyRevisedLimit)
                    .Must((modelObject, commandeeredPropertyRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsCommandeeredPropertyCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.CommandeeredPropertyRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelCommandeeredPropertyRevisedLimitMissing);

                //Communication Equipment Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.CommunicationEquipmentRevisedLimit)
                    .Must((modelObject, communicationEquipmentRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsCommunicationEquipmentCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.CommunicationEquipmentRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelCommunicationEquipmentRevisedLimitMissing);

                //Computer Equipment Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ComputerEquipmentRevisedLimit)
                    .Must((modelObject, computerEquipmentRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsComputerEquipmentCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ComputerEquipmentRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelComputerEquipmentRevisedLimitMissing);

                //Detached Signs Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.DetachedSignsRevisedLimit)
                    .Must((modelObject, detachedSignsRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsDetachedSignsCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.DetachedSignsRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelDetachedSignsRevisedLimitMissing);


                //Electrical Damage Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ElectricalDamageRevisedLimit)
                    .Must((modelObject, electricalDamageRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsElectricalDamageCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ElectricalDamageRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelElectricalDamageRevisedLimitMissing);

                When(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass.ToUpper() == "SC", () =>
                {
                    //Extra Expense and Business Income Coverage
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ExtraExpenseAndBusinessIncomeRevisedLimit)
                       .Must((modelObject, extraExpenseAndBusinessIncomeRevisedLimit) =>
                       CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsExtraExpenseAndBusinessIncomeCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ExtraExpenseAndBusinessIncomeRevisedLimit))
                       .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelExtraExpenseAndBusinessIncomeRevisedLimitMissing);
                });

                //Fairs, Exhibitions, Expositions or Trade Shows Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.FairsExhibitionsExpositionsORTradeShowsRevisedLimit)
                    .Must((modelObject, fairsExhibitionsExpositionsORTradeShowsRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsFairsExhibitionsExpositionsORTradeShowsCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.FairsExhibitionsExpositionsORTradeShowsRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelFairsExhibitionsExpositionsORTradeShowsRevisedLimitMissing);

                //Fine Arts Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.FineartsRevisedLimit)
                    .Must((modelObject, fineartsRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsFineartsCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.FineartsRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelFineartsRevisedLimitMissing);

                //Fire Department Service Charge Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.FireDepartmentServiceChargeRevisedLimit)
                    .Must((modelObject, fireDepartmentServiceChargeRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsFireDepartmentServiceChargeCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.FireDepartmentServiceChargeRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelFireDepartmentServiceChargeRevisedLimitMissing);

                //Flagpoles Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.FlagpolesRevisedLimit)
                    .Must((modelObject, flagpolesRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsFlagpolesCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.FlagpolesRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelFlagpolesRevisedLimitMissing);

                // Glass Display or Trophy Cases Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.GlassDisplayORTrophyCasesRevisedLimit)
                    .Must((modelObject, glassDisplayORTrophyCasesRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsGlassDisplayORTrophyCasesCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.GlassDisplayORTrophyCasesRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelGlassDisplayORTrophyCasesRevisedLimitMissing);

                // Grounds, Maintenance Equipment Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.GroundsMaintenanceEquipmentRevisedLimit)
                    .Must((modelObject, groundsMaintenanceEquipmentRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsGroundsMaintenanceEquipmentCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.GroundsMaintenanceEquipmentRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelGroundsMaintenanceEquipmentRevisedLimitMissing);

                // Lock Replacement Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.LockReplacementRevisedLimit)
                    .Must((modelObject, lockReplacementRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsLockReplacementCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.LockReplacementRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelLockReplacementRevisedLimitMissing);

                // Money, Securities and Stamps - Inside Premise Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.MoneySecuritiesAndStampsInsidePremiseRevisedLimit)
                    .Must((modelObject, moneySecuritiesAndStampsInsidePremiseRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsMoneySecuritiesAndStampsInsidePremiseCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.MoneySecuritiesAndStampsInsidePremiseRevisedLimit)).WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelMoneySecuritiesAndStampsInsidePremiseRevisedLimitMissing);

                //Money, Securities and Stamps - Outside Premise Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.MoneySecuritiesAndStampsOutsidePremiseRevisedLimit)
                    .Must((modelObject, moneySecuritiesAndStampsOutsidePremiseRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsMoneySecuritiesAndStampsOutsidePremiseCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.MoneySecuritiesAndStampsOutsidePremiseRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelMoneySecuritiesAndStampsOutsidePremiseRevisedLimitMissing);

                //Newly Acquired or Constructed Property - Building Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.NewlyAcquiredORConstructedPropertyBuildingRevisedLimit)
               .Must((modelObject, newlyAcquiredORConstructedPropertyBuildingRevisedLimit) =>
               CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsNewlyAcquiredORConstructedPropertyBuildingCoverageSelected,
               modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.NewlyAcquiredORConstructedPropertyBuildingRevisedLimit))
               .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelNewlyAcquiredORConstructedPropertyBuildingRevisedLimitMissing);

                //Newly Acquired or Constructed Property - Personal Property Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.NewlyAcquiredORConstructedPropertyPersonalPropertyRevisedLimit)
                    .Must((modelObject, newlyAcquiredORConstructedPropertyPersonalPropertyRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsNewlyAcquiredORConstructedPropertyPersonalPropertyCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.NewlyAcquiredORConstructedPropertyPersonalPropertyRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelNewlyAcquiredORConstructedPropertyPersonalPropertyRevisedLimitMissing);

                //Off Premises Utility Failure Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.OffPremisesUtilityFailureRevisedLimit)
                    .Must((modelObject, offPremisesUtilityFailureRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsOffPremisesUtilityFailureCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.OffPremisesUtilityFailureRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelOffPremisesUtilityFailureRevisedLimitMissing);

                //Outdoor Property - Any one tree, shrub or plant Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.OutdoorPropertyAnyOneTreeShrubORplantRevisedLimit)
                    .Must((modelObject, outdoorPropertyAnyOneTreeShrubORplantRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsOutdoorPropertyAnyOneTreeShrubORplantCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.OutdoorPropertyAnyOneTreeShrubORplantRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelOutdoorPropertyAnyOneTreeShrubORplantRevisedLimitMissing);

                //Outdoor Property - Total limit Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.OutdoorPropertyTotalLimitRevisedLimit)
                    .Must((modelObject, outdoorPropertyTotalLimitRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsOutdoorPropertyTotalLimitCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.OutdoorPropertyTotalLimitRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelOutdoorPropertyTotalLimitRevisedLimitMissing);

                //Personal Effects and Property of Others - Any one employee or volunteer Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRevisedLimit)
                    .Must((modelObject, personalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsPersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelPersonalEffectsAndPropertyOfOthersAnyOneEmployeeORvolunteerRevisedLimitMissing);

                //Personal Effects and Property of Others - Any one occurrence Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRevisedLimit)
                    .Must((modelObject, personalEffectsAndPropertyOfOthersAnyOneOccurrenceRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsPersonalEffectsAndPropertyOfOthersAnyOneOccurrenceCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelPersonalEffectsAndPropertyOfOthersAnyOneOccurrenceRevisedLimitMissing);

                //Pollutant Clean Up and Removal Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PollutantCleanUpAndRemovalRevisedLimit)
                    .Must((modelObject, pollutantCleanUpAndRemovalRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsPollutantCleanUpAndRemovalCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PollutantCleanUpAndRemovalRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelPollutantCleanUpAndRemovalRevisedLimitMissing);

                //Property in Transit Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PropertyInTransitRevisedLimit)
                    .Must((modelObject, propertyInTransitRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsPropertyInTransitCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PropertyInTransitRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelPropertyInTransitRevisedLimitMissing);

                //Property Off-Premises Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PropertyOffPremisesRevisedLimit)
                    .Must((modelObject, propertyOffPremisesRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsPropertyOffPremisesCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PropertyOffPremisesRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelPropertyOffPremisesRevisedLimitMissing);

                //Spoilage Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.SpoilageCoverageRevisedLimit)
                    .Must((modelObject, spoilageCoverageRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsSpoilageCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.SpoilageCoverageRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelSpoilageCoverageRevisedLimitMissing);

                //Valuable Papers and Records Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ValuablePapersAndRecordsRevisedLimit)
                    .Must((modelObject, valuablePapersAndRecordsRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsValuablePapersAndRecordsCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ValuablePapersAndRecordsRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelValuablePapersAndRecordsRevisedLimitMissing);

                //Extra Expense and Tuition & Fees Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ExtraExpenseAndTuitionFeesRevisedLimit)
                    .Must((modelObject, extraExpenseAndTuitionFeesRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsExtraExpenseAndTuitionFeesCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ExtraExpenseAndTuitionFeesRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelExtraExpenseAndTuitionFeesRevisedLimitMissing);

                //Valuable Papers
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ValuablePapersRevisedLimit)
                    .Must((modelObject, valuablePapersRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsValuablePapersCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.ValuablePapersRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelValuablePapersRevisedLimitMissing);

                //Musical Instruments and Band Uniforms Coverage
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.MusicalInstrumentsAndBandUniformsRevisedLimit)
                    .Must((modelObject, musicalInstrumentsAndBandUniformsRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsMusicalInstrumentsAndBandUniformsCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.MusicalInstrumentsAndBandUniformsRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelMusicalInstrumentsAndBandUniformsRevisedLimitMissing);

                //Personal Property of Employees or Volunteers - Any one employee or volunteer
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRevisedLimit)
                    .Must((modelObject, personalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsPersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelPersonalPropertyOfEmployeesORVolunteersAnOneEmployeeORvolunteerRevisedLimitMissing);

                //Personal Property of Employees or Volunteers - Any one occurrence
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRevisedLimit)
                    .Must((modelObject, PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRevisedLimit) =>
                    CheckNY360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.IsPersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceCoverageSelected, modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyStateSpecificInputModel.PropertyNewYork360InputModel.PersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelPersonalPropertyOfEmployeesORVolunteersAnyOneOccurrenceRevisedLimitMissing);
            });
        }

        public bool IsModelValid(RaterFacadeModel model)
        {
            if (model != null && model.RaterInputFacadeModel.LineOfBusiness != null)
            {
                if (model.RaterInputFacadeModel.LineOfBusiness.Property == true && model.RaterInputFacadeModel.LineOfBusinessInputModel.Property == null)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckNY360CoveragePremiumAndLimits(bool premiumType, decimal limitValue)
        {
            if (premiumType && limitValue <= 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool CheckForStateValue(RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var propertyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            DataTable dataTable = null;
            bool flag = false;
            dataTable = this.propertyDataAccess.GetStateList(policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                throw new Exception(" state does not exist.");
            }
            else
            {
                var row = dataTable.AsEnumerable().Where(r => r.Field<string>("StateCode") == model.RaterInputFacadeModel.PolicyHeaderModel.State).ToList();
                if (row.Count > 0)
                {
                    flag = true;
                }
            }
            return flag;
        }

        public bool CheckDates(RaterFacadeModel model)
        {
            if (model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate > model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsProRatafactorWithDatesValid(RaterFacadeModel model)
        {
            bool returnFlag = false;
            if ((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).TotalDays != 0)
            {
                decimal proRatafactor = Math.Round(Convert.ToDecimal((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate).TotalDays / (model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).TotalDays), 2, MidpointRounding.AwayFromZero);
                if (proRatafactor <= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return returnFlag;
            }
        }


        public bool CheckRangeForValue(decimal valueTocheck, string factorType, RaterFacadeModel model, out string message)
        {
            message = string.Empty;
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var propertyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            DataTable dataTable = null;
            bool flag = false;

            dataTable = this.propertyDataAccess.GetMinMaxValueForFactor(policyHeaderModel.State, policyHeaderModel.PrimaryClass, propertyInputModel.LineOfBusiness, factorType, policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                message = factorType + " range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = factorType + " Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = factorType + " Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }

            return flag;
        }

        //TODO
        public bool CheckForOptionalCoverageMoneySecuritiesStamps(RaterFacadeModel model)
        {
            bool valueToReturn = true;
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel != null)
            {
                if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.MoneySecuritiesStampsTemporaryIncreasedLimitofInsuranceCoverage.ToUpper() == "Money, Securities, Stamps - Temporary Increased Limit of Insurance"
                    && model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.MoneySecuritiesStampsTemporaryIncreasedLimitofInsurancePremium == 0)
                {
                    valueToReturn = false;
                }

            }
            return valueToReturn;
        }

        public bool CheckForOptionalCoverageFlatCharge(RaterFacadeModel model, ref String errorMessages)
        {
            bool valueToReturn = true;
            int index = 1;
            //String stringIndex = string.Empty;
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel != null)
            {
                foreach (var optionalCoverage in model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                {
                    if (optionalCoverage.RatingBasis.ToUpper() == "FLAT CHARGE" && optionalCoverage.Premium == 0)
                    {
                        valueToReturn = false;
                        //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                    }
                    index++;
                }
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;

            return valueToReturn;
        }

        public bool CheckForOptionalCoverageOtherForLimit(RaterFacadeModel model, string checkLimit, ref String errorMessages)
        {
            bool valueToReturn = true;
            int index = 1;
            //String stringIndex = string.Empty;
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel != null)
            {
                foreach (var optionalCoverage in model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                {
                    if (optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER" && optionalCoverage.RatingBasis.ToUpper() == checkLimit && optionalCoverage.Limit == 0)
                    {
                        valueToReturn = false;
                        //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                    }
                    index++;
                }
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return valueToReturn;
        }

        public bool CheckForOptionalCoverageOtherForRate(RaterFacadeModel model, string checkLimit, ref String errorMessages)
        {
            bool valueToReturn = true;
            int index = 1;
            //String stringIndex = string.Empty;
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel != null)
            {
                foreach (var optionalCoverage in model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                {
                    if (optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER" && optionalCoverage.RatingBasis.ToUpper() == checkLimit && optionalCoverage.Rate == 0)
                    {
                        valueToReturn = false;
                        //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                    }
                    index++;
                }
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return valueToReturn;

        }

    }
}
