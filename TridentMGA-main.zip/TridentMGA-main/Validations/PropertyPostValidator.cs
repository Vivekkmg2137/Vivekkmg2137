﻿// <copyright file="ProviderViewModelValidator.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Validations
{
    using System;
    using System.Collections.Generic;
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Models;
    using Models.ApiModels.LineOfBusiness.Property.Output;
    using Models.ApiModels;
    using Microsoft.Extensions.Configuration;
    using System.Data;
    using System.Linq;

    public class PropertyPostValidator : AbstractValidator<RaterFacadeModel>
    {
        private PropertyDataAccess DataAccess { get; set; }
        protected ILoggingManager Logger { get; private set; }
        readonly IConfiguration configuration;

        public PropertyPostValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.Logger = logger;
            this.DataAccess = new PropertyDataAccess(this.configuration, this.Logger);
            this.configuration = configuration;



            this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TotalTIV).ScalePrecision(4, 15)
               .Must((modelObject, buildingDefPoints) =>
               CheckTotalTIV(modelObject)).WithMessage(Resources.ErrorMessages.OutputPropertyTotalTIVMissing);

            //AL, CO, DE, IL, IN, MA, MI, MN, NC, SC, TX, UT, VT, WY 
            string[] stateCheck1 = new string[14] { "AL", "CO", "DE", "IL", "IN", "MA", "MI", "MN", "NC", "SC", "TX", "UT", "VT", "WY" };
            // CT, GA, KS, ME, MS, MO, NH, OH, PA  
            string[] stateCheck2 = new string[9] { "CT", "GA", "KS", "ME", "MS", "MO", "NH", "OH", "PA" };


            When(reg => stateCheck1.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                //ClimaticalHazardsBuildingPointsSubtotal
                string stringClimaticalHazardsBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ClimaticalHazardsBuildingPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ClimaticalHazardsBuildingPointsSubtotal,
                "Climatical Hazards", "Parent line", null
                , modelObject, out stringClimaticalHazardsBuildingPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringClimaticalHazardsBuildingPointsSubtotal) ?
                stringClimaticalHazardsBuildingPointsSubtotal : Resources.ErrorMessages.OutputPropertyClimaticalHazardsBuildingPointsSubtotalNotInRange);

                //ClimaticalHazardsHurricaneContentPoints
                string stringClimaticalHazardsHurricaneContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ClimaticalHazardsContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ClimaticalHazardsContentPointsSubtotal,
                "Climatical Hazards", "Parent line", null
                , modelObject, out stringClimaticalHazardsHurricaneContentPoints)).
                WithMessage(!string.IsNullOrEmpty(stringClimaticalHazardsHurricaneContentPoints) ?
                stringClimaticalHazardsHurricaneContentPoints : Resources.ErrorMessages.OutputPropertyClimaticalHazardsContentPointsSubtotalNotInRange);


            });

            When(reg => stateCheck2.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {

                //  DisasterExposureBuildingPointsSubtotal
                string stringDisasterExposureBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.DisasterExposureBuildingPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.DisasterExposureBuildingPointsSubtotal,
                "Disaster Exposure", "Parent line", null
                , modelObject, out stringDisasterExposureBuildingPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringDisasterExposureBuildingPointsSubtotal) ?
                stringDisasterExposureBuildingPointsSubtotal : Resources.ErrorMessages.OutputPropertyDisasterExposureBuildingPointsSubtotalNotInRange);

                //ClimaticalHazardsBuildingPointsSubtotal
                string stringClimaticalHazardsBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ClimaticalHazardsBuildingPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ClimaticalHazardsBuildingPointsSubtotal,
                "Climatical Hazards", "Parent line", null
                , modelObject, out stringClimaticalHazardsBuildingPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringClimaticalHazardsBuildingPointsSubtotal) ?
                stringClimaticalHazardsBuildingPointsSubtotal : Resources.ErrorMessages.OutputPropertyClimaticalHazardsBuildingPointsSubtotalNotInRange);


                //SpecialOccupancyBuildingPointsSubtotal
                string stringSpecialOccupancyBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.SpecialOccupancyBuildingPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ClimaticalHazardsBuildingPointsSubtotal,
                "Special Occupancy", "Parent line", null
                , modelObject, out stringSpecialOccupancyBuildingPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringSpecialOccupancyBuildingPointsSubtotal) ?
                stringSpecialOccupancyBuildingPointsSubtotal : Resources.ErrorMessages.OutputPropertySpecialOccupancyBuildingPointsSubtotalNotInRange);


                //PrivateProtectionBuildingPointsSubtotal
                string stringPrivateProtectionBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PrivateProtectionBuildingPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PrivateProtectionBuildingPointsSubtotal,
                "Private Protection", "Parent line", null
                , modelObject, out stringPrivateProtectionBuildingPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringPrivateProtectionBuildingPointsSubtotal) ?
                stringSpecialOccupancyBuildingPointsSubtotal : Resources.ErrorMessages.OutputPropertyPrivateProtectionBuildingPointsSubtotalNotInRange);


                //PublicProtectionBuildingPointsSubtotal
                string stringPublicProtectionBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PublicProtectionBuildingPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PublicProtectionBuildingPointsSubtotal,
                "Public Protection", "Parent line", null
                , modelObject, out stringPublicProtectionBuildingPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringPublicProtectionBuildingPointsSubtotal) ?
                stringPublicProtectionBuildingPointsSubtotal : Resources.ErrorMessages.OutputPropertyPublicProtectionBuildingPointsSubtotalNotInRange);


                //ConstructionBuildingPointsSubtotal
                string stringConstructionBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ConstructionBuildingPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ConstructionBuildingPointsSubtotal,
                "Construction", "Parent line", null
                , modelObject, out stringConstructionBuildingPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringConstructionBuildingPointsSubtotal) ?
                stringConstructionBuildingPointsSubtotal : Resources.ErrorMessages.OutputPropertyConstructionBuildingPointsSubtotalNotInRange);


                //FloodBuildingPointsSubtotal
                string stringFloodBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodBuildingPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodBuildingPointsSubtotal,
                "Flood", "Parent line", null
                , modelObject, out stringFloodBuildingPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringFloodBuildingPointsSubtotal) ?
                stringFloodBuildingPointsSubtotal : Resources.ErrorMessages.OutputPropertyFloodBuildingPointsSubtotalNotInRange);


                //EarthMovementBuildingPointsSubtotal
                string stringEarthMovementBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthMovementBuildingPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthMovementBuildingPointsSubtotal,
                "Earth Movement", "Parent line", null
                , modelObject, out stringEarthMovementBuildingPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringEarthMovementBuildingPointsSubtotal) ?
                stringEarthMovementBuildingPointsSubtotal : Resources.ErrorMessages.OutputPropertystringEarthMovementBuildingPointsSubtotalNotInRange);


                //DisasterExposureContentPointsSubtotal
                string stringDisasterExposureContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.DisasterExposureContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.DisasterExposureContentPointsSubtotal,
                "Disaster Exposure", "Parent line", null
                , modelObject, out stringDisasterExposureContentPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringEarthMovementBuildingPointsSubtotal) ?
                stringDisasterExposureContentPointsSubtotal : Resources.ErrorMessages.OutputPropertyDisasterExposureContentPointsSubtotalNotInRange);


                //ClimaticalHazardsHurricaneContentPoints
                string stringClimaticalHazardsHurricaneContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ClimaticalHazardsContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ClimaticalHazardsContentPointsSubtotal,
                "Climatical Hazards", "Parent line", null
                , modelObject, out stringClimaticalHazardsHurricaneContentPoints)).
                WithMessage(!string.IsNullOrEmpty(stringClimaticalHazardsHurricaneContentPoints) ?
                stringClimaticalHazardsHurricaneContentPoints : Resources.ErrorMessages.OutputPropertyClimaticalHazardsContentPointsSubtotalNotInRange);


                //SpecialOccupancyContentPointsSubtotal
                string stringSpecialOccupancyContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.SpecialOccupancyContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.SpecialOccupancyContentPointsSubtotal,
                "Special Occupancy", "Parent line", null
                , modelObject, out stringSpecialOccupancyContentPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringSpecialOccupancyContentPointsSubtotal) ?
                stringSpecialOccupancyContentPointsSubtotal : Resources.ErrorMessages.OutputPropertySpecialOccupancyContentPointsSubtotalSubtotalNotInRange);


                //PrivateProtectionContentPointsSubtotal
                string stringPrivateProtectionContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PrivateProtectionContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PrivateProtectionContentPointsSubtotal,
                "Private Protection", "Parent line", null
                , modelObject, out stringPrivateProtectionContentPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringPrivateProtectionContentPointsSubtotal) ?
                stringPrivateProtectionContentPointsSubtotal : Resources.ErrorMessages.OutputPropertyPrivateProtectionContentPointsSubtotalNotInRange);


                //PublicProtectionContentPointsSubtotal
                string stringPublicProtectionContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PublicProtectionContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PublicProtectionContentPointsSubtotal,
                "Public Protection", "Parent line", null
                , modelObject, out stringPublicProtectionContentPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringPublicProtectionContentPointsSubtotal) ?
                stringPublicProtectionContentPointsSubtotal : Resources.ErrorMessages.OutputPropertyPublicProtectionContentPointsSubtotalNotInRange);


                //ExternalExposureContentPointsSubtotal
                string stringExternalExposureContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ExternalExposureContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ExternalExposureContentPointsSubtotal,
                "External Exposure", "Parent line", null
                , modelObject, out stringExternalExposureContentPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringExternalExposureContentPointsSubtotal) ?
                stringExternalExposureContentPointsSubtotal : Resources.ErrorMessages.OutputPropertyExternalExposureContentPointsSubtotalNotInRange);


                //ConstructionContentPointsSubtotal
                string stringConstructionContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ConstructionContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ConstructionContentPointsSubtotal,
                "Construction", "Parent line", null
                , modelObject, out stringConstructionContentPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringConstructionContentPointsSubtotal) ?
                stringConstructionContentPointsSubtotal : Resources.ErrorMessages.OutputPropertyConstructionContentPointsSubtotalNotInRange);


                //FloodContentPointsSubtotal
                string stringFloodContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodContentPointsSubtotal,
                "Flood", "Parent line", null
                , modelObject, out stringFloodContentPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringFloodContentPointsSubtotal) ?
                stringFloodContentPointsSubtotal : Resources.ErrorMessages.OutputPropertyFloodContentPointsSubtotalNotInRange);

                //EarthMovementContentPointsSubtotal
                  string stringEarthMovementContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthMovementContentPointsSubtotal)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthMovementContentPointsSubtotal,
                "Earth Movement", "Parent line", null
                , modelObject, out stringEarthMovementContentPointsSubtotal)).
                WithMessage(!string.IsNullOrEmpty(stringEarthMovementContentPointsSubtotal) ?
                stringEarthMovementContentPointsSubtotal : Resources.ErrorMessages.OutputPropertyEarthMovementContentPointsSubtotalNotInRange);


            });

            
           
            



            #region Commented code

            //STEP-II
            //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownLimitFactor).ScalePrecision(4, 15)
            //    .NotNull().WithMessage(Resources.ErrorMessages.OutputPropertyEquipmentBreakdownLimitFactorRequired);

            //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownDeductibleFactor).ScalePrecision(4, 15)
            //    .NotNull().WithMessage(Resources.ErrorMessages.OutputPropertyEquipmentBreakdownDeductibleFactorRequired);

            //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BusinessIncomeAndExtraExpenseDeductibleFactor).ScalePrecision(4, 15)
            //    .NotNull().WithMessage(Resources.ErrorMessages.OutputPropertyBusinessIncomeAndExtraExpenseDeductibleFactorRequired);

            //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PollutantCleanUpLimitFactor).ScalePrecision(4, 15)
            //    .NotNull().WithMessage(Resources.ErrorMessages.OutputPropertyPollutantCleanUpLimitFactorRequired);

            //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.RefrigerantContaminationLimitFactor).ScalePrecision(4, 15)
            //.NotNull().WithMessage(Resources.ErrorMessages.OutputPropertyRefrigerantContaminationLimitFactorRequired);



            //this.RuleFor(reg =>  reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownSpoilageDollarDeductible).ScalePrecision(4, 15)
            //    .NotNull().WithMessage(Resources.ErrorMessages.OutputPropertyEquipmentBreakdownSpoilageDollarDeductibleRequired);

            //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium).ScalePrecision(4, 15)
            //    .NotNull().WithMessage(Resources.ErrorMessages.OutputPropertyEquipmentBreakdownTotalPremiumRequired);

            // #region Property CW
            // #region Building BPP Premium 
            // decimal calculatedBuildingModifiedMLR = 0
            // , calculatedContentsModifiedMLR = 0, calculatedModifiedNormalLossRate = 0, calculatedBuildingFinalRate = 0,
            // calculatedContentsFinalRate = 0, calculatedBuildingBPPPremium = 0;

            // //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TotalTIV)
            // //    .Must((modelObject, totalTIV) => IsTotalTIVValid(modelObject, out calculatedTotalTIV))
            // //    .WithMessage(x => string.Format("Value of TotalTIV should be equal to {0} ", calculatedTotalTIV));

            // this.When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Coinsurance != null && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.MarginClause != null && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Valuation != null, () =>
            // {
            //     this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingModifiedMLR)
            //         .Must((modelObject, buildingModifiedMLR) => IsBuildingModifiedMLRValid(modelObject.OutputModel.Property, out calculatedBuildingModifiedMLR))
            //         .WithMessage(x => string.Format("Value of BuildingModifiedMLR should be equal to {0} !", calculatedBuildingModifiedMLR));
            // });

            // this.When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Coinsurance != null && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.MarginClause != null && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Valuation != null, () =>
            // {
            //     this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsModifiedMLR)
            //         .Must((modelObject, contentsModifiedMLR) => IsContentsModifiedMLRValid(modelObject.OutputModel.Property, out calculatedContentsModifiedMLR))
            //         .WithMessage(x => string.Format("Value of ContentsModifiedMLR should be equal to {0} !", calculatedContentsModifiedMLR));
            // });

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedNormalLossRate)
            //    .Must((modelObject, modifiedNormalLossRate) => IsModifiedNormalLossRateUnderLimitValid(modelObject, out calculatedModifiedNormalLossRate))
            //    .WithMessage(x => string.Format("If Deductible is  $2, 500 and below, ModifiedNormalLossRate should be equal to {0} !", calculatedModifiedNormalLossRate));


            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedNormalLossRate)
            //    .Must((modelObject, modifiedNormalLossRate) => IsModifiedNormalLossRateOverLimtiValid(modelObject, out calculatedModifiedNormalLossRate))
            //    .WithMessage(x => string.Format("If Deductible is  $5, 000 and below, ModifiedNormalLossRate should be equal to {0} !", calculatedModifiedNormalLossRate));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingFinalRate)
            //   .Must((modelObject, buildingFinalRate) => IsBuildingFinalRateValid(modelObject.OutputModel.Property, out calculatedBuildingFinalRate))
            //   .WithMessage(x => string.Format("Value of BuildingFinalRate  should be equal to be  {0} !", calculatedBuildingFinalRate));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsFinalRate)
            //   .Must((modelObject, contentsFinalRate) => IsContentsFinalRateValid(modelObject.OutputModel.Property, out calculatedContentsFinalRate))
            //   .WithMessage(x => string.Format("Value of ContentsFinalRate  should be equal to be {0} !", calculatedContentsFinalRate));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium)
            //    .Must((modelObject, buildingBPPPremium) => IsBuildingBPPPremiumValid(modelObject, out calculatedBuildingBPPPremium))
            //   .WithMessage(x => string.Format("Value of BuildingBPPPremium  should be equal to be {0} !", calculatedBuildingBPPPremium));


            // #endregion

            // #region Equipment Breakdown
            // decimal calculatedEquipmentBreakdownBuildingOrContentsPremium = 0, calculatedEquipmentBreakdownBusinessIncomePremium = 0,
            //     calculatedPremium1 = 0, calculatedPremium2 = 0, calculatedEquipmentBreakdownTotalPremium = 0, calculatedEquipmentBreakdownLimit = 0, calculatedEquipmentBreakdownRate = 0;

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownBuildingOrContentsPremium)
            //     .Must((modelObject, EquipmentBreakdownBuildingOrContentsPremium) => IsEquipmentBreakdownBuildingOrContentsPremiumValid(modelObject.OutputModel.Property, out calculatedEquipmentBreakdownBuildingOrContentsPremium))
            //      .WithMessage(x => string.Format("Value of EquipmentBreakdownBuildingOrContentsPremium should be equal to {0} !", calculatedEquipmentBreakdownBuildingOrContentsPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownBusinessIncomePremium)
            //    .Must((modelObject, EquipmentBreakdownBusinessIncomePremium) => IsequipmentBreakdownBusinessIncomePremiumValid(modelObject, out calculatedEquipmentBreakdownBusinessIncomePremium))
            //     .WithMessage(x => string.Format("Value of EquipmentBreakdownBusinessIncomePremium should be equal to {0} !", calculatedEquipmentBreakdownBusinessIncomePremium));
            // #endregion

            // #region WindFlood Earthquake Prem
            // decimal calculatedPerilBuildingPoints = 0, calculatedBuildingDefPointsNoPerils = 0, calculatedContentsDefTotalPointsNoPerils = 0, calculatedBuildingModifiedMLRNoPerils = 0
            // , calculatedBuildingCombinedRateNoPerils = 0, calculatedBuildingPremiumNoPerils = 0, calculatedBuildingPremiumTotal = 0, calculatedBuildingPremiumForPerils = 0, calculatedContentsModifiedMLRNoPerils = 0
            // , calculatedContentsCombinedRateNoPerils = 0, calculatedContentsPremiumNoPerils = 0, calculatedContentsPremiumTotal = 0, calculatedContentsPremiumForPerils = 0, calculatedWindBuildingPremium = 0
            // , calculatedWindContentPremium = 0, calculatedWindTotalPremium = 0, calculatedfloodBuildingPremium = 0, calculatedFloodContentPremium = 0, calculatedFloodTotalPremium = 0, calculatedEarthquakeBuildingPremium = 0
            // , calculatedEarthquakeContentPremium = 0, calculatedEarthquakeTotalPremium = 0;

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilBuildingPoints)
            //  .Must((modelObject, perilBuildingPoints) => IsPerilBuildingPointsValid(modelObject, out calculatedPerilBuildingPoints))
            //   .WithMessage(x => string.Format("Value of PerilBuildingPoints should be equal to {0} !", calculatedPerilBuildingPoints));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingDefPointsNoPerils)
            //  .Must((modelObject, buildingDefPointsNoPerils) => IsBuildingDefPointsNoPerilsValid(modelObject, out calculatedBuildingDefPointsNoPerils))
            //   .WithMessage(x => string.Format("Value of buildingDefPointsNoPerils should be equal to {0} !", calculatedBuildingDefPointsNoPerils));

            // this.RuleFor(reg => reg.OutputModel.Property.ContentsDefTotalPointsNoPerils)
            //  .Must((modelObject, ContentsDefTotalPointsNoPerils) => IsContentsDefTotalPointsNoPerilsValid(modelObject, out calculatedContentsDefTotalPointsNoPerils))
            //   .WithMessage(x => string.Format("Value of ContentsDefTotalPointsNoPerils should be equal to {0} !", calculatedContentsDefTotalPointsNoPerils));

            // // -------------Step A-----------------------//
            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingModifiedMLRNoPerils)
            //  .Must((modelObject, buildingModifiedMLRNoPerils) => IsBuildingModifiedMLRNoPerilsValid(modelObject, out calculatedBuildingModifiedMLRNoPerils))
            //   .WithMessage(x => string.Format("Value of BuildingModifiedMLRNoPerils should be equal to {0} !", calculatedBuildingModifiedMLRNoPerils));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingCombinedRateNoPerils)
            //  .Must((modelObject, buildingCombinedRateNoPerils) => IsBuildingCombinedRateNoPerilsValid(modelObject, out calculatedBuildingCombinedRateNoPerils))
            //   .WithMessage(x => string.Format("Value of BuildingCombinedRateNoPerils should be equal to {0} !", calculatedBuildingCombinedRateNoPerils));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumNoPerils)
            //  .Must((modelObject, buildingPremiumNoPerils) => IsBuildingPremiumNoPerilsValid(modelObject, out calculatedBuildingPremiumNoPerils))
            //   .WithMessage(x => string.Format("Value of BuildingPremiumNoPerils should be equal to {0} !", calculatedBuildingPremiumNoPerils));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumTotal)
            // .Must((modelObject, buildingPremiumTotal) => IsBuildingPremiumTotalValid(modelObject, out calculatedBuildingPremiumTotal))
            //  .WithMessage(x => string.Format("Value of BuildingPremiumTotal should be equal to {0} !", calculatedBuildingPremiumTotal));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumForPerils)
            // .Must((modelObject, buildingPremiumForPerils) => IsBuildingPremiumForPerilsValid(modelObject, out calculatedBuildingPremiumForPerils))
            //  .WithMessage(x => string.Format("Value of BuildingPremiumForPerils should be equal to {0} !", calculatedBuildingPremiumForPerils));

            // // -------------Step B-----------------------//

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsModifiedMLRNoPerils)
            //.Must((modelObject, contentsModifiedMLRNoPerils) => IsContentsModifiedMLRNoPerilsValid(modelObject, out calculatedContentsModifiedMLRNoPerils))
            // .WithMessage(x => string.Format("Value of ContentsModifiedMLRNoPerils should be equal to {0} !", calculatedContentsModifiedMLRNoPerils));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsCombinedRateNoPerils)
            // .Must((modelObject, contentsCombinedRateNoPerils) => IsContentsCombinedRateNoPerilsValid(modelObject, out calculatedContentsCombinedRateNoPerils))
            //.WithMessage(x => string.Format("Value of ContentsCombinedRateNoPerils should be equal to {0} !", calculatedContentsCombinedRateNoPerils));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumNoPerils)
            // .Must((modelObject, contentsPremiumNoPerils) => IsContentsPremiumNoPerilsValid(modelObject, out calculatedContentsPremiumNoPerils))
            // .WithMessage(x => string.Format("Value of ContentsPremiumNoPerils should be equal to {0} !", calculatedContentsPremiumNoPerils));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumTotal)
            // .Must((modelObject, contentsPremiumTotal) => IsContentsPremiumTotalValid(modelObject, out calculatedContentsPremiumTotal))
            // .WithMessage(x => string.Format("Value of ContentsPremiumTotal should be equal to {0} !", calculatedContentsPremiumTotal));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumForPerils)
            // .Must((modelObject, contentsPremiumForPerils) => IsContentsPremiumForPerilsValid(modelObject, out calculatedContentsPremiumForPerils))
            // .WithMessage(x => string.Format("Value of ContentsPremiumForPerils should be equal to {0} !", calculatedContentsPremiumForPerils));

            // // -------------Step C-----------------------//

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindBuildingPremium)
            // .Must((modelObject, windBuildingPremium) => IsWindBuildingPremiumValid(modelObject, out calculatedWindBuildingPremium))
            // .WithMessage(x => string.Format("Value of WindBuildingPremium should be equal to {0} !", calculatedWindBuildingPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindContentPremium)
            // .Must((modelObject, windContentPremium) => IsWindContentPremiumValid(modelObject, out calculatedWindContentPremium))
            // .WithMessage(x => string.Format("Value of WindContentPremium should be equal to {0} !", calculatedWindContentPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium)
            // .Must((modelObject, windTotalPremium) => IsWindTotalPremiumValid(modelObject, out calculatedWindTotalPremium))
            // .WithMessage(x => string.Format("Value of WindTotalPremium should be equal to {0} !", calculatedWindTotalPremium));

            // //------------Setp D------------//
            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodBuildingPremium)
            // .Must((modelObject, floodBuildingPremium) => IsFloodBuildingPremiumValid(modelObject, out calculatedfloodBuildingPremium))
            // .WithMessage(x => string.Format("Value of FloodBuildingPremium should be equal to {0} !", calculatedfloodBuildingPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodContentPremium)
            //.Must((modelObject, floodContentPremium) => IsFloodContentPremiumValid(modelObject, out calculatedFloodContentPremium))
            //.WithMessage(x => string.Format("Value of FloodContentPremium should be equal to {0} !", calculatedFloodContentPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium)
            //.Must((modelObject, floodTotalPremium) => IsFloodTotalPremiumValid(modelObject, out calculatedFloodTotalPremium))
            //.WithMessage(x => string.Format("Value of FloodTotalPremium should be equal to {0} !", calculatedFloodTotalPremium));

            // //------------Setp E------------//

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeBuildingPremium)
            // .Must((modelObject, earthquakeBuildingPremium) => IsEarthquakeBuildingPremiumValid(modelObject, out calculatedEarthquakeBuildingPremium))
            // .WithMessage(x => string.Format("Value of EarthquakeBuildingPremium should be equal to {0} !", calculatedEarthquakeBuildingPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeContentPremium)
            // .Must((modelObject, earthquakeContentPremium) => IsEarthquakeContentPremiumValid(modelObject, out calculatedEarthquakeContentPremium))
            // .WithMessage(x => string.Format("Value of EarthquakeContentPremium should be equal to {0} !", calculatedEarthquakeContentPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium)
            // .Must((modelObject, earthquakeTotalPremium) => IsEarthquakeTotalPremiumValid(modelObject, out calculatedEarthquakeTotalPremium))
            // .WithMessage(x => string.Format("Value of EarthquakeTotalPremium should be equal to {0} !", calculatedEarthquakeTotalPremium));

            // #endregion

            // #region Final Property

            // decimal calculatedEquipmentBreakdown = 0, calculatedProRatafactor = 0, calculatedBasePremium = 0, calculatedNonModifiedPremium = 0
            // , calculatedManualPremium = 0, calculatedTierPremium = 0, calculatedIRPMPremium = 0, calculatedOtherModPremium = 0,
            // calculatedTerrorismPremium = 0, calculatedModifiedPremium = 0, calculatedFireSafetySurcharge = 0;

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdown)
            // .Must((modelObject, equipmentBreakdown) => IsEquipmentBreakdowmValid(modelObject, out calculatedEquipmentBreakdown))
            // .WithMessage(x => string.Format("Value of EquipmentBreakdown should be equal to {0} !", calculatedEquipmentBreakdown));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor)
            // .Must((modelObject, proRatafactor) => IsProRatafactorValid(modelObject, out calculatedProRatafactor))
            // .WithMessage(x => string.Format("Value of ProRatafactor should be equal to {0} !", calculatedProRatafactor));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BasePremium)
            // .Must((modelObject, basePremium) => IsBasePremiumValid(modelObject, out calculatedBasePremium))
            // .WithMessage(x => string.Format("Value of BasePremium should be equal to {0} !", calculatedBasePremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium)
            //.Must((modelObject, nonModifiedPremium) => IsNonModifiedPremium(modelObject, out calculatedNonModifiedPremium))
            //.WithMessage(x => string.Format("Value of NonModifiedPremium should be equal to {0} !", calculatedNonModifiedPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium)
            //.Must((modelObject, manualPremium) => IsManualPremiumValid(modelObject, out calculatedManualPremium))
            //.WithMessage(x => string.Format("Value of ManualPremium should be equal to {0} !", calculatedManualPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium)
            // .Must((modelObject, tierPremium) => IsTierPremiumValid(modelObject, out calculatedTierPremium))
            // .WithMessage(x => string.Format("Value of TierPremium should be equal to {0} !", calculatedTierPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium)
            // .Must((modelObject, iRPMPremium) => IsIRPMPremiumValid(modelObject, out calculatedIRPMPremium))
            // .WithMessage(x => string.Format("Value of IRPMPremium should be equal to {0} !", calculatedIRPMPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium)
            // .Must((modelObject, otherModPremium) => IsOtherModPremiumValid(modelObject, out calculatedOtherModPremium))
            // .WithMessage(x => string.Format("Value of OtherModPremium should be equal to {0} !", calculatedOtherModPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TerrorismPremium)
            // .Must((modelObject, terrorismPremium) => IsTerrorismPremiumValid(modelObject, out calculatedTerrorismPremium))
            // .WithMessage(x => string.Format("Value of TerrorismPremium should be equal to {0} !", calculatedTerrorismPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium)
            // .Must((modelObject, modifiedPremium) => IsModifiedPremiumValid(modelObject, out calculatedModifiedPremium))
            // .WithMessage(x => string.Format("Value of ModifiedPremium should be equal to {0} !", calculatedModifiedPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium)
            // .Must((modelObject, modifiedPremium) => IsModifiedPremiumValid(modelObject, out calculatedModifiedPremium))
            // .WithMessage(x => string.Format("Value of ModifiedPremium should be equal to {0} !", calculatedModifiedPremium));

            // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FireSafetySurcharge)
            //.Must((modelObject, fireSafetySurcharge) => IsFireSafetySurchargeValid(modelObject, out calculatedFireSafetySurcharge))
            //.WithMessage(x => string.Format("Value of FireSafetySurcharge should be equal to {0} !", calculatedFireSafetySurcharge));

            // #endregion

            // #endregion

            //#region 360 Coverage

            //this.When(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel != null, () =>
            //{
            //    //Step 1 - Business Income & Extra Expense(BI & EE)

            //    decimal calculatedBusinessIncomeAndExtraExpensePremium = 0, calculatedDependentPropertyPremium = 0, calculatedInterruptionOfComputerOperationsPremium = 0, calculatedLeaseCancellationMovingExpensesPremium = 0, calculatedNewlyAcquiredOrConstructedPropertyPremium = 0,
            //    calculatedOffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium = 0, calculatedBusinessIncomeAndExtraExpense360CoveragePremium = 0, calculatedFireDepartmentServiceChargePremium = 0
            //    , calculatedFungusWetRotDryRotAndBacteriaPremium = 0, calculatedGlassDisplayOrTrophyCasesPremium = 0, calculatedInventoryAndAppraisalPremium = 0, calculatedKeyCardPremium = 0, calculatedLockReplacementPremium = 0,
            //    calculatedMoneyAndSecuritiesOnYourPremisesPremium = 0, calculatedMoneyAndSecuritiesAwayFromYourPremisesPremium = 0, calculatedNewlyAcquiredOrConstructedPropertyBuildingsPremium = 0,
            //    calculatedNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium = 0, calculatedNonOwnedDetachedTrailersPremium = 0, calculatedOffPremisesUtilityFailureDamageToCoveredPropertyPremium = 0,
            //    calculatedOutdoorPropertyPremium = 0, calculatedPropertyInTransitPremium = 0;

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.BusinessIncomeAndExtraExpensePremium)
            //    .Must((modelObject, businessIncomeAndExtraExpensePremium) => IsBusinessIncomeAndExtraExpensePremiumValid(modelObject, out calculatedBusinessIncomeAndExtraExpensePremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.BusinessIncomeAndExtraExpensePremium should be equal to {0} !", calculatedBusinessIncomeAndExtraExpensePremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.DependentPropertyPremium)
            //   .Must((modelObject, dependentPropertyPremium) => IsDependentPropertyPremiumValid(modelObject, out calculatedDependentPropertyPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.DependentPropertyPremium should be equal to {0} !", calculatedDependentPropertyPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.InterruptionOfComputerOperationsPremium)
            //   .Must((modelObject, interruptionOfComputerOperationsPremium) => IsInterruptionOfComputerOperationsPremiumValid(modelObject, out calculatedInterruptionOfComputerOperationsPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.InterruptionOfComputerOperationsPremium should be equal to {0} !", calculatedInterruptionOfComputerOperationsPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.LeaseCancellationMovingExpensesPremium)
            //   .Must((modelObject, leaseCancellationMovingExpensesPremium) => IsLeaseCancellationMovingExpensesPremiumValid(modelObject, out calculatedLeaseCancellationMovingExpensesPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.LeaseCancellationMovingExpensesPremium should be equal to {0} !", calculatedLeaseCancellationMovingExpensesPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium)
            //    .Must((modelObject, newlyAcquiredOrConstructedPropertyPremium) => IsNewlyAcquiredOrConstructedPropertyPremiumValid(modelObject, out calculatedNewlyAcquiredOrConstructedPropertyPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium should be equal to {0} !", calculatedNewlyAcquiredOrConstructedPropertyPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium)
            //    .Must((modelObject, offPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium) => IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremiumValid(modelObject, out calculatedOffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium should be equal to {0} !", calculatedOffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium));

            //    //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BusinessIncomeAndExtraExpense360CoveragePremium)
            //    //.Must((modelObject, businessIncomeAndExtraExpense360CoveragePremium) => IsBusinessIncomeAndExtraExpense360CoveragePremiumValid(modelObject, out calculatedBusinessIncomeAndExtraExpense360CoveragePremium))
            //    //.WithMessage(x => string.Format("Value of OutputModel.Property.BusinessIncomeAndExtraExpense360CoveragePremium should be equal to {0} !", calculatedBusinessIncomeAndExtraExpense360CoveragePremium));


            //    // -----Step 7.1 Ordinance or Law - Coverage B

            //    decimal calculatedOrdinanceOrLawCoverageBPremium = 0, calculatedOrdinanceOrLawCoverageCPremium = 0, calculatedAccountsReceivableRecordsPremium = 0,
            //    calculatedAppurtenantStructuresPremium = 0, calculatedAudioVisualAndCommunicationEquipmentPremium = 0, calculatedChangesInTemperatureOrHumidityPremium = 0,
            //    calculatedCommandeeredPropertyPremium = 0, calculatedComputerEquipmentPremium = 0, calculatedDebrisRemovalYourPremisesPremium = 0, calculatedDebrisRemovalWindBlownDebrisPremium = 0,
            //    calculatedElectronicDataPremium = 0, calculatedFineArtsPremium = 0, calculatedPersonalEffectsAndPropertyOfOthersPremium = 0, calculatedPersonalPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium = 0
            //    , calculatedPollutantCleanUpAndRemovalPremium = 0, calculatedPropertyOffPremisesPremium = 0, calculatedRechargeOfFireProtectionEquipmentPremium = 0, calculatedRetainingWallsPremium = 0,
            //    calculatedRewardPaymentsPremium = 0, calculatedSalespersonsSamplesPremium = 0, calculatedSCADAUpgradePremium = 0, calculatedSodTreesShrubsAndPlantsAnyOnePremium = 0,
            //    calculatedSodTreesShrubsAndPlantsOccurrencePremium = 0, calculatedSpoilagePremium = 0, calculatedUndamagedLeaseholdImprovementsPremium = 0, calculatedValuablePapersAndRecordsOtherThanElectronicDataPremium = 0,
            //    calculatedProperty360ModificationCoverageTotalPremium = 0, calculatedTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium = 0, calculatedGolfCoursesTeeToGreenPremium = 0,
            //    calculatedGolfCoursesSprinklerAndUndergroundWiringPremium = 0, calculatedGolfCoursesAdditionalGolfCoursePropertyPremium = 0, calculatedProperty360GolfCourceTotalPremium = 0,
            //    calculatedLossOfMunicipalTaxRevenuePremium = 0;

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OrdinanceOrLawCoverageBPremium)
            //    .Must((modelObject, ordinanceOrLawCoverageBPremium) => IsOrdinanceOrLawCoverageBPremiumValid(modelObject, out calculatedOrdinanceOrLawCoverageBPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.OrdinanceOrLawCoverageBPremium should be equal to {0} !", calculatedOrdinanceOrLawCoverageBPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OrdinanceOrLawCoverageCPremium)
            //    .Must((modelObject, ordinanceOrLawCoverageCPremium) => IsOrdinanceOrLawCoverageCPremiumValid(modelObject, out calculatedOrdinanceOrLawCoverageCPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.OrdinanceOrLawCoverageCPremium should be equal to {0} !", calculatedOrdinanceOrLawCoverageCPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.AccountsReceivableRecordsPremium)
            //    .Must((modelObject, accountsReceivableRecordsPremium) => IsAccountsReceivableRecordsPremiumValid(modelObject, out calculatedAccountsReceivableRecordsPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.AccountsReceivableRecordsPremium should be equal to {0} !", calculatedAccountsReceivableRecordsPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.AppurtenantStructuresPremium)
            //    .Must((modelObject, appurtenantStructuresPremium) => IsAppurtenantStructuresPremiumValid(modelObject, out calculatedAppurtenantStructuresPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.AppurtenantStructuresPremium should be equal to {0} !", calculatedAppurtenantStructuresPremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.AudioVisualAndCommunicationEquipmentPremium)
            //    .Must((modelObject, audioVisualAndCommunicationEquipmentPremium) => IsAudioVisualAndCommunicationEquipmentPremiumValid(modelObject, out calculatedAudioVisualAndCommunicationEquipmentPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.AudioVisualAndCommunicationEquipmentPremium should be equal to {0} !", calculatedAudioVisualAndCommunicationEquipmentPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ChangesInTemperatureOrHumidityPremium)
            //    .Must((modelObject, changesInTemperatureOrHumidityPremium) => IsChangesInTemperatureOrHumidityPremiumValid(modelObject, out calculatedChangesInTemperatureOrHumidityPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.ChangesInTemperatureOrHumidityPremium should be equal to {0} !", calculatedChangesInTemperatureOrHumidityPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.CommandeeredPropertyPremium)
            //    .Must((modelObject, CommandeeredPropertyPremium) => IsCommandeeredPropertyPremiumValid(modelObject, out calculatedCommandeeredPropertyPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.CommandeeredPropertyPremium should be equal to {0} !", calculatedCommandeeredPropertyPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ComputerEquipmentPremium)
            //    .Must((modelObject, computerEquipmentPremium) => IsComputerEquipmentPremiumValid(modelObject, out calculatedComputerEquipmentPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.ComputerEquipmentPremium should be equal to {0} !", calculatedComputerEquipmentPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.DebrisRemovalYourPremisesPremium)
            //    .Must((modelObject, debrisRemovalYourPremisesPremium) => IsDebrisRemovalYourPremisesPremiumValid(modelObject, out calculatedDebrisRemovalYourPremisesPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.DebrisRemovalYourPremisesPremium should be equal to {0} !", calculatedDebrisRemovalYourPremisesPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.DebrisRemovalWindBlownDebrisPremium)
            //    .Must((modelObject, debrisRemovalWindBlownDebrisPremium) => IsDebrisRemovalWindBlownDebrisPremiumValid(modelObject, out calculatedDebrisRemovalWindBlownDebrisPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.DebrisRemovalWindBlownDebrisPremium should be equal to {0} !", calculatedDebrisRemovalWindBlownDebrisPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ElectronicDataPremium)
            //   .Must((modelObject, electronicDataPremium) => IsElectronicDataPremiumValid(modelObject, out calculatedElectronicDataPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.ElectronicDataPremium should be equal to {0} !", calculatedElectronicDataPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.FineArtsPremium)
            //   .Must((modelObject, fineArtsPremium) => IsFineArtsPremiumValid(modelObject, out calculatedFineArtsPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.FineArtsPremium should be equal to {0} !", calculatedFineArtsPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.FireDepartmentServiceChargePremium)
            //   .Must((modelObject, fireDepartmentServiceChargePremium) => IsFireDepartmentServiceChargePremiumValid(modelObject, out calculatedFireDepartmentServiceChargePremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.FireDepartmentServiceChargePremium should be equal to {0} !", calculatedFireDepartmentServiceChargePremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.FungusWetRotDryRotAndBacteriaPremium)
            //   .Must((modelObject, fungusWetRotDryRotAndBacteriaPremium) => IsFungusWetRotDryRotAndBacteriaPremiumValid(modelObject, out calculatedFungusWetRotDryRotAndBacteriaPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.FungusWetRotDryRotAndBacteriaPremium should be equal to {0} !", calculatedFungusWetRotDryRotAndBacteriaPremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GlassDisplayOrTrophyCasesPremium)
            //    .Must((modelObject, glassDisplayOrTrophyCasesPremium) => IsGlassDisplayOrTrophyCasesPremiumValid(modelObject, out calculatedGlassDisplayOrTrophyCasesPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.GlassDisplayOrTrophyCasesPremium should be equal to {0} !", calculatedGlassDisplayOrTrophyCasesPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.InventoryAndAppraisalPremium)
            //     .Must((modelObject, inventoryAndAppraisalPremium) => IsInventoryAndAppraisalPremiumValid(modelObject, out calculatedInventoryAndAppraisalPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.InventoryAndAppraisalPremium should be equal to {0} !", calculatedInventoryAndAppraisalPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.KeyCardPremium)
            //     .Must((modelObject, keyCardPremium) => IsKeyCardPremiumValid(modelObject, out calculatedKeyCardPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.KeyCardPremium should be equal to {0} !", calculatedKeyCardPremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.LockReplacementPremium)
            //    .Must((modelObject, lockReplacementPremium) => IsLockReplacementPremiumValid(modelObject, out calculatedLockReplacementPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.LockReplacementPremium should be equal to {0} !", calculatedLockReplacementPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium)
            //    .Must((modelObject, moneyAndSecuritiesOnYourPremisesPremium) => IsMoneyAndSecuritiesOnYourPremisesPremiumValid(modelObject, out calculatedMoneyAndSecuritiesOnYourPremisesPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium should be equal to {0} !", calculatedMoneyAndSecuritiesOnYourPremisesPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium)
            //     .Must((modelObject, moneyAndSecuritiesAwayFromYourPremisesPremium) => IsMoneyAndSecuritiesAwayFromYourPremisesPremiumValid(modelObject, out calculatedMoneyAndSecuritiesAwayFromYourPremisesPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium should be equal to {0} !", calculatedMoneyAndSecuritiesAwayFromYourPremisesPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium)
            //    .Must((modelObject, newlyAcquiredOrConstructedPropertyBuildingsPremium) => IsNewlyAcquiredOrConstructedPropertyBuildingsPremiumValid(modelObject, out calculatedNewlyAcquiredOrConstructedPropertyBuildingsPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium should be equal to {0} !", calculatedNewlyAcquiredOrConstructedPropertyBuildingsPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium)
            //    .Must((modelObject, newlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium) => IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremiumValid(modelObject, out calculatedNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium should be equal to {0} !", calculatedNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NonOwnedDetachedTrailersPremium)
            //    .Must((modelObject, nonOwnedDetachedTrailersPremium) => IsNonOwnedDetachedTrailersPremiumValid(modelObject, out calculatedNonOwnedDetachedTrailersPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.NonOwnedDetachedTrailersPremium should be equal to {0} !", calculatedNonOwnedDetachedTrailersPremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium)
            //    .Must((modelObject, offPremisesUtilityFailureDamageToCoveredPropertyPremium) => IsOffPremisesUtilityFailureDamageToCoveredPropertyPremiumValid(modelObject, out calculatedOffPremisesUtilityFailureDamageToCoveredPropertyPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium should be equal to {0} !", calculatedOffPremisesUtilityFailureDamageToCoveredPropertyPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OutdoorPropertyPremium)
            //    .Must((modelObject, outdoorPropertyPremium) => IsOutdoorPropertyPremiumValid(modelObject, out calculatedOutdoorPropertyPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.OutdoorPropertyPremium should be equal to {0} !", calculatedOutdoorPropertyPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium)
            //    .Must((modelObject, personalEffectsAndPropertyOfOthersPremium) => IsPersonalEffectsAndPropertyOfOthersPremiumValid(modelObject, out calculatedPersonalEffectsAndPropertyOfOthersPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium should be equal to {0} !", calculatedPersonalEffectsAndPropertyOfOthersPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium)
            //    .Must((modelObject, personalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium) => IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremiumValid(modelObject, out calculatedPersonalPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium should be equal to {0} !", calculatedPersonalPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PollutantCleanUpAndRemovalPremium)
            //    .Must((modelObject, pollutantCleanUpAndRemovalPremium) => IsPollutantCleanUpAndRemovalPremiumValid(modelObject, out calculatedPollutantCleanUpAndRemovalPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.PollutantCleanUpAndRemovalPremium should be equal to {0} !", calculatedPollutantCleanUpAndRemovalPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PropertyInTransitPremium)
            //    .Must((modelObject, propertyInTransitPremium) => IsPropertyInTransitPremiumValid(modelObject, out calculatedPropertyInTransitPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.PropertyInTransitPremium should be equal to {0} !", calculatedPropertyInTransitPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PropertyOffPremisesPremium)
            //   .Must((modelObject, PropertyOffPremisesPremium) => IsPropertyOffPremisesPremiumValid(modelObject, out calculatedPropertyOffPremisesPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.PropertyOffPremisesPremium should be equal to {0} !", calculatedPropertyOffPremisesPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.RechargeOfFireProtectionEquipmentPremium)
            //   .Must((modelObject, rechargeOfFireProtectionEquipmentPremium) => IsRechargeOfFireProtectionEquipmentPremiumValid(modelObject, out calculatedRechargeOfFireProtectionEquipmentPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.RechargeOfFireProtectionEquipmentPremium should be equal to {0} !", calculatedRechargeOfFireProtectionEquipmentPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.RetainingWallsPremium)
            //   .Must((modelObject, retainingWallsPremium) => IsRetainingWallsPremiumValid(modelObject, out calculatedRetainingWallsPremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.RetainingWallsPremium should be equal to {0} !", calculatedRetainingWallsPremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.RewardPaymentsPremium)
            //    .Must((modelObject, rewardPaymentsPremium) => IsRewardPaymentsPremiumValid(modelObject, out calculatedRewardPaymentsPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.RewardPaymentsPremium should be equal to {0} !", calculatedRewardPaymentsPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SalespersonsSamplesPremium)
            //    .Must((modelObject, salespersonsSamplesPremium) => IsSalespersonsSamplesPremiumValid(modelObject, out calculatedSalespersonsSamplesPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.SalespersonsSamplesPremium should be equal to {0} !", calculatedSalespersonsSamplesPremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SCADAUpgradePremium)
            //    .Must((modelObject, sCADAUpgradePremium) => IsSCADAUpgradePremiumValid(modelObject, out calculatedSCADAUpgradePremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.SCADAUpgradePremium should be equal to {0} !", calculatedSCADAUpgradePremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium)
            //   .Must((modelObject, sodTreesShrubsAndPlantsAnyOnePremium) => IsSodTreesShrubsAndPlantsAnyOnePremiumValid(modelObject, out calculatedSodTreesShrubsAndPlantsAnyOnePremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium should be equal to {0} !", calculatedSodTreesShrubsAndPlantsAnyOnePremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium)
            //   .Must((modelObject, sodTreesShrubsAndPlantsOccurrencePremium) => IsSodTreesShrubsAndPlantsOccurrencePremiumValid(modelObject, out calculatedSodTreesShrubsAndPlantsOccurrencePremium))
            //   .WithMessage(x => string.Format("Value of Property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium should be equal to {0} !", calculatedSodTreesShrubsAndPlantsOccurrencePremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SpoilagePremium)
            //    .Must((modelObject, spoilagePremium) => IsSpoilagePremiumValid(modelObject, out calculatedSpoilagePremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.SpoilagePremium should be equal to {0} !", calculatedSpoilagePremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium)
            //    .Must((modelObject, theftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium) => IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremiumValid(modelObject, out calculatedTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium should be equal to {0} !", calculatedTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.UndamagedLeaseholdImprovementsPremium)
            //    .Must((modelObject, undamagedLeaseholdImprovementsPremium) => IsUndamagedLeaseholdImprovementsPremiumValid(modelObject, out calculatedUndamagedLeaseholdImprovementsPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.UndamagedLeaseholdImprovementsPremium should be equal to {0} !", calculatedUndamagedLeaseholdImprovementsPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium)
            //    .Must((modelObject, valuablePapersAndRecordsOtherThanElectronicDataPremium) => IsValuablePapersAndRecordsOtherThanElectronicDataPremiumValid(modelObject, out calculatedValuablePapersAndRecordsOtherThanElectronicDataPremium))
            //    .WithMessage(x => string.Format("Value of Property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium should be equal to {0} !", calculatedValuablePapersAndRecordsOtherThanElectronicDataPremium));

            //    //this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360ModificationCoverageTotalPremium)
            //    //.Must((modelObject, property360ModificationCoverageTotalPremium) => IsProperty360ModificationCoverageTotalPremiumValid(modelObject, out calculatedProperty360ModificationCoverageTotalPremium))
            //    //.WithMessage(x => string.Format("Value of OutputModel.Property.Property360ModificationCoverageTotalPremium should be equal to {0} !", calculatedProperty360ModificationCoverageTotalPremium));


            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GolfCoursesTeeToGreenPremium)
            //      .Must((modelObject, golfCoursesTeeToGreenPremium) => IsGolfCoursesTeeToGreenPremiumValid(modelObject, out calculatedGolfCoursesTeeToGreenPremium))
            //      .WithMessage(x => string.Format("Value of Property360OutputModel.GolfCoursesTeeToGreenPremium should be equal to {0} !", calculatedGolfCoursesTeeToGreenPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium)
            //     .Must((modelObject, golfCoursesSprinklerAndUndergroundWiringPremium) => IsGolfCoursesSprinklerAndUndergroundWiringPremiumValid(modelObject, out calculatedGolfCoursesSprinklerAndUndergroundWiringPremium))
            //     .WithMessage(x => string.Format("Value of Property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium should be equal to {0} !", calculatedGolfCoursesSprinklerAndUndergroundWiringPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium)
            //     .Must((modelObject, golfCoursesAdditionalGolfCoursePropertyPremium) => IsGolfCoursesAdditionalGolfCoursePropertyPremiumValid(modelObject, out calculatedGolfCoursesAdditionalGolfCoursePropertyPremium))
            //     .WithMessage(x => string.Format("Value of Property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium should be equal to {0} !", calculatedGolfCoursesAdditionalGolfCoursePropertyPremium));

            //   // this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360GolfCourceTotalPremium)
            //   //.Must((modelObject, property360GolfCourceTotalPremium) => IsProperty360GolfCourceTotalPremiumValid(modelObject, out calculatedProperty360GolfCourceTotalPremium))
            //   //.WithMessage(x => string.Format("Value of OutputModel.Property.Property360GolfCourceTotalPremium should be equal to {0} !", calculatedProperty360GolfCourceTotalPremium));

            //    this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.LossOfMunicipalTaxRevenuePremium)
            //      .Must((modelObject, lossOfMunicipalTaxRevenuePremium) => IsLossOfMunicipalTaxRevenuePremiumValid(modelObject, out calculatedLossOfMunicipalTaxRevenuePremium))
            //      .WithMessage(x => string.Format("Value of LossOfMunicipalTaxRevenuePremium should be equal to {0} !", calculatedLossOfMunicipalTaxRevenuePremium));
            //});
            //#endregion
            #endregion
        }

        public bool CheckTotalTIV(RaterFacadeModel model)
        {
            if ((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV + model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV) > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckForMinMaxValueForHazard(decimal valueTocheck, string category, string subCategory, string justification, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var propertyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetMinMaxValueForHazard(policyHeaderModel.State, propertyInputModel.LineOfBusiness, category, subCategory, justification,
                policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                message = category + " - " + subCategory + " range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = category + " - " + subCategory + " Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = category + " - " + subCategory + " Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }

            return flag;
        }

        #region Commented code

        //// #region BPP-Premium
        //// /// <summary>
        //// /// Check TotalTIV valid value
        //// /// TotalTIV =  BuildingTIV + ContentsTIV
        //// /// Sum of Total Building TIV & Contents TIV
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <param name="totalTIV">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsTotalTIVValid(RaterFacadeModel model, out decimal totalTIV)
        //// {
        ////     totalTIV = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV + model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV;
        ////     if (totalTIV == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TotalTIV)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step I - Building BPP Premium , StepIII-WindFloodEarthquakePrem
        //// /// Check BuildingModifiedMLR valid value
        //// ///  BuildingModifiedMLRValid = (BuildingBaseMLR + BuildingAddtlDefCharge) * AOPDeductible * Coinsurance * MarginClause * Valuation
        //// ///  (Step 6  + Step 7 )*Step 10 * Step 11* Step 12 * Step 13
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <param name="buildingModifiedMLR">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsBuildingModifiedMLRValid(PropertyOutputModel model, out decimal buildingModifiedMLR)
        //// {
        ////     buildingModifiedMLR = Math.Round((model.BuildingBaseMLR + model.BuildingAddtlDefCharge) * model.AOPDeductibleFactor * (decimal)model.CoinsuranceFactor * (decimal)model.MarginClauseFactor * model.ValuationFactor, 3, MidpointRounding.AwayFromZero);
        ////     if (buildingModifiedMLR == model.BuildingModifiedMLR)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }


        //// /// <summary>
        //// ///  Step I - Building BPP Premium , StepIII-WindFloodEarthquakePrem
        //// /// Check Contents Modified MLR valid value 
        //// /// ContentsModifiedMLR = (ContentsBaseMLR + ContentsAddtlDefCharge) * AOPDeductible * Coinsurance * MarginClause * Valuation
        //// /// (Step 8  + Step 9)*Step 10 * Step 11* Step 12 * Step 13
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <param name="contentsModifiedMLR">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsContentsModifiedMLRValid(PropertyOutputModel model, out decimal contentsModifiedMLR)
        //// {
        ////     contentsModifiedMLR = Math.Round((model.ContentsBaseMLR + model.ContentsAddtlDefCharge) * model.AOPDeductibleFactor * (decimal)model.CoinsuranceFactor * (decimal)model.MarginClauseFactor * model.ValuationFactor, 3, MidpointRounding.AwayFromZero);
        ////     if (contentsModifiedMLR == model.ContentsModifiedMLR)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// ///// <summary>
        //// /////  Step I - Building BPP Premium , StepIII-WindFloodEarthquakePrem
        //// ///// Check AOPDeductible is valid or not for value below 2500
        //// ///// (SumNetNormalLossClaims * LCMFactor) / (NormalLossTIVValue / 100)
        //// ///// </summary>
        //// ///// <param name="model">PropertyOutputModel</param>
        //// ///// <returns>bool value</returns>
        //// //public bool IsModifiedNormalLossRateUnderLimitValid(RaterFacadeModel model, out decimal modifiedNormalLossRate)
        //// //{
        //// //    modifiedNormalLossRate = 0;
        //// //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.NormalLossTIVValue != 0)
        //// //    {
        //// //        modifiedNormalLossRate = (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SumNetNormalLossClaims * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LCMFactor) / (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.NormalLossTIVValue / 100);
        //// //        if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible > 2500)
        //// //        {
        //// //            return true;
        //// //        }
        //// //        else if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible <= 2500 && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedNormalLossRate == modifiedNormalLossRate)
        //// //        {
        //// //            return true;
        //// //        }
        //// //        else
        //// //        {
        //// //            return false;
        //// //        }
        //// //    }
        //// //    else
        //// //    {
        //// //        return true;
        //// //    }

        //// //}

        //// /// <summary>
        //// /// IsModifiedNormalLossRateOverLimtiValid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="modifiedNormalLossRate">decimal</param>
        //// /// <returns>bool</returns>
        //// public bool IsModifiedNormalLossRateOverLimtiValid(RaterFacadeModel model, out decimal modifiedNormalLossRate)
        //// {

        ////     modifiedNormalLossRate = 0;

        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible < 5000)
        ////     {
        ////         return true;
        ////     }
        ////     else if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible >= 5000 && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NormalLossRate != modifiedNormalLossRate)
        ////     {
        ////         modifiedNormalLossRate = 0;
        ////         return false;
        ////     }
        ////     else
        ////     {

        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step I - Building BPP Premium , StepIII-WindFloodEarthquakePrem
        //// /// Check BuildingFinalRate is Valid or not
        //// /// BuildingFinalRate = BuildingModifiedMLR + ModifiedNormalLossRate
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <param name="buildingFinalRate">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsBuildingFinalRateValid(PropertyOutputModel model, out decimal buildingFinalRate)
        //// {
        ////     buildingFinalRate = model.BuildingModifiedMLR + model.ModifiedNormalLossRate;
        ////     if (buildingFinalRate == model.BuildingFinalRate)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check ContentsFinalRate is Valid or not
        //// /// ContentsFinalRate = ContentsModifiedMLR + ModifiedNormalLossRate
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <returns>bool value</returns>
        //// public bool IsContentsFinalRateValid(PropertyOutputModel model, out decimal contentsFinalRate)
        //// {
        ////     contentsFinalRate = model.ContentsModifiedMLR + model.ModifiedNormalLossRate;
        ////     if (contentsFinalRate == model.ContentsFinalRate)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check BuildingBPPPremium is Valid or not
        //// /// BuildingBPPPremium = BuildingFinalRate * (BuildingTIV / 100) + ContentsFinalRate * (ContentsTIV / 100);
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <returns>bool value</returns>
        //// public bool IsBuildingBPPPremiumValid(RaterFacadeModel model, out decimal buildingBPPPremium)
        //// {
        ////     buildingBPPPremium = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingFinalRate * (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV / 100) + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsFinalRate * (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV / 100), MidpointRounding.AwayFromZero);
        ////     if (buildingBPPPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }
        //// #endregion

        //// #region Equipment Breakdown
        //// /// <summary>
        //// /// Check EquipmentBreakdownBuildingOrContentsPremium is valid
        //// /// EquipmentBreakdownBuildingOrContentsPremium = (TotalTIV / 100) * EquipmentBreakdownLimitFactor * EquipmentBreakdownDeductibleFactor
        //// /// (Step 3/100)* Step 4 * Step 5
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <param name="equipmentBreakdownBuildingOrContentsPremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsEquipmentBreakdownBuildingOrContentsPremiumValid(PropertyOutputModel model, out decimal equipmentBreakdownBuildingOrContentsPremium)
        //// {
        ////     equipmentBreakdownBuildingOrContentsPremium = (model.TotalTIV / 100) * model.EquipmentBreakdownLimitFactor * model.EquipmentBreakdownDeductibleFactor;
        ////     if (equipmentBreakdownBuildingOrContentsPremium == model.EquipmentBreakdownBuildingOrContentsPremium)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check EquipmentBreakdownBuildingOrContentsPremium is valid
        //// /// EquipmentBreakdownBusinessIncomePremium = (BusinessIncomeAndExtraExpenseLimit / 100) * EquipmentBreakdownLimitFactor * BusinessIncomeAndExtraExpenseDeductibleFactor
        //// /// (Step 1/100) * Step 4 * Step 6
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <param name="equipmentBreakdownBusinessIncomePremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsequipmentBreakdownBusinessIncomePremiumValid(RaterFacadeModel model, out decimal equipmentBreakdownBusinessIncomePremium)
        //// {
        ////     equipmentBreakdownBusinessIncomePremium = (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit / 100) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownLimitFactor * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownBusinessIncomeAndExtraExpenseDeductibleFactor;
        ////     if (equipmentBreakdownBusinessIncomePremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownBusinessIncomePremium)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Check IsPremium1Valid is valid
        //// ///  premium1 = (EquipmentBreakdownBuildingOrContentsPremium + EquipmentBreakdownBusinessIncomePremium) * (1 + PollutantCleanUpLimitFactor + RefrigerantContaminationLimitFactor)
        //// /// (Step 13 + Step 14) * (1+Step 7 + Step 8)
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <param name="premium1">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsPremium1Valid(RaterFacadeModel model, out decimal premium1)
        //// {
        ////     premium1 = (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownBuildingOrContentsPremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownBusinessIncomePremium) * (1 + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PollutantCleanUpLimitFactor + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.RefrigerantContaminationLimitFactor);
        ////     if (!(model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageDeductible != 0 && model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageMinimumDeductible != 0))
        ////     {
        ////         if (premium1 == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Premium1)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }

        //// }

        //// /// <summary>
        //// /// check EquipmentBreakdownLimit is valid 
        //// /// equipmentBreakdownLimit = BusinessIncomeAndExtraExpenseLimit + TotalTIV;
        //// /// Step 1 + Step 3
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="equipmentBreakdownLimit"></param>
        //// /// <returns>bool Value</returns>
        //// public bool IsEquipmentBreakdownLimitValid(RaterFacadeModel model, out decimal equipmentBreakdownLimit)
        //// {

        ////     equipmentBreakdownLimit = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
        ////     {
        ////         equipmentBreakdownLimit = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TotalTIV;
        ////         if (equipmentBreakdownLimit == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownLimit)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }

        //// }

        //// /// <summary>
        //// /// Check EquipmentBreakdownRate is Valid
        //// /// EquipmentBreakdownRate = (EquipmentBreakdownTotalPremium * 100) / (EquipmentBreakdownDeductibleFactor * EquipmentBreakdownLimit)
        //// /// (Step C.1 *100)/(Step 5 * Step C.2)
        //// /// </summary>
        //// /// <param name="model">PropertyOutputModel</param>
        //// /// <param name="equipmentBreakdownLimit">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsEquipmentBreakdownRateValid(RaterFacadeModel model, out decimal equipmentBreakdownRate)
        //// {
        ////     equipmentBreakdownRate = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownDeductibleFactor != 0 && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownLimit != 0)
        ////     {
        ////         equipmentBreakdownRate = Math.Round((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium * 100) / (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownDeductibleFactor * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownLimit), MidpointRounding.AwayFromZero);
        ////         if (equipmentBreakdownRate == model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownRate)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// #endregion

        //// #region WindFloodEarthquakePrem
        //// /// <summary>
        //// ///Check PerilBuildingPoints is Valid
        //// ///Peril Building Points = Step 17 + Step 18 + Step 19
        //// ///perilBuildingPoints = WindBuildingPoints + FloodBuildingPoints + EarthquakeBuildingPoints;
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="perilBuildingPoints">decimal</param>
        //// /// <returns>bool Value</returns>
        //// //public bool IsPerilBuildingPointsValid(RaterFacadeModel model, out decimal perilBuildingPoints)
        //// //{

        //// //    perilBuildingPoints = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindBuildingPoints + model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodBuildingPoints + model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeBuildingPoints;
        //// //    if (perilBuildingPoints == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilBuildingPoints)
        //// //    {

        //// //        return true;
        //// //    }
        //// //    else
        //// //    {
        //// //        return false;
        //// //    }
        //// //}

        //// /// <summary>
        //// /// Check BuildingDefPointsNoPerils is valid
        //// /// Def Pts No Perils = Step 20 - Step 21
        //// ///  buildingDefPointsNoPerils = BuildingDefPoints - PerilBuildingPoints;
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="buildingDefPointsNoPerils">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsBuildingDefPointsNoPerilsValid(RaterFacadeModel model, out decimal buildingDefPointsNoPerils)
        //// {
        ////     buildingDefPointsNoPerils = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingDefTotalPoints - model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilBuildingPoints;
        ////     if (buildingDefPointsNoPerils == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingDefPointsNoPerils)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }

        //// }

        //// /// <summary>
        //// /// Check ContentsDefTotalPointsNoPerils is Valid
        //// /// ContentsDefTotalPointsNoPerils (ContentsDefTotalPoints - PerilContentsPoints)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="ContentsDefTotalPointsNoPerils">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsContentsDefTotalPointsNoPerilsValid(RaterFacadeModel model, out decimal ContentsDefTotalPointsNoPerils)
        //// {

        ////     ContentsDefTotalPointsNoPerils = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsDefTotalPoints - model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilContentsPoints;
        ////     if (ContentsDefTotalPointsNoPerils == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsDefTotalPointsNoPerils)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;

        ////     }
        //// }

        //// /// <summary>
        //// ///  Check BuildingModifiedMLRNoPerils is Valid
        //// ///  Step A - Steps to calculate Wind/Flood/Earthquake Building Premium
        //// ///  Step A.1 ((Step 1 + Step 24)* Step 5 * Step 6 * Step 7 * Step 8) : BuildingModifiedMLRNoPerils ((BuildingBaseMLR + BuildingAddtlChargeRateNoPerils) * AOPDeductibleFacto * CoinsuranceFactor * MarginClauseFactor * ValuationFactor)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="buildingModifiedMLRNoPerils">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsBuildingModifiedMLRNoPerilsValid(RaterFacadeModel model, out decimal buildingModifiedMLRNoPerils)
        //// {
        ////     buildingModifiedMLRNoPerils = Math.Round((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBaseMLR + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingAddtlChargeRateNoPerils) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.AOPDeductibleFactor
        ////                                                                       * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.CoinsuranceFactor * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.MarginClauseFactor * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ValuationFactor, 3, MidpointRounding.AwayFromZero);
        ////     if (buildingModifiedMLRNoPerils == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingModifiedMLRNoPerils)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check BuildingCombinedRateNoPerils is Valid
        //// ///  Step A.2 (Step 14 + Step A.1) : BuildingCombinedRateNoPerils (ModifiedNormalLossRate + BuildingModifiedMLRNoPerils)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="buildingModifiedMLRNoPerils">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsBuildingCombinedRateNoPerilsValid(RaterFacadeModel model, out decimal buildingCombinedRateNoPerils)
        //// {

        ////     buildingCombinedRateNoPerils = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedNormalLossRate + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingModifiedMLRNoPerils;
        ////     if (buildingCombinedRateNoPerils == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingCombinedRateNoPerils)
        ////     {
        ////         return true;

        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check BuildingPremiumNoPerils is Valid
        //// /// Step A.3 ((Step A.2 * Step 22)/100) : BuildingPremiumNoPerils ((BuildingCombinedRateNoPerils * BuildingTIV) / 100)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="buildingCombinedRateNoPerils">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsBuildingPremiumNoPerilsValid(RaterFacadeModel model, out decimal buildingPremiumNoPerils)
        //// {

        ////     buildingPremiumNoPerils = Math.Round((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingCombinedRateNoPerils * model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV) / 100, 2, MidpointRounding.AwayFromZero);
        ////     if (buildingPremiumNoPerils == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumNoPerils)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check BuildingPremiumTotal is Valid
        //// /// // Step A.4 ((Step 22 * Step 15)/100) : BuildingPremiumTotal ((BuildingValue * BuildingFinalRate) / 100)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="buildingPremiumTotal">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsBuildingPremiumTotalValid(RaterFacadeModel model, out decimal buildingPremiumTotal)
        //// {
        ////     buildingPremiumTotal = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingFinalRate) / 100, 2, MidpointRounding.AwayFromZero);
        ////     if (buildingPremiumTotal == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumTotal)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check BuildingPremiumForPerils is Valid
        //// /// Step A.5 (Step A.4 - Step A.3) : BuildingPremiumForPerils (BuildingPremiumTotal - BuildingPremiumNoPerils)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="buildingPremiumForPerils">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsBuildingPremiumForPerilsValid(RaterFacadeModel model, out decimal buildingPremiumForPerils)
        //// {
        ////     buildingPremiumForPerils = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumTotal - model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumNoPerils, 2, MidpointRounding.AwayFromZero);
        ////     if (buildingPremiumForPerils == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumForPerils)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check ContentsModifiedMLRNoPerils is Valid
        //// /// // Step B -Steps to calculate Wind / Flood / Earthquake Content Premium
        //// /// // Step B.1 ((Step 3 + Step 32)* Step 5 * Step 6 * Step 7 * Step 8) :
        //// /// // ContentsModifiedMLRNoPerils ((ContentsBaseMLR + ContentsAddtlChargeRateNoPerils) * AOPDeductibleFactor * CoinsuranceFactor * MarginClauseFactor * ValuationFactor)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="contentsModifiedMLRNoPerils">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsContentsModifiedMLRNoPerilsValid(RaterFacadeModel model, out decimal contentsModifiedMLRNoPerils)
        //// {

        ////     contentsModifiedMLRNoPerils = Math.Round((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsBaseMLR + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsAddtlChargeRateNoPerils) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.AOPDeductibleFactor
        ////                                                              * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.CoinsuranceFactor * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.MarginClauseFactor * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ValuationFactor, 3, MidpointRounding.AwayFromZero);
        ////     if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsModifiedMLRNoPerils == contentsModifiedMLRNoPerils)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check contentsCombinedRateNoPerils is Valid
        //// ///  // Step B.2 (Step 14 + Step B.1) : ContentsCombinedRateNoPerils (ModifiedNormalLossRate + ContentsModifiedMLRNoPerils)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="contentsCombinedRateNoPerils">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsContentsCombinedRateNoPerilsValid(RaterFacadeModel model, out decimal contentsCombinedRateNoPerils)
        //// {
        ////     contentsCombinedRateNoPerils = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedNormalLossRate + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsModifiedMLRNoPerils;
        ////     if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsCombinedRateNoPerils == contentsCombinedRateNoPerils)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check ContentsPremiumNoPerils is Valid
        //// ///  Step B.3 ((Step B.2 * Step 30)/100) : ContentsPremiumNoPerils ((ContentsCombinedRateNoPerils * ContentsValue) / 100)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="contentsPremiumTotal">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsContentsPremiumNoPerilsValid(RaterFacadeModel model, out decimal contentsPremiumNoPerils)
        //// {

        ////     contentsPremiumNoPerils = Math.Round((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsCombinedRateNoPerils * model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV) / 100, 2, MidpointRounding.AwayFromZero);
        ////     if (contentsPremiumNoPerils == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumNoPerils)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check ContentsPremiumTotal is Valid
        //// /// // Step B.4 ((Step 30 * Step 16)/100) : ContentsPremiumTotal ((ContentsValue * ContentsFinalRate) / 100)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="contentsPremiumTotal">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsContentsPremiumTotalValid(RaterFacadeModel model, out decimal contentsPremiumTotal)
        //// {

        ////     contentsPremiumTotal = (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsFinalRate) / 100;
        ////     contentsPremiumTotal = Math.Round(contentsPremiumTotal, 2, MidpointRounding.AwayFromZero);
        ////     if (contentsPremiumTotal == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumTotal)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {

        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// check ContentsPremiumForPerils Valid
        //// /// // Step B.5 (Step B.4 - Step B.3) : ContentsPremiumForPerils (ContentsPremiumTotal - ContentsPremiumNoPerils)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="contentsPremiumTotal">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsContentsPremiumForPerilsValid(RaterFacadeModel model, out decimal contentsPremiumForPerils)
        //// {
        ////     contentsPremiumForPerils = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumTotal - model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumNoPerils, 2, MidpointRounding.AwayFromZero);
        ////     if (contentsPremiumForPerils == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumForPerils)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }

        //// }


        //// /// <summary>
        //// ///  Step C.1 ((Step 17/Step 21)*Step A.5) : WindBuildingPremium ((WindBuildingPoints / PerilBuildingPoints) * BuildingPremiumForPerils)
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="windBuildingPremium"></param>
        //// /// <returns>bool Value</returns>
        //////TODO
        //// //public bool IsWindBuildingPremiumValid(RaterFacadeModel model, out decimal windBuildingPremium)
        //// //{

        //// //    windBuildingPremium = 0;
        //// //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilBuildingPoints != 0)
        //// //    {
        //// //        windBuildingPremium = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindBuildingPoints / model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilBuildingPoints) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumForPerils, MidpointRounding.AwayFromZero);
        //// //        if (windBuildingPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindBuildingPremium)
        //// //        {
        //// //            return true;
        //// //        }
        //// //        else
        //// //        {
        //// //            return false;
        //// //        }
        //// //    }
        //// //    else
        //// //    {
        //// //        return true;
        //// //    }


        //// //}

        //// /// <summary>
        //// /// Check WindContentPremium is valid
        //// /// Step C.2 ((Step 25/Step 29)*Step B.5) : WindContentPremium ((WindContentsPoints / PerilContentsPoints) * ContentsPremiumForPerils)
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="windBuildingPremium"></param>
        //// /// <returns>bool Value</returns>
        //// /// 
        //// //TODO
        //// //public bool IsWindContentPremiumValid(RaterFacadeModel model, out decimal windContentPremium)
        //// //{

        //// //    windContentPremium = 0;

        //// //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilContentsPoints != 0)
        //// //    {
        //// //        windContentPremium = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindContentsPoints / model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilContentsPoints) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumForPerils, MidpointRounding.AwayFromZero);
        //// //        if (windContentPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindContentPremium)
        //// //        {
        //// //            return true;
        //// //        }
        //// //        else
        //// //        {
        //// //            return false;
        //// //        }

        //// //    }
        //// //    else
        //// //    {

        //// //        return true;
        //// //    }

        //// //}

        //// /// <summary>
        //// /// Check WindTotalPremium is Valid
        //// /// Step C.3 (Step C.1 + Step C.2) : WINDTOTALPREMIUM (WindBuildingPremium + WindContentPremium)
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="windTotalPremium"></param>
        //// /// <returns>bool Value</returns>
        //// //TODO
        //// //public bool IsWindTotalPremiumValid(RaterFacadeModel model, out decimal windTotalPremium)
        //// //{

        //// //    windTotalPremium = Math.Round((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindBuildingPremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindContentPremium), MidpointRounding.AwayFromZero);
        //// //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == true)
        //// //    {
        //// //        if (windTotalPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.WindTotalPremium)
        //// //        {
        //// //            return true;
        //// //        }
        //// //        else
        //// //        {
        //// //            return false;
        //// //        }
        //// //    }
        //// //    else
        //// //    {
        //// //        return true;
        //// //    }

        //// //}

        //// /// <summary>
        //// ///  // Step D.1 ((Step 18/Step 21)*Step A.5) : FloodBuildingPremium ((FloodBuildingPoints / PerilBuildingPoints) * BuildingPremiumForPerils)
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="floodBuildingPremium"></param>
        //// /// <returns>bool Value</returns>
        //// //TODO
        //// //public bool IsFloodBuildingPremiumValid(RaterFacadeModel model, out decimal floodBuildingPremium)
        //// //{

        //// //    floodBuildingPremium = 0;
        //// //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilBuildingPoints != 0)
        //// //    {
        //// //        floodBuildingPremium = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodBuildingPoints / model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilBuildingPoints) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumForPerils, MidpointRounding.AwayFromZero);
        //// //        if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodBuildingPremium == floodBuildingPremium)
        //// //        {
        //// //            return true;
        //// //        }
        //// //        else
        //// //        {
        //// //            return false;
        //// //        }
        //// //    }
        //// //    else
        //// //    {

        //// //        return true;
        //// //    }

        //// //}

        //// /// <summary>
        //// /// Step D.2 ((Step 26/Step 29)*Step B.5) : FloodContentPremium ((FloodContentPremium / PerilContentsPoints) * ContentsPremiumForPerils)
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="floodContentPremium"></param>
        //// /// <returns>bool Value</returns>
        //////TODO
        //// //public bool IsFloodContentPremiumValid(RaterFacadeModel model, out decimal floodContentPremium)
        //// //{

        //// //    floodContentPremium = 0;
        //// //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilContentsPoints != 0)
        //// //    {

        //// //        floodContentPremium = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodContentsPoint / model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilContentsPoints) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumForPerils, MidpointRounding.AwayFromZero);
        //// //        if (floodContentPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodContentPremium)
        //// //        {
        //// //            return true;
        //// //        }
        //// //        else
        //// //        {
        //// //            return false;
        //// //        }
        //// //    }
        //// //    else
        //// //    {
        //// //        return true;
        //// //    }

        //// //}

        //// /// <summary>
        //// ///  // Step D.3 (Step D.1 + Step D.2) : FLOODTOTALPREMIUM (FloodBuildingPremium + FloodTotalPremium)
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="FloodTotalPremium"></param>
        //// /// <returns>bool Value</returns>
        //// public bool IsFloodTotalPremiumValid(RaterFacadeModel model, out decimal FloodTotalPremium)
        //// {

        ////     FloodTotalPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == true)
        ////     {
        ////         FloodTotalPremium = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodBuildingPremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodContentPremium, MidpointRounding.AwayFromZero);
        ////         if (FloodTotalPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FloodTotalPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }
        //// // Step E -EARTHQUAKE PREMIUM CALCULATION
        //// // Execute Step E only when Included radio button is selected for Earthquake Coverage

        //// /// <summary>
        //// /// Check earthquakeBuildingPremium is Valid
        //// /// Step E.1 ((Step 19/Step 21)*Step A.5) : EarthquakeBuildingPremium ((EarthquakeBuildingPoints / PerilBuildingPoints) * BuildingPremiumForPerils)
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="floodContentPremium"></param>
        //// /// <returns>bool Value</returns>
        //////TODO
        //// //public bool IsEarthquakeBuildingPremiumValid(RaterFacadeModel model, out decimal earthquakeBuildingPremium)
        //// //{

        //// //    earthquakeBuildingPremium = 0;
        //// //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilBuildingPoints != 0)
        //// //    {
        //// //        earthquakeBuildingPremium = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeBuildingPoints / model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilBuildingPoints) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingPremiumForPerils, MidpointRounding.AwayFromZero);
        //// //        if (earthquakeBuildingPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeBuildingPremium)
        //// //        {
        //// //            return true;
        //// //        }
        //// //        else
        //// //        {
        //// //            return false;
        //// //        }
        //// //    }
        //// //    else
        //// //    {
        //// //        return true;
        //// //    }
        //// //}

        //// /// <summary>
        //// /// Step E.2 ((Step 27/Step 29)*Step B.5) : EarthquakeContentPremium ((EarthquakeContentsPoints / PerilContentsPoints) * ContentsPremiumForPerils)
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="EarthquakeContentPremium"></param>
        //// /// <returns>bool Value</returns>
        //////TODO
        //// //public bool IsEarthquakeContentPremiumValid(RaterFacadeModel model, out decimal earthquakeContentPremium)
        //// //{

        //// //    earthquakeContentPremium = 0;
        //// //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == true && model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilContentsPoints != 0)
        //// //    {
        //// //        earthquakeContentPremium = Math.Round((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeContentsPoints / model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.PerilContentsPoints) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ContentsPremiumForPerils, MidpointRounding.AwayFromZero);

        //// //        if (earthquakeContentPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeContentPremium)
        //// //        {

        //// //            return true;
        //// //        }
        //// //        else
        //// //        {
        //// //            return false;
        //// //        }
        //// //    }
        //// //    else
        //// //    {
        //// //        return true;
        //// //    }

        //// //}

        //// /// <summary>
        //// /// Step E.3 (Step E.1 + Step E.2) : EARTHQUAKETOTALPREMIUM (EarthquakeBuildingPremium + EarthquakeContentPremium)
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="earthquakeTotalPremium"></param>
        //// /// <returns>bool Value</returns>
        //// //// 
        //// public bool IsEarthquakeTotalPremiumValid(RaterFacadeModel model, out decimal earthquakeTotalPremium)
        //// {
        ////     earthquakeTotalPremium = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeBuildingPremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeContentPremium, MidpointRounding.AwayFromZero);
        ////     if (earthquakeTotalPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EarthquakeTotalPremium)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }

        //// }
        //// #endregion

        //// //#region Optional Coverage
        //// ///// <summary>
        //// ///// 
        //// ///// </summary>
        //// ///// <param name="model"></param>
        //// ///// <returns>bool Value</returns>
        //// //public bool IsOptionalCoverageValid(RaterFacadeModel model)
        //// //{

        //// //    foreach (var optionalCoverage in model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoverages)
        //// //    {

        //// //        // Step 3 ((Step 1 /1000) * Step 2) OtherPremium : (OtherLimit / 1000) * OtherRate
        //// //        if (optionalCoverage.OptionalCoverage.ToUpper() == "OTHER" && optionalCoverage.RatingBasis.ToUpper() == "PER 1,000 OF LIMIT")
        //// //        {
        //// //            decimal Premium = Math.Round((optionalCoverage.Limit / 1000) * optionalCoverage.Rate,MidpointRounding.AwayFromZero);
        //// //            if (optionalCoverage.Premium == Premium)
        //// //            {
        //// //                return true;
        //// //            }
        //// //            else
        //// //            {
        //// //                return false;
        //// //            }
        //// //        }

        //// //        // Step 3 ((Step 1 /1000) * Step 2) OtherPremium : (OtherLimit / 100) * OtherRate
        //// //        else if (optionalCoverage.OptionalCoverage.ToUpper() == "OTHER" && optionalCoverage.RatingBasis.ToUpper() == "PER 100 OF LIMIT")
        //// //        {
        //// //            decimal premium = Math.Round((optionalCoverage.Limit / 100) * optionalCoverage.Rate,MidpointRounding.AwayFromZero);
        //// //            if (premium == optionalCoverage.Premium)
        //// //            {
        //// //                return true;
        //// //            }
        //// //            else
        //// //            {
        //// //                return false;
        //// //            }
        //// //        }

        //// //    }
        //// //    return true;

        //// //}
        //// //#endregion

        //// #region Final Property

        //// /// <summary>
        //// /// Check equipmentBreakdown is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="equipmentBreakdown">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsEquipmentBreakdowmValid(RaterFacadeModel model, out decimal equipmentBreakdown)
        //// {

        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == true)
        ////     {
        ////         equipmentBreakdown = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownRate;
        ////         if (equipmentBreakdown == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         equipmentBreakdown = model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium;
        ////         if (equipmentBreakdown == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        //// }
        //// public bool IsProRatafactorValid(RaterFacadeModel model, out decimal proRatafactor)
        //// {
        ////     proRatafactor = 0;
        ////     if ((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).TotalDays != 0)
        ////     {
        ////         proRatafactor = Math.Round(Convert.ToDecimal((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate).TotalDays / (model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).TotalDays), 2, MidpointRounding.AwayFromZero);
        ////         if (proRatafactor == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check BasePremiumCalculation is Valid
        //// ///  Step A- Base Premium Calculation. 
        //// /// BasePremiumCalculation : ((BuildingAndContents + EquipmentBreakdown) * ProRatafactor)
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="basePremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsBasePremiumValid(RaterFacadeModel model, out decimal basePremium)
        //// {

        ////     basePremium = Math.Round((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor, MidpointRounding.AwayFromZero);
        ////     if (basePremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BasePremium)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {

        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check NonModifiedPremiumCalculation is Valid
        //// /// Step B.1- Non-Modified Premium Calculation 
        //// /// Step B.2 (B.1 * ProRatafactor) 
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="nonModifiedPremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsNonModifiedPremium(RaterFacadeModel model, out decimal nonModifiedPremium)
        //// {
        ////     nonModifiedPremium = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OptionalCoverageTotalPremium * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor, MidpointRounding.AwayFromZero);
        ////     if (nonModifiedPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check manualPremium is Valid
        //// /// Step B.1- Non-Modified Premium Calculation 
        //// /// NonModifiedPremiumCalculation : OptionalCoverageTotalPremium
        //// /// //Step B.2 (B.1 * ProRatafactor) 
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="manualPremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsManualPremiumValid(RaterFacadeModel model, out decimal manualPremium)
        //// {
        ////     manualPremium = Math.Round((((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BuildingBPPPremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.BusinessIncomeAndExtraExpense360CoveragePremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360TotalPremiums) * model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LargeRiskFactor)
        ////                                                                          * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.EquipmentBreakdownTotalPremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor, MidpointRounding.AwayFromZero);
        ////     if (manualPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium)
        ////     {
        ////         if (manualPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////         {
        ////             if (manualPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////             {
        ////                 return true;
        ////             }
        ////             else
        ////             {
        ////                 return false;
        ////             }
        ////         }
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }


        //// /// <summary>
        //// /// Check TierPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="tierPremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// // TierPremiumCalculation : ((ManualPremiumCalculation - NonModifiedPremiumCalculation) * TierFactor) + NonModifiedPremiumCalculation
        //// public bool IsTierPremiumValid(RaterFacadeModel model, out decimal tierPremium)
        //// {

        ////     tierPremium = Math.Round(((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ManualPremium - model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierFactor) + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, MidpointRounding.AwayFromZero);
        ////     if (tierPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium)
        ////     {
        ////         if (tierPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium)
        ////         {
        ////             if (tierPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////             {
        ////                 if (tierPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////                 {
        ////                     return true;
        ////                 }
        ////                 else
        ////                 {
        ////                     return false;
        ////                 }
        ////             }
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }

        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check IRPMPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="iRPMPremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsIRPMPremiumValid(RaterFacadeModel model, out decimal iRPMPremium)
        //// {
        ////     iRPMPremium = Math.Round(((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TierPremium - model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium) * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMFactor) + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, MidpointRounding.AwayFromZero);

        ////     if (iRPMPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium)
        ////     {
        ////         if (iRPMPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////         {
        ////             if (iRPMPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////             {
        ////                 return true;
        ////             }
        ////             else
        ////             {
        ////                 return false;
        ////             }
        ////         }
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check OtherModPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="otherModPremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsOtherModPremiumValid(RaterFacadeModel model, out decimal otherModPremium)
        //// {
        ////     otherModPremium = Math.Round(((model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.IRPMPremium - model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium) * model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OtherModFactor) + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.NonModifiedPremium, MidpointRounding.AwayFromZero);

        ////     if (otherModPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium)
        ////     {
        ////         if (otherModPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////         {
        ////             if (otherModPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////             {
        ////                 return true;
        ////             }
        ////             else
        ////             {
        ////                 return false;
        ////             }
        ////         }
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check TerrorismPremium is Valid
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="terrorismPremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsTerrorismPremiumValid(RaterFacadeModel model, out decimal terrorismPremium)
        //// {
        ////     terrorismPremium = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TerrorismFactor, MidpointRounding.AwayFromZero);

        ////     if (terrorismPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TerrorismPremium)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check ModifiedPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="modifiedPremium">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsModifiedPremiumValid(RaterFacadeModel model, out decimal modifiedPremium)
        //// {
        ////     modifiedPremium = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TerrorismPremium, MidpointRounding.AwayFromZero);

        ////     if (modifiedPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ModifiedPremium)
        ////     {
        ////         if (modifiedPremium < model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////         {
        ////             if (modifiedPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.LOBMinimumPremium)
        ////             {
        ////                 return true;
        ////             }
        ////             else
        ////             {
        ////                 return false;
        ////             }
        ////         }
        ////         return true;
        ////     }
        ////     else
        ////     {
        ////         return false;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check FireSafetySurcharge is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="fireSafetySurcharge">decimal</param>
        //// /// <returns>bool value</returns>
        //// public bool IsFireSafetySurchargeValid(RaterFacadeModel model, out decimal fireSafetySurcharge)
        //// {

        ////     fireSafetySurcharge = 0;
        ////     if ((model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == AppConstants.MN && (model.RaterInputFacadeModel.PolicyHeaderModelpolicyHeader.TransactionType.ToUpper() == AppConstants.NEWBUSINESS || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == AppConstants.RENEWAL)
        ////             || (model.RaterInputFacadeModel.PolicyHeaderModelpolicyHeader.TransactionType.ToUpper() == AppConstants.NEWBUSINESS || model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == AppConstants.RENEWAL && model.RaterInputFacadeModel.PolicyHeaderModel.TransactionType.ToUpper() == AppConstants.ENDORSEMENT)))//todo
        ////     {
        ////         fireSafetySurcharge = Math.Round(model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.OtherModPremium * model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FireSafetySurchargeRate, 2, MidpointRounding.AwayFromZero);
        ////         if (fireSafetySurcharge == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.FireSafetySurcharge)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {

        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }


        //// #endregion

        //// #region 360 Coverage
        //// /// <summary>
        //// /// Step 1 - Business Income & Extra Expense (BI & EE)
        //// /// Check is  businessIncomeAndExtraExpensePremium Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="businessIncomeAndExtraExpensePremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsBusinessIncomeAndExtraExpensePremiumValid(RaterFacadeModel model, out decimal businessIncomeAndExtraExpensePremium)
        //// {
        ////     businessIncomeAndExtraExpensePremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.BusinessIncomeAndExtraExpenseRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.BusinessIncomeAndExtraExpensePremium == businessIncomeAndExtraExpensePremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check dependentPropertyPremium is Valid
        //// /// Step 2 - Dependent Property Business Income
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="dependentPropertyPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsDependentPropertyPremiumValid(RaterFacadeModel model, out decimal dependentPropertyPremium)
        //// {
        ////     dependentPropertyPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.DependentPropertyRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.DependentPropertyPremium == dependentPropertyPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 3 - Interruption of Computer Operations
        //// /// Check InterruptionOfComputerOperationsPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="interruptionOfComputerOperationsPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsInterruptionOfComputerOperationsPremiumValid(RaterFacadeModel model, out decimal interruptionOfComputerOperationsPremium)
        //// {
        ////     interruptionOfComputerOperationsPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.InterruptionOfComputerOperationsRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.InterruptionOfComputerOperationsPremium == interruptionOfComputerOperationsPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 4 - Lease Cancellation Moving Expenses
        //// /// Check LeaseCancellationMovingExpensesPremium
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="leaseCancellationMovingExpensesPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsLeaseCancellationMovingExpensesPremiumValid(RaterFacadeModel model, out decimal leaseCancellationMovingExpensesPremium)
        //// {
        ////     leaseCancellationMovingExpensesPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.LeaseCancellationMovingExpensesRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.LeaseCancellationMovingExpensesPremium == leaseCancellationMovingExpensesPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 5 - Newly Acquired or Constructed Property  – Business Income
        //// /// Check  NewlyAcquiredOrConstructedPropertyPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="newlyAcquiredOrConstructedPropertyPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsNewlyAcquiredOrConstructedPropertyPremiumValid(RaterFacadeModel model, out decimal newlyAcquiredOrConstructedPropertyPremium)
        //// {
        ////     newlyAcquiredOrConstructedPropertyPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NewlyAcquiredOrConstructedPropertyRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NewlyAcquiredOrConstructedPropertyPremium == newlyAcquiredOrConstructedPropertyPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Off Premises Utility Failure - Business Income and Extra Expense
        //// ///  Check offPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="offPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremiumValid(RaterFacadeModel model, out decimal offPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium)
        //// {
        ////     offPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium == offPremisesUtilityFailureBusinessIncomeAndExtraExpensePremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// ///-----

        //// /// <summary>
        //// /// Step 7.1 Ordinance or Law - Coverage B
        //// /// Check ordinanceOrLawCoverageBPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="ordinanceOrLawCoverageBPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsOrdinanceOrLawCoverageBPremiumValid(RaterFacadeModel model, out decimal ordinanceOrLawCoverageBPremium)
        //// {

        ////     ordinanceOrLawCoverageBPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OrdinanceOrLawCoverageBRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OrdinanceOrLawCoverageBPremium == ordinanceOrLawCoverageBPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 7.2 Ordinance or Law - Coverage C
        //// ///Check ordinanceOrLawCoverageCPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="ordinanceOrLawCoverageCPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsOrdinanceOrLawCoverageCPremiumValid(RaterFacadeModel model, out decimal ordinanceOrLawCoverageCPremium)
        //// {

        ////     ordinanceOrLawCoverageCPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OrdinanceOrLawCoverageCRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OrdinanceOrLawCoverageCPremium == ordinanceOrLawCoverageCPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 8 - Accounts Receivable Records
        //// ///  Check accountsReceivableRecordsPremium is valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="accountsReceivableRecordsPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsAccountsReceivableRecordsPremiumValid(RaterFacadeModel model, out decimal accountsReceivableRecordsPremium)
        //// {

        ////     accountsReceivableRecordsPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.AccountsReceivableRecordsRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.AccountsReceivableRecordsPremium == accountsReceivableRecordsPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 9 -  Appurtenant Structures
        //// /// check appurtenantStructuresPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="appurtenantStructuresPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsAppurtenantStructuresPremiumValid(RaterFacadeModel model, out decimal appurtenantStructuresPremium)
        //// {

        ////     appurtenantStructuresPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.AppurtenantStructuresRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.AppurtenantStructuresPremium == appurtenantStructuresPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 10 -  Audio Visual and Communication Equipment
        //// /// Check  audioVisualAndCommunicationEquipmentPremium is valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="audioVisualAndCommunicationEquipmentPremium"></param>
        //// /// <returns>bool Value</returns>
        //// public bool IsAudioVisualAndCommunicationEquipmentPremiumValid(RaterFacadeModel model, out decimal audioVisualAndCommunicationEquipmentPremium)
        //// {

        ////     audioVisualAndCommunicationEquipmentPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.AudioVisualAndCommunicationEquipmentRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.AudioVisualAndCommunicationEquipmentPremium == audioVisualAndCommunicationEquipmentPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }


        //// /// <summary>
        //// /// Step 11 - Changes in Temperature or Humidity
        //// /// Check audioVisualAndCommunicationEquipmentPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="audioVisualAndCommunicationEquipmentPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsChangesInTemperatureOrHumidityPremiumValid(RaterFacadeModel model, out decimal changesInTemperatureOrHumidityPremium)
        //// {

        ////     changesInTemperatureOrHumidityPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ChangesInTemperatureOrHumidityRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ChangesInTemperatureOrHumidityPremium == changesInTemperatureOrHumidityPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 12 - Commandeered Property
        //// ///  Check commandeeredPropertyPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="commandeeredPropertyPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsCommandeeredPropertyPremiumValid(RaterFacadeModel model, out decimal commandeeredPropertyPremium)
        //// {

        ////     commandeeredPropertyPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.CommandeeredPropertyRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.CommandeeredPropertyPremium == commandeeredPropertyPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 13 - Computer Equipment
        //// ///Check  commandeeredPropertyPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="commandeeredPropertyPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsComputerEquipmentPremiumValid(RaterFacadeModel model, out decimal computerEquipmentPremium)
        //// {

        ////     computerEquipmentPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ComputerEquipmentRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ComputerEquipmentPremium == computerEquipmentPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 14- Debris Removal - Your Premises.
        //// /// Check debrisRemovalYourPremisesPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="debrisRemovalYourPremisesPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsDebrisRemovalYourPremisesPremiumValid(RaterFacadeModel model, out decimal debrisRemovalYourPremisesPremium)
        //// {

        ////     debrisRemovalYourPremisesPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.DebrisRemovalYourPremisesRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.DebrisRemovalYourPremisesPremium == debrisRemovalYourPremisesPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 15 - Debris Removal -   Wind Blown Debris
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="debrisRemovalWindBlownDebrisPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsDebrisRemovalWindBlownDebrisPremiumValid(RaterFacadeModel model, out decimal debrisRemovalWindBlownDebrisPremium)
        //// {

        ////     debrisRemovalWindBlownDebrisPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.DebrisRemovalWindBlownDebrisRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.DebrisRemovalWindBlownDebrisPremium == debrisRemovalWindBlownDebrisPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 16 - Electronic Data
        //// /// Check ElectronicDataPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="electronicDataPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsElectronicDataPremiumValid(RaterFacadeModel model, out decimal electronicDataPremium)
        //// {

        ////     electronicDataPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ElectronicDataRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ElectronicDataPremium == electronicDataPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }


        //// /// <summary>
        //// /// Step 17 -Fine Arts
        //// /// Check is fineArtsPremium Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="fineArtsPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsFineArtsPremiumValid(RaterFacadeModel model, out decimal fineArtsPremium)
        //// {

        ////     fineArtsPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.FineArtsRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.FineArtsPremium == fineArtsPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 18 -Fire Department Service Charge
        //// /// Check  FireDepartmentServiceChargePremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="fireDepartmentServiceChargePremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsFireDepartmentServiceChargePremiumValid(RaterFacadeModel model, out decimal fireDepartmentServiceChargePremium)
        //// {
        ////     fireDepartmentServiceChargePremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.FireDepartmentServiceChargeRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.FireDepartmentServiceChargePremium == fireDepartmentServiceChargePremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 19 - Fungus, Wet Rot, Dry Rot and Bacteria
        //// /// Check fungusWetRotDryRotAndBacteriaPremium Is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="fungusWetRotDryRotAndBacteriaPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsFungusWetRotDryRotAndBacteriaPremiumValid(RaterFacadeModel model, out decimal fungusWetRotDryRotAndBacteriaPremium)
        //// {
        ////     fungusWetRotDryRotAndBacteriaPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.FungusWetRotDryRotAndBacteriaRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.FungusWetRotDryRotAndBacteriaPremium == fungusWetRotDryRotAndBacteriaPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 20 - Glass Display or Trophy Cases
        //// /// Check glassDisplayOrTrophyCasesPremium  is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="glassDisplayOrTrophyCasesPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsGlassDisplayOrTrophyCasesPremiumValid(RaterFacadeModel model, out decimal glassDisplayOrTrophyCasesPremium)
        //// {
        ////     glassDisplayOrTrophyCasesPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GlassDisplayOrTrophyCasesRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GlassDisplayOrTrophyCasesPremium == glassDisplayOrTrophyCasesPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 21 - Inventory and Appraisal
        //// /// Check inventoryAndAppraisalPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="inventoryAndAppraisalPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsInventoryAndAppraisalPremiumValid(RaterFacadeModel model, out decimal inventoryAndAppraisalPremium)
        //// {
        ////     inventoryAndAppraisalPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.InventoryAndAppraisalRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.InventoryAndAppraisalPremium == inventoryAndAppraisalPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 22 - Key/Card
        //// /// Check keyCardPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="keyCardPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsKeyCardPremiumValid(RaterFacadeModel model, out decimal keyCardPremium)
        //// {
        ////     keyCardPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.KeyCardRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.KeyCardPremium == keyCardPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 23 - Lock Replacement
        //// /// Check lockReplacementPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="lockReplacementPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsLockReplacementPremiumValid(RaterFacadeModel model, out decimal lockReplacementPremium)
        //// {
        ////     lockReplacementPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.LockReplacementRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.LockReplacementPremium == lockReplacementPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 24 - Money and Securities -On Your Premises
        //// /// Check MoneyAndSecuritiesOnYourPremisesPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="moneyAndSecuritiesOnYourPremisesPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsMoneyAndSecuritiesOnYourPremisesPremiumValid(RaterFacadeModel model, out decimal moneyAndSecuritiesOnYourPremisesPremium)
        //// {
        ////     moneyAndSecuritiesOnYourPremisesPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.MoneyAndSecuritiesOnYourPremisesRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium == moneyAndSecuritiesOnYourPremisesPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 25 - Money and Securities - Away From Your Premises
        //// ///  Check moneyAndSecuritiesAwayFromYourPremisesPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="moneyAndSecuritiesAwayFromYourPremisesPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsMoneyAndSecuritiesAwayFromYourPremisesPremiumValid(RaterFacadeModel model, out decimal moneyAndSecuritiesAwayFromYourPremisesPremium)
        //// {
        ////     moneyAndSecuritiesAwayFromYourPremisesPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium == moneyAndSecuritiesAwayFromYourPremisesPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 26 - Newly Acquired or Constructed Property -Buildings
        //// /// Check newlyAcquiredOrConstructedPropertyBuildingsPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="newlyAcquiredOrConstructedPropertyBuildingsPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsNewlyAcquiredOrConstructedPropertyBuildingsPremiumValid(RaterFacadeModel model, out decimal newlyAcquiredOrConstructedPropertyBuildingsPremium)
        //// {
        ////     newlyAcquiredOrConstructedPropertyBuildingsPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium == newlyAcquiredOrConstructedPropertyBuildingsPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }


        //// /// <summary>
        //// /// Step 27 - Newly Acquired or Constructed Property Your Business Personal Property
        //// /// Check newlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="newlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremiumValid(RaterFacadeModel model, out decimal newlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium)
        //// {
        ////     newlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium == newlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 28 - Non-owned Detached Trailers
        //// ///  Cehck nonOwnedDetachedTrailersPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="nonOwnedDetachedTrailersPremium"></param>
        //// /// <returns>bool Value</returns>
        //// public bool IsNonOwnedDetachedTrailersPremiumValid(RaterFacadeModel model, out decimal nonOwnedDetachedTrailersPremium)
        //// {
        ////     nonOwnedDetachedTrailersPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NonOwnedDetachedTrailersRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NonOwnedDetachedTrailersPremium == nonOwnedDetachedTrailersPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 29 - Off Premises Utility Failure - Damage to Covered Property
        //// /// Check offPremisesUtilityFailureDamageToCoveredPropertyPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="offPremisesUtilityFailureDamageToCoveredPropertyPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsOffPremisesUtilityFailureDamageToCoveredPropertyPremiumValid(RaterFacadeModel model, out decimal offPremisesUtilityFailureDamageToCoveredPropertyPremium)
        //// {
        ////     offPremisesUtilityFailureDamageToCoveredPropertyPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium == offPremisesUtilityFailureDamageToCoveredPropertyPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }


        //// /// <summary>
        //// ///  Step 30 - Outdoor Property
        //// ///  Check OutdoorPropertyPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="OutdoorPropertyPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsOutdoorPropertyPremiumValid(RaterFacadeModel model, out decimal outdoorPropertyPremium)
        //// {
        ////     outdoorPropertyPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OutdoorPropertyRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OutdoorPropertyPremium == outdoorPropertyPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 31 - Personal Effects and Property of Others
        //// /// Check personalEffectsAndPropertyOfOthersPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="personalEffectsAndPropertyOfOthersPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsPersonalEffectsAndPropertyOfOthersPremiumValid(RaterFacadeModel model, out decimal personalEffectsAndPropertyOfOthersPremium)
        //// {
        ////     personalEffectsAndPropertyOfOthersPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PersonalEffectsAndPropertyOfOthersRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium == personalEffectsAndPropertyOfOthersPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check personalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium is Valid
        //// /// Step 32 - Personal Effects and Property of Others - Any Employee or Volunteer
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="personalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremiumValid(RaterFacadeModel model, out decimal personalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium)
        //// {
        ////     personalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium == personalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }


        //// /// <summary>
        //// /// Check  pollutantCleanUpAndRemovalPremium is Valid
        //// /// Step 33 - Pollutant Clean Up and Removal
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="pollutantCleanUpAndRemovalPremium"></param>
        //// /// <returns>bool Value</returns>
        //// public bool IsPollutantCleanUpAndRemovalPremiumValid(RaterFacadeModel model, out decimal pollutantCleanUpAndRemovalPremium)
        //// {
        ////     pollutantCleanUpAndRemovalPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ModificationPollutantCleanUpAndRemovalRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PollutantCleanUpAndRemovalPremium == pollutantCleanUpAndRemovalPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check PropertyInTransitPremium is Valid
        //// /// Step 34 - Property In Transit
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="propertyInTransitPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsPropertyInTransitPremiumValid(RaterFacadeModel model, out decimal propertyInTransitPremium)
        //// {
        ////     propertyInTransitPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PropertyInTransitRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PropertyInTransitPremium == propertyInTransitPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check PropertyOffPremisesPremium is Valid
        //// /// Step 35 - Property Off-premises
        //// /// </summary>
        //// /// <param name="model"></param>
        //// /// <param name="propertyOffPremisesPremium"></param>
        //// /// <returns>bool Value</returns>
        //// public bool IsPropertyOffPremisesPremiumValid(RaterFacadeModel model, out decimal propertyOffPremisesPremium)
        //// {
        ////     propertyOffPremisesPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PropertyOffPremisesRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PropertyOffPremisesPremium == propertyOffPremisesPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// ///  Step 36 - Recharge of Fire Protection Equipment
        //// /// Check RechargeOfFireProtectionEquipmentPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="rechargeOfFireProtectionEquipmentPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsRechargeOfFireProtectionEquipmentPremiumValid(RaterFacadeModel model, out decimal rechargeOfFireProtectionEquipmentPremium)
        //// {
        ////     rechargeOfFireProtectionEquipmentPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.RechargeOfFireProtectionEquipmentRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.RechargeOfFireProtectionEquipmentPremium == rechargeOfFireProtectionEquipmentPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Step 37 - Retaining Walls
        //// /// Check RetainingWallsPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="retainingWallsPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsRetainingWallsPremiumValid(RaterFacadeModel model, out decimal retainingWallsPremium)
        //// {
        ////     retainingWallsPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.RetainingWallsRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.RetainingWallsPremium == retainingWallsPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check RewardPaymentsPremium is Valid
        //// /// Step 38 - Reward Payments
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="rewardPaymentsPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsRewardPaymentsPremiumValid(RaterFacadeModel model, out decimal rewardPaymentsPremium)
        //// {
        ////     rewardPaymentsPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.RewardPaymentsRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.RewardPaymentsPremium == rewardPaymentsPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check SalespersonsSamplesPremium is Valid
        //// /// Step 39 - Salesperson’s Samples
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="salespersonsSamplesPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsSalespersonsSamplesPremiumValid(RaterFacadeModel model, out decimal salespersonsSamplesPremium)
        //// {
        ////     salespersonsSamplesPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SalespersonsSamplesRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SalespersonsSamplesPremium == salespersonsSamplesPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check SCADAUpgradePremium is Valid
        //// /// Step 40 -SCADA Upgrade
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="sCADAUpgradePremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsSCADAUpgradePremiumValid(RaterFacadeModel model, out decimal sCADAUpgradePremium)
        //// {
        ////     sCADAUpgradePremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SCADAUpgradeRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SCADAUpgradePremium == sCADAUpgradePremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// //Step 41- Sod, Trees, Shrubs, and Plants - Any One
        //// /// <summary>
        //// /// Check  SodTreesShrubsAndPlantsAnyOnePremium is Valid
        //// /// </summary>
        //// /// <param name="model">decimal</param>
        //// /// <param name="sodTreesShrubsAndPlantsAnyOnePremium">RaterFacadeModel</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsSodTreesShrubsAndPlantsAnyOnePremiumValid(RaterFacadeModel model, out decimal sodTreesShrubsAndPlantsAnyOnePremium)
        //// {
        ////     sodTreesShrubsAndPlantsAnyOnePremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SodTreesShrubsAndPlantsAnyOneRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium == sodTreesShrubsAndPlantsAnyOnePremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check SodTreesShrubsAndPlantsOccurrencePremium is Valid
        //// ///  Step 42  Sod, Trees, Shrubs, and Plants -Occurrence
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="sodTreesShrubsAndPlantsOccurrencePremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsSodTreesShrubsAndPlantsOccurrencePremiumValid(RaterFacadeModel model, out decimal sodTreesShrubsAndPlantsOccurrencePremium)
        //// {
        ////     sodTreesShrubsAndPlantsOccurrencePremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SodTreesShrubsAndPlantsOccurrenceRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium == sodTreesShrubsAndPlantsOccurrencePremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check  SpoilagePremium is Valid
        //// ///  Step 43 - Spoilage
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="spoilagePremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsSpoilagePremiumValid(RaterFacadeModel model, out decimal spoilagePremium)
        //// {
        ////     spoilagePremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SpoilageRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SpoilagePremium == spoilagePremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }


        //// /// <summary>
        //// /// Check TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium is Valid
        //// /// Step 44 - Theft of Jewelry, Furs, Stamps, and Other Specified Items – Occurrence Limit
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="theftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremiumValid(RaterFacadeModel model, out decimal theftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium)
        //// {
        ////     theftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium == theftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check UndamagedLeaseholdImprovementsPremium is Valid
        //// /// Step 45 - Undamaged Leasehold Improvements
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="undamagedLeaseholdImprovementsPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsUndamagedLeaseholdImprovementsPremiumValid(RaterFacadeModel model, out decimal undamagedLeaseholdImprovementsPremium)
        //// {
        ////     undamagedLeaseholdImprovementsPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.UndamagedLeaseholdImprovementsRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.UndamagedLeaseholdImprovementsPremium == undamagedLeaseholdImprovementsPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }


        //// /// <summary>
        //// /// Check ValuablePapersAndRecordsOtherThanElectronicDataPremium is Valid
        //// /// Step 46 - Valuable Papers and Records Other than Electronic Data
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="valuablePapersAndRecordsOtherThanElectronicDataPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsValuablePapersAndRecordsOtherThanElectronicDataPremiumValid(RaterFacadeModel model, out decimal valuablePapersAndRecordsOtherThanElectronicDataPremium)
        //// {
        ////     valuablePapersAndRecordsOtherThanElectronicDataPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium == valuablePapersAndRecordsOtherThanElectronicDataPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check Property360ModificationCoverageTotalPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="property360ModificationCoverageTotalPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsProperty360ModificationCoverageTotalPremiumValid(RaterFacadeModel model, out decimal property360ModificationCoverageTotalPremium)
        //// {

        ////     property360ModificationCoverageTotalPremium = (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OrdinanceOrLawCoverageBPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OrdinanceOrLawCoverageCPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.AccountsReceivableRecordsPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.AppurtenantStructuresPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.AudioVisualAndCommunicationEquipmentPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ChangesInTemperatureOrHumidityPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.CommandeeredPropertyPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ComputerEquipmentPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.DebrisRemovalYourPremisesPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.DebrisRemovalWindBlownDebrisPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ElectronicDataPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.FineArtsPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.FireDepartmentServiceChargePremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.FungusWetRotDryRotAndBacteriaPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GlassDisplayOrTrophyCasesPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.KeyCardPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.LockReplacementPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.MoneyAndSecuritiesOnYourPremisesPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.MoneyAndSecuritiesAwayFromYourPremisesPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NewlyAcquiredOrConstructedPropertyBuildingsPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.NonOwnedDetachedTrailersPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OffPremisesUtilityFailureDamageToCoveredPropertyPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.OutdoorPropertyPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PersonalEffectsAndPropertyOfOthersPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PollutantCleanUpAndRemovalPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PropertyInTransitPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.PropertyOffPremisesPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.RechargeOfFireProtectionEquipmentPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.RetainingWallsPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.RewardPaymentsPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SalespersonsSamplesPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SCADAUpgradePremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SodTreesShrubsAndPlantsAnyOnePremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SodTreesShrubsAndPlantsOccurrencePremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.SpoilagePremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.UndamagedLeaseholdImprovementsPremium
        ////                                                                             + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.ValuablePapersAndRecordsOtherThanElectronicDataPremium
        ////                                                                             );
        ////     if (property360ModificationCoverageTotalPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360ModificationCoverageTotalPremium)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {

        ////         return false;
        ////     }
        //// }


        //// /// <summary>
        //// /// Cehck golfCoursesTeeToGreenPremium is Valid
        //// /// Step 47 -Golf Courses - Tee to Green  
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="golfCoursesTeeToGreenPremium">golfCoursesTeeToGreenPremium</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsGolfCoursesTeeToGreenPremiumValid(RaterFacadeModel model, out decimal golfCoursesTeeToGreenPremium)
        //// {
        ////     golfCoursesTeeToGreenPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GolfCoursesTeeToGreenRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GolfCoursesTeeToGreenPremium == golfCoursesTeeToGreenPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check GolfCoursesSprinklerAndUndergroundWiringPremium Is Valid
        //// ///  Step 48 - Golf Courses -Sprinkler and Underground Wiring    
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="golfCoursesSprinklerAndUndergroundWiringPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsGolfCoursesSprinklerAndUndergroundWiringPremiumValid(RaterFacadeModel model, out decimal golfCoursesSprinklerAndUndergroundWiringPremium)
        //// {
        ////     golfCoursesSprinklerAndUndergroundWiringPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GolfCoursesSprinklerAndUndergroundWiringRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium == golfCoursesSprinklerAndUndergroundWiringPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check golfCoursesAdditionalGolfCoursePropertyPremium  is Valid
        //// /// Step 49 - Golf Courses -Additional Golf Course Property              
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="golfCoursesAdditionalGolfCoursePropertyPremium">decimal</param>
        //// /// <returns> bool Value</returns>
        //// public bool IsGolfCoursesAdditionalGolfCoursePropertyPremiumValid(RaterFacadeModel model, out decimal golfCoursesAdditionalGolfCoursePropertyPremium)
        //// {
        ////     golfCoursesAdditionalGolfCoursePropertyPremium = 0;
        ////     if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GolfCoursesAdditionalGolfCoursePropertyRevisedLimit == 0)
        ////     {
        ////         if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium == golfCoursesAdditionalGolfCoursePropertyPremium)
        ////         {
        ////             return true;
        ////         }
        ////         else
        ////         {
        ////             return false;
        ////         }
        ////     }
        ////     else
        ////     {
        ////         return true;
        ////     }
        //// }

        //// /// <summary>
        //// /// Check property360GolfCourceTotalPremium is Valid
        //// /// </summary>
        //// /// <param name="model">RaterFacadeModel</param>
        //// /// <param name="property360GolfCourceTotalPremium">decimal</param>
        //// /// <returns>bool Value</returns>
        //// public bool IsProperty360GolfCourceTotalPremiumValid(RaterFacadeModel model, out decimal property360GolfCourceTotalPremium)
        //// {

        ////     property360GolfCourceTotalPremium = (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GolfCoursesTeeToGreenPremium
        ////                                                                     + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GolfCoursesSprinklerAndUndergroundWiringPremium
        ////                                                                     + model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.GolfCoursesAdditionalGolfCoursePropertyPremium);

        ////     if (property360GolfCourceTotalPremium == model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360GolfCourceTotalPremium)
        ////     {
        ////         return true;
        ////     }
        ////     else
        ////     {

        ////         return false;
        ////     }
        //// }

        //// ///// <summary>
        //// ///// Check LossOfMunicipalTaxRevenuePremium is Valid
        //// ///// </summary>
        //// ///// <param name="model">RaterFacadeModel</param>
        //// ///// <param name="property360OptionalCoverage">decimal</param>
        //// ///// <returns>bool Value</returns>
        //// //public bool IsLossOfMunicipalTaxRevenuePremiumValid(RaterFacadeModel model, out decimal lossOfMunicipalTaxRevenuePremium)
        //// //{
        //// //    lossOfMunicipalTaxRevenuePremium = 0;
        //// //    if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.LossOfMunicipalTaxRevenueRevisedLimit == 0)
        //// //    {
        //// //        if (model.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.Property360OutputModel.LossOfMunicipalTaxRevenuePremium == lossOfMunicipalTaxRevenuePremium)
        //// //        {
        //// //            return true;
        //// //        }
        //// //        else
        //// //        {
        //// //            return false;
        //// //        }
        //// //    }
        //// //    else
        //// //    {
        //// //        return true;
        //// //    }
        //// //}
        //// #endregion
        #endregion
    }
}