﻿// <copyright file="PropertyPreValidator.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace Validations
{
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Microsoft.Extensions.Configuration;
    using Models;
    using Models.ApiModels;
    using System;
    using System.Data;
    using System.Linq;

    /// <summary>
    /// PropertyPreValidator
    /// </summary>
    public class PropertyPreValidator : AbstractValidator<RaterFacadeModel>
    {
        /// <summary>
        /// DataAccess object
        /// </summary>
        private PropertyDataAccess DataAccess { get; set; }

        /// <summary>
        /// Loger object
        /// </summary>
        private ILoggingManager logger { get; set; }

        /// <summary>
        /// Configuration object
        /// </summary>
        private IConfiguration configuration { get; set; }

        /// <summary>
        /// PropertyPreValidator
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public PropertyPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.DataAccess = new PropertyDataAccess(this.configuration, this.logger);

            #region Model Validation

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusiness)
                .Must((modelObject, selectedLineOfBusiness) => IsModelValid(modelObject))
                .WithMessage(Resources.ErrorMessages.InputJSONNotValidForLOBs);
            
            this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.ProRatafactor)
                .Must((modelObject, policyExpirationDate) => IsProRatafactorWithDatesValid(modelObject))
                .WithMessage(Resources.ErrorMessages.InputPolicyHeaderPolicyDateInvalidForProRatafactor);

            #endregion

            #region Step I -Building BPP Premium
            //-------------------------------------------------------------------------------------------------------------------//
            /*this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV).ScalePrecision(4, 15)
            .NotNull().WithMessage(Resources.ErrorMessages.InputPropertyBuildingTIVMissing)
            .NotEqual(0).WithMessage(Resources.ErrorMessages.InputPropertyBuildingTIVMissing);

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV).ScalePrecision(4, 15)
                .NotNull().WithMessage(Resources.ErrorMessages.InputPropertyContentsTIVMissing)
                .NotEqual(0).WithMessage(Resources.ErrorMessages.InputPropertyContentsTIVMissing);
            */
            this.RuleFor(reg => reg.RaterOutputFacadeModel.LineOfBusinessOutputModel.Property.TotalTIV).ScalePrecision(4, 15)
               .Must((modelObject, buildingDefPoints) =>
                      CheckTotalTIV(modelObject)).WithMessage(Resources.ErrorMessages.InputPropertyTotalTIVMissing);

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Blanket).NotEmpty().
                 WithMessage(Resources.ErrorMessages.InputPropertyBlanketMissing);

            //change 16-07-2020
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodDeductible).NotNull()
                    .WithMessage(Resources.ErrorMessages.InputPropertyFloodDeductibleMissing)
                    .NotEqual(0).
                    WithMessage(Resources.ErrorMessages.InputPropertyFloodDeductibleMissing);
            });

            //change 16-07-2020
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeDeductible)
                .Must((modelObject, disasterExposureBuildingPoints) =>
                      CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeDeductible)).
                WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeDeductibleMissing);
            });

            //change 16-07-2020
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailDeductible)
                 .Must((modelObject, disasterExposureBuildingPoints) =>
                        CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailDeductible)).
                 WithMessage(Resources.ErrorMessages.InputPropertyWindstormAndHailDeductibleMissing);
            });

            //change 16-07-2020
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AOPDeductible).ScalePrecision(4, 15)
                .NotNull().WithMessage(Resources.ErrorMessages.InputPropertyAOPDeductibleMissing).NotEqual(0).WithMessage(Resources.ErrorMessages.InputPropertyAOPDeductibleMissing);

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Coinsurance)
              .NotNull().WithMessage(Resources.ErrorMessages.InputPropertyCoinsuranceMissing).NotEmpty().WithMessage(Resources.ErrorMessages.InputPropertyCoinsuranceMissing);

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Valuation)
                .NotEmpty().WithMessage(Resources.ErrorMessages.InputPropertyValuationMissing);


            //-------------------------------------------------------------------------------------------------------------------//
            #endregion

            #region Step II - Equipment Breakdown 
            //Step II - Equipment Breakdown 

            //change 16-07-2020
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownDeductible).ScalePrecision(4, 15)
                .Must((modelObject, disasterExposureBuildingPoints) =>
                     CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownDeductible))
                .WithMessage(Resources.ErrorMessages.InputPropertyEquipmentBreakdownDeductibleMissing).NotEqual(0).WithMessage(Resources.ErrorMessages.InputPropertyEquipmentBreakdownDeductibleMissing);

                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit).ScalePrecision(4, 15)
                .Must((modelObject, disasterExposureBuildingPoints) =>
                     CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit))
                .WithMessage(Resources.ErrorMessages.InputPropertyBusinessIncomeAndExtraExpenseLimitMissing);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EquipmentBreakdownCoverage, () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage == false, () =>
                {
                    /*when with spoilage is selected
                     * Steps invovled 
                     * (Step 15 + Step 16) *  Step 2
                    Step 15 = (Step 13 + Step 14) * (1+Step 7 + Step 8)
                    Step 13 =  (Step 3/100)* Step 4 * Step 5
                    Step 14 = (Step 1/100) * Step 4 * Step 6
                    Step 16 = Step 15 * (Step 9 + Step 10) * Step 11 * Step 12
                    */
                    When(reg => !string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType), () =>
                    {
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType)
                        .Must((modelObject, spoilageType) =>
                         ValidateSpoilageType(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType))
                         .WithMessage(Resources.ErrorMessages.InputPropertySpoilageTypeInvalid);

                        // If Spoilage Deductible is selected but Spoilage minimum deductible is not selected
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageMinimumDeductible).ScalePrecision(4, 15)
                            .Must((modelObject, spoilageMinimumDeductible) => CheckSpoilageValue(modelObject)).
                            WithMessage(Resources.ErrorMessages.InputPropertySpoilageMinimumDeductibleMissing);
                    });
                    //change 16-07-2020
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EBSpoilageLimit).ScalePrecision(4, 15)
                        .Must((modelObject, disasterExposureBuildingPoints) =>
                            CheckCoveragePermitstring(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType,
                            modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EBSpoilageLimit))
                        .WithMessage(Resources.ErrorMessages.InputPropertySpoilageType1LimitMissing);

                    //change 16-07-2020
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PollutantCleanUpLimit).ScalePrecision(4, 15)
                         .Must((modelObject, disasterExposureBuildingPoints) =>
                             CheckCoveragePermitstring(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PollutantCleanUpLimit))
                         .WithMessage(Resources.ErrorMessages.InputPropertyPollutantCleanUpLimitMissing);

                    //change 16-07-2020
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.RefrigerantContaminationLimit).ScalePrecision(4, 15)
                        .Must((modelObject, disasterExposureBuildingPoints) =>
                            CheckCoveragePermitstring(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType,
                                                       modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.RefrigerantContaminationLimit))
                        .WithMessage(Resources.ErrorMessages.InputPropertyRefrigerantContaminationLimitMissing);


                    //when w/o spoilage selected
                    /* { (Step 13 + Step 14) *(1 + Step 7 + Step 8 + Step 9 + Step 10)}
                   *Step 2
                   (Step 3 / 100) * Step 4 * Step 5
                   (Step 1 / 100) * Step 4 * Step 6*/
                    //change 16-07-2020
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM).ScalePrecision(4, 15)
                          .Must((modelObject, disasterExposureBuildingPoints) =>
                                CheckCoveragePermitstring(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType,
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM))
                          .WithMessage(Resources.ErrorMessages.InputPropertyEquipmentBreakdownIRPMNotInRange);

                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PollutantCleanUpLimit).ScalePrecision(4, 15)
                        .Must((modelObject, disasterExposureBuildingPoints) =>
                                CheckCoveragePermitstring(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType,
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PollutantCleanUpLimit))
                        .WithMessage(Resources.ErrorMessages.InputPropertyPollutantCleanUpLimitMissing);

                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.RefrigerantContaminationLimit).ScalePrecision(4, 15)
                       .Must((modelObject, disasterExposureBuildingPoints) =>
                                CheckCoveragePermitstring(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType,
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.RefrigerantContaminationLimit))
                       .WithMessage(Resources.ErrorMessages.InputPropertyRefrigerantContaminationLimitMissing);



                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM).ScalePrecision(4, 15)
                    .Must((modelObject, equipmentBreakdownIRPM) =>
                    CheckRangeForValue(Math.Round((modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.IRPM / 100), 2), "IRPM", modelObject)).
                    WithMessage(Resources.ErrorMessages.InputPropertyEquipmentBreakdownIRPMNotInRange);

                    ////change 16-07-2020
                    //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EBSpoilageLimit).ScalePrecision(4, 15)
                    //.NotNull().NotEqual(0).WithMessage(Resources.ErrorMessages.InputPropertySpoilageType1LimitMissing);

                    //// If Spoilage Deductible is selected but Spoilage minimum deductible is not selected

                    //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageMinimumDeductible).ScalePrecision(4, 15)
                    //.Must((modelObject, spoilageMinimumDeductible) => CheckSpoilageValue(modelObject)).
                    //WithMessage(Resources.ErrorMessages.InputPropertySpoilageMinimumDeductibleMissing);

                    //change 16-07-2020
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit).ScalePrecision(4, 15)
                            .Must((modelObject, disasterExposureBuildingPoints) =>
                                 CheckCoveragePermitstring(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SelectedSpoilageType,
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BusinessIncomeAndExtraExpenseLimit))
                           .WithMessage(Resources.ErrorMessages.InputPropertyBusinessIncomeAndExtraExpenseLimitMissing);
                });

                //Step C -Referred Equipment Breakdown coverage calculation
                /*  Equipment Breakdown Total Premium	=	Input field
                    Equipment Breakdown Limit	=	Step 1 + Step 3
                    Equipment Breakdown Rate	=	(Step C.1 *100)/(Step 5 * Step C.2)
                 */
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ReferredEquipmentBreakdownCoverage, () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InputEquipmentBreakdownTotalPremium).ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                         CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InputEquipmentBreakdownTotalPremium))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyEquipmentBreakdownTotalPremiumMissing);

                });
            });

            #endregion

            #region StepIII-WindFloodEarthquakePrem
            //---------------------------------------------------------------------------------------------------------------------------//
            //range coding  -- change value here
            //for wind
            #region  Climatical Hazards
            string stringClimaticalHazardsHurricaneContentPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                      CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints,
                                                   "Climatical Hazards", "Hurricane",
                                                   modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneJustification
                                                   , modelObject, out stringClimaticalHazardsHurricaneContentPoints)).
              WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsHurricaneContentPoints) ?
                                                     stringClimaticalHazardsHurricaneContentPoints : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringClimaticalHazardsSevereConvectiveContentPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                        CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints,
                                                     "Climatical Hazards", "Severe Convective",
                                                     modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveJustification
                                                      , modelObject, out stringClimaticalHazardsSevereConvectiveContentPoints)).
                 WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsSevereConvectiveContentPoints) ?
                                                         stringClimaticalHazardsSevereConvectiveContentPoints : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringClimaticalHazardsWinterStormContentPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                     CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints,
                                                  "Climatical Hazards", "Winter Storm",
                                                  modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormJustification
                                                  , modelObject, out stringClimaticalHazardsWinterStormContentPoints)).
                WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsWinterStormContentPoints) ?
                                                        stringClimaticalHazardsWinterStormContentPoints : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringClimaticalHazardsHurricaneBuildingPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints).ScalePrecision(4, 15)
                  .Must((modelObject, windBuildingPoints) =>
                         CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints,
                                                      "Climatical Hazards", "Hurricane",
                                                      modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneJustification
                                                      , modelObject, out stringClimaticalHazardsHurricaneBuildingPoints)).
                  WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsHurricaneBuildingPoints) ?
                                                         stringClimaticalHazardsHurricaneBuildingPoints : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            string stringClimaticalHazardsSevereConvectiveBuildingPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                        CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints,
                                                     "Climatical Hazards", "Severe Convective",
                                                     modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveJustification
                                                     , modelObject, out stringClimaticalHazardsSevereConvectiveBuildingPoints)).
                 WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsSevereConvectiveBuildingPoints) ?
                                                        stringClimaticalHazardsSevereConvectiveBuildingPoints : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            string stringClimaticalHazardsWinterStormBuildingPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                       CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints,
                                                     "Climatical Hazards", "Winter Storm",
                                                     modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormJustification
                                                      , modelObject, out stringClimaticalHazardsWinterStormBuildingPoints)).
                WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsWinterStormBuildingPoints) ?
                                                        stringClimaticalHazardsWinterStormBuildingPoints : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);
            #endregion  Climatical Hazards

            #region Flood Exposure

            string stringFloodExposureContentPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureContentPoints).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                      CheckForMinMaxValueForFloodExposureUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureContentPoints,
                                                                        "Flood Exposure",
                                                                        null,
                                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureJustification
                                                                        , modelObject, out stringFloodExposureContentPoints)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodExposureContentPoints) ?
                                                         stringFloodExposureContentPoints : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringFloodExposureBuildingPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureBuildingPoints).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                         CheckForMinMaxValueForFloodExposureUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureBuildingPoints,
                                                                           "Flood Exposure",
                                                                           null,
                                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureJustification
                                                                            , modelObject, out stringFloodExposureBuildingPoints)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodExposureBuildingPoints) ?
                                                         stringFloodExposureBuildingPoints :
                 Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            #endregion Flood Exposure

            #region Flood Covered Zone


            #region ContentPoints
            string stringFloodCoveredZoneContentPoints1 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints1).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                         CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints1,
                                                                   "Flood", "Covered Zone",
                                                                   modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification1
                                                                   , modelObject,
                                                                   out stringFloodCoveredZoneContentPoints1)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints1) ?
                                                         stringFloodCoveredZoneContentPoints1 : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringFloodCoveredZoneContentPoints2 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints2).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                         CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints2,
                                                                   "Flood", "Covered Zone",
                                                                   modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification2
                                                                   , modelObject,
                                                                   out stringFloodCoveredZoneContentPoints2)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints2) ?
                                                         stringFloodCoveredZoneContentPoints2 : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringFloodCoveredZoneContentPoints3 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints3).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                         CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints3,
                                                                  "Flood", "Covered Zone",
                                                                  modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification3
                                                                  , modelObject,
                                                                  out stringFloodCoveredZoneContentPoints3)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints3) ?
                                                        stringFloodCoveredZoneContentPoints3 : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringFloodCoveredZoneContentPoints4 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints4).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                         CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints4,
                                                                    "Flood", "Covered Zone",
                                                                    modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification4
                                                                   , modelObject,
                                                                    out stringFloodCoveredZoneContentPoints4)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints4) ?
                                                        stringFloodCoveredZoneContentPoints4 : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringFloodCoveredZoneContentPoints5 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints5).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                         CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints5,
                                                                  "Flood", "Covered Zone", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification5
                                                                  , modelObject, out stringFloodCoveredZoneContentPoints5)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints5) ?
                                                        stringFloodCoveredZoneContentPoints5 : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            #endregion ContentPoints


            #region Building Points

            string stringFloodCoveredZoneBuildingPoints1 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints1).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                 CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints1,
                                                            "Flood", "Covered Zone",
                                                            modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification1
                                                           , modelObject, out stringFloodCoveredZoneBuildingPoints1)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneBuildingPoints1) ?
                                                        stringFloodCoveredZoneBuildingPoints1 : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            string stringFloodCoveredZoneBuildingPoints2 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints2).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                 CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints2,
                                                            "Flood", "Covered Zone",
                                                            modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification2
                                                           , modelObject, out stringFloodCoveredZoneBuildingPoints2)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneBuildingPoints2) ?
                                                        stringFloodCoveredZoneBuildingPoints2 : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            string stringFloodCoveredZoneBuildingPoints3 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints3).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                 CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints3,
                                                           "Flood", "Covered Zone",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification3
                                                           , modelObject,
                                                           out stringFloodCoveredZoneBuildingPoints3)).
                 WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneBuildingPoints3) ?
                                                        stringFloodCoveredZoneBuildingPoints3 : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            string stringFloodCoveredZoneBuildingPoints4 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints4).ScalePrecision(4, 15)
             .Must((modelObject, windBuildingPoints) =>
             CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints4,
                                                       "Flood", "Covered Zone",
                                                       modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification4
                                                      , modelObject,
                                                       out stringFloodCoveredZoneBuildingPoints4)).
             WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneBuildingPoints4) ?
                                                    stringFloodCoveredZoneBuildingPoints4 : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            string stringFloodCoveredZoneBuildingPoints5 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints5).ScalePrecision(4, 15)
             .Must((modelObject, windBuildingPoints) =>
             CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints5,
                                                       "Flood", "Covered Zone",
                                                       modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification5
                                                       , modelObject,
                                                       out stringFloodCoveredZoneBuildingPoints5)).
             WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneBuildingPoints5) ?
                                                    stringFloodCoveredZoneBuildingPoints5 : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            #endregion Building Points


            #endregion Flood Covered Zone

            #region Earthquake
            string stringEarthquakeExposureContentPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureContentPoints).ScalePrecision(4, 15)
                 .Must((modelObject, windBuildingPoints) =>
                        CheckForMinMaxValueForFloodExposureUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureContentPoints,
                                                                          "Earthquake Exposure",
                                                                          null,
                                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureJustification
                                                                          , modelObject,
                                                                          out stringEarthquakeExposureContentPoints)).
                 WithMessage(x => !string.IsNullOrEmpty(stringEarthquakeExposureContentPoints) ?
                                                        stringEarthquakeExposureContentPoints : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringEarthquakeExposureBuildingPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureBuildingPoints).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                        CheckForMinMaxValueForFloodExposureUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureBuildingPoints,
                                                                           "Earthquake Exposure",
                                                                           null,
                                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureJustification
                                                                           , modelObject,
                                                                           out stringEarthquakeExposureBuildingPoints)).
                WithMessage(x => !string.IsNullOrEmpty(stringEarthquakeExposureBuildingPoints) ?
                                                        stringEarthquakeExposureBuildingPoints :
                                                        Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);
            #endregion

            #region Earth Movement
            #region Earth Movement BuildingPoints

            string stringEarthMovementTerritoryBuildingPoints1 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints1).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                        CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints1,
                                                                  "Earth Movement", "Territory", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryJustification1
                                                                   , modelObject, out stringEarthMovementTerritoryBuildingPoints1)).
                WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementTerritoryBuildingPoints1) ?
                                                       stringEarthMovementTerritoryBuildingPoints1 : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            string stringEarthMovementTerritoryBuildingPoints2 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints2).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                     CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints2,
                                                                "Earth Movement",
                                                                "Territory",
                                                                modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryJustification2, modelObject,
                                                                 out stringEarthMovementTerritoryBuildingPoints2)).
                WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementTerritoryBuildingPoints2) ?
                                                        stringEarthMovementTerritoryBuildingPoints2 : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);

            string stringEarthMovementLimitBuildingPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitBuildingPoints).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitBuildingPoints,
                                                          "Earth Movement",
                                                          "Limit",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitJustification
                                                          , modelObject, out stringEarthMovementLimitBuildingPoints)).
                WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementLimitBuildingPoints) ?
                                                        stringEarthMovementLimitBuildingPoints : Resources.ErrorMessages.InputPropertyBuildingPointsNotInRange);
            #endregion

            #region Earth Movement content Points

            string stringEarthMovementTerritoryContentPoints1 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints1).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                        CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints1,
                                                                  "Earth Movement",
                                                                  "Territory",
                                                                  modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryJustification1
                                                                  , modelObject,
                                                                  out stringEarthMovementTerritoryContentPoints1)).
                WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementTerritoryContentPoints1) ?
                                                       stringEarthMovementTerritoryContentPoints1 :
                                                       Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringEarthMovementTerritoryContentPoints2 = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints2).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints2,
                "Earth Movement", "Territory", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryJustification2
                , modelObject, out stringEarthMovementTerritoryContentPoints2)).
                WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementTerritoryContentPoints2) ? stringEarthMovementTerritoryContentPoints2 : Resources.ErrorMessages.InputPropertyContentPointsNotInRange);

            string stringEarthMovementLimitContentPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitContentPoints).ScalePrecision(4, 15)
                .Must((modelObject, windBuildingPoints) =>
                        CheckForMinMaxValueForFloodUnderDeficency(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitContentPoints,
                                                                  "Earth Movement",
                                                                  "Limit",
                                                                  modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitJustification
                                                                  , modelObject, out stringEarthMovementLimitContentPoints)).
                WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementLimitContentPoints) ?
                                                       stringEarthMovementLimitContentPoints :
                                                       Resources.ErrorMessages.InputPropertyContentPointsNotInRange);
            #endregion

            #endregion
            #endregion StepIII-WindFloodEarthquakePrem

            //#region  Step V -Optional Coverage
            ////---------------------------------------------------------------------------------------------------------------------------//

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel != null, () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.IsAdditionalCoveredPropertyOptionalCoverageSelected, () =>
                {
                    string messageAdditionalCoveredPropertyPremium = Resources.ErrorMessages.InputPropertyAdditionalCoveredPropertyPremiumMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.IsAdditionalCoveredPropertyOptionalCoverageSelected)
                        .Must((modelObject, propertyOptionalCoverages) =>
                                CheckForOptionalCoverageADDITIONALCOVEREDPROPERTY(modelObject)).
                        WithMessage(x => messageAdditionalCoveredPropertyPremium);

                });
                string messageAdditionalCoveredPropertyPremiumLmit = Resources.ErrorMessages.InputPropertyAlabamaWindHailPremiumLimitMissing;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel)
                   .Must((modelObject, propertyOptionalCoverages) =>
                         CheckForOptionalCoverageALABAMAWINDHAILPremiumLimit(modelObject,
                                                                             ref messageAdditionalCoveredPropertyPremiumLmit)).
                   WithMessage(x => messageAdditionalCoveredPropertyPremiumLmit);

                string messageAdditionalCoveredPropertyPremiumstate = Resources.ErrorMessages.InputPropertyAlabamaWindHailPremiumStateNotAllowed;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel)
                    .Must((modelObject, propertyOptionalCoverages) =>
                            CheckForOptionalCoverageALABAMAWINDHAILPremiumState(modelObject,
                                                                                ref messageAdditionalCoveredPropertyPremiumstate)).
                     WithMessage(x => messageAdditionalCoveredPropertyPremiumstate);


                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel != null, () =>
                {

                    string messageOtherCoveragePremium = Resources.ErrorMessages.InputPropertyOtherCoveragePremiumMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                        .Must((modelObject, propertyOptionalCoverages) =>
                                CheckForOptionalCoverageFlatCharge(modelObject,
                                                                    ref messageOtherCoveragePremium)).
                        WithMessage(x => messageOtherCoveragePremium);

                    string messageOtherCoveragePremiumLimit = Resources.ErrorMessages.InputPropertyOtherCoverageLimitMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                        .Must((modelObject, propertyOptionalCoverages) =>
                               CheckForOptionalCoverageOtherForLimit(modelObject,
                                                                     ref messageOtherCoveragePremiumLimit)).
                        WithMessage(x => messageOtherCoveragePremiumLimit);

                    string messageOtherCoveragePremiumRate = Resources.ErrorMessages.InputPropertyOtherCoverageRateMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                        .Must((modelObject, propertyOptionalCoverages) =>
                                CheckForOptionalCoverageOtherForRate(modelObject,
                                                                     ref messageOtherCoveragePremiumRate)).
                        WithMessage(x => messageOtherCoveragePremiumRate);
                });

                #region Mamta  on 20-07-2021
                //148)Property -> Optional Coverage	
                //Description	
                //If  Other Optional Coverage is added and corresponding Description is left blank.
                //Cannot Rate the quote as Other Optional Coverage Description is invalid.
                string messageOptionalCoveragePremiumRate = Resources.ErrorMessages.InputPropertyAdditionalCoveredPropertyDescriptionMissing;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                     .Must((modelObject, propertyOptionalCoverages) =>
                            CheckForOtherOptionalCoverage(modelObject,
                                                          ref messageOptionalCoveragePremiumRate)).
                     WithMessage(x => messageOptionalCoveragePremiumRate);

                //149)Property -> Optional Coverage	
                //Rating Basis	
                //If  Other Optional Coverage is added and Rating Basis dropdown is left blank
                //Cannot Rate the quote as Other Optional Coverage Rating Basis is invalid.
                string messageOptionalCoveragePremiumRateBasis = Resources.ErrorMessages.InputPropertyAdditionalCoveredPropertyRatingBasisMissing;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel)
                     .Must((modelObject, propertyOptionalCoverages) =>
                            CheckForOtherOptionalCoverageRatingBasis(modelObject,
                                                                     ref messageOptionalCoveragePremiumRateBasis)).
                     WithMessage(x => messageOptionalCoveragePremiumRateBasis);
                #endregion                
            });
            ////---------------------------------------------------------------------------------------------------------------------------//

            #region  Step IV -360 Coverage
            //---------------------------------------------------------------------------------------------------------------------------//
            //
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel != null, () =>
            {
                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsBusinessIncomeAndExtraExpenseCoverageSelected, () =>
                {
                    //step 1 - Business Income & Extra Expense (BI & EE)
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.BusinessIncomeAndExtraExpenseRevisedLimit)
                    .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.BusinessIncomeAndExtraExpenseRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelBusinessIncomeAndExtraExpenseRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsDependentPropertyCoverageSelected, () =>
                {
                    //step 2 -Dependent Property Business Income
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.DependentPropertyRevisedLimit)
                    .Must((modelObject, dependentPropertyRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.DependentPropertyRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelDependentPropertyRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsInterruptionOfComputerOperationsCoverageSelected, () =>
                {
                    //step 3 - Interruption of Computer Operations
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.InterruptionOfComputerOperationsRevisedLimit)
                    .Must((modelObject, interruptionOfComputerOperationsRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.InterruptionOfComputerOperationsRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelInterruptionOfComputerOperationsRevisedLimtMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsLeaseCancellationMovingExpensesCoverageSelected, () =>
                {
                    //Step 4 - Lease Cancellation Moving Expenses
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.LeaseCancellationMovingExpensesRevisedLimit)
                    .Must((modelObject, leaseCancellationMovingExpensesRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.LeaseCancellationMovingExpensesRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelLeaseCancellationMovingExpensesRevisedLimitMissing);

                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsNewlyAcquiredOrConstructedPropertyCoverageSelected, () =>
                {
                    // Step 5 - Newly Acquired or Constructed Property  – Business Income
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NewlyAcquiredOrConstructedPropertyRevisedLimit)
                     .Must((modelObject, newlyAcquiredOrConstructedPropertyRevisedLimit) =>
                             Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NewlyAcquiredOrConstructedPropertyRevisedLimit))
                     .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelNewlyAcquiredOrConstructedPropertyRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsOffPremisesUtilityFailureBusinessIncomeAndExtraExpenseCoverageSelected, () =>
                {
                    // Step 6 - Off Premises Utility Failure - Business Income and Extra Expense
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit)
                    .Must((modelObject, offPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelOffPremisesUtilityFailureBusinessIncomeAndExtraExpenseRevisedLimitMissing);

                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsOrdinanceOrLawCoverageBSelected, () =>
                {
                    //Step 7.1 Ordinance or Law - Coverage B
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OrdinanceOrLawCoverageBRevisedLimit)
                    .Must((modelObject, ordinanceOrLawCoverageCRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OrdinanceOrLawCoverageBRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelOrdinanceOrLawCoverageBRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsOrdinanceOrLawCoverageCSelected, () =>
                {
                    //Step 7.2 - Ordinance or Law - Coverage 
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OrdinanceOrLawCoverageCRevisedLimit)
                    .Must((modelObject, ordinanceOrLawCoverageCRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OrdinanceOrLawCoverageCRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelOrdinanceOrLawCoverageCRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsAccountsReceivableRecordsCoverageSelected, () =>
                {
                    //Step 8 - Accounts Receivable Records
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.AccountsReceivableRecordsRevisedLimit)
                        .Must((modelObject, accountsReceivableRecordsRevisedLimit) =>
                               Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.AccountsReceivableRecordsRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelAccountsReceivableRecordsRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsAppurtenantStructuresCoverageSelected, () =>
                {

                    //Step 9 - Appurtenant Structures
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.AppurtenantStructuresRevisedLimit)
                        .Must((modelObject, appurtenantStructuresRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.AppurtenantStructuresRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelAppurtenantStructuresRevisedLimitMissing);

                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsAudioVisualAndCommunicationEquipmentCoverageSelected, () =>
                {
                    // Step 10 - Audio Visual and Communication Equipment
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.AudioVisualAndCommunicationEquipmentRevisedLimit)
                         .Must((modelObject, audioVisualAndCommunicationEquipmentRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.AudioVisualAndCommunicationEquipmentRevisedLimit))
                         .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelAudioVisualAndCommunicationEquipmentRevisedLimitMissing);

                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsChangesInTemperatureOrHumidityCoverageSelected, () =>
                {
                    // Step 11 - Changes in Temperature or Humidity
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ChangesInTemperatureOrHumidityRevisedLimit)
                        .Must((modelObject, changesInTemperatureOrHumidityRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ChangesInTemperatureOrHumidityRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelChangesInTemperatureOrHumidityRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsCommandeeredPropertyCoverageSelected, () =>
                {
                    //Step 12 - Commandeered Property
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.CommandeeredPropertyRevisedLimit)
                        .Must((modelObject, commandeeredPropertyRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.CommandeeredPropertyRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelCommandeeredPropertyRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsComputerEquipmentCoverageSelected, () =>
                {
                    //Step 13 - Computer Equipment
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ComputerEquipmentRevisedLimit)
                        .Must((modelObject, computerEquipmentRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ComputerEquipmentRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelComputerEquipmentRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsDebrisRemovalYourPremisesCoverageSelected, () =>
                {
                    //Step 14- Debris Removal - Your Premises
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.DebrisRemovalYourPremisesRevisedLimit)
                        .Must((modelObject, debrisRemovalYourPremisesRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.DebrisRemovalYourPremisesRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelDebrisRemovalYourPremisesRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsDebrisRemovalWindBlownDebrisCoverageSelected, () =>
                {
                    //Step 15 - Debris Removal - Wind Blown Debris
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.DebrisRemovalWindBlownDebrisRevisedLimit)
                        .Must((modelObject, debrisRemovalWindBlownDebrisRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.DebrisRemovalWindBlownDebrisRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelDebrisRemovalWindBlownDebrisRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsElectronicDataCoverageSelected, () =>
                {
                    //Step 16 - Electronic Data
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ElectronicDataRevisedLimit)
                        .Must((modelObject, electronicDataRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ElectronicDataRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelElectronicDataRevisedLimitMissing);

                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsFineArtsCoverageSelected, () =>
                {
                    //Step 17 -Fine Arts
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.FineArtsRevisedLimit)
                        .Must((modelObject, fineArtsRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.FineArtsRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelFineArtsRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsFireDepartmentServiceChargeCoverageSelected, () =>
                {
                    //Step 18 -Fire Department Service Charge
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.FireDepartmentServiceChargeRevisedLimit)
                        .Must((modelObject, fireDepartmentServiceChargeRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.FireDepartmentServiceChargeRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelFireDepartmentServiceChargeRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsFungusWetRotDryRotAndBacteriaCoverageSelected, () =>
                {
                    //Step 19 - Fungus, Wet Rot, Dry Rot and Bacteria
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.FungusWetRotDryRotAndBacteriaRevisedLimit)
                        .Must((modelObject, fungusWetRotDryRotAndBacteriaRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.FungusWetRotDryRotAndBacteriaRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelFungusWetRotDryRotAndBacteriaRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsGlassDisplayOrTrophyCasesCoverageSelected, () =>
                {
                    //Step 20 - Glass Display or Trophy Cases
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GlassDisplayOrTrophyCasesRevisedLimit)
                       .Must((modelObject, glassDisplayOrTrophyCasesRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GlassDisplayOrTrophyCasesRevisedLimit))
                       .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelGlassDisplayOrTrophyCasesRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsInventoryAndAppraisalCoverageSelected, () =>
                {
                    //Step 21 - Inventory and Appraisal
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.InventoryAndAppraisalRevisedLimit)
                        .Must((modelObject, inventoryAndAppraisalRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.InventoryAndAppraisalRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelInventoryAndAppraisalRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsKeyCardCoverageSelected, () =>
                {
                    //Step 22 - Key/Card
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.KeyCardRevisedLimit)
                        .Must((modelObject, keyCardRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.KeyCardRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelKeyCardRevisedLimitLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsLockReplacementCoverageSelected, () =>
                {
                    //change 16-07-2020
                    //Step 23 - Lock Replacement
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.LockReplacementRevisedLimit)
                       .Must((modelObject, lockReplacementRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.LockReplacementRevisedLimit))
                       .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelLockReplacementRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsMoneyAndSecuritiesOnYourPremisesCoverageSelected, () =>
                {
                    //Step 24 - Money and Securities -On Your Premises
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.MoneyAndSecuritiesOnYourPremisesRevisedLimit)
                        .Must((modelObject, moneyAndSecuritiesOnYourPremisesRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.MoneyAndSecuritiesOnYourPremisesRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelMoneyAndSecuritiesOnYourPremisesRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsMoneyAndSecuritiesAwayFromYourPremisesCoverageSelected, () =>
                {
                    //Step 25 - Money and Securities - Away From Your Premises
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit)
                        .Must((modelObject, moneyAndSecuritiesAwayFromYourPremisesRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.MoneyAndSecuritiesAwayFromYourPremisesRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelMoneyAndSecuritiesAwayFromYourPremisesRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsNewlyAcquiredOrConstructedPropertyBuildingsCoverageSelected, () =>
                {
                    //Step 26 - Newly Acquired or Constructed Property -Buildings
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit)
                       .Must((modelObject, newlyAcquiredOrConstructedPropertyRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NewlyAcquiredOrConstructedPropertyBuildingsRevisedLimit))
                       .WithMessage(Resources.ErrorMessages.InputModelPropertyPropertyNY360InputModelNewlyAcquiredORConstructedPropertyBuildingRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyCoverageSelected, () =>
                {
                    //Step 27 - Newly Acquired or Constructed Property - Your Business Personal Property
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit)
                        .Must((modelObject, newlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelNewlyAcquiredOrConstructedPropertyYourBusinessPersonalPropertyRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsNonOwnedDetachedTrailersCoverageSelected, () =>
                {
                    //Step 28 - Non-owned Detached Trailers
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NonOwnedDetachedTrailersRevisedLimit)
                        .Must((modelObject, nonOwnedDetachedTrailersRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.NonOwnedDetachedTrailersRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelNonOwnedDetachedTrailersRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsOffPremisesUtilityFailureDamageToCoveredPropertyCoverageSelected, () =>
                {
                    //Step 29 - Off Premises Utility Failure - Damage to Covered Property
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit)
                        .Must((modelObject, offPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelOffPremisesUtilityFailureDamageToCoveredPropertyRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsOutdoorPropertyCoverageSelected, () =>
                {
                    //Step 30 - Outdoor Property
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OutdoorPropertyRevisedLimit)
                        .Must((modelObject, outdoorPropertyRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.OutdoorPropertyRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelOutdoorPropertyRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsPersonalEffectsAndPropertyOfOthersCoverageSelected, () =>
                {
                    //Step 31 - Personal Effects and Property of Others
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PersonalEffectsAndPropertyOfOthersRevisedLimit)
                        .Must((modelObject, personalEffectsAndPropertyOfOthersRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PersonalEffectsAndPropertyOfOthersRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelPersonalEffectsAndPropertyOfOthersRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerCoverageSelected, () =>
                {
                    //Step 32 - Personal Effects and Property of Others - Any Employee or Volunteer
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit)
                        .Must((modelObject, personalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelPersonalEffectsAndPropertyOfOthersAnyEmployeeOrVolunteerRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsModificationPollutantCleanUpAndRemovalCoverageSelected, () =>
                {
                    //Step 33 - Pollutant Clean Up and Removal
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ModificationPollutantCleanUpAndRemovalRevisedLimit)
                        .Must((modelObject, pollutantCleanUpAndRemovalRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ModificationPollutantCleanUpAndRemovalRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelPollutantCleanUpAndRemovalRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsPropertyInTransitCoverageSelected, () =>
                {
                    //Step 34 - Property In Transit
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PropertyInTransitRevisedLimit)
                        .Must((modelObject, propertyInTransitRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PropertyInTransitRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelInTransitRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsPropertyOffPremisesCoverageSelected, () =>
                {
                    //Step 35 - Property Off-premises
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PropertyOffPremisesRevisedLimit)
                        .Must((modelObject, propertyOffPremisesRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.PropertyOffPremisesRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelOffPremisesRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsRechargeOfFireProtectionEquipmentCoverageSelected, () =>
                {
                    //Step 36 - Recharge of Fire Protection Equipment
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.RechargeOfFireProtectionEquipmentRevisedLimit)
                        .Must((modelObject, rechargeOfFireProtectionEquipmentRevisedLimit) =>
                               Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.RechargeOfFireProtectionEquipmentRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelRechargeOfFireProtectionEquipmentRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsRetainingWallsCoverageSelected, () =>
                {
                    //Step 37 - Retaining Walls
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.RetainingWallsRevisedLimit)
                     .Must((modelObject, retainingWallsRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.RetainingWallsRevisedLimit))
                     .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelRetainingWallsRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsRewardPaymentsCoverageSelected, () =>
                {
                    //Step 38 - Reward Payments
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.RewardPaymentsRevisedLimit)
                        .Must((modelObject, rewardPaymentsRevisedLimit) =>
                        Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.RewardPaymentsRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelRewardPaymentsRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsSalespersonsSamplesCoverageSelected, () =>
                {
                    //Step 39 - Salesperson’s Samples
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SalespersonsSamplesRevisedLimit)
                        .Must((modelObject, slespersonsSamplesRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SalespersonsSamplesRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelSalespersonsSamplesRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsSCADAUpgradeCoverageSelected, () =>
                {
                    //Step 40 -SCADA Upgrade
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SCADAUpgradeRevisedLimit)
                        .Must((modelObject, sCADAUpgradeRevisedLimit) =>
                               Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SCADAUpgradeRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelSCADAUpgradeRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsSodTreesShrubsAndPlantsOccurrenceCoverageSelected, () =>
                {
                    //Step 41- Sod, Trees, Shrubs, and Plants - Any One
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SodTreesShrubsAndPlantsAnyOneRevisedLimit)
                        .Must((modelObject, sodTreesShrubsAndPlantsAnyOneRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SodTreesShrubsAndPlantsAnyOneRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelSodTreesShrubsAndPlantsAnyOneRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsSodTreesShrubsAndPlantsOccurrenceCoverageSelected, () =>
                {
                    //Step 42  Sod, Trees, Shrubs, and Plants -Occurrence
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SodTreesShrubsAndPlantsOccurrenceRevisedLimit)
                        .Must((modelObject, sodTreesShrubsAndPlantsOccurrenceRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SodTreesShrubsAndPlantsOccurrenceRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelSodTreesShrubsAndPlantsOccurrenceRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsSpoilageCoverageSelected, () =>
                {
                    //Step 43 - Spoilage
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SpoilageRevisedLimit)
                        .Must((modelObject, spoilageRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.SpoilageRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelSpoilageRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitCoverageSelected, () =>
                {
                    //change 16-07-2020
                    //Step 44 - Theft of Jewelry, Furs, Stamps, and Other Specified Items – Occurrence Limit
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit)
                    .Must((modelObject, theftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit) =>
                           Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.TheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimit))
                    .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelTheftOfJewelryFursStampsAndOtherSpecifiedItemsOccurrenceLimitRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsUndamagedLeaseholdImprovementsCoverageSelected, () =>
                {
                    //Step 45 - Undamaged Leasehold Improvements
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.UndamagedLeaseholdImprovementsRevisedLimit)
                         .Must((modelObject, undamagedLeaseholdImprovementsRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.UndamagedLeaseholdImprovementsRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelUndamagedLeaseholdImprovementsRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsValuablePapersAndRecordsOtherThanElectronicDataCoverageSelected, () =>
                {
                    //Step 46 - Valuable Papers and Records Other than Electronic Data
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit)
                         .Must((modelObject, valuablePapersAndRecordsOtherThanElectronicDataRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.ValuablePapersAndRecordsOtherThanElectronicDataRevisedLimit))
                         .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelValuablePapersAndRecordsOtherThanElectronicDataRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsGolfCoursesTeeToGreenCoverageSelected, () =>
                {
                    //Step 47 -Golf Courses - Tee to Green
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GolfCoursesTeeToGreenRevisedLimit)
                         .Must((modelObject, golfCoursesTeeToGreenRevisedLimit) =>
                         Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GolfCoursesTeeToGreenRevisedLimit))
                         .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelGolfCoursesTeeToGreenRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsGolfCoursesSprinklerAndUndergroundWiringCoverageSelected, () =>
                {
                    //Step 48 - Golf Courses -Sprinkler and Underground Wiring
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GolfCoursesSprinklerAndUndergroundWiringRevisedLimit)
                         .Must((modelObject, golfCoursesSprinklerAndUndergroundWiringRevisedLimit) =>
                                 Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GolfCoursesSprinklerAndUndergroundWiringRevisedLimit))
                         .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelGolfCoursesSprinklerAndUndergroundWiringRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsGolfCoursesAdditionalGolfCoursePropertyCoverageSelected, () =>
                {
                    //Step 49 - Golf Courses -Additional Golf Course Property
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GolfCoursesAdditionalGolfCoursePropertyRevisedLimit)
                        .Must((modelObject, golfCoursesAdditionalGolfCoursePropertyRevisedLimit) =>
                                Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.GolfCoursesAdditionalGolfCoursePropertyRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelGolfCoursesAdditionalGolfCoursePropertyRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsIngressOrEgressCoverageSelected, () =>
                {
                    //150)Property 360 -> Business Income Coverages	
                    //Ingress or Egress Revised Limit.
                    //If Ingress or Egress coverage is selected but Revised Limit is NOT entered.
                    //Cannot Rate the quote as  Ingress or Egress Revised Limit is invalid.
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IngressOrEgressRevisedLimit)
                        .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IngressOrEgressRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelBusinessIngressOrEgressRevisedLimitMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsIngressOrEgressCoverageSelected, () =>
                {
                    //151)Property 360 -> Business Income Coverages	
                    //Ingress or Egress #Miles
                    //If Ingress or Egress coverage is selected but #Miles is NOT selected.
                    //Cannot Rate the quote as  Ingress or Egress #Miles is invalid.
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IngressOrEgressMiles)
                        .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                              Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IngressOrEgressMiles))
                         .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelBusinessIngressOrEgressMilesMissing);
                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.IsBusinessIncomePollutantCleanUpAndRemovalSelected, () =>
                {
                    //152)Property 360 -> Business Income Coverages	
                    //Pollutant Clean Up and Removal Revised Limit
                    //If Pollutant Clean Up and Removal coverage is selected but Revised Limit is NOT entered.
                    //Cannot Rate the quote as Pollutant Clean Up and Removal Revised Limit is invalid.
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.BusinessIncomePollutantCleanUpAndRemovalRevisedLimit)
                        .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.BusinessIncomePollutantCleanUpAndRemovalRevisedLimit))
                        .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360InputModelPollutantCleanUpAndRemovalRevisedLimitMissing);
                });

                #region 360OptionalCoverageInputModel

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel != null, () =>
                {
                    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel != null, () =>
                      {
                          //Step 50 - Loss of Municipal Tax Revenue
                          string messageLossOfMunicipalTaxRevenueRevisedLimit = Resources.ErrorMessages.InputModelPropertyProperty360InputModelLossOfMunicipalTaxRevenueRevisedLimitMissing;
                          this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel)
                          .Must((modelObject, value) =>
                          Check360CoveragePremiumAndLimitsForLossOfMunicipal(modelObject, ref messageLossOfMunicipalTaxRevenueRevisedLimit))
                          .WithMessage(x => messageLossOfMunicipalTaxRevenueRevisedLimit);

                      });

                    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.IsBuildersRiskCoverageSelected, () =>
                    {
                        //153)Property 360-> Optional
                        //Builders Risk Limit	
                        //If Builders Risk coverage is selected but Limit is NOT entered.
                        //Cannot Rate the quote as Builders Risk Limit is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.BuildersRiskLimit)
                           .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                 Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.BuildersRiskLimit))
                           .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageBuildersRiskLimitMissing);

                        //154)Property 360-> Optional
                        //Builders Risk Loc	
                        //If Builders Risk coverage is selected but Loc is NOT entered.
                        //Cannot Rate the quote as Builders Risk Loc is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.BuildersRiskLocation)
                           .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                  Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.BuildersRiskLocation))
                           .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageBuildersRiskLocMissing);

                        //155)Property 360-> Optional
                        //Builders Risk Bldg
                        //If Builders Risk coverage is selected but Bldg is NOT entered.
                        //Cannot Rate the quote as Builders Risk Bldg is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.BuildersRiskBuilding)
                             .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                    Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.BuildersRiskBuilding))
                             .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageBuildersRiskMissing);

                        //156)Property 360-> Optional
                        //Builders Risk Location Description
                        //If Builders Risk coverage is selected but Location Description is NOT entered.
                        //Cannot Rate the quote as Builders Risk Location Description is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.BuildersRiskLocationDescription)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                    Check360CoverageDescription(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.BuildersRiskLocationDescription))
                            .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageBuildersRiskDescriptionMissing);
                    });

                    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.IsForestFireExpenseInAnyOne72HourPeriodCoverageSelected, () =>
                    {
                        //157)Property 360-> Optional
                        //Forest Fire Expense - In Any One 72 Hour Period Limit	
                        //If In Any One 72 Hour Period coverage is selected but Limit is NOT entered.
                        //Cannot Rate the quote as Forest Fire Expense - In Any One 72 Hour Period Limit is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.ForestFireExpenseInAnyOne72HourPeriod)
                           .Must((modelObject, ForestFireExpenseInAnyOne72HourPeriod) =>
                                  Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.ForestFireExpenseInAnyOne72HourPeriod))
                           .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageForestFireExpenseInAnyOne72HourPeriodMissing);
                    });

                    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.IsForestFireExpenseInAnyOnePolicyPeriodCoverageSelected, () =>
                    {
                        //158)Property 360-> Optional
                        //Forest Fire Expense -In Any One Policy Period Limit	
                        //If In Any One Policy Period coverage is selected but limit is NOT entered.
                        //Cannot Rate the quote as Forest Fire Expense - In Any One Policy Period Limit is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.ForestFireExpenseInAnyOnePolicyPeriod)
                            .Must((modelObject, ForestFireExpenseInAnyOnePolicyPeriod) =>
                                     Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.ForestFireExpenseInAnyOnePolicyPeriod))
                            .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageForestFireExpenseInAnyOnePolicyPeriodMissing);
                    });

                    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.IsHistoricPropertyValuationCoverageSelected, () =>
                    {
                        //159)Property 360-> Optional
                        //Historic Property Valuation Limit	
                        //If Historic Property Valuation is selected but Limit is NOT entered.
                        //Cannot Rate the quote as Historic Property Valuation Limit is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.HistoricPropertyValuationLimit)
                           .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                 Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.HistoricPropertyValuationLimit))
                           .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageHistoricPropertyValuationLimitMissing);

                        //160)Property 360-> Optional
                        //Historic Property Valuation  Loc	
                        //If Historic Property Valuation coverage is selected but Loc is NOT entered.
                        //Cannot Rate the quote as Historic Property Valuation Loc is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.HistoricPropertyValuationLocation)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                   Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.HistoricPropertyValuationLocation))
                            .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageHistoricPropertyValuationLocationMissing);

                        //161)Property 360-> Optional
                        //Historic Property Valuation  Bldg	
                        //If Historic Property Valuation coverage is selected but Bldg is NOT entered.
                        //Cannot Rate the quote as Historic Property Valuation Bldg is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.HistoricPropertyValuationBuilding)
                           .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                 Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.HistoricPropertyValuationBuilding))
                           .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageHistoricPropertyValuationBuildingMissing);

                        //162)Property 360-> Optional
                        //Historic Property Valuation  Location Description	
                        //If Historic Property Valuation coverage is selected but Location Description is NOT entered.
                        //Cannot Rate the quote as Historic Property Valuation Location Description is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.HistoricPropertyValuationLocationDescription)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                    Check360CoverageDescription(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.HistoricPropertyValuationLocationDescription))
                            .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageHistoricPropertyValuationLocationDescriptionMissing);
                    });

                    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.IsUndergroundPropertyOnPremiseExcessCoverageSelected, () =>
                    {
                        //163)Property 360-> Optional
                        //Underground Property On-Premise Excess Limit	
                        //If Underground Property On-Premise Excess coverage is selected but Limit is NOT entered.
                        //Cannot Rate the quote as Underground Property On-Premise Excess Limit is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOnPremiseExcessLimit)
                           .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOnPremiseExcessLimit))
                           .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageUndergroundPropertyOnPremiseExcessLimitMissing);

                        //164)Property 360-> Optional
                        //Underground Property On-Premise Excess Loc	
                        //If Underground Property On-Premise Excess coverage is selected but Loc is NOT entered.
                        //Cannot Rate the quote as Underground Property On-Premise Excess Loc is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOnPremiseExcessLocation)
                           .Must((modelObject, UndergroundPropertyOnPremiseExcessLimit) =>
                                 Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOnPremiseExcessLocation))
                           .WithMessage(Resources.ErrorMessages.UndergroundPropertyOnPremiseExcessLocationMissing);

                        //165)Property 360-> Optional
                        //Underground Property On-Premise Excess Bldg	
                        //If Underground Property On-Premise Excess coverage is selected but Bldg is NOT entered.
                        //Cannot Rate the quote as Underground Property On-Premise Excess Bldg is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOnPremiseExcessBuilding)
                             .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                 Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOnPremiseExcessBuilding))
                              .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageUndergroundPropertyOnUndergroundPropertyOnPremiseExcessBuildingMissing);

                        //166)Property 360-> Optional
                        //Underground Property On-Premise Excess Location Description	
                        //If Underground Property On-Premise Excess coverage is selected but Location Description is NOT entered.
                        //Cannot Rate the quote as Underground Property On-Premise Excess Location Description is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOnPremiseExcessLocationDescription)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                    Check360CoverageDescription(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOnPremiseExcessLocationDescription))
                            .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageUndergroundPropertyOnPremiseExcessLocationDescriptionMissing);
                    });

                    When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.IsUndergroundPropertyOffPremiseExcessCoverageSelected, () =>
                    {
                        //167)Property 360-> Optional
                        //Underground Property Off-Premise Excess  Limit	
                        //If Underground Property off-Premise Excess coverage is selected but Limit is NOT entered.
                        //Cannot Rate the quote as Underground Property off-Premise Excess limit is invalid.
                        this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOffPremiseExcessLimit)
                          .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                                 Check360CoveragePremiumAndLimits(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.UndergroundPropertyOffPremiseExcessLimit))
                          .WithMessage(Resources.ErrorMessages.InputModelPropertyProperty360OptionalCoverageUndergroundPropertyOffPremiseExcessLimitMissing);
                    });
                });

                #endregion
            });
            //---------------------------------------------------------------------------------------------------------------------------//
            #endregion

            #region VI-Final Property Premium
            //------------------------------------------------------------------------------------------------///

            //val 1
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LargeRiskFactor).ScalePrecision(4, 15)
                .NotNull().WithMessage(Resources.ErrorMessages.InputModelPropertyLargeRiskFactorMissing);


            //val 2

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LargeRiskFactor)
                .Must((modelObject, largeRiskFactor) => CheckRangeForValue(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LargeRiskFactor, "LargeRiskFactor", modelObject))
                .WithMessage(Resources.ErrorMessages.InputModelPropertyLargeRiskFactorNotInRange);

            //------------------------------------------------------------------------------------------------///
            #endregion

            //this is from version 5 list
            #region Pre-Validations Kinjal
            /*
            //2) Equipment Breakdown &Other Perils
            // Windstorm and Hail Deductible
            // If Windstorm and Hail Deductible dropdown is left blank and Windstorm and Hail coverage is included
            // Cannot Rate the quote as Windstorm and Hail Deductible is invalid.

            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailDeductible)
            .ScalePrecision(4, 15).Must((modelObject, disasterExposureBuildingPoints) =>
             CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage,
                modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailDeductible)).
            WithMessage(Resources.ErrorMessages.InputPropertyWindstormAndHailDeductibleMissing);
            */

            //3)Equipment Breakdown &Other Perils
            //Windstorm and Hail Subject to Minimum Deductible -Other
            //When Other is selected as "Windstorm and Hail Subject to Minimum Deductible" and the Other textbox is left blank.	
            //Cannot Rate the quote as Windstorm and Hail Subject to Minimum Deductible-Other is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailSubjectToMinimumDeductibleOther)
                 .ScalePrecision(4, 15).Must((modelObject, disasterExposureBuildingPoints) =>
                         CheckCoveragePermitstringwithValue(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailSubjectToMinimumDeductible,
                                                             modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailSubjectToMinimumDeductibleOther, "OTHER")).
                 WithMessage(Resources.ErrorMessages.InputPropertyWindstormAndHailSubjectToMinimumDeductibleInvalid);
            });

            //4)Property->Equipment Breakdown & Other Perils
            //Flood Limit
            //If Flood Limit dropdown is left blank and Flood coverage is included
            //Cannot Rate the quote as Flood Limit is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodLimit)
                .ScalePrecision(4, 15).Must((modelObject, disasterExposureBuildingPoints) =>
                       CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodLimit))
                .WithMessage(Resources.ErrorMessages.InputPropertyFoodLimitMissing);
            });

            //5)Property->Equipment Breakdown & Other Perils
            //Flood Deductible
            //If Flood Deductible dropdown is left blank and Flood coverage is included
            //Cannot Rate the quote as Flood Deductible is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodDeductible)
                .ScalePrecision(4, 15).Must((modelObject, disasterExposureBuildingPoints) =>
                       CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodDeductible)).
                WithMessage(Resources.ErrorMessages.InputPropertyFoodDeductibleMissing);
            });

            //6)Property->Equipment Breakdown & Other Perils
            //Earthquake Limit
            //If Earthquake Limit dropdown is left blank and Earthquake coverage is included
            //Cannot Rate the quote as Earthquake Limit is invalid.
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeLimit)
                .ScalePrecision(4, 15).Must((modelObject, disasterExposureBuildingPoints) =>
                        CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeLimit)).
                WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeLimitMissing);

                //7)Property->Equipment Breakdown & Other Perils
                //Earthquake Deductible
                //If Earthquake Deductible dropdown is left blank and Earthquake coverage is included
                //Cannot Rate the quote as Earthquake Deductible is invalid.            
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeDeductible)
                .ScalePrecision(4, 15).Must((modelObject, disasterExposureBuildingPoints) =>
                        CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeDeductible)).
                WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeDeductibleMissing);
            });

            //8)Property->Equipment Breakdown & Other Perils
            //Earthquake Subject to Minimum Deductible -Other
            //When Other is selected as "Windstorm and Hail Subject to Minimum Deductible" and the Other textbox is left blank.	
            //Cannot Rate the quote as Earthquake Subject to Minimum Deductible-Other is invalid.
            //this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeSubjectToMinimumDeductibleOther)
            //   .ScalePrecision(4, 15).NotEqual(0).
            //   WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeDeductibleMissing);
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeSubjectToMinimumDeductibleOther)
                 .ScalePrecision(4, 15).Must((modelObject, disasterExposureBuildingPoints) =>
                         CheckCoveragePermitstringwithValue(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeSubjectToMinimumDeductible,
                                                            modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeSubjectToMinimumDeductibleOther, "OTHER")).
                 WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeSubjectToMinimumDeductibleInvalid);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeDeductible)
                  .ScalePrecision(4, 15).Must((modelObject, disasterExposureBuildingPoints) =>
                          CheckCoveragePermit(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeDeductible)).
                  WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeDeductibleMissing);
            });

            //AL, CO, DE, IL, IN, MA, MI, MN, NC, SC, TX, UT, VT, WY 
            string[] stateCheck1 = new string[14] { "AL", "CO", "DE", "IL", "IN", "MA", "MI", "MN", "NC", "SC", "TX", "UT", "VT", "WY" };

            When(reg => stateCheck1.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                //------------------------------------------Disaster Exposure starts from here----------------------------------///
                //9)Property->Hazard Points
                //A. Disaster Exposure Building Points
                //When Disaster Exposure Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Disaster Exposure Building Points is invalid.      "Read table "" Trident.HazardPoints"" to get the range of Minimum & Maximum value enterable for this field from column ""Deficiency Point Min"" & ""Deficiency Point Max"" respectively
                string stringDisasterExposureBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, disasterExposureBuildingPoints) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureBuildingPoints,
                                                           "Disaster Exposure",
                                                           null,
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureJustification,
                                                           modelObject,
                                                           out stringDisasterExposureBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringDisasterExposureBuildingPoints) ?
                                    stringDisasterExposureBuildingPoints :
                                    Resources.ErrorMessages.InputPropertyDisasterExposureBuildingPointsInvalid);

                //10)Property->Hazard Points
                //A. Disaster Exposure Content Points
                //When Disaster Exposure Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Disaster Exposure Content Points is invalid.
                string stringDisasterExposureContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, disasterExposureContentPoints) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureContentPoints,
                                                       "Disaster Exposure",
                                                       null,
                                                       modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureJustification,
                                                       modelObject,
                                                       out stringDisasterExposureContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringDisasterExposureContentPoints) ? stringDisasterExposureContentPoints : Resources.ErrorMessages.InputPropertyDisasterExposureContentPointsInvalid);


                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureContentPoints != 0 ||
                reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureBuildingPoints != 0) &&
                string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureJustification), () =>
                {
                    //11)Property->Hazard Points
                    //A. Disaster Exposure Justification When Disaster Exposure Building Points AND / OR Disaster Exposure Content Points is added AND Justification textfield is left blank
                    //Cannot Rate the quote as Disaster Exposure Justification is invalid.
                    //Display for States = AL, CO, DE, IL, IN, MA, MI, MN, NC, SC, TX, UT, VT, WY
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyDisasterExposureJustificationInvalid);
                });


                //------------------------------------------Hurricane starts from here----------------------------------///

                // 12) Property->Hazard Points
                // Hurricane Building Points
                //"Condition 1: When Hurricane Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Hurricane Building Points is invalid.		
                //"Read table "" Trident.HazardPoints"" to get the range of Minimum &Maximum value enterable for this field from column ""Deficiency Point Min"" & ""Deficiency Point Max"" respectively
                string stringClimaticalHazardsHurricaneBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints,
                                                         "Climatical Hazards",
                                                         "Hurricane",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneJustification,
                                                         modelObject,
                                                         out stringClimaticalHazardsHurricaneBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsHurricaneBuildingPoints) ?
                                                            stringClimaticalHazardsHurricaneBuildingPoints :
                                                            Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneBuildingPointsInvalid);

                //Condition 2: When Hurricane Building Points input value exist AND Wind & Hail Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                   .Equal(false)
                   .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneBuildingPointsInvalid);
                });

                // 13) Property->Hazard Points
                // Hurricane Content Points
                // "Condition 1: When input Hurricane Content Points is not within the Minimum & Maximum range
                // Cannot Rate the quote as Hurricane Content Points is invalid.
                string stringClimaticalHazardsHurricaneContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                        CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints,
                                                    "Climatical Hazards",
                                                    "Hurricane",
                                                    modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneJustification,
                                                    modelObject,
                                                    out stringClimaticalHazardsHurricaneContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsHurricaneContentPoints) ?
                                                            stringClimaticalHazardsHurricaneContentPoints :
                                                            Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneContentPointsInvalid);

                //Condition 2: When Hurricane Content Points input value exist AND Wind & Hail Coverage is excluded."
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints != 0), () =>
              {
                  this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                     .Equal(false)
                     .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneContentPointsInvalid);
              });


                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints != 0 ||
                            reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints != 0) &&
                            string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneJustification), () =>
                {
                    //14)Property->Hazard Points
                    //Hurricane Justification
                    //When Hurricane Building Points AND/ OR Hurricane Content Points is added AND Justification textfield is left blank
                    //Cannot Rate the quote as Hurricane Justification is invalid.
                    //Display for States = AL, CO, DE, IL, IN, MA, MI, MN, NC, SC, TX, UT, VT, WY
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneJustification)
                        .NotNull().WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneJustificationInvalid)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneJustificationInvalid);

                });

                //------------------------------------------Severe Convective starts from here----------------------------------///

                //15)Property->Hazard Points
                //Severe Convective Building Points
                //"Condition 1: When Severe Convective Building Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as Severe Convective Building Points is invalid.
                string stringClimaticalHazardsSevereConvectiveBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                        CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints,
                                                    "Climatical Hazards",
                                                    "Severe Convective",
                                                    modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveJustification,
                                                    modelObject,
                                                    out stringClimaticalHazardsSevereConvectiveBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsSevereConvectiveBuildingPoints) ?
                                        stringClimaticalHazardsSevereConvectiveBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveBuildingPointsInvalid);

                // Condition 2: When Severe Convective Building Points input value exist AND Wind &Hail Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                             reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints != 0), () =>
               {
                   this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                      .Equal(false)
                      .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveBuildingPointsInvalid);
               });

                //16)Property->Hazard Points
                //Severe Convective Content Points
                //"Condition 1:  When Severe Convective Content Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Severe Convective Building Points is invalid.
                string stringClimaticalHazardsSevereConvectiveContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                        CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints,
                                                    "Climatical Hazards",
                                                    "Severe Convective",
                                                    modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveJustification,
                                                    modelObject,
                                                    out stringClimaticalHazardsSevereConvectiveContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsSevereConvectiveContentPoints) ?
                                        stringClimaticalHazardsSevereConvectiveContentPoints :
                                        Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveContentPointsInvalid);

                // Condition 2: When Severe Convective Content Points input value exist AND Wind &Hail Coverage is excluded.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                        reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints != 0), () =>
                 {
                     this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveContentPointsInvalid);
                 });

                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints != 0 ||
                           reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints != 0) &&
                           string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveJustification), () =>
               {
                   //17)Property->Hazard Points
                   //Severe Convective Justification
                   //When Severe Convective Building Points AND/ OR Severe Convective Content Points is added AND Justification textfield is left blank
                   //Cannot Rate the quote as Severe Convective Justification is invalid.
                   this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveJustification)
                      .NotNull().WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveJustificationInvalid).NotEmpty()
                      .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveJustificationInvalid);
               });


                //------------------------------------------Winter Storm starts from here----------------------------------///

                //18)Property->Hazard Points
                //Winter Storm Building Points
                //"Condition 1: When Winter Storm Building Points input value is not within the Minimum & Maximum range
                // Condition 2: When Winter Storm Building Points input value exist AND Wind &Hail Coverage is excluded."	
                // Cannot Rate the quote as Winter Storm Building Points is invalid.
                string stringClimaticalHazardsWinterStormBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                        CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints,
                                                    "Climatical Hazards",
                                                    "Winter Storm",
                                                    modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormJustification,
                                                    modelObject,
                                                    out stringClimaticalHazardsWinterStormBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsWinterStormBuildingPoints) ?
                                                            stringClimaticalHazardsWinterStormBuildingPoints :
                                                            Resources.ErrorMessages.InputPropertyClimaticalHazardsWinterStormBuildingPointsInvalid);

                // Condition 2: When Winter Storm Building Points input value exist AND Wind &Hail Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
               reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints != 0), () =>
               {
                   this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                      .Equal(false)
                      .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsWinterStormBuildingPointsInvalid);
               });

                //19) Property->Hazard Points
                // Winter Storm Content Points
                // "Condition 1: When Winter Storm Content Points input value is not within the Minimum & Maximum range.
                //	Cannot Rate the quote as Winter Storm Content Points is invalid.
                string stringClimaticalHazardsWinterStormContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints,
                                                        "Climatical Hazards", "Winter Storm", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormJustification
                                                        , modelObject, out stringClimaticalHazardsWinterStormContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsWinterStormContentPoints) ? stringClimaticalHazardsWinterStormContentPoints : Resources.ErrorMessages.InputPropertyClimaticalHazardsWinterStormContentPointsInvalid);

                //  Condition 2: When Winter Storm Content Points input value exist AND Wind &Hail Coverage is excluded."
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                 reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints != 0), () =>
                 {
                     this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                    .Equal(false)
                    .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsWinterStormContentPointsInvalid);
                 });

                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints != 0 ||
               reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints != 0) &&
               string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormJustification), () =>
               {
                   //20)Property->Hazard Points
                   //Winter Storm Justification
                   //When Winter Storm Building Points AND/ OR Winter Storm Content Points is added AND Justification textfield is left blank
                   //Cannot Rate the quote as Winter Storm Justification is invalid.
                   this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormJustification)
                      .NotEmpty()
                      .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsWinterStormJustificationInvalid);
               });

                //21) Property->Hazard Points
                //All Other Building Points
                // When All Other Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as All Other Building Points is invalid.
                string stringClimaticalHazardsAllOtherBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, disasterExposureContentPoints) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints,
                                                        "Climatical Hazards",
                                                        "All Other",
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherJustification,
                                                        modelObject,
                                                        out stringClimaticalHazardsAllOtherBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsAllOtherBuildingPoints) ?
                                                            stringClimaticalHazardsAllOtherBuildingPoints :
                                                            Resources.ErrorMessages.InputPropertyClimaticalHazardsAllOtherBuildingPointsInvalid);

                //22) Property->Hazard Points
                // All Other Content Points
                // When All Other Content Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as All Other Content Points is invalid.
                string stringClimaticalHazardsAllOtherContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherContentPoints)
                     .ScalePrecision(4, 15)
                     .Must((modelObject, disasterExposureContentPoints) =>
                              CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherContentPoints,
                                                           "Climatical Hazards",
                                                           "All Other",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherJustification, modelObject,
                                                           out stringClimaticalHazardsAllOtherContentPoints))
                      .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsAllOtherContentPoints) ?
                                         stringClimaticalHazardsAllOtherContentPoints :
                                         Resources.ErrorMessages.InputPropertyClimaticalHazardsAllOtherContentPointsInvalid);

                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints != 0 ||
                      reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints != 0) &&
                      string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherJustification), () =>
                {
                    //23)Property->Hazard Points
                    //All Other Justification
                    //When All Other Building Points AND/ OR All Other Content Points is added AND Justification textfield is left blank
                    //Cannot Rate the quote as All Other Justification is invalid.
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyClimaticalHazardsAllOtherJustificationInvalid);
                });

                //24)Property->Hazard Points
                //B. Climatical Hazards Building Points Subtotal
                //When Climatical Hazards Building Points Subtotal value is not within the Minimum & Maximum range    
                //Error message -Rate the quote as Climatical Hazards Building Points Subtotal is invalid."	
                //Climatical Hazards Building Points Subtotal = Hurricane Building points + Severe Convective Building Points + Winter Storm Building points + All Other Building Points
                string stringClimaticalHazardsBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints
                             + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints
                             + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints
                             + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints
                             )
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                     CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints
                                                         + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints
                                                         + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints
                                                         + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints,
                                                    "Climatical Hazards",
                                                    "Parent line",
                                                    null,
                                                    modelObject,
                                                    out stringClimaticalHazardsBuildingPointsSubtotal))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsBuildingPointsSubtotal) ?
                                        stringClimaticalHazardsBuildingPointsSubtotal :
                                        Resources.ErrorMessages.InputPropertyClimaticalHazardsBuildingPointsSubtotalInvalid);

                //25)Property->Hazard Points
                //B. Climatical Hazards Content Points Subtotal
                //When Climatical Hazards Content Points Subtotal value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Climatical Hazards Content Points Subtotal is invalid.
                //Climatical Hazards Content Points Subtotal = Hurricane Content points +Severe Convective Content Points + Winter Storm Content points + All Other Content Points
                string stringClimaticalHazardsContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints
                             + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints
                             + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints
                             + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherContentPoints
                             )
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints
                                                                 + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints
                                                                 + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints
                                                                 + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherContentPoints,
                                                         "Climatical Hazards",
                                                         "Parent line",
                                                         null,
                                                         modelObject,
                                                         out stringClimaticalHazardsContentPointsSubtotal))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsContentPointsSubtotal) ?
                                        stringClimaticalHazardsContentPointsSubtotal :
                                        Resources.ErrorMessages.InputPropertyClimaticalHazardsContentPointsSubtotalInvalid);

                ///--------------------------------------------Occupancy Hazards Building Points---------------------------///

                //26)Property->Hazard Points
                //C. Occupancy Hazards Building Points
                //When Occupancy Hazards Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Occupancy Hazard Building Points is invalid.
                string stringOccupancyHazardsBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                          CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsBuildingPoints,
                                                        "Occupancy Hazards",
                                                        null,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsJustification,
                                                        modelObject,
                                                        out stringOccupancyHazardsBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringOccupancyHazardsBuildingPoints) ?
                                       stringOccupancyHazardsBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyOccupancyHazardsBuildingPointsInvalid);


                //27) Property->Hazard Points
                // C. Occupancy Hazards Content Points
                // When Occupancy Hazards Content Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as Occupancy Hazard Content Points is invalid.
                string stringOccupancyHazardsContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                          CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsContentPoints,
                                                        "Occupancy Hazards",
                                                        null,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsJustification,
                                                        modelObject,
                                                        out stringOccupancyHazardsContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringOccupancyHazardsContentPoints) ?
                                      stringOccupancyHazardsContentPoints :
                                      Resources.ErrorMessages.InputPropertyOccupancyHazardsContentPointsInvalid);

                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsContentPoints != 0 ||
                              reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsBuildingPoints != 0) &&
                              string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsJustification), () =>
                {
                    //28)Property->Hazard Points
                    //C. Occupancy Hazards Justification
                    //When Occupancy Hazards Building Points AND / OR Occupancy Hazards Content Points is added AND Justification textfield is left blank
                    //Cannot Rate the quote as Occupancy Hazards Justification is invalid.
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.OccupancyHazardsJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyOccupancyHazardsJustificationInvalid);
                });

                ///--------------------------------------------Lack of Private Protection Building Points---------------------------///

                //29)Property->Hazard Points
                //D. Lack of Private Protection Building Points
                //When Lack of Private Protection Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Lack of Private Protection Building Points is invalid.
                string stringLackofPrivateProtectionBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionBuildingPoints,
                                                        "Lack of Private Protection",
                                                        null,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionJustification,
                                                        modelObject,
                                                        out stringLackofPrivateProtectionBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringLackofPrivateProtectionBuildingPoints) ?
                                        stringLackofPrivateProtectionBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyLackofPrivateProtectionBuildingPointsInvalid);

                // 30) Property->Hazard Points
                // D. Lack of Private Protection Content Points
                // When Lack of Private Protection Content Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as Lack of Private Protection Content Points is invalid.
                string stringLackofPrivateProtectionContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionContentPoints)
                     .ScalePrecision(4, 15)
                     .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionContentPoints,
                                                           "Lack of Private Protection",
                                                            null,
                                                            modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionJustification,
                                                            modelObject,
                                                            out stringLackofPrivateProtectionContentPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringLackofPrivateProtectionContentPoints) ?
                                        stringLackofPrivateProtectionContentPoints :
                                        Resources.ErrorMessages.InputPropertyLackofPrivateProtectionContentPointsInvalid);

                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionBuildingPoints != 0 ||
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionContentPoints != 0) &&
                     string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionJustification), () =>
                 {
                     // 31)Property->Hazard Points
                     // D. Lack of Private Protection Justification
                     // When  Lack of Private Protection Building Points AND / OR  Lack of Private Protection Content Points is added AND Justification textfield is left blank
                     // Cannot Rate the quote as Lack of Private Protection Justification is invalid.
                     this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.LackofPrivateProtectionJustification)
                         .NotEmpty()
                         .WithMessage(Resources.ErrorMessages.InputPropertyLackofPrivateProtectionJustificationInvalid);
                 });

                #endregion

                #region Mamta On 19-July-2021
                //32)Property->Hazard Points
                //E. Amended Limit or Add'l Coverage Building Points	
                //When Amended Limit or Add'l Coverage Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Amended Limit or Add'l Coverage Building Points is invalid.
                string stringAmendedLimitorAddCoverageBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageBuildingPoints,
                                                          "Amended Limit or Add'l Coverage",
                                                           null,
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageJustification,
                                                           modelObject,
                                                           out stringAmendedLimitorAddCoverageBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringAmendedLimitorAddCoverageBuildingPoints) ?
                                       stringAmendedLimitorAddCoverageBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyAmendedLimitorAddCoverageBuildingPointsInvalid);

                // 33)Property -> Hazard Points
                // E. Amended Limit or Add'l Coverage Content Points
                //  When Amended Limit or Add'l Coverage Content Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as Amended Limit or Add'l Coverage Content Points is invalid.
                string stringAmendedLimitorAddCoverageContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageContentPoints)
                     .ScalePrecision(4, 15)
                     .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageContentPoints,
                                                           "Amended Limit or Add'l Coverage",
                                                           null,
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageJustification,
                                                           modelObject,
                                                           out stringAmendedLimitorAddCoverageContentPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringAmendedLimitorAddCoverageContentPoints) ?
                                        stringAmendedLimitorAddCoverageContentPoints :
                                        Resources.ErrorMessages.InputPropertyAmendedLimitContentPointsInvalid);

                //34)Property -> Hazard Points
                //E. Amended Limit or Add'l Coverage Justification
                // When  Lack of Private Protection Building Points AND / OR  Lack of Private Protection Content Points is added AND Justification textfield is left blank
                // Cannot Rate the quote as Lack of Private Protection Justification is invalid.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageContentPoints != 0 ||
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageContentPoints != 0) &&
                     string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageJustification), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.AmendedLimitorAddCoverageJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyAmendedLimitJustificationInvalid);
                });

                // 35 )Property -> Hazard Points
                //F. Inadequate Public Protection Building Points
                //When Inadequate Public Protection Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Inadequate Public Protection Building Points is invalid.
                string stringInadequatePublicProtectionBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionBuildingPoints,
                                                         "Inadequate Public Protection",
                                                         null,
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionJustification,
                                                         modelObject,
                                                         out stringInadequatePublicProtectionBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringInadequatePublicProtectionBuildingPoints) ?
                                        stringInadequatePublicProtectionBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyInadequatePublicProtectionBuildingPointsInvalid);

                //36 )Property -> Hazard Points
                //F. Inadequate Public Protection Content Points
                // When Content Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as Inadequate Public Protection Content Points is invalid.
                string stringInadequatePublicProtectionContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionContentPoints,
                                                         "Inadequate Public Protection",
                                                         null,
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionJustification,
                                                         modelObject,
                                                         out stringInadequatePublicProtectionContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringInadequatePublicProtectionContentPoints) ?
                                      stringInadequatePublicProtectionContentPoints :
                                      Resources.ErrorMessages.InputPropertyLackofInadequatePublicProtectionContentPointsInvalid);

                //37 )Property -> Hazard Points
                // F. Inadequate Public Protection Justification
                // When Inadequate Public Protection Building Points AND/OR Inadequate Public Protection Content Points is added AND Justification textfield is left blank
                // Cannot Rate the quote as Inadequate Public Protection Justification is invalid.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionContentPoints != 0 ||
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionContentPoints != 0) &&
                     string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionJustification), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.InadequatePublicProtectionJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyInadequatePublicProtectionJustificationInvalid);
                });

                //38 )Property -> Hazard Points
                //G. Extra External Exposure Building Points
                //When Extra External Exposure Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Extra External Exposure Building Points is invalid.
                string stringExtraExternalExposureBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                          CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureBuildingPoints,
                                                       "Extra External Exposure",
                                                       null,
                                                       modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureJustification,
                                                       modelObject,
                                                       out stringExtraExternalExposureBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringExtraExternalExposureBuildingPoints) ?
                                        stringExtraExternalExposureBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyExtraExternalExposureBuildingPointsInvalid);

                //39 )Property -> Hazard Points
                //G. Extra External Exposure Content Points
                // WhenExtra External Exposure Content Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Extra External Exposure Content Points is invalid.
                string stringExtraExternalExposureContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureContentPoints,
                                                        "Extra External Exposure",
                                                        null,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureJustification,
                                                        modelObject, out stringExtraExternalExposureContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringExtraExternalExposureContentPoints) ?
                                      stringExtraExternalExposureContentPoints :
                                      Resources.ErrorMessages.InputPropertyExtraExternalExposureContentPointsInvalid);

                //40 )Property -> Hazard Points
                // G. Extra External Exposure Justification
                // When Extra External Exposure Building Points AND/OR Extra External Exposure Content Points is added AND Justification textfield is left blank.
                // Cannot Rate the quote as Extra External Exposure Justification is invalid.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureBuildingPoints != 0 ||
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureContentPoints != 0) &&
                     string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureJustification), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExtraExternalExposureJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyExtraExternalExposureContentJustificationInvalid);
                });


                //41 )Property -> Hazard Points
                //H. Deficiency Construction Building Points
                //When Extra External Exposure Building Points AND/OR Extra External Exposure Content Points is added AND Justification textfield is left blank
                //Cannot Rate the quote as Extra External Exposure Justification is invalid.
                string stringDeficiencyConstructionBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionBuildingPoints,
                                                          "Deficiency Construction",
                                                          null,
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionJustification,
                                                          modelObject,
                                                          out stringDeficiencyConstructionBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringDeficiencyConstructionBuildingPoints) ? stringDeficiencyConstructionBuildingPoints : Resources.ErrorMessages.InputPropertyDeficiencyConstructionBuildingPointsInvalid);

                //42 )Property -> Hazard Points
                //H. Deficiency Construction Content Points
                // When Deficiency Construction Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Deficiency Construction Building Points is invalid.
                string stringDeficiencyConstructionContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionContentPoints,
                                                        "Deficiency Construction",
                                                        null,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionJustification,
                                                        modelObject,
                                                        out stringDeficiencyConstructionContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringDeficiencyConstructionContentPoints) ?
                                        stringDeficiencyConstructionContentPoints :
                                        Resources.ErrorMessages.InputPropertyDeficiencyConstructionContentPointsInvalid);

                //43 )Property -> Hazard Points
                // H. Deficiency Construction Justification
                //When Deficiency Construction Building Points AND/OR Deficiency Construction Content Points is added AND Justification textfield is left blank
                //Cannot Rate the quote as Deficiency Construction Justification is invalid.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionBuildingPoints != 0 ||
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionContentPoints != 0) &&
                     string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionJustification), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DeficiencyConstructionJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyDeficiencyConstructionJustificationInvalid);
                });

                //44 )Property -> Hazard Points
                //I. Unusual Combustion Building Points
                //When Unusual Combustion Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Unusual Combustion Building Points is invalid.
                string stringUnusualCombustionBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionBuildingPoints)
                  .ScalePrecision(4, 15)
                  .Must((modelObject, value) =>
                          CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionBuildingPoints,
                                                       "Unusual Combustion",
                                                       null,
                                                       modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionJustification,
                                                       modelObject,
                                                       out stringUnusualCombustionBuildingPoints))
                  .WithMessage(x => !string.IsNullOrEmpty(stringUnusualCombustionBuildingPoints) ?
                                     stringUnusualCombustionBuildingPoints :
                                     Resources.ErrorMessages.InputPropertyUnusualCombustionBuildingPointsInvalid);

                //45 )Property -> Hazard Points
                //I. Unusual Combustion Content Points
                //When Unusual Combustion Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Unusual Combustion Content Points is invalid.
                string stringUnusualCombustionContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionContentPoints,
                                                        "Unusual Combustion",
                                                        null,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionJustification,
                                                        modelObject,
                                                        out stringUnusualCombustionContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringUnusualCombustionContentPoints) ?
                                      stringUnusualCombustionContentPoints :
                                      Resources.ErrorMessages.InputPropertyUnusualCombustionContentPointsInvalid);

                //46 )Property -> Hazard Points
                // I. Unusual Combustion Justification
                //When Unusual Combustion Building Points AND/OR Unusual Combustion Content Points is added AND Justification textfield is left blank
                //Cannot Rate the quote as Unusual Combustion Justification is invalid.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionContentPoints != 0 ||
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionContentPoints != 0) &&
                     string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionJustification), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.UnusualCombustionJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyUnusualCombustionJustificationInvalid);
                });

                //47 )Property -> Hazard Points
                //J. Flood Exposure Building Points
                //Condition 1:When Flood Exposure Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Flood Exposure Building Points is invalid.
                string stringFloodExposureBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureBuildingPoints,
                                                         "Flood Exposure",
                                                         null,
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureJustification,
                                                         modelObject,
                                                         out stringFloodExposureBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringFloodExposureBuildingPoints) ?
                                        stringFloodExposureBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyFloodExposureBuildingPointsInvalid);

                //Condition 2:When Flood Exposure Building Points input value exist AND Flood Coverage is excluded.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureBuildingPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                       .Equal(false)
                       .WithMessage(Resources.ErrorMessages.InputPropertyFloodExposureBuildingPointsInvalid);
                });

                //48 )Property -> Hazard Points
                //J. Flood Exposure Content Points
                //Condition 1:  When Flood Exposure Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Flood Exposure Content Points is invalid.
                string stringFloodExposureContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureContentPoints,
                                                        "Flood Exposure",
                                                        null,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureJustification,
                                                        modelObject,
                                                        out stringFloodExposureContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringFloodExposureContentPoints) ?
                                        stringFloodExposureContentPoints :
                                        Resources.ErrorMessages.InputPropertyFloodExposureContentPointsInvalid);

                //Condition 2:When Flood Exposure Content Points input value exist AND Flood Coverage is excluded.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureContentPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                       .Equal(false)
                       .WithMessage(Resources.ErrorMessages.InputPropertyFloodExposureContentPointsInvalid);

                });

                //49 )Property -> Hazard Points
                // J. Flood Exposure Justification
                // When  Lack of Private Protection Building Points AND / OR  Lack of Private Protection Content Points is added AND Justification textfield is left blank
                // Cannot Rate the quote as Lack of Private Protection Justification is invalid.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureContentPoints != 0 ||
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureContentPoints != 0) &&
                     string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureJustification), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodExposureJustificationInvalid);
                });

                //50 )Property -> Hazard Points
                //K. Earthquake Exposure Building Points
                //Condition 1:When Earthquake Exposure Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Earthquake Exposure Building Points is invalid.
                string stringEarthquakeExposureBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureBuildingPoints,
                                                        "Earthquake Exposure",
                                                        null,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureJustification,
                                                        modelObject,
                                                        out stringEarthquakeExposureBuildingPoints))
                    .WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeExposureBuildingPointsInvalid);

                //Condition 2:When Earthquake Exposure Building Points input value exist AND Flood Coverage is excluded.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == false &&
                reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureBuildingPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                        .Equal(false)
                        .WithMessage(x => !string.IsNullOrEmpty(stringEarthquakeExposureBuildingPoints) ? stringEarthquakeExposureBuildingPoints : Resources.ErrorMessages.InputPropertyEarthquakeExposureBuildingPointsInvalid);
                });

                //51 )Property -> Hazard Points
                //K. Earthquake Exposure Content Points
                //Condition 1:When Earthquake Exposure Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Earthquake Exposure Content Points is invalid.
                string stringEarthquakeExposureContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodExposureContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureContentPoints,
                                                        "Earthquake Exposure",
                                                        null,
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureJustification,
                                                        modelObject,
                                                        out stringEarthquakeExposureContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringEarthquakeExposureContentPoints) ?
                                        stringEarthquakeExposureContentPoints :
                                        Resources.ErrorMessages.InputPropertyEarthquakeExposureContentPointsInvalid);

                //Condition 2:When Earthquake Exposure Content Points input value exist AND Flood Coverage is excluded.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureContentPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                       .Equal(false)
                       .WithMessage(x => !string.IsNullOrEmpty(stringEarthquakeExposureContentPoints) ? stringEarthquakeExposureContentPoints : Resources.ErrorMessages.InputPropertyEarthquakeExposureContentPointsInvalid);

                });

                //52 )Property -> Hazard Points
                // K. Earthquake Exposure Justification
                //When Earthquake Exposure Building Points AND/OR Earthquake Exposure Content Points is added AND Justification textfield is left blank
                //Cannot Rate the quote as Earthquake Exposure Justification is invalid.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureContentPoints != 0 ||
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureContentPoints != 0) &&
                     string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureJustification), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeExposureJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyEarthquakeExposureJustificationInvalid);
                });

                //53 )Property -> Hazard Points
                //L. Excluded or Reduced Coverage Building Points
                //When Excluded or Reduced Coverage Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Excluded or Reduced Coverage Building Points is invalid.
                string stringExcludedOrReducedCoverageBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageBuildingPoints,
                                                         "Excluded or Reduced Coverage",
                                                         null,
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageJustification,
                                                         modelObject,
                                                         out stringExcludedOrReducedCoverageBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringExcludedOrReducedCoverageBuildingPoints) ?
                                       stringExcludedOrReducedCoverageBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyExcludedOrReducedCoverageBuildingPointsInvalid);

                //54 )Property -> Hazard Points
                //L. Excluded or Reduced Coverage Content Points
                //When Excluded or Reduced Coverage Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Excluded or Reduced Coverage Content Points is invalid.
                string stringExcludedOrReducedCoverageContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                         CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageContentPoints,
                                                      "Excluded or Reduced Coverage",
                                                      null,
                                                      modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageJustification,
                                                      modelObject,
                                                      out stringExcludedOrReducedCoverageContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringExcludedOrReducedCoverageContentPoints) ?
                                      stringExcludedOrReducedCoverageContentPoints :
                                      Resources.ErrorMessages.InputPropertyExcludedOrReducedCoverageContentPointsInvalid);

                //55 )Property -> Hazard Points
                // L. Excluded or Reduced Coverage Justification
                //When Excluded or Reduced Coverage Building Points AND/OR Excluded or Reduced Coverage Content Points is added AND Justification textfield is left blank
                //Cannot Rate the quote as Excluded or Reduced Coverage Justification is invalid.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageContentPoints != 0 ||
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageContentPoints != 0) &&
                     string.IsNullOrEmpty(reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageJustification), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExcludedorReducedCoverageJustification)
                        .NotEmpty()
                        .WithMessage(Resources.ErrorMessages.InputPropertyExcludedOrReducedCoverageJustificationInvalid);
                });
                //TODO 56 -57 No Validation

                #endregion

            });

            // CT, GA, KS, ME, MS, MO, NH, OH, PA  
            string[] stateCheck2 = new string[9] { "CT", "GA", "KS", "ME", "MS", "MO", "NH", "OH", "PA" };

            When(reg => stateCheck2.Contains(reg.RaterInputFacadeModel.PolicyHeaderModel.State), () =>
            {
                #region Mamta 21-07-2021
                //58 )Property -> Hazard Points
                //Dispersion Building Points
                //When Dispersion Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Dispersion Building Points  is invalid.
                string stringPropertyDispersionBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureDispersionBuildingPoints)
                      .ScalePrecision(4, 15)
                      .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureDispersionBuildingPoints,
                                                          "Disaster Exposure",
                                                          "Dispersion",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureDispersionJustification,
                                                          modelObject,
                                                          out stringPropertyDispersionBuildingPoints))
                      .WithMessage(x => !string.IsNullOrEmpty(stringPropertyDispersionBuildingPoints) ?
                                         stringPropertyDispersionBuildingPoints :
                                         Resources.ErrorMessages.InputPropertyDispersionBuildingPointsInvalid);

                //59 )Property -> Hazard Points
                //Dispersion Content Points
                //When Dispersion Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Dispersion Content Points is invalid.
                string stringDispersionContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureDispersionContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                          CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureDispersionContentPoints,
                                                        "Disaster Exposure",
                                                        "Dispersion",
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureDispersionJustification,
                                                        modelObject,
                                                        out stringDispersionContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringDispersionContentPoints) ?
                                      stringDispersionContentPoints :
                                      Resources.ErrorMessages.InputPropertyDispersionContentPointsInvalid);

                //60 )Property -> Hazard Points
                //PML Building Points
                //When PML Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as PML Building Points is invalid.
                string stringPMLBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLBuildingPoints)
                      .ScalePrecision(4, 15)
                      .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLBuildingPoints,
                                                          "Disaster Exposure",
                                                          "PML",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLJustification,
                                                          modelObject,
                                                          out stringPMLBuildingPoints))
                      .WithMessage(x => !string.IsNullOrEmpty(stringPMLBuildingPoints) ?
                                          stringPMLBuildingPoints :
                                          Resources.ErrorMessages.InputPropertyPMLBuildingPointsInvalid);

                //61 )Property -> Hazard Points
                //PML Content Points
                //When PML Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as PML Content Points is invalid.
                string stringPMLContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLContentPoints,
                                                       "Disaster Exposure", "PML", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLJustification, modelObject, out stringPMLContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringPMLContentPoints) ?
                                      stringPMLContentPoints :
                                      Resources.ErrorMessages.InputPropertyPMLContentPointsInvalid);

                //62 )Property -> Hazard Points
                //A. Disaster Exposure Building Points Subtotal
                //When Disaster Exposure Building Points subtotal is not within the Minimum & Maximum range
                //Cannot Rate the quote as Disaster Exposure Building Points Subtotal is invalid.
                string stringDisasterExposurePoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureBuildingPoints
                             + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLBuildingPoints)
                      .ScalePrecision(4, 15)
                      .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureDispersionBuildingPoints
                                                         + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLBuildingPoints,
                                                         "Disaster Exposure",
                                                         "Parent Line",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLJustification,
                                                         modelObject,
                                                         out stringDisasterExposurePoints))
                      .WithMessage(x => !string.IsNullOrEmpty(stringDisasterExposurePoints) ?
                                         stringDisasterExposurePoints :
                                         Resources.ErrorMessages.InputPropertyDisasterExposureBuildingPointsInvalid);

                //63 )Property -> Hazard Points
                //Disaster Exposure Content Points Subtotal
                //When Disaster Exposure Content Points subtotal is not within the Minimum & Maximum range
                //Cannot Rate the quote as Disaster Exposure Content Points Subtotal is invalid.
                string stringDisasterExposureBuildingContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureDispersionContentPoints
                                    + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                          CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposureDispersionContentPoints
                                                         + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.DisasterExposurePMLContentPoints,
                                                       "Disaster Exposure",
                                                       "Parent Line",
                                                       null,
                                                       modelObject,
                                                       out stringDisasterExposureBuildingContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringDisasterExposureBuildingContentPoints) ?
                                        stringDisasterExposureBuildingContentPoints :
                                        Resources.ErrorMessages.InputPropertyDisasterExposureBuildingContentPointsInvalid);

                //66)Property->Hazard Points
                //Severe Convective Building Points
                //"Condition 1: When Severe Convective Building Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as Severe Convective Building Points is invalid.
                string stringSevereConvectiveBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints,
                                                         "Climatical Hazards",
                                                         "Severe Convective",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveJustification,
                                                         modelObject,
                                                         out stringSevereConvectiveBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringSevereConvectiveBuildingPoints) ?
                                        stringSevereConvectiveBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveBuildingPointsInvalid);

                // Condition 2: When Severe Convective Building Points input value exist AND Wind &Hail Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                      reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                        .Equal(false)
                        .WithMessage(x => !string.IsNullOrEmpty(stringSevereConvectiveBuildingPoints) ? stringSevereConvectiveBuildingPoints : Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveBuildingPointsInvalid);
                });

                //67)Property->Hazard Points
                //Severe Convective Content Points
                //"Condition 1:  When Severe Convective Content Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Severe Convective Building Points is invalid.
                string stringSevereConvectiveContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints,
                                                          "Climatical Hazards",
                                                          "Severe Convective",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveJustification,
                                                          modelObject,
                                                          out stringSevereConvectiveContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringSevereConvectiveContentPoints) ?
                                       stringSevereConvectiveContentPoints :
                                       Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveBuildingPointsInvalid);

                // Condition 2: When Severe Convective Content Points input value exist AND Wind &Hail Coverage is excluded.
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                      reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                        .Equal(false)
                        .WithMessage(x => !string.IsNullOrEmpty(stringSevereConvectiveContentPoints) ?
                                           stringSevereConvectiveContentPoints :
                                           Resources.ErrorMessages.InputPropertyClimaticalHazardsSevereConvectiveContentPointsInvalid);
                });

                //68) Property->Hazard Points
                // Winter Storm Building Points
                //"Condition 1: When Winter Storm Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Winter Storm Building Points is invalid.		
                //"Read table ""Trident.HazardPoints"" to get the range of Minimum &Maximum value enterable for this field from column ""Deficiency Point Min"" & ""Deficiency Point Max"" respectively
                string stringWinterStormBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints,
                                                         "Climatical Hazards",
                                                         "Winter Storm",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormJustification,
                                                         modelObject,
                                                         out stringWinterStormBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringWinterStormBuildingPoints) ?
                                       stringWinterStormBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyClimaticalHazardsWinterStormBuildingPointsInvalid);

                //Condition 2: When Winter Storm Building Points input value exist AND Wind & Hail Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                    reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                        .Equal(false)
                        .WithMessage(x => !string.IsNullOrEmpty(stringWinterStormBuildingPoints) ? stringWinterStormBuildingPoints : Resources.ErrorMessages.InputPropertyClimaticalHazardsWinterStormBuildingPointsInvalid);
                });

                //69) Property->Hazard Points
                // Winter Storm Content Points
                // "Condition 1: When Winter Storm Content Points input value is not within the Minimum & Maximum range.
                //	Cannot Rate the quote as Winter Storm Content Points is invalid.
                string stringWinterStormContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints,
                                                         "Climatical Hazards",
                                                         "Winter Storm",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormJustification,
                                                         modelObject,
                                                         out stringWinterStormContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringWinterStormContentPoints) ?
                                       stringWinterStormContentPoints :
                                       Resources.ErrorMessages.InputPropertyClimaticalHazardsWinterStormContentPointsInvalid);

                //  Condition 2: When Winter Storm Content Points input value exist AND Wind &Hail Coverage is excluded."
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                    .Equal(false)
                    .WithMessage(x => !string.IsNullOrEmpty(stringWinterStormContentPoints) ? stringWinterStormContentPoints : Resources.ErrorMessages.InputPropertyClimaticalHazardsWinterStormContentPointsInvalid);
                });

                //70) Property->Hazard Points
                //All Other Building Points
                // When All Other Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as All Other Building Points is invalid.
                string stringOtherBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, disasterExposureContentPoints) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints,
                                                           "Climatical Hazards",
                                                           "All Other",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherJustification,
                                                           modelObject,
                                                           out stringOtherBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringOtherBuildingPoints) ?
                                        stringOtherBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyClimaticalHazardsAllOtherBuildingPointsInvalid);

                //71) Property->Hazard Points
                // All Other Content Points
                // When All Other Content Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as All Other Content Points is invalid.
                string stringOtherContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, disasterExposureContentPoints) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherContentPoints,
                                                          "Climatical Hazards",
                                                          "All Other",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherJustification,
                                                          modelObject,
                                                          out stringOtherContentPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringOtherContentPoints) ?
                                        stringOtherContentPoints :
                                        Resources.ErrorMessages.InputPropertyClimaticalHazardsAllOtherContentPointsInvalid);

                //72 )Property -> Hazard Points
                //B.Climatical Hazards Building Points Subtotal
                //When Climatical Hazards Building Points subtotal is not within the Minimum & Maximum range
                //Cannot Rate the quote as Climatical Hazards Building Points Subtotal is invalid.
                string stringClimaticalHazardsBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints
                            + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints
                            + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints
                            + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints
                            )
                      .ScalePrecision(4, 15)
                      .Must((modelObject, value) =>
                              CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints
                                                                + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveBuildingPoints
                                                                + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormBuildingPoints
                                                                + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherBuildingPoints,
                                                            "Climatical Hazards",
                                                            "Parent line",
                                                            null,
                                                            modelObject,
                                                            out stringClimaticalHazardsBuildingPoints))
                      .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsBuildingPoints) ?
                                         stringClimaticalHazardsBuildingPoints :
                                         Resources.ErrorMessages.InputPropertyClimaticalHazardsBuildingPointsInvalid);

                //73 )Property -> Hazard Points
                //B. Climatical Hazards Content Points Subtotal
                // When Climatical Hazards Content Points subtotal is not within the Minimum & Maximum range
                // Cannot Rate the quote as Climatical Hazards Content Points Subtotal is invalid.
                string stringClimaticalHazardsContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherContentPoints
                                )
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsSevereConvectiveContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsWinterStormContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsAllOtherContentPoints,
                                                        "Climatical Hazards",
                                                        "Parent line",
                                                        null,
                                                        modelObject,
                                                        out stringClimaticalHazardsContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringClimaticalHazardsContentPoints) ?
                                        stringClimaticalHazardsContentPoints :
                                        Resources.ErrorMessages.InputPropertyClimaticalContentPointsInvalid);

                //74)Property->Hazard Points
                //Hazards Building Points	
                //When Hazards Building Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Hazards Building Points is invalid.
                string stringHazardsBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsBuildingPoints,
                                                         "Special Occupancy",
                                                         "Hazards",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsJustification,
                                                         modelObject,
                                                         out stringHazardsBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringHazardsBuildingPoints) ?
                                        stringHazardsBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyHazardsBuildingPointsPointsInvalid);


                //75)Property->Hazard Points
                //Hazards Content Points
                //When Hazards Content Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Hazards Content Points is invalid.
                string stringHazardsContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsContentPoints,
                                                          "Special Occupancy",
                                                          "Hazards",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsJustification,
                                                          modelObject,
                                                          out stringHazardsContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringHazardsContentPoints) ?
                                        stringHazardsContentPoints :
                                        Resources.ErrorMessages.InputPropertyHazardsContentPointsPointsInvalid);

                //76)Property->Hazard Points
                //Processing Building Points
                //When Processing Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Processing Building Points is invalid.
                string stringProcessingBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                    CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingBuildingPoints,
                    "Special Occupancy", "Processing", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingJustification, modelObject, out stringProcessingBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringProcessingBuildingPoints) ? stringProcessingBuildingPoints : Resources.ErrorMessages.InputPropertyProcessingBuildingPointsInvalid);

                // 77 )Property -> Hazard Points
                //Processing Contents Points
                //When Processing Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Processing Content Points is invalid.
                string stringProcessingContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingContentPoints,
                                                         "Special Occupancy",
                                                         "Processing",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingJustification,
                                                         modelObject,
                                                         out stringProcessingContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringProcessingContentPoints) ?
                                       stringProcessingContentPoints :
                                       Resources.ErrorMessages.InputPropertyProcessingContentPointsInvalid);

                // 78 )Property -> Hazard Points
                //Business Income PML Building Points
                //When Business Income PML Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Business Income PML Building Points is invalid.
                string stringBusinessIncomePMLBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLBuildingPoints,
                                                        "Special Occupancy",
                                                        "Business Income PML",
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLJustification,
                                                        modelObject,
                                                        out stringBusinessIncomePMLBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringBusinessIncomePMLBuildingPoints) ?
                                        stringBusinessIncomePMLBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyBusinessIncomePMLBuildingPointsInvalid);

                //79 )Property -> Hazard Points
                //Business Income PML Content Points
                //When Business Income PML Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Business Income PML Content Points is invalid.
                string stringBusinessIncomePMLContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLContentPoints,
                                                          "Special Occupancy",
                                                          "Business Income PML",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLJustification,
                                                          modelObject,
                                                          out stringBusinessIncomePMLContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringBusinessIncomePMLContentPoints) ?
                                       stringBusinessIncomePMLContentPoints :
                                       Resources.ErrorMessages.InputPropertyBusinessIncomePMLContentPointsInvalid);


                //80)Property -> Hazard Points	
                //Number of Occupants Building Points	
                //When Number of Occupants Building Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Number of Occupants Building Points is invalid.
                string stringNumberOfOccupantsBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsBuildingPoints,
                                                          "Special Occupancy",
                                                          "Number of Occupants",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsJustification,
                                                          modelObject,
                                                          out stringNumberOfOccupantsBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringNumberOfOccupantsBuildingPoints) ?
                                       stringNumberOfOccupantsBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyNumberOfOccupantsBuildingPointsInvalid);

                //81 )Property -> Hazard Points
                //Number of Occupants Content points
                //When Number of Occupants Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Number of Occupants Content Points is invalid.
                string stringNumberOfOccupantsContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsContentPoints)
                     .ScalePrecision(4, 15)
                     .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsContentPoints,
                                                           "Special Occupancy",
                                                           "Number of Occupants",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsJustification,
                                                           modelObject,
                                                           out stringNumberOfOccupantsContentPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringNumberOfOccupantsContentPoints) ?
                                        stringNumberOfOccupantsContentPoints : Resources.ErrorMessages.InputPropertyNumberOfOccupantsContentPointsInvalid);

                //82 )Property -> Hazard Points
                //C. Special Occupancy Building Points Subtotal
                //When Special Occupancy Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Special Occupancy  Content Points Subtotal is invalid.
                string stringSpecialOccupancyBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsBuildingPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsBuildingPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingBuildingPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLBuildingPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsBuildingPoints,
                                                        "Special Occupancy",
                                                        "Parent line",
                                                        null,
                                                        modelObject,
                                                        out stringSpecialOccupancyBuildingPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringSpecialOccupancyBuildingPoints) ?
                                      stringSpecialOccupancyBuildingPoints :
                                      Resources.ErrorMessages.InputPropertySpecialOccupancyBuildingPointsSubtotalInvalid);

                //83)Property -> Hazard Points
                //C. Special Occupancy Content Points Subtotal	
                //When Special Occupancy Content Points subtotal is not within the Minimum & Maximum range
                //Cannot Rate the quote as Special Occupancy  Content Points Subtotal is invalid.
                string stringSpecialOccupancyContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsContentPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyHazardsContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyProcessingContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyBusinessIncomePMLContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecialOccupancyNumberofOccupantsContentPoints,
                                                        "Special Occupancy",
                                                        "Parent line",
                                                        null,
                                                        modelObject,
                                                        out stringSpecialOccupancyContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringSpecialOccupancyContentPoints) ?
                                      stringSpecialOccupancyContentPoints :
                                      Resources.ErrorMessages.InputPropertySpecialOccupancyContentPointsSubtotalInvalid);

                //84)Property -> Hazard Points
                //Fire Suppression Building Points
                //When Fire Suppression Building Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Fire Suppression Building Points is invalid.
                string stringFireSuppressionBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionBuildingPoints,
                                                          "Private Protection",
                                                          "Fire Suppression",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionJustification,
                                                          modelObject,
                                                          out stringFireSuppressionBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringFireSuppressionBuildingPoints) ?
                                        stringFireSuppressionBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyFireSuppressionBuildingPointsInvalid);

                //85 )Property -> Hazard Points
                //Fire Suppression Content Points
                //When Fire Suppression Content Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Fire Suppression Content Points is invalid.
                string stringFireSuppressionContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionContentPoints)
                     .ScalePrecision(4, 15)
                     .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionContentPoints,
                                                           "Private Protection",
                                                           "Fire Suppression",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionJustification,
                                                           modelObject,
                                                           out stringFireSuppressionContentPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringFireSuppressionContentPoints) ?
                                        stringFireSuppressionContentPoints :
                                        Resources.ErrorMessages.InputPropertyFireSuppressionContentPointsInvalid);

                //86)Property -> Hazard Points
                //Fire Protection Building Points
                //When Fire Protection Building Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Fire Protection Building Points is invalid.
                string stringFireProtectionBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionBuildingPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireProtectionBuildingPoints,
                                                        "Private Protection",
                                                        "Fire Protection",
                                                        modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireProtectionJustification,
                                                        modelObject,
                                                        out stringFireProtectionBuildingPoints))
                  .WithMessage(x => !string.IsNullOrEmpty(stringFireProtectionBuildingPoints) ?
                                     stringFireProtectionBuildingPoints :
                                     Resources.ErrorMessages.InputPropertyFireProtectionBuildingPointsInvalid);

                //87 )Property -> Hazard Points
                //Fire Protection Content Points
                //When Fire Protection Content Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Fire Protection Content Points is invalid.
                string stringFireProtectionContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireProtectionContentPoints)
                 .ScalePrecision(4, 15)
                 .Must((modelObject, value) =>
                         CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireProtectionContentPoints,
                                                       "Private Protection",
                                                       "Fire Protection",
                                                       modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireProtectionJustification,
                                                       modelObject,
                                                       out stringFireProtectionContentPoints))
                 .WithMessage(x => !string.IsNullOrEmpty(stringFireProtectionContentPoints) ?
                                    stringFireProtectionContentPoints :
                                    Resources.ErrorMessages.InputPropertyFireProtectionContentPointsInvalid);

                //88)Property -> Hazard Points
                //Central Monitoring Building Points
                //When Central Monitoring Building Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Central Monitoring Building Points is invalid.
                string stringCentralMonitoringBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringBuildingPoints,
                                                          "Private Protection",
                                                          "Central Monitoring",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringJustification,
                                                          modelObject,
                                                          out stringCentralMonitoringBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringCentralMonitoringBuildingPoints) ?
                                       stringCentralMonitoringBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyCentralMonitoringBuildingPointsInvalid);

                //89 )Property -> Hazard Points
                //Central Monitoring Content Points
                //When Central Monitoring Content Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Central Monitoring Content Points is invalid.
                string stringCentralMonitoringContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringContentPoints)
                     .ScalePrecision(4, 15)
                     .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringContentPoints,
                                                           "Private Protection",
                                                           "Central Monitoring",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringJustification,
                                                           modelObject,
                                                           out stringCentralMonitoringContentPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringCentralMonitoringContentPoints) ?
                                        stringCentralMonitoringContentPoints :
                                        Resources.ErrorMessages.InputPropertyCentralMonitoringContentPointsInvalid);

                //90)Property -> Hazard Points
                //D. Private Protection Building Points Subtotal	
                //When Private Protection Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Private Protection Building Points Subtotal is invalid.
                string stringPrivateProtectionBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireProtectionBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringBuildingPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionBuildingPoints
                                                                + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireProtectionBuildingPoints
                                                                + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringBuildingPoints,
                                                         "Private Protection",
                                                         "Parent line",
                                                         null,
                                                         modelObject,
                                                         out stringPrivateProtectionBuildingPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringPrivateProtectionBuildingPoints) ?
                                      stringPrivateProtectionBuildingPoints :
                                      Resources.ErrorMessages.InputPropertyPrivateProtectionBuildingPointsSubtotalInvalid);

                //91)Property -> Hazard Points
                //D. Private Protection Content Points Subtotal	
                //When Private Protection Content Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Private Protection Content Points Subtotal is invalid.
                string stringPrivateProtectionContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireProtectionContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringContentPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireSuppressionContentPoints
                                                                + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionFireProtectionContentPoints
                                                                + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PrivateProtectionCentralMonitoringContentPoints,
                                                           "Private Protection",
                                                           "Parent line",
                                                           null,
                                                           modelObject,
                                                           out stringPrivateProtectionContentPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringPrivateProtectionContentPoints) ?
                                      stringPrivateProtectionContentPoints :
                                      Resources.ErrorMessages.InputPropertyPrivateProtectionContentPointsSubtotalInvalid);

                //92)Property -> Hazard Points
                //Specific Insurance Building Points
                //When Specific Insurance Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Specific Insurance Building Points is invalid.
                string stringSpecificInsuranceBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceBuildingPoints,
                                                          "Specific Insurance",
                                                          "Specific Insurance",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceJustification,
                                                          modelObject,
                                                          out stringSpecificInsuranceBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringSpecificInsuranceBuildingPoints) ?
                                        stringSpecificInsuranceBuildingPoints : Resources.ErrorMessages.InputPropertySpecificInsuranceBuildingPointsInvalid);

                //93)Property -> Hazard Points
                //Specific Insurance Content Points
                //When Specific Insurance Content Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Specific Insurance Content Points is invalid.
                string stringSpecificInsuranceContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceContentPoints,
                                                          "Specific Insurance",
                                                          "Specific Insurance",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceJustification,
                                                          modelObject,
                                                          out stringSpecificInsuranceContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringSpecificInsuranceContentPoints) ?
                                       stringSpecificInsuranceContentPoints :
                                       Resources.ErrorMessages.InputPropertySpecificInsuranceContentPointsInvalid);

                //94)Property -> Hazard Points
                //E. Specific Insurance Building Points Subtotal	
                //When Specific Insurance Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Specific Insurance Building Points Subtotal is invalid.
                string stringSpecificInsuranceBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceBuildingPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceBuildingPoints,
                                                         "Specific Insurance",
                                                         "Parent line",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceJustification,
                                                         modelObject,
                                                         out stringSpecificInsuranceBuildingPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringSpecificInsuranceBuildingPointsSubtotal) ?
                                      stringSpecificInsuranceBuildingPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertySpecificInsuranceBuildingPointsSubtotalInvalid);

                //95)Property -> Hazard Points
                //E. Specific Insurance Content Points Subtotal	
                //When Specific Insurance Content Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Specific Insurance Content Points Subtotal is invalid.
                string stringSpecificInsuranceContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceContentPoints,
                                                         "Specific Insurance",
                                                         "Parent line",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpecificInsuranceJustification,
                                                         modelObject,
                                                         out stringSpecificInsuranceContentPointsSubtotal))
                    .WithMessage(x => !string.IsNullOrEmpty(stringSpecificInsuranceContentPointsSubtotal) ?
                                        stringSpecificInsuranceContentPointsSubtotal :
                                        Resources.ErrorMessages.InputPropertySpecificInsuranceContentPointsSubtotalInvalid);


                //96)Property -> Hazard Points
                //Low Hazard Building Points
                //When Low Hazard Building Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Low Hazard Building Points is invalid.
                string stringLowHazardBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardBuildingPoints,
                                                           "Public Protection",
                                                           "Low Hazard",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardJustification,
                                                           modelObject,
                                                           out stringLowHazardBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringLowHazardBuildingPoints) ?
                                       stringLowHazardBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyLowHazardBuildingPointsInvalid);

                //97)Property -> Hazard Points
                //Low Hazard Content Points
                //When Low Hazard Content Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Low Hazard Content Points is invalid.
                string stringLowHazardContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardContentPoints,
                                                          "Public Protection",
                                                          "Low Hazard",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardJustification,
                                                          modelObject,
                                                          out stringLowHazardContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringLowHazardContentPoints) ?
                                       stringLowHazardContentPoints :
                                       Resources.ErrorMessages.InputPropertyLowHazardContentPointsInvalid);

                //98)Property -> Hazard Points
                //Medium Hazard Building Points
                //When Medium Hazard Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Medium Hazard Building Points is invalid.
                string stringMediumHazardBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardBuildingPoints,
                                                          "Public Protection",
                                                          "Medium Hazard",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardJustification,
                                                          modelObject,
                                                          out stringMediumHazardBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringMediumHazardBuildingPoints) ?
                                       stringMediumHazardBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyMediumHazardBuildingPointsInvalid);

                //99)Property -> Hazard Points
                //Medium Hazard Content Points
                //When Medium Hazard Content Points input value is not within the Minimum & Maximum range.
                //Cannot Rate the quote as Medium Hazard Content Points is invalid.
                string stringMediumHazardContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardContentPoints,
                                                          "Public Protection",
                                                          "Medium Hazard",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardJustification,
                                                          modelObject,
                                                          out stringMediumHazardContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringMediumHazardContentPoints) ?
                                       stringMediumHazardContentPoints :
                                       Resources.ErrorMessages.InputPropertyMediumHazardContentPointsInvalid);

                //100)Property -> Hazard Points
                //High Hazard Building Points	
                //When High Hazard Building Points input value is not within the Minimum & Maximum range	
                //Cannot Rate the quote as High Hazard Building Points is invalid.
                string stringHighHazardBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardBuildingPoints)
                  .ScalePrecision(4, 15)
                  .Must((modelObject, value) =>
                  CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardBuildingPoints,
                 "Public Protection", "High Hazard", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardJustification, modelObject, out stringHighHazardBuildingPoints))
                 .WithMessage(x => !string.IsNullOrEmpty(stringHighHazardBuildingPoints) ?
                                    stringHighHazardBuildingPoints :
                                    Resources.ErrorMessages.InputPropertyHighHazardBuildingPointsInvalid);

                //101)Property -> Hazard Points
                //High Hazard Content Points	
                //When High Hazard Content Points input value is not within the Minimum & Maximum range	
                //Cannot Rate the quote as High Hazard Content Points is invalid.
                string stringHighHazardContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardContentPoints)
                     .ScalePrecision(4, 15)
                     .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardContentPoints,
                                                           "Public Protection",
                                                           "High Hazard",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardJustification,
                                                           modelObject,
                                                           out stringHighHazardContentPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringHighHazardContentPoints) ?
                                        stringHighHazardContentPoints :
                                        Resources.ErrorMessages.InputPropertyHighHazardContentPointsInvalid);


                //102)Property -> Hazard Points
                //F. Public Protection Building Points Subtotal	
                //When Public Protection Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Public Protection Building Points Subtotal is invalid.
                string stringPublicProtectionBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardBuildingPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardBuildingPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardBuildingPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardBuildingPoints,
                                                         "Private Protection",
                                                         "Parent line",
                                                         null,
                                                         modelObject,
                                                         out stringPublicProtectionBuildingPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringPublicProtectionBuildingPointsSubtotal) ?
                                      stringPublicProtectionBuildingPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyPublicProtectionBuildingPointsSubtotalInvalid);

                //103)Property -> Hazard Points
                //F. Public Protection Content Points Subtotal	
                //When Public Protection Content Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Public Protection Content Points Subtotal is invalid.
                string stringPublicProtectionContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardContentPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionLowHazardContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionMediumHazardContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PublicProtectionHighHazardContentPoints,
                                                        "Private Protection",
                                                        "Parent line",
                                                        null,
                                                        modelObject,
                                                        out stringPublicProtectionContentPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringPublicProtectionContentPointsSubtotal) ?
                                      stringPublicProtectionContentPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyPublicProtectionContentPointsSubtotalInvalid);

                #endregion
                #region 20-07-2021

                ///--------------------------------------------External Exposure Building Points---------------------------///

                //104) Property->Hazard Points
                //External Exposure Building Points
                //When External Exposure Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as External Exposure Building Points is invalid.
                string stringExternalExposureBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureBuildingPoints,
                                                          "External Exposure",
                                                          "External Exposure",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureJustification,
                                                          modelObject,
                                                          out stringExternalExposureBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringExternalExposureBuildingPoints) ?
                                       stringExternalExposureBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyExternalExposureBuildingPointsInvalid);


                //105) Property->Hazard Points
                //External Exposure Content Points
                //When External Exposure Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as External Exposure Content Points is invalid.
                string stringExternalExposureContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureContentPoints,
                                                         "External Exposure", "External Exposure",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureJustification,
                                                         modelObject,
                                                         out stringExternalExposureContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringExternalExposureContentPoints) ?
                                       stringExternalExposureContentPoints :
                                       Resources.ErrorMessages.InputPropertyExternalExposureContentPointsInvalid);


                //106)Property->Hazard Points
                //Separation Building Points
                //When Separation Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Separation Building Points is invalid.
                string stringSeparationBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationBuildingPoints)
                     .ScalePrecision(4, 15)
                     .Must((modelObject, value) =>
                             CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationBuildingPoints,
                                                           "External Exposure",
                                                           "Separation",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationJustification,
                                                           modelObject,
                                                           out stringSeparationBuildingPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringSeparationBuildingPoints) ?
                                        stringSeparationBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyExternalExposureSeparationBuildingPointsInvalid);

                //107)Property->Hazard Points
                //Separation Content Points
                //When Separation Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Separation Content Points is invalid.
                string stringSeparationContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationContentPoints,
                                                         "External Exposure",
                                                         "Separation",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationJustification,
                                                         modelObject,
                                                         out stringSeparationContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringSeparationContentPoints) ?
                                       stringSeparationContentPoints :
                                       Resources.ErrorMessages.InputPropertyExternalExposureSeparationContentPointsInvalid);

                //108)Property -> Hazard Points
                //G. External Exposure Building Points Subtotal
                //When External Exposure Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as External Exposure Building Points Subtotal is invalid.
                string stringExternalExposureBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationBuildingPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureBuildingPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationBuildingPoints,
                                                         "External Exposure",
                                                         "Parent line",
                                                         null,
                                                         modelObject,
                                                         out stringExternalExposureBuildingPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringExternalExposureBuildingPointsSubtotal) ?
                                      stringExternalExposureBuildingPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyExternalExposureBuildingPointsSubtotalInvalid);

                //109)Property -> Hazard Points
                //G. External Exposure Content Points Subtotal
                //When External Exposure Content Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as External Exposure Content Points Subtotal is invalid.
                string stringExternalExposureContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationContentPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExternalExposureSeparationContentPoints,
                                                           "External Exposure",
                                                           "Parent line",
                                                           null,
                                                           modelObject,
                                                           out stringExternalExposureContentPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringExternalExposureContentPointsSubtotal) ?
                                      stringExternalExposureContentPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyExternalExposureContentPointsSubtotalInvalid);

                //----------------------Construction------------------------------------//


                //110)Property->Hazard Points
                //Construction Building Points
                //When Construction Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Construction Building Points is invalid.
                string stringConstructionBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionBuildingPoints,
                                                            "Construction",
                                                            "Construction",
                                                            modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionJustification,
                                                            modelObject,
                                                            out stringConstructionBuildingPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringConstructionBuildingPoints) ?
                                         stringConstructionBuildingPoints :
                                         Resources.ErrorMessages.InputPropertyExternalConstructionBuildingPointsInvalid);

                //111)Property->Hazard Points
                //Construction Content Points
                //When Construction Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Construction Content Points is invalid.
                string stringConstructionContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                    CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionContentPoints,
                    "Construction", "Construction", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionJustification, modelObject, out stringConstructionContentPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringConstructionContentPoints) ? stringConstructionContentPoints : Resources.ErrorMessages.InputPropertyConstructionContentPointsInvalid);

                //112)Property->Hazard Points
                //Engineering Building Points
                //When Engineering Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Engineering Building Points is invalid.
                string stringEngineeringBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringBuildingPoints,
                                                           "Construction",
                                                           "Engineering",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringJustification, modelObject, out stringEngineeringBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringEngineeringBuildingPoints) ?
                                        stringEngineeringBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyConstructionEngineeringBuildingPointsInvalid);

                //113)Property->Hazard Points
                //Engineering Content Points
                //When Engineering Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Engineering Content Points is invalid.
                string stringEngineeringContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringContentPoints,
                                                           "Construction",
                                                           "Engineering",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringJustification,
                                                           modelObject,
                                                           out stringEngineeringContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringEngineeringContentPoints) ?
                                        stringEngineeringContentPoints :
                                        Resources.ErrorMessages.InputPropertyConstructionEngineeringContentPointsInvalid);

                //114)Property->Hazard Points
                //Attraction Value Building Points
                //When Attraction Value Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Attraction Value Building Points is invalid.
                string stringAttractionValueBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueBuildingPoints,
                                                           "Construction",
                                                           "Attraction Value",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueJustification,
                                                           modelObject,
                                                           out stringAttractionValueBuildingPoints))
                     .WithMessage(x => !string.IsNullOrEmpty(stringAttractionValueBuildingPoints) ?
                                        stringAttractionValueBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyConstructionAttractionValueBuildingPointsInvalid);


                // 115) Property->Hazard Points
                // Attraction Value Content Points
                // When Attraction Value Content Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as Attraction Value Content Points is invalid.
                string stringAttractionValueContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueContentPoints,
                                                           "Construction",
                                                           "Attraction Value",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueJustification,
                                                           modelObject,
                                                           out stringAttractionValueContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringAttractionValueContentPoints) ?
                                        stringAttractionValueContentPoints :
                                        Resources.ErrorMessages.InputPropertyConstructionAttractionValueContentPointsInvalid);

                //116)Property -> Hazard Points
                //H. Construction Building Points Sub total	
                //When  Construction Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Construction  Building Points Subtotal is invalid.
                string stringConstructionBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringBuildingPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueBuildingPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionBuildingPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringBuildingPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueBuildingPoints,
                                                           "Construction",
                                                           "Parent line",
                                                           null, modelObject,
                                                           out stringConstructionBuildingPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringConstructionBuildingPointsSubtotal) ?
                                      stringConstructionBuildingPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyConstructionBuildingPointsSubtotalInvalid);

                //117)Property -> Hazard Points
                //H. Construction Content Points Sub total	
                //When  Construction Content Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as  Construction  Content Points Subtotal is invalid.
                string stringConstructionContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringContentPoints
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueContentPoints
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionEngineeringContentPoints
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ConstructionAttractionValueContentPoints,
                                                           "Construction",
                                                           "Parent line",
                                                           null,
                                                           modelObject,
                                                           out stringConstructionContentPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringConstructionContentPointsSubtotal) ?
                                      stringConstructionContentPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyConstructionContentPointsSubtotalInvalid);

                //118)Property->Hazard Points
                //Commodities Building Points
                //When Commodities Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Commodities Building Points is invalid.
                string stringCommoditiesBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesBuildingPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesBuildingPoints,
                                                         "Commodities",
                                                         "Commodities",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesJustification,
                                                         modelObject,
                                                          out stringCommoditiesBuildingPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringCommoditiesBuildingPoints) ?
                                      stringCommoditiesBuildingPoints :
                                      Resources.ErrorMessages.InputPropertyCommoditiesBuildingPointsInvalid);

                //119)Property->Hazard Points
                //Commodities Content Points
                //When Commodities Content Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Commodities Content Points is invalid.
                string stringCommoditiesContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesContentPoints,
                                                           "Commodities",
                                                           "Commodities",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesJustification,
                                                           modelObject,
                                                           out stringCommoditiesContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringCommoditiesContentPoints) ?
                                       stringCommoditiesContentPoints :
                                       Resources.ErrorMessages.InputPropertyCommoditiesContentPointsInvalid);


                //120)Property -> Hazard Points
                //I. Commodities Building Points Subtotal	
                //When Commodities Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Commodities Building Points Subtotal is invalid.
                string stringCommoditiesBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesBuildingPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesBuildingPoints,
                                                          "Commodities",
                                                          "Parent line",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesJustification,
                                                          modelObject,
                                                          out stringCommoditiesBuildingPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringCommoditiesBuildingPointsSubtotal) ?
                                      stringCommoditiesBuildingPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyCommoditiesBuildingPointsSubtotalInvalid);

                //121)Property -> Hazard Points
                //I. Commodities Content Points Subtotal	
                //When Commodities Content Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Commodities Content Points Subtotal is invalid.
                string stringCommoditiesContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesContentPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesContentPoints,
                                                         "Commodities",
                                                         "Parent line",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.CommoditiesJustification,
                                                         modelObject,
                                                         out stringCommoditiesContentPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringCommoditiesContentPointsSubtotal) ?
                                      stringCommoditiesContentPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyCommoditiesContentPointsSubtotalInvalid);


                //-------------------------------------FloodCoveredZone-----------------------------------------
                // 122) Property->Hazard Points
                // Covered Zone Building Points
                // "Condition 1: When Covered zone Building Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Building Points is invalid.
                string stringFloodCoveredZoneBuildingPoints1 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints1)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints1,
                                                         "Flood",
                                                         "Covered Zone",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification1,
                                                         modelObject, out stringFloodCoveredZoneBuildingPoints1))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneBuildingPoints1) ?
                                       stringFloodCoveredZoneBuildingPoints1 :
                                       Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);

                // Condition 2: When Covered Zone Building Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints1 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);
                });


                //123) Property->Hazard Points
                // Covered Zone Content Points
                // "Condition 1: When Covered zone Content Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Content Points is invalid.
                string stringFloodCoveredZoneContentPoints1 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints1)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints1,
                                                         "Flood",
                                                         "Covered Zone",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification1,
                                                         modelObject,
                                                         out stringFloodCoveredZoneContentPoints1))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints1) ?
                                       stringFloodCoveredZoneContentPoints1 :
                                       Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);

                // Condition 2: When Covered Zone Content Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints1 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);
                });

                //---------------------------------FloodCoveredZone2------------------------------------
                // 124) Property->Hazard Points
                // Covered Zone Building Points
                // "Condition 1: When Covered zone Building Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Building Points is invalid.
                string stringFloodCoveredZoneBuildingPoints2 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints2)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints2,
                                                         "Flood",
                                                         "Covered Zone",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification2,
                                                         modelObject,
                                                         out stringFloodCoveredZoneBuildingPoints2))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneBuildingPoints2) ?
                                      stringFloodCoveredZoneBuildingPoints2 :
                                      Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);

                // Condition 2: When Covered Zone Building Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints2 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);
                });


                //125) Property->Hazard Points
                // Covered Zone Content Points
                // "Condition 1: When Covered zone Content Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Content Points is invalid.
                string stringFloodCoveredZoneContentPoints2 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints2)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints2,
                                                         "Flood",
                                                         "Covered Zone",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification2,
                                                         modelObject,
                                                         out stringFloodCoveredZoneContentPoints2))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints2) ?
                                      stringFloodCoveredZoneContentPoints2 :
                                      Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);

                // Condition 2: When Covered Zone Content Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                      reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints2 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);
                });

                //---------------------------------FloodCoveredZone3------------------------------------
                // 126) Property->Hazard Points
                // Covered Zone Building Points
                // "Condition 1: When Covered zone Building Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Building Points is invalid.
                string stringCoveredZoneBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints3)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints3,
                                                         "Flood",
                                                         "Covered Zone",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification3,
                                                         modelObject,
                                                         out stringCoveredZoneBuildingPoints))
                   .WithMessage(x => !string.IsNullOrEmpty(stringCoveredZoneBuildingPoints) ?
                                      stringCoveredZoneBuildingPoints :
                                      Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);

                // Condition 2: When Covered Zone Building Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                       reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints3 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(x => !string.IsNullOrEmpty(stringCoveredZoneBuildingPoints) ? stringCoveredZoneBuildingPoints : Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);
                });


                //127) Property->Hazard Points
                // Covered Zone Content Points
                // "Condition 1: When Covered zone Content Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Content Points is invalid.
                string stringFloodCoveredZoneContentPoints3 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints3)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints3,
                                                         "Flood",
                                                         "Covered Zone",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification3,
                                                         modelObject,
                                                         out stringFloodCoveredZoneContentPoints3))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints3) ?
                                       stringFloodCoveredZoneContentPoints3 :
                                       Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);

                // Condition 2: When Covered Zone Content Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints3 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);
                });

                //---------------------------------FloodCoveredZone4------------------------------------
                // 128) Property->Hazard Points
                // Covered Zone Building Points
                // "Condition 1: When Covered zone Building Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Building Points is invalid.
                string stringFloodCoveredZoneBuildingPoints4 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints4)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints4,
                                                         "Flood", "Covered Zone", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification4, modelObject,
                                                          out stringFloodCoveredZoneBuildingPoints4))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneBuildingPoints4) ?
                                      stringFloodCoveredZoneBuildingPoints4 :
                                      Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);

                // Condition 2: When Covered Zone Building Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints4 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);
                });


                //129) Property->Hazard Points
                // Covered Zone Content Points
                // "Condition 1: When Covered zone Content Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Content Points is invalid.
                string stringFloodCoveredZoneContentPoints4 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints4)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints4,
                                                          "Flood",
                                                          "Covered Zone",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification4,
                                                          modelObject,
                                                          out stringFloodCoveredZoneContentPoints4))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints4) ?
                                      stringFloodCoveredZoneContentPoints4 :
                                      Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);

                // Condition 2: When Covered Zone Content Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints4 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);
                });

                //---------------------------------FloodCoveredZone5------------------------------------
                // 130) Property->Hazard Points
                // Covered Zone Building Points
                // "Condition 1: When Covered zone Building Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Building Points is invalid.
                string stringFloodCoveredZoneBuildingPoints5 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints5)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints5,
                                                           "Flood",
                                                           "Covered Zone",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification5,
                                                           modelObject,
                                                           out stringFloodCoveredZoneBuildingPoints5))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneBuildingPoints5) ?
                                      stringFloodCoveredZoneBuildingPoints5 :
                                      Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);

                // Condition 2: When Covered Zone Building Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints5 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodCoveredZoneBuildingPointsInvalid);
                });


                //131) Property->Hazard Points
                // Covered Zone Content Points
                // "Condition 1: When Covered zone Content Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Covered Zone Content Points is invalid.
                string stringFloodCoveredZoneContentPoints5 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints5)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints5,
                                                          "Flood",
                                                          "Covered Zone",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneJustification5,
                                                          modelObject,
                                                          out stringFloodCoveredZoneContentPoints5))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodCoveredZoneContentPoints5) ?
                                      stringFloodCoveredZoneContentPoints5 :
                                      Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);

                // Condition 2: When Covered Zone Content Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints5 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyFloodCoveredZoneContentPointsInvalid);
                });

                //132)Property -> Hazard Points
                //J. Flood Building Points Subtotal
                //When Flood Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Flood Building Points Subtotal is invalid
                string stringFloodBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints1
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints2
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints3
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints4
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints5
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints1
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints2
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints3
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints4
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneBuildingPoints5,
                                                           "Flood",
                                                           "Parent line",
                                                           null,
                                                           modelObject,
                                                           out stringFloodBuildingPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodBuildingPointsSubtotal) ?
                                       stringFloodBuildingPointsSubtotal :
                                       Resources.ErrorMessages.InputPropertyFloodBuildingPointsSubtotalInvalid);

                //133)Property -> Hazard Points
                //J. Flood Content Points Subtotal	
                //When Flood Content Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Flood Content Points Subtotal is invalid.
                string stringFloodContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints1
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints2
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints3
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints4
                                + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints5
                                )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints1
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints2
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints3
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints4
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.FloodCoveredZoneContentPoints5,
                                                           "Flood",
                                                           "Parent line",
                                                           null,
                                                           modelObject,
                                                           out stringFloodContentPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringFloodContentPointsSubtotal) ?
                                      stringFloodContentPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyFloodContentPointsSubtotalInvalid);

                //------------------------------

                //---------------------------------EarthMovementTerritory1------------------------------------
                //134) Property->Hazard Points
                //Territory Building Points
                //"Condition 1 When Territory Building Points input value is not within the Minimum & Maximum range
                //Cannot Rate the quote as Territory Building Points is invalid.
                string stringEarthMovementTerritoryBuildingPoints1 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints1)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints1,
                                                         "Earth Movement",
                                                         "Territory",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryJustification1,
                                                          modelObject,
                                                          out stringEarthMovementTerritoryBuildingPoints1))
                   .WithMessage(!string.IsNullOrEmpty(stringEarthMovementTerritoryBuildingPoints1) ?
                                      stringEarthMovementTerritoryBuildingPoints1 :
                                      Resources.ErrorMessages.InputPropertyEarthMovementTerritoryBuildingPointsInvalid);

                //Condition 2: When Territory Building Points input value exist AND Earthquake Coverage is excluded."
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints1 != 0), () =>
                     {
                         this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage)
                             .Equal(false)
                             .WithMessage(Resources.ErrorMessages.InputPropertyEarthMovementTerritoryBuildingPointsInvalid);
                     });


                // 135)Property->Hazard Points
                //Territory Conten Points
                //"Condition 1 When Territory Content Points input value is not within the Minimum & Maximum range
                //Condition 2: When Territory Content Points input value exist AND Earthquake Coverage is excluded."	
                //Cannot Rate the quote as Territory Content Points is invalid.
                string stringEarthMovementTerritoryContentPoints1 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints1)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints1,
                                                          "Earth Movement",
                                                          "Territory",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryJustification1,
                                                          modelObject,
                                                          out stringEarthMovementTerritoryContentPoints1))
                   .WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementTerritoryContentPoints1) ?
                                      stringEarthMovementTerritoryContentPoints1 :
                                      Resources.ErrorMessages.InputPropertyEarthMovementTerritoryContentPointsInvalid);

                // Condition 2: When Covered Zone Content Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints1 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyEarthMovementTerritoryContentPointsInvalid);
                });

                //---------------------------------EarthMovementTerritory1------------------------------------
                // 136)Property->Hazard Points
                // Territory Building Points
                // "Condition 1 When Territory Building Points input value is not within the Minimum & Maximum range
                // Condition 2: When Territory Building Points input value exist AND Earthquake Coverage is excluded."	
                // Cannot Rate the quote as Territory Building Points is invalid.
                string stringEarthMovementTerritoryBuildingPoints2 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints2)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints2,
                                                          "Earth Movement",
                                                          "Territory",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryJustification2,
                                                          modelObject,
                                                          out stringEarthMovementTerritoryBuildingPoints2))
                   .WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementTerritoryBuildingPoints2) ?
                                      stringEarthMovementTerritoryBuildingPoints2 :
                                      Resources.ErrorMessages.InputPropertyEarthMovementTerritoryBuildingPointsInvalid);

                //Condition 2: When Territory Building Points input value exist AND Earthquake Coverage is excluded."
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints2 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyEarthMovementTerritoryBuildingPointsInvalid);
                });


                // 137)Property->Hazard Points
                //Territory Conten Points
                //"Condition 1 When Territory Content Points input value is not within the Minimum & Maximum range
                //Condition 2: When Territory Content Points input value exist AND Earthquake Coverage is excluded."	
                //Cannot Rate the quote as Territory Content Points is invalid.
                string stringEarthMovementTerritoryContentPoints2 = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints2)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints2,
                                                         "Earth Movement",
                                                         "Territory",
                                                         modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryJustification2,
                                                         modelObject,
                                                         out stringEarthMovementTerritoryContentPoints2))
                   .WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementTerritoryContentPoints2) ?
                                      stringEarthMovementTerritoryContentPoints2 :
                                      Resources.ErrorMessages.InputPropertyEarthMovementTerritoryContentPointsInvalid);

                // Condition 2: When Covered Zone Content Points input value exist AND Flood Coverage is excluded."	
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints2 != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyEarthMovementTerritoryContentPointsInvalid);
                });


                //  ----------------------------------------Limit-------------------------------------------------------------------
                //138) ->Hazard Points
                //Limit Building Points
                //"Condition 1: When Limit Building Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Limit Building Points is invalid
                string stringEarthMovementLimitBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                              CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitBuildingPoints,
                                                            "Earth Movement",
                                                            "Limit",
                                                            modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitJustification,
                                                            modelObject,
                                                            out stringEarthMovementLimitBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementLimitBuildingPoints) ?
                                        stringEarthMovementLimitBuildingPoints :
                                        Resources.ErrorMessages.InputPropertyEarthMovementLimitBuildingPointInvalid);

                // Condition 2: When Limit Building Points input value exist AND Earthquake Coverage is excluded"
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitBuildingPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyEarthMovementLimitBuildingPointInvalid);
                });

                //139) ->Hazard Points
                //Limit Content Points
                //"Condition 1: When Limit Content Points input value is not within the Minimum & Maximum range.
                // Cannot Rate the quote as Limit Content Points is invalid.
                string stringEarthMovementLimitContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitContentPoints)
                  .ScalePrecision(4, 15)
                  .Must((modelObject, value) =>
                          CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitContentPoints,
                                                         "Earth Movement",
                                                         "Limit",
                                                          modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitJustification,
                                                          modelObject,
                                                          out stringEarthMovementLimitContentPoints))
                  .WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementLimitContentPoints) ?
                                     stringEarthMovementLimitContentPoints :
                                     Resources.ErrorMessages.InputPropertyEarthMovementLimitContentPointsInvalid);

                // Condition 2: When Limit Content Points input value exist AND Earthquake Coverage is excluded"
                When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage == false &&
                     reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitContentPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthquakeCoverage)
                        .Equal(false)
                        .WithMessage(Resources.ErrorMessages.InputPropertyEarthMovementLimitContentPointsInvalid);
                });

                //140)Property -> Hazard Points
                //K. Earth Movement Building Points Subtotal	
                //When Earth Movement Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Earth Movement Building Points Subtotal is invalid.
                string stringEarthMovementBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints1
                                    + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints2
                                    + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitBuildingPoints
                                    )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints1
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryBuildingPoints2
                                                            + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitBuildingPoints,
                                                           "Earth Movement",
                                                           "Parent line",
                                                           null,
                                                           modelObject,
                                                           out stringEarthMovementBuildingPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementBuildingPointsSubtotal) ?
                                      stringEarthMovementBuildingPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyEarthMovementBuildingPointsSubtotalInvalid);

                //141)Property -> Hazard Points
                //K. Earth Movement Content Points Subtotal	
                //When Earth Movement Content Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Earth Movement Content Points Subtotal is invalid.
                string stringEarthMovementContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints1
                                    + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints2
                                    + reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitContentPoints
                                    )
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints1
                                                                + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementTerritoryContentPoints2
                                                                + modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.EarthMovementLimitContentPoints,
                                                            "Earth Movement",
                                                            "Parent line",
                                                            null,
                                                            modelObject,
                                                            out stringEarthMovementContentPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringEarthMovementContentPointsSubtotal) ?
                                       stringEarthMovementContentPointsSubtotal :
                                       Resources.ErrorMessages.InputPropertyEarthMovementContentPointsSubtotalInvalid);

                //  ----------------------------------------Exclusion or Reduction of Coverage Building Points-------------------------------------------------------------------

                //142) Property->Hazard Points
                // Exclusion or Reduction of Coverage Building Points	
                // When Exclusion or Reduction of Coverage Building Points input value is not within the Minimum & Maximum range	
                // Cannot Rate the quote as Exclusion or Reduction of Coverage Building Points is invalid.
                string stringExclusionorReductionofCoverageBuildingPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageBuildingPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageBuildingPoints,
                                                           "Exclusion or Reduction of Coverage",
                                                           "Exclusion or Reduction of Coverage",
                                                            modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageJustification,
                                                            modelObject,
                                                            out stringExclusionorReductionofCoverageBuildingPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringExclusionorReductionofCoverageBuildingPoints) ?
                                       stringExclusionorReductionofCoverageBuildingPoints :
                                       Resources.ErrorMessages.InputPropertyExclusionorReductionofCoverageBuildingPointsInvalid);

                //143) Property->Hazard Points
                // Exclusion or Reduction of Coverage Content Points
                // When Exclusion or Reduction of Coverage Content Points input value is not within the Minimum & Maximum range
                // Cannot Rate the quote as Exclusion or Reduction of Coverage Content Points is invalid.
                string stringExclusionorReductionofCoverageContentPoints = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageContentPoints)
                    .ScalePrecision(4, 15)
                    .Must((modelObject, value) =>
                            CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageContentPoints,
                                                           "Exclusion or Reduction of Coverage",
                                                           "Exclusion or Reduction of Coverage",
                                                           modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageJustification,
                                                           modelObject,
                                                           out stringExclusionorReductionofCoverageContentPoints))
                    .WithMessage(x => !string.IsNullOrEmpty(stringExclusionorReductionofCoverageContentPoints) ?
                                       stringExclusionorReductionofCoverageContentPoints :
                                       Resources.ErrorMessages.InputPropertyExclusionorReductionofCoverageContentPointsInvalid);

                //144)Property -> Hazard Points
                //L. Exclusion or Reduction of Coverage Building Points Subtotal	
                //When Exclusion or Reduction of Coverage Building Points subtotal is not within the Minimum & Maximum range	
                //Cannot Rate the quote as Exclusion or Reduction of Coverage Building Points Subtotal is invalid.
                string stringExclusionorReductionofCoverageBuildingPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageBuildingPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageBuildingPoints,
                                                         "Exclusion or Reduction of Coverage",
                                                         "Parent line",
                                                         null,
                                                         modelObject,
                                                         out stringExclusionorReductionofCoverageBuildingPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringExclusionorReductionofCoverageBuildingPointsSubtotal) ?
                                      stringExclusionorReductionofCoverageBuildingPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyExclusionOrReductionOfCoverageBuildingPointsSubtotalInvalid);

                //145)Property -> Hazard Points
                // L.Exclusion or Reduction of Coverage Content Points Subtotal
                // When Exclusion or Reduction of Coverage Content Points subtotal is not within the Minimum & Maximum range
                // Cannot Rate the quote as Exclusion or Reduction of Coverage Content Points Subtotal is invalid.
                string stringExclusionorReductionofCoverageContentPointsSubtotal = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageBuildingPoints)
                   .ScalePrecision(4, 15)
                   .Must((modelObject, value) =>
                           CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ExclusionorReductionofCoverageBuildingPoints,
                                                         "Exclusion or Reduction of Coverage",
                                                         "Parent line",
                                                         null,
                                                         modelObject,
                                                         out stringExclusionorReductionofCoverageContentPointsSubtotal))
                   .WithMessage(x => !string.IsNullOrEmpty(stringExclusionorReductionofCoverageContentPointsSubtotal) ?
                                      stringExclusionorReductionofCoverageContentPointsSubtotal :
                                      Resources.ErrorMessages.InputPropertyExclusionOrReductionOfCoverageContentPointsSubtotalInvalid);
                #endregion
            });

            // 64) Property->Hazard Points
            // Hurricane Building Points
            //"Condition 1: When Hurricane Building Points input value is not within the Minimum & Maximum range
            //Cannot Rate the quote as Hurricane Building Points is invalid.		
            //"Read table "" Trident.HazardPoints"" to get the range of Minimum &Maximum value enterable for this field from column ""Deficiency Point Min"" & ""Deficiency Point Max"" respectively
            string stringHurricaneBuildingPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints)
                .ScalePrecision(4, 15)
                .Must((modelObject, value) =>
                CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints,
                "Climatical Hazards", "Hurricane", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneJustification, modelObject, out stringHurricaneBuildingPoints))
                .WithMessage(x => !string.IsNullOrEmpty(stringHurricaneBuildingPoints) ? stringHurricaneBuildingPoints : Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneBuildingPointsInvalid);
            //Condition 2: When Hurricane Building Points input value exist AND Wind & Hail Coverage is excluded."	
            When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneBuildingPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                       .Equal(false)
                       .WithMessage(x => !string.IsNullOrEmpty(stringHurricaneBuildingPoints) ? stringHurricaneBuildingPoints : Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneBuildingPointsInvalid);
                });

            // 65) Property->Hazard Points
            // Hurricane Content Points
            // "Condition 1: When input Hurricane Content Points is not within the Minimum & Maximum range
            // Cannot Rate the quote as Hurricane Content Points is invalid.
            string stringHurricaneContentPoints = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints)
               .ScalePrecision(4, 15)
               .Must((modelObject, value) =>
               CheckForMinMaxValueForHazard(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints,
               "Climatical Hazards", "Hurricane", modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneJustification, modelObject, out stringHurricaneContentPoints))
               .WithMessage(x => !string.IsNullOrEmpty(stringHurricaneContentPoints) ? stringHurricaneContentPoints : Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneContentPointsInvalid);

            //Condition 2: When Hurricane Content Points input value exist AND Wind & Hail Coverage is excluded."
            When(reg => (reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage == false &&
                reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ClimaticalHazardsHurricaneContentPoints != 0), () =>
                {
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.WindstormAndHailCoverage)
                        .Equal(false)
                        .WithMessage(x => !string.IsNullOrEmpty(stringHurricaneContentPoints) ? stringHurricaneContentPoints : Resources.ErrorMessages.InputPropertyClimaticalHazardsHurricaneContentPointsInvalid);

                });

            #region Manu's Code

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel != null && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel != null, () =>
            {

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel != null
                && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel.Count > 0, () =>
                {
                    //168)Property 360-> Optional
                    //Vacancy Permit Limit	
                    //If Vacancy Permit coverage is selected but Limit is NOT entered.
                    //Cannot Rate the quote as Vacancy Permit Limit is invalid.
                    string message360OptionalCoverageVacancyPermitsInputModelVacancyPermitLimit = Resources.ErrorMessages.Property360OptionalCoverageInputModelVacancyPermitsInputModelVacancyPermitLimitMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel[0].VacancyPermitLimit)
                               .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                           Check360CoverageVacancyPermitLimit(modelObject, ref message360OptionalCoverageVacancyPermitsInputModelVacancyPermitLimit))
                           .WithMessage(x => message360OptionalCoverageVacancyPermitsInputModelVacancyPermitLimit);


                    //169)Property 360-> Optional
                    //Vacancy Permit Deductible	
                    //If Vacancy Permit Deductible is selected but Deductible is NOT entered.
                    //Cannot Rate the quote as Vacancy Permit Deductible is invalid.
                    string message360OptionalCoverageVacancyPermitsInputModelVacancyPermitDeductible = Resources.ErrorMessages.Property360OptionalCoverageInputModelVacancyPermitsInputModelVacancyPermitDeductibleMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel)
                                 .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                           Check360CoverageVacancyPermitDeductible(modelObject, ref message360OptionalCoverageVacancyPermitsInputModelVacancyPermitDeductible))
                           .WithMessage(x => message360OptionalCoverageVacancyPermitsInputModelVacancyPermitDeductible);


                    //170) Property 360-> Optional	
                    //Vacancy Permit Loc	
                    //If Vacancy Permit coverage is selected but Loc is NOT entered.
                    //Cannot Rate the quote as Vacancy Permit Loc is invalid. 
                    string messagePhysicalDamageLoc = Resources.ErrorMessages.Property360OptionalCoverageInputModelVacancyPermitsInputModelVacancyPermitLocationMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel)
                           .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                           Check360CoverageVacancyPermitLocation(modelObject, ref messagePhysicalDamageLoc))
                           .WithMessage(x => messagePhysicalDamageLoc);

                    //Property 360-> Optional	Vacancy Permit Deductible	If Vacancy Permit Deductible is selected but Deductible is NOT entered.
                    //Cannot Rate the quote as Vacancy Permit Deductible is invalid.
                    string messagePhysicalDeductible = Resources.ErrorMessages.Property360OptionalCoverageInputModelVacancyPermitsInputModelVacancyPermitLocationMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoverageVacancyPermitLocation(modelObject, ref messagePhysicalDeductible))
                            .WithMessage(x => messagePhysicalDeductible);

                    //171) Property 360-> Optional	
                    //Vacancy Permit Bldg	
                    //If Vacancy Permit coverage is selected but Bldg is NOT entered.
                    //Cannot Rate the quote as Vacancy Permit Bldg is invalid.
                    string message360OptionalCoverageVacancyPermitsInputModelVacancyPermitBuilding = Resources.ErrorMessages.Property360OptionalCoverageInputModelVacancyPermitsInputModelVacancyPermitBuildingMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                             Check360CoverageVacancyPermitBuilding(modelObject, ref message360OptionalCoverageVacancyPermitsInputModelVacancyPermitBuilding))
                            .WithMessage(x => message360OptionalCoverageVacancyPermitsInputModelVacancyPermitBuilding);

                    //172) Property 360-> Optional	
                    //Vacancy Permit Location Description	
                    //If Vacancy Permit coverage is selected but Location Description is NOT entered.
                    //Cannot Rate the quote as Vacancy Permit Location Description is invalid.
                    string message360OptionalCoverageVacancyPermitsInputModelVacancyPermitLocDescription = Resources.ErrorMessages.Property360OptionalCoverageInputModelVacancyPermitsInputModelVacancyPermitLocationDescriptionMissing;
                    this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoverageVacancyPermitLocationDescription(modelObject, ref message360OptionalCoverageVacancyPermitsInputModelVacancyPermitLocDescription))
                            .WithMessage(x => message360OptionalCoverageVacancyPermitsInputModelVacancyPermitLocDescription);

                });

                When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel != null
                 && reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel.Count > 0, () =>
                 {


                     //173) Property 360-> Optional	
                     //Vehicle Physical Damage Limit	
                     //If Vehicle Physical Damage coverage is selected but Limit is NOT entered.
                     //Cannot Rate the quote as Vehicle Physical Damage Limit is invalid.
                     string message360OptionalCoveragePhysicalDamagesInputModelVehiclePhysicalDamageLimit = Resources.ErrorMessages.Property360OptionalCoverageInputModelVehiclePhysicalDamagesInputModelVehiclePhysicalDamageLimitMissing;
                     this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoverageVehiclePhysicalDamageLimit(modelObject, ref message360OptionalCoveragePhysicalDamagesInputModelVehiclePhysicalDamageLimit))
                            .WithMessage(x => message360OptionalCoveragePhysicalDamagesInputModelVehiclePhysicalDamageLimit);

                     //174)Property 360-> Optional
                     //Vehicle Physical Damage Loc	
                     //If Vehicle Physical Damage coverage is selected but Loc is NOT entered.
                     //Cannot Rate the quote as Vehicle Physical Damage Loc is invalid.
                     string message360OptionalCoveragePhysicalDamagesInputModelVehiclePhysicalDamageLOC = Resources.ErrorMessages.Property360OptionalCoverageInputModelVehiclePhysicalDamagesInputModelVehiclePhysicalDamageLocationMissing;
                     this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoverageVehiclePhysicalDamageLocation(modelObject, ref message360OptionalCoveragePhysicalDamagesInputModelVehiclePhysicalDamageLOC))
                            .WithMessage(x => message360OptionalCoveragePhysicalDamagesInputModelVehiclePhysicalDamageLOC);

                     //175)Property 360-> Optional	
                     //Vehicle Physical Damage Bldg	
                     //If Vehicle Physical Damage coverage is selected but Bldg is NOT entered.
                     // Cannot Rate the quote as Vehicle Physical Damage Bldg is invalid.
                     string messagePhysicalDamageLocationLBldg = Resources.ErrorMessages.Property360OptionalCoverageInputModelVehiclePhysicalDamagesInputModelVehiclePhysicalDamageBuildingMissing;
                     this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoverageVehiclePhysicalDamageBuilding(modelObject, ref messagePhysicalDamageLocationLBldg))
                            .WithMessage(x => messagePhysicalDamageLocationLBldg);

                     //176) Property 360-> Optional	
                     //Vehicle Physical Damage Location Description	
                     //If Vehicle Physical Damage coverage is selected but Location Description is NOT entered.
                     //Cannot Rate the quote as Vehicle Physical Damage Location Description is invalid.
                     string messageVehiclePhysicalDamageLocationDescription = Resources.ErrorMessages.Property360OptionalCoverageInputModelVehiclePhysicalDamagesInputModeVehiclePhysicalDamageLocationDescriptionMissing;
                     this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel)
                            .Must((modelObject, businessIncomeAndExtraExpenseRevisedLimit) =>
                            Check360CoverageVehiclePhysicalDamageLocationDescription(modelObject, ref messageVehiclePhysicalDamageLocationDescription))
                            .WithMessage(x => messageVehiclePhysicalDamageLocationDescription);


                 });
            });

            #endregion

        }

        /// <summary>
        /// IsModelValid
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public bool IsModelValid(RaterFacadeModel model)
        {
            if (model != null && model.RaterInputFacadeModel.LineOfBusiness != null)
            {
                if (model.RaterInputFacadeModel.LineOfBusiness.Property == true && model.RaterInputFacadeModel.LineOfBusinessInputModel.Property == null)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// CheckRangeForValue
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="factorType"></param>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public bool CheckRangeForValue(decimal valueTocheck, string factorType, RaterFacadeModel model)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var propertyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            DataTable dataTable = null;
            bool flag = false;

            dataTable = this.DataAccess.GetMinMaxValueForFactor(policyHeaderModel.State, policyHeaderModel.PrimaryClass, propertyInputModel.LineOfBusiness, factorType, policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                throw new Exception(factorType + " range does not exist.");
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    throw new Exception(factorType + " Min range does not exist.");
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    throw new Exception(factorType + " Max range does not exist.");
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }

            return flag;
        }       

        /// <summary>
        /// CheckForMinMaxValueForHazard
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="category"></param>
        /// <param name="subCategory"></param>
        /// <param name="justification"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueForHazard(decimal valueTocheck, string category, string subCategory, string justification, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var propertyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetMinMaxValueForHazard(policyHeaderModel.State, propertyInputModel.LineOfBusiness, category, subCategory, justification,
                policyHeaderModel.PolicyEffectiveDate);
            if (dataTable == null)
            {
                message = !string.IsNullOrEmpty(subCategory) ? category + " - " + subCategory + " range does not exist." :
                          category + " - range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = !string.IsNullOrEmpty(subCategory) ? category + " - " + subCategory + " Min range does not exist."
                        : category + " - Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = !string.IsNullOrEmpty(subCategory) ? category + " - " + subCategory + " Max range does not exist."
                        : category + " - Max range does not exist.";
                }
                decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                if (valueTocheck >= minValue && valueTocheck <= maxValue)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckForMinMaxValueForFloodUnderDeficency
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="category"></param>
        /// <param name="subCategory"></param>
        /// <param name="justification"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueForFloodUnderDeficency(decimal valueTocheck, string category, string subCategory, string justification, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var propertyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            DataTable dataTable = null;
            bool flag = true;

            //For States - CT, GA, KS, ME, MS, MO, NH, OH, PA Input field is Subtotal of Flood as Deficiency Point Category.
            string[] stateCheck = new string[9] { "CT", "GA", "KS", "ME", "MS", "MO", "NH", "OH", "PA" };
            message = string.Empty;

            if (stateCheck.Contains(model.RaterInputFacadeModel.PolicyHeaderModel.State))
            {
                dataTable = this.DataAccess.GetMinMaxValueForHazard(policyHeaderModel.State, propertyInputModel.LineOfBusiness, category, subCategory, justification,
                policyHeaderModel.PolicyEffectiveDate);
                if (dataTable == null)
                {
                    message = !string.IsNullOrEmpty(subCategory) ? category + " - " + subCategory + " range does not exist." :
                        category + " -  range does not exist.";
                }
                else
                {
                    if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                    {
                        message = !string.IsNullOrEmpty(subCategory) ? category + " - " + subCategory + " Min range does not exist." :
                            category + " - Min range does not exist.";
                    }
                    if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                    {
                        message = !string.IsNullOrEmpty(subCategory) ? category + " - " + subCategory + " Max range does not exist."
                            : category + " - Max range does not exist.";
                    }
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                    if (valueTocheck >= minValue && valueTocheck <= maxValue)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }

            return flag;
        }

        /// <summary>
        /// CheckForMinMaxValueForFloodExposureUnderDeficency
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="category"></param>
        /// <param name="subCategory"></param>
        /// <param name="justification"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueForFloodExposureUnderDeficency(decimal valueTocheck, string category, string subCategory, string justification, RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var propertyInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property;
            DataTable dataTable = null;
            bool flag = true;
            message = string.Empty;
            //For States -AL, CO, DE, IL, IN, MA, MI, MN, NC, SC, TX, UT, VT, WY Input field is the Flood Exposure Deficiency point category. 
            string[] stateCheck = new string[14] { "AL", "CO", "DE", "IL", "IN", "MA", "MI", "MN", "NC", "SC", "TX", "UT", "VT", "WY" };

            if (stateCheck.Contains(model.RaterInputFacadeModel.PolicyHeaderModel.State))
            {
                dataTable = this.DataAccess.GetMinMaxValueForHazard(policyHeaderModel.State, propertyInputModel.LineOfBusiness, category, subCategory, justification,
                policyHeaderModel.PolicyEffectiveDate);
                if (dataTable == null)
                {
                    message = !string.IsNullOrEmpty(subCategory) ? category + " - " + subCategory + " range does not exist." :
                         category + " range does not exist.";
                }
                else
                {
                    if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                    {
                        message = string.IsNullOrEmpty(subCategory) ? category + " - " + subCategory + " Min range does not exist."
                            : category + " Min range does not exist.";
                    }
                    if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                    {
                        message = string.IsNullOrEmpty(subCategory) ? category + " - " + subCategory + " Max range does not exist."
                            : category + " Max range does not exist.";
                    }
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);
                    if (valueTocheck >= minValue && valueTocheck <= maxValue)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            else
            {
                flag = true;
            }
            return flag;
        }

        /// <summary>
        /// CheckSpoilageValue
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public bool CheckSpoilageValue(RaterFacadeModel model)
        {
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageDeductible > 0 && model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.SpoilageMinimumDeductible <= 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// CheckForOptionalCoverageADDITIONALCOVEREDPROPERTY
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public bool CheckForOptionalCoverageADDITIONALCOVEREDPROPERTY(RaterFacadeModel model)
        {
            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel;
            bool valueToReturn = true;
            if (checkModel.IsAdditionalCoveredPropertyOptionalCoverageSelected)
            {
                if (checkModel.AdditionalCoveredPropertyOptionalCoverage == "ADDITIONAL COVERED PROPERTY" && checkModel.AdditionalCoveredPropertyPremium == 0)
                {
                    valueToReturn = false;
                }
            }
            return valueToReturn;
        }

        /// <summary>
        /// CheckForOptionalCoverageFlatCharge
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool CheckForOptionalCoverageFlatCharge(RaterFacadeModel model, ref String errorMessages)
        {
            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel;
            bool valueToReturn = true;
            int index = 1;
            //String stringIndex = string.Empty;
            if (checkModel != null)
            {
                foreach (var optionalCoverage in checkModel)
                {
                    if (optionalCoverage.IsOptionalCoverageSelected && optionalCoverage.RatingBasis.ToUpper() == "FLAT CHARGE" && optionalCoverage.Premium == 0)
                    {
                        valueToReturn = false;
                        //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + "," + index) : index.ToString();
                    }
                    index++;
                }
            }

            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return valueToReturn;
        }

        /// <summary>
        /// CheckForOtherOptionalCoverageRatingBasis
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool CheckForOtherOptionalCoverageRatingBasis(RaterFacadeModel model, ref String errorMessages)
        {
            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel;
            bool valueToReturn = true;
            int index = 1;
            //String stringIndex = string.Empty;
            if (checkModel != null)
            {
                foreach (var optionalCoverage in checkModel)
                {
                    if (optionalCoverage.IsOptionalCoverageSelected)
                    {
                        if (!string.IsNullOrEmpty(optionalCoverage.OptionalCoverageName) && optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER")
                        {
                            if (string.IsNullOrEmpty(optionalCoverage.RatingBasis))
                            {
                                valueToReturn = false;
                                //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                            }
                        }
                    }
                    index++;
                }
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return valueToReturn;
        }

        /// <summary>
        /// CheckForOtherOptionalCoverage
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool CheckForOtherOptionalCoverage(RaterFacadeModel model, ref String errorMessages)
        {
            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel;
            bool valueToReturn = true;
            int index = 1;
            //String stringIndex = string.Empty;
            if (checkModel != null)
            {
                foreach (var optionalCoverage in checkModel)
                {
                    if (optionalCoverage.IsOptionalCoverageSelected)
                    {
                        if (!string.IsNullOrEmpty(optionalCoverage.OptionalCoverageName) && optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER")
                        {
                            if (string.IsNullOrEmpty(optionalCoverage.Description))
                            {
                                valueToReturn = false;
                                //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                            }
                        }
                    }
                    index++;
                }
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return valueToReturn;
        }

        /// <summary>
        /// CheckForOptionalCoverageOtherForLimit
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool CheckForOptionalCoverageOtherForLimit(RaterFacadeModel model, ref String errorMessages)
        {
            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel;
            bool valueToReturn = true;
            int index = 1;
            //String stringIndex = string.Empty;
            if (checkModel != null)
            {
                foreach (var optionalCoverage in checkModel)
                {
                    if (optionalCoverage.IsOptionalCoverageSelected && optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER" && (optionalCoverage.RatingBasis.ToUpper() == "PER 1000 OF LIMIT" || optionalCoverage.RatingBasis.ToUpper() == "PER 100 OF LIMIT") && optionalCoverage.Limit == 0)
                    {
                        valueToReturn = false;
                        //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                    }
                    index++;
                }
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return valueToReturn;
        }

        /// <summary>
        /// CheckForOptionalCoverageOtherForRate
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool CheckForOptionalCoverageOtherForRate(RaterFacadeModel model, ref String errorMessages)
        {
            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel.PropertyOptionalOthersCoverageInputModel;
            bool valueToReturn = true;
            int index = 1;
            //String stringIndex = string.Empty;
            if (checkModel != null)
            {
                foreach (var optionalCoverage in checkModel)
                {
                    if (optionalCoverage.IsOptionalCoverageSelected && optionalCoverage.OptionalCoverageName.ToUpper() == "OTHER" && (optionalCoverage.RatingBasis.ToUpper() == "PER 1000 OF LIMIT" || optionalCoverage.RatingBasis.ToUpper() == "PER 100 OF LIMIT") && optionalCoverage.Rate == 0)
                    {
                        valueToReturn = false;
                        //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                    }
                    index++;
                }
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return valueToReturn;
        }

        /// <summary>
        /// CheckForOptionalCoverageALABAMAWINDHAILPremiumLimit
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool CheckForOptionalCoverageALABAMAWINDHAILPremiumLimit(RaterFacadeModel model, ref String errorMessages)
        {
            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel;
            bool valueToReturn = true;
            //change 16-07-2020
            if (checkModel.IsAlabamaWindAndHailCertificateCreditCoverageSelected)
            {
                if (checkModel.AlabamaWindAndHailCertificateCreditCoverage.ToUpper() == "ALABAMA WIND & HAIL CERTIFICATE CREDIT" && checkModel.AlabamaWindAndHailCertificateCreditPremium > -100000)
                {
                    valueToReturn = false;
                }
            }
            return valueToReturn;
        }

        /// <summary>
        /// CheckForOptionalCoverageALABAMAWINDHAILPremiumState
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool CheckForOptionalCoverageALABAMAWINDHAILPremiumState(RaterFacadeModel model, ref String errorMessages)
        {

            var checkModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.PropertyOptionalCoveragesModel;
            bool valueToReturn = false;
            //change 16-07-2020
            //int index = 1;
            //String stringIndex = string.Empty;
            if (checkModel.IsAlabamaWindAndHailCertificateCreditCoverageSelected)
            {
                if (checkModel.AlabamaWindAndHailCertificateCreditCoverage.ToUpper() == "ALABAMA WIND & HAIL CERTIFICATE CREDIT" && model.RaterInputFacadeModel.PolicyHeaderModel.State.ToUpper() == StateCodeConstant.AL)
                {
                    valueToReturn = true;
                }
                //else
                //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
            }
            else
            {
                valueToReturn = true;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return valueToReturn;
        }

        /// <summary>
        /// Check360CoveragePremiumAndLimits
        /// </summary>
        /// <param name="limitValue"></param>
        /// <returns>bool</returns>
        public bool Check360CoveragePremiumAndLimits(decimal limitValue)
        {
            if (limitValue <= 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }


        /// <summary>
        /// IsProRatafactorWithDatesValid
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public bool IsProRatafactorWithDatesValid(RaterFacadeModel model)
        {
            bool returnFlag = false;
            if ((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).TotalDays != 0)
            {
                decimal proRatafactor = Math.Round(Convert.ToDecimal((model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.TransactionEffectiveDate).TotalDays / (model.RaterInputFacadeModel.PolicyHeaderModel.PolicyExpirationDate - model.RaterInputFacadeModel.PolicyHeaderModel.PolicyEffectiveDate).TotalDays), 2, MidpointRounding.AwayFromZero);
                if (proRatafactor <= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return returnFlag;
            }
        }

        /// <summary>
        /// CheckTotalTIV
        /// </summary>
        /// <param name="model"></param>
        /// <returns>bool</returns>
        public bool CheckTotalTIV(RaterFacadeModel model)
        {
            //change 16-07-2020
            if ((model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.BuildingTIV + model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.ContentTIV) > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //change 16-07-2020

        /// <summary>
        /// Check360CoveragePremiumAndLimitsForLossOfMunicipal
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoveragePremiumAndLimitsForLossOfMunicipal(RaterFacadeModel model, ref String errorMessages)
        {
            bool returnFlag = true;
            int index = 1;
            //String stringIndex = string.Empty;
            if (model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel != null &&
                model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel != null)
            {
                foreach (var item in model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.LossOfMunicipalTaxRevenuesInputModel)
                {
                    if (item.IsLossOfMunicipalTaxRevenueCoverageSelected && item.LossOfMunicipalTaxRevenueRevisedLimit == 0)
                    {
                        returnFlag = false;
                        //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                    }
                    else
                    {
                        returnFlag = true;
                    }
                    index++;
                }
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return returnFlag;

        }


        /// <summary>
        /// ValidateSpoilageType
        /// </summary>
        /// <param name="spoilageType"></param>
        /// <returns>bool</returns>
        public bool ValidateSpoilageType(string spoilageType)
        {
            if (spoilageType == "Type1" || spoilageType == "Type2")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //If Vehicle Physical Damage coverage is selected but Location Description is NOT entered.
        /// <summary>
        /// Check360CoverageVehiclePhysicalDamageLocationDescription
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageVehiclePhysicalDamageLocationDescription(RaterFacadeModel model, ref String errorMessages)
        {
            bool is_valid = true;
            var vehiclePhysicalDamagesInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel;
            int index = 1;
            //String stringIndex = string.Empty;
            foreach (var item in vehiclePhysicalDamagesInputModel)
            {
                if (item.IsVehiclePhysicalDamageCoverageSelected && string.IsNullOrEmpty(item.VehiclePhysicalDamageLocationDescription))
                {
                    is_valid = false;
                    //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                }
                index++;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return is_valid;
        }

        //If Vehicle Physical Damage coverage is selected but Bldg is NOT entered.

        /// <summary>
        /// Check360CoverageVehiclePhysicalDamageBuilding
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageVehiclePhysicalDamageBuilding(RaterFacadeModel model, ref String errorMessages)
        {
            bool is_valid = true;
            var vehiclePhysicalDamagesInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel;
            int index = 1;
            ////String stringIndex = string.Empty;
            foreach (var item in vehiclePhysicalDamagesInputModel)
            {
                if (item.IsVehiclePhysicalDamageCoverageSelected && item.VehiclePhysicalDamageBuilding <= 0)
                {
                    is_valid = false;
                    //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                }
                index++;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return is_valid;
        }
        //If Vehicle Physical Damage coverage is selected but Loc is NOT entered.

        /// <summary>
        /// Check360CoverageVehiclePhysicalDamageLocation
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageVehiclePhysicalDamageLocation(RaterFacadeModel model, ref String errorMessages)
        {
            bool is_valid = true;
            var vehiclePhysicalDamagesInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel;
            int index = 1;
            //String stringIndex = string.Empty;
            foreach (var item in vehiclePhysicalDamagesInputModel)
            {
                if (item.IsVehiclePhysicalDamageCoverageSelected && item.VehiclePhysicalDamageLocation <= 0)
                {
                    is_valid = false;
                    //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                }
                index++;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return is_valid;
        }
        //If Vehicle Physical Damage coverage is selected but Limit is NOT entered.

        /// <summary>
        /// Check360CoverageVehiclePhysicalDamageLimit
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageVehiclePhysicalDamageLimit(RaterFacadeModel model, ref String errorMessages)
        {
            bool is_valid = true;
            var vehiclePhysicalDamagesInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VehiclePhysicalDamagesInputModel;
            int index = 1;
            //String stringIndex = string.Empty;
            foreach (var item in vehiclePhysicalDamagesInputModel)
            {
                if (item.IsVehiclePhysicalDamageCoverageSelected && item.VehiclePhysicalDamageLimit <= 0)
                {
                    is_valid = false;
                    //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                }
                index++;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return is_valid;
        }

        //If Vehicle Physical Damage coverage is selected but Limit is NOT entered.
        /// <summary>
        /// Check360CoverageVacancyPermitLocationDescription
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageVacancyPermitLocationDescription(RaterFacadeModel model, ref String errorMessages)
        {
            bool is_valid = true;
            int index = 0;
            //String stringIndex = string.Empty;
            var vacancyPermitsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel;

            foreach (var item in vacancyPermitsInputModel)
            {
                if (item.IsVacancyPermitCoverageSelected && string.IsNullOrEmpty(item.VacancyPermitLocationDescription))
                {
                    is_valid = false;
                    //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                }
                index++;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return is_valid;
        }

        //If Vacancy Permit coverage is selected but Bldg is NOT entered.
        /// <summary>
        /// Check360CoverageVacancyPermitBuilding
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageVacancyPermitBuilding(RaterFacadeModel model, ref String errorMessages)
        {
            bool is_valid = true;
            int index = 0;
            var vacancyPermitsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel;
            //String stringIndex = string.Empty;
            foreach (var item in vacancyPermitsInputModel)
            {
                if (item.IsVacancyPermitCoverageSelected && item.VacancyPermitBuilding <= 0)
                {
                    is_valid = false;
                    //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                }
                index++;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return is_valid;
        }

        //If Vacancy Permit coverage is selected but Loc is NOT entered.
        /// <summary>
        /// Check360CoverageVacancyPermitLocation
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageVacancyPermitLocation(RaterFacadeModel model, ref String errorMessages)
        {
            bool is_valid = true;
            var vacancyPermitsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel;
            int index = 1;
            //String stringIndex = string.Empty;
            foreach (var item in vacancyPermitsInputModel)
            {
                if (item.IsVacancyPermitCoverageSelected && item.VacancyPermitLocation <= 0)
                {
                    is_valid = false;
                    //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                }
                index++;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return is_valid;
        }

        //Change 19-07-2021 by Mamta
        //If coverage is selected but Limit is NOT entered.
        /// <summary>
        /// Check360CoverageDescription
        /// </summary>
        /// <param name="stringDescription"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageDescription(string stringDescription)
        {
            if (!string.IsNullOrEmpty(stringDescription))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //If Vacancy Permit Limit coverage is selected but Limit is NOT entered.
        /// <summary>
        /// Check360CoverageVacancyPermitLimit
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageVacancyPermitLimit(RaterFacadeModel model, ref String errorMessages)
        {
            bool is_valid = true;
            var vacancyPermitsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel;
            int index = 1;
            //String stringIndex = string.Empty;
            foreach (var item in vacancyPermitsInputModel)
            {
                if (item.IsVacancyPermitCoverageSelected && item.VacancyPermitLimit <= 0)
                {
                    is_valid = false;
                    //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                }
                index++;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return is_valid;
        }

        //If Vacancy Permit Limit coverage is selected but Deductible is NOT entered.
        /// <summary>
        /// Check360CoverageVacancyPermitDeductible
        /// </summary>
        /// <param name="model"></param>
        /// <param name="errorMessages"></param>
        /// <returns>bool</returns>
        public bool Check360CoverageVacancyPermitDeductible(RaterFacadeModel model, ref String errorMessages)
        {
            bool is_valid = true;
            var vacancyPermitsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.Property.Property360InputModel.Property360OptionalCoverageInputModel.VacancyPermitsInputModel;
            int index = 1;
            //String stringIndex = string.Empty;
            foreach (var item in vacancyPermitsInputModel)
            {
                if (item.IsVacancyPermitCoverageSelected && item.VacancyPermitDeductible <= 0)
                {
                    is_valid = false;
                    //stringIndex = !string.IsNullOrEmpty(stringIndex) ? (stringIndex + ","+ index ): index.ToString();
                }
                index++;
            }
            //errorMessages= !string.IsNullOrEmpty(stringIndex) ? (errorMessages+ "At indexes [" + stringIndex + "]"): errorMessages;
            return is_valid;
        }

        /// <summary>
        /// CheckCoveragePermitstring
        /// </summary>
        /// <param name="valuePremium"></param>
        /// <returns>bool</returns>
        public bool CheckCoveragePermitstring(string isChecked, decimal valuePremium)
        {
            if ((!string.IsNullOrEmpty(isChecked) && valuePremium > 0) || (string.IsNullOrEmpty(isChecked) && valuePremium == 0))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// CheckCoveragePermit
        /// </summary>
        /// <param name="isChecked"></param>
        /// <param name="valuePremium"></param>
        /// <returns>bool</returns>
        public bool CheckCoveragePermit(decimal valuePremium)
        {
            if (valuePremium > 0) 
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// CheckCoveragePermitstringwithValue
        /// </summary>
        /// <param name="isChecked"></param>
        /// <param name="valuePremium"></param>
        /// <param name="valuetocheck"></param>
        /// <returns>bool</returns>
        public bool CheckCoveragePermitstringwithValue(string isChecked, decimal valuePremium, string valuetocheck)
        {
            bool isValid = false;
            if (string.IsNullOrEmpty(isChecked))
            {
                isValid = true;
            }
            else if (!string.IsNullOrEmpty(isChecked))
            {
                if (isChecked.ToUpper() == valuetocheck.ToUpper())
                {
                    if (valuePremium > 0)
                        isValid = true;
                }
                else
                {
                    isValid = true;
                }
            }
            return isValid;
        }

    }
}
