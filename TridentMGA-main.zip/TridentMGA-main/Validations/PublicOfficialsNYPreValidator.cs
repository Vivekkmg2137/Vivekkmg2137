﻿namespace Validations
{
    using AutoMapper;
    using DataAccess;
    using FluentValidation;
    using Logging;
    using Microsoft.Extensions.Configuration;
    using Models;
    using Models.ApiModels;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Text;

    /// <summary>
    /// PublicOfficialsNYPreValidator
    /// </summary>
    public class PublicOfficialsNYPreValidator : AbstractValidator<RaterFacadeModel>
    {
        /// <summary>
        /// DataAccess Object
        /// </summary>
        private PublicOfficialsDataAccess DataAccess { get; set; }

        /// <summary>
        /// Logger Object
        /// </summary>
        protected ILoggingManager Logger { get; private set; }

        /// <summary>
        /// Configuration Object
        /// </summary>
        readonly IConfiguration configuration;

        /// <summary>
        /// Mapper Object
        /// </summary>
        private readonly IMapper _mapper;

        /// <summary>
        /// PublicOfficialsNYPreValidator
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public PublicOfficialsNYPreValidator(IConfiguration configuration, ILoggingManager logger)
        {
            this.configuration = configuration;
            this.Logger = logger;
            this.DataAccess = new PublicOfficialsDataAccess(this.configuration, this.Logger);

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.LiabilityLimitRate >= 0, () =>
            {
                //If 'Limit Rate' is Incorrectly received by the rater i.e.not in the range of lookup
                //Cannot Rate the quote as 'Rate' entered is not in the allowed range
                string stringLiabilityLimitRate = string.Empty;
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.LiabilityLimitRate)
                    .Must((modelObject, value) => CheckForMinMaxValueLiabilityLimitRate(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.LiabilityLimitRate,2),modelObject, out stringLiabilityLimitRate))
                    .WithMessage(x => !string.IsNullOrEmpty(stringLiabilityLimitRate) ? stringLiabilityLimitRate : Resources.ErrorMessages.InputPublicOfficialsLimitRateNotInRange);
            });

            //If 'Deductible/SIR' is selected as 'Deductible' & 'Retention' entered is not applicable or not as per the lookup values per state
            //Cannot Rate the Quote as the 'Retention' is not applicable
            string stringRetention = string.Empty;
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.DeductibleSIR.ToUpper() == "DEDUCTIBLE" ||
            reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.DeductibleSIR.ToUpper() == "SIR", () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.Retention)
                    .Must((modelObject, value) => CheckForApplicableDeductible(modelObject, out stringRetention))
                    .WithMessage(x => !string.IsNullOrEmpty(stringRetention) ? stringRetention : Resources.ErrorMessages.InputPublicOfficialsRetentionNotApplicableForState);
            });

            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.ExposureRate >= 0, () =>
            {
                string stringExposureRate = string.Empty;
                //If 'Exposure Rate' is Incorrectly received by the rater i.e.not in the range of lookup   
                //Cannot Rate the quote as 'Exposure Rate' entered is not in the allowed range
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.ExposureRate)
                    .Must((modelObject, value) => CheckForMinMaxValueExposureRate(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.ExposureRate,2),modelObject,out stringExposureRate))
                    .WithMessage(x => !string.IsNullOrEmpty(stringExposureRate)? stringExposureRate : Resources.ErrorMessages.InputPublicOfficialsExposureRateNotInRange);
            });

            /*
            //If this coverage is checked on the UI for not applicable states(when JSON tag - 'Suppl. Extended Reporting PeriodIsSelected' = True) Possibly combine these edits   
            //Cannot Rate the quote as 'Suppl. Extended Reporting Period' is not applicable for the selected State
            string stringSupplExtendedReportingPeriod = string.Empty;
            When(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected, () =>
            {
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                     .Must((modelObject, value) =>
                            CheckApplicableOptionalCoverage(modelObject,
                                                            "Suppl. Extended Reporting Period",
                                                            false,
                                                            out stringSupplExtendedReportingPeriod))
                     .WithMessage(x => !string.IsNullOrEmpty(stringSupplExtendedReportingPeriod)
                                        ? stringSupplExtendedReportingPeriod :
                                        Resources.ErrorMessages.InputPublicOfficialsSupplExtendedReportingPeriodNotApplicableForState);

                //If this coverage is checked on the UI for not applicable states & Primary Class Combination(when JSON tag - 'Suppl. Extended Reporting PeriodIsSelected' = True)
                //Cannot Rate the quote as 'Suppl. Extended Reporting Period' is not applicable for the selected State & Primary Class Combination
                this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.PublicOfficialsOptionalCoverageModel.SupplExtendedReportingPeriodIsSelected)
                     .Must((modelObject, value) =>
                            CheckApplicableOptionalCoverage(modelObject,
                                                             "Suppl. Extended Reporting Period",
                                                             true,
                                                             out stringSupplExtendedReportingPeriod))
                     .WithMessage(x => !string.IsNullOrEmpty(stringSupplExtendedReportingPeriod)
                                         ? stringSupplExtendedReportingPeriod :
                                         Resources.ErrorMessages.InputPublicOfficialsSupplExtendedReportingPeriodWithPrimaryClassNotApplicableForState);
            });
            */
      
            //If 'IRPM Factor' entered is not within the lookup columns range
            //Cannot Rate the quote as 'IRPM' value is invalid
            string stringIRPMFactor = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.IRPMFactor)
                .Must((modelObject, value) => CheckForMinMaxValueIRPMFactor(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.IRPMFactor, modelObject, out stringIRPMFactor))
                .WithMessage(x => !string.IsNullOrEmpty(stringIRPMFactor)? stringIRPMFactor : Resources.ErrorMessages.InputPublicOfficialsIRPMFactorNotInRange);

            //If 'Other Mod Factor' entered is not within the lookup columns range
            // Cannot Rate the quote as 'Other Mod Factor' value is invalid
            string stringOtherModFactor = string.Empty;
            this.RuleFor(reg => reg.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.OtherModRate)
                .Must((modelObject, value) => CheckForMinMaxValueOtherModFactor(Math.Round(modelObject.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY.OtherModRate,  2), modelObject, out stringOtherModFactor))
                .WithMessage(x => !string.IsNullOrEmpty(stringOtherModFactor) ? stringOtherModFactor : Resources.ErrorMessages.InputPublicOfficialsOtherModFactorNotInRange);

            //If 'Population / ADA' Is not received by the rater       
            //Cannot Rate the quote as 'Population / ADA' is mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .NotNull()
                .WithMessage(x => Resources.ErrorMessages.InputPublicOfficialsPopulationADARequired);

            //If 'Population / ADA' entered is greater than 99999999   
            // Cannot Rate the quote as 'Population / ADA' is invalid
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PopulationADA)
                .LessThanOrEqualTo(99999999)
                .WithMessage(x => Resources.ErrorMessages.InputPublicOfficialsPopulationADAOutOfRange);

            //If 'Location Type' is not received by the rater
            // Cannot Rate the quote as 'Location Type' is mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.LocationType)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelPublicOfficialsLocationTypeRequired);

            //If 'Primary Class' is not received by the rater   
            //Cannot Rate the quote as 'Primary Class' is mandatory
            this.RuleFor(reg => reg.RaterInputFacadeModel.PolicyHeaderModel.PrimaryClass)
                .NotEmpty()
                .WithMessage(x => Resources.ErrorMessages.InputModelPublicOfficialsPrimaryClassRequired);
        }

        /// <summary>
        /// Check For Min Max Value Liability Limit Rate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueLiabilityLimitRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var publicOfficialsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetProfLinesLiabilityLimitRateMinMax(policyHeaderModel.State,
                                                                                publicOfficialsInputModel.LineOfBusiness,
                                                                                publicOfficialsInputModel.LiabilityLimit,
                                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                                policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "LiabilityLimitRate" + publicOfficialsInputModel.LiabilityLimit + " range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["Factor"] == DBNull.Value)
                {
                    message = "LiabilityLimitRate " + publicOfficialsInputModel.LiabilityLimit + " range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    flag = true;
                }
            }

            return flag;
        }
        /// <summary>
        /// Check For Min Max Value Exposure Rate
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueExposureRate(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var publicOfficialsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetProfLinesExposureRate(policyHeaderModel.State,
                                                                 policyHeaderModel.PrimaryClass,
                                                                 publicOfficialsInputModel.LineOfBusiness,
                                                                 policyHeaderModel.PolicyEffectiveDate,
                                                                 policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "ExposureRate range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["BaseRate"] == DBNull.Value)
                {
                    message = "ExposureRate Min range does not exist.";
                }
                
                if (string.IsNullOrEmpty(message))
                {
                    flag = true;
                }
            }

            return flag;
        }
        /// <summary>
        /// Check For Min Max Value IRPM Factor
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueIRPMFactor(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var publicOfficialsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetIRPMRateMinMax(policyHeaderModel.State,
                                                            publicOfficialsInputModel.LineOfBusiness,
                                                            policyHeaderModel.PolicyEffectiveDate,
                                                            policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "IRPMFactor range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "IRPMFactor Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "IRPMFactor Max range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }
            return flag;
        }
        /// <summary>
        /// Check For Min Max Value Other Mod Factor
        /// </summary>
        /// <param name="valueTocheck"></param>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForMinMaxValueOtherModFactor(decimal valueTocheck, RaterFacadeModel model, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var publicOfficialsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetOtherModRateMinMax(policyHeaderModel.State,
                                                                publicOfficialsInputModel.LineOfBusiness,
                                                                policyHeaderModel.PolicyEffectiveDate,
                                                                policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "OtherModFactor range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["MinValue"] == DBNull.Value)
                {
                    message = "OtherModFactor Min range does not exist.";
                }
                if (dataTable.Rows[0]["MaxValue"] == DBNull.Value)
                {
                    message = "OtherModFactor Max range does not exist.";
                }
                if (string.IsNullOrEmpty(message))
                {
                    decimal minValue = Convert.ToDecimal(dataTable.Rows[0]["MinValue"]);
                    decimal maxValue = Convert.ToDecimal(dataTable.Rows[0]["MaxValue"]);

                    flag = (valueTocheck >= minValue && valueTocheck <= maxValue) ? true : false;
                }
            }

            return flag;
        }
        /// <summary>
        /// Check For Applicable Deductible
        /// </summary>
        /// <param name="model"></param>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public bool CheckForApplicableDeductible(RaterFacadeModel model, out string message)
        {
            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var publicOfficialsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            dataTable = this.DataAccess.GetProfLinesApplicableDeductible(policyHeaderModel.State,
                                                                            publicOfficialsInputModel.LineOfBusiness,
                                                                            publicOfficialsInputModel.DeductibleSIR,
                                                                            publicOfficialsInputModel.Retention,
                                                                            policyHeaderModel.PolicyEffectiveDate,
                                                                            policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "ApplicableDeductible " + publicOfficialsInputModel.Retention + " range does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["IsApplicable"] != DBNull.Value)
                {
                    flag = Convert.ToBoolean(dataTable.Rows[0]["IsApplicable"]);
                }

            }

            return flag;
        }
        /// <summary>
        /// Check Applicable Optional Coverage
        /// </summary>
        /// <param name="model"></param>
        /// <param name="coverage"></param>
        /// <param name="checkprimaryclass"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool CheckApplicableOptionalCoverage(RaterFacadeModel model, string coverage, bool checkprimaryclass, out string message)
        {

            var policyHeaderModel = model.RaterInputFacadeModel.PolicyHeaderModel;
            var publicOfficialsInputModel = model.RaterInputFacadeModel.LineOfBusinessInputModel.PublicOfficials.NY;
            DataTable dataTable = null;
            bool flag = false;
            message = string.Empty;
            string paraState = !string.IsNullOrEmpty(policyHeaderModel.State) ? policyHeaderModel.State : StateCodeConstant.CW;
            string paraPrimaryClass = !string.IsNullOrEmpty(policyHeaderModel.PrimaryClass) ? policyHeaderModel.PrimaryClass : "ALL";
            dataTable = this.DataAccess.GetCheckProfLinesApplicableOptionalCoverage(paraState,
                                                                                        (checkprimaryclass ? paraPrimaryClass : null),
                                                                                        publicOfficialsInputModel.LineOfBusiness,
                                                                                        coverage, policyHeaderModel.PolicyEffectiveDate,
                                                                                        policyHeaderModel.PolicyExpirationDate);
            if (dataTable == null)
            {
                message = "OptionalCoverage " + coverage + " does not exist.";
            }
            else
            {
                if (dataTable.Rows[0]["IsApplicable"] != DBNull.Value)
                {
                    flag = Convert.ToBoolean(dataTable.Rows[0]["IsApplicable"]);
                }
            }
            return flag;
        }
    }
}
